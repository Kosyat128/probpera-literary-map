# Genuine next country UI preflight defect

Actual current review helper and installed SDK: a private country candidate is
initially approvable. Changing only opaque override rights while its timestamp,
catalogue, EN and all other fields remain exact still gives canPromote=true.
The frozen target expects false and FAILS; all controls PASS, two controlled
calls remain unchanged, canonical machine writes and builds remain zero.

This is the earlier UI preflight only. Separate native SQL proves atomic human
approval refuses full override drift. No unsafe canonical write is claimed.
Source graph, original diagnostic and transport support are frozen. Deliberate
path/loader adaptation is needed to replay against frozen sources; preserve
this genuine BEFORE and its target assertion. No live provider was used.
