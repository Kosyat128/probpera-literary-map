const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {createHash}=require('node:crypto');
const repo=path.resolve(__dirname,'../probpera-literary-map'),out=path.resolve(__dirname,'catalog-review-country-before');
if(fs.existsSync(out))throw Error('Never replace a genuine BEFORE');
fs.mkdirSync(out,{recursive:true});
Object.assign(process.env,{CATALOG_ADMISSION_REPO:repo,CATALOG_ADMISSION_SOURCE_ROOT:repo,CATALOG_ADMISSION_OUTPUT_ROOT:path.join(out,'controlled')});
const runtime=require(path.join(repo,'apps/admin/lib/fixtures/catalog-admission-runtime.cjs'));
async function main(){
 const view=runtime.setup('country');const generated=await view.helper();assert.equal(generated.state,'translated');
 const api=view.load('apps/admin/lib/premium-translation-review.ts');
 const inspect=()=>api.loadPremiumTranslationReview({supabase:view.sdk,entityType:'country',entityId:view.identity(0),sourceFields:structuredClone(view.rows[0].fields)});
 const initial=await inspect();assert.equal(initial.status,'pending');assert.equal(initial.canPromote,true);
 const before=structuredClone(view.rows[0]);
 view.rows[0].row.fields.rights='Changed country override rights with identical timestamp';
 const after=await inspect();
 assert.deepEqual(view.rows[0],{...before,row:{...before.row,fields:{...before.row.fields,rights:view.rows[0].row.fields.rights}}});
 assert.equal(view.rows[0].row.updated_at,before.row.updated_at);
 assert.equal(view.providerCalls.length,2);assert.equal(view.writes.length,0);assert.equal(view.builds.length,0);
 const graph=[...view.graph.values()].sort((a,b)=>a.module.localeCompare(b.module));
 for(const source of graph){const data=fs.readFileSync(path.join(repo,source.module));assert.equal(createHash('sha256').update(data).digest('hex'),source.sha256);
  const dest=path.join(out,'sources',source.module);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,data,{flag:'wx'});}
 const report={classification:'GENUINE_NEXT_COUNTRY_UI_PREFLIGHT_DEFECT_NOT_ACCEPTANCE_PASS',generated,initial,after,
  onlyOverrideRightsChanged:true,catalogAndOtherOverrideFieldsExact:true,overrideTimestampExact:true,providerCalls:2,canonicalWrites:0,publicBuildRequests:0,graph,
  assertion:{expectedCanPromote:false,actualCanPromote:after.canPromote,pass:after.status==='pending'&&after.canPromote===false},
  scope:'Actual review helper and installed SDK-controlled reads; separate native SQL proves atomic approval refuses full override drift.'};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({classification:report.classification,controlChecks:'PASS',target:report.assertion,sourceCount:graph.length}));
 assert.equal(report.assertion.pass,true,'Country UI preflight must close approval after full override rights drift without timestamp changes');
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
