const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),prior=path.resolve(__dirname,'../writer-operation-sql-native');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
if(fs.existsSync(path.join(__dirname,'new-run.log'))&&fs.existsSync(path.join(__dirname,'source-manifest.json'))){
 const previous=JSON.parse(fs.readFileSync(path.join(__dirname,'source-manifest.json'),'utf8'));
 const history=path.join(__dirname,'history',previous.fixtureSha256.slice(0,16));fs.mkdirSync(history,{recursive:true});
 for(const file of ['fixture.sql','source-manifest.json','new-run.log','new-cleanup.json','new-cleanup.log'])if(fs.existsSync(path.join(__dirname,file))&&!fs.existsSync(path.join(history,file)))fs.copyFileSync(path.join(__dirname,file),path.join(history,file));
}
const manifest=JSON.parse(fs.readFileSync(path.join(prior,'source-manifest.json'),'utf8'));
for(const source of [...manifest.foundation.sources,...manifest.sources])if(hash(fs.readFileSync(path.join(repo,source.file)))!==source.sha256)throw Error('Original immutable SQL drift '+source.file);
const foundation=fs.readFileSync(path.join(prior,'fixture.sql'));
if(hash(foundation)!==manifest.fixtureSha256)throw Error('Original native fixture changed');
const sources=[];
const read=file=>{const b=fs.readFileSync(path.join(repo,file));const target=path.join(__dirname,'sources',file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,b);sources.push({file,sha256:hash(b)});return b.toString('utf8');};
const sql=[foundation.toString(),read('supabase/migrations/20261029220832_catalog_translation_operation_admission.sql'),
 read('scripts/database/fixtures/catalog-translation-operation-admission.sql')].join('\n');
fs.writeFileSync(path.join(__dirname,'fixture.sql'),sql);
fs.writeFileSync(path.join(__dirname,'source-manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),sources,foundation:manifest,foundationSha256:hash(foundation),fixtureSha256:hash(sql)},null,2));
const db=process.argv[2]||'catalog_operations_v1_20261030';
const runner=fs.readFileSync(path.join(prior,'run-probe.ps1'),'utf8').replaceAll('writer-operation-sql-native','catalog-operation-sql-native')
 .replace(/writer_operations_v\d+_20261029/g,db);
fs.writeFileSync(path.join(__dirname,'run-probe.ps1'),runner);
console.log(JSON.stringify({database:db,fixtureSha256:hash(sql),sources:sources.length}));
