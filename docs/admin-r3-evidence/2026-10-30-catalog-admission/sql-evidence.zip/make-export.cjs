const fs=require('node:fs'),path=require('node:path');
const original=fs.readFileSync(path.resolve(__dirname,'../writer-operation-sql-native/concurrent-and-export.ps1'),'utf8');
const header=original.slice(0,original.indexOf(" $database='"));
const footer=original.slice(original.indexOf('}finally{'));
const body=fs.readFileSync(path.join(__dirname,'export-body.ps1'),'utf8');
fs.writeFileSync(path.join(__dirname,'concurrent-and-export.ps1'),(header+body+'\n'+footer).replaceAll('writer-operation-sql-native','catalog-operation-sql-native'));
