create function public.reconcile_catalog_translation_operation(p_entity_type text,p_entity_id text,p_operation_id uuid default null)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; identity text;
begin
  perform premium_translation_private.assert_actor();identity:=premium_translation_private.catalog_operation_identity(p_entity_type,p_entity_id);
  perform pg_advisory_xact_lock(hashtextextended('catalog-operation:'||p_entity_type||':'||identity,7291));
  select cache.* into a from premium_translation_private.catalog_operation_artifacts cache join public.translation_job_items item on item.id=cache.item_id
    where cache.entity_type=p_entity_type and cache.entity_id=identity and (p_operation_id is null or cache.operation_id=p_operation_id)
    order by (item.staff_retry is not null) desc,cache.created_at desc,cache.operation_id desc limit 1;
  if a.operation_id is null then return null; end if;
  return premium_translation_private.catalog_operation_view(a,true);
end; $$;
