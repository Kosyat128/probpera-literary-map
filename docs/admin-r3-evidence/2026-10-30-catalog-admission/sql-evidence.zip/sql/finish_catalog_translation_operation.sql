create function public.finish_catalog_translation_operation(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_candidate jsonb default null
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; j public.translation_jobs%rowtype;
  i public.translation_job_items%rowtype; attempt public.translation_job_attempts%rowtype;
  draft public.premium_translation_working_drafts%rowtype; current_work jsonb; current_ru jsonb; current_sources jsonb; selected_source jsonb; urls jsonb; n integer;
  fingerprint text; digest text; status text; code text; state text; persistence text:='none'; result jsonb; receipt jsonb;
  first_call jsonb; last_call jsonb; stamp timestamptz:=clock_timestamp(); current_bound boolean:=true;
begin
  a:=premium_translation_private.catalog_operation_owned(p_job_id,p_item_id,p_operation_id);
  if p_outcome is null or jsonb_typeof(p_outcome)<>'object'
    or not(p_outcome ?& array['status','providerCalls'])
    or p_outcome-array['status','providerCalls','errorCode','model','requestId','inputTokens','outputTokens','durationMs']<>'{}'::jsonb
    or coalesce(p_outcome->>'status','') not in ('succeeded','dead_letter','conflict','stale','skipped','not-configured','cancelled')
    or jsonb_typeof(p_outcome->'providerCalls') is distinct from 'number'
    or p_outcome->>'providerCalls' !~ '^[0-4]$'
    or (p_outcome->>'providerCalls')::integer<>jsonb_array_length(a.calls)
    or (p_outcome->>'errorCode' is not null and p_outcome->>'errorCode' not in
      ('translation_not_configured','provider_unavailable','provider_request_failed','provider_invalid_response',
       'source_changed','write_conflict','database_read_failed','database_write_failed','unexpected','translation_operation_stopped')) then
    raise exception 'Invalid catalog finish outcome' using errcode='22023'; end if;
  fingerprint:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_outcome,p_candidate));
  if a.final_receipt is not null then
    if a.finish_fingerprint is distinct from fingerprint then raise exception 'Catalog finish intent differs' using errcode='40001'; end if;
    return premium_translation_private.catalog_operation_view(a,true);
  end if;
  if exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->'responseReceivedAt'='null'::jsonb) then
    raise exception 'Catalog provider outcome remains unknown' using errcode='40001'; end if;
  select * into j from public.translation_jobs where id=p_job_id for update;
  select * into i from public.translation_job_items where id=p_item_id for update;
  status:=p_outcome->>'status';code:=p_outcome->>'errorCode';
  if (status='succeeded') is distinct from (p_candidate is not null) then
    raise exception 'Catalog completed candidate required only for success' using errcode='22023'; end if;
  if p_candidate is not null then
    n:=jsonb_array_length(a.calls);
    if not premium_translation_private.exact_object(p_candidate,array['payload','provenance','translatorCallId','reviewerCallId'])
      or n<1 or octet_length(p_candidate::text)>1048576
      or (a.configuration->'twoPassReview'='true'::jsonb and not exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->>'pass'='review'))
      or (a.configuration->'twoPassReview'='false'::jsonb and (n>2 or exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->>'pass'='review'))) then
      raise exception 'Catalog independent review proof missing' using errcode='22023'; end if;
    first_call:=a.calls->0->'metadata';last_call:=a.calls->(jsonb_array_length(a.calls)-1)->'metadata';
    if p_candidate->>'translatorCallId' is distinct from first_call->>'callId'
      or p_candidate->>'reviewerCallId' is distinct from (case when n=1 then null else last_call->>'callId' end)
      or p_candidate->'provenance'->>'provider' is distinct from a.provider
      or p_candidate->'provenance'->>'translatorModel' is distinct from first_call->>'model'
      or p_candidate->'provenance'->>'reviewerModel' is distinct from (case when n=1 then null else last_call->>'model' end)
      or p_candidate->'provenance'->>'translatorRequestId' is distinct from coalesce(first_call->>'requestId',first_call->>'responseId')
      or p_candidate->'provenance'->>'reviewerRequestId' is distinct from (case when n=1 then null else coalesce(last_call->>'requestId',last_call->>'responseId') end) then
      raise exception 'Catalog candidate provider evidence differs' using errcode='40001'; end if;
    perform premium_translation_private.assert_shape(a.entity_type,a.source_snapshot,a.source_revision,a.target_revision,
      p_candidate->'payload',p_candidate->'provenance');
    if a.entity_type='literary_work' then
      select value into selected_source from jsonb_array_elements(a.raw_seed->'sources') where value->>'id'=a.raw_seed->>'selectedTitleSourceId';
      select coalesce(jsonb_agg(url order by position),'[]'::jsonb) into urls from (
        select url,min(position) position from (
          select value #>> '{}' url,position from jsonb_array_elements(a.raw_seed#>'{english,source_urls}') with ordinality e(value,position) where value #>> '{}' ~ '^https://'
          union all select value #>> '{}',position+jsonb_array_length(a.raw_seed#>'{english,source_urls}') from jsonb_array_elements(a.raw_seed#>'{russian,source_urls}') with ordinality r(value,position)
        ) combined group by url
      ) ordered_urls;
      if p_candidate->'payload'->'sourceUrls' is distinct from urls
        or p_candidate->'payload'->'bibliographicTitle' is distinct from jsonb_build_object('value',a.source_snapshot->'verifiedEnglishTitle',
          'provider',selected_source->'provider','sourceUrl',selected_source->'source_url','retrievedAt',selected_source->'retrieved_at') then
        raise exception 'Catalog recorded bibliography/source rights binding differs' using errcode='40001'; end if;
    end if;
    -- Promotion takes draft -> canonical row locks; use the same order.
    perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||a.entity_type||':'||a.entity_id,0));
    select * into draft from public.premium_translation_working_drafts where entity_type=a.entity_type and entity_id=a.entity_id for update;
    begin
      perform premium_translation_private.catalog_operation_assert_current(a);
    exception when serialization_failure then current_bound:=false; end;
    if not current_bound then
      status:='conflict';code:='write_conflict';
      if a.entity_type='literary_work' then
        select to_jsonb(w) into current_work from public.literary_works w where id=a.entity_id::uuid;
        select to_jsonb(r) into current_ru from public.literary_work_translations r where work_id=a.entity_id::uuid and locale='ru';
        select coalesce(jsonb_agg(to_jsonb(s) order by id),'[]'::jsonb) into current_sources from public.literary_work_sources s where work_id=a.entity_id::uuid;
        if current_work is distinct from a.raw_seed->'work' or current_ru is distinct from a.raw_seed->'russian'
          or current_sources is distinct from a.raw_seed->'sources' then status:='stale';code:='source_changed'; end if;
      end if;
    end if;
    digest:=probpera_translation_operations.retry_fingerprint(jsonb_build_object('entityType',a.entity_type,'entityId',a.entity_id,
      'targetLocale','en','sourceHash',a.source_hash,'sourceSnapshot',a.source_snapshot,'sourceRevision',a.source_revision,
      'targetRevision',a.target_revision,'payload',p_candidate->'payload','provenance',p_candidate->'provenance'));
    -- A fully validated body is retained independently of live CAS/cancel.
    -- Existing pending author/review work is never replaced.
    if draft.id is null then
      insert into public.premium_translation_working_drafts(entity_type,entity_id,source_hash,candidate_hash,source_snapshot,
        source_revision,target_revision,payload,provenance,created_by)
        values(a.entity_type,a.entity_id,a.source_hash,digest,a.source_snapshot,a.source_revision,a.target_revision,
          p_candidate->'payload',p_candidate->'provenance',a.actor_id) returning * into draft;
      persistence:='working-draft';
    elsif draft.candidate_hash=digest and draft.source_snapshot=a.source_snapshot and draft.source_revision=a.source_revision
      and draft.target_revision=a.target_revision and draft.payload=p_candidate->'payload' and draft.provenance=p_candidate->'provenance' then
      persistence:='working-draft';
    else
      persistence:='private-artifact';status:='conflict';code:='write_conflict';draft:=null;
    end if;
  end if;
  if j.cancel_requested_at is not null then status:='cancelled';code:=null; end if;
  if status in ('succeeded','skipped','cancelled') then code:=null;
  elsif code is null then code:=case status when 'stale' then 'source_changed' when 'conflict' then 'write_conflict'
    when 'not-configured' then 'translation_not_configured' else 'unexpected' end; end if;
  state:=case status when 'succeeded' then 'translated' when 'dead_letter' then 'failed' else status end;
  result:=jsonb_build_object('state',state,'errorCode',code,'persistence',persistence,
    'draftId',case when persistence='working-draft' then draft.id else null end,
    'draftVersion',case when persistence='working-draft' then draft.version else null end,
    'draftUpdatedAt',case when persistence='working-draft' then draft.created_at else null end,'candidateHash',digest,'publication','unchanged',
    'humanReview',case when p_candidate is null then 'unchanged' else 'pending' end);
  j.status:=case status when 'succeeded' then 'completed' when 'dead_letter' then 'failed' else status end;
  j.succeeded_items:=case when status='succeeded' then 1 else 0 end;j.failed_items:=case when status='dead_letter' then 1 else 0 end;
  j.version:=j.version+1;j.updated_at:=stamp;j.completed_at:=stamp;
  if not(status='skipped' and jsonb_array_length(a.calls)=0) then
    j.resume_cursor:=a.confirmed_cursor||jsonb_build_object('catalogOperation',j.resume_cursor->'catalogOperation');
  end if;
  receipt:=premium_translation_private.catalog_operation_view(a)||jsonb_build_object('phase','finished','blockReason',null,'pendingCallId',null,
    'canExecute',false,'canDispatch',false,'jobVersion',j.version::text,'resumeCursor',j.resume_cursor-'catalogOperation','result',result);
  i.status:=case status when 'succeeded' then 'succeeded' when 'cancelled' then 'cancelled' else status end;
  i.attempt_count:=1;i.staff_retry:=null;i.last_error_code:=code;i.updated_at:=stamp;
  attempt:=jsonb_populate_record(null::public.translation_job_attempts,jsonb_build_object(
    'id',nextval('public.translation_job_attempts_id_seq'),'item_id',p_item_id,'attempt_number',1,
    'outcome',case when status='cancelled' then 'skipped' else status end,'provider',a.provider,
    'model',p_outcome->'model','provider_request_id',p_outcome->'requestId','error_code',code,
    'input_tokens',p_outcome->'inputTokens','output_tokens',p_outcome->'outputTokens','duration_ms',p_outcome->'durationMs',
    'created_at',stamp,'staff_retry_operation_id',p_operation_id,'staff_retry_receipt',jsonb_build_object('version',1,
      'actorId',a.actor_id,'intentHash',a.intent_hash,'finishFingerprint',fingerprint,'receipt',receipt,
      'progress',premium_translation_private.catalog_operation_progress(a.calls))));
  if persistence='working-draft' then a.linked_draft_id:=draft.id;a.linked_draft_version:=draft.version; end if;
  a.candidate_hash:=digest;
  a.candidate:=p_candidate;a.final_receipt:=receipt;a.finish_fingerprint:=fingerprint;
  a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);a.attempt_write_proof:=to_jsonb(attempt);
  update premium_translation_private.catalog_operation_artifacts set candidate=a.candidate,final_receipt=receipt,finish_fingerprint=fingerprint,
    linked_draft_id=a.linked_draft_id,linked_draft_version=a.linked_draft_version,candidate_hash=digest,
    job_write_proof=a.job_write_proof,item_write_proof=a.item_write_proof,attempt_write_proof=a.attempt_write_proof where operation_id=p_operation_id;
  insert into public.translation_job_attempts overriding system value select attempt.*;
  update public.translation_job_items set status=i.status,attempt_count=i.attempt_count,staff_retry=null,last_error_code=code,updated_at=stamp where id=p_item_id;
  update public.translation_jobs set status=j.status,succeeded_items=j.succeeded_items,failed_items=j.failed_items,version=j.version,
    updated_at=stamp,completed_at=stamp,resume_cursor=j.resume_cursor where id=p_job_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.catalog_operation.finished','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'state',state,'persistence',persistence,'candidateHash',digest));
  return receipt;
end; $$;
