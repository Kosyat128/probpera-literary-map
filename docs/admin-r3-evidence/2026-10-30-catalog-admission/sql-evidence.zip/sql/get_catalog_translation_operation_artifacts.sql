create function public.get_catalog_translation_operation_artifacts(p_job_id uuid,p_item_id uuid,p_operation_id uuid,
  p_entity_type text,p_entity_id text,p_intent_hash text,p_source_hash text)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;
begin
  a:=premium_translation_private.catalog_operation_owned(p_job_id,p_item_id,p_operation_id);
  if a.entity_type is distinct from p_entity_type or a.entity_id is distinct from premium_translation_private.catalog_operation_identity(p_entity_type,p_entity_id)
    or a.intent_hash is distinct from p_intent_hash or a.source_hash is distinct from p_source_hash then
    raise exception 'Catalog private artifact binding differs' using errcode='40001'; end if;
  return jsonb_build_object('version',1,'receipt',premium_translation_private.catalog_operation_view(a,true),'expectedState',a.expected_state,'rawSeed',a.raw_seed,
    'sourceSnapshot',a.source_snapshot,'sourceRevision',a.source_revision,'targetRevision',a.target_revision,'configuration',a.configuration,'calls',a.calls,'candidate',a.candidate);
end; $$;
