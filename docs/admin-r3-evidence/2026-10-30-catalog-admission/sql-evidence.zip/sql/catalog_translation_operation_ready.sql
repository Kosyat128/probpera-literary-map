create function public.catalog_translation_operation_ready()
returns boolean language plpgsql stable security definer set search_path='' as $$
declare signature text; routine regprocedure;
begin
  perform premium_translation_private.assert_actor();
  foreach signature in array array[
    'public.begin_catalog_translation_operation(uuid,uuid,uuid,text,text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb)',
    'public.record_catalog_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text)',
    'public.record_catalog_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb)',
    'public.finish_catalog_translation_operation(uuid,uuid,uuid,jsonb,jsonb)',
    'public.reconcile_catalog_translation_operation(text,text,uuid)',
    'public.get_catalog_translation_operation_artifacts(uuid,uuid,uuid,text,text,text,text)'] loop
    routine:=to_regprocedure(signature);
    if routine is null or not has_function_privilege('authenticated',routine,'EXECUTE') then return false; end if;
  end loop;
  return to_regclass('premium_translation_private.catalog_operation_artifacts') is not null
    and to_regprocedure('premium_translation_private.assert_catalog_operation_promotion_current(public.premium_translation_working_drafts,text,jsonb)') is not null
    and exists(select 1 from pg_index where indexrelid=to_regclass('public.translation_catalog_active_operation_unique') and indisunique and indisvalid and indpred is not null)
    and (select count(*)=3 from pg_trigger where not tgisinternal and tgenabled='O'
      and tgfoid=to_regprocedure('premium_translation_private.catalog_operation_guard()')
      and tgname in ('translation_jobs_catalog_integrity','translation_items_catalog_integrity','translation_attempts_catalog_integrity'));
end; $$;
