create function premium_translation_private.catalog_operation_view(a premium_translation_private.catalog_operation_artifacts,
  replayed boolean default false,execute_allowed boolean default false,dispatch_allowed boolean default false)
returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare j public.translation_jobs%rowtype; pending text; reason text; phase text:='running';
begin
  select * into j from public.translation_jobs where id=a.job_id;
  select value->'metadata'->>'callId' into pending from jsonb_array_elements(a.calls) where value->'metadata'->'responseReceivedAt'='null'::jsonb limit 1;
  if a.final_receipt is not null then return a.final_receipt||jsonb_build_object('replayed',replayed,'canExecute',false,'canDispatch',false);
  elsif auth.uid() is distinct from a.actor_id then reason:='operation_owned_by_another_actor';phase:='blocked';
  elsif pending is not null and not dispatch_allowed then reason:='provider_outcome_unknown';phase:='blocked';
  elsif j.cancel_requested_at is not null then reason:='operation_stopped';phase:='blocked'; end if;
  return jsonb_build_object('version',1,'jobId',a.job_id,'itemId',a.item_id,'operationId',a.operation_id,'entityType',a.entity_type,'entityId',a.entity_id,
    'actorId',a.actor_id,'provider',a.provider,'sourceHash',a.source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,
    'configurationHash',a.configuration_hash,'configuration',a.configuration,'sourceRevision',a.source_revision,'targetRevision',a.target_revision,
    'jobVersion',j.version::text,'phase',phase,'canExecute',execute_allowed and reason is null,'canDispatch',dispatch_allowed,
    'replayed',replayed,'providerCalls',jsonb_array_length(a.calls),'pendingCallId',pending,'blockReason',reason,'resumeCursor',j.resume_cursor-'catalogOperation','result',null);
end; $$;
