create function premium_translation_private.catalog_operation_identity(k text,v text)
returns text language plpgsql immutable security invoker set search_path='' as $$
begin
  if k is null or k not in ('literary_work','country') then raise exception 'Unsupported catalog operation kind' using errcode='22023'; end if;
  perform premium_translation_private.assert_identity(k,v);
  if k='literary_work' then return v::uuid::text; end if;
  if v<>btrim(v) or v ~ '[[:cntrl:]]' then raise exception 'Invalid country identity' using errcode='22023'; end if;
  return v;
end; $$;

create function premium_translation_private.catalog_operation_cursor_valid(k text,v jsonb)
returns boolean language sql immutable security invoker set search_path='' as $$
 select coalesce(jsonb_typeof(v)='object' and v-(case k when 'literary_work' then 'libraryCursor' else 'countryCursor' end)='{}'::jsonb
   and (v='{}'::jsonb or (jsonb_typeof(v->(case k when 'literary_work' then 'libraryCursor' else 'countryCursor' end))='number'
     and v->>(case k when 'literary_work' then 'libraryCursor' else 'countryCursor' end) ~ '^[0-9]{1,9}$')),false);
$$;

-- Client projections are deliberately distinguished from full server rows.
-- Timestamp offsets are equivalent instants; every authored value is exact.
create function premium_translation_private.catalog_operation_projection(actual jsonb,expected jsonb,keys text[])
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare projection jsonb;
begin
  if not premium_translation_private.exact_object(expected,keys) then return false; end if;
  select jsonb_object_agg(key,value) into projection from jsonb_each(actual) where key=any(keys);
  return (projection-'updated_at')=(expected-'updated_at')
    and (projection->>'updated_at')::timestamptz is not distinct from (expected->>'updated_at')::timestamptz;
exception when others then return false;
end; $$;

create function premium_translation_private.catalog_operation_capture(k text,identity text,expected jsonb)
returns jsonb language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare w public.literary_works%rowtype; ru public.literary_work_translations%rowtype; en public.literary_work_translations%rowtype;
  c public.country_profile_overrides%rowtype; sources jsonb; selected uuid;
begin
  if k='literary_work' then
    select * into w from public.literary_works where id=identity::uuid for update;
    select * into ru from public.literary_work_translations where work_id=identity::uuid and locale='ru' for update;
    select * into en from public.literary_work_translations where work_id=identity::uuid and locale='en' for update;
    if w.id is null or ru.id is null or en.id is null then raise exception 'Book source disappeared' using errcode='40001'; end if;
    -- Parent FOR UPDATE also excludes new FK source inserts until transaction
    -- completion. Deterministic source locks exclude licence/update/delete races.
    perform 1 from public.literary_work_sources where work_id=w.id order by id for share;
    select coalesce(jsonb_agg(to_jsonb(s) order by s.id),'[]'::jsonb) into sources from public.literary_work_sources s where work_id=w.id;
    select id into selected from public.literary_work_sources where work_id=w.id
      and provider=expected#>>'{titleSource,provider}' and source_url=expected#>>'{titleSource,source_url}'
      and retrieved_at=(expected#>>'{titleSource,retrieved_at}')::date and 'title'=any(field_names);
    if selected is null then raise exception 'Verified bibliographic source changed' using errcode='40001'; end if;
    return jsonb_build_object('version',1,'work',to_jsonb(w),'russian',to_jsonb(ru),'english',to_jsonb(en),'sources',sources,'selectedTitleSourceId',selected);
  end if;
  select * into c from public.country_profile_overrides where country_id=identity for update;
  return jsonb_build_object('version',1,'catalogFields',expected->'catalogFields','override',case when c.id is null then 'null'::jsonb else to_jsonb(c) end);
end; $$;

create function premium_translation_private.catalog_operation_expected_valid(k text,expected jsonb,seed jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare selected jsonb;
begin
  if expected->'version' is distinct from '1'::jsonb then return false; end if;
  if k='literary_work' then
    if not premium_translation_private.exact_object(expected,array['version','work','russian','english','titleSource'])
      or not premium_translation_private.exact_object(expected->'titleSource',array['provider','source_url','retrieved_at']) then return false; end if;
    select value into selected from jsonb_array_elements(seed->'sources') where value->>'id'=seed->>'selectedTitleSourceId';
    return premium_translation_private.catalog_operation_projection(seed->'work',expected->'work',array['id','title','original_title','first_published','original_language','editorial_status','updated_at'])
      and premium_translation_private.catalog_operation_projection(seed->'russian',expected->'russian',array['id','title','description','source_language','source_urls','editorial_status','updated_at','metadata'])
      and premium_translation_private.catalog_operation_projection(seed->'english',expected->'english',array['id','title','description','source_urls','translation_method','editorial_status','updated_at','metadata'])
      and jsonb_build_object('provider',selected->'provider','source_url',selected->'source_url','retrieved_at',selected->'retrieved_at')=expected->'titleSource';
  end if;
  if not premium_translation_private.exact_object(expected,array['version','catalogFields','override'])
    or jsonb_typeof(expected->'catalogFields') is distinct from 'object' or expected->'catalogFields' is distinct from seed->'catalogFields' then return false; end if;
  if seed->'override'='null'::jsonb then return expected->'override'='null'::jsonb; end if;
  return premium_translation_private.catalog_operation_projection(seed->'override',expected->'override',array['id','fields','updated_at']);
exception when others then return false;
end; $$;
