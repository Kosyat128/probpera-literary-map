create function public.begin_catalog_translation_operation(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_entity_type text,p_entity_id text,p_provider text,p_source_hash text,
  p_source_snapshot jsonb,p_source_revision jsonb,p_target_revision jsonb,p_expected_state jsonb,p_configuration jsonb,
  p_current_cursor jsonb default '{}'::jsonb,p_resume_cursor jsonb default '{}'::jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare actor uuid:=premium_translation_private.assert_actor(); a premium_translation_private.catalog_operation_artifacts%rowtype;
  j public.translation_jobs%rowtype; i public.translation_job_items%rowtype; identity text; request_hash text; marker jsonb; view jsonb;
  stamp timestamptz:=clock_timestamp();
begin
  identity:=premium_translation_private.catalog_operation_identity(p_entity_type,p_entity_id);
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id) or p_provider is null or p_provider not in ('openai','cloudflare')
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$'
    or jsonb_typeof(p_expected_state) is distinct from 'object' or octet_length(p_expected_state::text)>4194304
    or premium_translation_private.catalog_operation_configuration_valid(p_entity_type,p_configuration,p_provider) is distinct from true
    or premium_translation_private.catalog_operation_cursor_valid(p_entity_type,p_current_cursor) is distinct from true
    or premium_translation_private.catalog_operation_cursor_valid(p_entity_type,p_resume_cursor) is distinct from true then
    raise exception 'Invalid catalog operation admission' using errcode='22023'; end if;
  request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_job_id,p_item_id,p_operation_id,actor,p_entity_type,identity,
    p_provider,p_source_hash,p_source_snapshot,p_source_revision,p_target_revision,p_expected_state,p_configuration,p_current_cursor,p_resume_cursor));
  perform pg_advisory_xact_lock(hashtextextended('catalog-operation:'||p_entity_type||':'||identity,7291));
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7292));
  select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation_id for update;
  if a.operation_id is not null then
    if a.actor_id is distinct from actor then raise exception 'Catalog operation actor differs' using errcode='42501'; end if;
    if a.begin_request_hash is distinct from request_hash then raise exception 'Catalog begin intent differs' using errcode='40001'; end if;
    return premium_translation_private.catalog_operation_view(a,true);
  end if;
  select cache.* into a from premium_translation_private.catalog_operation_artifacts cache
    join public.translation_job_items item on item.id=cache.item_id
    where cache.entity_type=p_entity_type and cache.entity_id=identity and item.staff_retry is not null for update of cache;
  if a.operation_id is not null then
    view:=premium_translation_private.catalog_operation_view(a,true);
    if a.final_receipt is not null then return view; end if;
    return view||jsonb_build_object('phase','blocked','blockReason',coalesce(view->>'blockReason','operation_in_progress'));
  end if;
  -- FINISH serializes private candidate creation on this same lock. Recheck
  -- after waiting: a completed prior admission cannot be paid for again.
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||identity,0));
  if exists(select 1 from public.translation_jobs where id=p_job_id)
    or exists(select 1 from public.translation_job_items where id=p_item_id)
    or exists(select 1 from public.premium_translation_working_drafts where entity_type=p_entity_type
      and (case when p_entity_type='literary_work' then lower(entity_id)=identity else entity_id=identity end)) then
    raise exception 'Catalog job identity or private candidate already exists' using errcode='40001'; end if;
  a.operation_id:=p_operation_id;a.job_id:=p_job_id;a.item_id:=p_item_id;a.actor_id:=actor;a.entity_type:=p_entity_type;a.entity_id:=identity;
  a.provider:=p_provider;a.source_hash:=p_source_hash;a.begin_request_hash:=request_hash;a.expected_state:=p_expected_state;
  a.raw_seed:=premium_translation_private.catalog_operation_capture(p_entity_type,identity,p_expected_state);
  if octet_length(a.raw_seed::text)>4194304 then raise exception 'Catalog raw source exceeds admission limit' using errcode='22023'; end if;
  if premium_translation_private.catalog_operation_expected_valid(p_entity_type,p_expected_state,a.raw_seed) is distinct from true then
    raise exception 'Catalog expected client projection changed' using errcode='40001'; end if;
  if premium_translation_private.catalog_operation_source_valid(p_entity_type,identity,p_source_snapshot,p_source_revision,p_target_revision,a.raw_seed) is distinct from true then
    raise exception 'Catalog source/target eligibility changed' using errcode='40001'; end if;
  a.raw_seed_hash:=probpera_translation_operations.retry_fingerprint(a.raw_seed);
  a.intent_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(request_hash,a.raw_seed_hash));
  a.configuration:=p_configuration;a.configuration_hash:=probpera_translation_operations.retry_fingerprint(p_configuration);
  a.source_snapshot:=p_source_snapshot;a.source_revision:=p_source_revision;a.target_revision:=p_target_revision;
  a.confirmed_cursor:=p_resume_cursor;a.calls:='[]'::jsonb;a.created_at:=stamp;
  marker:=jsonb_build_object('version',1,'protocol','catalog-translation','operationId',p_operation_id,'actorId',actor,'entityType',p_entity_type,
    'entityId',identity,'sourceHash',p_source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,
    'configurationHash',a.configuration_hash,'startedAt',stamp,'attemptNumber',1,'progress',jsonb_build_object('version',1,'updatedAt',stamp,'calls','[]'::jsonb));
  j:=jsonb_populate_record(null::public.translation_jobs,jsonb_build_object('id',p_job_id,'kind',p_entity_type,'source_locale','ru','target_locale','en',
    'provider',p_provider,'status','reviewing','total_items',1,'succeeded_items',0,'failed_items',0,'requested_by',actor,'started_at',stamp,'version',1,
    'created_at',stamp,'updated_at',stamp,'resume_cursor',p_current_cursor||jsonb_build_object('catalogOperation',
      jsonb_build_object('version',1,'entityType',p_entity_type,'operationId',p_operation_id,'actorId',actor,'intentHash',a.intent_hash))));
  i:=jsonb_populate_record(null::public.translation_job_items,jsonb_build_object('id',p_item_id,'job_id',p_job_id,'position',0,'entity_type',p_entity_type,
    'entity_id',identity,'source_hash',p_source_hash,'status','reviewing','attempt_count',0,'max_attempts',3,'next_attempt_at',stamp,'created_at',stamp,'updated_at',stamp,'staff_retry',marker));
  a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);
  insert into premium_translation_private.catalog_operation_artifacts select a.*;
  insert into public.translation_jobs select j.*;
  insert into public.translation_job_items select i.*;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata) values(actor,'translation.catalog_operation.admitted','translation_job',p_job_id::text,
    jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'entityType',p_entity_type,'entityId',identity,'sourceHash',p_source_hash,'rawSeedHash',a.raw_seed_hash));
  return premium_translation_private.catalog_operation_view(a,false,true);
end; $$;
