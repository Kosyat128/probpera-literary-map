create function public.record_catalog_translation_operation_response(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_metadata jsonb,p_response_artifact jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; i public.translation_job_items%rowtype;
  call jsonb; position integer; progress jsonb; stamp timestamptz:=clock_timestamp();
begin
  a:=premium_translation_private.catalog_operation_owned(p_job_id,p_item_id,p_operation_id);
  if not premium_translation_private.exact_object(p_metadata,array['callId','provider','model','pass','httpStatus','requestId','responseId','inputTokens','outputTokens'])
    or not premium_translation_private.exact_object(p_response_artifact,array['version','body'])
    or p_response_artifact->'version' is distinct from '1'::jsonb or octet_length(p_response_artifact::text)>1048576 then
    raise exception 'Invalid catalog response artifact' using errcode='22023'; end if;
  select value,(n-1)::integer into call,position from jsonb_array_elements(a.calls) with ordinality x(value,n)
    where value->'metadata'->>'callId'=p_metadata->>'callId';
  if position is null then raise exception 'Catalog response dispatch not found' using errcode='40001'; end if;
  if call->'metadata'->>'provider' is distinct from p_metadata->>'provider'
    or call->'metadata'->>'model' is distinct from p_metadata->>'model' or call->'metadata'->>'pass' is distinct from p_metadata->>'pass' then
    raise exception 'Catalog response identity differs' using errcode='40001'; end if;
  if call->'metadata'->'responseReceivedAt'<>'null'::jsonb then
    if (call->'metadata')-array['dispatchRecordedAt','responseReceivedAt'] is distinct from p_metadata
      or call->'responseArtifact' is distinct from p_response_artifact then raise exception 'Catalog response evidence differs' using errcode='40001'; end if;
    return premium_translation_private.catalog_operation_view(a,true);
  end if;
  if a.final_receipt is not null then raise exception 'Catalog operation already finished' using errcode='40001'; end if;
  call:=call||jsonb_build_object('metadata',p_metadata||jsonb_build_object('dispatchRecordedAt',call->'metadata'->'dispatchRecordedAt','responseReceivedAt',stamp),
    'responseArtifact',p_response_artifact);
  a.calls:=jsonb_set(a.calls,array[position::text],call);
  if octet_length(a.calls::text)>4194304 then raise exception 'Catalog aggregate response artifact limit exceeded' using errcode='22023'; end if;
  progress:=premium_translation_private.catalog_operation_progress(a.calls);
  if not probpera_translation_operations.retry_journal_valid(progress,a.provider) then
    raise exception 'Catalog response metadata differs' using errcode='22023'; end if;
  select * into i from public.translation_job_items where id=p_item_id for update;
  i.staff_retry:=i.staff_retry||jsonb_build_object('progress',progress);i.updated_at:=stamp;a.item_write_proof:=to_jsonb(i);
  update premium_translation_private.catalog_operation_artifacts set calls=a.calls,item_write_proof=a.item_write_proof where operation_id=p_operation_id;
  update public.translation_job_items set staff_retry=i.staff_retry,updated_at=i.updated_at where id=p_item_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.catalog_operation.response_received','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'callId',p_metadata->'callId','responseHash',probpera_translation_operations.retry_fingerprint(p_response_artifact)));
  return premium_translation_private.catalog_operation_view(a);
end; $$;