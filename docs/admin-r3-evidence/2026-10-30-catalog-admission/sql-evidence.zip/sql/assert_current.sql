create function premium_translation_private.catalog_operation_assert_current(a premium_translation_private.catalog_operation_artifacts)
returns void language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare current_seed jsonb;
begin
  current_seed:=premium_translation_private.catalog_operation_capture(a.entity_type,a.entity_id,a.expected_state);
  if current_seed is distinct from a.raw_seed then raise exception 'Catalog full source/target seed changed' using errcode='40001'; end if;
  if premium_translation_private.catalog_operation_source_valid(a.entity_type,a.entity_id,a.source_snapshot,a.source_revision,a.target_revision,current_seed) is distinct from true then
    raise exception 'Catalog source eligibility or English ownership changed' using errcode='40001'; end if;
end; $$;
