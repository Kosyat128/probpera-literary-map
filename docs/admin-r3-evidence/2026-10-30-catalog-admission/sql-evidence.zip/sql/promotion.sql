create function premium_translation_private.assert_catalog_operation_promotion_current(
  d public.premium_translation_working_drafts,catalog_hash text,catalog_fields jsonb)
returns void language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;
begin
  -- Link by the actual draft UUID first. Altering its hash/version/body cannot
  -- downgrade a newly bound candidate into an unbound legacy candidate.
  -- Plain read avoids cache -> draft / draft -> cache lock inversion at FINISH.
  select * into a from premium_translation_private.catalog_operation_artifacts where linked_draft_id=d.id;
  if a.operation_id is null then return; end if;
  if a.final_receipt is null or a.entity_type is distinct from d.entity_type or a.entity_id is distinct from d.entity_id
    or a.linked_draft_version is distinct from d.version or a.candidate_hash is distinct from d.candidate_hash
    or a.source_hash is distinct from d.source_hash or a.source_snapshot is distinct from d.source_snapshot
    or a.source_revision is distinct from d.source_revision or a.target_revision is distinct from d.target_revision
    or a.candidate->'payload' is distinct from d.payload or a.candidate->'provenance' is distinct from d.provenance then
    raise exception 'Catalog linked candidate binding changed' using errcode='40001'; end if;
  if d.entity_type='country' and (catalog_fields is distinct from a.raw_seed->'catalogFields'
    or catalog_hash is distinct from a.source_revision->>'catalogSourceHash') then
    raise exception 'Catalog country source changed' using errcode='40001'; end if;
  perform premium_translation_private.catalog_operation_assert_current(a);
end; $$;
