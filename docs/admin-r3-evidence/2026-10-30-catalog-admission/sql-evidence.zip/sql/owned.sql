create function premium_translation_private.catalog_operation_owned(p_job uuid,p_item uuid,p_operation uuid)
returns premium_translation_private.catalog_operation_artifacts language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;
begin
  perform premium_translation_private.assert_actor();
  select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation for update;
  if a.operation_id is null then raise exception 'Catalog operation not found' using errcode='P0002'; end if;
  if a.actor_id is distinct from auth.uid() then raise exception 'Catalog operation actor differs' using errcode='42501'; end if;
  if a.job_id is distinct from p_job or a.item_id is distinct from p_item or a.entity_type not in ('literary_work','country') then
    raise exception 'Catalog operation identity differs' using errcode='40001'; end if;
  return a;
end; $$;
