create function premium_translation_private.catalog_operation_configuration_valid(k text,v jsonb,p text)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare key text;
begin
  if not premium_translation_private.exact_object(v,array['version','provider','model','reviewerModel','promptFingerprint',
    'translatorReasoningEffort','translatorReasoningMode','reviewerReasoningEffort','reviewerReasoningMode','schemaName','maxOutputTokens','twoPassReview'])
    or v->'version' is distinct from '1'::jsonb or v->>'provider' is distinct from p
    or v->>'schemaName' is distinct from (case k when 'literary_work' then 'probpera_literary_work_translation' else 'probpera_country_profile_translation' end)
    or v->'maxOutputTokens' is distinct from to_jsonb(case k when 'literary_work' then 4000 else 12000 end)
    or jsonb_typeof(v->'twoPassReview') is distinct from 'boolean'
    or jsonb_typeof(v->'promptFingerprint') is distinct from 'string' or v->>'promptFingerprint' !~ '^[a-f0-9]{64}$' or octet_length(v::text)>4096 then return false; end if;
  foreach key in array array['model','reviewerModel'] loop
    if jsonb_typeof(v->key) is distinct from 'string' or char_length(v->>key) not between 1 and 200 or v->>key ~ '[[:cntrl:]]' then return false; end if;
  end loop;
  foreach key in array array['translatorReasoningEffort','reviewerReasoningEffort'] loop
    if jsonb_typeof(v->key) is distinct from 'string' or v->>key not in ('none','low','medium','high','xhigh','max') then return false; end if;
  end loop;
  foreach key in array array['translatorReasoningMode','reviewerReasoningMode'] loop
    if jsonb_typeof(v->key) is distinct from 'string' or v->>key not in ('standard','pro') then return false; end if;
  end loop;
  return true;
end; $$;
