create function premium_translation_private.catalog_operation_source_valid(k text,identity text,s jsonb,r jsonb,t jsonb,seed jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare w jsonb:=seed->'work'; ru jsonb:=seed->'russian'; en jsonb:=seed->'english'; selected jsonb;
  effective jsonb; translations jsonb; catalog_translations jsonb; protected jsonb; current_source jsonb;
begin
  if not premium_translation_private.valid_revision(t) or octet_length(s::text)>4194304 then return false; end if;
  if k='literary_work' then
    if not premium_translation_private.exact_object(r,array['workId','workUpdatedAt','russianId','russianUpdatedAt'])
      or not premium_translation_private.exact_object(s,array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls'])
      or r->>'workId' is distinct from identity or (w->>'id')::uuid is distinct from identity::uuid
      or (r->>'russianId')::uuid is distinct from (ru->>'id')::uuid or (t->>'id')::uuid is distinct from (en->>'id')::uuid
      or (r->>'workUpdatedAt')::timestamptz is distinct from (w->>'updated_at')::timestamptz
      or (r->>'russianUpdatedAt')::timestamptz is distinct from (ru->>'updated_at')::timestamptz
      or (t->>'updatedAt')::timestamptz is distinct from (en->>'updated_at')::timestamptz
      or w->>'editorial_status' not in ('reviewed','verified') or ru->>'editorial_status' not in ('reviewed','verified')
      or jsonb_array_length(ru->'source_urls')=0 or en->>'translation_method' is distinct from 'machine-translation' then return false; end if;
    select value into selected from jsonb_array_elements(seed->'sources') where value->>'id'=seed->>'selectedTitleSourceId';
    current_source:=jsonb_build_object('russianTitle',ru->'title','verifiedEnglishTitle',premium_translation_private.trim_text(en->>'title'),
      'verifiedEnglishTitleSourceUrl',selected->'source_url','description',ru->'description','originalTitle',coalesce(w->>'original_title',''),
      'firstPublished',w->'first_published','originalLanguage',coalesce(w->>'original_language',''),'sourceLanguage',ru->'source_language','sourceUrls',ru->'source_urls');
    return current_source=s and char_length(s->>'verifiedEnglishTitle')>0
      and not exists(select 1 from unnest(string_to_array(s->>'verifiedEnglishTitle',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311 or ascii(glyph) between 11744 and 11775
          or ascii(glyph) between 42560 and 42655 or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      and en#>>'{metadata,premiumTranslation,bibliographicTitle,value}'=s->>'verifiedEnglishTitle'
      and en#>>'{metadata,premiumTranslation,bibliographicTitle,sourceUrl}'=s->>'verifiedEnglishTitleSourceUrl'
      and en->'source_urls' ? (s->>'verifiedEnglishTitleSourceUrl') and selected->'field_names' ? 'title';
  end if;
  if not premium_translation_private.exact_object(r,array['overrideId','overrideUpdatedAt','catalogSourceHash'])
    or coalesce(r->>'catalogSourceHash','') !~ '^[a-f0-9]{64}$'
    or jsonb_build_object('id',r->'overrideId','updatedAt',r->'overrideUpdatedAt') is distinct from t
    or not premium_translation_private.valid_country_fields(s,false) or coalesce(s->>'name','')=''
    or (coalesce(s->>'description','')='' and coalesce(s->>'history','')='' and coalesce(s->>'historicalNote','')='') then return false; end if;
  if seed->'override'='null'::jsonb then
    if t->>'id' is not null then return false; end if;
  elsif (seed#>>'{override,id}')::uuid is distinct from (t->>'id')::uuid
    or (seed#>>'{override,updated_at}')::timestamptz is distinct from (t->>'updatedAt')::timestamptz then return false; end if;
  if (seed->'catalogFields' ? 'translations' and jsonb_typeof(seed#>'{catalogFields,translations}') is distinct from 'object')
    or (seed#>'{override,fields}' ? 'translations' and jsonb_typeof(seed#>'{override,fields,translations}') is distinct from 'object') then return false; end if;
  effective:=seed->'catalogFields'||coalesce(nullif(seed#>'{override,fields}','null'::jsonb),'{}'::jsonb);
  translations:=coalesce(effective->'translations','{}'::jsonb);catalog_translations:=coalesce(seed#>'{catalogFields,translations}','{}'::jsonb);
  protected:=case when translations ? 'en' then translations->'en' when catalog_translations ? 'en' then catalog_translations->'en' else null end;
  return protected is null or (protected->>'locale'='en' and protected->>'method'='machine-translation');
exception when others then return false;
end; $$;
