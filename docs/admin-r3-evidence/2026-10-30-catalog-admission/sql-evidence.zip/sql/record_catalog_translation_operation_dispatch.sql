create function public.record_catalog_translation_operation_dispatch(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_call_id uuid,p_provider text,p_model text,p_pass text,p_request_hash text
)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; j public.translation_jobs%rowtype;
  i public.translation_job_items%rowtype; call jsonb; metadata jsonb; progress jsonb; stamp timestamptz:=clock_timestamp();
begin
  a:=premium_translation_private.catalog_operation_owned(p_job_id,p_item_id,p_operation_id);
  if not probpera_translation_operations.retry_uuid(p_call_id) or p_provider is distinct from a.provider
    or p_model is null or p_pass is null or p_pass not in ('translation','repair','review')
    or p_request_hash is null or p_request_hash !~ '^[a-f0-9]{64}$'
    or p_model is distinct from a.configuration->>(case when p_pass='translation' then 'model' else 'reviewerModel' end) then
    raise exception 'Invalid catalog dispatch binding' using errcode='22023'; end if;
  for call in select value from jsonb_array_elements(a.calls) loop
    if call->'metadata'->>'callId'=p_call_id::text then
      if call->>'requestHash' is distinct from p_request_hash or call->'metadata'->>'pass' is distinct from p_pass
        or call->'metadata'->>'model' is distinct from p_model then raise exception 'Catalog dispatch intent differs' using errcode='40001'; end if;
      return premium_translation_private.catalog_operation_view(a,true);
    end if;
  end loop;
  select * into j from public.translation_jobs where id=p_job_id for update;
  if a.final_receipt is not null or j.cancel_requested_at is not null or j.status<>'reviewing'
    or jsonb_array_length(a.calls)>=4 or exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->'responseReceivedAt'='null'::jsonb) then
    raise exception 'Catalog dispatch is blocked or outcome unknown' using errcode='40001'; end if;
  if a.configuration->'twoPassReview'='false'::jsonb and (p_pass='review' or jsonb_array_length(a.calls)>=2) then
    raise exception 'Unconfigured catalog review pass' using errcode='22023'; end if;
  perform premium_translation_private.catalog_operation_assert_current(a);
  metadata:=jsonb_build_object('callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,
    'dispatchRecordedAt',stamp,'responseReceivedAt',null,'httpStatus',null,'requestId',null,'responseId',null,'inputTokens',null,'outputTokens',null);
  a.calls:=a.calls||jsonb_build_array(jsonb_build_object('requestHash',p_request_hash,'metadata',metadata,'responseArtifact',null));
  progress:=premium_translation_private.catalog_operation_progress(a.calls);
  if not probpera_translation_operations.retry_journal_valid(progress,a.provider) then
    raise exception 'Catalog dispatch sequence differs' using errcode='40001'; end if;
  select * into i from public.translation_job_items where id=p_item_id for update;
  i.staff_retry:=i.staff_retry||jsonb_build_object('progress',progress);i.updated_at:=stamp;
  a.item_write_proof:=to_jsonb(i);
  update premium_translation_private.catalog_operation_artifacts set calls=a.calls,item_write_proof=a.item_write_proof where operation_id=p_operation_id;
  update public.translation_job_items set staff_retry=i.staff_retry,updated_at=i.updated_at where id=p_item_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.catalog_operation.dispatch_recorded','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,'requestHash',p_request_hash));
  return premium_translation_private.catalog_operation_view(a,false,false,true);
end; $$;