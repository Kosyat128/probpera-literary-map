const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),out=path.resolve(__dirname,'../catalog-operation-sql-evidence-20261030-sol');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const read=name=>JSON.parse(fs.readFileSync(path.join(__dirname,name),'utf8').replace(/^\uFEFF/,''));
const manifest=read('source-manifest.json'),migration=fs.readFileSync(path.join(repo,'supabase/migrations/20261029220832_catalog_translation_operation_admission.sql'),'utf8');
const functions=read('native-functions.json');
const nativeBinding=functions.map(fn=>{
 const short=fn.name.slice(0,fn.name.indexOf('(')),name=short.includes('.')?short:'public.'+short;
 let start=migration.indexOf('create function '+name+'(');if(start<0)start=migration.indexOf('create or replace function '+name+'(');
 const bodyStart=migration.indexOf('as $$',start)+5,bodyEnd=migration.indexOf('$$;',bodyStart);
 if(start<0||bodyStart<5||bodyEnd<0)throw Error('Missing native function '+name);
 const body=migration.slice(bodyStart,bodyEnd),normalized=body.replace(/\r\n?/g,'\n');
 if(normalized!==fn.source.replace(/\r\n?/g,'\n'))throw Error('Native function does not bind current source '+name);
 return{name:fn.name,bodySha256:hash(body),nativeBodySha256:hash(fn.source),normalization:'CRLF/LF only',pinnedSearchPath:fn.config?.includes('search_path=""')};
});
const old=fs.readFileSync(path.join(repo,'supabase/migrations/20261029181630_site_copy_private_translation_review.sql'),'utf8');
const start=old.indexOf('create or replace function public.promote_premium_translation_working_draft('),end=old.indexOf('$$;',old.indexOf('as $$',start))+3;
const oldPromote=old.slice(start,end),insertion="  if p_entity_type in ('literary_work','country') then\n    perform premium_translation_private.assert_catalog_operation_promotion_current(candidate,p_catalog_source_hash,p_catalog_source_fields);\n  end if;\n";
const a=migration.indexOf('create or replace function public.promote_premium_translation_working_draft('),b=migration.indexOf('$$;',migration.indexOf('as $$',a))+3;
if(migration.slice(a,b).replace(insertion,'')!==oldPromote)throw Error('Unrelated promotion branch bytes changed');
const advisorText=fs.readFileSync(path.join(__dirname,'security-advisors.log'),'utf8').replace(/^\uFEFF/,'');
const advisor=JSON.parse(advisorText.split(/\r?\n/).find(line=>line.startsWith('{')));
const ownNames=new Set(functions.map(fn=>fn.name.slice(0,fn.name.indexOf('(')).split('.').at(-1)));
const ownFindings=advisor.results.filter(x=>ownNames.has(x.metadata?.name)||x.metadata?.name==='catalog_operation_artifacts');
if(ownFindings.length)throw Error('New production advisor finding '+JSON.stringify(ownFindings));
const cases=read('native-case-results.json'),concurrency=read('concurrent-receipts.json');
const beforeZip=path.join(repo,'docs/admin-r3-evidence/2026-10-30-writer-admission/next-library-country-admission-before.zip');
if(hash(fs.readFileSync(beforeZip))!=='652bbe1367df8b92f267a418600d55ce76feb9fa1f9a69b969722a02c8f27cef')throw Error('Frozen BEFORE changed');
const sourceMap=new Map([...manifest.foundation.foundation.sources,...manifest.foundation.sources,...manifest.sources].map(s=>[s.file,s]));
const summary={atUtc:new Date().toISOString(),mode:'Current isolated native SQL proof; no managed/provider/production run',
 migrationSha256:hash(migration),fixtureSha256:hash(fs.readFileSync(path.join(repo,'scripts/database/fixtures/catalog-translation-operation-admission.sql'))),
 maintainedFixtureExit:0,resultGroups:Object.keys(cases),resultGroupCount:Object.keys(cases).length,nativeFunctionBinding:nativeBinding,
 promoteCompatibility:{oldFunctionBytes:Buffer.byteLength(oldPromote),allOldBytesPreservedAfterRemovingOneConditionalHook:true,oldFunctionSha256:hash(oldPromote)},
 concurrent:concurrency,advisors:{...read('advisors-lint-receipt.json'),findingCount:advisor.results.length,newProductionFindings:ownFindings,findings:advisor.results.map(x=>({name:x.name,level:x.level,object:x.metadata?.schema+'.'+x.metadata?.name}))},
 cleanup:[read('new-cleanup.json'),read('export-cleanup.json')],frozenBeforeZipSha256:'652bbe1367df8b92f267a418600d55ce76feb9fa1f9a69b969722a02c8f27cef',
 boundaries:['All Auth/catalog/provider values are synthetic. Native SQL uses real unchanged canonical/operations/private/writer migrations, no real provider or paid request.',
 'Existing writer API/cache/migration unchanged; the old promotion function has one two-kind conditional hook, with every other original byte preserved.',
 'Licence/metadata changes with exact unchanged book/RU/EN rows and timestamps deny linked approval. Unlinked legacy drafts retain old guards; the hook is not retroactive.',
 'Current UI preflight can still offer approval after raw licence/rights drift; the atomic SQL guard refuses it. Metadata-only UI freshness is the separately frozen next defect, not implemented here.',
 'Partial-pass paid replay, stable scans and T13 operator recovery remain pending. Unknown dispatch does not expire into another request; stored raw body is not a valid complete candidate.',
 'Advisors exit1 inherited synthetic fixture findings is retained, not PASS; lint NOT RUN because plpgsql_check is absent and no extension was installed.',
 'The initial runner overwrote earlier full iteration logs. iteration-observations.json contains honest observed excerpts; exact v7 full raw history and final v8 raw log are separately retained.',
 'Native positive approvals intentionally mutate only synthetic canonical rows to prove the explicit approval path. Provider FINISH and all refusal controls preserve canonical rows/outbox.',
 'No binaries, node_modules, credentials, DB data or services are bundled. Replay requires existing documented local runtimes and an owned disposable PG cluster.']};
fs.writeFileSync(path.join(__dirname,'native-summary.json'),JSON.stringify(summary,null,2));
fs.mkdirSync(out,{recursive:true});
const copy=(source,target)=>{fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(source,target);};
for(const file of ['build-migration.cjs','build-probe.cjs','make-export.cjs','export-body.ps1','concurrent-and-export.ps1','run-probe.ps1','fixture.sql','source-manifest.json','native-summary.json',
 'native-artifacts.json','native-receipts.json','native-functions.json','native-case-results.json','concurrent-receipts.json','security-advisors.log','advisors-lint-receipt.json',
 'new-run.log','new-cleanup.json','new-cleanup.log','export-cleanup.json','export-cleanup.log','iteration-observations.json','pack-evidence.cjs'])copy(path.join(__dirname,file),path.join(out,file));
for(const entry of fs.readdirSync(__dirname))if(/^(?:fresh|finish|queued)-/.test(entry))copy(path.join(__dirname,entry),path.join(out,entry));
function tree(source,target){for(const entry of fs.readdirSync(source,{withFileTypes:true})){const from=path.join(source,entry.name),to=path.join(target,entry.name);if(entry.isDirectory())tree(from,to);else copy(from,to);}}
tree(path.join(__dirname,'sql'),path.join(out,'sql'));tree(path.join(__dirname,'history'),path.join(out,'history'));
for(const source of sourceMap.values()){
 const bytes=fs.readFileSync(path.join(repo,source.file));if(hash(bytes)!==source.sha256)throw Error('Source drift '+source.file);
 const target=path.join(out,'sources',source.file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes);
}
const prior=path.resolve(__dirname,'../writer-operation-sql-native');for(const file of ['fixture.sql','source-manifest.json','run-probe.ps1'])copy(path.join(prior,file),path.join(out,'foundation',file));
const conformance=path.resolve(__dirname,'../catalog-admission-v1/native-dto-2026-10-29T22-34-27-210Z/report.json');
if(fs.existsSync(conformance)){const bytes=fs.readFileSync(conformance);if(hash(bytes)!=='4dd5ba931cbf52df52bb7a58d11f30f8a4c0f34088e72da956ac64560cac0af9')throw Error('Native TS conformance changed');copy(conformance,path.join(out,'actual-ts-native-conformance-report.json'));}
fs.writeFileSync(path.join(out,'README.txt'),`Catalog admission native evidence, GPT-6.1 Sol Ultra, 2026-10-30\n\nFinal v8 maintained fixture exit0; ${summary.resultGroupCount} result groups. Actual parallel admissions and a BEGIN blocked on the prior FINISH database lock execute independently for BOTH literary_work/country. Exactly one admission is granted; the queued operation has zero new dispatch authority after a private candidate is created. Native routine source bodies match current source (line endings only); all old promotion bytes remain exact after removing the single conditional hook.\n\nRead native-summary.json and iteration-observations.json for limits and honest iteration history. The schema compiles against real original SQL/bootstrap/private/writer fixtures; no managed E2E/provider/invoice/production claim. Current UI freshness is a separate next defect; atomic approval rejects the raw-source drift.\n\nReplay entry points: build-migration.cjs (uses sql/ templates and original source), build-probe.cjs (appends new migration/fixture to verified frozen foundation), run-probe.ps1 (owned loopback PID/data-directory guard; refuses an existing DB; finally stops same PID), concurrent-and-export.ps1 (two sessions/queued FINISH/raw DTO/advisors, same owned cluster guard). Rebase documented repo/parentwork/runtime paths to extracted sources/foundation and an owned disposable PG17 cluster with synthetic anon/authenticated/service_role fixture roles. No DB data/binaries/dependencies/CLI home are included. fixture.sql is the exact final joined replay SQL, ON_ERROR_STOP enforced.\n\nactual-ts-native-conformance-report.json is a copied independent 41/41 real TypeScript+installed SDK conformance report; its full runner is retained by the root acceptance artifact, not reimplemented here. All input native JSON and exact production SQL sources are included. Frozen unresolved BEFORE ZIP652bbe... remains byte-unchanged.\n`);
const files=[];function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,e.name);if(e.isDirectory())walk(f);else{const b=fs.readFileSync(f);files.push({file:path.relative(out,f).replaceAll('\\','/'),bytes:b.length,sha256:hash(b)});}}}walk(out);files.sort((a,b)=>a.file.localeCompare(b.file));
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),sourceCount:sourceMap.size,files},null,2));
console.log(JSON.stringify({out,files:files.length,sourceCount:sourceMap.size,nativeFunctions:nativeBinding.length,resultGroups:summary.resultGroupCount,advisorFindings:advisor.results.length,newProductionFindings:ownFindings.length}));
