$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\catalog-operation-sql-native'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-export.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8'
 $psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not the owned isolated cluster'}
 $database='catalog_operations_v8_20261030'
 function Invoke-CatalogQuery([string]$query){
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc $query
  if($LASTEXITCODE -ne 0){throw 'Owned SQL query failed'}
  return ,@($raw|Where-Object{ $_.StartsWith('{') -or $_.StartsWith('[')})
 }
 function Start-CatalogSession([string]$file,[string]$application){
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$psql;$info.UseShellExecute=$false;$info.CreateNoWindow=$true
  $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true;$info.Environment['PGAPPNAME']=$application
  foreach($argument in @('-h','127.0.0.1','-p','55438','-U','postgres','-d',$database,'--no-psqlrc','--set=ON_ERROR_STOP=1','-qAt','-f',$file)){$info.ArgumentList.Add($argument)}
  $process=[Diagnostics.Process]::new();$process.StartInfo=$info;$clock=[Diagnostics.Stopwatch]::StartNew()
  if(-not $process.Start()){throw 'Owned concurrent session failed'}
  return @{process=$process;stdout=$process.StandardOutput.ReadToEndAsync();stderr=$process.StandardError.ReadToEndAsync();clock=$clock;application=$application}
 }
 function Finish-CatalogSession($entry,[string]$label){
  if(-not $entry.process.WaitForExit(15000)){$entry.process.Kill();throw 'Owned session timeout'}
  $entry.clock.Stop();$stdout=$entry.stdout.GetAwaiter().GetResult();$stderr=$entry.stderr.GetAwaiter().GetResult()
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($label+'.stdout.log')),$stdout)
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($label+'.stderr.log')),$stderr)
  if($entry.process.ExitCode -ne 0){throw ($label+' SQL failed '+$stderr)}
  $json=@($stdout -split "`n"|Where-Object{$_.TrimStart().StartsWith('{')})
  if($json.Count -ne 1){throw ('Unexpected receipt '+$label)}
  return @{pid=$entry.process.Id;application=$entry.application;elapsedMs=$entry.clock.ElapsedMilliseconds;exitCode=$entry.process.ExitCode;receipt=($json[0]|ConvertFrom-Json)}
 }
 $concurrent=@()
 foreach($kind in @('literary_work','country')){
  $seedRaw=Invoke-CatalogQuery ("select public.catalog_fixture_seed('"+$kind+"','native-concurrent',true)")
  if($seedRaw.Count -ne 1){throw 'Expected seed'}
  $seedLiteral=$seedRaw[0].Replace("'","''")
  $sessionSql="begin;set local role authenticated;select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);select public.catalog_fixture_begin('"+$seedLiteral+"'::jsonb);select pg_sleep(0.75);commit;"
  $file=Join-Path $nativeRoot ('fresh-'+$kind+'.sql');[IO.File]::WriteAllText($file,$sessionSql)
  $one=Start-CatalogSession $file ('catalog-fresh1-'+$kind);$two=Start-CatalogSession $file ('catalog-fresh2-'+$kind)
  $a=Finish-CatalogSession $one ('fresh-'+$kind+'-1');$b=Finish-CatalogSession $two ('fresh-'+$kind+'-2')
  if(@(@($a,$b)|Where-Object{$_.receipt.canExecute}).Count -ne 1 -or $a.receipt.operationId -ne $b.receipt.operationId){throw 'Concurrent catalog admission not exclusive'}
  $receipt=($a.receipt|ConvertTo-Json -Depth 30 -Compress).Replace("'","''")
  $payload=((($seedRaw[0]|ConvertFrom-Json).payload)|ConvertTo-Json -Depth 30 -Compress).Replace("'","''")
  $paidRaw=Invoke-CatalogQuery ("select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);select public.catalog_fixture_pass(public.catalog_fixture_pass('"+$receipt+"'::jsonb,'translation','"+$payload+"'::jsonb),'review','"+$payload+"'::jsonb)")
  $paid=($paidRaw[0]|ConvertFrom-Json);$paidLiteral=$paidRaw[0].Replace("'","''")
  $finishSql="begin;select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);select operation_id from premium_translation_private.catalog_operation_artifacts where operation_id='"+$paid.operationId+"' for update;select pg_sleep(0.9);set local role authenticated;select public.catalog_fixture_finish('"+$paidLiteral+"'::jsonb,'"+$payload+"'::jsonb);commit;"
  $queueSql="begin;set local role authenticated;select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);create temp table race_result(v jsonb);do `$race`$ begin insert into race_result select public.catalog_fixture_begin('"+$seedLiteral+"'::jsonb);exception when serialization_failure then insert into race_result values(jsonb_build_object('refused',sqlstate,'canExecute',false));end;`$race`$;select v from race_result;commit;"
  $finishFile=Join-Path $nativeRoot ('finish-'+$kind+'.sql');$queueFile=Join-Path $nativeRoot ('queued-'+$kind+'.sql')
  [IO.File]::WriteAllText($finishFile,$finishSql);[IO.File]::WriteAllText($queueFile,$queueSql)
  $finisher=Start-CatalogSession $finishFile ('catalog-finisher-'+$kind)
  [Threading.Thread]::Sleep(150)
  $queued=Start-CatalogSession $queueFile ('catalog-queued-'+$kind)
  [Threading.Thread]::Sleep(150)
  $wait=Invoke-CatalogQuery ("select jsonb_build_object('blocked',exists(select 1 from pg_stat_activity where application_name='catalog-queued-"+$kind+"' and cardinality(pg_blocking_pids(pid))>0))")
  $waitProof=$wait[0]|ConvertFrom-Json
  $finish=Finish-CatalogSession $finisher ('finish-'+$kind);$waiting=Finish-CatalogSession $queued ('queued-'+$kind)
  if(-not $waitProof.blocked -or $waiting.receipt.canExecute){throw 'Queued admission did not prove zero new dispatch authority'}
  $count=Invoke-CatalogQuery ("select jsonb_build_object('cacheRows',count(*),'linkedCandidates',count(*) filter(where linked_draft_id is not null)) from premium_translation_private.catalog_operation_artifacts where operation_id='"+$paid.operationId+"'")
  $concurrent+=@{entityType=$kind;freshSessions=@($a,$b);finishSession=$finish;queuedSession=$waiting;actualBlockedOnDatabaseLock=$waitProof.blocked;countProof=($count[0]|ConvertFrom-Json);providerCalls=0}
 }
 $concurrent|ConvertTo-Json -Depth 35|Set-Content -LiteralPath (Join-Path $nativeRoot 'concurrent-receipts.json') -Encoding utf8
 $queries=@{
  'native-case-results.json'='select jsonb_object_agg(label,value) from public.catalog_operation_fixture_results';
  'native-receipts.json'="select jsonb_object_agg(label,case when value ? 'receipt' then value->'receipt' else value end) from public.catalog_operation_fixture_results where value ? 'receipt' or value ? 'jobId'";
  'native-artifacts.json'="select jsonb_object_agg(label,value->'artifact') from public.catalog_operation_fixture_results where value ? 'artifact'";
  'native-functions.json'="select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'securityDefiner',p.prosecdef,'config',p.proconfig,'source',p.prosrc) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where (n.nspname='public' and (p.proname like '%catalog_translation_operation%' or p.proname='promote_premium_translation_working_draft')) or (n.nspname='premium_translation_private' and (p.proname like 'catalog_operation_%' or p.proname='assert_catalog_operation_promotion_current'))";
 }
 foreach($filename in $queries.Keys){
  $raw=Invoke-CatalogQuery ("select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);"+$queries[$filename])
  if($raw.Count -ne 1){throw ('Unexpected export '+$filename)}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $filename),$raw[0],[Text.UTF8Encoding]::new($false))
 }
 $available=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc -Atc "select count(*) from pg_available_extensions where name='plpgsql_check'"
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1'
 $env:SUPABASE_HOME='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\catalog-operation-sql-native\cli-home'
 $cli='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\portable-db-tools\supabase-2.120.0\supabase.exe'
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$database+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors.log')
 $advisorExit=$LASTEXITCODE
 [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');target=('owned loopback '+$database);advisorsExitCode=$advisorExit;lintStatus='NOT_RUN_PLPGSQL_CHECK_UNAVAILABLE_NO_INSTALL';plpgsqlCheckAvailable=[int]$available;installedAnything=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-receipt.json') -Encoding utf8
 Write-Output 'ACTUAL_TWO_KIND_CONCURRENT_AND_QUEUED_FINISH_PASS'

}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'export-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'export-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
