const fs=require('node:fs'),path=require('node:path');
const repo=path.resolve(__dirname,'../../probpera-literary-map');
const target=path.join(repo,'supabase/migrations/20261029220832_catalog_translation_operation_admission.sql');
const writerPath=path.join(repo,'supabase/migrations/20261029202308_writer_translation_operation_admission.sql');
let sql=fs.readFileSync(writerPath,'utf8').replaceAll('writer_operation_','catalog_operation_')
 .replaceAll('writer_translation_operation','catalog_translation_operation').replaceAll('translation_writer_active','translation_catalog_active')
 .replaceAll('writer_integrity','catalog_integrity').replaceAll('writerOperation','catalogOperation').replaceAll('Writer operation','Catalog operation')
 .replaceAll('Writer provider','Catalog provider').replaceAll('Writer dispatch','Catalog dispatch').replaceAll('Writer response','Catalog response')
 .replaceAll('Writer finish','Catalog finish').replaceAll('Writer candidate','Catalog candidate').replaceAll('Writer independent','Catalog independent')
 .replaceAll("'writer-biography'","'catalog-translation'");
sql=sql.replace('  entity_id text not null,','  entity_type text not null check(entity_type in (\'literary_work\',\'country\')),\n  entity_id text not null,\n  begin_request_hash text not null,\n  raw_seed_hash text not null,\n  raw_seed jsonb not null check(jsonb_typeof(raw_seed)=\'object\' and octet_length(raw_seed::text)<=4194304),\n  linked_draft_id uuid unique,\n  linked_draft_version bigint,\n  candidate_hash text,');
sql=sql.replace(/  expected_override_fields jsonb[^\n]*\n/,'  expected_state jsonb not null check(jsonb_typeof(expected_state)=\'object\' and octet_length(expected_state::text)<=4194304),\n');
sql=sql.replace("octet_length(source_snapshot::text)<=1048576","octet_length(source_snapshot::text)<=4194304")
 .replace("octet_length(calls::text)<=1048576","octet_length(calls::text)<=4194304")
 .replace('  candidate jsonb,',"  candidate jsonb check(candidate is null or (jsonb_typeof(candidate)='object' and octet_length(candidate::text)<=1048576)),")
 .replace("where entity_type='writer' and staff_retry is not null;","where entity_type in ('literary_work','country') and staff_retry is not null;");
sql=sql.replace("new.entity_type='writer'","new.entity_type in ('literary_work','country')").replace("old.entity_type='writer'","old.entity_type in ('literary_work','country')");
function replaceFunction(name,body){const start=sql.indexOf('create function '+name+'(');if(start<0)throw Error(name);const end=sql.indexOf('$$;',sql.indexOf('as $$',start))+3;if(end<3)throw Error(name+'end');sql=sql.slice(0,start)+body+sql.slice(end);}
for(const name of ['configuration_valid','source_valid','view','owned','assert_current'])replaceFunction('premium_translation_private.catalog_operation_'+name,fs.readFileSync(path.join(__dirname,'sql',name+'.sql'),'utf8'));
for(const name of ['finish_catalog_translation_operation','reconcile_catalog_translation_operation','get_catalog_translation_operation_artifacts','catalog_translation_operation_ready','begin_catalog_translation_operation','record_catalog_translation_operation_dispatch','record_catalog_translation_operation_response'])replaceFunction('public.'+name,fs.readFileSync(path.join(__dirname,'sql',name+'.sql'),'utf8'));
const helpers=fs.readFileSync(path.join(__dirname,'sql/helpers.sql'),'utf8');
sql=sql.replace('create function premium_translation_private.catalog_operation_configuration_valid(',()=>helpers+'\n\ncreate function premium_translation_private.catalog_operation_configuration_valid(');
const old=fs.readFileSync(path.join(repo,'supabase/migrations/20261029181630_site_copy_private_translation_review.sql'),'utf8');
const start=old.indexOf('create or replace function public.promote_premium_translation_working_draft(');
const end=old.indexOf('$$;',old.indexOf('as $$',start))+3;
const originalPromote=old.slice(start,end);
const insertion="  if p_entity_type in ('literary_work','country') then\n    perform premium_translation_private.assert_catalog_operation_promotion_current(candidate,p_catalog_source_hash,p_catalog_source_fields);\n  end if;\n";
const needle='  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,candidate.source_snapshot,';
if(!originalPromote.includes(needle))throw Error('Promote insertion boundary missing');
const promoted=originalPromote.replace(needle,insertion+needle);
if(promoted.replace(insertion,'')!==originalPromote)throw Error('Unrelated promotion bytes changed');
sql=sql.slice(0,sql.indexOf('revoke all on function premium_translation_private.catalog_operation_configuration_valid'))+
 fs.readFileSync(path.join(__dirname,'sql/promotion.sql'),'utf8')+'\n\n'+promoted+'\n\n'+fs.readFileSync(path.join(__dirname,'sql/acl.sql'),'utf8')+'\ncommit;\n';
fs.writeFileSync(target,sql);
console.log(JSON.stringify({target,bytes:Buffer.byteLength(sql),promoteOriginalBytes:Buffer.byteLength(originalPromote),unrelatedPromoteBytesPreserved:true}));
