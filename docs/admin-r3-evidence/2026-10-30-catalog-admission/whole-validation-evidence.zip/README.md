# Whole-admin catalog admission validation

The final207-file broad suite and five gates bind to the frozen source fingerprint
in final/validation-summary.json. Six historical M02 missing-original-fixture cases
remain FAIL. The readonly text gate remains the exact previous41 findings; four
other gates pass. No skip, replacement BEFORE or weakened assertion was used. The first frozen
broad run retained24 legacy review-transport setup failures plus the six known
M02 failures. V2 corrects only that fixture, preserves all production bytes and
reruns the complete207-file selection; original failures remain in history/.

Separate controlled-runtime and native SQL archives bind the new mandatory book
and country admission, private raw/completed output retention, optional review,
source/rights/manual protection and actual cursor/ACK behavior. The same original
admission contract retains four BEFORE target failures and four CURRENT passes.
Their declared scopes and intermediate failures are separate from this broad run.

Two next UI preflight BEFORE archives contain genuine target FAIL controls: the
view still offers approval after full-source metadata drift. Current atomic SQL
approval refuses both book and country drift. These are not unsafe canonical
writes and are not mislabeled UI acceptance. The full project goal remains open.

Runners need pinned repository dependencies and deliberate path adaptation from
their original workspace. Keep the safe child environment and fresh output dirs.
Verify all internal manifests. No credentials, dependencies, caches, database
data/binaries or generated application bundles are packaged.
