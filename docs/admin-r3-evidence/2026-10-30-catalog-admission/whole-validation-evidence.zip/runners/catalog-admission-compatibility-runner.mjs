import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
const work=path.dirname(fileURLToPath(import.meta.url)), root=path.resolve(work,'../probpera-literary-map');
const out=path.join(work,'catalog-admission-compatibility-v2');
if(fs.existsSync(out))throw Error('Use a fresh evidence directory');
fs.mkdirSync(path.join(out,'temp'),{recursive:true});
const files=['apps/admin/lib/writer-admission-routing.integration.test.ts','apps/admin/lib/writer-translation-operation-rpc.integration.test.ts','apps/admin/lib/catalog-translation-operation-rpc.integration.test.ts','apps/admin/app/(dashboard)/editorial-database/editorial-database-load-errors.integration.test.ts','apps/admin/app/(dashboard)/library/library-load-errors.integration.test.ts'];
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>/^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i.test(key)));
Object.assign(env,{CI:'1',NEXT_TELEMETRY_DISABLED:'1',NO_COLOR:'1',TMP:path.join(out,'temp'),TEMP:path.join(out,'temp')});
const args=[path.join(root,'node_modules/vitest/vitest.mjs'),'run',...files,'--maxWorkers=2','--reporter=verbose','--reporter=json','--outputFile.json='+path.join(out,'tests.raw.json')];
const receipt={startedAt:new Date().toISOString(),files,executable:process.execPath,args,environmentPolicy:'OS paths only, task TMP/TEMP, CI and telemetry optout',status:'RUNNING'};
const save=()=>fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');save();
const log=path.join(out,'tests.log');fs.writeFileSync(log,'');
const child=spawn(process.execPath,args,{cwd:root,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
child.stdout.on('data',bytes=>fs.appendFileSync(log,bytes));child.stderr.on('data',bytes=>fs.appendFileSync(log,bytes));
child.on('error',error=>{receipt.error=String(error);save();});
child.on('close',(exitCode,signal)=>{
 Object.assign(receipt,{finishedAt:new Date().toISOString(),exitCode,signal,status:exitCode===0?'PASS':'FAIL',logSha256:createHash('sha256').update(fs.readFileSync(log)).digest('hex')});
 if(fs.existsSync(path.join(out,'tests.raw.json'))){const report=JSON.parse(fs.readFileSync(path.join(out,'tests.raw.json'),'utf8'));receipt.tests={total:report.numTotalTests,passed:report.numPassedTests,failed:report.numFailedTests,pending:report.numPendingTests};}
 save();console.log(JSON.stringify(receipt));process.exitCode=exitCode===0?0:1;
});
console.log('Compatibility run started with streaming evidence; previous four-minute timeout preserved.');
