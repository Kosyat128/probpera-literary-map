import datetime, hashlib, json, pathlib, zipfile

repo=pathlib.Path(r'C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map')
work=repo.parent/'work'
out=work/'catalog-admission-final-validation-v2'
destination=repo/'docs/admin-r3-evidence/2026-10-30-catalog-admission'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((out/name).read_text(encoding='utf-8-sig'))
write=lambda name,value:(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
tests=read('selected-tests-summary.json'); receipt=read('selected-tests-receipt.json')
gates=read('gates-summary.json'); drift=read('source-drift.json')
preservation=read('baseline-preservation.json'); increment=read('increment-source-comparison.json')
before=read('source-before.json'); after=read('source-after-tests.json')
assert receipt.get('finishedAt') and before['head']==after['head']
assert drift['zeroValidationSourceDrift'] and before['validationSourceSha256']==after['validationSourceSha256']
assert preservation['pass'] and increment['status']=='PASS'
assert tests['testFileCount']==207 and tests['numPendingTests']==0 and tests['numTodoTests']==0
for gate in gates['receipts']:
    individual=read(gate['id']+'-receipt.json')
    assert individual.get('finishedAt') and individual['status']==gate['status']

baseline=repo/'docs/admin-r3-evidence/2026-10-30-writer-admission/whole-validation-evidence.zip'
assert sha(baseline.read_bytes())=='289c7b4b26d237c2c7b21bc724375398fc04a4d81e4de25e59647fc87ee65b6b'
with zipfile.ZipFile(baseline) as z:
    old_tests_bytes=z.read('final/selected-tests-summary.json'); old_tests=json.loads(old_tests_bytes)
    old_text=z.read('final/gate-readonly-hyphens.log')
def failures(report):
    return sorted([{'fullName':failure['fullName'],'firstErrors':[message.replace('\r\n','\n').split('\n')[0] for message in failure.get('failureMessages',[])]}
      for file in report.get('failedFiles',[]) for failure in file.get('assertionFailures',[])],key=lambda item:item['fullName'])
comparison={'sameFailureCasesAndFirstErrors':failures(tests)==failures(old_tests),'baseline':failures(old_tests),'current':failures(tests),
 'sourceArchiveSha256':sha(baseline.read_bytes()),'claim':'Exact case names and first diagnostic line; line-ending normalization only. No fabricated original fixture, ignored case or replacement BEFORE.'}
write('baseline-failure-comparison.json',comparison)
assert comparison['sameFailureCasesAndFirstErrors'] and tests['numFailedTests']==6
text=(out/'gate-readonly-hyphens.log').read_bytes()
text_comparison={'byteIdenticalToBaseline':text==old_text,'baselineSha256':sha(old_text),'currentSha256':sha(text),
 'findingCount':sum(line.startswith('- ') for line in text.decode('utf-8-sig').splitlines()),'normalizerWriteFlagUsed':False}
write('readonly-gate-baseline-comparison.json',text_comparison)
assert text_comparison['byteIdenticalToBaseline'] and text_comparison['findingCount']==41
assert gates['passed']==4 and all(g['status']=='PASS' or g['id']=='gate-readonly-hyphens' for g in gates['receipts'])
external=[]
for name in ['catalog-admission-controlled-tests.zip','sql-evidence.zip','next-catalog-review-full-seed-before.zip','next-catalog-country-review-full-seed-before.zip']:
    file=destination/name; assert file.exists()
    external.append({'path':name,'bytes':file.stat().st_size,'sha256':sha(file.read_bytes())})
expected_next={'next-catalog-review-full-seed-before.zip':'f45180d64f50bde36a74189641958cfc7e2aec6d899ee09cb08321572b9fd2c4',
 'next-catalog-country-review-full-seed-before.zip':'2c7588bdc02a5cec9c1e8c1088a1b2b50386d2882df209b4cd0436fca438871a'}
assert all(item['sha256']==expected_next[item['path']] for item in external if item['path'] in expected_next)
summary={'schemaVersion':1,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':before['head'],
 'classification':'LOCAL_CATALOG_INCREMENT_VERIFIED_WITH_KNOWN_INHERITED_FAILURES_NOT_FULL_R3_ACCEPTANCE',
 'tests':{'files':tests['testFileCount'],'total':tests['numTotalTests'],'passed':tests['numPassedTests'],'failed':tests['numFailedTests'],
 'pending':tests['numPendingTests'],'todo':tests['numTodoTests'],'exitCode':receipt['exitCode'],'sameSixHistoricalFailures':True},
 'gates':{**gates,'readonlyLogByteIdenticalToBaseline':True,'readonlyFindingCount':41},
 'source':{'nonDocFileCount':after['validationSourceCount'],'nonDocFingerprint':after['validationSourceSha256'],'fullFileCount':after['trackedFileCount'],
 'beforeFullAggregate':before['aggregateSha256'],'afterTestsFullAggregate':after['aggregateSha256'],'zeroValidationSourceDrift':True,
 'changedExistingVersusWriter':len(increment['changedExisting']),'addedVersusWriter':len(increment['added']),'unchangedPreviousFiles':increment['unchangedOriginalSourceCount'],
 'exclusion':'docs/ only; all tracked/owned non-doc files compared. Documentation changes are separately reported.'},
 'preservation':{'pass':True,'normalizers':len(preservation['normalizers']),'rulesAndTests':len(preservation['normalizerRulesAndTests']),
 'ASTScopes':len(preservation['normalizerImportAndCallScopes']),'oldMigrations':len(preservation['oldMigrations']),
 'telegramPaths':len(preservation['independentTelegram']),'packageFiles':len(preservation['packages']),'writeFlagUsed':False},
 'externalArchives':external,
 'limitations':['Six M02 cases require absent genuine original .tmp/m02-operation-wiring-before files; failures retained.',
 'Readonly text gate remains the exact previous41 findings; excluded normalizer subsystem preserved.',
 'First frozen broad V1 had24 additional legacy review-fixture setup failures plus6 historical failures; raw V1 is preserved. V2 changes only that faithful transport test, with all production bytes unchanged.',
 'Focused361 and native DTO41 are distinct overlapping scopes, not additional acceptance criteria. Earlier324 compatibility PASS is not substituted for this frozen-source broad run; its original240-second timeout is retained.',
 'Native PostgreSQL uses controlled Auth/staff boundaries; consult its original advisor/lint/history receipts. No live managed acceptance is claimed.',
 'UI preflight still offers approval after metadata-only full-seed drift; current atomic SQL promotion refuses it. Both next-step genuine BEFORE target failures are separate archives.',
 'Partial-pass replay, global budgets/concurrency, stable T12 scanning and full operator retry remain pending.',
 'No keys/setup, paid provider, managed/browser E2E, production migration/deploy, push or PR ran. Full26-module/230-criterion goal remains active.']}
write('validation-summary.json',summary)
history=work/'catalog-admission-final-validation-v1'
first=json.loads((history/'source-before.json').read_text(encoding='utf-8'))
old={f['path']:f for f in first['files'] if not f['path'].startswith('docs/')}
new={f['path']:f for f in before['files'] if not f['path'].startswith('docs/')}
changed=[{'path':p,'beforeSha256':old[p]['sha256'],'afterSha256':f['sha256']} for p,f in new.items() if p in old and old[p]!=f]
assert [f['path'] for f in changed]==['apps/admin/lib/premium-translation-review.integration.test.ts']
assert set(old)==set(new) and first['head']==before['head']
history_report=json.loads((history/'selected-tests-summary.json').read_text(encoding='utf-8'))
assert history_report['numFailedTests']==30 and sum(len(f['assertionFailures']) for f in history_report['failedFiles'] if f['name'].endswith('/premium-translation-review.integration.test.ts'))==24
write('v1-to-v2-source-comparison.json',{'status':'PASS','comparisonExclusion':'docs/ only','firstFingerprint':first['validationSourceSha256'],
 'finalFingerprint':before['validationSourceSha256'],'changed':changed,'unchangedPreviousFiles':len(old)-1,
 'firstBroad':{'total':history_report['numTotalTests'],'passed':history_report['numPassedTests'],'failed':30,'newLegacyReviewFixtureFailures':24,'historicalM02Failures':6},
 'firstRunClassification':'Preserved failed first broad run; no gates ran on V1. One review transport test correction only; all production source bytes unchanged.'})
entries={}
for file in history.iterdir():
    if file.is_file() and file.suffix in ['.json','.log','.txt']:
        entries['history/first-frozen-broad/'+file.name]=file.read_bytes()
for file in out.iterdir():
    if file.is_file() and file.suffix in ['.json','.log','.txt','.md'] and file.name!='evidence-package-manifest.json':entries['final/'+file.name]=file.read_bytes()
for name in ['catalog-admission-final-validation-v2-runner.mjs','catalog-admission-final-preservation-v2.mjs','catalog-admission-increment-comparison-v2.mjs','catalog-admission-compatibility-runner.mjs','package-catalog-admission-final-validation-v2.py','package-catalog-review-before.py','catalog-admission-final-validation-v1-runner.mjs']:
    entries['runners/'+name]=(work/name).read_bytes()
entries['baseline/selected-tests-summary.json']=old_tests_bytes
entries['baseline/gate-readonly-hyphens.log']=old_text
entries['external-archive-readback.json']=(destination/'root-independent-archive-check.json').read_bytes()
entries['README.md']=b'''# Whole-admin catalog admission validation

The final207-file broad suite and five gates bind to the frozen source fingerprint
in final/validation-summary.json. Six historical M02 missing-original-fixture cases
remain FAIL. The readonly text gate remains the exact previous41 findings; four
other gates pass. No skip, replacement BEFORE or weakened assertion was used. The first frozen
broad run retained24 legacy review-transport setup failures plus the six known
M02 failures. V2 corrects only that fixture, preserves all production bytes and
reruns the complete207-file selection; original failures remain in history/.

Separate controlled-runtime and native SQL archives bind the new mandatory book
and country admission, private raw/completed output retention, optional review,
source/rights/manual protection and actual cursor/ACK behavior. The same original
admission contract retains four BEFORE target failures and four CURRENT passes.
Their declared scopes and intermediate failures are separate from this broad run.

Two next UI preflight BEFORE archives contain genuine target FAIL controls: the
view still offers approval after full-source metadata drift. Current atomic SQL
approval refuses both book and country drift. These are not unsafe canonical
writes and are not mislabeled UI acceptance. The full project goal remains open.

Runners need pinned repository dependencies and deliberate path adaptation from
their original workspace. Keep the safe child environment and fresh output dirs.
Verify all internal manifests. No credentials, dependencies, caches, database
data/binaries or generated application bundles are packaged.
'''
manifest={'schemaVersion':1,'head':before['head'],'classification':summary['classification'],'sourceFingerprint':after['validationSourceSha256'],
 'entries':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]}
entries['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
archive=destination/'whole-validation-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    for item in manifest['entries']:assert sha(z.read(item['path']))==item['sha256']
package_receipt={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
 'verifiedPayloads':len(manifest['entries']),'manifestSha256':sha(entries['manifest.json']),
 'sourceFingerprint':after['validationSourceSha256'],'testFiles':207,'testsPassed':tests['numPassedTests'],'testsFailed':6,
 'gatesPassed':4,'gatesTotal':5,'readonlyBaselineFindings':41,'sameSixHistoricalFailures':True,'zeroValidationSourceDrift':True}
(destination/'whole-validation-evidence.receipt.json').write_text(json.dumps(package_receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(package_receipt))
