from pathlib import Path
import json,hashlib,zipfile,datetime,sys
work=Path(__file__).resolve().parent
repo=work.parent/'probpera-literary-map'
country=sys.argv[1:]==['country']
capture=work/('catalog-review-country-before' if country else 'catalog-review-full-seed-before')
prefix='next-catalog-country-review-full-seed-before' if country else 'next-catalog-review-full-seed-before'
diagnostic='catalog-review-country-before.cjs' if country else 'catalog-review-full-seed-before.cjs'
destination=repo/'docs/admin-r3-evidence/2026-10-30-catalog-admission'
destination.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
report=json.loads((capture/'report.json').read_text(encoding='utf-8'))
assert not report['assertion']['pass'] and (report.get('catalogAndOtherOverrideFieldsExact') if country else report['masterRowsExact']) and report['providerCalls']==2
entries={'report.json':(capture/'report.json').read_bytes(),'diagnostic-before.cjs':(work/diagnostic).read_bytes()}
for source in report['graph']:
    data=(capture/'sources'/source['module']).read_bytes()
    assert sha(data)==source['sha256']
    entries['sources/'+source['module']]=data
for name in ['catalog-admission-runtime.cjs','catalog-admission-boundary.cjs']:
    entries['support/'+name]=(repo/'apps/admin/lib/fixtures'/name).read_bytes()
original=repo/'docs/admin-r3-evidence/2026-10-30-writer-admission/next-library-country-admission-before.zip'
data=original.read_bytes()
assert sha(data)=='652bbe1367df8b92f267a418600d55ce76feb9fa1f9a69b969722a02c8f27cef'
entries['support/original-library-country-before.zip']=data
packages=[]
for name in ['@supabase/supabase-js','typescript','next','zod','fflate']:
    p=repo/'node_modules'/name/'package.json'
    packages.append({'name':name,'version':json.loads(p.read_text(encoding='utf-8'))['version'],'packageManifestSha256':sha(p.read_bytes())})
entries['runtime-packages.json']=(json.dumps(packages,indent=2)+'\n').encode()
entries['README.md']=b'''# Genuine next UI preflight defect

The actual current review helper and installed SDK observe an initially valid
private book candidate. Changing only the full source licence, with all master,
RU and EN row bytes/timestamps exact, still exposes canPromote=true. The frozen
target assertion expects false and FAILS. Initial ready, exact source drift,
two unchanged controlled calls, zero canonical writes and zero builds PASS.

This capture concerns the earlier UI preflight only. Current native SQL evidence
separately proves atomic human approval refuses this full-seed drift. This is
not a claim of an unsafe canonical write, whole UI acceptance or live-provider
execution. The next correction must preserve the original target assertion.

Source files, diagnostic and versioned transport support are frozen separately.
The diagnostic has original workspace paths; replay against frozen sources
needs explicit path/loader adaptation, never replacing this genuine BEFORE.
Dependencies and original support archive are pinned; no credentials, database
binaries, database data, caches or generated applications are packaged.
'''
manifest={'schemaVersion':1,'classification':report['classification'],'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'entries':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]}
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
entries['manifest.json']=manifest_bytes
if country:
    entries['README.md']=b'''# Genuine next country UI preflight defect

Actual current review helper and installed SDK: a private country candidate is
initially approvable. Changing only opaque override rights while its timestamp,
catalogue, EN and all other fields remain exact still gives canPromote=true.
The frozen target expects false and FAILS; all controls PASS, two controlled
calls remain unchanged, canonical machine writes and builds remain zero.

This is the earlier UI preflight only. Separate native SQL proves atomic human
approval refuses full override drift. No unsafe canonical write is claimed.
Source graph, original diagnostic and transport support are frozen. Deliberate
path/loader adaptation is needed to replay against frozen sources; preserve
this genuine BEFORE and its target assertion. No live provider was used.
'''
    manifest['entries']=[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items()) if name!='manifest.json']
    manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
    entries['manifest.json']=manifest_bytes
archive=destination/(prefix+'.zip')
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    for entry in manifest['entries']:assert sha(z.read(entry['path']))==entry['sha256']
receipt={'path':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'verifiedPayloads':len(manifest['entries']),
 'actualProductionModuleCount':len(report['graph']),'controls':'PASS','target':'FAIL (genuine unresolved UI preflight)',
 'manifestSha256':sha(manifest_bytes)}
(destination/(prefix+'-manifest.json')).write_bytes(manifest_bytes)
(destination/(prefix+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
