const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const inputPath=path.resolve(process.argv[2]),outputPath=path.resolve(process.argv[3]);
assert.equal(fs.existsSync(outputPath),false,'Never overwrite immutable SAME acceptance evidence');
const bytes=fs.readFileSync(inputPath),report=JSON.parse(bytes),checks=[];
const check=(kind,name,category,fn)=>{try{fn();checks.push({kind,name,category,pass:true});}catch(error){checks.push({kind,name,category,pass:false,error:error.stack||String(error)});}};
for(const kind of ['library','country']){
 const r=report.cases.find(c=>c.kind===kind);assert.ok(r);
 check(kind,'Actual action/helper/premium/SDK execution is bound','control',()=>{
  const action=kind==='library'?'apps/admin/app/(dashboard)/translations/actions.ts':'apps/admin/app/(dashboard)/translations/country-actions.ts';
  const helper=kind==='library'?'apps/admin/lib/auto-translate-literary-work.ts':'apps/admin/lib/auto-translate-country-profile.ts';
  for(const module of [action,helper,'apps/admin/lib/premium-english-translation.ts','apps/admin/lib/translation-operation-budget.ts','apps/admin/lib/translation-run-record.ts'])assert.ok(r.sources.some(s=>s.module===module));
  if(kind==='library')assert.ok(r.sources.some(s=>s.module==='apps/admin/lib/auto-translate-literary-work-safe.ts'));
  assert.ok(r.packages.some(p=>p.name==='@supabase/supabase-js'));assert.equal(r.executionFailures,0);
 });
 check(kind,'One accepted request loses delivery and both fresh actual actions redirect','control',()=>{
  assert.equal(r.snapshots.length,2);assert.equal(r.snapshots[0].addedSameSourceCalls,1);
  assert.equal(r.providerCalls[0].acceptedByControlledBoundary,true);assert.equal(r.providerCalls[0].delivery,'lost-after-acceptance');
  assert.equal(r.snapshots[0].privateCandidates,0);assert.ok(r.snapshots.every(s=>s.redirect.includes('/translations')));
 });
 check(kind,'Canonical/manual/source/rights/revisions are preserved without public build','preservation',()=>{
  assert.deepEqual(r.canonicalAfter,r.canonicalBefore);assert.equal(r.canonicalMachineWrites,0);assert.equal(r.publicBuildRequests,0);
  assert.equal(r.providerCalls.filter(c=>c.entityId===r.manualId).length,0);
 });
 check(kind,'Fresh same-source action must make zero provider calls after uncertain acceptance','target',()=>assert.equal(r.snapshots[1].addedSameSourceCalls,0));
 check(kind,'A durable recoverable operation identity must precede the provider dispatch','target',()=>{
  const at=r.timeline.findIndex(e=>e.event==='controlled-provider-accepted');assert.ok(at>=0);
  assert.ok(r.timeline.slice(0,at).some(e=>e.event==='sdk-boundary'&&e.method==='POST'&&/begin|dispatch|admission/iu.test(e.name)),
   'A later dead_letter summary is not durable pre-dispatch admission');
 });
}
const result={contract:'Immutable SAME library+country unknown-provider-result admission invariants',checkedAt:new Date().toISOString(),inputPath,inputSha256:sha(bytes),
 contractSha256:sha(fs.readFileSync(__filename)),checks,controlFailures:checks.filter(c=>!c.pass&&c.category!=='target').length,
 targetFailures:checks.filter(c=>!c.pass&&c.category==='target').length,
 scope:'Invariant contract over actual execution report, separate from defect-specific observations. Future transport-boundary additions require explicit runner source delta; never call modified whole runner identical.'};
fs.writeFileSync(outputPath,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({outputPath,controlFailures:result.controlFailures,targetFailures:result.targetFailures},null,2));
process.exitCode=result.controlFailures?2:result.targetFailures?1:0;
