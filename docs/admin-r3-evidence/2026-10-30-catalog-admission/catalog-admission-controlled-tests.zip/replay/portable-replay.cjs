const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const extracted=path.resolve(__dirname,'..'),dependencies=path.resolve(process.argv[2]||''),out=path.resolve(process.argv[3]||'');
assert.ok(process.argv[2]&&process.argv[3],'Usage: node replay/portable-replay.cjs <project-checkout-with-installed-dependencies> <new-output-directory>');
assert.equal(fs.existsSync(out),false,'Use a new output directory; the dependency repository remains read-only');fs.mkdirSync(out,{recursive:true});
const native=require('node:module').createRequire(path.join(dependencies,'package.json')),{unzipSync}=native('fflate');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex'),source=path.join(extracted,'source-current');
const archive=fs.readFileSync(path.join(extracted,'original-before/next-library-country-admission-before.zip'));
assert.equal(sha(archive),'652bbe1367df8b92f267a418600d55ce76feb9fa1f9a69b969722a02c8f27cef');
const originals=unzipSync(archive),before=path.join(out,'before-source'),written=new Map();
for(const [name,bytes]of Object.entries(originals)){const match=/^diagnostic-before\/(?:library|country)\/raw-graph\/sources\/(.+)$/u.exec(name);if(!match)continue;
  if(written.has(match[1])){assert.equal(sha(bytes),written.get(match[1]));continue;}const destination=path.join(before,match[1]);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes,{flag:'wx'});written.set(match[1],sha(bytes));}
const contract=path.join(out,'original-contract.cjs');fs.writeFileSync(contract,originals['admission-loss.same-contract.cjs']);
assert.equal(sha(fs.readFileSync(contract)),'1032b8b03fa702b1ab44a22681a5db4630626cf4ac323841191dedc684a20d04');
const preload=path.join(out,'input-artifact-location.cjs');
const mappings=Object.fromEntries([['docs/admin-r3-evidence/2026-10-30-writer-admission/next-library-country-admission-before.zip','next-library-country-admission-before.zip'],
  ['docs/admin-r3-evidence/2026-10-29-profile-budgets/next-writer-admission-before.zip','next-writer-admission-before.zip']].map(([relative,name])=>[path.join(dependencies,relative),path.join(extracted,'original-before',name)]));
fs.writeFileSync(preload,`const fs=require('node:fs'),path=require('node:path'),read=fs.readFileSync;const map=${JSON.stringify(mappings)};fs.readFileSync=function(file,...args){return read.call(this,typeof file==='string'?(map[path.resolve(file)]||file):file,...args);};\n`);
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>/^(?:PATH|SystemRoot|windir|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i.test(key)));
const temp=path.join(out,'temp');fs.mkdirSync(temp);Object.assign(env,{TEMP:temp,TMP:temp,CATALOG_ADMISSION_REPO:dependencies});
const runs=[];function run(name,args,extra={}){const value=spawnSync(process.execPath,['--require',preload,...args],{cwd:dependencies,env:{...env,...extra},encoding:'utf8',timeout:60000,maxBuffer:32*1024*1024});
  fs.writeFileSync(path.join(out,name+'.stdout.log'),value.stdout||'');fs.writeFileSync(path.join(out,name+'.stderr.log'),value.stderr||'');runs.push({name,status:value.status,error:value.error?.message||null});return value;}
const fixture=path.join(source,'apps/admin/lib/fixtures/catalog-admission-runtime.cjs');
for(const mode of ['before','current']){const directory=path.join(out,mode);assert.equal(run(mode,[fixture],{CATALOG_ADMISSION_SOURCE_ROOT:mode==='before'?before:source,CATALOG_ADMISSION_OUTPUT_ROOT:directory}).status,0);
  const result=path.join(out,mode+'-contract.json'),checked=run(mode+'-contract',[contract,path.join(directory,'same-scenario-report.json'),result]);
  const proof=JSON.parse(fs.readFileSync(result));assert.equal(proof.controlFailures,0);assert.equal(proof.targetFailures,mode==='before'?4:0);assert.equal(checked.status,mode==='before'?1:0);}
assert.equal(run('runtime-cases',[path.join(source,'apps/admin/lib/fixtures/catalog-admission-cases.cjs')],{CATALOG_ADMISSION_SOURCE_ROOT:source,CATALOG_ADMISSION_OUTPUT_ROOT:path.join(out,'cases')}).status,0);
const cases=JSON.parse(fs.readFileSync(path.join(out,'cases/catalog-admission-cases-report.json')));assert.ok(cases.checks.every(x=>x.pass));
assert.equal(run('native-dto',[path.join(extracted,'replay/native-dto-conformance.cjs')],{CATALOG_DTO_REPO:dependencies,CATALOG_DTO_NATIVE:path.join(extracted,'native-sql'),CATALOG_DTO_OUTPUT:path.join(out,'native-dto'),CATALOG_DTO_SOURCE_ROOT:source}).status,0);
const dto=JSON.parse(fs.readFileSync(path.join(out,'native-dto/report.json')));assert.equal(dto.checks.length,41);assert.ok(dto.checks.every(x=>x.pass));
const receipt={atUtc:new Date().toISOString(),dependencyRepositoryReadOnly:dependencies,capturedApplicationSources:source,runs,runtimeGroups:cases.checks.length,nativeChecks:dto.checks.length,
  beforeTargetFailures:4,currentTargetFailures:0,controlFailures:0,
  hosting:'No symlink, dependency install, parentwork path or service required. Input archive file locations alone are redirected to their byte-verified bundled copies; application source loading and all algorithms remain unchanged.',
  scope:'Portable direct-runtime/immutable-contract/nativeDTO replay. The separate recorded focused Vitest/typecheck selection also covers UI and legacy assertions.'};
fs.writeFileSync(path.join(out,'portable-replay-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));
