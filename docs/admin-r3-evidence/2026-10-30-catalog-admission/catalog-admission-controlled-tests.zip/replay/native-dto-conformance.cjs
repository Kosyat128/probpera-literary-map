const assert = require('node:assert/strict'), fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const { createRequire } = require('node:module');
const repo = process.env.CATALOG_DTO_REPO || path.resolve(__dirname, '../../probpera-literary-map'), nativeDir = process.env.CATALOG_DTO_NATIVE || path.resolve(__dirname, '../catalog-operation-sql-native');
const output = process.env.CATALOG_DTO_OUTPUT || path.join(__dirname, `native-dto-${new Date().toISOString().replaceAll(/[:.]/g,'-')}`); fs.mkdirSync(output,{recursive:true});
process.env.CATALOG_ADMISSION_REPO = repo; process.env.CATALOG_ADMISSION_SOURCE_ROOT = process.env.CATALOG_DTO_SOURCE_ROOT || repo; process.env.CATALOG_ADMISSION_OUTPUT_ROOT = path.join(output,'runtime');
const { setup } = require(path.join(repo,'apps/admin/lib/fixtures/catalog-admission-runtime.cjs'));
const runtime = setup('library'), api = runtime.load('apps/admin/lib/catalog-translation-operation-rpc.ts');
const { createClient } = createRequire(path.join(repo,'package.json'))('@supabase/supabase-js');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const files = ['native-receipts.json','concurrent-receipts.json','native-artifacts.json'];
const inputs = [], checks = [];
const named = data => Array.isArray(data) ? data.map((value,index)=>[String(index),value]) : Object.entries(data);
function nestedReceipts(value,label='root') {
  if (!value || typeof value !== 'object') return [];
  if (value.jobId && value.itemId && value.operationId && value.phase && value.entityId) return [[label,value]];
  return Object.entries(value).flatMap(([key,item])=>nestedReceipts(item,`${label}.${key}`));
}
async function main() {
  for (const name of files) {
    const filename=path.join(nativeDir,name), bytes=fs.readFileSync(filename), data=JSON.parse(bytes);
    inputs.push({file:filename,bytes:bytes.length,sha256:sha(bytes)});
    for (const [label,value] of name === 'concurrent-receipts.json' ? nestedReceipts(data) : named(data)) {
      try {
        if (name !== 'native-artifacts.json') {
          const receipt = value.receipt || value;
          if (receipt.entityType) assert.ok(api.parseCatalogTranslationOperationReceipt(receipt,{entityType:receipt.entityType,entityId:receipt.entityId}), 'Actual catalog parser must accept unchanged native catalog receipt');
          else {
            const writer = runtime.load('apps/admin/lib/writer-translation-operation-rpc.ts');
            assert.ok(writer.parseWriterTranslationOperationReceipt(receipt,{countryId:receipt.countryId,writerId:receipt.writerId}), 'Existing writer parser accepts unchanged compatibility receipt, without widening catalog admission');
          }
        } else {
          const target=value.receipt, requests=[];
          const sdk=createClient('https://native-catalog-dto.fixture.invalid','synthetic-no-live-auth',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},global:{fetch:async(input,init={})=>{
            const url=new URL(typeof input==='string'?input:input.url); assert.equal(url.origin,'https://native-catalog-dto.fixture.invalid');
            assert.equal(url.pathname,'/rest/v1/rpc/get_catalog_translation_operation_artifacts');
            const args=JSON.parse(init.body); requests.push(args);
            assert.deepEqual(args,{p_job_id:target.jobId,p_item_id:target.itemId,p_operation_id:target.operationId,p_entity_type:target.entityType,p_entity_id:target.entityId,p_intent_hash:target.intentHash,p_source_hash:target.sourceHash});
            return new Response(JSON.stringify(value),{status:200,headers:{'Content-Type':'application/json'}});
          }}});
          const parsed=await api.getCatalogTranslationOperationArtifacts(sdk,target); assert.deepEqual(parsed,value,'Native artifacts must pass without DTO normalization or payload replacement'); assert.equal(requests.length,1);
        }
        checks.push({file:name,label,pass:true});
      } catch(error) { checks.push({file:name,label,pass:false,error:error.stack||String(error)}); }
    }
  }
  const sources=[...runtime.graph.values()];
  for(const source of sources) assert.equal(sha(fs.readFileSync(path.join(repo,source.module))),source.sha256);
  const report={atUtc:new Date().toISOString(),inputs,checks,sources,unchanged:true,providerCalls:runtime.providerCalls.length,
    scope:'Unchanged native PostgreSQL receipt/artifact values replayed through actual maintained TS parser and installed-SDK privateGET wrapper. Only SDK return transport controlled; native DB was independently exercised by SQL owner.',
    limitations:['No live services, provider expense, external invoice, production operations or approval UI acceptance.']};
  fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n'); console.log(JSON.stringify({output,checks,sourceCount:sources.length}));
  process.exitCode=checks.some(check=>!check.pass)?1:0;
}
main().catch(error=>{console.error(error.stack||String(error));process.exitCode=2;});
