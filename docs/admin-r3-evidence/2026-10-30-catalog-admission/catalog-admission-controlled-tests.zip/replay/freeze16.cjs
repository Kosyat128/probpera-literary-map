const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),ts=require(path.join(repo,'node_modules/typescript'));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex'),file='apps/admin/lib/premium-translation-review.integration.test.ts';
const original=fs.readFileSync(path.join(__dirname,'legacy-originals/premium-translation-review.integration.test.ts')),current=fs.readFileSync(path.join(repo,file));
function expectations(bytes){const ast=ts.createSourceFile(file,bytes.toString(),ts.ScriptTarget.Latest,true),result=[];
  function visit(node){if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='expect')result.push(node.getText(ast));ts.forEachChild(node,visit);}visit(ast);return result;}
assert.deepEqual(expectations(current),expectations(original),'Every original expect call remains exactly unchanged');
const previous=JSON.parse(fs.readFileSync(path.join(__dirname,'final-focused-2026-10-29T22-31-41-156Z/owned-source-freeze.json')));
for(const owned of previous.owned)assert.equal(sha(fs.readFileSync(path.join(repo,owned.file))),owned.sha256);
const raw=JSON.parse(fs.readFileSync(path.join(__dirname,'premium-review-adapter-v1.raw.json')));assert.equal(raw.numPassedTests,34);assert.equal(raw.numFailedTests,0);
const report={atUtc:new Date().toISOString(),owned:[...previous.owned,{file,bytes:current.length,sha256:sha(current)}],ownedCount:16,previous15Unchanged:true,
  reviewBoundary:{file,originalSha256:sha(original),currentSha256:sha(current),originalExpectCalls:expectations(original).length,currentExpectCalls:expectations(current).length,expectCallsExactlyEqual:true,tests:34,passed:34},
  priorFocused:{tests:361,passed:361},wholeAdminTypecheckExit:0,productionChanges:false,
  reason:'Root-authorized boundary-only 16th adapter after broadV1 exposed24fixture-transport failures; original human/CAS/ack/publication/source/hyphen/opaque assertions are unchanged.'};
fs.writeFileSync(path.join(__dirname,'owned16-source-freeze.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({sha256:sha(fs.readFileSync(path.join(__dirname,'owned16-source-freeze.json'))),...report.reviewBoundary}));
