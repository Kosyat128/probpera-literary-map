const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const repo = path.resolve(__dirname, '../../probpera-literary-map');
const output = path.join(__dirname, `final-focused-${new Date().toISOString().replaceAll(/[:.]/g, '-')}`);
fs.mkdirSync(output, { recursive: true });
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const owned = ['catalog-translation-operation-rpc.integration.test.ts','catalog-admission.integration.test.ts','catalog-admission-routing.integration.test.ts',
  'fixtures/catalog-admission-boundary.cjs','fixtures/catalog-admission-runtime.cjs','fixtures/catalog-admission-cases.cjs',
  'fixtures/library-batch-budget-cap.cjs','fixtures/country-batch-budget-cap.cjs','fixtures/profile-library-budget-controls.cjs',
  'profile-library-batch-budgets.integration.test.ts','literary-work-machine-review.integration.test.ts','country-profile-machine-review.integration.test.ts',
  'literary-work-manual-english.integration.test.ts','country-profile-manual-english.integration.test.ts','country-translation-source-binding.integration.test.ts'].map(file => `apps/admin/lib/${file}`);
const writer = ['translation-response-artifacts.integration.test.ts','writer-translation-operation-rpc.integration.test.ts','writer-admission.integration.test.ts',
  'writer-admission-routing.integration.test.ts','writer-biography-machine-review.integration.test.ts','profile-library-batch-budgets.integration.test.ts'].map(file => `apps/admin/lib/${file}`);
const tests = [...new Set([...writer,...owned.filter(file => file.endsWith('.test.ts'))])];
const snapshot = files => files.map(file => ({ file, bytes: fs.statSync(path.join(repo,file)).size, sha256: sha(fs.readFileSync(path.join(repo,file))) }));
const before = snapshot(owned), start = Date.now();
const temp = path.join(output,'temp'); fs.mkdirSync(temp);
const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => /^(?:PATH|SystemRoot|windir|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i.test(key)));
Object.assign(env, { TEMP: temp, TMP: temp });
const commands = [
  { name:'vitest', args:['node_modules/vitest/vitest.mjs','run',...tests,'--reporter=json','--outputFile='+path.join(output,'vitest-report.json')], max:240000 },
  { name:'typecheck', args:['node_modules/typescript/bin/tsc','--noEmit','--project','apps/admin/tsconfig.json','--pretty','false'], max:90000 },
];
const runs = commands.map(command => {
  const result = spawnSync(process.execPath,command.args,{cwd:repo,env,encoding:'utf8',timeout:command.max,maxBuffer:32*1024*1024});
  fs.writeFileSync(path.join(output,command.name+'.stdout.log'),result.stdout||''); fs.writeFileSync(path.join(output,command.name+'.stderr.log'),result.stderr||'');
  return {name:command.name,command:[process.execPath,...command.args],exit:result.status,error:result.error?.message||null,signal:result.signal};
});
const after = snapshot(owned), vitest = fs.existsSync(path.join(output,'vitest-report.json')) ? JSON.parse(fs.readFileSync(path.join(output,'vitest-report.json'))) : null;
const receipt = {atUtc:new Date().toISOString(),repo,output,startMs:start,tests,ownedBefore:before,ownedAfter:after,ownedUnchanged:JSON.stringify(before)===JSON.stringify(after),runs,
  selection:{files:vitest?.numTotalTestSuites,tests:vitest?.numTotalTests,passed:vitest?.numPassedTests,failed:vitest?.numFailedTests,pending:vitest?.numPendingTests},
  limits:['Focused controlled integration; native SQL separately verified. Original writer 154 case meanings preserved, shared book/country protocol observation adapted explicitly.',
    'No live services, paid provider, production, normalized content writes, global runner or full M07/T13 admin browser acceptance.']};
fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify(receipt,null,2)); process.exitCode=runs.some(run=>run.exit!==0)||!receipt.ownedUnchanged?1:0;
