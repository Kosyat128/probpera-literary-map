# Genuine next UI preflight defect

The actual current review helper and installed SDK observe an initially valid
private book candidate. Changing only the full source licence, with all master,
RU and EN row bytes/timestamps exact, still exposes canPromote=true. The frozen
target assertion expects false and FAILS. Initial ready, exact source drift,
two unchanged controlled calls, zero canonical writes and zero builds PASS.

This capture concerns the earlier UI preflight only. Current native SQL evidence
separately proves atomic human approval refuses this full-seed drift. This is
not a claim of an unsafe canonical write, whole UI acceptance or live-provider
execution. The next correction must preserve the original target assertion.

Source files, diagnostic and versioned transport support are frozen separately.
The diagnostic has original workspace paths; replay against frozen sources
needs explicit path/loader adaptation, never replacing this genuine BEFORE.
Dependencies and original support archive are pinned; no credentials, database
binaries, database data, caches or generated applications are packaged.
