const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {createHash}=require('node:crypto');
const repo=path.resolve(__dirname,'../probpera-literary-map');
const out=path.resolve(__dirname,'catalog-review-full-seed-before');
if(fs.existsSync(out))throw Error('Never replace a genuine BEFORE');
fs.mkdirSync(out,{recursive:true});
process.env.CATALOG_ADMISSION_REPO=repo;
process.env.CATALOG_ADMISSION_SOURCE_ROOT=repo;
process.env.CATALOG_ADMISSION_OUTPUT_ROOT=path.join(out,'controlled');
const runtime=require(path.join(repo,'apps/admin/lib/fixtures/catalog-admission-runtime.cjs'));
async function main(){
 const view=runtime.setup('library');
 const generated=await view.helper();assert.equal(generated.state,'translated');
 const api=view.load('apps/admin/lib/premium-translation-review.ts');
 const inspect=()=>api.loadPremiumTranslationReview({supabase:view.sdk,entityType:'literary_work',entityId:view.identity(0)});
 const initial=await inspect();assert.equal(initial.status,'pending');assert.equal(initial.canPromote,true);
 const masterBefore=structuredClone({work:view.rows[0].work,russian:view.rows[0].russian,english:view.rows[0].english});
 const oldSources=structuredClone(view.rows[0].sources);
 view.rows[0].sources[0].license_name='Changed rights while all master rows and timestamps remain exact';
 const after=await inspect();
 assert.deepEqual({work:view.rows[0].work,russian:view.rows[0].russian,english:view.rows[0].english},masterBefore);
 assert.notDeepEqual(view.rows[0].sources,oldSources);
 assert.equal(view.providerCalls.length,2);assert.equal(view.writes.length,0);assert.equal(view.builds.length,0);
 const graph=[...view.graph.values()].sort((a,b)=>a.module.localeCompare(b.module));
 for(const source of graph){
  const data=fs.readFileSync(path.join(repo,source.module));assert.equal(createHash('sha256').update(data).digest('hex'),source.sha256);
  const destination=path.join(out,'sources',source.module);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,data,{flag:'wx'});
 }
 const report={classification:'GENUINE_NEXT_UI_PREFLIGHT_DEFECT_NOT_ACCEPTANCE_PASS',generated,initial,after,
  masterRowsExact:true,sourceRightsChanged:true,providerCalls:view.providerCalls.length,canonicalWrites:0,publicBuildRequests:0,
  graph,assertion:{expectedCanPromote:false,actualCanPromote:after.canPromote,pass:after.status==='pending'&&after.canPromote===false},
  scope:'Actual review helper and SDK-controlled reads. Existing native SQL separately proves atomic promotion refuses this drift. This capture concerns the earlier UI preflight only.'};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({classification:report.classification,controlChecks:'PASS',target:report.assertion,sourceCount:graph.length}));
 assert.equal(report.assertion.pass,true,'UI preflight must close approval after full source rights drift without relying on master timestamp changes');
}
main().catch(error=>{console.error(error.stack);process.exitCode=1;});
