# M07 country batch: retained BEFORE budget defect

This archive records an unresolved BEFORE defect, **not an acceptance PASS**.
Its country action/helper source bytes were captured before either country file
was edited for budgets. Writer/book budget work already existed at that time;
this is a separate country baseline, not the same whole-tree state as the earlier
writer/library captures. HEAD alone does not identify these uncommitted trees.

The original actual country batch starts three costly attempts and six premium
passes despite a success-only cap of two. Three synthetic override timestamps
deliberately change after their reviewer responses. The real helper detects the
late CAS conflicts, records zero successes and three conflicts, and wraps
`countryCursor` to zero. Canonical EN, third locale, catalog fields, sources,
rights and all authored data remain exact; there are no canonical machine writes
or public-build requests.

## Evidence roles

- `country-conflict-budget.cjs`: frozen observation diagnostic; exit **0 means the
  known defect was observed**, not application acceptance.
- `country-conflict-run/`: original report, manifest and fourteen byte-exact
  modules executed before country implementation changes.
- `country-conflict-frozen-replay/`: same diagnostic replayed solely against the
  captured original graph, reproducing three attempts, six passes and conflicts.
- `country-conflict-budget-acceptance.cjs`: separate contract fixture frozen
  before country implementation. With the same three inputs, it expects two
  attempts, four passes, two conflict items and cursor two.
- `country-budget-contract-before/report.json`: four target failures, with
  execution and preservation controls passing. The acceptance child exits **1**
  for those target failures; unexpected execution failures exit **2**.
- Receipts, stdout, source manifests, dependency hashes and `sha256-manifest.json`
  identify actual commands, results and original bytes. The adjacent ZIP manifest
  supplies archive hash and readback verification.

This focused fixture does not establish all M07-T10/T11, M07 or R3 acceptance.

## Replay

Use installed repository Node 24/npm 11 dependencies. No credentials are needed.
Unpack under parent `work/`; choose a new output directory for each execution.

```powershell
$evidence = 'C:\path\to\work\unpacked-country-evidence'
$repo = 'C:\path\to\probpera-literary-map'
Set-Location -LiteralPath $repo
$env:COUNTRY_BUDGET_REPO = $repo
$env:COUNTRY_BUDGET_SOURCE_ROOT = Join-Path $evidence 'country-conflict-run/sources'
$env:COUNTRY_BUDGET_OUTPUT_ROOT = Join-Path $evidence 'new-original-contract-replay'
node (Join-Path $evidence 'country-conflict-budget-acceptance.cjs')
```

Original sources should exit **1** with four target failures. To compare fixed
code, point `COUNTRY_BUDGET_SOURCE_ROOT` at the repository, choose another new
output directory and execute the exact same fixture. Do not replace historical
sources, alter assertions or lower limits to manufacture a passing result.

## Boundaries

Actual country action/helper, structural array counts, timeline/chronology years,
premium two-pass pipeline, runtime gate/probe, run DTO, installed Supabase SDK and
native Next redirect execute. Staff, catalog data, PostgREST transport and
Cloudflare AI binding are controlled. The helper, validators and premium
algorithm are not mocked; uncontrolled network is forbidden by `global.fetch`.

All source/model text and rights are synthetic. There is no separate manual,
current or pending input, invalid-output/repair, deadline, 30-row scan, ordering,
real Auth/PostgREST/database/RLS/provider/browser or production acceptance here.
No paid calls occurred. No credentials, sessions, dependencies or native binaries
are packaged.

Git-status text equality is not a whole-tree byte hash. The strong preservation
claim applies to the fourteen executed/captured source modules. Their hashes were
checked around execution and frozen replay and during ZIP readback. Country
implementation changes subsequently made in the repository do not alter these
captured BEFORE files.
