$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\profile-budget-sql-native'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Earlier postmaster PID exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-advisors.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8'
 $psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not the owned local cluster'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d profile_budget_old_20261029 --no-psqlrc --set=ON_ERROR_STOP=1 -Atc "select jsonb_object_agg(label,value) from public.profile_budget_probe_receipts" > (Join-Path $nativeRoot 'old-native-envelopes.json')
 if($LASTEXITCODE -ne 0){throw 'Old native receipt export failed'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d profile_budget_new_20261029 --no-psqlrc --set=ON_ERROR_STOP=1 -Atc "select jsonb_object_agg(label,value) from public.profile_budget_fixture_results" > (Join-Path $nativeRoot 'new-native-envelopes.json')
 if($LASTEXITCODE -ne 0){throw 'New native receipt export failed'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d profile_budget_new_20261029 --no-psqlrc --set=ON_ERROR_STOP=1 -Atc "select jsonb_build_object('name',p.proname,'returnType',p.prorettype::regtype::text,'securityDefiner',p.prosecdef,'volatility',p.provolatile,'configuration',p.proconfig,'source',p.prosrc) from pg_proc p where p.oid='public.profile_translation_budget_ready()'::regprocedure" > (Join-Path $nativeRoot 'new-native-function.json')
 if($LASTEXITCODE -ne 0){throw 'Function metadata export failed'}
 $available=& $psql -h 127.0.0.1 -p 55438 -U postgres -d profile_budget_new_20261029 --no-psqlrc --set=ON_ERROR_STOP=1 -Atc "select count(*) from pg_available_extensions where name='plpgsql_check'"
 if($LASTEXITCODE -ne 0){throw 'Extension availability query failed'}
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1'
 $env:SUPABASE_HOME='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\profile-budget-sql-native\cli-home'
 $cli='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\portable-db-tools\supabase-2.120.0\supabase.exe'
 $url='postgresql://postgres@127.0.0.1:55438/profile_budget_new_20261029?sslmode=disable'
 & $cli db advisors --db-url $url --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors.log')
 $advisorExit=$LASTEXITCODE
 if($available -eq '1'){
  & $cli db lint --db-url $url --schema public --level warning --fail-on error --output-format json *> (Join-Path $nativeRoot 'database-lint.log')
  $lintExit=$LASTEXITCODE
  $lintStatus='EXECUTED'
 }else{
  $lintExit=$null;$lintStatus='NOT_RUN_PLPGSQL_CHECK_UNAVAILABLE_NO_INSTALL'
 }
 [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');target='owned 127.0.0.1:55438/profile_budget_new_20261029';advisorsExitCode=$advisorExit;lintStatus=$lintStatus;lintExitCode=$lintExit;plpgsqlCheckAvailable=[int]$available;installedAnything=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-receipt.json') -Encoding utf8
 Get-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-receipt.json')
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'advisors-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
