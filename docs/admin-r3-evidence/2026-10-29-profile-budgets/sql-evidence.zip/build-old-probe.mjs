import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
const repo=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map`;
const out=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\work\profile-budget-sql-native`;
const sha=value=>createHash('sha256').update(value).digest('hex');
const originalBootstrap=fs.readFileSync(path.resolve(out,'../site-copy-sql-native/fixture.sql'),'utf8');
const start=originalBootstrap.indexOf('create schema auth;');
const end=originalBootstrap.indexOf('create table public.categories (');
const auditStart=originalBootstrap.indexOf('create table public.admin_audit_log (');
const auditEnd=originalBootstrap.indexOf('\n);',auditStart)+4;
if(start<0||end<start||auditStart<0||auditEnd<auditStart)throw Error('Known existing synthetic bootstrap not found');
const sources=[];
const read=file=>{const bytes=fs.readFileSync(path.join(repo,file));const target=path.join(out,'sources',file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes);sources.push({file,sha256:sha(bytes)});return bytes.toString('utf8');};
const oldBase=read('supabase/migrations/20260901_zz_translation_operations.sql');
const oldRuntime=read('supabase/migrations/20260901_zz_translation_operations_runtime.sql');
const bootstrap=originalBootstrap.slice(start,end)+'\n'+originalBootstrap.slice(auditStart,auditEnd);
const test=`
create table public.profile_budget_probe_receipts(label text primary key,value jsonb not null);
grant select,insert on public.profile_budget_probe_receipts to authenticated;
insert into auth.users(id) values ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'),('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb');
insert into public.staff_memberships(user_id,role) values ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','owner');
set role authenticated;
select set_config('request.jwt.claim.sub','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',false);
do $probe$
declare kind text; prefix text; cap integer; budget jsonb; cursor jsonb; job uuid; returned jsonb;
  before_count integer; rejected_constraint text;
begin
  foreach kind in array array['literary_work','writer','country'] loop
    prefix:=case kind when 'literary_work' then 'library' when 'writer' then 'writer' else 'country' end;
    cap:=case kind when 'literary_work' then 4 when 'writer' then 3 else 2 end;
    budget:=jsonb_build_object('version',1,'attempts',1,'providerCalls',1,'maxAttempts',cap,'maxProviderCalls',cap*4,
      'elapsedMs',300000,'deadlineMs',300000,'stopped',false,'stopReason','deadline');
    cursor:=jsonb_build_object(prefix||'Cursor',1,prefix||'Budget',budget);
    select count(*) into before_count from public.translation_jobs;
    begin
      perform public.record_translation_sync_run(kind,'cloudflare',jsonb_build_array(jsonb_build_object('entityType',kind,'entityId','budget-probe-'||kind)),
        '[{"status":"dead_letter","errorCode":"translation_operation_stopped"}]'::jsonb,cursor);
      raise exception 'Expected the original constraint to reject translation_operation_stopped';
    exception when check_violation then
      get stacked diagnostics rejected_constraint=constraint_name;
      assert rejected_constraint in ('translation_job_items_last_error_code_check','translation_job_attempts_error_code_check');
      insert into public.profile_budget_probe_receipts values ('old-stopped-rejected-'||kind,jsonb_build_object('sqlstate','23514','constraint',rejected_constraint));
    end;
    assert (select count(*) from public.translation_jobs)=before_count,'Failed record must roll back its new job';
    job:=public.record_translation_sync_run(kind,'cloudflare',jsonb_build_array(jsonb_build_object('entityType',kind,'entityId','budget-probe-'||kind)),
      '[{"status":"dead_letter","errorCode":"provider_request_failed"}]'::jsonb,cursor);
    returned:=public.get_translation_job_resume(job);
    assert returned->'resumeCursor'=cursor,'Operational budget JSON must round trip exactly';
    assert returned->>'kind'=kind and returned->>'status'='failed';
    assert not ((returned->'resumeCursor') ?| array['source','sourceSnapshot','payload','SOURCE_DATA','DRAFT_TRANSLATION']);
    insert into public.profile_budget_probe_receipts values ('old-allowed-roundtrip-'||kind,returned);
  end loop;
end;
$probe$;
select set_config('request.jwt.claim.sub','bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',false);
do $probe$
declare item record;
begin
  begin
    perform public.record_translation_sync_run('writer','cloudflare','[{"entityType":"writer","entityId":"blocked"}]'::jsonb,
      '[{"status":"dead_letter","errorCode":"provider_request_failed"}]'::jsonb,'{}'::jsonb);
    raise exception 'Expected nonstaff denial';
  exception when insufficient_privilege then
    insert into public.profile_budget_probe_receipts values ('old-nonstaff-record-denied','{"sqlstate":"42501"}'::jsonb);
  end;
  for item in select value from public.profile_budget_probe_receipts where label like 'old-allowed-roundtrip-%' loop
    assert public.get_translation_job_resume((item.value->>'id')::uuid) is null,'Nonstaff RLS cannot read a job receipt';
  end loop;
  insert into public.profile_budget_probe_receipts values ('old-nonstaff-resume-denied','{"result":null}'::jsonb);
end;
$probe$;
reset role;
do $probe$
begin
  assert not has_function_privilege('anon','public.record_translation_sync_run(text,text,jsonb,jsonb,jsonb)','EXECUTE');
  assert not has_function_privilege('anon','public.get_translation_job_resume(uuid)','EXECUTE');
  assert (select count(*) from public.translation_jobs)=3;
  assert (select count(*) from public.translation_job_items)=3;
  assert (select count(*) from public.translation_job_attempts)=3;
  assert to_regprocedure('public.profile_translation_budget_ready()') is null;
end;
$probe$;
select jsonb_build_object('oldChecks',jsonb_object_agg(label,value)) from public.profile_budget_probe_receipts;
select conname,pg_get_expr(conbin,conrelid) from pg_constraint where conname in
  ('translation_job_items_last_error_code_check','translation_job_attempts_error_code_check') order by conname;
`;
const sql=['\\set ON_ERROR_STOP on','\\pset format unaligned','\\pset tuples_only on',bootstrap,oldBase,oldRuntime,test].join('\n');
fs.writeFileSync(path.join(out,'old-fixture.sql'),sql);
fs.writeFileSync(path.join(out,'old-source-manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),sources,bootstrap:{kind:'Existing isolated synthetic Auth/staff/audit fixture excerpts',sha256:sha(bootstrap)},fixtureSha256:sha(sql)},null,2));
console.log(JSON.stringify({sources:sources.length,fixtureSha256:sha(sql),out}));
