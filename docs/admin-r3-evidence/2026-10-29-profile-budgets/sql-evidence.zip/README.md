# Profile translation budgets: native SQL proof

This archive verifies a narrow PostgreSQL compatibility and access contract.
It does not claim production migration, managed Auth/PostgREST, browser or complete
M07/R3 acceptance. No provider, deployment or real-user service was contacted.

## Observed BEFORE and AFTER

The actual two original Translation Operations migrations reject
`translation_operation_stopped` with SQLSTATE **23514** on all three profile kinds.
The failed RPC rolls back its new job; an existing allowed error code round-trips
the extra `libraryBudget`, `writerBudget` and `countryBudget` metadata correctly.
Nonstaff recording is denied and RLS hides resume receipts.

After applying the new additive migration in another fresh disposable database,
the maintained fixture passes **ten result groups**:

- All three stopped outcomes persist the new code in both existing error columns
  and round-trip exact operational budget JSON through the real record/resume RPCs.
- All nine previous error codes remain accepted in both tables. Null success
  remains supported; an unknown code still fails and leaves no orphan job.
- Readiness is strict true for a current staff actor, false for either
  unvalidated/rejecting guard and false when either required RPC or its execute
  permission is unavailable. Merely mentioning the stop code is insufficient.
- Nonstaff and missing actors receive **42501**, anonymous/service-role execute
  grants are absent, and the service-only lease API is not widened.
- The readiness function is stable, uses invoker permissions and an empty search
  path. Its actual stored function body exactly matches the migration body.

The original two migration files are byte-unchanged. The new migration was created
by Supabase CLI **2.120.0** after its help was read. Source manifests bind all four
SQL files: two original migrations, the additive migration and maintained fixture.

## Results that are not green

Security advisors exit **1** for one deliberately local fixture receipt table,
`public.profile_budget_fixture_results`, which has no RLS. That table belongs to
the synthetic fixture and is not created by the production migration. There are
**no findings for the new readiness function**. The raw finding is retained; this
is not reported as a passing full security-advisor run.

Database lint is **NOT_RUN** because the portable native server has no available
`plpgsql_check` extension. No extension or software was installed to obtain a
green result. Native execution still compiles and exercises the function and its
positive/negative guards.

## Artifacts and replay

`native-summary.json` is the concise result map. Raw psql output, native envelopes,
stored function metadata, CLI/diagnostic receipts and all three owned-process
cleanup receipts remain alongside it. `sources/` contains exact verified SQL
bytes; the hash manifest excludes only itself. The adjacent archive manifest
records ZIP SHA256 and readback verification.

`old-fixture.sql` and `new-fixture.sql` are self-contained SQL compositions with
the same existing synthetic Auth/staff/audit bootstrap and actual migration SQL.
Run each only in a separate **fresh, owned, disposable PostgreSQL 17 database**,
with the synthetic `anon`, `authenticated` and `service_role` roles already
prepared. They are not production scripts. The new composition includes the
maintained repository fixture unchanged.

The captured PowerShell wrappers are machine-specific instrumentation: they
check the exact owned data directory, listener, PID and database name, refuse to
overwrite a pre-existing probe database, and stop only their own postmaster in a
finally block. Adapt paths for another machine while retaining those ownership
guards. No database data directory, native binary, credentials, auth sessions or
CLI home directory is packaged.

All three local postmasters stopped successfully. No PID file, process or
listener on port 55438 remained after cleanup. No Windows service was created.

## Limits

Auth, staff memberships and audit dependencies are synthetic. Real job tables,
RLS/ACL, record/resume RPCs, constraints and the new capability SQL execute in
PostgreSQL **17.11**. Managed GoTrue/PostgREST, deployment schema/ledger and real
authenticated application flows require separate verification.

Readiness intentionally recognizes exact canonical validated allowlists. A
semantically different custom guard fails closed rather than granting paid-work
admission from a substring match. Resume metadata produced by the tested callers
contains operational fields only; this archive does not claim that arbitrary
staff-supplied JSON is prevented by the pre-existing generic RPC schema.
