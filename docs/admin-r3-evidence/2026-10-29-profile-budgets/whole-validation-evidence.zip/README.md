# Whole-admin validation for the profile-budget increment

Final200-file suite and five gates execute on the final frozen source fingerprint
recorded in final/validation-summary.json. Six inherited historical M02 fixture
errors remain FAIL. The readonly text gate remains the exact41-file baseline
FAIL; four other gates pass. No skip or replacement BEFORE was introduced.

diagnostics/v1 preserves the earlier broad run, initial Windows mkdir EPERM,
the new test-only ProcessEnv type error and unsuccessful build retry. A single
TypeScript assertion fixes that error without changing emitted JavaScript;
its exact proof and fresh focused tests are separate versioned evidence.
The final V2 full suite and all gates repeat after the correction.

Native SQL, paired runtime tests and the next failing provider-admission BEFORE
capture are separate archives, hashed in final/validation-summary.json. The next
BEFORE defect is not acceptance PASS. No managed/live service, paid provider,
production release or full26-module/230-criterion acceptance is claimed.

The supplied runners require the locked repository dependencies and contain
historical absolute workspace paths. Adapt paths deliberately, keep the safe
child environment and use fresh output labels when replaying. Verify internal
hashes before extracting into an empty scratch directory. Credentials, caches,
dependencies, generated-byte backups and native database binaries/data are absent.
