from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, difflib, datetime

work = Path(__file__).resolve().parent
repo = work.parent / 'probpera-literary-map'
out = work / 'profile-budget-current-evidence-typefix.zip'
assert not out.exists(), 'Do not replace an existing evidence artifact'
sha = lambda b: hashlib.sha256(b).hexdigest()
members = {}
def add(name, file):
    data = Path(file).read_bytes()
    assert name not in members
    members[name] = data
def generated(name, value):
    assert name not in members
    members[name] = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf8')
def tree(prefix, directory, predicate=lambda _: True):
    directory = Path(directory)
    for file in sorted(directory.rglob('*')):
        if file.is_file() and predicate(file.relative_to(directory)):
            add(prefix + '/' + file.relative_to(directory).as_posix(), file)

specs = [
 ('writer','m07-profile-budgets-before-20261029-sol','writer-conflict-budget-acceptance.cjs','ee8b3c97d6db0db81efd67f8edf7c26cc4ff05c4507ba37b3e7ca6a0209fdc8e'),
 ('library','m07-library-budgets-before-20261029-sol','library-conflict-budget-acceptance.cjs','e442438f2c234ca1da007d7633ce49d3363c2eb860f4287418fa2c7f3c1d2a51'),
 ('country','m07-country-budgets-before-20261029-sol','country-conflict-budget-acceptance.cjs','2f5ad953c2d34a0c021e70da28e25ceb53df38fca5222837629b6c4bb4d914f8'),
]
transport = []
archives = []
for kind, folder, original, expected in specs:
    archive = work / (folder + '.zip')
    add('original-v1/' + archive.name, archive)
    with ZipFile(archive) as z:
        assert z.testzip() is None
        raw = z.read(original)
        assert sha(raw) == expected
        manifest = json.loads(z.read('sha256-manifest.json').decode('utf8'))
        # The original writer/library/country manifests use a files array.
        entries = manifest['files'] if isinstance(manifest, dict) else manifest
        for item in entries:
            filename = item.get('path', item.get('file'))
            assert sha(z.read(filename)) == item['sha256'], filename
        archives.append({'kind':kind,'archive':archive.name,'sha256':sha(archive.read_bytes()),'members':len(z.namelist()),'verifiedInternalFiles':len(entries),'v1FixtureSha256':expected})
    before = (work / folder / original).read_bytes()
    assert sha(before) == expected
    current_file = repo / 'apps/admin/lib/fixtures' / (kind + '-batch-budget-cap.cjs')
    after = current_file.read_bytes()
    before_text = before.decode('utf8').replace('\r\n','\n')
    after_text = after.decode('utf8').replace('\r\n','\n')
    if kind == 'library':
        reverted = after_text.replace("    else if (table === 'profile_translation_budget_ready') data = true;\n",'',1)
    else:
        reverted = after_text.replace("    if (table === 'profile_translation_budget_ready') data = true;\n    else if (table === 'get_premium_translation_working_draft')", "    if (table === 'get_premium_translation_working_draft')",1)
    assert reverted == before_text, kind
    # Reconstructed original bytes also match, preserving original line endings.
    restored_bytes = reverted.replace('\n','\r\n').encode('utf8') if b'\r\n' in before else reverted.encode('utf8')
    assert restored_bytes == before
    patch = ''.join(difflib.unified_diff(before_text.splitlines(True), after_text.splitlines(True),fromfile=original,tofile=current_file.relative_to(repo).as_posix()))
    members['transport-only/' + kind + '-v1-v2.diff'] = patch.encode('utf8')
    transport.append({'kind':kind,'originalV1Sha256':sha(before),'maintainedV2Sha256':sha(after),'exactOriginalBytesRestoredAfterRemovingReadinessTrueTransportBranch':True,'originalInputsAssertionsAndLoadedAlgorithmsUnchanged':True})

legacy = []
for name in ['country-profile-machine-review.integration.test.ts','literary-work-machine-review.integration.test.ts','writer-biography-machine-review.cjs']:
    before_file = work / 'profile-budget-legacy-fixture-before' / name
    after_file = repo / 'apps/admin/lib' / ('fixtures/' + name if name.endswith('.cjs') else name)
    before, after = before_file.read_bytes(), after_file.read_bytes()
    a, b = before.decode('utf8').replace('\r\n','\n'), after.decode('utf8').replace('\r\n','\n')
    if name.startswith('country'):
        reverted = b.replace('    if (name === "profile_translation_budget_ready") return { data: true, error: null };\n','',1)
    else:
        quote = "'" if name.endswith('.cjs') else '"'
        prefix = '      if (table === ' + quote + 'profile_translation_budget_ready' + quote + ') data = true;\n      else if '
        reverted = b.replace(prefix,'      if ',1)
    assert reverted == a, name
    add('legacy-readiness-only/before/' + name, before_file)
    add('legacy-readiness-only/after/' + name, after_file)
    members['legacy-readiness-only/' + name + '.diff'] = ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True),fromfile='before/'+name,tofile='after/'+name)).encode('utf8')
    legacy.append({'file':after_file.relative_to(repo).as_posix(),'beforeSha256':sha(before),'afterSha256':sha(after),'onlySemanticChange':'Synthetic SDK transport returns true for profile_translation_budget_ready; assertions and domain/provider algorithms unchanged.','exactLogicalOriginalRestored':True})

tree('v2-paired-runs',work/'m07-profile-budget-contract-v2')
tree('current-final',work/'m07-profile-budget-current-final-typefix',lambda rel: not (len(rel.parts)>1 and rel.parts[0]=='current-controls' and rel.parts[1].startswith('case-')))
tree('legacy-focused251',work/'profile-budget-final-validation-v1',lambda rel: rel.name in {'focused-tests-receipt.json','focused-tests.log','focused-tests.raw.json'})
for script in ['run-profile-budget-pairs.cjs','run-profile-budget-current-final.cjs','m07-profile-budget-v2-transport-change.json']:
    add('runners/' + script, work/script)
add('runners/package-profile-budget-evidence-typefix.py',Path(__file__))
add('runners/run-profile-budget-current-typefix.cjs',work/'run-profile-budget-current-typefix.cjs')
add('runners/fix-profile-budget-env-type.cjs',work/'fix-profile-budget-env-type.cjs')
tree('type-only-correction',work/'m07-profile-budget-env-type-fix')
generated('transport-only/proof.json',{'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'v1UnchangedArchives':archives,'maintainedV2':transport,'rootLegacyReadinessOnly':legacy})
summary=json.loads((work/'m07-profile-budget-current-final-typefix/summary.json').read_text(encoding='utf8'))
generated('summary.json',{'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'current':summary,'pairedBefore':json.loads((work/'m07-profile-budget-contract-v2/before-summary.json').read_text(encoding='utf8')),'pairedCurrent':json.loads((work/'m07-profile-budget-contract-v2/current-summary.json').read_text(encoding='utf8')),'boundaries':['Actual root actions, helpers, validators, premium translation/review/repair pipeline, DTO adapters, budget and installed SDK execute.','Synthetic Auth, catalog/database transport, Cloudflare AI response transport, and injected budget clock only. No domain/helper algorithm stub; no real billing, network, DB, browser or production acceptance claim.','V1 original captures and target FAILs retained. V2 changes only the readiness-true transport branch; V2 BEFORE again fails all four original target assertions per domain. CURRENT-only extra scenarios are additional acceptance controls, not historical BEFORE tests.','No full broad-suite result is claimed in this artifact. SQL readiness/check-constraint compatibility is verified separately by the SQL owner.']})
members['README.md'] = '''# Profile translation budget regression evidence after type-only correction

One `as NodeJS.ProcessEnv` type assertion resolves the augmented ProcessEnv
compile error. TypeScript5.9.3 emits exactly identical JavaScript before/after;
the proof, both source files and both emitted outputs are in
`type-only-correction/`. Inputs, assertions, allowlist and production files are
unchanged. The fresh final commands include admin TypeScript exit0 as well as
39/39 maintained tests and 33/33 standalone CURRENT controls. Prior runtime ZIP
63bad20db74b9a90a13427798fd313b9ad06a92a8c5abdc0bceda4995a44d9fd
is retained unchanged as evidence of the source before this type correction.

The final maintained suite passed 39/39 tests. Its 33 CURRENT scenarios execute
real writer, book and country actions/helpers against synthetic transport and a
deterministic budget clock. Source hashes and command terminal receipts are in
`current-final/`. The 26-file source fingerprint is the executed test graph plus
the five new maintained fixture/test files, not the entire repository.

The three SAME fixtures compare the same original conflict inputs. V2 BEFORE
retains four target failures per domain: writer/book five attempts and ten calls;
country three attempts and six calls. V2 CURRENT passes those assertions with
writer 3/6, book 4/8 and country 2/4 attempts/calls, preserving canonical authored
data and making no publication request. Caps are 3/12, 4/16 and 2/8 respectively;
the ordinary conflict scenario uses two passes per admitted attempt.

`original-v1/` contains unchanged original archives, including genuine captured
BEFORE graphs, original bytes/receipts, failures, hashes and scope notes. V2 adds
only a boolean-true response for the new readiness RPC at the SDK transport
boundary; `transport-only/proof.json` verifies exact V1 byte restoration after
removing that branch. All original positive inputs, target assertions, races and
algorithms remain intact. Root's three existing test fixtures received the same
readiness-only transport admission; their before/after bytes and diffs are in
`legacy-readiness-only/`. The separate fresh 251-test result is retained under
`legacy-focused251/`; it is not counted as part of maintained39.

CURRENT controls cover missing/false/malformed readiness (zero paid work), cheap
manual/current/pending guards, repair and retry reservations, one shared call
cap, deadline before first request with cursor retained, partial started request
with cursor advanced once, completed private output retained after deadline,
and a rejected run acknowledgement without claiming a saved cursor. Missing or
false readiness means migration_required; malformed readiness means database
read_failed. Warm-up calls constructing valid current/pending records are
separately retained and excluded only from measured operation windows.

Only Auth/catalog/PostgREST transport, Cloudflare response transport and the
budget factory clock are controlled. Actual helpers, premium pipeline and SDK
execute. Outputs are synthetic, credentials are not inherited by child fixtures,
uncontrolled fetch is denied, and no real paid/provider/production call occurs.
This artifact does not establish all M07 or R3 criteria, native SQL deployment,
browser behavior, real billing or a full repository test PASS. Budgets here are
per invocation; cross-run/global accounting and restart uncertainty remain
uncovered. No claim of durable cross-run spending limits is made.

Replay CURRENT from the repository with Node24 and its locked dependencies:
`node node_modules/vitest/vitest.mjs run apps/admin/lib/profile-library-batch-budgets.integration.test.ts --maxWorkers=2`
The maintained inputs are committed repository fixtures and default to current
root sources. Historical replay requires extracting each original archive into
its named parent-work folder and choosing a fresh output directory; original
README files document environment path overrides. `runners/` retains the exact
commands/orchestration, whose original parent-work placement is recorded by
receipts. Historical mode prose inside the original acceptance scripts is
preserved literally; actual sourceRoot, hashes and target results identify each
execution. No historical failure is reclassified as an acceptance PASS.
'''.encode('utf8')
generated('sha256-manifest.json',{'files':[{'path':name,'sha256':sha(data),'bytes':len(data)} for name,data in sorted(members.items())]})
with ZipFile(out,'x',compression=ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):
        z.writestr(name,data)
with ZipFile(out) as z:
    assert z.testzip() is None
    manifest=json.loads(z.read('sha256-manifest.json').decode('utf8'))
    for row in manifest['files']:
        assert sha(z.read(row['path']))==row['sha256']
receipt={'path':str(out),'sha256':sha(out.read_bytes()),'bytes':out.stat().st_size,'members':len(members),'verifiedPayloadFiles':len(manifest['files']),'currentSourceAggregate':summary['sourceAggregateSha256'],'maintainedTests':summary['maintainedTests'],'currentScenarios':summary['currentScenarios']}
(work/'profile-budget-current-evidence-typefix-manifest.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
print(json.dumps(receipt))
