const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {spawnSync}=require('node:child_process');const assert=require('node:assert/strict');
const work=__dirname,repo=path.resolve(work,'../probpera-literary-map'),mode=process.argv[2];
assert.ok(['before','current'].includes(mode));const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const base=path.join(work,'m07-profile-budget-contract-v2');fs.mkdirSync(base,{recursive:true});
const specs=[['writer','PROFILE_BUDGET','m07-profile-budgets-before-20261029-sol','writer-conflict-run'],['library','LIBRARY_BUDGET','m07-library-budgets-before-20261029-sol','library-conflict-run'],['country','COUNTRY_BUDGET','m07-country-budgets-before-20261029-sol','country-conflict-run']];
const allow=/^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i;
const results=[];
for(const[kind,prefix,folder,capture]of specs){
 const script=path.join(repo,'apps/admin/lib/fixtures',kind+'-batch-budget-cap.cjs');
 const sourceRoot=mode==='current'?repo:path.join(work,folder,capture,'sources');
 if(mode==='before'){
  const original=JSON.parse(fs.readFileSync(path.join(work,folder,capture,'manifest.json'),'utf8'));
  for(const entry of original.sources)assert.equal(sha(fs.readFileSync(path.join(sourceRoot,entry.module))),entry.sha256);
 }
 const output=path.join(base,kind+'-'+mode);assert.equal(fs.existsSync(output),false);
 const env=Object.fromEntries(Object.entries(process.env).filter(([k])=>allow.test(k)));
 Object.assign(env,{[prefix+'_REPO']:repo,[prefix+'_SOURCE_ROOT']:sourceRoot,[prefix+'_OUTPUT_ROOT']:output,CI:'1',NEXT_TELEMETRY_DISABLED:'1',NO_COLOR:'1'});
 const startedAt=new Date().toISOString();const child=spawnSync(process.execPath,[script],{cwd:repo,env,encoding:'utf8',timeout:30000,maxBuffer:16*1024*1024,windowsHide:true});
 const stdout=path.join(base,kind+'-'+mode+'.stdout.json'),stderr=path.join(base,kind+'-'+mode+'.stderr.log');fs.writeFileSync(stdout,child.stdout||'');fs.writeFileSync(stderr,child.stderr||'');
 const receipt={kind,mode,executable:process.execPath,args:[script],cwd:repo,sourceRoot,startedAt,finishedAt:new Date().toISOString(),exitCode:child.status,signal:child.signal,error:child.error?String(child.error):null,fixtureSha256:sha(fs.readFileSync(script)),stdoutSha256:sha(Buffer.from(child.stdout||'')),stderrSha256:sha(Buffer.from(child.stderr||'')),environment:'OS paths only, explicit current/captured source root and fresh work output; no credentials inherited.'};
 fs.writeFileSync(path.join(base,kind+'-'+mode+'-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
 assert.equal(child.error,undefined);assert.equal(child.stderr,'');const report=JSON.parse(child.stdout);
 const targets=report.checks.filter(c=>c.category==='target'),controls=report.checks.filter(c=>c.category!=='target');
 assert.ok(controls.every(c=>c.pass));assert.equal(targets.length,4);assert.equal(targets.filter(c=>!c.pass).length,mode==='before'?4:0);assert.equal(child.status,mode==='before'?1:0);assert.equal(report.unchanged,true);
 results.push({kind,mode,fixtureSha256:receipt.fixtureSha256,attempts:report.expensiveAttempts,providerCalls:report.providerCalls,conflicts:report.conflicts,cursor:report.result.resumeCursor,targetFailures:targets.filter(c=>!c.pass).length,executionAndPreservationPass:true});
}
fs.writeFileSync(path.join(base,mode+'-summary.json'),JSON.stringify({mode,results},null,2)+'\n');console.log(JSON.stringify({mode,results}));
