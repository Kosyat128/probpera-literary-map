const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const assert = require('node:assert/strict');
const repo = path.resolve(__dirname, '../probpera-literary-map');
const out = path.join(__dirname, 'm07-profile-budget-current-final');
assert.equal(fs.existsSync(out), false, 'Final evidence must use a fresh directory');
fs.mkdirSync(out, { recursive: true });
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const files = new Set(['apps/admin/lib/profile-library-batch-budgets.integration.test.ts', ...['writer-batch-budget-cap.cjs','library-batch-budget-cap.cjs','country-batch-budget-cap.cjs','profile-library-budget-controls.cjs'].map(name=>'apps/admin/lib/fixtures/'+name)]);
for (const kind of ['writer','library','country']) for (const row of JSON.parse(fs.readFileSync(path.join(__dirname,'m07-profile-budget-contract-v2',kind+'-current','manifest.json'),'utf8')).sources) files.add(row.module);
const snapshot = () => [...files].sort().map(file=>({file,sha256:sha(fs.readFileSync(path.join(repo,file)))}));
const before = snapshot();
fs.writeFileSync(path.join(out,'source-before.json'),JSON.stringify(before,null,2)+'\n');
for (const row of before) { const target=path.join(out,'sources',row.file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(path.join(repo,row.file),target); }
const allow=/^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i;
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>allow.test(key)));
const temp=path.join(__dirname,'m07-budget-vitest-temp');fs.mkdirSync(temp,{recursive:true});
Object.assign(env,{TEMP:temp,TMP:temp,CI:'1',NO_COLOR:'1',NEXT_TELEMETRY_DISABLED:'1'});
const envFilePresence=['.env','.env.local','.env.development','.env.development.local','apps/admin/.env','apps/admin/.env.local','apps/admin/.env.production','apps/admin/.env.production.local'].map(file=>({file,present:fs.existsSync(path.join(repo,file))}));
assert.ok(envFilePresence.every(row=>!row.present));
function run(label,args,extra={}){
 const startedAt=new Date().toISOString();const result=spawnSync(process.execPath,args,{cwd:repo,env:{...env,...extra},encoding:'utf8',timeout:60000,maxBuffer:32*1024*1024,windowsHide:true});
 fs.writeFileSync(path.join(out,label+'.stdout.log'),result.stdout||'');fs.writeFileSync(path.join(out,label+'.stderr.log'),result.stderr||'');
 const receipt={label,executable:process.execPath,nodeVersion:process.version,args,cwd:repo,startedAt,finishedAt:new Date().toISOString(),exitCode:result.status,signal:result.signal,error:result.error?String(result.error):null,stdoutSha256:sha(Buffer.from(result.stdout||'')),stderrSha256:sha(Buffer.from(result.stderr||'')),environmentKeys:Object.keys({...env,...extra}).sort(),environmentDescription:'System paths only; controlled workspace TEMP/TMP; explicit test flags/output path. No secret values captured or inherited.',envFilePresence};
 fs.writeFileSync(path.join(out,label+'-receipt.json'),JSON.stringify(receipt,null,2)+'\n');
 assert.equal(result.error,undefined);assert.equal(result.status,0,result.stderr);return result;
}
run('maintained39',['node_modules/vitest/vitest.mjs','run','apps/admin/lib/profile-library-batch-budgets.integration.test.ts','--maxWorkers=2','--reporter=json','--outputFile='+path.join(out,'maintained39.raw.json')]);
const controls=run('current33',['apps/admin/lib/fixtures/profile-library-budget-controls.cjs'],{PROFILE_LIBRARY_BUDGET_OUTPUT_ROOT:path.join(out,'current-controls')});
const report=JSON.parse(controls.stdout), tests=JSON.parse(fs.readFileSync(path.join(out,'maintained39.raw.json'),'utf8'));
assert.equal(tests.numTotalTests,39);assert.equal(tests.numPassedTests,39);assert.equal(tests.numFailedTests,0);assert.equal(tests.numPendingTests,0);assert.equal(tests.numTodoTests,0);
assert.equal(report.checks.length,33);assert.ok(report.checks.every(check=>check.pass));assert.equal(report.currentSourceOnly,true);assert.equal(report.unchanged,true);
const after=snapshot();assert.deepEqual(after,before);fs.writeFileSync(path.join(out,'source-after.json'),JSON.stringify(after,null,2)+'\n');
const result={atUtc:new Date().toISOString(),sourceFiles:before.length,sourceAggregateSha256:sha(before.map(row=>row.file+'\0'+row.sha256+'\n').join('')),sourceDrift:[],maintainedTests:{total:39,passed:39,failed:0,pending:0,todo:0},currentScenarios:{total:33,passed:33},graphModules:report.sources.length,fixtureHashes:before.filter(row=>row.file.includes('/fixtures/')||row.file.endsWith('profile-library-batch-budgets.integration.test.ts'))};
fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
