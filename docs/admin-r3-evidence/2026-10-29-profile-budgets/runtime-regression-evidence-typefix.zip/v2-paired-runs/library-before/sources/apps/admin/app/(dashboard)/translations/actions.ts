"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";

import { ensureLiteraryWorkEnglishTranslation } from "@/lib/auto-translate-literary-work-safe";
import { ensureSiteCopyEnglishTranslation } from "@/lib/auto-translate-site-copy-private";
import { ensureWriterEnglishBiography } from "@/lib/auto-translate-writer-biography";
import { requireStaff } from "@/lib/auth";
import {
  loadEditorialCatalog,
  type EditorialCatalog,
} from "@/lib/editorial-catalog";
import { redirect } from "@/lib/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import {
  advanceBackfillCursor,
  circularBackfillIndex,
  normalizeBackfillCursor,
  translationBackfillCursorParams,
} from "@/lib/translation-backfill-cursor";
import { translationErrorCode } from "@/lib/translation-errors";
import { premiumTranslationRuntimeGate } from "@/lib/translation-runtime-gate";
import {
  recordTranslationSyncRun,
  type TranslationRunItem,
} from "@/lib/translation-run-record";

const SITE_COPY_SYSTEM_KEY = "site-copy-overrides";
const MAX_LIBRARY_TRANSLATIONS = 4;
const MAX_LIBRARY_SCAN = 60;
const MAX_WRITER_TRANSLATIONS = 3;
const MAX_WRITER_SCAN = 120;

function objectValue(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

function translationsUrl(values: Record<string, string | number | null | undefined>) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) {
    if (value !== null && value !== undefined && String(value)) {
      params.set(key, String(value));
    }
  }
  return `/translations${params.size ? `?${params}` : ""}`;
}

export async function translatePremiumLibraryBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  }
  if (!(await premiumTranslationRuntimeGate(supabase))) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "translation_not_configured" }));
  }

  const readiness = await supabase.rpc("premium_machine_translation_ready");
  if (readiness.error || readiness.data !== true) {
    redirect(
      translationsUrl({
        ...cursorParams,
        errorCode: "translation_migration_required",
      })
    );
  }

  const countResponse = await supabase
    .from("literary_work_translations")
    .select("work_id", { count: "exact", head: true })
    .eq("locale", "ru")
    .in("editorial_status", ["reviewed", "verified"]);
  if (countResponse.error) {
    redirect(
      translationsUrl({ ...cursorParams, errorCode: "database_read_failed" })
    );
  }
  const totalCandidates = countResponse.count || 0;
  const startCursor = normalizeBackfillCursor(
    cursorParams.libraryCursor,
    totalCandidates
  );

  const russianRows = totalCandidates
    ? await supabase
        .from("literary_work_translations")
        .select("work_id")
        .eq("locale", "ru")
        .in("editorial_status", ["reviewed", "verified"])
        .order("updated_at", { ascending: true })
        .range(
          startCursor,
          Math.min(startCursor + MAX_LIBRARY_SCAN - 1, totalCandidates - 1)
        )
    : { data: [], error: null };
  if (russianRows.error) {
    redirect(
      translationsUrl({ ...cursorParams, errorCode: "database_read_failed" })
    );
  }

  let translated = 0;
  let reviewPending = 0;
  let stale = 0;
  let current = 0;
  let manual = 0;
  let skipped = 0;
  let failed = 0;
  let processed = 0;
  let firstError = "";
  const runItems: TranslationRunItem[] = [];
  const uniqueWorkIds = [
    ...new Set((russianRows.data || []).map((row) => String(row.work_id))),
  ];
  for (const workId of uniqueWorkIds) {
    if (translated >= MAX_LIBRARY_TRANSLATIONS) break;
    processed += 1;
    const result = await ensureLiteraryWorkEnglishTranslation({
      supabase,
      actorId: session.user.id,
      workId,
      runtimeApproved: true,
    });
    const runState =
      result.state === "not-ready" ? "not-configured" : result.state;
    runItems.push({
      entityId: workId,
      state: runState,
      error: result.error,
      model: result.model,
    });
    if (runState === "translated") translated += 1;
    else if (runState === "review-pending") reviewPending += 1;
    else if (runState === "stale") stale += 1;
    else if (runState === "current") current += 1;
    else if (runState === "manual") manual += 1;
    else if (runState === "failed") {
      failed += 1;
      firstError = result.error || "";
      break;
    } else if (runState === "conflict") failed += 1;
    else skipped += 1;
  }
  const nextLibraryCursor = advanceBackfillCursor(
    startCursor,
    processed,
    totalCandidates
  );
  try {
    await recordTranslationSyncRun({
      supabase,
      kind: "literary_work",
      items: runItems,
      resumeCursor: { libraryCursor: nextLibraryCursor },
    });
  } catch {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_write_failed" }));
  }

  revalidatePath("/translations");
  revalidatePath("/library");
  redirect(
    translationsUrl({
      ...cursorParams,
      success: `Книги: новых машинных черновиков ${translated}, ожидают проверки ${reviewPending}, устаревших черновиков ${stale}, актуальных ${current}, ручных ${manual}, пропущено ${skipped}, ошибок ${failed}. Машинные черновики не опубликованы.`,
      errorCode: firstError ? translationErrorCode(firstError) : null,
      libraryCursor: nextLibraryCursor,
    })
  );
}

function staticWriterCandidates(editorialCatalog: EditorialCatalog) {
  const candidates: Array<{
    countryId: string;
    writerId: string;
    sourceFields: Record<string, unknown>;
  }> = [];
  for (const country of editorialCatalog.countries) {
    for (const writer of country.writers) {
      const translations = objectValue(writer.fields.biographyTranslations);
      const ru = objectValue(translations.ru);
      const en = objectValue(translations.en);
      const russianEligible =
        ru.locale === "ru" &&
        ru.method === "editorial-original" &&
        new Set(["reviewed", "verified"]).has(String(ru.status)) &&
        typeof ru.text === "string" &&
        ru.text.trim().length >= 120 &&
        Array.isArray(ru.sources) &&
        ru.sources.length > 0;
      const staticManualEnglish =
        en.locale === "en" &&
        en.method !== "machine-translation" &&
        new Set(["reviewed", "verified"]).has(String(en.status));
      if (russianEligible && !staticManualEnglish) {
        candidates.push({
          countryId: country.id,
          writerId: writer.id,
          sourceFields: writer.fields,
        });
      }
    }
  }
  return candidates;
}

export async function translatePremiumWriterBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  }
  if (!(await premiumTranslationRuntimeGate(supabase))) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "translation_not_configured" }));
  }

  const editorialCatalog = await loadEditorialCatalog();
  const candidates = staticWriterCandidates(editorialCatalog);
  const startCursor = normalizeBackfillCursor(
    cursorParams.writerCursor,
    candidates.length
  );
  let translated = 0;
  let reviewPending = 0;
  let stale = 0;
  let current = 0;
  let manual = 0;
  let skipped = 0;
  let failed = 0;
  let processed = 0;
  let firstError = "";
  const runItems: TranslationRunItem[] = [];
  const scanLimit = Math.min(MAX_WRITER_SCAN, candidates.length);

  for (let step = 0; step < scanLimit; step += 1) {
    if (translated >= MAX_WRITER_TRANSLATIONS) break;
    const candidate = candidates[
      circularBackfillIndex(startCursor, step, candidates.length)
    ];
    if (!candidate) break;
    processed += 1;
    const result = await ensureWriterEnglishBiography({
      supabase,
      actorId: session.user.id,
      ...candidate,
      runtimeApproved: true,
    });
    const runState = result.state === "not-ready" ? "failed" : result.state;
    runItems.push({
      entityId: `${candidate.countryId}/${candidate.writerId}`,
      state: runState,
      error: result.error,
      model: result.model,
    });
    if (runState === "translated") translated += 1;
    else if (runState === "review-pending") reviewPending += 1;
    else if (runState === "stale") stale += 1;
    else if (runState === "current") current += 1;
    else if (runState === "manual") manual += 1;
    else if (runState === "failed") {
      failed += 1;
      firstError = result.error || "";
      break;
    } else if (runState === "conflict") failed += 1;
    else skipped += 1;
  }
  const nextWriterCursor = advanceBackfillCursor(
    startCursor,
    processed,
    candidates.length
  );
  try {
    await recordTranslationSyncRun({
      supabase,
      kind: "writer",
      items: runItems,
      resumeCursor: { writerCursor: nextWriterCursor },
    });
  } catch {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_write_failed" }));
  }

  revalidatePath("/translations");
  revalidatePath("/editorial-database");
  redirect(
    translationsUrl({
      ...cursorParams,
      success: `Биографии: новых машинных черновиков ${translated}, ожидают проверки ${reviewPending}, устаревших черновиков ${stale}, актуальных ${current}, ручных ${manual}, пропущено ${skipped}, ошибок ${failed}. Машинные черновики не опубликованы.`,
      errorCode: firstError ? translationErrorCode(firstError) : null,
      writerCursor: nextWriterCursor,
    })
  );
}

export async function translatePremiumSiteCopyBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  }
  if (!(await premiumTranslationRuntimeGate(supabase))) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "translation_not_configured" }));
  }
  const response = await supabase.from("homepage_blocks").select("id,settings,updated_at")
    .contains("settings", { systemKey: SITE_COPY_SYSTEM_KEY })
    .order("updated_at", { ascending: false }).limit(2);
  const rows = z.array(z.object({ id: z.string().uuid(), settings: z.record(z.string(), z.unknown()),
    updated_at: z.string().datetime({ offset: true }) })).max(1).safeParse(response.data);
  if (response.error || !rows.success) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_read_failed" }));
  }
  const existing = rows.data[0];
  if (!existing) {
    redirect(translationsUrl({ ...cursorParams,
      success: "Тексты сайта: русских CMS-переопределений для перевода пока нет." }));
  }
  const result = await ensureSiteCopyEnglishTranslation({ supabase, actorId: session.user.id,
    blockId: existing.id, runtimeApproved: true });
  try {
    await recordTranslationSyncRun({ supabase, kind: "site_copy", items: [{ entityId: existing.id,
      state: result.state === "not-ready" ? "not-configured" : result.state,
      error: result.error, model: result.model }] });
  } catch {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_write_failed" }));
  }
  revalidatePath("/translations");
  revalidatePath("/site-copy");
  if (result.state === "failed" || result.state === "not-ready" || result.state === "not-configured" ||
      result.state === "conflict") {
    redirect(translationsUrl({ ...cursorParams, errorCode: result.state === "conflict" ? "write_conflict"
      : result.state === "not-ready" ? "translation_migration_required"
        : result.state === "not-configured" ? "translation_not_configured" : translationErrorCode(result.error) }));
  }
  const success = result.state === "translated" || result.state === "review-pending"
    ? "Тексты сайта: машинный черновик сохранён и ожидает вашей проверки. Он не опубликован."
    : result.state === "stale"
      ? "Тексты сайта: сохранённый машинный черновик устарел. Проверьте или отклоните его перед новым переводом."
      : result.state === "manual" ? "Тексты сайта: ручной английский текст сохранён без изменений."
        : "Тексты сайта: новых строк для перевода нет.";
  redirect(translationsUrl({ ...cursorParams, success }));
}
