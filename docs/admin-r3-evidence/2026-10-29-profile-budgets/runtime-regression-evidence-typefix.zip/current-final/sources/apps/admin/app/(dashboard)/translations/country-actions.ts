"use server";

import { revalidatePath } from "next/cache";
import { unstable_rethrow } from "next/navigation";

import { ensureCountryEnglishProfile } from "@/lib/auto-translate-country-profile";
import { requireStaff } from "@/lib/auth";
import { loadEditorialCatalog } from "@/lib/editorial-catalog";
import { redirect } from "@/lib/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import {
  advanceBackfillCursor,
  circularBackfillIndex,
  normalizeBackfillCursor,
  translationBackfillCursorParams,
} from "@/lib/translation-backfill-cursor";
import { translationErrorCode } from "@/lib/translation-errors";
import { createTranslationOperationBudget, type TranslationOperationBudgetReason } from "@/lib/translation-operation-budget";
import { translationOperationBudgetNotice } from "@/lib/translation-operation-budget-notice";
import { profileTranslationBudgetReadiness } from "@/lib/translation-profile-budget-readiness";
import { premiumTranslationRuntimeGate } from "@/lib/translation-runtime-gate";
import {
  recordTranslationSyncRun,
  type TranslationRunItem,
} from "@/lib/translation-run-record";

const MAX_COUNTRY_TRANSLATIONS = 2;
const MAX_COUNTRY_SCAN = 30;
const MAX_COUNTRY_PROVIDER_CALLS = MAX_COUNTRY_TRANSLATIONS * 4;
const COUNTRY_OPERATION_DEADLINE_MS = 300_000;

function translationsUrl(values: Record<string, string | number | null | undefined>) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) {
    if (value !== null && value !== undefined && String(value)) {
      params.set(key, String(value));
    }
  }
  return `/translations${params.size ? `?${params}` : ""}`;
}

export async function translatePremiumCountryBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  }
  const operationBudget = createTranslationOperationBudget({
    maxAttempts: MAX_COUNTRY_TRANSLATIONS, maxProviderCalls: MAX_COUNTRY_PROVIDER_CALLS,
    deadlineMs: COUNTRY_OPERATION_DEADLINE_MS,
  });
  if (!(await premiumTranslationRuntimeGate(supabase))) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "translation_not_configured" }));
  }

  const budgetReadinessError = await profileTranslationBudgetReadiness(supabase);
  if (budgetReadinessError) redirect(translationsUrl({ ...cursorParams, errorCode: budgetReadinessError }));
  const editorialCatalog = await loadEditorialCatalog();
  const candidates = editorialCatalog.countries;
  const startCursor = normalizeBackfillCursor(
    cursorParams.countryCursor,
    candidates.length
  );
  let translated = 0;
  let reviewPending = 0;
  let stale = 0;
  let current = 0;
  let manual = 0;
  let skipped = 0;
  let failed = 0;
  let processed = 0;
  let firstError = "";
  let budgetStopReason: TranslationOperationBudgetReason | null = null;
  const runItems: TranslationRunItem[] = [];
  const scanLimit = Math.min(MAX_COUNTRY_SCAN, candidates.length);

  for (let step = 0; step < scanLimit; step += 1) {
    budgetStopReason = operationBudget.exhaustedReason();
    if (budgetStopReason || translated >= MAX_COUNTRY_TRANSLATIONS || firstError) break;
    const country = candidates[
      circularBackfillIndex(startCursor, step, candidates.length)
    ];
    if (!country) break;
    const result = await ensureCountryEnglishProfile({
      supabase,
      actorId: session.user.id,
      countryId: country.id,
      sourceFields: country.fields,
      runtimeApproved: true,
      operationBudget,
    });
    if (result.budgetStop && result.budgetStop.providerCalls === 0) {
      budgetStopReason = result.budgetStop.reason;
      break;
    }
    processed += 1;
    runItems.push({
      entityId: country.id,
      state: result.state === "not-ready" ? "not-configured" : result.state,
      error: result.error,
      model: result.model,
    });
    if (result.budgetStop) {
      budgetStopReason = result.budgetStop.reason;
      failed += 1;
      firstError = result.error || "";
      break;
    }
    if (result.state === "translated") translated += 1;
    else if (result.state === "review-pending") reviewPending += 1;
    else if (result.state === "stale") stale += 1;
    else if (result.state === "current") current += 1;
    else if (result.state === "manual") manual += 1;
    else if (result.state === "failed") {
      failed += 1;
      firstError = result.error || "";
    } else if (result.state === "conflict") failed += 1;
    else skipped += 1;
  }
  const nextCountryCursor = advanceBackfillCursor(
    startCursor,
    processed,
    candidates.length
  );
  const budget = operationBudget.snapshot();
  try {
    await recordTranslationSyncRun({
      supabase,
      kind: "country",
      items: runItems,
      resumeCursor: { countryCursor: nextCountryCursor, countryBudget: { version: 1, ...budget, stopReason: budgetStopReason } },
    });
  } catch (error) {
    unstable_rethrow(error);
    redirect(translationsUrl({ ...cursorParams, errorCode: "translation_run_record_unconfirmed" }));
  }

  revalidatePath("/translations");
  revalidatePath("/editorial-database");
  redirect(
    translationsUrl({
      ...cursorParams,
      success: `Страны: новых машинных черновиков ${translated}, ожидают проверки ${reviewPending}, устаревших черновиков ${stale}, актуальных ${current}, ручных ${manual}, пропущено ${skipped}, ошибок ${failed}. Машинные черновики не опубликованы.` + translationOperationBudgetNotice(budget, budgetStopReason),
      errorCode: firstError ? translationErrorCode(firstError) : null,
      countryCursor: nextCountryCursor,
    })
  );
}
