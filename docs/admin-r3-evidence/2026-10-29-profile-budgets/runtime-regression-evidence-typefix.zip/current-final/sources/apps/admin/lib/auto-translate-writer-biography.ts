import type { SupabaseClient } from "@supabase/supabase-js";
import { unstable_rethrow } from "next/navigation";
import { z } from "zod";

import { adminEnv } from "./env";
import { premiumTranslateToEnglish } from "./premium-english-translation";
import { premiumTranslationRuntimeMetadata } from "./premium-translation-runtime";
import { translationErrorCode } from "./translation-errors";
import { premiumTranslationRuntimeGate } from "./translation-runtime-gate";
import {
  TranslationOperationBudgetError, type TranslationOperationBudget, type TranslationOperationBudgetStop,
} from "./translation-operation-budget";
import {
  PremiumTranslationDraftError, premiumTranslationCandidateOutcome,
  readPremiumTranslationWorkingDraft, samePremiumTranslationJson,
  stagePremiumTranslationWorkingDraft, writerBiographyCandidateIdentity,
  type PremiumTranslationCandidateOutcome,
} from "./premium-translation-working-draft";
import {
  assertWriterBiographyEnglishFidelity,
  isCurrentMachineWriterBiography,
  writerBiographyEnglishAutomationOwnership,
  writerBiographySourceFields,
  writerBiographySourceIdentity,
  writerBiographySourceUsages,
  type WriterBiographyProfile,
  type WriterBiographySource,
  type WriterBiographySourceField,
  type WriterBiographySourceUsage,
} from "./writer-biography-edit";

const biographyOutputSchema = z.object({
  text: z.string().trim().min(120).max(1_600),
});

const biographyJsonSchema = {
  type: "object",
  additionalProperties: false,
  required: ["text"],
  properties: { text: { type: "string", minLength: 120, maxLength: 1_600 } },
} as const;

type BiographySource = WriterBiographySource;
type BiographyProfile = WriterBiographyProfile;

type BiographyMap = Partial<Record<"ru" | "en", BiographyProfile>>;

function objectValue(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

function validSources(value: unknown): BiographySource[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((candidate) => {
    const source = objectValue(candidate);
    const provider = typeof source.provider === "string" ? source.provider.trim() : "";
    const url = typeof source.url === "string" ? source.url.trim() : "";
    const fields: WriterBiographySourceField[] = Array.isArray(source.fields)
      ? source.fields.flatMap((item) => {
          const field = typeof item === "string" ? item.trim() : "";
          return writerBiographySourceFields.includes(
            field as WriterBiographySourceField
          )
            ? [field as WriterBiographySourceField]
            : [];
        })
      : [];
    const usage =
      typeof source.usage === "string" ? source.usage.trim() : "";
    const retrievedAt =
      typeof source.retrievedAt === "string" ? source.retrievedAt.trim() : "";
    if (
      !provider ||
      !/^https:\/\//iu.test(url) ||
      !fields.length ||
      !writerBiographySourceUsages.includes(
        usage as WriterBiographySourceUsage
      ) ||
      !retrievedAt
    ) {
      return [];
    }
    return [{
      provider,
      url,
      fields,
      usage: usage as WriterBiographySourceUsage,
      retrievedAt,
      author: typeof source.author === "string" ? source.author : undefined,
      title: typeof source.title === "string" ? source.title : undefined,
      licenseName:
        typeof source.licenseName === "string" ? source.licenseName : undefined,
      licenseUrl:
        typeof source.licenseUrl === "string" ? source.licenseUrl : undefined,
    }];
  });
}

function biographyProfile(value: unknown, locale: "ru" | "en") {
  const row = objectValue(value);
  const status = row.status;
  const method = row.method;
  if (
    row.locale !== locale ||
    typeof row.text !== "string" ||
    typeof row.sourceLanguage !== "string" ||
    !new Set(["draft", "reviewed", "verified"]).has(String(status)) ||
    !new Set([
      "editorial-original",
      "human-translation",
      "machine-translation",
      "licensed-source",
    ]).has(String(method))
  ) {
    return null;
  }
  return {
    ...row,
    locale,
    text: row.text.trim(),
    sourceLanguage: row.sourceLanguage.trim(),
    status: status as BiographyProfile["status"],
    method: method as BiographyProfile["method"],
    reviewedAt: typeof row.reviewedAt === "string" ? row.reviewedAt : undefined,
    sources: validSources(row.sources),
    translationMeta: objectValue(row.translationMeta) as BiographyProfile["translationMeta"],
  } as BiographyProfile;
}

function biographyMap(value: unknown): BiographyMap {
  const source = objectValue(value);
  const ru = biographyProfile(source.ru, "ru");
  const en = biographyProfile(source.en, "en");
  return {
    ...(ru ? { ru } : {}),
    ...(en ? { en } : {}),
  };
}

export function writerBiographyTranslationSource(fields: Record<string, unknown>, writerId: string) {
  const rawTranslations = objectValue(fields.biographyTranslations);
  const translations = biographyMap(rawTranslations);
  const russian = translations.ru;
  if (!russian) return null;
  return {
    russian, english: translations.en, russianProfile: objectValue(rawTranslations.ru),
    eligible: new Set(["reviewed", "verified"]).has(russian.status) &&
      russian.method === "editorial-original" && Boolean(russian.reviewedAt) && russian.sources.length > 0,
    source: {
      writerName: writerBiographySourceIdentity(fields, writerId),
      text: russian.text, sourceLanguage: russian.sourceLanguage, sources: russian.sources,
    },
  };
}

export function writerBiographyTranslationOwnership(
  sourceFields: Record<string, unknown>, overrideFields: Record<string, unknown>
) {
  const effectiveFields = { ...sourceFields, ...overrideFields };
  const rawTranslations = objectValue(effectiveFields.biographyTranslations);
  const english = biographyProfile(rawTranslations.en, "en");
  const ownership = writerBiographyEnglishAutomationOwnership({ overrideFields, english });
  if (ownership === "tombstone") return ownership;
  // A present incomplete entry is authored/unknown, never permission to overwrite it.
  if (Object.hasOwn(rawTranslations, "en") && (!english || english.method !== "machine-translation")) return "human";
  const rawEnglish = objectValue(rawTranslations.en);
  if (Object.hasOwn(rawEnglish, "translationMeta") &&
      (!rawEnglish.translationMeta || typeof rawEnglish.translationMeta !== "object" || Array.isArray(rawEnglish.translationMeta))) {
    return "human";
  }
  return ownership;
}

function validateEnglishBiography(
  value: unknown,
  source: { writerName: string; text: string }
) {
  const parsed = biographyOutputSchema.parse(value);
  assertWriterBiographyEnglishFidelity({
    sourceText: source.text,
    englishText: parsed.text,
    writerName: source.writerName,
  });
  return parsed;
}

async function sha256(value: unknown) {
  const bytes = new TextEncoder().encode(JSON.stringify(value));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (byte) =>
    byte.toString(16).padStart(2, "0")
  ).join("");
}

export type WriterBiographyTranslationState =
  | "translated"
  | "review-pending"
  | "stale"
  | "not-ready"
  | "current"
  | "manual"
  | "skipped"
  | "not-configured"
  | "conflict"
  | "failed";

export async function ensureWriterEnglishBiography(input: {
  supabase: SupabaseClient;
  actorId: string;
  countryId: string;
  writerId: string;
  sourceFields: Record<string, unknown>;
  runtimeApproved?: boolean;
  replaceEnglishTombstone?: boolean;
  operationBudget?: TranslationOperationBudget;
}): Promise<{
  state: WriterBiographyTranslationState;
  model?: string;
  reviewerModel?: string | null;
  error?: string;
  overrideId?: string;
  budgetStop?: TranslationOperationBudgetStop;
} & Partial<PremiumTranslationCandidateOutcome>> {
  if (!adminEnv.openAiAutoTranslateProfiles) return { state: "skipped" };
  if (!input.runtimeApproved && !(await premiumTranslationRuntimeGate(input.supabase))) {
    return { state: "not-configured" };
  }

  const existingResponse = await input.supabase
    .from("writer_profile_overrides")
    .select("id,fields,updated_at")
    .eq("country_id", input.countryId)
    .eq("writer_id", input.writerId)
    .maybeSingle();
  if (existingResponse.error) {
    return { state: "failed", error: existingResponse.error.message };
  }

  const existingOverride = existingResponse.data;
  const overrideFields = objectValue(existingOverride?.fields);
  const effectiveFields = { ...input.sourceFields, ...overrideFields };
  const context = writerBiographyTranslationSource(effectiveFields, input.writerId);
  if (!context?.eligible) {
    return {
      state: "skipped",
      error: "a reviewed project-original Russian biography with provenance is required",
    };
  }
  const { russian, english, source } = context;
  const englishOwnership = writerBiographyTranslationOwnership(input.sourceFields, overrideFields);
  if (
    englishOwnership === "tombstone" &&
    !input.replaceEnglishTombstone
  ) {
    return {
      state: "skipped",
      error: "an explicit English biography tombstone is present",
      overrideId: existingOverride?.id,
    };
  }
  if (englishOwnership === "human") {
    return { state: "manual", overrideId: existingOverride?.id };
  }

  const sourceHash = await sha256(source);
  if (isCurrentMachineWriterBiography({
    russian,
    english,
    sourceHash,
    writerName: source.writerName,
  })) {
    return { state: "current", overrideId: existingOverride?.id };
  }

  let entityId: string;
  try { entityId = writerBiographyCandidateIdentity(input.countryId, input.writerId); }
  catch { return { state: "failed", error: "Invalid writer translation identity" }; }
  const sourceRevision = {
    countryId: input.countryId, writerId: input.writerId,
    overrideId: existingOverride?.id || null, overrideUpdatedAt: existingOverride?.updated_at || null,
    catalogSourceHash: await sha256(input.sourceFields), replaceEnglishTombstone: Boolean(input.replaceEnglishTombstone),
  };
  const targetRevision = { id: existingOverride?.id || null, updatedAt: existingOverride?.updated_at || null };
  // Match the JSON wire representation without changing any authored string or metadata.
  const sourceSnapshot = JSON.parse(JSON.stringify({
    ...source, russianProfile: context.russianProfile, catalogFields: input.sourceFields,
  }));
  try {
    const pending = await readPremiumTranslationWorkingDraft(input.supabase, { entityType: "writer_biography", entityId });
    if (pending) {
      if (pending.entityType !== "writer_biography" || pending.sourceHash !== sourceHash ||
          pending.sourceRevision.catalogSourceHash !== sourceRevision.catalogSourceHash ||
          !samePremiumTranslationJson(pending.sourceSnapshot, sourceSnapshot)) {
        return { state: "stale", error: "Writer source changed; the saved private candidate requires review or discard" };
      }
      if (!samePremiumTranslationJson(pending.targetRevision, targetRevision)) {
        return { state: "conflict", error: "Writer override changed after the private candidate was saved" };
      }
      return { state: "review-pending", ...premiumTranslationCandidateOutcome(pending),
        model: pending.provenance.translatorModel, reviewerModel: pending.provenance.reviewerModel,
        overrideId: existingOverride?.id };
    }
  } catch (error) {
    unstable_rethrow(error);
    return { state: "not-ready", error: "Private translation drafts are unavailable" };
  }

  const runtime = premiumTranslationRuntimeMetadata();
  const providerCallsBefore = input.operationBudget?.snapshot().providerCalls ?? 0;
  let attemptStarted = false;
  try {
    if (input.operationBudget) {
      input.operationBudget.startAttempt();
      attemptStarted = true;
    }
    const translated = await premiumTranslateToEnglish({
      source,
      schema: biographyJsonSchema,
      schemaName: "probpera_writer_biography_translation",
      validate: (value) => validateEnglishBiography(value, source),
      // A checked biography may never be published from a single model pass,
      // even when the generic premium-translation setting disables review.
      review: true,
      maxOutputTokens: 4_000,
      ...(input.operationBudget === undefined ? {} : { operationBudget: input.operationBudget }),
      domainInstructions: [
        "This is a concise factual literary biography for a world-literature encyclopedia.",
        "Preserve every biographical fact, date, institution, work and award exactly; do not infer missing facts.",
        "Use the established English form of the writer's name and institutions when unambiguous.",
        "Write 2-4 fluent sentences with an authoritative reference-work tone, not promotional copy.",
      ],
    });
    if (!translated.reviewerModel) {
      throw new Error(
        "writer biography translation did not complete the required reviewer pass"
      );
    }

    const latestResponse = existingOverride
      ? await input.supabase
          .from("writer_profile_overrides")
          .select("updated_at")
          .eq("id", existingOverride.id)
          .maybeSingle()
      : null;
    if (
      existingOverride &&
      (latestResponse?.error ||
        !latestResponse?.data ||
        latestResponse.data.updated_at !== existingOverride.updated_at)
    ) {
      return { state: "conflict", error: "writer override changed during translation" };
    }

    const saved = await stagePremiumTranslationWorkingDraft(input.supabase, {
      entityType: "writer_biography", entityId, sourceHash, sourceSnapshot, sourceRevision, targetRevision,
      payload: { text: translated.value.text },
      provenance: {
        provider: runtime.provider, translatorModel: translated.translatorModel,
        reviewerModel: translated.reviewerModel, generatedAt: new Date().toISOString(),
        translatorRequestId: translated.translatorRequestId || null,
        reviewerRequestId: translated.reviewerRequestId || null,
      },
    });

    await input.supabase.from("admin_audit_log").insert({
      actor_id: input.actorId,
      action: "writer_profile.auto_translation.staged",
      entity_type: "writer_profile",
      entity_id: entityId,
      metadata: {
        countryId: input.countryId,
        writerId: input.writerId,
        locale: "en",
        source_hash: sourceHash,
        provider: runtime.provider,
        model: translated.translatorModel,
        reviewer_model: translated.reviewerModel,
        translator_request_id: translated.translatorRequestId,
        reviewer_request_id: translated.reviewerRequestId,
        input_tokens: translated.inputTokens,
        output_tokens: translated.outputTokens,
        review_input_tokens: translated.reviewInputTokens,
        review_output_tokens: translated.reviewOutputTokens,
        working_draft_id: saved.id,
        human_review: "pending",
      },
    });

    return {
      state: "translated",
      ...premiumTranslationCandidateOutcome(saved),
      model: translated.translatorModel,
      reviewerModel: translated.reviewerModel,
      overrideId: existingOverride?.id,
    };
  } catch (error) {
    unstable_rethrow(error);
    if (input.operationBudget && error instanceof TranslationOperationBudgetError) {
      const providerCalls = input.operationBudget.snapshot().providerCalls - providerCallsBefore;
      return { state: providerCalls > 0 ? "failed" : "skipped", error: error.message,
        budgetStop: { reason: error.reason, attemptStarted, providerCalls } };
    }
    if (error instanceof PremiumTranslationDraftError && error.code === "conflict") {
      return { state: "conflict", error: error.message };
    }
    const message = error instanceof Error ? error.message : "writer biography translation failed";
    await input.supabase.from("admin_audit_log").insert({
      actor_id: input.actorId,
      action: "writer_profile.auto_translation.failed",
      entity_type: "writer_profile",
      entity_id: `${input.countryId}:${input.writerId}`,
      metadata: {
        locale: "en",
        provider: runtime.provider,
        model: runtime.model,
        reviewer_model: runtime.reviewerModel,
        error_code: translationErrorCode(message),
      },
    });
    return { state: "failed", error: message };
  }
}

export { validateEnglishBiography as validateWriterBiographyTranslationCandidate };
