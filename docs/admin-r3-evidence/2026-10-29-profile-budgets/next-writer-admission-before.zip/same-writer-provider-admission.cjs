const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const { execFileSync } = require('node:child_process');

const repo = path.resolve(process.env.PROFILE_ADMISSION_REPO || path.join(__dirname, '../../probpera-literary-map'));
const sourceRoot = path.resolve(process.env.PROFILE_ADMISSION_SOURCE_ROOT || repo);
const output = path.resolve(process.env.PROFILE_ADMISSION_OUTPUT_ROOT || path.join(__dirname, 'diagnostic-current'));
const support = path.join(__dirname, 'frozen-writer-budget-fixture.cjs');
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
assert.equal(fs.existsSync(output), false, 'Preserve all original evidence; use a new output root');
fs.mkdirSync(output, { recursive: true });
const nativeRequire = createRequire(path.join(repo, 'package.json'));
const { createClient } = nativeRequire('@supabase/supabase-js');
const { isRedirectError } = nativeRequire('next/dist/client/components/redirect-error');
const { getURLFromRedirectError } = nativeRequire('next/dist/client/components/redirect');
const checks = [], timeline = [], providerCalls = [], audits = [], stages = [], privateCandidates = new Map(), snapshots = [];
let runtime, phase = 'setup', providerAcceptanceSerial = 0, journalSerial = 0;
const record = (name, category, body) => {
  try { const detail = body(); checks.push({ name, category, pass: true, ...(detail === undefined ? {} : { detail }) }); }
  catch (error) { checks.push({ name, category, pass: false, error: error.stack || String(error) }); }
};
const response = (value, status = 200) => new Response(JSON.stringify(value), { status, headers: { 'Content-Type': 'application/json' } });
const canonical = () => ({ catalog: structuredClone(runtime.catalog), rows: structuredClone([...runtime.rows.values()]) });

async function main() {
  const supportBytes = fs.readFileSync(support), supportText = supportBytes.toString();
  assert.equal(sha(supportBytes), '1b5f9959c94b1a9ab3e80cb7df306defe9b72008be6c96b68d011efd68e2a22d', 'Original maintained declarations are frozen exactly');
  const boundary = supportText.indexOf('\nasync function main()');
  assert.ok(boundary > 0);
  const fixtureProcess = { env: { PROFILE_BUDGET_REPO: repo, PROFILE_BUDGET_SOURCE_ROOT: sourceRoot,
    PROFILE_BUDGET_OUTPUT_ROOT: path.join(output, 'raw-graph') } };
  runtime = new Function('require', '__dirname', '__filename', 'process', supportText.slice(0, boundary) +
    '\nreturn {load,mocks,ai,fetchBoundary,calls,wire,runs,writes,builds,revalidations,graph,rows,writers,catalog,englishText,russian,actorId,stamp,get activeWriter(){return activeWriter;}};')
    (require, __dirname, support, fixtureProcess);

  // One unknown-result candidate plus one protected manual EN record. These are
  // synthetic inputs, without source-code changes or altered translation logic.
  runtime.catalog.countries[0].writers.splice(2);
  const manual = runtime.rows.get(runtime.writers[1].id);
  manual.fields.biographyTranslations = { ru: structuredClone(runtime.russian), en: {
    ...structuredClone(runtime.russian), locale: 'en', text: runtime.englishText,
    method: 'human-translation', manualRights: { preserve: 'Exact manual EN rights' },
  } };
  const before = canonical();

  const fetchBoundary = async (resource, init = {}) => {
    const url = new URL(typeof resource === 'string' ? resource : resource.url);
    assert.equal(url.origin, 'https://profile-budget.fixture.invalid', 'No external data service is reachable');
    const method = init.method || 'GET', name = url.pathname.split('/').at(-1), body = init.body ? JSON.parse(init.body) : null;
    timeline.push({ phase, event: 'sdk-boundary', method, name });
    if (name === 'get_premium_translation_working_draft') {
      runtime.wire.push({ method, path: url.pathname, body: structuredClone(body) });
      return response({ schemaVersion: 1, entityType: body.p_entity_type, entityId: body.p_entity_id,
        draft: privateCandidates.get(`${body.p_entity_type}:${body.p_entity_id}`) || null });
    }
    if (name === 'stage_premium_translation_working_draft') {
      const key = `${body.p_entity_type}:${body.p_entity_id}`;
      assert.equal(privateCandidates.has(key), false, 'A pending candidate is never overwritten');
      const draft = { id: '12345678-1234-4234-8234-000000000001', version: 1,
        entityType: body.p_entity_type, entityId: body.p_entity_id, targetLocale: 'en', humanReview: 'pending',
        sourceHash: body.p_source_hash, candidateHash: sha(JSON.stringify(body)), sourceSnapshot: body.p_source_snapshot,
        sourceRevision: body.p_source_revision, targetRevision: body.p_target_revision, payload: body.p_payload,
        provenance: body.p_provenance, createdAt: new Date().toISOString(), createdBy: runtime.actorId };
      privateCandidates.set(key, structuredClone(draft)); stages.push({ phase, body: structuredClone(body) });
      runtime.wire.push({ method, path: url.pathname, body: structuredClone(body) });
      return response({ schemaVersion: 1, entityType: draft.entityType, entityId: draft.entityId, draft });
    }
    if (name === 'admin_audit_log' && method === 'POST') {
      audits.push({ phase, body: structuredClone(body) });
      runtime.wire.push({ method, path: url.pathname, body: structuredClone(body) });
      return response(null, 201);
    }
    const result = await runtime.fetchBoundary(resource, init);
    if (name === 'record_translation_sync_run') {
      timeline.push({ phase, event: 'posthoc-run-record', jobId: `cccccccc-cccc-4ccc-8ccc-${String(++journalSerial).padStart(12, '0')}` });
      return response(`cccccccc-cccc-4ccc-8ccc-${String(journalSerial).padStart(12, '0')}`);
    }
    return result;
  };
  const sdk = createClient('https://profile-budget.fixture.invalid', 'synthetic-no-auth-session', {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }, global: { fetch: fetchBoundary },
  });
  runtime.mocks['@/lib/supabase/server'] = { async createServerSupabaseClient() { return sdk; } };
  runtime.ai.run = async (model, input) => {
    const content = JSON.parse(input.messages[1].content);
    const pass = Object.hasOwn(content, 'INVALID_DRAFT_TRANSLATION') ? 'repair' : Object.hasOwn(content, 'DRAFT_TRANSLATION') ? 'review' : 'translation';
    assert.equal(runtime.activeWriter, runtime.writers[0].id, 'Only the intended nonmanual candidate may reach the provider');
    const call = { phase, serial: ++providerAcceptanceSerial, writerId: runtime.activeWriter, model, pass,
      source: structuredClone(content.SOURCE_DATA), requestSha256: sha(JSON.stringify(input)),
      sourceSha256: sha(JSON.stringify(content.SOURCE_DATA)), acceptedByControlledBoundary: true,
      delivery: providerAcceptanceSerial === 1 ? 'lost-after-acceptance' : 'returned' };
    providerCalls.push(call); timeline.push({ phase, event: 'controlled-provider-accepted', serial: call.serial, pass });
    if (call.serial === 1) {
      const error = new Error('Controlled provider request timed out after acceptance; response delivery lost');
      error.name = 'TimeoutError';
      throw error;
    }
    return { id: `controlled-admission-${call.serial}`, response: JSON.stringify({ text: runtime.englishText }), usage: { prompt_tokens: 10, completion_tokens: 10 } };
  };

  const actions = runtime.load('apps/admin/app/(dashboard)/translations/actions.ts');
  const runAction = async label => {
    phase = label;
    const callsBefore = providerCalls.length, runsBefore = runtime.runs.length;
    let redirect;
    try { await actions.translatePremiumWriterBatchAction(new FormData()); throw new Error('Actual action returned without native redirect'); }
    catch (error) { assert.equal(isRedirectError(error), true, error.stack); redirect = getURLFromRedirectError(error); }
    const result = { phase, redirect, params: Object.fromEntries(new URL(redirect, 'https://fixture.invalid').searchParams),
      addedProviderCalls: providerCalls.length - callsBefore, newRuns: structuredClone(runtime.runs.slice(runsBefore)),
      privateCandidates: privateCandidates.size, stages: stages.length, audits: audits.filter(row => row.phase === label).length };
    snapshots.push(result); return result;
  };
  const first = await runAction('first-action');
  record('First actual action receives the controlled accepted transport failure', 'execution', () => {
    assert.equal(first.addedProviderCalls, 1); assert.equal(first.params.errorCode, 'provider_request_failed');
    assert.equal(providerCalls[0].delivery, 'lost-after-acceptance'); assert.equal(providerCalls[0].pass, 'translation');
  });
  record('First actual failure is journalled without creating private output', 'execution', () => {
    assert.equal(first.newRuns.length, 1); assert.equal(first.newRuns[0].p_kind, 'writer');
    assert.deepEqual(first.newRuns[0].p_outcomes, [{ status: 'dead_letter', errorCode: 'provider_request_failed' }]);
    assert.equal(first.privateCandidates, 0); assert.equal(first.stages, 0); assert.equal(first.audits, 1);
  });
  const firstCanonical = canonical();
  record('First failure preserves complete source, canonical fields and manual rights', 'preservation', () => assert.deepEqual(firstCanonical, before));
  const second = await runAction('second-fresh-action');
  record('Second actual fresh batch executes without missing fixture boundaries', 'execution', () => {
    assert.equal(second.newRuns.length, 1); assert.equal(second.params.errorCode, undefined);
    assert.equal(second.addedProviderCalls, 2); assert.deepEqual(providerCalls.slice(1).map(call => call.pass), ['translation', 'review']);
    assert.deepEqual(second.newRuns[0].p_outcomes.map(item => item.status), ['succeeded', 'skipped']);
    assert.equal(second.privateCandidates, 1); assert.equal(second.stages, 1);
  });
  record('Repeated provider entry uses exactly the unchanged original source', 'execution', () => {
    assert.deepEqual(providerCalls[1].source, providerCalls[0].source);
    assert.equal(providerCalls[1].sourceSha256, providerCalls[0].sourceSha256);
    assert.equal(providerCalls[1].requestSha256, providerCalls[0].requestSha256);
    assert.deepEqual(canonical(), firstCanonical);
  });
  record('Canonical RU, EN, manual text, sources and rights remain byte-for-byte equivalent JSON', 'preservation', () => {
    assert.deepEqual(canonical(), before); assert.equal(runtime.writes.length, 0); assert.equal(runtime.builds.length, 0);
  });
  record('No second provider dispatch is permitted after the first accepted request loses delivery', 'target', () => {
    assert.equal(second.addedProviderCalls, 0, 'A fresh action must reconcile the uncertain existing attempt instead of translating the same revision again');
  });
  record('The uncertain accepted request retains a durable recoverable identity before a fresh attempt', 'target', () => {
    const acceptance = timeline.findIndex(event => event.event === 'controlled-provider-accepted');
    const durableBeforeDispatch = timeline.slice(0, acceptance).filter(event => event.event === 'sdk-boundary' && /begin|dispatch|admission/iu.test(event.name));
    assert.ok(durableBeforeDispatch.length > 0, 'A posthoc dead_letter run cannot establish the accepted request identity');
  });
  const sources = [...runtime.graph.values()].sort((left, right) => left.module.localeCompare(right.module));
  record('Every executed source is frozen exactly with no drift during the run', 'binding', () => {
    for (const entry of sources) {
      assert.equal(sha(fs.readFileSync(path.join(sourceRoot, entry.module))), entry.sha256);
      assert.equal(sha(fs.readFileSync(path.join(output, 'raw-graph/sources', entry.module))), entry.sha256);
    }
  });
  const packages = ['@supabase/supabase-js', 'typescript', 'next', 'zod'].map(name => {
    const packagePath = path.join(repo, 'node_modules', name, 'package.json');
    const bytes = fs.readFileSync(packagePath);
    return { name, version: JSON.parse(bytes.toString()).version, packagePath, packageSha256: sha(bytes) };
  });
  const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim();
  const report = { mode: 'NEXT-SLICE BEFORE; target assertion failures are preserved, never acceptance PASS',
    checkedAt: new Date().toISOString(), head, sourceRoot, node: process.version, checks,
    executionFailures: checks.filter(check => !check.pass && check.category !== 'target').length,
    targetFailures: checks.filter(check => !check.pass && check.category === 'target').length,
    providerCalls, snapshots, timeline, audits, stages, wire: runtime.wire,
    canonicalBefore: before, canonicalAfter: canonical(), canonicalMachineWrites: runtime.writes.length,
    publicBuildRequests: runtime.builds.length, sourceCount: sources.length, sources, packages,
    fixtureSha256: sha(fs.readFileSync(__filename)), supportSha256: sha(supportBytes),
    limitations: ['Actual writer action/helper, premium translator/reviewer and error handling, runtime gate/probe, DTO/run adapters, installed Supabase SDK and native Next redirect execute.',
      'Auth, catalog, in-memory PostgREST transport and Cloudflare AI binding are synthetic. The boundary records one accepted request and immediately throws TimeoutError to model lost delivery; no real timer or provider invoice is demonstrated.',
      'The second invocation is a new actual FormData batch on identical canonical/source revisions, rather than the failed-item retry UI or native browser lifecycle.',
      'No real network, Auth, DB, RLS, provider, paid dispatch, build, social or production operations. No repository source/test/SQL/docs edits; normalizer/hyphen paths are not invoked by this fixture.'] };
  fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
  fs.writeFileSync(path.join(output, 'manifest.json'), JSON.stringify({ head, sourceRoot, sources, packages,
    fixtureSha256: report.fixtureSha256, supportSha256: report.supportSha256 }, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ report: path.join(output, 'report.json'), sourceCount: sources.length,
    checks: checks.map(({ name, category, pass }) => ({ name, category, pass })), executionFailures: report.executionFailures,
    targetFailures: report.targetFailures, providerCalls: providerCalls.length, snapshots: snapshots.map(({ phase, addedProviderCalls, privateCandidates }) => ({ phase, addedProviderCalls, privateCandidates })) }, null, 2));
  process.exitCode = report.executionFailures ? 2 : report.targetFailures ? 1 : 0;
}
main().catch(error => {
  fs.writeFileSync(path.join(output, 'diagnostic-error.json'), JSON.stringify({ error: error.stack || String(error), phase, timeline, providerCalls,
    wire: runtime?.wire, sources: runtime ? [...runtime.graph.values()] : [] }, null, 2), { flag: 'wx' });
  console.error(error.stack || error); process.exitCode = 2;
});
