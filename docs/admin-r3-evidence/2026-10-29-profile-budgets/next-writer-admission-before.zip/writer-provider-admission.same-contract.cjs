const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const inputPath = path.resolve(process.argv[2]);
const outputPath = path.resolve(process.argv[3]);
assert.equal(fs.existsSync(outputPath), false, 'Never overwrite original SAME evidence');
const bytes = fs.readFileSync(inputPath), report = JSON.parse(bytes);
const checks = [];
function check(name, category, body) {
  try { body(); checks.push({ name, category, pass: true }); }
  catch (error) { checks.push({ name, category, pass: false, error: error.stack || String(error) }); }
}
check('Actual writer action, helper, premium transport and installed SDK are bound', 'control', () => {
  for (const module of ['apps/admin/app/(dashboard)/translations/actions.ts', 'apps/admin/lib/auto-translate-writer-biography.ts',
    'apps/admin/lib/premium-english-translation.ts', 'apps/admin/lib/translation-operation-budget.ts', 'apps/admin/lib/translation-run-record.ts']) {
    assert.ok(report.sources.some(source => source.module === module));
  }
  assert.ok(report.packages.some(entry => entry.name === '@supabase/supabase-js'));
});
check('One controlled first request is accepted, loses delivery and creates no candidate', 'control', () => {
  assert.equal(report.snapshots[0].addedProviderCalls, 1);
  assert.equal(report.providerCalls[0].acceptedByControlledBoundary, true);
  assert.equal(report.providerCalls[0].delivery, 'lost-after-acceptance');
  assert.equal(report.snapshots[0].privateCandidates, 0);
});
check('Both actions complete through the native redirect without missing execution', 'control', () => {
  assert.equal(report.snapshots.length, 2);
  assert.ok(report.snapshots.every(snapshot => typeof snapshot.redirect === 'string' && snapshot.redirect.includes('/translations')));
  assert.equal(report.executionFailures, 0);
});
check('Canonical source, manual EN, sources, rights and revision tokens remain exact', 'preservation', () => {
  assert.deepEqual(report.canonicalAfter, report.canonicalBefore);
  const manual = report.canonicalAfter.rows.find(row => row.fields.biographyTranslations?.en?.method === 'human-translation');
  assert.ok(manual); assert.equal(manual.fields.biographyTranslations.en.manualRights.preserve, 'Exact manual EN rights');
  assert.equal(report.canonicalMachineWrites, 0); assert.equal(report.publicBuildRequests, 0);
});
check('Fresh batch must dispatch zero requests after the accepted attempt loses delivery', 'target', () => {
  assert.equal(report.snapshots[1].addedProviderCalls, 0, 'Reconcile the uncertain original attempt; do not resend an identical source revision');
});
check('Unknown accepted outcome must have a durable recoverable identity before dispatch', 'target', () => {
  const acceptance = report.timeline.findIndex(event => event.event === 'controlled-provider-accepted');
  assert.ok(acceptance >= 0);
  assert.ok(report.timeline.slice(0, acceptance).some(event => event.event === 'sdk-boundary' && /begin|dispatch|admission/iu.test(event.name)),
    'A later dead_letter journal entry is insufficient to identify the accepted request');
});
const result = { contract: 'Frozen SAME writer accepted-request loss contract', inputPath, inputSha256: sha(bytes),
  contractSha256: sha(fs.readFileSync(__filename)), checkedAt: new Date().toISOString(), checks,
  controlFailures: checks.filter(check => !check.pass && check.category !== 'target').length,
  targetFailures: checks.filter(check => !check.pass && check.category === 'target').length,
  scope: 'Invariant contract evaluated over the actual runtime scenario report. The scenario runner has separate defect-specific diagnostics; future harness boundary changes require explicit source comparison and cannot be called an identical whole-runner replay.' };
fs.writeFileSync(outputPath, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ outputPath, controlFailures: result.controlFailures, targetFailures: result.targetFailures, checks: checks.map(({name,category,pass}) => ({name,category,pass})) }, null, 2));
process.exitCode = result.controlFailures ? 2 : result.targetFailures ? 1 : 0;
