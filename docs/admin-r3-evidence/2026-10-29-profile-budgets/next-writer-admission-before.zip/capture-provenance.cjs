const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = __dirname;
const repo = path.resolve(root, '../../probpera-literary-map');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const read = relative => JSON.parse(fs.readFileSync(path.join(root, relative), 'utf8'));
const original = read('diagnostic-current/report.json'), replay = read('frozen-before-replay/report.json');
const contract = read('same-before-acceptance.json');
assert.deepEqual(original.sources, replay.sources);
assert.deepEqual(original.providerCalls.map(({phase,pass,sourceSha256,requestSha256,delivery}) => ({phase,pass,sourceSha256,requestSha256,delivery})),
  replay.providerCalls.map(({phase,pass,sourceSha256,requestSha256,delivery}) => ({phase,pass,sourceSha256,requestSha256,delivery})));
assert.equal(original.executionFailures, 0); assert.equal(replay.executionFailures, 0);
assert.equal(original.targetFailures, 2); assert.equal(replay.targetFailures, 2);
assert.equal(contract.controlFailures, 0); assert.equal(contract.targetFailures, 2);
assert.equal(fs.readFileSync(path.join(root, 'frozen-before-replay.exit.txt'), 'utf8').trim(), '1');
assert.equal(fs.readFileSync(path.join(root, 'same-before-acceptance.exit.txt'), 'utf8').trim(), '1');
const bindings = original.sources.map(entry => {
  const currentSha256 = sha(fs.readFileSync(path.join(repo, entry.module)));
  const capturedSha256 = sha(fs.readFileSync(path.join(root, 'diagnostic-current/raw-graph/sources', entry.module)));
  const replaySha256 = sha(fs.readFileSync(path.join(root, 'frozen-before-replay/raw-graph/sources', entry.module)));
  assert.equal(currentSha256, entry.sha256); assert.equal(capturedSha256, entry.sha256); assert.equal(replaySha256, entry.sha256);
  return { ...entry, currentSha256, capturedSha256, replaySha256 };
});
const files = [];
function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) walk(absolute);
    else if (entry.name !== 'provenance.json') files.push({ file: path.relative(root, absolute).replaceAll('\\', '/'), sha256: sha(fs.readFileSync(absolute)) });
  }
}
walk(root); files.sort((a,b) => a.file.localeCompare(b.file));
const result = { checkedAt: new Date().toISOString(), head: original.head,
  sourceCount: bindings.length, currentSourcesEqualFrozenBefore: true, capturedSourcesEqualFrozenReplay: true,
  identicalScenarioFixtureAndSourceGraph: original.fixtureSha256 === replay.fixtureSha256,
  identicalControlledProviderPassesAndSourcePayloads: true, bindings,
  graphAggregateSha256: sha(JSON.stringify(original.sources)), artifacts: files,
  acceptance: { invariantControlsPassed: 4, invariantTargetsFailed: 2, invariantExit: 1,
    runtimeExecutionPreservationAndBindingPassed: 7, runtimeTargetsFailed: 2, runtimeExecutionFailures: 0, runtimeExit: 1 },
  scope: 'Frozen BEFORE reproduction only. No repository sources were authored by this capture. File bindings establish the 17 executed modules; they do not claim the entire concurrent worktree stayed unchanged.' };
fs.writeFileSync(path.join(root, 'provenance.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ provenance: path.join(root, 'provenance.json'), graphAggregateSha256: result.graphAggregateSha256,
  artifactCount: files.length, sourceCount: result.sourceCount, acceptance: result.acceptance,
  keyArtifacts: files.filter(file => ['frozen-before-replay/report.json','frozen-before-replay/manifest.json','same-before-acceptance.json',
    'same-writer-provider-admission.cjs','writer-provider-admission.same-contract.cjs'].includes(file.file)) }, null, 2));
