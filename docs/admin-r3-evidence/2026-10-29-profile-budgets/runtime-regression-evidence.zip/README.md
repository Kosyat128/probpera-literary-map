# Profile translation budget regression evidence

The final maintained suite passed 39/39 tests. Its 33 CURRENT scenarios execute
real writer, book and country actions/helpers against synthetic transport and a
deterministic budget clock. Source hashes and command terminal receipts are in
`current-final/`. The 26-file source fingerprint is the executed test graph plus
the five new maintained fixture/test files, not the entire repository.

The three SAME fixtures compare the same original conflict inputs. V2 BEFORE
retains four target failures per domain: writer/book five attempts and ten calls;
country three attempts and six calls. V2 CURRENT passes those assertions with
writer 3/6, book 4/8 and country 2/4 attempts/calls, preserving canonical authored
data and making no publication request. Caps are 3/12, 4/16 and 2/8 respectively;
the ordinary conflict scenario uses two passes per admitted attempt.

`original-v1/` contains unchanged original archives, including genuine captured
BEFORE graphs, original bytes/receipts, failures, hashes and scope notes. V2 adds
only a boolean-true response for the new readiness RPC at the SDK transport
boundary; `transport-only/proof.json` verifies exact V1 byte restoration after
removing that branch. All original positive inputs, target assertions, races and
algorithms remain intact. Root's three existing test fixtures received the same
readiness-only transport admission; their before/after bytes and diffs are in
`legacy-readiness-only/`. The separate fresh 251-test result is retained under
`legacy-focused251/`; it is not counted as part of maintained39.

CURRENT controls cover missing/false/malformed readiness (zero paid work), cheap
manual/current/pending guards, repair and retry reservations, one shared call
cap, deadline before first request with cursor retained, partial started request
with cursor advanced once, completed private output retained after deadline,
and a rejected run acknowledgement without claiming a saved cursor. Missing or
false readiness means migration_required; malformed readiness means database
read_failed. Warm-up calls constructing valid current/pending records are
separately retained and excluded only from measured operation windows.

Only Auth/catalog/PostgREST transport, Cloudflare response transport and the
budget factory clock are controlled. Actual helpers, premium pipeline and SDK
execute. Outputs are synthetic, credentials are not inherited by child fixtures,
uncontrolled fetch is denied, and no real paid/provider/production call occurs.
This artifact does not establish all M07 or R3 criteria, native SQL deployment,
browser behavior, real billing or a full repository test PASS. Budgets here are
per invocation; cross-run/global accounting and restart uncertainty remain
uncovered. No claim of durable cross-run spending limits is made.

Replay CURRENT from the repository with Node24 and its locked dependencies:
`node node_modules/vitest/vitest.mjs run apps/admin/lib/profile-library-batch-budgets.integration.test.ts --maxWorkers=2`
The maintained inputs are committed repository fixtures and default to current
root sources. Historical replay requires extracting each original archive into
its named parent-work folder and choosing a fresh output directory; original
README files document environment path overrides. `runners/` retains the exact
commands/orchestration, whose original parent-work placement is recorded by
receipts. Historical mode prose inside the original acceptance scripts is
preserved literally; actual sourceRoot, hashes and target results identify each
execution. No historical failure is reclassified as an acceptance PASS.
