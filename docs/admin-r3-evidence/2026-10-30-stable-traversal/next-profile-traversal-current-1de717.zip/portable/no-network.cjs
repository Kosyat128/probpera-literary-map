// Supplementary external-boundary guard only. The original SDK receives its
// unchanged explicit local fetch transports; no application source is adapted.
globalThis.fetch=async()=>{throw new Error('Portable BEFORE replay forbids network access');};
