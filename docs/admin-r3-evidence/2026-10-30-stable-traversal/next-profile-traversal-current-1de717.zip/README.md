# Unresolved CURRENT profile diagnostic on global1de717

This is a separate CURRENT next-slice proof. It does not replace the genuine original profile BEFORE archive, whose bytes remain SHA256 `5489cdc6aa59f823d69357b5b76f9be057300882696569f297632080cb3a261a`. That original is included intact under `reference/`.

The current writer/country actions still reproduce six failing coverage/no-repeat targets in eight assertions under unchanged contract `a988d0df137b66ef6822450d0307fb76222e2c706cc341a2b04a6ee5e5378008`. Country cases inspect30+30 and writer cases120+120, with zero execution failure/provider/canonical/build counts. Exact author/manual EN/opaque rights/source rows and scenario mutations remain preserved. This is not library acceptance or a new profile implementation result.

All36 executed application sources and six support fixtures were captured separately and matched by byte length/SHA256 against root's global source snapshot `1de7172827ad785bb99967618fb662e77ceeb556fa1c7ce5490d4084ad08bb47`. The complete source-before metadata snapshot is included. Root owned the still-running broad/gates at capture time; this artifact does not accept those gates or declare full R3 completion.

`proposal/` contains the latest parent-only typed adapter/contract proposal and its43 DTO/type guard checks. Country IDs retain the existing120 UTF-16-unit cap; the proposed deferred construction check runs only on job INSERT (at most20), with immediate immutable item and local job-update guards. No native profile functions/migration/implementation are created or accepted.

## Portable CURRENT replay

Extract to a fresh directory and run:

```text
node portable/replay-current.cjs --dependency-root <existing-installed-project> --output <new-output-directory>
```

The installed Node/SDK/Next/TypeScript/Zod/fflate packages are read only; no dependency links/copies or current application source fallback are used. The extracted36 CURRENT modules and six support fixtures execute through the unchanged paired runner. Only sourceRoot's filesystem location differs; every other recorded report field must match exactly. The replayer checks all42 global bindings, safe unique manifest paths and hashes, and the original a988 invariant. A global fetch guard blocks network; original explicit SDK transports remain controlled. Expected result is six target FAIL/eight, not an acceptance PASS.

The frozen manifest lists each payload except itself. Profiles still need fixed full tuple membership rather than a global fingerprint stale-stop. Native profile DB/RLS/concurrency, unknown paid outcome and retry behavior, admin E2E and the full M07/R3 criteria remain unverified. No paid/live/production/key actions ran.
