const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process'),{createRequire}=require('node:module');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const args=Object.fromEntries(process.argv.slice(2).reduce((pairs,value,index,all)=>index%2===0?[...pairs,[value,all[index+1]]]:pairs,[]));
assert.ok(args['--dependency-root'],'Use --dependency-root for an installed dependency directory; no current application source is used.');
assert.ok(args['--output'],'Use a fresh --output directory.');
const root=path.resolve(__dirname,'..'),dependencyRoot=path.resolve(args['--dependency-root']),output=path.resolve(args['--output']);
assert.equal(fs.existsSync(output),false,'Replay output must be a new directory');fs.mkdirSync(output,{recursive:true});
const read=file=>fs.readFileSync(path.join(root,file)),json=file=>JSON.parse(read(file));
const safe=file=>typeof file==='string'&&file.length>0&&!file.includes('\\')&&!file.startsWith('/')&&!file.includes(':')&&file.split('/').every(part=>part&&part!=='.'&&part!=='..');
const manifest=json('manifest.json'),paths=new Set();
function verify(){for(const row of manifest.files){assert.ok(safe(row.file));const key=row.file.toLowerCase();assert.equal(paths.has(key),false,'Manifest path collision '+row.file);paths.add(key);const bytes=read(row.file);assert.equal(bytes.length,row.bytes,row.file);assert.equal(sha(bytes),row.sha256,row.file);}paths.clear();}
verify();
const beforeRoot='work/m07-t12-profile-before-20261030-sol',original=json(beforeRoot+'/run-2026-10-29T23-36-49-744Z/report.json'),contractFile='same-contract.cjs';
assert.equal(sha(read(contractFile)),'a988d0df137b66ef6822450d0307fb76222e2c706cc341a2b04a6ee5e5378008');
assert.equal(sha(read(beforeRoot+'/run-2026-10-29T23-36-49-744Z/report.json')),'5e86af8425eb38b503ba4ffba17795059ef1cb82e633708b9795c55f9d6887f3');
assert.equal(sha(read(beforeRoot+'/prepared-proof-receipt.json')),'e2446516469885d416ecce1ea1177c9da60ea8cceebd13be19311ac46d0dfd19');
const graph=new Map();for(const scenario of original.cases)for(const source of scenario.sources){const previous=graph.get(source.module);if(previous)assert.equal(previous.sha256,source.sha256);graph.set(source.module,source);}
assert.equal(graph.size,34);for(const source of graph.values())assert.equal(sha(read('probpera-literary-map/'+source.module)),source.sha256,source.module);
const installedRequire=createRequire(path.join(dependencyRoot,'package.json'));
const packages=['@supabase/supabase-js','typescript','next','zod','fflate'].map(name=>{let entry;try{entry=installedRequire.resolve(name+'/package.json');}catch{let current=path.dirname(installedRequire.resolve(name));while(current!==path.dirname(current)&&!fs.existsSync(path.join(current,'package.json')))current=path.dirname(current);entry=path.join(current,'package.json');}const data=JSON.parse(fs.readFileSync(entry));return{name,version:data.version,packageJsonSha256:sha(fs.readFileSync(entry)),path:entry};});
const runner=path.join(root,beforeRoot,'profile-array-before.cjs'),prior=new Set(fs.readdirSync(path.dirname(runner)));
const child=cp.spawnSync(process.execPath,['--require',path.join(root,'portable/no-network.cjs'),runner],{cwd:output,env:{...process.env,NODE_PATH:path.join(dependencyRoot,'node_modules')},encoding:'utf8',timeout:180000,maxBuffer:20*1024*1024});
fs.writeFileSync(path.join(output,'stdout.log'),child.stdout||'');fs.writeFileSync(path.join(output,'stderr.log'),child.stderr||'');
assert.equal(child.error,undefined,child.error?.stack);assert.equal(child.status,0,child.stderr||child.stdout);
const added=fs.readdirSync(path.dirname(runner)).filter(file=>!prior.has(file)&&file.startsWith('run-'));assert.equal(added.length,1);
const generatedPath=path.join(path.dirname(runner),added[0],'report.json'),raw=JSON.parse(fs.readFileSync(generatedPath));
assert.equal(raw.classification,'GENUINE_PROFILE_CIRCULAR_ARRAY_BEFORE_NOT_ACCEPTANCE_PASS');assert.equal(raw.cases.length,4);
assert.deepEqual(raw.controls,{executionFailures:0,providerCalls:0,canonicalWrites:0,publicBuildRequests:0});
const observer={executionFailures:raw.controls.executionFailures,providerCalls:raw.controls.providerCalls,cases:raw.cases.map((current,index)=>{
 const old=original.cases[index];for(const field of ['kind','mutation','initialIds','beforeMembership','afterMembership','originalAuthorRows','secondCursor','omitted','repeated','protectedAuthorRowsExact','survivingCatalogSourceRowsExact','providerCalls','canonicalWrites','publicBuildRequests','sources'])assert.deepEqual(current[field],old[field],current.kind+':'+field);
 assert.deepEqual(current.first.helperIds,old.first.helperIds);assert.deepEqual(current.second.helperIds,old.second.helperIds);assert.equal(current.actualResumeReads.length,1);assert.deepEqual(current.actualResumeReads,old.actualResumeReads);
 const counts=new Map();for(const id of current.seen)counts.set(id,(counts.get(id)||0)+1);
 return{kind:current.kind+'/'+current.mutation,omittedInitialIdsAtCursorWrap:current.initialIds.filter(id=>!counts.has(id)),repeatedInitialIds:current.initialIds.filter(id=>(counts.get(id)||0)>1)};
})};
const same=require(path.join(root,contractFile))(observer);assert.equal(same.targetFailures,6);assert.equal(same.target.length,8);
verify();for(const source of graph.values())assert.equal(sha(read('probpera-literary-map/'+source.module)),source.sha256);
fs.copyFileSync(generatedPath,path.join(output,'actual-frozen-report.json'));
const receipt={classification:'PORTABLE_GENUINE_PROFILE_BEFORE_REPLAY_EXPECTED_SIX_TARGET_FAILURES_NOT_ACCEPTANCE',node:process.version,packages,sourceCount:graph.size,manifestPayloads:manifest.files.length,
 originalRunnerSha256:sha(read(beforeRoot+'/profile-array-before.cjs')),originalReportSha256:sha(read(beforeRoot+'/run-2026-10-29T23-36-49-744Z/report.json')),preparedProofReceiptSha256:sha(read(beforeRoot+'/prepared-proof-receipt.json')),contractSha256:sha(read(contractFile)),
 actualReportSha256:sha(fs.readFileSync(generatedPath)),same,executionFailures:0,providerCalls:0,canonicalWrites:0,publicBuilds:0,originalInputsUnchanged:true,
 boundaries:'Original runner and34 application modules execute unchanged from the extracted frozen tree. Four captured metadata runtime transports and one exactly archived transitive fixture are original support bytes. Installed SDK/Next/TypeScript/Zod are read only through NODE_PATH; no current application source, links or generated substitute source is used. Catalog/Auth/read transports are controlled, AI dispatch is forbidden, global network is denied. No native profile DB/RLS, admin E2E, failed-item retry or T12 acceptance is claimed.'};
fs.writeFileSync(path.join(output,'replay-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({output,sourceCount:graph.size,targetFailures:same.targetFailures,targets:same.target.length,executionFailures:0,providerCalls:0,canonicalWrites:0,publicBuilds:0,actualReportSha256:receipt.actualReportSha256}));
