const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const here=__dirname,repo=path.resolve(here,'../../probpera-literary-map');
const input=path.join(here,'run-2026-10-29T23-36-49-744Z/report.json'),bytes=fs.readFileSync(input),raw=JSON.parse(bytes);
const originalContract=path.resolve(here,'../m07-t12-library-before-20261030-sol/same-contract.cjs');
const contractBytes=fs.readFileSync(originalContract);assert.equal(sha(contractBytes),'a988d0df137b66ef6822450d0307fb76222e2c706cc341a2b04a6ee5e5378008');
const out=path.join(here,'contract-proof-v1');assert.equal(fs.existsSync(out),false);fs.mkdirSync(out);
fs.writeFileSync(path.join(out,'same-contract.cjs'),contractBytes,{flag:'wx'});
const observer={executionFailures:raw.controls.executionFailures,providerCalls:raw.controls.providerCalls,cases:raw.cases.map(c=>{
 const counts=new Map();for(const id of c.seen)counts.set(id,(counts.get(id)||0)+1);
 const omitted=c.initialIds.filter(id=>!counts.has(id)),repeated=c.initialIds.filter(id=>(counts.get(id)||0)>1);
 assert.deepEqual(omitted,c.omitted);assert.deepEqual(repeated,c.repeated.map(([id])=>id));
 assert.equal(c.secondCursor,0);assert.equal(c.providerCalls,0);assert.equal(c.canonicalWrites,0);assert.equal(c.publicBuildRequests,0);
 assert.equal(c.protectedAuthorRowsExact,true);assert.equal(c.survivingCatalogSourceRowsExact,true);
 assert.equal(c.actualResumeReads.length,1);
 return{kind:c.kind+'/'+c.mutation,omittedInitialIdsAtCursorWrap:omitted,repeatedInitialIds:repeated};
})};
const result=require(path.join(out,'same-contract.cjs'))(observer);assert.equal(result.targetFailures,6);assert.equal(result.target.length,8);
const graph=new Map();for(const c of raw.cases)for(const s of c.sources){const prior=graph.get(s.module);if(prior)assert.equal(prior.sha256,s.sha256);graph.set(s.module,s);}
const sources=[...graph.values()].sort((a,b)=>a.module.localeCompare(b.module));
for(const s of sources){const file=path.join(path.dirname(input),'sources',s.module),captured=fs.readFileSync(file),current=fs.readFileSync(path.join(repo,s.module));assert.equal(sha(captured),s.sha256);assert.equal(sha(current),s.sha256);}
const runtimeFiles=['apps/admin/lib/fixtures/catalog-admission-runtime.cjs','apps/admin/lib/fixtures/writer-admission-runtime.cjs','apps/admin/lib/fixtures/catalog-admission-boundary.cjs','apps/admin/lib/fixtures/writer-admission-boundary.cjs'];
const runtime=runtimeFiles.map(file=>{const b=fs.readFileSync(path.join(repo,file)),target=path.join(out,'support',file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,b,{flag:'wx'});return{file,sha256:sha(b),bytes:b.length};});
const report={classification:'ORIGINAL_LIBRARY_CONTRACT_APPLIED_TO_GENUINE_PROFILE_BEFORE',input:{file:path.relative(here,input).replaceAll('\\','/'),sha256:sha(bytes)},contract:{sha256:sha(contractBytes),byteIdentical:true},
 observerAdaptation:'Only field names are mapped: controls.executionFailures/providerCalls, initial-ID membership observed from actual SDK helper reads, and unique kind/mutation labels. No outcome is invented; deleted fixture members were already visited. Raw capture remains unchanged.',
 observer,result,sourceCount:sources.length,sources,support:runtime,script:{file:'profile-array-before.cjs',sha256:sha(fs.readFileSync(path.join(here,'profile-array-before.cjs')))},
 limitations:['Six of eight target assertions fail; this is unresolved BEFORE evidence, not an acceptance pass.','A cursor wrap is not an explicit UI100% claim or proof of permanent starvation.','Profile catalogue/Auth/SDK transports are synthetic; actual action/helper/resume/budget/run modules execute; no real database/RLS/provider claim.']};
fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output:out,reportSha256:sha(fs.readFileSync(path.join(out,'report.json'))),targets:result.target.length,targetFailures:result.targetFailures,sourceCount:sources.length,inputSha256:sha(bytes),contractSha256:sha(contractBytes)}));
