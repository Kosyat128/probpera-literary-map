const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const here=__dirname,repo=path.resolve(here,'../../probpera-literary-map'),native=createRequire(path.join(repo,'package.json')),{createClient}=native('@supabase/supabase-js');
const input=fs.readFileSync(path.join(here,'profile-array-before.cjs'),'utf8'),boundary=input.indexOf('\nasync function main()');assert.ok(boundary>0);
const shared=new Function('require','__dirname',input.slice(0,boundary)+'\nreturn {setup,output};')(require,here);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
async function scenario(kind){
 const view=shared.setup(kind),table=kind==='country'?'country_profile_overrides':'writer_profile_overrides',firstId=view.initialIds[0],faults=[];
 const originalFrom=view.view.sdk.from.bind(view.view.sdk);
 const controlled=createClient(`https://${kind}-scan-failure.fixture.invalid`,'synthetic-no-auth-session',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},global:{fetch:async(resource,init={})=>{
  const url=new URL(typeof resource==='string'?resource:resource.url),method=init.method||'GET';assert.equal(url.pathname,`/rest/v1/${table}`);
  if(faults.length===0){const request={method,path:url.pathname,query:Object.fromEntries(url.searchParams),body:null};
   assert.equal(request.query[kind==='country'?'country_id':'writer_id'],`eq.${firstId}`);faults.push(request);view.view.wire.push(structuredClone(request));
   return new Response(JSON.stringify({code:'57014',message:'Controlled canonical metadata read failed before provider admission'}),{status:400,headers:{'Content-Type':'application/json'}});
  }
  return view.view.fetchBoundary(resource,init);
 }}});
 view.view.sdk.from=name=>name===table?controlled.from(name):originalFrom(name);
 const beforeAuthors=view.authorRows(),beforeSource=view.sourceRows();
 const first=await view.invoke(),second=await view.invoke(true);
 assert.deepEqual(first.helperIds,[firstId]);assert.equal(first.freeRuns.length,1);assert.equal(first.freeRuns[0].p_resume_cursor[`${kind}Cursor`],1);
 assert.equal(first.freeRuns[0].p_outcomes.length,1);assert.equal(first.freeRuns[0].p_outcomes[0].status,'dead_letter');
 assert.equal(second.helperIds.length,view.limit);assert.equal(second.helperIds.includes(firstId),false);
 assert.equal(second.helperIds[0],view.initialIds[1]);assert.equal(view.resumeReads.length,1);assert.equal(view.paidEntries.length,0);assert.equal(view.view.writes.length,0);assert.equal(view.view.builds.length,0);
 assert.deepEqual(view.authorRows(),beforeAuthors);assert.deepEqual(view.sourceRows(),beforeSource);
 return{kind,failureTarget:firstId,faults,first,second,actualStoredResumeRead:view.resumeReads[0],providerCalls:0,canonicalWrites:0,publicBuilds:0,authorRowsExact:true,catalogSourceRowsExact:true,observed:'The actual generic resume action consumes the stored next cursor and scans remaining IDs. It does not replay the failed ID, and submitted cursor999 never supplies authority.',sources:[...view.view.graph.values()]};
}
async function main(){const cases=[];for(const kind of ['country','writer'])cases.push(await scenario(kind));
 const report={classification:'CONTROLLED_METADATA_FAILURE_AND_REAL_SCAN_CONTINUE_DIAGNOSTIC_NOT_FAILED_ITEM_RETRY_ACCEPTANCE',executionFailures:0,cases,sourceScript:{file:'profile-array-before.cjs',sha256:sha(Buffer.from(input))},
  limitations:['The first read fails deterministically at the installed SDK transport before any paid admission. It is a known metadata failure, not an uncertain provider outcome.','The captured POST executes the real resume action and target batch. No rendered UI or profile failed-item retry command is implemented or accepted here.','T13 requires separate item/version-targeted retry through UI; the current profile page offers scan continuation only.']};
 const file=path.join(shared.output,'scan-continue-not-retry.json');fs.writeFileSync(file,JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({file,sha256:sha(fs.readFileSync(file)),cases:cases.map(c=>({kind:c.kind,failed:c.failureTarget,first:c.first.helperIds.length,continued:c.second.helperIds.length,providerCalls:0}))}));
}
main().catch(error=>{fs.writeFileSync(path.join(shared.output,'execution-error.json'),JSON.stringify({error:error.stack},null,2));console.error(error.stack);process.exitCode=2;});
