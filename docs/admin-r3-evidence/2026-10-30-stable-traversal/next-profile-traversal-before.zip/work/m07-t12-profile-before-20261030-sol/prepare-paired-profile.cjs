const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const original=fs.readFileSync(path.join(__dirname,'profile-array-before.cjs'),'utf8');let code=original;
const replacements=[
 ["const repo=path.resolve(__dirname,'../../probpera-literary-map'),native=", "const repo=process.env.M07_T12_PROFILE_REPO||path.resolve(__dirname,'../../probpera-literary-map'),sourceRoot=process.env.M07_T12_PROFILE_SOURCE_ROOT||repo,native="],
 ["const output=path.join(__dirname,'run-'+new Date().toISOString().replaceAll(/[:.]/g,'-'));", "const output=process.env.M07_T12_PROFILE_OUTPUT||path.join(__dirname,'paired-run-'+new Date().toISOString().replaceAll(/[:.]/g,'-'));"],
 ['CATALOG_ADMISSION_SOURCE_ROOT:repo','CATALOG_ADMISSION_SOURCE_ROOT:sourceRoot'],
 ['WRITER_ADMISSION_SOURCE_ROOT:repo','WRITER_ADMISSION_SOURCE_ROOT:sourceRoot'],
 ['fs.readFileSync(path.join(repo,source.module))','fs.readFileSync(path.join(sourceRoot,source.module))'],
 ["classification:'GENUINE_PROFILE_CIRCULAR_ARRAY_BEFORE_NOT_ACCEPTANCE_PASS'", "classification:'ADAPTED_SAME_HARNESS_PROFILE_REPLAY_NOT_ORIGINAL_RUNNER_NOT_ACCEPTANCE_PASS',sourceRoot"]
];
for(const [from,to]of replacements){assert.equal(code.split(from).length,2,from);code=code.replace(from,to);}
const file=path.join(__dirname,'profile-array-paired.cjs');assert.equal(fs.existsSync(file),false);fs.writeFileSync(file,code,{flag:'wx'});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
fs.writeFileSync(path.join(__dirname,'paired-loader-adaptation.json'),JSON.stringify({original:{file:'profile-array-before.cjs',sha256:sha(Buffer.from(original))},adapted:{file:'profile-array-paired.cjs',sha256:sha(Buffer.from(code))},replacements,
 declaration:'All adaptations are explicit source-root/output-root/classification bindings. Original synthetic SDK/Auth/catalog transports, actual app algorithms, scenario inputs and preservation assertions are unchanged. No assertion is removed or weakened. The original runner and raw capture remain immutable.',
 sourceRootFrozen:'run-2026-10-29T23-36-49-744Z/sources',sourceRootCurrent:'installed repository checkout'},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({file,sha256:sha(Buffer.from(code)),adaptations:replacements.length}));
