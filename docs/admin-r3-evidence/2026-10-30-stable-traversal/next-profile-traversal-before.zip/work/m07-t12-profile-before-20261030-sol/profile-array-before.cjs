const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),native=createRequire(path.join(repo,'package.json')),{createClient}=native('@supabase/supabase-js');
const {isRedirectError}=native('next/dist/client/components/redirect-error'),{getURLFromRedirectError}=native('next/dist/client/components/redirect');
const output=path.join(__dirname,'run-'+new Date().toISOString().replaceAll(/[:.]/g,'-'));fs.mkdirSync(output,{recursive:true});
const sha=value=>crypto.createHash('sha256').update(typeof value==='string'||Buffer.isBuffer(value)?value:JSON.stringify(value)).digest('hex');
Object.assign(process.env,{CATALOG_ADMISSION_REPO:repo,CATALOG_ADMISSION_SOURCE_ROOT:repo,CATALOG_ADMISSION_OUTPUT_ROOT:path.join(output,'country-runtime'),
 WRITER_ADMISSION_REPO:repo,WRITER_ADMISSION_SOURCE_ROOT:repo,WRITER_ADMISSION_OUTPUT_ROOT:path.join(output,'writer-runtime')});
const countryRuntime=require(path.join(repo,'apps/admin/lib/fixtures/catalog-admission-runtime.cjs'));
const writerRuntime=require(path.join(repo,'apps/admin/lib/fixtures/writer-admission-runtime.cjs'));
function setup(kind){
 const options={noManual:true,candidates:kind==='country'?60:240},view=kind==='country'?countryRuntime.setup('country',options):writerRuntime.setup(options);
 const total=kind==='country'?60:240,limit=kind==='country'?30:120,catalogEntries=[];
 if(kind==='country'){
  const template=structuredClone(view.countries[0]);view.countries.length=0;
  for(let i=0;i<total;i++){const row=structuredClone(template),suffix=String(i+1).padStart(12,'0');row.id=`scan-country-${String(i).padStart(3,'0')}`;row.label=`Scan country ${i}`;
   row.fields.id=row.id;row.fields.name=`Country ${i}`;row.row.id=`bbbbbbbb-bbbb-4bbb-8bbb-${suffix}`;row.row.country_id=row.id;row.row.fields.name=row.fields.name;row.row.fields.translations.en.method='human-translation';
   view.countries.push(row);catalogEntries.push({id:row.id,label:row.label,fields:row.fields,writers:[]});}
  view.mocks['@/lib/editorial-catalog']={async loadEditorialCatalog(){return{version:1,countries:structuredClone(catalogEntries)};}};
 }else{
  const template=structuredClone(view.writers[0]),rowTemplate=structuredClone(view.rows.get(view.writers[0].id));view.writers.length=0;view.rows.clear();
  for(let i=0;i<total;i++){const item=structuredClone(template),suffix=String(i+1).padStart(12,'0');item.id=`scan_writer_${String(i).padStart(3,'0')}`;item.label=`Scan writer ${i}`;
   item.fields.name=item.label;delete item.fields.biographyTranslations.en;const row=structuredClone(rowTemplate);row.id=`bbbbbbbb-bbbb-4bbb-8bbb-${suffix}`;row.writer_id=item.id;
   row.fields.biographyTranslations={en:{...structuredClone(view.russian),locale:'en',method:'human-translation',text:view.englishText,manualRights:{preserve:'Exact signed English consent'}}};
   view.writers.push(item);view.rows.set(item.id,row);catalogEntries.push(item);}
  view.catalog.countries[0].writers=catalogEntries;
 }
 const paidEntries=[];view.ai.run=async(model,request)=>{paidEntries.push({model,request});throw new Error('Provider forbidden in metadata-only scan capture');};
 const authorRows=()=>kind==='country'?view.countries.map(item=>({id:item.id,row:structuredClone(item.row),fields:structuredClone(item.fields)})):[...view.rows.values()].map(row=>structuredClone(row));
 const sourceRows=()=>catalogEntries.map(item=>({id:item.id,label:item.label,fields:structuredClone(item.fields)}));
 const originalAuthorRows=authorRows(),originalSourceRows=sourceRows(),initialIds=catalogEntries.map(item=>item.id),resumeReads=[];
 const helperIds=wire=>wire.filter(item=>item.method==='GET'&&item.path?.endsWith(kind==='country'?'/country_profile_overrides':'/writer_profile_overrides'))
  .map(item=>String(item.query[kind==='country'?'country_id':'writer_id']).slice(3));
 async function invoke(resume=false){const wireOffset=view.wire.length,runOffset=view.runs.length;
  let redirect;if(!resume){const first=await view.action('initial-scan');redirect=first.redirect;}
  else{
   const previous=view.runs[0],jobId='cccccccc-cccc-4ccc-8ccc-cccccccccccc',oldRpc=view.sdk.rpc.bind(view.sdk);
   const client=createClient(`https://${kind}-scan-resume.fixture.invalid`,'synthetic-no-auth-session',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},global:{fetch:async(resource,init={})=>{
    const url=new URL(typeof resource==='string'?resource:resource.url);assert.equal(url.pathname,'/rest/v1/rpc/get_translation_job_resume');const args=JSON.parse(init.body);assert.deepEqual(args,{p_job_id:jobId});
    const value={id:jobId,kind:kind==='country'?'country':'writer',status:'completed',resumeCursor:structuredClone(previous.p_resume_cursor)};resumeReads.push({args,response:value});return new Response(JSON.stringify(value),{status:200,headers:{'Content-Type':'application/json'}});
   }}});
   view.sdk.rpc=(name,args,config)=>name==='get_translation_job_resume'?client.rpc(name,args,config):oldRpc(name,args,config);
   view.mocks['./article-actions']={async translatePremiumArticleBatchAction(){throw new Error('Unexpected article dispatch');}};
   const form=new FormData();form.set('job_id',jobId);form.set(kind==='country'?'countryCursor':'writerCursor','999');
   try{await view.load('apps/admin/app/(dashboard)/translations/resume-action.ts').resumeTranslationJobAction(form);throw new Error('Actual resume must redirect');}
   catch(error){assert.equal(isRedirectError(error),true,error.stack);redirect=getURLFromRedirectError(error);}
  }
  return{redirect,helperIds:helperIds(view.wire.slice(wireOffset)),freeRuns:structuredClone(view.runs.slice(runOffset))};
 }
 return{view,kind,total,limit,catalogEntries,paidEntries,originalAuthorRows,originalSourceRows,initialIds,authorRows,sourceRows,resumeReads,invoke};
}
async function capture(kind,mutation){const run=setup(kind),first=await run.invoke();assert.equal(first.helperIds.length,run.limit);assert.equal(first.freeRuns[0].p_resume_cursor[`${kind}Cursor`],run.limit);
 const beforeMembership=run.catalogEntries.map(item=>item.id);
 if(mutation==='move-visited-to-tail')run.catalogEntries.push(run.catalogEntries.shift());
 else{
  run.catalogEntries.shift();const template=structuredClone(run.catalogEntries.at(-1));template.id=kind==='country'?'scan-country-new':'scan_writer_new';template.label='New synthetic catalogue member';
  if(kind==='country'){const seed=structuredClone(run.view.countries.at(-1));seed.id=template.id;seed.label=template.label;seed.fields.id=seed.id;seed.row.country_id=seed.id;seed.row.id='dddddddd-dddd-4ddd-8ddd-999999999999';
   run.view.countries.push(seed);template.fields=seed.fields;
  }else{const seed=structuredClone(run.view.rows.get(run.catalogEntries.at(-1).id));seed.writer_id=template.id;seed.id='dddddddd-dddd-4ddd-8ddd-999999999999';run.view.rows.set(template.id,seed);run.view.writers.push(template);}
  run.catalogEntries.push(template);
 }
 const afterMembership=run.catalogEntries.map(item=>item.id),second=await run.invoke(true),seen=[...first.helperIds,...second.helperIds],frequencies=new Map();for(const id of seen)frequencies.set(id,(frequencies.get(id)||0)+1);
 const stillPresent=run.initialIds.filter(id=>afterMembership.includes(id)),omitted=stillPresent.filter(id=>!frequencies.has(id)),repeated=[...frequencies].filter(([,count])=>count>1);
 const currentAuthors=run.authorRows(),protectedAuthors=currentAuthors.filter(row=>run.initialIds.includes(row.writer_id||row.id));
 assert.deepEqual(protectedAuthors,run.originalAuthorRows);
 for(const old of run.originalSourceRows){const current=run.sourceRows().find(row=>row.id===old.id);if(current)assert.deepEqual(current,old);}
 assert.equal(run.paidEntries.length,0);assert.equal(run.view.writes.length,0);assert.equal(run.view.builds.length,0);assert.equal(run.view.server.operations.size,0);
 const sources=[...run.view.graph.values()];for(const source of sources){const bytes=fs.readFileSync(path.join(repo,source.module));assert.equal(sha(bytes),source.sha256);const target=path.join(output,'sources',source.module);fs.mkdirSync(path.dirname(target),{recursive:true});if(!fs.existsSync(target))fs.writeFileSync(target,bytes,{flag:'wx'});}
 return{kind,mutation,initialIds:run.initialIds,beforeMembership,afterMembership,first,second,seen,distinctSeen:[...frequencies.keys()],omitted,repeated,
  secondCursor:second.freeRuns.at(-1).p_resume_cursor[`${kind}Cursor`],originalAuthorRows:run.originalAuthorRows,protectedAuthorRowsExact:true,survivingCatalogSourceRowsExact:true,
  providerCalls:run.paidEntries.length,canonicalWrites:run.view.writes.length,publicBuildRequests:run.view.builds.length,actualResumeReads:run.resumeReads,sources,
  limitation:'A zero legacy cursor is ambiguous, not proof that the existing UI literally claimed100percent corpus completion. The proof exposes missed/repeated still-present IDs at the numeric wrap boundary.'};
}
async function main(){const cases=[];for(const kind of ['country','writer'])for(const mutation of ['move-visited-to-tail','delete-visited-insert-tail'])cases.push(await capture(kind,mutation));
 const report={classification:'GENUINE_PROFILE_CIRCULAR_ARRAY_BEFORE_NOT_ACCEPTANCE_PASS',cases,controls:{executionFailures:0,providerCalls:0,canonicalWrites:0,publicBuildRequests:0},
  scope:'Actual staff sync actions, real profile helpers, runtime/probe/budget, free-run adapter, installed SDK and actual resume-action/native Next redirects execute. Only Auth/catalog/SDK/provider-forbidden boundary is controlled; no normalizer/source edits or live/nativeDBprofile claims.'};
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({output,cases:cases.map(item=>({kind:item.kind,mutation:item.mutation,first:item.first.helperIds.length,second:item.second.helperIds.length,cursor:item.secondCursor,omitted:item.omitted,repeated:item.repeated,providerCalls:item.providerCalls}))}));
}
main().catch(error=>{fs.writeFileSync(path.join(output,'execution-error.json'),JSON.stringify({error:error.stack||String(error)},null,2));console.error(error.stack||String(error));process.exitCode=2;});
