# Profile stable traversal: proposed next slice

This is parent-work design only. The current library slice must be frozen before maintained profile edits start. No implementation or acceptance result is claimed here. The machine-readable contract and case matrix are in `design.json`.

The genuine profile BEFORE uses contract `a988d0df137b66ef6822450d0307fb76222e2c706cc341a2b04a6ee5e5378008`. Its four country/writer mutation cases retain six failures in eight original coverage/no-repeat assertions, with zero execution failures, provider calls, canonical writes or builds. A global catalog fingerprint mismatch that merely stops continuation cannot satisfy those coverage assertions.

## Minimum storage and identity choice

Freeze the entire finite initial profile membership in one transaction using existing jobs and items, split into at most500 members per job. Materialize successor memberships at BEGIN as well: selecting a new successor from a later catalog would reintroduce omissions after500. Countries use exact text IDs; writers use the existing country/writer identity tuple parser. Assign the initial catalog order once to stored positions. Subsequent catalog reorderings never select a different identity for that position.

Use a separate strict `profileScan` marker and new profile scan RPC family for writer/country. Reuse the library protocol's small mechanics, but preserve the UUID-only library RPCs and all existing one-item paid APIs. A bounded hash array in each window stores the initial raw catalog-fields hash per member; at most500 SHA256 strings fit with fixed metadata under a deliberate64KiB marker limit. No source prose, rights copy, raw provider output, new table or new column is needed.

Store full original writer/country source and override information only through the existing private artifact protocols. Do not repurpose scan-parent `source_hash` as an unrelated catalog hash or recompute the legacy JavaScript hashes from reordered JSONB.

## Processing order

1. Require current staff/MFA authorization and derive actor in SQL. Fresh forms submit a per-render UUID; old saved ordinal jobs cannot become a verified prefix, including ordinal0. Raw malformed/nonzero legacy tokens cannot normalize into a new scan.
2. Read and validate the saved window first. Any attached or observed active paid child pins the exact tuple before current catalog, feature or configuration checks. Unknown/partial responses never authorize a fresh call.
3. The operation owner may recover a complete retained answer under the original source/config. Recovery grants no dispatch capability. Foreign unfinished children stay held; confirmed foreign terminal metadata can become one free parent observation. Persisted observed holds require an explicit terminal checkpoint, including zero-call release without advancement.
4. With no paid hold, load the catalog using the existing `loadEditorialCatalog({})` path to bypass the process cache. Resolve the exact stored tuple. A wholly unavailable catalog holds the scan. A missing tuple receives one missing-source disposition; a changed per-member raw catalog hash receives one stale disposition. Neither alters other members' positions. Reorder/global hash drift alone does not stop unchanged original tuples.
5. Call the existing helper for a still-current member. Add a narrow admission callback after owned BEGIN and artifact checks but before any provider dispatch. Attach the actual existing one-item operation to the exact scan item; its source/catalog/config/actor/tuple bindings must match. Add parent-cancellation checks at the cache dispatch boundary without changing old paid routine bodies or lease ACLs.
6. A confirmed terminal result produces one zero-provider parent observation and advances once. Preserve unknown outcomes and zero-call stops. Continue follows only the frozen successor chain and explicitly exhausts the initial set; it never wraps. Bound deadline and successor hops as well as scanned members.

Keep writer3 attempts/12 provider reservations/120 inspected members and country2/8/30, each with300000ms. Writer retains required two-pass review and4000 output tokens; country retains its optional review/repair behavior and12000 tokens. Standalone helper defaults stay1/4/300000.

## Important trust and freshness limits

The catalog lives in private KV/filesystem assets, so PostgreSQL cannot independently attest the current asset from a caller's hash. Server actions construct the bounded manifest and hashes; SQL enforces their structure and immutability, while existing owned paid admission/dispatch and full source/target CAS remain final expense authority. New scan endpoints grant no provider capability. Bypassing the module cache does not claim strong KV/DB atomicity.

Existing catalog-field hashes use exact `JSON.stringify` input order. Preserve that convention and authored fields. A per-member source change should be recorded stale once so other original members still finish; a separate fresh scan can evaluate the changed revision. This preserves coverage without paying against an obsolete catalog seed.

## Verification still required

Keep the original BEFORE sources, raw reports and a988 assertion bytes immutable. Run the same four mutations against current actual actions/helpers/SDK under an explicitly declared new metadata transport, retaining exact author/manual/source/rights assertions. Add native protocol/ACL/concurrency checks and>500 tuple materialization, same writer IDs in different countries, pending deletion, changed member source, unavailable catalog, and explicit fresh/continue UI cases.

Exercise unknown ACKs at every durable boundary, owned complete recovery after config/source removal or cancellation, foreign artifact denial, persisted observed-blocked terminal and zero-call cases. Retain the writer/country caps through conflicts and all review/repair passes. Inspect native child cursor receipts: running/blocked uses CURRENT, ordinary paid terminal uses NEXT, and zero-call skipped terminal remains CURRENT.

M07-T12 remains NOT_RUN for this proposed profile implementation. M07-T03 and full T13 need an independent10-item8success2failure item/version-targeted retry through UI/admin E2E; the existing genuine diagnostic proves only that scan Continue excludes a known failed metadata-read item. Full M07/M24/M04/M02/M13/R3 and managed end-to-end acceptance remain outside this design's claims.
