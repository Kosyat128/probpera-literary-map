# Prepared profile traversal BEFORE — unresolved

This archive preserves the genuine profile BEFORE. It is preparation for the next slice, not an implementation or an M07-T12 acceptance result. The exact original `a988d0df137b66ef6822450d0307fb76222e2c706cc341a2b04a6ee5e5378008` contract reports six failing targets in eight profile assertions. Execution failures, provider calls, canonical writes and public builds are zero.

The canonical frozen tree at `probpera-literary-map/` contains exactly34 application modules copied from the original capture and checked against its source graph, four original runtime/transport support files plus one genuine archived transitive support fixture, and the exact prior evidence archives needed by those runtimes/provenance. The four-file support list omitted its boundary's sibling freshness fixture; that fixture is recovered byte-for-byte from the earlier original library55b archive, with its full archive/entry hashes declared in `portable/transitive-support-provenance.json`. No current application source is relabeled or used as BEFORE, and no missing source is reconstructed. `manifest.json` lists every payload except itself, with byte length and SHA256, safe relative paths and case-insensitive uniqueness.

The genuine original runner and report remain under `work/m07-t12-profile-before-20261030-sol/`. The report SHA256 is `5e86af8425eb38b503ba4ffba17795059ef1cb82e633708b9795c55f9d6887f3`. The full earlier preparation receipt is exact SHA256 `e2446516469885d416ecce1ea1177c9da60ea8cceebd13be19311ac46d0dfd19`; reports it references are retained as explicitly historical preparation records. Their earlier `current` names refer to that captured c482 continuation point and are not substitutes for the canonical BEFORE source tree.

`design/` contains the separate proposed next implementation, source-input bindings and scope limits. Its current-source hashes are design provenance only. A global catalog fingerprint stale-stop does not replace the original surviving-member coverage contract.

## Portable replay

Extract the archive to a fresh directory. Supply an existing installation containing Node.js and the project's SDK/Next/TypeScript/Zod/fflate packages. Dependencies are read from that installation; they are not linked or copied into the frozen source tree. Use a fresh output path:

```text
node portable/replay.cjs --dependency-root <installed-project-directory> --output <new-output-directory>
```

The replayer verifies manifest paths/hashes, the original report/contract/preparation receipt and all34 source bindings. It runs the unchanged original runner with `NODE_PATH` pointing only to installed packages, from a separate output working directory. The archive's two-level work/repository layout preserves the original runner's path semantics; no source loader or assertion is patched. An additional preload forbids global network access. The original SDK transports remain controlled and the original AI boundary rejects all provider work.

Replay executes actual frozen actions, helpers, budgets, stored-job resume, typed RPC adapters and installed SDK/native Next redirects. It compares all original identities, mutations, helper visits, author rows, rights/manual preservation results and source graphs, and applies the unchanged contract. Expected replay result is six target FAIL/eight, zero execution failure/provider/canonical/build counts, and unchanged input hashes. The process exits successfully only when it reproduces those known failures exactly. Generated replay reports are clearly marked as BEFORE reproduction, not acceptance passes.

The profile catalog/Auth/SDK transports are synthetic. No native profile database/RLS, browser/admin E2E, permanent-starvation result, literal UI100% statement, global expense budget or failed-item retry is proved. Full M07, T13 retry and R3 remain unaccepted. No paid/live/production/key action is part of this artifact.
