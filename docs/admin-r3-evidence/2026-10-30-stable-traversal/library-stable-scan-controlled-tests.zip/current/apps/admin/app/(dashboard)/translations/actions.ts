"use server";

import { revalidatePath } from "next/cache";
import { unstable_rethrow } from "next/navigation";
import { z } from "zod";

import { runLibraryTranslationScan, libraryTranslationScanOrdinal } from "@/lib/library-translation-scan";
import { ensureSiteCopyEnglishTranslation } from "@/lib/auto-translate-site-copy-private";
import { ensureWriterEnglishBiography } from "@/lib/auto-translate-writer-biography";
import { requireStaff } from "@/lib/auth";
import {
  loadEditorialCatalog,
  type EditorialCatalog,
} from "@/lib/editorial-catalog";
import { redirect } from "@/lib/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import {
  advanceBackfillCursor,
  circularBackfillIndex,
  normalizeBackfillCursor,
  translationBackfillCursorParams,
} from "@/lib/translation-backfill-cursor";
import { translationErrorCode, type TranslationErrorCode } from "@/lib/translation-errors";
import {
  createTranslationOperationBudget,
  type TranslationOperationBudgetReason,
} from "@/lib/translation-operation-budget";
import { translationOperationBudgetNotice } from "@/lib/translation-operation-budget-notice";
import { profileTranslationBudgetReadiness } from "@/lib/translation-profile-budget-readiness";
import { premiumTranslationRuntimeGate } from "@/lib/translation-runtime-gate";
import {
  recordTranslationSyncRun,
  type TranslationRunItem,
} from "@/lib/translation-run-record";

const SITE_COPY_SYSTEM_KEY = "site-copy-overrides";
const MAX_WRITER_TRANSLATIONS = 3;
const MAX_WRITER_SCAN = 120;
// Bound expensive attempts independently of successful private saves. Reuse the
// article operation ceiling and its translation/repair/review/repair envelope.
const PROFILE_OPERATION_DEADLINE_MS = 300_000;
const MAX_WRITER_PROVIDER_CALLS = MAX_WRITER_TRANSLATIONS * 4;

function objectValue(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};
}

function translationsUrl(values: Record<string, string | number | null | undefined>) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) {
    if (value !== null && value !== undefined && String(value)) {
      params.set(key, String(value));
    }
  }
  return `/translations${params.size ? `?${params}` : ""}`;
}

export async function translatePremiumLibraryBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  const result = await runLibraryTranslationScan({ supabase, actorId: session.user.id,
    scanIntent: String(formData.get("libraryScanIntent") || "").trim() || null,
    jobId: String(formData.get("libraryJob") || "").trim() || null,
    legacyCursor: String(formData.get("libraryCursor") ?? "0") });
  revalidatePath("/translations");
  revalidatePath("/library");
  redirect(translationsUrl({ ...cursorParams,
    libraryJob: result.recoveryJobId,
    libraryCursor: result.receipt ? libraryTranslationScanOrdinal(result.receipt) : cursorParams.libraryCursor,
    errorCode: result.errorCode,
    success: result.receipt === null && result.processed === 0 ? null :
      (result.errorCode && result.errorCode !== "translation_scan_complete" ? "Пакет книг приостановлен. Подтверждённые итоги: " : "Книги: ") +
      `подтверждённо просмотрено ${result.processed}, подтверждённых машинных черновиков ${result.translated}, ожидают проверки ${result.reviewPending}, устаревших ${result.stale}, актуальных ${result.current}, ручных ${result.manual}, пропущено ${result.skipped}, ошибок ${result.failed}. Машинные черновики не опубликованы.` +
      (result.receipt?.exhausted && result.receipt.status !== "cancelled" && result.receipt.status !== "cancelling"
        ? " Сохранённый набор просмотрен; новые записи войдут в новый обход." : "") +
      translationOperationBudgetNotice(result.budget, result.stopReason),
  }));
}
function staticWriterCandidates(editorialCatalog: EditorialCatalog) {
  const candidates: Array<{
    countryId: string;
    writerId: string;
    sourceFields: Record<string, unknown>;
  }> = [];
  for (const country of editorialCatalog.countries) {
    for (const writer of country.writers) {
      const translations = objectValue(writer.fields.biographyTranslations);
      const ru = objectValue(translations.ru);
      const en = objectValue(translations.en);
      const russianEligible =
        ru.locale === "ru" &&
        ru.method === "editorial-original" &&
        new Set(["reviewed", "verified"]).has(String(ru.status)) &&
        typeof ru.text === "string" &&
        ru.text.trim().length >= 120 &&
        Array.isArray(ru.sources) &&
        ru.sources.length > 0;
      const staticManualEnglish =
        en.locale === "en" &&
        en.method !== "machine-translation" &&
        new Set(["reviewed", "verified"]).has(String(en.status));
      if (russianEligible && !staticManualEnglish) {
        candidates.push({
          countryId: country.id,
          writerId: writer.id,
          sourceFields: writer.fields,
        });
      }
    }
  }
  return candidates;
}

export async function translatePremiumWriterBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  }
  const operationBudget = createTranslationOperationBudget({
    maxAttempts: MAX_WRITER_TRANSLATIONS, maxProviderCalls: MAX_WRITER_PROVIDER_CALLS,
    deadlineMs: PROFILE_OPERATION_DEADLINE_MS,
  });
  if (!(await premiumTranslationRuntimeGate(supabase))) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "translation_not_configured" }));
  }

  const budgetReadinessError = await profileTranslationBudgetReadiness(supabase);
  if (budgetReadinessError) redirect(translationsUrl({ ...cursorParams, errorCode: budgetReadinessError }));
  const editorialCatalog = await loadEditorialCatalog();
  const candidates = staticWriterCandidates(editorialCatalog);
  const startCursor = normalizeBackfillCursor(
    cursorParams.writerCursor,
    candidates.length
  );
  let translated = 0;
  let reviewPending = 0;
  let stale = 0;
  let current = 0;
  let manual = 0;
  let skipped = 0;
  let failed = 0;
  let processed = 0;
  let firstError = "";
  let budgetStopReason: TranslationOperationBudgetReason | null = null;
  const runItems: TranslationRunItem[] = [];
  const scanLimit = Math.min(MAX_WRITER_SCAN, candidates.length);
  let operationUnconfirmed = false;
  let cancelled = 0;
  let firstErrorCode: TranslationErrorCode | null = null;

  for (let step = 0; step < scanLimit; step += 1) {
    budgetStopReason = operationBudget.exhaustedReason();
    if (budgetStopReason || translated >= MAX_WRITER_TRANSLATIONS) break;
    const candidate = candidates[
      circularBackfillIndex(startCursor, step, candidates.length)
    ];
    if (!candidate) break;
    const result = await ensureWriterEnglishBiography({
      supabase,
      actorId: session.user.id,
      ...candidate,
      runtimeApproved: true,
      operationBudget,
      operationCursor: {
        current: { writerCursor: advanceBackfillCursor(startCursor, processed, candidates.length) },
        next: { writerCursor: advanceBackfillCursor(startCursor, processed + 1, candidates.length) },
      },
    });
    if (result.state === "unconfirmed") {
      operationUnconfirmed = true;
      firstErrorCode = result.errorCode || "translation_retry_pending";
      budgetStopReason = result.budgetStop?.reason || null;
      break;
    }
    if (result.budgetStop && result.budgetStop.providerCalls === 0) {
      budgetStopReason = result.budgetStop.reason;
      break;
    }
    processed += 1;
    if (result.state === "cancelled") {
      cancelled += 1;
      firstErrorCode = "translation_operation_stopped";
      budgetStopReason = "stopped";
      operationBudget.stop();
      break;
    }
    const runState = result.state === "not-ready" ? "failed" : result.state;
    if (result.operation?.receipt?.phase !== "finished") runItems.push({
      entityId: `${candidate.countryId}/${candidate.writerId}`,
      state: runState,
      error: result.error,
      model: result.model,
    });
    if (result.budgetStop) {
      budgetStopReason = result.budgetStop.reason;
      failed += 1;
      firstError = result.error || "";
      break;
    }
    if (runState === "translated") translated += 1;
    else if (runState === "review-pending") reviewPending += 1;
    else if (runState === "stale") stale += 1;
    else if (runState === "current") current += 1;
    else if (runState === "manual") manual += 1;
    else if (runState === "failed") {
      failed += 1;
      firstError = result.error || "";
      firstErrorCode = result.errorCode || null;
      break;
    } else if (runState === "conflict") failed += 1;
    else skipped += 1;
  }
  const nextWriterCursor = advanceBackfillCursor(
    startCursor,
    processed,
    candidates.length
  );
  const budget = operationBudget.snapshot();
  try {
    await recordTranslationSyncRun({
      supabase,
      kind: "writer",
      items: runItems,
      resumeCursor: { writerCursor: nextWriterCursor, writerBudget: { version: 1, ...budget, stopReason: budgetStopReason } },
    });
  } catch (error) {
    unstable_rethrow(error);
    redirect(translationsUrl({ ...cursorParams, errorCode: "translation_run_record_unconfirmed" }));
  }

  revalidatePath("/translations");
  revalidatePath("/editorial-database");
  redirect(
    translationsUrl({
      ...cursorParams,
      success: (operationUnconfirmed ? "Пакет биографий приостановлен. Подтверждённые итоги: " : "Биографии: ") +
        `новых машинных черновиков ${translated}, ожидают проверки ${reviewPending}, устаревших черновиков ${stale}, актуальных ${current}, ручных ${manual}, пропущено ${skipped}, ошибок ${failed}.` +
        (cancelled ? ` Остановлено ${cancelled}.` : "") + " Машинные черновики не опубликованы." + translationOperationBudgetNotice(budget, budgetStopReason),
      errorCode: firstErrorCode || (firstError ? translationErrorCode(firstError) : null),
      writerCursor: nextWriterCursor,
    })
  );
}

export async function translatePremiumSiteCopyBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  }
  if (!(await premiumTranslationRuntimeGate(supabase))) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "translation_not_configured" }));
  }
  const response = await supabase.from("homepage_blocks").select("id,settings,updated_at")
    .contains("settings", { systemKey: SITE_COPY_SYSTEM_KEY })
    .order("updated_at", { ascending: false }).limit(2);
  const rows = z.array(z.object({ id: z.string().uuid(), settings: z.record(z.string(), z.unknown()),
    updated_at: z.string().datetime({ offset: true }) })).max(1).safeParse(response.data);
  if (response.error || !rows.success) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_read_failed" }));
  }
  const existing = rows.data[0];
  if (!existing) {
    redirect(translationsUrl({ ...cursorParams,
      success: "Тексты сайта: русских CMS-переопределений для перевода пока нет." }));
  }
  const result = await ensureSiteCopyEnglishTranslation({ supabase, actorId: session.user.id,
    blockId: existing.id, runtimeApproved: true });
  try {
    await recordTranslationSyncRun({ supabase, kind: "site_copy", items: [{ entityId: existing.id,
      state: result.state === "not-ready" ? "not-configured" : result.state,
      error: result.error, model: result.model }] });
  } catch {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_write_failed" }));
  }
  revalidatePath("/translations");
  revalidatePath("/site-copy");
  if (result.state === "failed" || result.state === "not-ready" || result.state === "not-configured" ||
      result.state === "conflict") {
    redirect(translationsUrl({ ...cursorParams, errorCode: result.state === "conflict" ? "write_conflict"
      : result.state === "not-ready" ? "translation_migration_required"
        : result.state === "not-configured" ? "translation_not_configured" : translationErrorCode(result.error) }));
  }
  const success = result.state === "translated" || result.state === "review-pending"
    ? "Тексты сайта: машинный черновик сохранён и ожидает вашей проверки. Он не опубликован."
    : result.state === "stale"
      ? "Тексты сайта: сохранённый машинный черновик устарел. Проверьте или отклоните его перед новым переводом."
      : result.state === "manual" ? "Тексты сайта: ручной английский текст сохранён без изменений."
        : "Тексты сайта: новых строк для перевода нет.";
  redirect(translationsUrl({ ...cursorParams, success }));
}
