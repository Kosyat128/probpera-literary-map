import type { SupabaseClient } from "@supabase/supabase-js";
import { unstable_rethrow } from "next/navigation";
import { z } from "zod";

import { translateSiteCopyBatchToEnglish, translationSourceHash } from "./auto-translate-site-copy";
import { premiumTranslationRuntimeMetadata } from "./premium-translation-runtime";
import {
  PremiumTranslationDraftError, premiumTranslationCandidateOutcome, readPremiumTranslationWorkingDraft,
  samePremiumTranslationJson, stagePremiumTranslationWorkingDraft,
  type PremiumTranslationCandidateOutcome,
} from "./premium-translation-working-draft";
import {
  siteCopyTranslationSource, validateSiteCopyTranslationCandidate, validSiteCopyTranslationKey,
} from "./site-copy-translation-contract";
import { createTranslationOperationBudget, type TranslationOperationBudget } from "./translation-operation-budget";
import { premiumTranslationRuntimeGate } from "./translation-runtime-gate";

const blockSchema = z.object({
  id: z.string().uuid(), updated_at: z.string().datetime({ offset: true }),
  settings: z.record(z.string(), z.unknown()),
});

export type SiteCopyTranslationState = "translated" | "review-pending" | "stale" | "current" |
  "manual" | "skipped" | "not-configured" | "conflict" | "not-ready" | "failed";

export type SiteCopyTranslationResult = {
  state: SiteCopyTranslationState;
  model?: string;
  reviewerModel?: string | null;
  error?: string;
  translatedItems?: number;
  sourceFreshness?: "current" | "stale" | "unknown";
} & Partial<PremiumTranslationCandidateOutcome>;

async function readSiteCopyBlock(supabase: SupabaseClient) {
  try {
    const response = await supabase.from("homepage_blocks").select("id,settings,updated_at")
      .contains("settings", { systemKey: "site-copy-overrides" })
      .order("updated_at", { ascending: false }).limit(2);
    unstable_rethrow(response?.error);
    const parsed = z.array(blockSchema).length(1).safeParse(response?.data);
    return response && !response.error && parsed.success ? parsed.data[0] : null;
  } catch (error) {
    unstable_rethrow(error);
    return null;
  }
}

/** One bounded provider batch; successful output is retained outside canonical copy. */
export async function ensureSiteCopyEnglishTranslation(input: {
  supabase: SupabaseClient;
  actorId: string;
  blockId: string;
  runtimeApproved?: boolean;
  keys?: readonly string[];
  operationBudget?: TranslationOperationBudget;
}): Promise<SiteCopyTranslationResult> {
  if (!z.string().uuid().safeParse(input.blockId).success || !z.string().uuid().safeParse(input.actorId).success ||
      (input.keys && (new Set(input.keys).size !== input.keys.length ||
        input.keys.some(key => !validSiteCopyTranslationKey(key))))) {
    return { state: "failed", error: "Invalid site-copy translation identity" };
  }
  if (!input.runtimeApproved && !(await premiumTranslationRuntimeGate(input.supabase))) {
    return { state: "not-configured" };
  }
  const block = await readSiteCopyBlock(input.supabase);
  if (!block || block.id !== input.blockId) {
    return { state: "failed", error: "Site-copy source could not be read" };
  }
  let source: Awaited<ReturnType<typeof siteCopyTranslationSource>>;
  try { source = await siteCopyTranslationSource(block.settings); }
  catch (error) {
    unstable_rethrow(error);
    return { state: "failed", error: "Site-copy source or English ownership is ambiguous" };
  }
  const targetRevision = { id: block.id, updatedAt: block.updated_at };
  try {
    const pending = await readPremiumTranslationWorkingDraft(input.supabase, {
      entityType: "site_copy", entityId: block.id,
    });
    if (pending) {
      if (pending.entityType !== "site_copy") throw new PremiumTranslationDraftError("unconfirmed");
      const liveByKey = new Map(source.items.map(item => [item.key, item]));
      if (!samePremiumTranslationJson(pending.sourceSnapshot.settings, block.settings) ||
          pending.sourceHash !== await translationSourceHash(pending.sourceSnapshot.items) ||
          pending.sourceSnapshot.items.some(item => !samePremiumTranslationJson(item, liveByKey.get(item.key)))) {
        return { state: "stale", error: "Site-copy source changed; review or discard the saved private candidate" };
      }
      if (!samePremiumTranslationJson(pending.targetRevision, targetRevision)) {
        return { state: "conflict", error: "Site-copy revision changed after the private candidate was saved" };
      }
      validateSiteCopyTranslationCandidate(pending.sourceSnapshot.items, pending.payload);
      return { state: "review-pending", ...premiumTranslationCandidateOutcome(pending),
        translatedItems: pending.payload.items.length, model: pending.provenance.translatorModel,
        reviewerModel: pending.provenance.reviewerModel };
    }
  } catch (error) {
    unstable_rethrow(error);
    return { state: "not-ready", error: "Private translation drafts are unavailable or unconfirmed" };
  }
  const selectedKeys = input.keys ? new Set(input.keys) : null;
  const items = source.items.filter(item => !selectedKeys || selectedKeys.has(item.key)).slice(0, 50);
  if (!items.length) {
    return { state: source.manual ? "manual" : source.current ? "current" : "skipped" };
  }
  const operationBudget = input.operationBudget ?? createTranslationOperationBudget({
    maxAttempts: 1, maxProviderCalls: 4, deadlineMs: 45_000,
  });
  const runtime = premiumTranslationRuntimeMetadata();
  try {
    operationBudget.startAttempt();
    const translated = await translateSiteCopyBatchToEnglish(items.map(({ key, text }) => ({ key, text })), {
      operationBudget,
    });
    if (!translated) return { state: "skipped" };
    const payload = validateSiteCopyTranslationCandidate(items, translated.value);
    const latest = await readSiteCopyBlock(input.supabase);
    const sourceFreshness = !latest ? "unknown" : latest.id !== block.id || latest.updated_at !== block.updated_at ||
      !samePremiumTranslationJson(latest.settings, block.settings) ? "stale" : "current";
    // Retain an already received result even if its source changed. Promotion,
    // unlike private staging, still requires the exact live source and target.
    const saved = await stagePremiumTranslationWorkingDraft(input.supabase, {
      entityType: "site_copy", entityId: block.id,
      sourceHash: await translationSourceHash(items),
      sourceRevision: { blockId: block.id, blockUpdatedAt: block.updated_at },
      targetRevision, sourceSnapshot: { settings: block.settings, items }, payload,
      provenance: {
        provider: runtime.provider, translatorModel: translated.translatorModel,
        reviewerModel: translated.reviewerModel, generatedAt: new Date().toISOString(),
        translatorRequestId: translated.translatorRequestId || null,
        reviewerRequestId: translated.reviewerRequestId || null,
      },
    });
    if (saved.entityType !== "site_copy") throw new PremiumTranslationDraftError("unconfirmed");
    await input.supabase.from("admin_audit_log").insert({
      actor_id: input.actorId, action: "site_copy.auto_translation.staged", entity_type: "site_copy",
      entity_id: block.id, metadata: {
        translated: items.length, source_hash: saved.sourceHash, working_draft_id: saved.id,
        candidate_hash: saved.candidateHash, model: translated.translatorModel,
        reviewer_model: translated.reviewerModel, translator_request_id: translated.translatorRequestId,
        reviewer_request_id: translated.reviewerRequestId,
      },
    });
    return { state: sourceFreshness === "stale" ? "stale" : "translated",
      ...premiumTranslationCandidateOutcome(saved), translatedItems: items.length, sourceFreshness,
      model: translated.translatorModel, reviewerModel: translated.reviewerModel,
      ...(sourceFreshness === "unknown" ? { error: "Private candidate retained; current source freshness could not be confirmed" } : {}) };
  } catch (error) {
    unstable_rethrow(error);
    if (error instanceof PremiumTranslationDraftError && error.code === "conflict") {
      return { state: "conflict", error: "Site-copy source changed while the private translation was being saved" };
    }
    return { state: "failed", error: error instanceof Error ? error.message : "Site-copy private translation failed" };
  }
}
