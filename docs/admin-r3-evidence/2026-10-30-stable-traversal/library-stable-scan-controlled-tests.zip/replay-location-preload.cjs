const fs=require('node:fs'),path=require('node:path'),Module=require('node:module'),{fileURLToPath}=require('node:url');
const dependencyRoot=path.resolve(process.env.REPLAY_DEPENDENCY_REPO||''),packageRoot=path.resolve(process.env.REPLAY_PACKAGE_ROOT||'');
if(!process.env.REPLAY_DEPENDENCY_REPO||!process.env.REPLAY_PACKAGE_ROOT)throw Error('Explicit replay roots are required');
const originals={read:fs.readFileSync,exists:fs.existsSync,stat:fs.statSync},mapping=new Map();
function key(value){try{return path.resolve(value instanceof URL?fileURLToPath(value):String(value)).toLowerCase();}catch{return null;}}
function walk(folder,prefix){for(const entry of fs.readdirSync(folder,{withFileTypes:true})){const current=path.join(folder,entry.name),relative=prefix?prefix+'/'+entry.name:entry.name;if(entry.isDirectory())walk(current,relative);else mapping.set(key(path.join(dependencyRoot,relative)),current);}}
walk(path.join(packageRoot,'current'),'');walk(path.join(packageRoot,'immutable'),'');
function mapped(value){if(typeof value==='number')return value;const lookup=key(value);if(mapping.has(lookup))return mapping.get(lookup);return value;}
function assertSourceBound(value){if(typeof value==='number')return;const lookup=key(value);if(lookup&&lookup.startsWith(key(dependencyRoot)+path.sep)&&!lookup.includes(path.sep+'node_modules'+path.sep)&&/\.(?:tsx?|cjs|mjs|json)$/u.test(lookup)&&!mapping.has(lookup))throw Error('Uncaptured local source read is forbidden: '+path.relative(dependencyRoot,String(value)));}
fs.readFileSync=function(value,...args){assertSourceBound(value);return originals.read.call(this,mapped(value),...args);};
fs.existsSync=function(value){return originals.exists.call(this,mapped(value));};fs.statSync=function(value,...args){return originals.stat.call(this,mapped(value),...args);};
Module.syncBuiltinESMExports();
const oldResolve=Module._resolveFilename;
Module._resolveFilename=function(request,parent,...rest){const base=typeof request==='string'?(path.isAbsolute(request)?request:request.startsWith('.')&&parent?.filename?path.resolve(path.dirname(parent.filename),request):null):null;
 if(base)for(const suffix of['','.cjs','.js','.ts','.tsx','/index.cjs','/index.js'])if(mapping.has(key(base+suffix)))return path.resolve(base+suffix);
 return oldResolve.call(this,request,parent,...rest);
};
const oldJs=Module._extensions['.js'];Module._extensions['.js']=function(module,filename){const target=mapping.get(key(filename));if(target&&filename.endsWith('.cjs'))return module._compile(originals.read(target,'utf8'),filename);return oldJs(module,filename);};
global.fetch=()=>{throw Error('Uncontrolled network is forbidden in this controlled evidence replay');};
