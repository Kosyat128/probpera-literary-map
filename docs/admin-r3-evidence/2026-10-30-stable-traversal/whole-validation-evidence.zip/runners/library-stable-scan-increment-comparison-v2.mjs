import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const work=path.dirname(fileURLToPath(import.meta.url));
const priorPath=path.join(work,'catalog-review-freshness-final-validation-v1/source-before.json');
const currentPath=path.join(work,'library-stable-scan-final-validation-v2/source-before.json');
const prior=JSON.parse(fs.readFileSync(priorPath,'utf8')),current=JSON.parse(fs.readFileSync(currentPath,'utf8'));
const hash=value=>createHash('sha256').update(value).digest('hex');
const before=new Map(prior.files.filter(f=>!f.path.startsWith('docs/')).map(f=>[f.path,f]));
const after=new Map(current.files.filter(f=>!f.path.startsWith('docs/')).map(f=>[f.path,f]));
const changed=[...after.values()].filter(f=>before.has(f.path)&&JSON.stringify(before.get(f.path))!==JSON.stringify(f));
const added=[...after.values()].filter(f=>!before.has(f.path));
const removed=[...before.values()].filter(f=>!after.has(f.path));
assert.equal(prior.validationSourceSha256,'c482dd130803939827a621432a104965cb0a0a35e0df848d4160604ec7e0c0ae');
assert.equal(prior.head,current.head);assert.deepEqual(removed,[]);
assert.deepEqual(changed.map(f=>f.path).sort(),[
 'apps/admin/app/(dashboard)/translations/actions.ts',
 'apps/admin/app/(dashboard)/translations/backfill-cursor.source.test.ts',
 'apps/admin/app/resilience-boundaries.source.test.ts',
 'apps/admin/lib/literary-work-machine-review.integration.test.ts',
 'apps/admin/app/(dashboard)/translations/page.tsx',
 'apps/admin/app/(dashboard)/translations/resume-action.ts',
 'apps/admin/lib/auto-translate-literary-work-safe.ts',
 'apps/admin/lib/auto-translate-literary-work.ts',
 'apps/admin/lib/catalog-admission-routing.integration.test.ts',
 'apps/admin/lib/catalog-translation-operation.ts',
 'apps/admin/lib/fixtures/catalog-admission-runtime.cjs',
 'apps/admin/lib/fixtures/library-batch-budget-cap.cjs',
 'apps/admin/lib/fixtures/profile-library-budget-controls.cjs',
 'apps/admin/lib/profile-library-batch-budgets.integration.test.ts',
].sort());
assert.deepEqual(added.map(f=>f.path).sort(),[
 'apps/admin/app/(dashboard)/translations/library-scan-ui.integration.test.ts',
 'apps/admin/lib/fixtures/library-translation-scan-boundary.cjs',
 'apps/admin/lib/fixtures/library-translation-scan-canonical.cjs',
 'apps/admin/lib/fixtures/library-translation-scan-cases.cjs',
 'apps/admin/lib/fixtures/library-translation-scan-runtime.cjs',
 'apps/admin/lib/library-translation-scan-rpc.integration.test.ts',
 'apps/admin/lib/library-translation-scan-rpc.ts',
 'apps/admin/lib/library-translation-scan.integration.test.ts',
 'apps/admin/lib/library-translation-scan.ts',
 'scripts/database/fixtures/library-translation-stable-scan.sql',
 'supabase/migrations/20261029235455_library_translation_stable_scan.sql',
].sort());
const result={status:'PASS',capturedAt:new Date().toISOString(),head:current.head,
 previousManifestSha256:hash(fs.readFileSync(priorPath)),currentManifestSha256:hash(fs.readFileSync(currentPath)),
 previousSourceCount:before.size,currentSourceCount:after.size,previousSourceFingerprint:prior.validationSourceSha256,currentSourceFingerprint:current.validationSourceSha256,
 changedExisting:changed.map(f=>({path:f.path,beforeSha256:before.get(f.path).sha256,afterSha256:f.sha256})),added,removed,
 unchangedOriginalSourceCount:before.size-changed.length,allChangesMatchDeclaredIncrement:true,
 comparisonExclusion:'docs/ only; every tracked/owned non-doc source compared.'};
fs.writeFileSync(path.join(work,'library-stable-scan-final-validation-v2/increment-source-comparison.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:'PASS',changed:changed.length,added:added.length,unchangedPrevious:result.unchangedOriginalSourceCount,sourceCount:after.size,fingerprint:current.validationSourceSha256}));
