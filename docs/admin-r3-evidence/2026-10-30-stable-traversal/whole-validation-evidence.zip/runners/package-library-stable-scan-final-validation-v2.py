import datetime, hashlib, json, pathlib, zipfile

work = pathlib.Path(__file__).resolve().parent
repo = work.parent / 'probpera-literary-map'
out = work / 'library-stable-scan-final-validation-v2'
destination = repo / 'docs/admin-r3-evidence/2026-10-30-stable-traversal'
sha = lambda value: hashlib.sha256(value).hexdigest()
read = lambda name: json.loads((out / name).read_text(encoding='utf-8-sig'))
def write(name, value):
    (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

tests, run, gates = read('selected-tests-summary.json'), read('selected-tests-receipt.json'), read('gates-summary.json')
before, after, drift = read('source-before.json'), read('source-after-tests.json'), read('source-drift.json')
preservation, increment = read('baseline-preservation.json'), read('increment-source-comparison.json')
assert before['head'] == after['head'] and run.get('finishedAt')
assert before['validationSourceSha256'] == after['validationSourceSha256'] and drift['zeroValidationSourceDrift']
assert preservation['pass'] and increment['status'] == 'PASS'
assert before['validationSourceSha256'] == 'da9ee3fa7dab3dd2ea1f5cc2f5c3aa174bf3c3b9061d2729fd3201fe21ccecbd'
assert len(increment['changedExisting']) == 14 and len(increment['added']) == 11 and increment['unchangedOriginalSourceCount'] == 10440
assert tests['testFileCount'] == 212 and tests['numTotalTests'] == 6532
assert tests['numPassedTests'] == 6526
assert tests['numFailedTests'] == 6 and tests['numPendingTests'] == tests['numTodoTests'] == 0
baseline = repo / 'docs/admin-r3-evidence/2026-10-30-catalog-review-freshness/whole-validation-evidence.zip'
assert sha(baseline.read_bytes()) == '3f6f7b8b3bc02578a92feaaf4f72ed9cc9049453c2c5a7d6c47bacdb660fa6a1'
with zipfile.ZipFile(baseline) as archive:
    old_tests_bytes = archive.read('final/selected-tests-summary.json')
    old_tests = json.loads(old_tests_bytes)
    old_text = archive.read('final/gate-readonly-hyphens.log')
def failures(report):
    return sorted([{'fullName': case['fullName'], 'firstErrors': [text.replace('\r\n', '\n').split('\n')[0] for text in case.get('failureMessages', [])]}
                   for file in report.get('failedFiles', []) for case in file.get('assertionFailures', [])], key=lambda row: row['fullName'])
failure_comparison = {'sameFailureCasesAndFirstErrors': failures(tests) == failures(old_tests), 'baseline': failures(old_tests),
                      'current': failures(tests), 'baselineArchiveSha256': sha(baseline.read_bytes()),
                      'claim': 'Exact cases/first errors; CRLF normalization only. No skip, substitute or reconstructed BEFORE.'}
write('baseline-failure-comparison.json', failure_comparison)
assert failure_comparison['sameFailureCasesAndFirstErrors']
initial_text = (out / 'gate-readonly-hyphens.log').read_bytes()
initial_lines = initial_text.decode('utf-8-sig').splitlines()
old_lines = old_text.decode('utf-8-sig').splitlines()
assert {line for line in initial_lines if line.startswith('- ')} - {line for line in old_lines if line.startswith('- ')} == {'- docs\\CODEX_ADMIN_EXECUTION_STATE.md'}
assert sum(line.startswith('- ') for line in initial_lines) == 42
text = (out / 'gate-readonly-hyphens-after-doc-correction.log').read_bytes()
text_comparison = {'byteIdenticalToBaseline': text == old_text, 'baselineSha256': sha(old_text), 'currentSha256': sha(text),
                   'findingCount': sum(line.startswith('- ') for line in text.decode('utf-8-sig').splitlines()), 'normalizerWriteFlagUsed': False,
                   'initialGateFindingCount': 42, 'initialGateLogSha256': sha(initial_text),
                   'correctedNewDocumentationHeadingOnly': True, 'originalGateLogRetained': True,
                   'finalReceipt': read('gate-readonly-hyphens-after-doc-correction-receipt.json')}
write('readonly-gate-baseline-comparison.json', text_comparison)
assert text_comparison['byteIdenticalToBaseline'] and text_comparison['findingCount'] == 41
assert gates['passed'] == 4 and all(gate['status'] == 'PASS' or gate['id'] == 'gate-readonly-hyphens' for gate in gates['receipts'])
assert gates['zeroValidationSourceDrift'] and gates['zeroTrackedFileDrift']
assert read('source-after-gates.json')['validationSourceSha256'] == before['validationSourceSha256']
for gate in gates['receipts']:
    receipt = read(gate['id'] + '-receipt.json')
    assert receipt.get('finishedAt') and receipt['status'] == gate['status']
external = []
for name in ['library-stable-scan-controlled-tests.zip', 'sql-evidence.zip', 'next-library-traversal-before.zip', 'next-profile-traversal-before.zip', 'next-profile-traversal-current-1de717.zip']:
    file = destination / name
    external.append({'path': name, 'bytes': file.stat().st_size, 'sha256': sha(file.read_bytes())})
summary = {'schemaVersion': 1, 'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': before['head'],
           'classification': 'LOCAL_LIBRARY_STABLE_TRAVERSAL_VERIFIED_WITH_KNOWN_BASELINE_FAILURES_NOT_FULL_M07_R3',
           'tests': {'files': tests['testFileCount'], 'total': tests['numTotalTests'], 'passed': tests['numPassedTests'],
                     'failed': tests['numFailedTests'], 'pending': 0, 'todo': 0, 'exitCode': run['exitCode'], 'sameSixHistoricalFailures': True},
           'gates': {**gates, 'finalReadonlyLogByteIdenticalToBaseline': True, 'finalReadonlyFindingCount': 41, 'initialReadonlyFindings': 42, 'documentationHeadingCorrectionOnly': True},
           'source': {'nonDocFileCount': after['validationSourceCount'], 'nonDocFingerprint': after['validationSourceSha256'],
                      'fullFileCount': after['trackedFileCount'], 'zeroValidationSourceDrift': True,
                      'changedExistingVersusC482': len(increment['changedExisting']), 'addedVersusC482': len(increment['added']),
                      'unchangedPreviousFiles': increment['unchangedOriginalSourceCount'], 'exclusion': 'docs/ only; all tracked/owned non-doc sources compared.'},
           'preservation': {'pass': True, 'normalizers': len(preservation['normalizers']), 'rulesAndTests': len(preservation['normalizerRulesAndTests']),
                            'ASTScopes': len(preservation['normalizerImportAndCallScopes']), 'oldMigrations': len(preservation['oldMigrations']),
                            'telegramPaths': len(preservation['independentTelegram']), 'packageFiles': len(preservation['packages']), 'writeFlagUsed': False},
           'externalArchives': external,
           'limitations': ['Six historical M02 tests still lack genuine original .tmp/m02-operation-wiring-before inputs; no reconstruction or omission.',
                           'Readonly text gate keeps the exact41 inherited findings. Excluded normalizers/rules/calls/tests unchanged.',
                           'Native SDK/DB, controlled action/SSR and focused counts overlap; these are not230 acceptance criteria.',
                           'Library windows freeze at most500 members with a UUID high-water/keyset successor. Behind-boundary/newer inserts require explicit fresh scope; no immutable all-future corpus claim.',
                           'Staff synchronous requests remain bounded60 inspected members/4 attempts/16 reservations/300000ms plus60 successor hops. No service lease grant/background execution claim.',
                           'Cancellation guards the actual attached window. A stopped historical window cannot be resumed through its successor shortcut; already active successor windows are separate jobs and are not retroactively cancelled by an ancestor flag.',
                           'Profile traversal remains genuine unresolved BEFORE and CURRENT6/8 failures;42 current code bindings match final da9 source. The proposed full tuple manifest design remains parent-only.',
                           'Partial-pass replay, global concurrency/billing budgets, addressed operator retry and full M07/M24/M04/M02/M13/R3 remain pending.',
                           'No real keys/setup, paid provider, managed/browser acceptance, production migration/deploy, push, PR or social send. Full26-module/230-criterion goal remains active.']}
write('validation-summary.json', summary)
entries = {'final/' + file.name: file.read_bytes() for file in out.iterdir() if file.is_file() and file.suffix in ['.json', '.log', '.txt', '.md']}
for name in ['library-stable-scan-final-validation-v2-runner.mjs', 'library-stable-scan-preservation-v2.mjs',
             'library-stable-scan-increment-comparison-v2.mjs', 'package-library-stable-scan-final-validation-v2.py',
             'library-stable-scan-post-documentation-check-v2.mjs', 'library-stable-scan-final-readonly-v2.mjs']:
    entries['runners/' + name] = (work / name).read_bytes()
for name in ['library-stable-scan-profile-source-preservation.json', 'library-stable-scan-profile-before-root-integrity.json',
             'library-stable-scan-profile-before-root-source-bindings.json', 'library-stable-scan-profile-before-receipt-original.json']:
    entries['root/' + name] = (work / name).read_bytes()
history = work / 'library-stable-scan-final-validation-v1'
for file in history.iterdir():
    if file.is_file() and file.suffix in ['.json', '.log', '.txt', '.md']:
        entries['history/broad-v1/' + file.name] = file.read_bytes()
initial = json.loads((history / 'selected-tests-summary.json').read_text(encoding='utf-8-sig'))
assert initial['numTotalTests'] == 6532 and initial['numFailedTests'] == 11 and initial['numPassedTests'] == 6521
entries['root/profile-current-root-integrity.json'] = (out / 'profile-current-root-integrity.json').read_bytes()
for name in ['library-stable-scan-controlled-independent-integrity.json', 'library-stable-scan-controlled-independent-assertions.json']:
    entries['root/' + name] = (work / name).read_bytes()
entries['root/original-controlled-outer-receipt.json'] = (work / 'library-stable-scan-controlled-count-audit/original-outer-receipt.json').read_bytes()
for name in ['sql-evidence.receipt.json', 'library-stable-scan-controlled-tests.receipt.json', 'library-stable-scan-controlled-tests.errata.json', 'library-stable-scan-focused-final214.raw.json']:
    entries['external-receipts/' + name] = (destination / name).read_bytes()
focused = json.loads(entries['external-receipts/library-stable-scan-focused-final214.raw.json'])
assert sha(entries['external-receipts/library-stable-scan-focused-final214.raw.json']) == '3b20af8082641306a9c5a178ab6d302eb7948d144d950eef88f463edd9093e34'
assert focused['numTotalTests'] == focused['numPassedTests'] == 214 and focused['numFailedTests'] == focused['numPendingTests'] == focused['numTodoTests'] == 0
entries['baseline/selected-tests-summary.json'] = old_tests_bytes
entries['baseline/gate-readonly-hyphens.log'] = old_text
entries['README.md'] = ('# Library stable traversal verification\n\n'
    'The final212-file broad suite and all five gates bind final/validation-summary.json.\n'
    '6526/6532 pass; exactly six historical M02 missing-original cases remain. The\n'
    'readonly gate is the exact prior41 findings; four other gates pass. No skipped\n'
    'case, reconstructed BEFORE, excluded normalizer edit or dependency change.\n\n'
    'Actual actions/helpers/SDK use stable UUID window membership and explicit\n'
    'completion. Formal paid child attachment precedes dispatch; unknown calls pin\n'
    'identity before current eligibility/config. Terminal metadata advances once\n'
    'through its own free logical observation, never a second paid attempt.\n'
    'Zero-call cleanup holds position. Explicit fresh commands replace legacy\n'
    'numeric restart; cancellation and complete retained-body recovery are separate.\n\n'
    'The initial broadV1 6521/6532 with11 failures is retained as history; finalV2 fixes five SDK/static/UI compatibility issues without weakening old assertions.\n\n'
    'Initial V2 readonly gate found42 files:41 inherited plus one newly authored documentation heading. Only that heading was corrected; the separately retained readonly rerun is byte-identical to the previous41-file baseline. No application source changed.\n\n'
    'Consult separate native/controlled archives for exact contracts, preserved\n'
    'initial failures, actual sessions, advisors/lint limits and cleanup. Profile\n'
    'BEFORE and proposal remain unresolved. Whole M07 and full R3 are not accepted.\n').encode()
manifest = {'schemaVersion': 1, 'head': before['head'], 'classification': summary['classification'],
            'sourceFingerprint': after['validationSourceSha256'],
            'entries': [{'path': name, 'bytes': len(value), 'sha256': sha(value)} for name, value in sorted(entries.items())]}
entries['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
archive_path = destination / 'whole-validation-evidence.zip'
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for name, value in sorted(entries.items()): archive.writestr(name, value)
with zipfile.ZipFile(archive_path) as archive:
    for row in manifest['entries']: assert sha(archive.read(row['path'])) == row['sha256']
receipt = {'archive': archive_path.name, 'bytes': archive_path.stat().st_size, 'sha256': sha(archive_path.read_bytes()),
           'verifiedPayloads': len(manifest['entries']), 'manifestSha256': sha(entries['manifest.json']),
           'sourceFingerprint': after['validationSourceSha256'], 'testFiles': tests['testFileCount'],
           'testsPassed': tests['numPassedTests'], 'testsFailed': 6, 'gatesPassed': 4, 'gatesTotal': 5,
           'readonlyBaselineFindings': 41, 'sameSixHistoricalFailures': True, 'zeroValidationSourceDrift': True}
(destination / 'whole-validation-evidence.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
