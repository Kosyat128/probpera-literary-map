const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {createRequire}=require('node:module'),{execFileSync}=require('node:child_process');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),supportFile=path.join(repo,'apps/admin/lib/fixtures/library-batch-budget-cap.cjs');
const supportBytes=fs.readFileSync(supportFile),support=supportBytes.toString('utf8'),boundary=support.indexOf('\nasync function main()');assert.ok(boundary>0);
const requireSupport=createRequire(supportFile),nativeRequire=createRequire(path.join(repo,'package.json'));
const {createClient}=nativeRequire('@supabase/supabase-js'),{isRedirectError}=nativeRequire('next/dist/client/components/redirect-error'),{getURLFromRedirectError}=nativeRequire('next/dist/client/components/redirect');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex'),database=process.env.M07_T12_DATABASE;
assert.match(database||'',/^translation_t12_v\d+_20261030$/);
const pgBin='C:/Users/685F~1/DOCUME~1/Codex/2026-1~1/v/work/PORTAB~1/POSTGR~1.11-/pgsql/bin',psql=path.join(pgBin,'psql.exe');
const out=path.join(__dirname,process.env.M07_T12_OUTPUT||'run-v1');assert.equal(fs.existsSync(out),false);fs.mkdirSync(out,{recursive:true});
const sqlDir=path.join(out,'native');fs.mkdirSync(sqlDir);let sqlSerial=0;
function query(sql,parse=true){const n=++sqlSerial,file=path.join(sqlDir,String(n).padStart(4,'0')+'.sql');fs.writeFileSync(file,sql);let raw;try{raw=execFileSync(psql,['-h','127.0.0.1','-p','55438','-U','postgres','-d',database,'--no-psqlrc','--set=ON_ERROR_STOP=1','-qAt','-f',file],{env:{...process.env,PGCLIENTENCODING:'UTF8'},encoding:'utf8',stdio:['ignore','pipe','pipe']});}catch(e){fs.writeFileSync(file+'.stdout.log',e.stdout||'');fs.writeFileSync(file+'.stderr.log',e.stderr||'');throw e;}fs.writeFileSync(file+'.stdout.log',raw);fs.writeFileSync(file+'.stderr.log','');return parse?JSON.parse(raw.trim()):raw;}
const sourceInputs=[];
function source(file){const bytes=fs.readFileSync(path.join(repo,file));sourceInputs.push({file,sha256:sha(bytes),bytes:bytes.length});const target=path.join(out,'input-sources',file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes);return bytes.toString('utf8');}
const archive=source('supabase/migrations/20260730_literary_archive.sql'),translations=source('supabase/migrations/20260808_book_translations_and_import_staging.sql'),cms=source('supabase/migrations/20260728_cms_foundation.sql');
function table(sql,name){const start=sql.indexOf('create table if not exists public.'+name+' (');assert.ok(start>=0);const end=sql.indexOf('\n);',start);assert.ok(end>start);return sql.slice(start,end+3);}
const clock=cms.match(/create or replace function public\.set_updated_at\(\)\r?\nreturns trigger[\s\S]*?\r?\n\$\$;/)?.[0];assert.ok(clock);
const triggerStart=translations.indexOf('drop trigger if exists literary_work_translations_set_updated_at'),triggerEnd=translations.indexOf('for each row execute function public.set_updated_at();',triggerStart)+'for each row execute function public.set_updated_at();'.length;
assert.ok(triggerStart>0&&triggerEnd>triggerStart);
query([table(archive,'literary_works'),table(translations,'literary_work_translations'),table(translations,'literary_work_sources'),clock,translations.slice(triggerStart,triggerEnd)].join('\n'),false);
const runtime=new Function('require','__dirname','__filename','process',support.slice(0,boundary)+'\nreturn {load,mocks,entries,wire,runs,ai,calls,writes,builds,revalidations,graph,controlledProcess,fetchBoundary};')
 (requireSupport,path.dirname(supportFile),supportFile,{env:{LIBRARY_BUDGET_REPO:repo,LIBRARY_BUDGET_SOURCE_ROOT:repo,LIBRARY_BUDGET_OUTPUT_ROOT:path.join(out,'actual-graph')}});
const template=structuredClone(runtime.entries[0]),stamp='2026-10-29T19:00:00.123456+00:00';
function entry(i){const e=structuredClone(template),suffix=String(i+1).padStart(12,'0'),id=`bbbbbbbb-bbbb-4bbb-8bbb-${suffix}`;
 Object.assign(e.work,{id,legacy_id:'scan-'+suffix,country_id:'fixture-country',writer_id:'fixture-writer',slug:'scan-'+suffix,genres:[],tags:[],description:'',source_url:null,reviewed_at:null,created_at:stamp});
 Object.assign(e.russian,{id:`cccccccc-cccc-4ccc-8ccc-${suffix}`,work_id:id,created_at:stamp,updated_at:i<10?stamp:new Date(Date.parse(stamp)+i*1000).toISOString()});
 Object.assign(e.english,{id:`dddddddd-dddd-4ddd-8ddd-${suffix}`,work_id:id,translation_method:'human-translation',created_at:stamp});
 e.sources.forEach((s,j)=>Object.assign(s,{id:`eeeeeeee-eeee-4eee-8eee-${String(i*10+j+1).padStart(12,'0')}`,work_id:id,created_at:stamp}));return e;}
function insert(list){for(const [name,rows]of [['literary_works',list.map(e=>e.work)],['literary_work_translations',list.flatMap(e=>[e.russian,e.english])],['literary_work_sources',list.flatMap(e=>e.sources)]])query(`insert into public.${name} select * from jsonb_populate_recordset(null::public.${name},'${JSON.stringify(rows).replaceAll("'","''")}'::jsonb);`,false);}
function snapshot(){return query("select jsonb_build_object('works',(select jsonb_agg(to_jsonb(t) order by id) from public.literary_works t),'translations',(select jsonb_agg(to_jsonb(t) order by id) from public.literary_work_translations t),'sources',(select jsonb_agg(to_jsonb(t) order by id) from public.literary_work_sources t));");}
const providerCalls=[],requests=[],scans=[],helperReads=[];let phase='setup';
runtime.ai.run=async()=>{providerCalls.push({phase});throw Error('No provider permitted in manual-ownership traversal proof');};
const tables=new Set(['literary_works','literary_work_translations','literary_work_sources']);
function literal(s){return "'"+s.replaceAll("'","''")+"'";}
function column(s){assert.match(s,/^[a-z_]+$/);return s;}
const fetchBoundary=async(resource,init={})=>{
 const url=new URL(typeof resource==='string'?resource:resource.url),method=init.method||'GET',name=url.pathname.split('/').at(-1),params=url.searchParams;
 if(!tables.has(name)||!['GET','HEAD'].includes(method))return runtime.fetchBoundary(resource,init);
 const conditions=[];
 for(const [k,v]of params){if(['select','order','offset','limit'].includes(k))continue;const key=column(k);
  if(v.startsWith('eq.'))conditions.push(`${key}=${literal(v.slice(3))}`);
  else if(v.startsWith('in.'))conditions.push(`${key} in (${v.slice(4,-1).split(',').map(literal).join(',')})`);
  else throw Error('Unsupported actual SDK read predicate '+k+'='+v);
 }
 const where=conditions.length?' where '+conditions.join(' and '):'';
 const columns=(params.get('select')||'*').split(',').map(c=>c==='*'?'*':column(c)).join(',');
 const order=params.get('order');let orderSql='';if(order){const parts=order.split('.');assert.ok(parts.length===2&&['asc','desc'].includes(parts[1]));orderSql=' order by '+column(parts[0])+' '+parts[1];}
 const offset=Number(params.get('offset')||0),limit=params.has('limit')?Number(params.get('limit')):null;
 assert.ok(Number.isSafeInteger(offset)&&offset>=0&&(limit===null||Number.isSafeInteger(limit)&&limit>=0));
 const base=`from public.${name}${where}`,count=query('select count(*) '+base+';');
 const data=method==='HEAD'?null:query(`select coalesce(jsonb_agg(to_jsonb(t)),'[]'::jsonb) from(select ${columns} ${base}${orderSql}${limit===null?'':' limit '+limit} offset ${offset}) t;`);
 const request={phase,method,name,params:Object.fromEntries(params),nativeCount:count,nativeRows:data};requests.push(request);
 if(name==='literary_work_translations'&&columns==='work_id'&&method==='GET')scans.push(request);
 if(name==='literary_works'&&params.get('id')?.startsWith('eq.'))helperReads.push({phase,id:params.get('id').slice(3)});
 return new Response(method==='HEAD'?null:JSON.stringify(data),{status:200,headers:{'Content-Type':'application/json','Content-Range':`0-${Math.max(0,count-1)}/${count}`}});
};
// Controlled readiness/selftest/free journal transport stays separate from the
// real native3-table content reads. No real Auth/RLS/PostgREST claim.
const sdk=createClient('https://library-budget.fixture.invalid','synthetic-no-auth-session',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},global:{fetch:fetchBoundary}});
runtime.mocks['@/lib/supabase/server']={async createServerSupabaseClient(){return sdk;}};
const statusBefore=execFileSync('git',['status','--porcelain'],{cwd:repo,encoding:'utf8'}),head=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();
async function action(label,params={}){phase=label;const before=helperReads.length,runsBefore=runtime.runs.length,scansBefore=scans.length,form=new FormData();for(const [k,v]of Object.entries(params))form.set(k,String(v));let redirect;
 try{await runtime.load('apps/admin/app/(dashboard)/translations/actions.ts').translatePremiumLibraryBatchAction(form);}catch(e){assert.equal(isRedirectError(e),true,e.stack);redirect=getURLFromRedirectError(e);}assert.ok(redirect);
 return {phase,redirect,params:Object.fromEntries(new URL(redirect,'https://fixture.invalid').searchParams),helperIds:helperReads.slice(before).map(x=>x.id),scans:structuredClone(scans.slice(scansBefore)),runs:structuredClone(runtime.runs.slice(runsBefore))};}
function comparison(before,after,{deletedId=null,updatedId=null,insertedId=null}){
 const old=structuredClone(before),now=structuredClone(after);
 for(const table of ['works','translations','sources']){if(deletedId)old[table]=old[table].filter(r=>(table==='works'?r.id:r.work_id)!==deletedId);if(insertedId)now[table]=now[table].filter(r=>(table==='works'?r.id:r.work_id)!==insertedId);}
 if(updatedId){for(const rows of [old.translations,now.translations])for(const r of rows)if(r.work_id===updatedId&&r.locale==='ru')delete r.updated_at;}
 return {allUndeclaredFieldsExact:JSON.stringify(old)===JSON.stringify(now),allHumanEnglishExact:JSON.stringify(old.translations.filter(r=>r.locale==='en'))===JSON.stringify(now.translations.filter(r=>r.locale==='en')),allSourcesAndRightsExact:JSON.stringify(old.sources)===JSON.stringify(now.sources)};
}
const cases=[];
async function scenario(kind){query('truncate public.literary_work_sources,public.literary_work_translations,public.literary_works;',false);runtime.entries.splice(0,runtime.entries.length,...Array.from({length:62},(_,i)=>entry(i)));insert(runtime.entries);
 const before=snapshot(),initialIds=runtime.entries.map(e=>e.work.id),tieCounts=query("select jsonb_build_object('maxTie',(select max(n) from(select count(*) n from public.literary_work_translations where locale='ru' group by updated_at)x),'ruCount',count(*)) from public.literary_work_translations where locale='ru';");
 assert.equal(tieCounts.ruCount,62);assert.equal(tieCounts.maxTie,10);
 const first=await action(kind+'-first');assert.equal(first.helperIds.length,60);assert.equal(first.params.libraryCursor,'60');
 const mutation={kind,updatedId:null,deletedId:null,insertedId:null};
 if(kind==='update-visited'){mutation.updatedId=first.helperIds[0];query(`update public.literary_work_translations set updated_at=now() where work_id=${literal(mutation.updatedId)} and locale='ru';`,false);}
 else if(kind==='delete-visited'){mutation.deletedId=first.helperIds[0];query(`delete from public.literary_works where id=${literal(mutation.deletedId)};`,false);}
 else{const added=entry(1000);added.russian.updated_at='2026-10-01T00:00:00.000000Z';mutation.insertedId=added.work.id;runtime.entries.push(added);insert([added]);}
 const afterMutation=snapshot(),preservation=comparison(before,afterMutation,mutation);assert.ok(Object.values(preservation).every(Boolean),'Only declared fixture mutation may change native data');
 const second=await action(kind+'-resume',{libraryCursor:first.params.libraryCursor});const after=snapshot();assert.deepEqual(after,afterMutation,'Actual batch must not modify any native content');
 const counts=new Map();for(const id of [...first.helperIds,...second.helperIds])counts.set(id,(counts.get(id)||0)+1);
 const omitted=initialIds.filter(id=>!counts.has(id)),repeated=initialIds.filter(id=>(counts.get(id)||0)>1),checks=[
  {name:'All initial eligible snapshot members reached before cursor wraps',category:'target',pass:omitted.length===0,actualOmitted:omitted},
  {name:'Continuation does not revisit an already inspected manual member',category:'target',pass:repeated.length===0,actualRepeated:repeated}];
 assert.equal(second.params.libraryCursor,'0');assert.equal(providerCalls.length,0);assert.equal(runtime.calls.length,0);assert.equal(runtime.writes.length,0);assert.equal(runtime.builds.length,0);
 const value={kind,mutation,tieCounts,first,second,initialIds,distinctSeen:counts.size,omittedInitialIdsAtCursorWrap:omitted,repeatedInitialIds:repeated,counts:Object.fromEntries(counts),preservation,nativeContentBefore:before,nativeContentAfterDeclaredMutation:afterMutation,nativeContentAfterAction:after,checks,executionFailures:0,providerCalls:0,canonicalWritesByAction:0,publicBuilds:0};cases.push(value);
 fs.writeFileSync(path.join(out,kind+'.json'),JSON.stringify(value,null,2));console.log(JSON.stringify({kind,first:first.helperIds.length,resume:second.helperIds.length,distinct:counts.size,omitted:omitted.length,repeated:repeated.length,cursor:second.params.libraryCursor,providerCalls:0}));}
async function main(){for(const kind of ['update-visited','delete-visited','insert-before-cursor'])await scenario(kind);
 const graph=[...runtime.graph.values()].sort((a,b)=>a.module.localeCompare(b.module));for(const s of graph)assert.equal(sha(fs.readFileSync(path.join(repo,s.module))),s.sha256);
 assert.equal(execFileSync('git',['status','--porcelain'],{cwd:repo,encoding:'utf8'}),statusBefore,'No maintained edits during proof');
 const packages=['@supabase/supabase-js','typescript','next','zod'].map(name=>({name,version:JSON.parse(fs.readFileSync(path.join(repo,'node_modules',name,'package.json'),'utf8')).version}));
 const report={mode:'Genuine unresolved BEFORE: native-backed actual library action bounded-sweep omission; not permanent starvation proof',head,database,executionFailures:0,targetFailures:cases.flatMap(x=>x.checks).filter(x=>!x.pass).length,checks:cases.flatMap(x=>x.checks),cases:cases.map(({nativeContentBefore,nativeContentAfterDeclaredMutation,nativeContentAfterAction,...x})=>x),sourceInputs,sourceGraph:graph,sourceCount:graph.length,support:{file:path.relative(repo,supportFile).replaceAll('\\','/'),sha256:sha(supportBytes)},packages,providerCalls:0,canonicalWritesByAction:0,publicBuilds:0,sourceUnchanged:true,repositoryStatusUnchanged:true,
  boundaries:['Actual library action/safe helper/inner manual ownership/probe/runtime/budget/cursor/run DTO/native Next redirect execute; all human EN yields zero provider calls. Premium provider is trapped, not stubbed success.',
   'Installed SDK serializes actual table/count/order/range queries. Real isolated PG17 executes exact extracted original canonical3-table DDL/constraints plus real now() function/RU update trigger; all content/count/order/helper reads are native. Auth/readiness/probe/free-run journal transport remains controlled and separately recorded; no real PostgREST/RLS/Auth/provider claim.',
   'Native insert/delete/update controls are declared; all other RU/EN/source/licence/rights values remain exact and the batch performs no native writes.',
   'This proves an original bounded-sweep member omission and/or duplicate at numeric cursor wrap under the specific mutations. It does NOT prove permanent starvation or a UI100% claim. Profile cursor risks are source inference only until a separate actual profile scenario executes.',
   'Original updated_at order lacks tie-breaker; ten RU rows have exactly equal timestamps. Equal dates are present in the native proof; tie-only nondeterministic selection is not separately claimed.']};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));fs.writeFileSync(path.join(out,'sdk-wire.json'),JSON.stringify({requests,controlledBoundary:runtime.wire,runs:runtime.runs},null,2));fs.writeFileSync(path.join(out,'support-original.cjs'),supportBytes);
 const contract=`const assert=require('node:assert/strict');module.exports=function(report){assert.equal(report.executionFailures,0);assert.equal(report.providerCalls,0);const target=report.cases.flatMap(c=>[{name:c.kind+':all-original-members-seen',pass:c.omittedInitialIdsAtCursorWrap.length===0},{name:c.kind+':no-repeat-within-sweep',pass:c.repeatedInitialIds.length===0}]);return{executionFailures:0,targetFailures:target.filter(x=>!x.pass).length,target};};\n`;
 fs.writeFileSync(path.join(out,'same-contract.cjs'),contract);console.log(JSON.stringify({report:path.join(out,'report.json'),executionFailures:0,targetFailures:report.targetFailures,sourceCount:graph.length}));process.exitCode=report.targetFailures?1:0;}
main().catch(e=>{fs.writeFileSync(path.join(out,'execution-error.json'),JSON.stringify({error:e.stack,requests,scans,helperReads,providerCalls},null,2));console.error(e.stack);process.exitCode=2;});
