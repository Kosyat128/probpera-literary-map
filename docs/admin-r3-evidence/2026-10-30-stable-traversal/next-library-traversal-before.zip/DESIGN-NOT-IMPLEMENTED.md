# M07-T12 next design — read only

Strict GPT-6.1 Sol / Ultra. Parent preparation only during root c482 freeze.
No maintained source/test/SQL edits. No new migration or service-role runner.

## Requirement and observed boundary

M07-T12 requires stable traversal with a tie-breaker/fixed set/keyset or a proven
equivalent when insert/delete/update changes the set and updated_at values tie.
It forbids endless omission/repetition and false full progress from OFFSET.

The actual library action orders reviewed/verified RU translations only by
updated_at ascending and applies range(startCursor,...). There is no unique
tie-breaker. start and next cursors are offsets modulo a newly read live count.
Writer/country traversal indexes a newly loaded catalogue/candidate array modulo
its current length. Those profile risks are source inference, not native proof.

The native-backed library BEFORE proves a bounded-sweep omission, not permanent
starvation or an actual UI100% statement.62 reviewed RU/human EN records include
10 exactly equal RU timestamps. Actual first action classifies60 manually owned
records, so0provider requests. Updating a visited RU timestamp then resuming60
reads2, wraps0, sees61 distinct initial members, omits1 and repeats1. Deleting a
visited work yields60+1,1omitted/0repeat/wrap0. Inserting before the cursor yields
60+3,all62 original seen but1repeat; the new inserted member is deferred. Every
undeclared text/EN/source/licence/rights field remains exact. It is not a paid
retention, Auth/RLS or real PostgREST proof.

## Highest priority: finite stable library window

Reuse the already implemented article scan pattern, not its article-only RPCs:
unique work_id UUID order, an initial upperId, bounded frozen pending IDs and an
explicit nextIndex/exhausted state. Select ONLY locale=ru and reviewed|verified.
Order work_id ASC (RU work+locale is unique), work_id<=upperId, and work_id>afterId
for each new window. No OFFSET or updated_at order. A second updated_at tie-break
alone is insufficient because updating a timestamp still changes its position.

Materialize up to500 IDs in existing translation_jobs/items before inspecting
them.500 is the existing item-position/job bound and article pending-window cap;
keep the current per-request library scan60, paid attempts4/provider reservations16
and shared deadline300000 unchanged. Resume inspects the exact pending identities,
reloading live rows for existing cheap eligibility/manual/current/pending guards.
Deleted/no-longer-eligible IDs become a real skipped/stale observation exactly
once; they do not shift a later identity. Source text/rights are not frozen into
operational JSON. Existing paid private cache captures their full current seed.

At window completion, afterId becomes the last recorded ID, not a live OFFSET or
last successful paid item. Appending a new window uses stable ID keyset under the
original upper bound. Inserts behind an already completed boundary are deferred
to an explicit fresh scan; this is a documented read/window snapshot, not an
immutable global archive membership claim. Completion means the confirmed bounded
scope has no remaining identities at that read, never all future material.

## Proposed strict metadata DTO (not an implemented API)

```ts
type LibraryScan = {
  version: 1; order: 'work_id'; upperId: UUID;
  afterId: UUID | null;
  pendingIds: UUID[]; // unique, strictly increasing, <=upperId, max500
  nextIndex: number; //0..pendingIds.length; never modulo
  lastWindow: boolean;
  exhausted: boolean;
};
type ScanOperationLink = {
  jobId: UUID; itemId: UUID; operationId: UUID;
  actorId: UUID; entityType: 'literary_work'|'writer_biography'|'country';
  entityId: string; intentHash: Hash64; sourceHash: Hash64;
  configurationHash: Hash64;
};
type ScanReceipt = {
  version: 1; mode: 'staff-bounded-sync-resume';
  jobId: UUID; jobVersion: string; kind: 'literary_work'|'writer'|'country';
  actorId: UUID; configurationHash: Hash64;
  cursor: {libraryScan: LibraryScan};
  currentItem: null | {itemId: UUID; position: number; entityId: string;
    operation: ScanOperationLink|null};
};
```

Existing translation_job_items remains membership/order authority; validate that
pendingIds and positions match those actual rows. Existing job/item/attempt state
remains the control plane. No parallel queue/table, provider source/body in JSON,
new role, service lease permission, or background processing claim is needed.
The same job identity/CAS cursor survives each bounded staff HTTP invocation.

Proposed narrow staff RPC responsibilities, names subject to final root design:

1. begin/read bounded scan: actor-bound idempotent job UUID, strict kind/config,
   authoritative recorded membership/cursor/version. Library seed selected on
   the server. Replays return exact binding; identity differences fail40001.
2. attach current operation: scan job+expectedVersion+actual current item UUID,
   existing paid job/item/operation/intent/source/config binding. Native lookup
   verifies its entity and actor, not a client-asserted result. Lock scan only;
   do not add a cache/job lock cycle. Before any provider dispatch the attachment
   must be durably confirmed. If its ACK is lost, read it back; if unconfirmed,
   no dispatch and existing zero-call admission cleanup keeps current position.
3. checkpoint one item: CAS exact current identity and expected version. A free
   observation records its actual classification. A paid observation is verified
   against the exact existing terminal operation receipt; it creates no second
   paid attempt row. Terminal receipt/cursor replay advances once, ACK loss is
   read back. Unexpected/journal failures never claim advancement.
4. complete/append window: CAS exact saved cursor. Empty-tail completion is
   rechecked server-side like the existing article completion helper. A completed
   scan stays exhausted; Continue cannot wrap to a fresh0 implicitly.

## Crucial compatibility: paid cursor bodies already closed

Writer BEGIN accepts ONLY{} or{writerCursor:number}; catalog cursor_valid accepts
ONLY{} or{libraryCursor:number}/{countryCursor:number}. These proven writer/catalog
APIs/cache/migrations must not receive a hidden scan DTO or have their closed
contract silently loosened. Existing article RPCs reject other entity kinds.

Keep the stable scan state in its separate existing job and link existing paid
receipts. Existing helper scalar current/next can denote the current snapshot
ordinal, not an OFFSET into a new live set. Add an optional coordinator hook just
after successful BEGIN and before startAttempt/provider dispatch to confirm the
scan attachment. This is a deliberate TS integration point; no model/provider/
prompt/candidate/private-artifact behavior changes are needed.

On unknown dispatch/response, hold the stable current identity and exact linked
operation irrespective of source/country count/catalogue changes. Read/reconcile
the existing operation first; never reinterpret its scalar cursor against a new
set. No automatic expiry, new UUID/source/provider/config bypass or partial-pass
resend. Finished confirmed candidate recovery advances once; raw body alone does
not. A deadline before first dispatch/zero-call cleanup holds current position.
Completed private output remains retained as now. New scan cancellation stops new
admissions and preserves any accepted unknown child intent; no billing or remote
cancellation guarantee.

The attachment plan deliberately avoids rewriting proven single-item paid BEGIN
to reuse a pre-existing multi-item scan job. Those APIs create their own one-item
jobs and exact integrity proofs. Scan membership references their receipts rather
than duplicating their paid attempts or widening claim/complete privileges.

## Profile strategy and precise data needs

Country catalogue has200 identities; writer catalogue1686. A live eligible-writer
filter can shrink after RU/manual state changes. For stable scan membership use
all catalogue writer identities, fresh cheap helper classification for each, and
closed tuples{countryId,writerId}; country identities remain exact text. Reuse
the existing writer canonical colon identity for scan/paid links, not the legacy
free aggregate slash display identity. Do not rewrite historical IDs.

Minimal bounded alternative: snapshot ordered identities/fingerprint, not text.
Keep an explicit non-modulo index/end and hash of the exact ordered identity
sequence. All pending IDs are fixed. On resume first honor any linked unknown
operation; then a changed catalogue membership fingerprint fails stale instead of
silently mapping an ordinal to another profile. A fresh scan is an explicit new
intent. RU/rights changes that preserve identity membership still use the existing
full private-seed and ownership guards. If cross-membership continuation is a
requirement, materialize the finite catalogue into existing jobs in<=500-ID
segments under one scan identity; that larger variant needs explicit bound/CAS
design, not an unchecked large JSON array or a new queue.

Use deterministic exact identity ordering (tuples/UTF8 byte comparison) and hash
the ordered tuple list unambiguously. No author normalization, source content,
rights or prose belong in this membership hash. Do not assume JSONB hashing equals
the existing JS sourceHash/catalogue hash; use separate names/protocols.

Source/API files requiring later ownership agreement:
- translations/actions.ts library count/order/range and writer membership;
- country-actions.ts flat membership; translation-backfill-cursor.ts legacy input;
- resume-action.ts and translations/page.tsx new scan UUID/explicit fresh intent;
- new isolated typed scan DTO/RPC/coordinator;
- minimal optional admission hook in existing writer/catalog coordinators and
  helper operation context; legacy callers retain current behavior;
- NEW additive metadata RPCs on existing jobs/items, never old migration edits.

Reject nonzero legacy scalar continuation as stale under the new protocol rather
than silently starting0. An explicit Fresh command may safely start a new scan;
existing current/manual/pending guards prevent payment just to rebuild statistics.
Continue remaining scan and retry a failed paid item remain separate intentions;
this design adds no partial retry/UI recovery claim for M07-T13.

## Later acceptance, not run/implemented here

Use the immutable native-backed SAME coverage/no-repeat contract, actual bounded
action+SDK and native row reads. Preserve update/delete/insert/ten-tie controls.
Add two staff continuations racing one current item, ACK loss before/after attach
and checkpoint, unknown source/model/catalogue change, same snapshot end without
wrap, deleted pending IDs, empty tail completion race, all-manual/paid-only scans,
config/actor/CAS mismatch and old ordinal stale behavior. Provider0 native rights
proof and controlled-provider paid protocols are separate receipts. Current T10
caps and all existing writer/catalog/private/promotion tests must remain intact.
