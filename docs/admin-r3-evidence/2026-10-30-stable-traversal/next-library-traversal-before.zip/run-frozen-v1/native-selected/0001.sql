create table if not exists public.literary_works (
  id uuid primary key default gen_random_uuid(),
  legacy_id text not null unique check (char_length(legacy_id) between 2 and 180),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  title text not null check (char_length(title) between 1 and 300),
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{0,179}$'),
  original_title text not null default '' check (char_length(original_title) <= 300),
  first_published integer check (first_published between -3000 and 2100),
  original_language text not null default '' check (char_length(original_language) <= 120),
  genres text[] not null default '{}',
  tags text[] not null default '{}',
  description text not null default '' check (char_length(description) <= 5000),
  source_url text,
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (writer_id, slug)
);
create table if not exists public.literary_work_translations (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  locale text not null check (locale in ('ru', 'en')),
  title text not null check (char_length(title) between 1 and 300),
  description text not null check (char_length(description) between 140 and 900),
  source_language text not null check (char_length(source_language) between 2 and 40),
  translation_method text not null
    check (
      translation_method in (
        'editorial-original',
        'human-translation',
        'licensed-source'
      )
    ),
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  source_urls text[] not null default '{}',
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, locale),
  check (
    editorial_status = 'draft'
    or (
      reviewed_at is not null
      and cardinality(source_urls) > 0
    )
  )
);
create table if not exists public.literary_work_sources (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  provider text not null check (char_length(provider) between 2 and 160),
  source_url text not null check (source_url ~ '^https://'),
  field_names text[] not null check (cardinality(field_names) > 0),
  license_name text,
  usage text not null
    check (usage in ('structured-data', 'reference-only', 'licensed-copy')),
  retrieved_at date not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, provider, source_url)
);
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
drop trigger if exists literary_work_translations_set_updated_at
  on public.literary_work_translations;
create trigger literary_work_translations_set_updated_at
  before update on public.literary_work_translations
  for each row execute function public.set_updated_at();