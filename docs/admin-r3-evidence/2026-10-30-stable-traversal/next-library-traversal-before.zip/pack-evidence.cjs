const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const out=path.resolve(__dirname,'../m07-t12-library-before-evidence-20261030-sol'),sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const read=n=>JSON.parse(fs.readFileSync(path.join(__dirname,n),'utf8').replace(/^\uFEFF/,''));
const initial=read('run-v1/report.json'),frozen=read('run-frozen-v1/report.json'),freeze=read('freeze-manifest.json'),same=require('./same-contract.cjs');
assert.equal(initial.executionFailures,0);assert.equal(frozen.executionFailures,0);assert.equal(same(initial).targetFailures,4);assert.equal(same(frozen).targetFailures,4);assert.deepEqual(initial.sourceGraph,frozen.sourceGraph);
for(let i=0;i<initial.cases.length;i++){assert.deepEqual(initial.cases[i].omittedInitialIdsAtCursorWrap,frozen.cases[i].omittedInitialIdsAtCursorWrap);assert.deepEqual(initial.cases[i].repeatedInitialIds,frozen.cases[i].repeatedInitialIds);assert.ok(Object.values(initial.cases[i].preservation).every(Boolean));assert.ok(Object.values(frozen.cases[i].preservation).every(Boolean));}
const cleanup=[read('new-cleanup.json'),read('frozen-cleanup.json')];for(const c of cleanup){assert.equal(c.pgCtlExitCode,0);assert.equal(c.processRemains,false);assert.equal(c.pidFileRemains,false);assert.equal(c.serviceCreated,false);}
const copy=(a,b)=>{fs.mkdirSync(path.dirname(b),{recursive:true});fs.copyFileSync(a,b);};
const tree=(a,b)=>{for(const e of fs.readdirSync(a,{withFileTypes:true})){const x=path.join(a,e.name),y=path.join(b,e.name);if(e.isDirectory())tree(x,y);else copy(x,y);}};
fs.mkdirSync(out,{recursive:true});
for(const name of ['probe.cjs','freeze.cjs','pack-evidence.cjs','same-contract.cjs','freeze-manifest.json','run-owned.ps1','run-frozen.ps1','node-run.log','frozen-node-run.log','new-cleanup.json','new-cleanup.log','frozen-cleanup.json','frozen-cleanup.log','postgres-new.log','postgres-frozen.log','DESIGN-NOT-IMPLEMENTED.md'])copy(path.join(__dirname,name),path.join(out,name));
tree(path.join(__dirname,'frozen-sources'),path.join(out,'frozen-sources'));tree(path.join(__dirname,'instrumentation'),path.join(out,'instrumentation'));tree(path.join(__dirname,'history'),path.join(out,'history'));
const selected=[];
for(const run of ['run-v1','run-frozen-v1']){
 for(const name of ['report.json','sdk-wire.json','update-visited.json','delete-visited.json','insert-before-cursor.json'])copy(path.join(__dirname,run,name),path.join(out,run,name));
 const dir=path.join(__dirname,run,'native'),all=fs.readdirSync(dir).filter(n=>n.endsWith('.sql')).sort();
 let representative=0;
 for(const name of all){const sql=fs.readFileSync(path.join(dir,name),'utf8');
  const essential=/create table|truncate public\.|insert into public\.|update public\.|delete from public\.|select jsonb_build_object\('works'|select work_id from public.literary_work_translations|select count\(\*\) from public.literary_work_translations where locale=/i.test(sql);
  const sample=!essential&&representative++<3;if(!essential&&!sample)continue;
  for(const suffix of ['', '.stdout.log','.stderr.log'])copy(path.join(dir,name+suffix),path.join(out,run,'native-selected',name+suffix));
  selected.push({run,file:name,sha256:sha(sql),selection:essential?'all DDL/seeds/mutations/snapshots/scans/counts':'representative helper read'});
 }
}
const summary={atUtc:new Date().toISOString(),mode:'UNRESOLVED_BEFORE_NOT_CURRENT_PASS',sourceCount:initial.sourceCount,immutableInputs:freeze.files.length,sameContractSha256:freeze.sameContractSha256,executionFailures:0,originalTargetFailures:same(initial).targetFailures,frozenTargetFailures:same(frozen).targetFailures,cases:initial.cases.map(c=>({kind:c.kind,first:c.first.helperIds.length,resume:c.second.helperIds.length,distinct:c.distinctSeen,omitted:c.omittedInitialIdsAtCursorWrap,repeated:c.repeatedInitialIds,cursor:c.second.params.libraryCursor,providerCalls:0,preservation:c.preservation})),cleanup,nativeSelected:selected,nativeTotalSqlPerRun:1164,
 boundaries:['Native3-table constraints/content/query/trigger reads are real; readiness/Auth/selftest/free journal transport controlled. No real PostgREST/RLS or provider claim.',
 'Unresolved bounded-sweep omission/repetition, not proven permanent starvation or actualUI100%. Tied dates10 present; tie-only nondeterminism not separately claimed.',
 'Both actual source and immutable frozen replay execute the same behavior with0provider/canonical batchwrites/builds; targetFAIL4 andexecution0 are expected defect evidence.',
 'All selected DDL/seeds/mutations/snapshots/scan/count SQL and raw stdout/stderr included. Repetitive individual helper SQL traces are curated to3samples; complete actualSDK native row responses are in sdk-wire.json and all1164query triples perrun remain in parentwork.',
 'Design is proposed only; existing paid numeric DTOs/grants/APIs unchanged and no stable traversal implementation has been applied.']};
fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify(summary,null,2));
fs.writeFileSync(path.join(out,'README.txt'),`M07-T12 library traversal unresolved BEFORE — GPT-6.1 Sol Ultra

This is defect evidence, NOT CURRENT acceptance PASS. Real existing library batch+safe/helper manual-ownership paths+cursor/budgets/run DTO+native Next redirect and installedSDK execute against synthetic table rows. All62EN rows are deliberate human translations, so the real helper free guards return manual and no provider is invoked. AI is trapped; there is no fake provider success or helper algorithm replacement.

Both original and immutable frozen replay: executionFailures0,targetFailures4/6. Update visited RUtimestamp:60+2 reads,61distinct initial IDs,1omitted+1repeat,cursor0. Delete visited work:60+1,61distinct,1omitted/0repeat,cursor0. Insert before cursor:60+3,62originalseen/1repeat,newrow deferred,cursor0.10RU timestamps are exactly tied. Initial eligible IDs, actual SDK range/order, actual native returned IDs and exact omitted/repeated identities are recorded. This proves bounded-sweep omission/repetition, NOT permanent starvation or an actual UI100% statement.

The owned PG17 databases contain3 real canonical table definitions/constraints extracted byte-exact from existing migrations plus the exact real now() function/RU update trigger. All SDK table/count/order/range/helper reads run real native SQL. Native3-table rows have no real Auth/RLS/PostgREST layer; readiness/Auth/selftest/free-run journal transport remains separately controlled/recorded. Manual EN/source/licence/rights/all other canonical fields remain exact except declared timestamp/insert/delete controls; the batch performs zero native writes and requests zero builds. Old migrations and all maintained files/archives remain untouched.

19 actual source modules+3 SQL sources are immutable under frozen-sources. Instrumentation includes the exact support prefix and controlled boundary dependencies. same-contract.cjs SHA${freeze.sameContractSha256} is the invariant for original/frozen and later CURRENT. history/probe-original-executed.cjs preserves the original fixture bytes; probe.cjs adds only portable input/output paths and a nonfatal external-status observation for frozen replay. No product changes are included. DESIGN-NOT-IMPLEMENTED.md is a proposal only.

Replay requires existing Node+installed @supabase/supabase-js/TypeScript/Next/Zod versions listed in reports and an owned isolated PG17 cluster. run-owned.ps1/run-frozen.ps1 verify the exact owned loopback data_directory/PID and refuse an existing database; they start/query/stop in one context, no service. Rebase documented repo/parentwork/runtime paths to extraction and a disposable local cluster. Use a new DB/output path for every replay; expected diagnostic exit1 is targetFAIL, whereas execution faults exit2. Never point this fixture at a managed environment.

All selected native DDL/seeds/mutations/snapshots/scan/count raw query triples are included;3 representative helper query triples perrun plus complete sdk-wire.json responses preserve actual helper evidence. The repetitive1164-query-perrun full traces remain in parentwork and are intentionally curated from this ZIP. Cleanup proves originalPID5420/frozenPID15348 stopped with no process/PIDfile/service. No binaries,deps,DB data or secrets are bundled.
`);
const files=[];function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,e.name);if(e.isDirectory())walk(f);else if(path.relative(out,f)!=='manifest.json'){const b=fs.readFileSync(f);files.push({file:path.relative(out,f).replaceAll('\\','/'),bytes:b.length,sha256:sha(b)});}}}walk(out);files.sort((a,b)=>a.file.localeCompare(b.file));fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),mode:summary.mode,sourceCount:19,immutableInputs:22,files},null,2));console.log(JSON.stringify({out,files:files.length,nativeSelected:selected.length,executionFailures:0,targetFailures:4}));
