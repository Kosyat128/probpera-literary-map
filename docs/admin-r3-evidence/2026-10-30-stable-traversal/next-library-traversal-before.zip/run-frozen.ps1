$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\m07-t12-library-before-20261030-sol'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$pgBin='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\PORTAB~1\POSTGR~1.11-\pgsql\bin'
$owned=Get-Content -LiteralPath (Join-Path $clusterRoot 'owned-cluster.json') -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID exists; refusing start'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false
$exitCode=1
try{
 & (Join-Path $pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-frozen.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned PostgreSQL start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 [pscustomobject]@{port=55438;listenAddress='127.0.0.1';dataDirectory=$dataDirectory;pgBin=$pgBin;pid=$ownedPid;service=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $clusterRoot 'owned-cluster.json') -Encoding utf8
 $env:PGCLIENTENCODING='UTF8'
 $psql=Join-Path $pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Connection not to owned isolated cluster'}
 $exists=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc "select count(*) from pg_database where datname='translation_t12_v2_20261030'"
 if($exists -ne '0'){throw 'Probe database already exists; refusing reset'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc --set=ON_ERROR_STOP=1 -c 'create database translation_t12_v2_20261030'
 if($LASTEXITCODE -ne 0){throw 'Owned probe database creation failed'}
 $env:M07_T12_DATABASE='translation_t12_v2_20261030'
 $env:M07_T12_OUTPUT='run-frozen-v1'
 $env:M07_T12_SOURCE_ROOT=Join-Path $nativeRoot 'frozen-sources'
 $env:M07_T12_SUPPORT_PATH=Join-Path $nativeRoot 'instrumentation\library-batch-budget-cap.cjs'
 & node (Join-Path $nativeRoot 'probe.cjs') *> (Join-Path $nativeRoot 'frozen-node-run.log')
 $exitCode=$LASTEXITCODE
 Get-Content -LiteralPath (Join-Path $nativeRoot 'frozen-node-run.log')|Select-Object -Last 6
 Write-Output ('DIAGNOSTIC_EXIT='+$exitCode)
}finally{
 if($started){
  $actualPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
  if($actualPid -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'frozen-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'frozen-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
exit $exitCode
