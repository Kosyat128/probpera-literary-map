$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\library-scan-sql-native'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-core-v6.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8'
 $psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not the owned isolated cluster'}
 $database='library_scan_v6_20261030'
 $queries=@{
  'native-goldens-core-v6.json'="select coalesce(jsonb_agg(jsonb_build_object('rpc',rpc,'args',args,'response',response) order by at_time,id),'[]'::jsonb) from public.library_scan_fixture_wire";
  'native-cases-core-v6.json'='select jsonb_object_agg(label,value) from public.library_scan_fixture_results';
  'native-functions-core-v6.json'="select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'securityDefiner',p.prosecdef,'config',p.proconfig,'source',p.prosrc) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where (n.nspname='public' and (p.proname like '%catalog_translation_operation%' or p.proname like '%writer_translation_operation%' or p.proname in ('get_catalog_translation_candidate_freshness','promote_premium_translation_working_draft','begin_library_translation_scan','get_library_translation_scan','attach_library_translation_scan_operation','checkpoint_library_translation_scan_item','continue_library_translation_scan'))) or(n.nspname='premium_translation_private' and(p.proname like 'catalog_operation_%' or p.proname like 'writer_operation_%' or p.proname='assert_catalog_operation_promotion_current')) or(n.nspname='probpera_translation_operations' and p.proname like 'library_scan_%')";
  'native-tables-core-v6.json'="select jsonb_agg(jsonb_build_object('name',c.relname,'acl',c.relacl,'columns',(select jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull) order by a.attnum) from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped)) order by c.relname) from pg_class c where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass)";
 }
 foreach($name in $queries.Keys){
  $file=Join-Path $nativeRoot ($name+'.sql');[IO.File]::WriteAllText($file,$queries[$name],[Text.UTF8Encoding]::new($false))
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f $file 2> (Join-Path $nativeRoot ($name+'.stderr.log'))
  if($LASTEXITCODE -ne 0){throw 'Core export failed'}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $name),($raw -join "
"),[Text.UTF8Encoding]::new($false))
 }
 $baseline=& $psql -h 127.0.0.1 -p 55438 -U postgres -d catalog_freshness_v3_20261030 --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'native-tables-core-v6.json.sql')
 if($LASTEXITCODE -ne 0){throw 'Baseline table read failed'}
 [IO.File]::WriteAllText((Join-Path $nativeRoot 'native-tables-baseline-c482.json'),($baseline -join "
"),[Text.UTF8Encoding]::new($false))
 Write-Output 'NATIVE_LIBRARY_CORE_GOLDENS_EXPORTED'
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'core-v6-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'core-v6-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
