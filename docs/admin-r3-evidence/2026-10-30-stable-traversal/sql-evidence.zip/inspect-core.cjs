const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const read=(file,dir=__dirname)=>JSON.parse(fs.readFileSync(path.join(dir,file),'utf8').replace(/^\uFEFF/,''));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex'),goldens=read('native-goldens-core-v6.json'),functions=read('native-functions-core-v6.json');
const old=read('native-functions.json',path.resolve(__dirname,'../catalog-freshness-sql-native'));
for(const f of old){const current=functions.find(x=>x.name===f.name);assert.ok(current,f.name);assert.equal(current.source.replace(/\r\n?/g,'\n'),f.source.replace(/\r\n?/g,'\n'));assert.deepEqual(current.config,f.config);assert.equal(current.securityDefiner,f.securityDefiner);}
assert.deepEqual(read('native-tables-core-v6.json'),read('native-tables-baseline-c482.json'));
const kinds={};for(const g of goldens){kinds[g.rpc]=(kinds[g.rpc]||0)+1;const r=g.response;assert.equal(r.members.length,r.totalItems);for(let i=0;i<r.members.length;i++)assert.equal(r.members[i].status==='reviewing',i>=r.nextPosition);if(r.child){assert.equal(r.child.receipt.canExecute,false);assert.equal(r.child.receipt.canDispatch,false);}}
assert.equal(Object.keys(kinds).length,5);
const result={atUtc:new Date().toISOString(),mode:'PROVISIONAL_CORE_NATIVE_NOT_FINAL_CONCURRENCY_ACCEPTANCE',goldens:goldens.length,rpcCounts:kinds,oldFunctionBodiesAndConfigExact:old.length,columnsAndTableAclVsC482Exact:true,
 files:['native-goldens-core-v6.json','native-cases-core-v6.json','native-functions-core-v6.json','core-v6-source-manifest.json'].map(file=>({file,sha256:sha(fs.readFileSync(path.join(__dirname,file)))}))};
fs.writeFileSync(path.join(__dirname,'core-v6-summary.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
