$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\library-scan-sql-native'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-concurrency.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8'
 $psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not the owned isolated cluster'}
 $database='library_scan_v7_20261030'
 $script:freshnessQuerySequence=0
 function Invoke-FreshnessQuery([string]$query){
  # psql Windows argv uses the active ANSI codepage for non-ASCII -c text.
  # Use exact UTF8 files instead of round-tripping authored fixture prose in argv.
  $script:freshnessQuerySequence++
  $queryFile=Join-Path $nativeRoot ('export-query-'+$script:freshnessQuerySequence+'.sql')
  [IO.File]::WriteAllText($queryFile,$query,[Text.UTF8Encoding]::new($false))
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f $queryFile 2> (Join-Path $nativeRoot ('export-query-'+$script:freshnessQuerySequence+'.stderr.log'))
  if($LASTEXITCODE -ne 0){throw 'Owned SQL query failed'}
  [IO.File]::WriteAllText($queryFile+'.stdout.log',($raw -join "
"),[Text.UTF8Encoding]::new($false))
  return ,@($raw|Where-Object{ $_.StartsWith('{') -or $_.StartsWith('[')})
 }
 function Start-FreshnessSession([string]$file,[string]$application){
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$psql;$info.UseShellExecute=$false;$info.CreateNoWindow=$true
  $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true;$info.Environment['PGAPPNAME']=$application
  foreach($argument in @('-h','127.0.0.1','-p','55438','-U','postgres','-d',$database,'--no-psqlrc','--set=ON_ERROR_STOP=1','-qAt','-f',$file)){$info.ArgumentList.Add($argument)}
  $process=[Diagnostics.Process]::new();$process.StartInfo=$info;$clock=[Diagnostics.Stopwatch]::StartNew()
  if(-not $process.Start()){throw 'Owned concurrent session failed'}
  return @{process=$process;stdout=$process.StandardOutput.ReadToEndAsync();stderr=$process.StandardError.ReadToEndAsync();clock=$clock;application=$application}
 }
 function Finish-FreshnessSession($entry,[string]$label){
  if(-not $entry.process.WaitForExit(15000)){$entry.process.Kill();throw 'Owned session timeout'}
  $entry.clock.Stop();$stdout=$entry.stdout.GetAwaiter().GetResult();$stderr=$entry.stderr.GetAwaiter().GetResult()
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($label+'.stdout.log')),$stdout)
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($label+'.stderr.log')),$stderr)
  if($entry.process.ExitCode -ne 0){throw ($label+' SQL failed '+$stderr)}
  $json=@($stdout -split "`n"|Where-Object{$_.TrimStart().StartsWith('{')})
  if($json.Count -ne 1){throw ('Unexpected receipt '+$label)}
  return @{pid=$entry.process.Id;application=$entry.application;elapsedMs=$entry.clock.ElapsedMilliseconds;exitCode=$entry.process.ExitCode;receipt=($json[0]|ConvertFrom-Json)}
 }
 $database='library_scan_v7_20261030'
 function Sql-Literal([string]$value){return "'"+$value.Replace("'","''")+"'"}
 function Json-Literal($value){return (Sql-Literal ($value|ConvertTo-Json -Depth 70 -Compress))+'::jsonb'}
 function One-Query([string]$query){$rows=Invoke-FreshnessQuery $query;if($rows.Count -ne 1){throw 'Expected one native JSON result'};return $rows[0]|ConvertFrom-Json}
 $script:trackedSessions=@()
 function Start-TrackedSession([string]$file,[string]$application){$entry=Start-FreshnessSession $file $application;$script:trackedSessions+=,$entry;return $entry}
 function Save-Results{$results|ConvertTo-Json -Depth 90|Set-Content -LiteralPath(Join-Path $nativeRoot 'concurrent-results.partial.json') -Encoding utf8}
 function Wait-Sleep([string]$application){
  for($step=0;$step -lt 30;$step++){$proof=One-Query("select jsonb_build_object('sleeping',exists(select 1 from pg_stat_activity where application_name="+(Sql-Literal $application)+" and wait_event='PgSleep'))");if($proof.sleeping){return $proof};[Threading.Thread]::Sleep(40)}
  throw ('Session did not reach post-operation barrier: '+$application)
 }
 function Wait-Blocked([string]$application){
  for($step=0;$step -lt 20;$step++){$proof=One-Query("select jsonb_build_object('blocked',exists(select 1 from pg_stat_activity where application_name="+(Sql-Literal $application)+" and cardinality(pg_blocking_pids(pid))>0))");if($proof.blocked){return $proof};[Threading.Thread]::Sleep(40)}
  throw ('No real database wait observed: '+$application)
 }
 function Session-File([string]$label,[string]$sql){$file=Join-Path $nativeRoot ($label+'.sql');[IO.File]::WriteAllText($file,$sql,[Text.UTF8Encoding]::new($false));return $file}
 function Caught-Expression([string]$expression){
  $template=@'
create temp table native_race_result(v jsonb);do $caught$ begin insert into native_race_result select __EXPRESSION__;exception when others then insert into native_race_result values(jsonb_build_object('errorCode',sqlstate));end;$caught$;select v from native_race_result;
'@
  return $template.Replace('__EXPRESSION__',$expression)
 }
 $actorSql="select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);"
 $roleSql="set local role authenticated;select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);"
 $results=@{}
 $runToken=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds().ToString();$bulkTag=([long]$runToken%100000)+100
 $config=One-Query($actorSql+"select public.library_scan_fixture_clear();select public.library_scan_fixture_seed(501,"+(Sql-Literal $bulkTag.ToString())+");select public.catalog_fixture_config('literary_work',true)")
 $configSql=Json-Literal $config;$scanId=[guid]::NewGuid().ToString()
 $beginExpr="public.begin_library_translation_scan('"+$scanId+"',"+$configSql+")"
 $file=Session-File 'race-initial' ("begin;"+$roleSql+"select "+$beginExpr+";select pg_sleep(0.9);commit;")
 $one=Start-TrackedSession $file 'library-initial-one';[Threading.Thread]::Sleep(140)
 $two=Start-TrackedSession $file 'library-initial-two';$wait=Wait-Blocked 'library-initial-two'
 $a=Finish-FreshnessSession $one 'race-initial-one';$b=Finish-FreshnessSession $two 'race-initial-two'
 if($a.receipt.jobId -ne $scanId -or $b.receipt.jobId -ne $scanId -or $a.receipt.replayed -eq $b.receipt.replayed){throw 'Initial request was not deduplicated'}
 $results.initial=@{sessions=@($a,$b);actualWait=$wait;count=(One-Query("select jsonb_build_object('jobs',count(*)) from public.translation_jobs where resume_cursor#>>'{libraryScan,scanId}'='"+$scanId+"'"))}
 Save-Results
 $complete=@'
create temp table native_bound(v jsonb);do $bound$ declare r jsonb;idx integer;begin r:=public.get_library_translation_scan('__SCAN__');for idx in 1..500 loop r:=public.library_scan_fixture_free(r);end loop;insert into native_bound values(r);end;$bound$;select v from native_bound;
'@
 $bound=One-Query($actorSql+$complete.Replace('__SCAN__',$scanId))
 $continueExpr="public.continue_library_translation_scan('"+$scanId+"',"+$bound.jobVersion+","+$configSql+")"
 $file=Session-File 'race-successor' ("begin;"+$roleSql+"select "+$continueExpr+";select pg_sleep(0.9);commit;")
 $one=Start-TrackedSession $file 'library-successor-one';[Threading.Thread]::Sleep(140)
 $two=Start-TrackedSession $file 'library-successor-two';$wait=Wait-Blocked 'library-successor-two'
 $a=Finish-FreshnessSession $one 'race-successor-one';$b=Finish-FreshnessSession $two 'race-successor-two'
 if($a.receipt.jobId -ne $b.receipt.jobId -or $a.receipt.windowIndex -ne 1 -or $a.receipt.totalItems -ne 1){throw 'Successor was duplicated or unbounded'}
 $count=One-Query("select jsonb_build_object('windows',count(*),'members',(select count(*) from public.translation_job_items where job_id in(select id from public.translation_jobs where resume_cursor#>>'{libraryScan,scanId}'='"+$scanId+"')),'firstHistory',(select count(*) from public.translation_job_attempts where item_id in(select id from public.translation_job_items where job_id='"+$scanId+"'))) from public.translation_jobs where resume_cursor#>>'{libraryScan,scanId}'='"+$scanId+"'")
 if($count.windows -ne 2 -or $count.members -ne 501 -or $count.firstHistory -ne 500){throw 'Window history changed'}
 $results.successor=@{sessions=@($a,$b);actualWait=$wait;count=$count}
 Save-Results

 # Concurrent same transition: exactly one logical observation/advance.
 $scan=One-Query($actorSql+"select public.library_scan_fixture_clear();select public.library_scan_fixture_seed(1,"+(Sql-Literal ($bulkTag+1).ToString())+");select public.begin_library_translation_scan(gen_random_uuid(),"+$configSql+")")
 $transition=[guid]::NewGuid().ToString();$request="public.library_scan_fixture_free("+(Json-Literal $scan)+",'manual',null,'"+$transition+"')"
 $file=Session-File 'race-checkpoint' ("begin;"+$roleSql+"select "+$request+";select pg_sleep(0.9);commit;")
 $one=Start-TrackedSession $file 'library-checkpoint-one';[Threading.Thread]::Sleep(140)
 $two=Start-TrackedSession $file 'library-checkpoint-two';$wait=Wait-Blocked 'library-checkpoint-two'
 $a=Finish-FreshnessSession $one 'race-checkpoint-one';$b=Finish-FreshnessSession $two 'race-checkpoint-two'
 $count=One-Query("select jsonb_build_object('observations',count(*)) from public.translation_job_attempts where item_id='"+$scan.members[0].itemId+"'")
 if($a.receipt.nextPosition -ne 1 -or $b.receipt.nextPosition -ne 1 -or $count.observations -ne 1){throw 'Concurrent checkpoint duplicated progress'}
 $results.checkpoint=@{sessions=@($a,$b);actualWait=$wait;count=$count}
 Save-Results

 # Parent cancel wins while child has cache/canonical locks and waits for parent.
 $setup=One-Query($actorSql+"select public.library_scan_fixture_single('cancel-first-"+$runToken+"',true)");$scan=$setup.scan;$child=$setup.child
 $callId=[guid]::NewGuid().ToString();$dispatch="public.record_catalog_translation_operation_dispatch('"+$child.jobId+"','"+$child.itemId+"','"+$child.operationId+"','"+$callId+"','cloudflare','fixture-translator','translation',repeat('c',64))"
 $cancelFile=Session-File 'race-cancel-first' ("begin;select id from public.translation_jobs where id='"+$scan.jobId+"' for update;select pg_sleep(0.9);"+$roleSql+"select public.request_translation_job_cancel('"+$scan.jobId+"',"+$scan.jobVersion+");commit;")
 $dispatchFile=Session-File 'race-dispatch-after-cancel' ("begin;"+$roleSql+(Caught-Expression $dispatch)+"commit;")
 $one=Start-TrackedSession $cancelFile 'library-cancel-first';[Threading.Thread]::Sleep(140)
 $two=Start-TrackedSession $dispatchFile 'library-dispatch-wait';$wait=Wait-Blocked 'library-dispatch-wait'
 $cancel=Finish-FreshnessSession $one 'race-cancel-first';$blocked=Finish-FreshnessSession $two 'race-dispatch-after-cancel'
 $count=One-Query("select jsonb_build_object('calls',jsonb_array_length(calls)) from premium_translation_private.catalog_operation_artifacts where operation_id='"+$child.operationId+"'")
 if($blocked.receipt.errorCode -ne '40001' -or $count.calls -ne 0){throw 'Cancel did not atomically stop new dispatch'}
 $done=One-Query($actorSql+"select public.finish_catalog_translation_operation('"+$child.jobId+"','"+$child.itemId+"','"+$child.operationId+"','{`"status`":`"skipped`",`"providerCalls`":0}',null)")
 $current=One-Query($actorSql+"select public.get_library_translation_scan('"+$scan.jobId+"')")
 $held=One-Query($actorSql+"select public.library_scan_fixture_checkpoint_child("+(Json-Literal $current)+","+(Json-Literal $done)+")")
 if($held.nextPosition -ne 0 -or $held.child -ne $null -or $held.transition -ne 'zero-call-held'){throw 'Cancelled0call cleanup advanced'}
 $results.cancelFirst=@{cancel=$cancel;dispatch=$blocked;actualWait=$wait;count=$count;zeroCallHeld=$held}
 Save-Results

 # Dispatch reservation wins; response retention is allowed after cancellation,
 # while the next reviewer dispatch must be refused by the additive DB guard.
 $setup=One-Query($actorSql+"select public.library_scan_fixture_single('dispatch-first-"+$runToken+"',true)");$scan=$setup.scan;$child=$setup.child
 $callId=[guid]::NewGuid().ToString();$dispatch="public.record_catalog_translation_operation_dispatch('"+$child.jobId+"','"+$child.itemId+"','"+$child.operationId+"','"+$callId+"','cloudflare','fixture-translator','translation',repeat('c',64))"
 $dispatchFile=Session-File 'race-dispatch-first' ("begin;"+$roleSql+"select "+$dispatch+";select pg_sleep(0.9);commit;")
 $cancelFile=Session-File 'race-cancel-after-dispatch' ("begin;"+$roleSql+"select public.request_translation_job_cancel('"+$scan.jobId+"',"+$scan.jobVersion+");commit;")
 $one=Start-TrackedSession $dispatchFile 'library-dispatch-first';$dispatchBarrier=Wait-Sleep 'library-dispatch-first'
 $two=Start-TrackedSession $cancelFile 'library-cancel-wait';$wait=Wait-Blocked 'library-cancel-wait'
 $accepted=Finish-FreshnessSession $one 'race-dispatch-first';$cancel=Finish-FreshnessSession $two 'race-cancel-after-dispatch'
 $metadata=@{callId=$callId;provider='cloudflare';model='fixture-translator';pass='translation';httpStatus=$null;requestId=$null;responseId='native-after-parent-cancel';inputTokens=5;outputTokens=6}
 $artifact=@{version=1;body=@{response=(@{description=$setup.args.payload.description}|ConvertTo-Json -Compress)}}
 $response=One-Query($actorSql+"select public.record_catalog_translation_operation_response('"+$child.jobId+"','"+$child.itemId+"','"+$child.operationId+"',"+(Json-Literal $metadata)+","+(Json-Literal $artifact)+")")
 $review="public.record_catalog_translation_operation_dispatch('"+$child.jobId+"','"+$child.itemId+"','"+$child.operationId+"',gen_random_uuid(),'cloudflare','fixture-reviewer','review',repeat('d',64))"
 $denied=One-Query($actorSql+(Caught-Expression $review))
 $done=One-Query($actorSql+"select public.finish_catalog_translation_operation('"+$child.jobId+"','"+$child.itemId+"','"+$child.operationId+"','{`"status`":`"cancelled`",`"providerCalls`":1}',null)")
 $current=One-Query($actorSql+"select public.get_library_translation_scan('"+$scan.jobId+"')")
 $terminal=One-Query($actorSql+"select public.library_scan_fixture_checkpoint_child("+(Json-Literal $current)+","+(Json-Literal $done)+")")
 $retained=One-Query("select jsonb_build_object('calls',jsonb_array_length(calls),'bodyRetained',calls->0->'responseArtifact'<>'null'::jsonb) from premium_translation_private.catalog_operation_artifacts where operation_id='"+$child.operationId+"'")
 if($denied.errorCode -ne '40001' -or $retained.calls -ne 1 -or -not $retained.bodyRetained -or $terminal.status -ne 'cancelled'){throw 'Accepted result lost or laterreview not stopped'}
 $results.dispatchFirst=@{dispatch=$accepted;cancel=$cancel;actualWait=$wait;response=$response;reviewDenied=$denied;retained=$retained;parentTerminal=$terminal}
 Save-Results

 # GET must wait for a checkpoint transaction and return a coherent terminal
 # prefix/current position, rather than mix member snapshots.
 $scan=One-Query($actorSql+"select public.library_scan_fixture_clear();select public.library_scan_fixture_seed(2,"+(Sql-Literal ($bulkTag+2).ToString())+");select public.begin_library_translation_scan(gen_random_uuid(),"+$configSql+")")
 $checkpointFile=Session-File 'race-coherence-checkpoint' ("begin;"+$roleSql+"select public.library_scan_fixture_free("+(Json-Literal $scan)+");select pg_sleep(0.9);commit;")
 $getFile=Session-File 'race-coherence-get' ("begin;"+$roleSql+"select public.get_library_translation_scan('"+$scan.jobId+"');commit;")
 $one=Start-TrackedSession $checkpointFile 'library-coherence-checkpoint';$coherenceBarrier=Wait-Sleep 'library-coherence-checkpoint'
 $two=Start-TrackedSession $getFile 'library-coherence-get';$wait=Wait-Blocked 'library-coherence-get'
 $checkpoint=Finish-FreshnessSession $one 'race-coherence-checkpoint';$get=Finish-FreshnessSession $two 'race-coherence-get'
 if($get.receipt.nextPosition -ne 1 -or $get.receipt.members[0].status -eq 'reviewing' -or $get.receipt.members[1].status -ne 'reviewing'){throw 'GET member/position snapshot was not coherent'}
 $results.getCoherence=@{checkpoint=$checkpoint;get=$get;actualWait=$wait};Save-Results

 # Three actual sessions prove no parent->entity/cache cycle: A owns cache,
 # B BEGIN owns entity and waits A, C checkpoint waits B without owning parent.
 $setup=One-Query($actorSql+"select public.library_scan_fixture_single('three-way-"+$runToken+"',true)");$scan=$setup.scan;$child=$setup.child
 $dispatch="public.record_catalog_translation_operation_dispatch('"+$child.jobId+"','"+$child.itemId+"','"+$child.operationId+"',gen_random_uuid(),'cloudflare','fixture-translator','translation',repeat('e',64))"
 $aFile=Session-File 'race-three-cache' ("begin;select operation_id from premium_translation_private.catalog_operation_artifacts where operation_id='"+$child.operationId+"' for update;select pg_sleep(1.1);"+$roleSql+"select "+$dispatch+";commit;")
 $bFile=Session-File 'race-three-entity' ("begin;"+$roleSql+"select public.catalog_fixture_begin("+(Json-Literal $setup.args)+");commit;")
 $cFile=Session-File 'race-three-checkpoint' ("begin;"+$roleSql+"select public.library_scan_fixture_free("+(Json-Literal $scan)+",'skipped','source_missing');commit;")
 $one=Start-TrackedSession $aFile 'library-three-cache';$cacheBarrier=Wait-Sleep 'library-three-cache'
 $two=Start-TrackedSession $bFile 'library-three-entity';$waitB=Wait-Blocked 'library-three-entity'
 $three=Start-TrackedSession $cFile 'library-three-checkpoint';$waitC=Wait-Blocked 'library-three-checkpoint'
 $a=Finish-FreshnessSession $one 'race-three-cache';$b=Finish-FreshnessSession $two 'race-three-entity';$c=Finish-FreshnessSession $three 'race-three-checkpoint'
 if($a.receipt.providerCalls -ne 1 -or $b.receipt.canExecute -or $c.receipt.nextPosition -ne 0 -or $c.receipt.transition -ne 'held'){throw 'Three-way ordering or unknown hold failed'}
 $results.threeSessionOrdering=@{cacheSession=$a;entitySession=$b;checkpointSession=$c;actualEntityWait=$waitB;actualCheckpointWait=$waitC;deadlock=$false}
 $results|ConvertTo-Json -Depth 90|Set-Content -LiteralPath(Join-Path $nativeRoot 'concurrent-results.json') -Encoding utf8
 foreach($entry in @(@{name='native-goldens-final.json';sql="select jsonb_agg(jsonb_build_object('rpc',rpc,'args',args,'response',response) order by at_time,id) from public.library_scan_fixture_wire"},@{name='native-cases-final.json';sql='select jsonb_object_agg(label,value) from public.library_scan_fixture_results'})){
  $data=Invoke-FreshnessQuery $entry.sql;if($data.Count -ne 1){throw 'Unexpected final export'}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $entry.name),$data[0],[Text.UTF8Encoding]::new($false))
 }
 Write-Output 'LIBRARY_ACTUAL_INITIAL_SUCCESSOR_CHECKPOINT_CANCEL_GET_AND_THREE_SESSION_PASS'

}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'concurrency-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'concurrency-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
 foreach($tracked in $script:trackedSessions){
  if(-not $tracked.process.WaitForExit(3000)){$tracked.process.Kill()}
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($tracked.application+'.all.stdout.log')),$tracked.stdout.GetAwaiter().GetResult())
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($tracked.application+'.all.stderr.log')),$tracked.stderr.GetAwaiter().GetResult())
 }
}
