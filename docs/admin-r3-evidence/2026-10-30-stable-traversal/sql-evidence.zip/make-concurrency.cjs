const fs=require('node:fs'),path=require('node:path');
const database=process.argv[2]||'library_scan_v7_20261030';if(!/^library_scan_v\d+_20261030$/.test(database))throw Error('Explicit isolated library database only');
const prior=fs.readFileSync(path.resolve(__dirname,'../catalog-freshness-sql-native/concurrent-and-export.ps1'),'utf8').replaceAll('catalog-freshness-sql-native','library-scan-sql-native');
const prefix=prior.slice(0,prior.indexOf(" $database='")).replaceAll('postgres-export.log','postgres-concurrency.log');
let helpers=prior.slice(prior.indexOf(' $script:freshnessQuerySequence=0'),prior.indexOf(' $concurrent=@()'));
helpers=helpers.replace('  return ,@($raw|Where-Object{',`  [IO.File]::WriteAllText($queryFile+'.stdout.log',($raw -join "\n"),[Text.UTF8Encoding]::new($false))\n  return ,@($raw|Where-Object{`);
if(!helpers.includes('function Finish-FreshnessSession'))throw Error('Missing original guarded native helper');
let tail=prior.slice(prior.indexOf('}finally{')).replaceAll('export-cleanup','concurrency-cleanup');
const drain=` foreach($tracked in $script:trackedSessions){
  if(-not $tracked.process.WaitForExit(3000)){$tracked.process.Kill()}
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($tracked.application+'.all.stdout.log')),$tracked.stdout.GetAwaiter().GetResult())
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($tracked.application+'.all.stderr.log')),$tracked.stderr.GetAwaiter().GetResult())
 }\n`;
tail=tail.slice(0,tail.lastIndexOf('}'))+drain+tail.slice(tail.lastIndexOf('}'));
let body=fs.readFileSync(path.join(__dirname,'concurrency-body.ps1'),'utf8').replaceAll('=Start-FreshnessSession','=Start-TrackedSession');
// Keep the tracking wrapper's call to the original helper, not itself.
body=body.replace('$entry=Start-TrackedSession','$entry=Start-FreshnessSession');
fs.writeFileSync(path.join(__dirname,'run-concurrency.ps1'),(prefix+" $database='library_scan_v6_20261030'\n"+helpers+body+'\n'+tail).replaceAll('library_scan_v6_20261030',database));
