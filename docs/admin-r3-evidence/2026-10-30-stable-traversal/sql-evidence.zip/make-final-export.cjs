const fs=require('node:fs'),path=require('node:path');
let source=fs.readFileSync(path.join(__dirname,'export-core-v6.ps1'),'utf8').replaceAll('library_scan_v6_20261030','library_scan_v8_20261030').replaceAll('core-v6','final');
source=source.replace(/^\s*'native-goldens-final\.json'=[^\n]*\n/m,'');
source=source.replace("'source',p.prosrc)","'source',p.prosrc,'acl',p.proacl)");
const insert=` $functionSql=[IO.File]::ReadAllText((Join-Path $nativeRoot 'native-functions-final.json.sql'))
 $baseline=& $psql -h 127.0.0.1 -p 55438 -U postgres -d catalog_freshness_v3_20261030 --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'native-functions-final.json.sql')
 if($LASTEXITCODE -ne 0){throw 'Old function ACL baseline read failed'}
 [IO.File]::WriteAllText((Join-Path $nativeRoot 'native-functions-baseline-c482.json'),($baseline -join "\n"),[Text.UTF8Encoding]::new($false))
 $indexSql="select jsonb_agg(jsonb_build_object('schema',n.nspname,'name',ci.relname,'definition',pg_get_indexdef(ci.oid)) order by n.nspname,ci.relname) from pg_index i join pg_class c on c.oid=i.indrelid join pg_class ci on ci.oid=i.indexrelid join pg_namespace n on n.oid=ci.relnamespace where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass)"
 $indexFile=Join-Path $nativeRoot 'native-indexes-final.sql';[IO.File]::WriteAllText($indexFile,$indexSql)
 foreach($target in @(@{db=$database;file='native-indexes-final.json'},@{db='catalog_freshness_v3_20261030';file='native-indexes-baseline-c482.json'})){
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $target.db --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f $indexFile
  if($LASTEXITCODE -ne 0){throw 'Index baseline read failed'}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $target.file),($raw -join "\n"),[Text.UTF8Encoding]::new($false))
 }
 $available=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc -Atc "select count(*) from pg_available_extensions where name='plpgsql_check'"
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1'
 $env:SUPABASE_HOME='C:\\Users\\Костя\\Documents\\Codex\\2026-10-09\\v\\work\\library-scan-sql-native\\cli-home'
 $cli='C:\\Users\\Костя\\Documents\\Codex\\2026-10-09\\v\\work\\portable-db-tools\\supabase-2.120.0\\supabase.exe'
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$database+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors-final.log')
 $advisorExit=$LASTEXITCODE
 [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');target=('owned loopback '+$database);advisorsExitCode=$advisorExit;lintStatus='NOT_RUN_PLPGSQL_CHECK_UNAVAILABLE_NO_INSTALL';plpgsqlCheckAvailable=[int]$available;installedAnything=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-final.json') -Encoding utf8
 Write-Output 'FINAL_LIBRARY_NATIVE_METADATA_ACL_INDEXES_ADVISORS_EXPORTED'
`;
source=source.replace(" Write-Output 'NATIVE_LIBRARY_CORE_GOLDENS_EXPORTED'",insert);
fs.writeFileSync(path.join(__dirname,'export-final.ps1'),source);
