const fs=require('node:fs'),path=require('node:path');
const prior=path.resolve(__dirname,'../catalog-freshness-sql-native/concurrent-and-export.ps1');
const script=fs.readFileSync(prior,'utf8').replaceAll('catalog-freshness-sql-native','library-scan-sql-native');
const prefix=script.slice(0,script.indexOf(" $database='")),tail=script.slice(script.indexOf('}finally{')).replaceAll('export-cleanup','core-v6-cleanup');
const body=` $database='library_scan_v6_20261030'
 $queries=@{
  'native-goldens-core-v6.json'="select coalesce(jsonb_agg(jsonb_build_object('rpc',rpc,'args',args,'response',response) order by at_time,id),'[]'::jsonb) from public.library_scan_fixture_wire";
  'native-cases-core-v6.json'='select jsonb_object_agg(label,value) from public.library_scan_fixture_results';
  'native-functions-core-v6.json'="select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'securityDefiner',p.prosecdef,'config',p.proconfig,'source',p.prosrc) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where (n.nspname='public' and (p.proname like '%catalog_translation_operation%' or p.proname like '%writer_translation_operation%' or p.proname in ('get_catalog_translation_candidate_freshness','promote_premium_translation_working_draft','begin_library_translation_scan','get_library_translation_scan','attach_library_translation_scan_operation','checkpoint_library_translation_scan_item','continue_library_translation_scan'))) or(n.nspname='premium_translation_private' and(p.proname like 'catalog_operation_%' or p.proname like 'writer_operation_%' or p.proname='assert_catalog_operation_promotion_current')) or(n.nspname='probpera_translation_operations' and p.proname like 'library_scan_%')";
  'native-tables-core-v6.json'="select jsonb_agg(jsonb_build_object('name',c.relname,'acl',c.relacl,'columns',(select jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull) order by a.attnum) from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped)) order by c.relname) from pg_class c where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass)";
 }
 foreach($name in $queries.Keys){
  $file=Join-Path $nativeRoot ($name+'.sql');[IO.File]::WriteAllText($file,$queries[$name],[Text.UTF8Encoding]::new($false))
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f $file 2> (Join-Path $nativeRoot ($name+'.stderr.log'))
  if($LASTEXITCODE -ne 0){throw 'Core export failed'}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $name),($raw -join "\n"),[Text.UTF8Encoding]::new($false))
 }
 $baseline=& $psql -h 127.0.0.1 -p 55438 -U postgres -d catalog_freshness_v3_20261030 --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'native-tables-core-v6.json.sql')
 if($LASTEXITCODE -ne 0){throw 'Baseline table read failed'}
 [IO.File]::WriteAllText((Join-Path $nativeRoot 'native-tables-baseline-c482.json'),($baseline -join "\n"),[Text.UTF8Encoding]::new($false))
 Write-Output 'NATIVE_LIBRARY_CORE_GOLDENS_EXPORTED'
`;
fs.writeFileSync(path.join(__dirname,'export-core-v6.ps1'),prefix.replaceAll('postgres-export.log','postgres-core-v6.log')+body+tail);
fs.copyFileSync(path.join(__dirname,'source-manifest.json'),path.join(__dirname,'core-v6-source-manifest.json'));
