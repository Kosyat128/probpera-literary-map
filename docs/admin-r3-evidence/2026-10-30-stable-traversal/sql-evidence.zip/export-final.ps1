$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\library-scan-sql-native'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-final.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8'
 $psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not the owned isolated cluster'}
 $database='library_scan_v8_20261030'
 $queries=@{
  'native-cases-final.json'='select jsonb_object_agg(label,value) from public.library_scan_fixture_results';
  'native-functions-final.json'="select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'securityDefiner',p.prosecdef,'config',p.proconfig,'source',p.prosrc,'acl',p.proacl) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where (n.nspname='public' and (p.proname like '%catalog_translation_operation%' or p.proname like '%writer_translation_operation%' or p.proname in ('get_catalog_translation_candidate_freshness','promote_premium_translation_working_draft','begin_library_translation_scan','get_library_translation_scan','attach_library_translation_scan_operation','checkpoint_library_translation_scan_item','continue_library_translation_scan'))) or(n.nspname='premium_translation_private' and(p.proname like 'catalog_operation_%' or p.proname like 'writer_operation_%' or p.proname='assert_catalog_operation_promotion_current')) or(n.nspname='probpera_translation_operations' and p.proname like 'library_scan_%')";
  'native-tables-final.json'="select jsonb_agg(jsonb_build_object('name',c.relname,'acl',c.relacl,'columns',(select jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull) order by a.attnum) from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped)) order by c.relname) from pg_class c where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass)";
 }
 foreach($name in $queries.Keys){
  $file=Join-Path $nativeRoot ($name+'.sql');[IO.File]::WriteAllText($file,$queries[$name],[Text.UTF8Encoding]::new($false))
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f $file 2> (Join-Path $nativeRoot ($name+'.stderr.log'))
  if($LASTEXITCODE -ne 0){throw 'Core export failed'}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $name),($raw -join "
"),[Text.UTF8Encoding]::new($false))
 }
 $baseline=& $psql -h 127.0.0.1 -p 55438 -U postgres -d catalog_freshness_v3_20261030 --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'native-tables-final.json.sql')
 if($LASTEXITCODE -ne 0){throw 'Baseline table read failed'}
 [IO.File]::WriteAllText((Join-Path $nativeRoot 'native-tables-baseline-c482.json'),($baseline -join "
"),[Text.UTF8Encoding]::new($false))
 $functionSql=[IO.File]::ReadAllText((Join-Path $nativeRoot 'native-functions-final.json.sql'))
 $baseline=& $psql -h 127.0.0.1 -p 55438 -U postgres -d catalog_freshness_v3_20261030 --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'native-functions-final.json.sql')
 if($LASTEXITCODE -ne 0){throw 'Old function ACL baseline read failed'}
 [IO.File]::WriteAllText((Join-Path $nativeRoot 'native-functions-baseline-c482.json'),($baseline -join "
"),[Text.UTF8Encoding]::new($false))
 $indexSql="select jsonb_agg(jsonb_build_object('schema',n.nspname,'name',ci.relname,'definition',pg_get_indexdef(ci.oid)) order by n.nspname,ci.relname) from pg_index i join pg_class c on c.oid=i.indrelid join pg_class ci on ci.oid=i.indexrelid join pg_namespace n on n.oid=ci.relnamespace where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass)"
 $indexFile=Join-Path $nativeRoot 'native-indexes-final.sql';[IO.File]::WriteAllText($indexFile,$indexSql)
 foreach($target in @(@{db=$database;file='native-indexes-final.json'},@{db='catalog_freshness_v3_20261030';file='native-indexes-baseline-c482.json'})){
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $target.db --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f $indexFile
  if($LASTEXITCODE -ne 0){throw 'Index baseline read failed'}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $target.file),($raw -join "
"),[Text.UTF8Encoding]::new($false))
 }
 $available=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc -Atc "select count(*) from pg_available_extensions where name='plpgsql_check'"
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1'
 $env:SUPABASE_HOME='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\library-scan-sql-native\cli-home'
 $cli='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\portable-db-tools\supabase-2.120.0\supabase.exe'
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$database+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors-final.log')
 $advisorExit=$LASTEXITCODE
 [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');target=('owned loopback '+$database);advisorsExitCode=$advisorExit;lintStatus='NOT_RUN_PLPGSQL_CHECK_UNAVAILABLE_NO_INSTALL';plpgsqlCheckAvailable=[int]$available;installedAnything=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-final.json') -Encoding utf8
 Write-Output 'FINAL_LIBRARY_NATIVE_METADATA_ACL_INDEXES_ADVISORS_EXPORTED'

}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'final-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'final-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
