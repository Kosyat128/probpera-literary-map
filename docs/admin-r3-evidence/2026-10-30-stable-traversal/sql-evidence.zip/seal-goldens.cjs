const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const expected=[['supabase/migrations/20261029235455_library_translation_stable_scan.sql','1966f749db15362b245d32b0e5b355b3f37dc4c154e2381c578b5ba11aba721b'],['scripts/database/fixtures/library-translation-stable-scan.sql','2edbc32bf11d3541d85645966d5cad504b40b685c887dfdc959bb3e7144d62ce']];
for(const [file,hash]of expected)assert.equal(sha(fs.readFileSync(path.join(repo,file))),hash);
const bytes=fs.readFileSync(path.join(__dirname,'native-goldens-final.json')),rows=JSON.parse(bytes);const counts={};for(const r of rows){counts[r.rpc]=(counts[r.rpc]||0)+1;assert.equal(r.response.version,1);if(r.response.child){assert.equal(r.response.child.receipt.canExecute,false);assert.equal(r.response.child.receipt.canDispatch,false);}}
const races=JSON.parse(fs.readFileSync(path.join(__dirname,'concurrent-results.json'),'utf8').replace(/^\uFEFF/,''));assert.deepEqual(Object.keys(races).sort(),['initial','successor','checkpoint','cancelFirst','dispatchFirst','getCoherence','threeSessionOrdering'].sort());
fs.copyFileSync(path.join(__dirname,'source-manifest.json'),path.join(__dirname,'final-source-manifest.json'));
const result={atUtc:new Date().toISOString(),database:'library_scan_v8_20261030',maintainedSources:expected,records:rows.length,rpcCounts:counts,goldensSha256:sha(bytes),manifestSha256:sha(fs.readFileSync(path.join(__dirname,'final-source-manifest.json'))),allSevenActualRaceGroupsPassed:true};
fs.writeFileSync(path.join(__dirname,'final-goldens-receipt.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
