const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { createRequire } = require('node:module');
const repo = path.resolve(__dirname, '../../probpera-literary-map');
const nativeRequire = createRequire(path.join(repo, 'package.json'));
const { unzipSync } = nativeRequire('fflate');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const mode = process.argv[2] || 'before', label = process.argv[3] || `${mode}-v1`;
const output = path.join(__dirname, `adapted-${label}`);
assert.equal(fs.existsSync(output), false); fs.mkdirSync(output, { recursive: true });
const zipPath = path.join(repo, 'docs/admin-r3-evidence/2026-10-29-profile-budgets/next-writer-admission-before.zip');
const zipBytes = fs.readFileSync(zipPath), archived = unzipSync(zipBytes);
assert.equal(sha(zipBytes), '44eceea641f3b19178a24b0824fa14b6adef0c77f4933db038d9a2404e498949');
const beforeRoot = path.join(output, 'before-source');
for (const [file, bytes] of Object.entries(archived)) {
  if (!file.startsWith('diagnostic-current/raw-graph/sources/')) continue;
  const destination = path.join(beforeRoot, file.slice('diagnostic-current/raw-graph/sources/'.length));
  fs.mkdirSync(path.dirname(destination), { recursive: true }); fs.writeFileSync(destination, bytes, { flag: 'wx' });
}
const originalContract = path.join(output, 'original-same-contract.cjs');
fs.writeFileSync(originalContract, archived['writer-provider-admission.same-contract.cjs'], { flag: 'wx' });
assert.equal(sha(fs.readFileSync(originalContract)), '239bf9786db1c2c998edb5a4b6092b4460d8b1b9efeace0c94071deffaccc3ea');
const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => /^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i.test(key)));
Object.assign(env, { WRITER_ADMISSION_REPO: repo, WRITER_ADMISSION_SOURCE_ROOT: mode === 'before' ? beforeRoot : repo,
  WRITER_ADMISSION_OUTPUT_ROOT: path.join(output, 'scenario') });
const script = path.join(repo, 'apps/admin/lib/fixtures/writer-admission-runtime.cjs');
const scenario = spawnSync(process.execPath, [script], { cwd: repo, env, encoding: 'utf8', timeout: 30_000 });
fs.writeFileSync(path.join(output, 'scenario.stdout.log'), scenario.stdout || ''); fs.writeFileSync(path.join(output, 'scenario.stderr.log'), scenario.stderr || '');
fs.writeFileSync(path.join(output, 'scenario.exit.json'), JSON.stringify({ status: scenario.status, signal: scenario.signal, error: scenario.error?.message || null }, null, 2));
assert.equal(scenario.error, undefined); assert.equal(scenario.status, 0, scenario.stderr);
const reportFile = path.join(output, 'scenario/same-scenario-report.json'), report = JSON.parse(fs.readFileSync(reportFile, 'utf8'));
const contractFile = path.join(output, 'same-contract-result.json');
const contract = spawnSync(process.execPath, [originalContract, reportFile, contractFile], { cwd: repo, env, encoding: 'utf8', timeout: 30_000 });
fs.writeFileSync(path.join(output, 'contract.stdout.log'), contract.stdout || ''); fs.writeFileSync(path.join(output, 'contract.stderr.log'), contract.stderr || '');
fs.writeFileSync(path.join(output, 'contract.exit.json'), JSON.stringify({ status: contract.status, signal: contract.signal, error: contract.error?.message || null }, null, 2));
assert.equal(contract.error, undefined);
const result = JSON.parse(fs.readFileSync(contractFile, 'utf8'));
assert.equal(result.controlFailures, 0); assert.equal(contract.status, mode === 'before' ? 1 : 0);
const bindings = { mode, sourceRoot: env.WRITER_ADMISSION_SOURCE_ROOT, originalArchiveSha256: sha(zipBytes),
  originalSupportSha256: sha(archived['frozen-writer-budget-fixture.cjs']), originalInvariantContractSha256: sha(fs.readFileSync(originalContract)),
  adaptedScenarioSha256: sha(fs.readFileSync(script)), adaptedBoundarySha256: sha(fs.readFileSync(path.join(repo, 'apps/admin/lib/fixtures/writer-admission-boundary.cjs'))),
  sourceCount: report.sources.length, sourceGraph: report.sources, invariants: result,
  adaptation: ['Original declaration loader and synthetic records are evaluated unchanged from the archived support bytes.',
    'New SDK boundary handles actual new RPCs only when the source calls them; captured BEFORE still executes original legacy effects.',
    'Observer snapshots actual provider calls/private effects and does not demand the original defect-specific extra two passes.',
    'All six invariant-contract assertions are original byte-identical, including both target assertions.'] };
fs.writeFileSync(path.join(output, 'adaptation-proof.json'), JSON.stringify(bindings, null, 2));
console.log(JSON.stringify({ output, mode, sourceCount: report.sources.length, providerCalls: report.providerCalls.length,
  controls: result.checks.filter(check => check.category !== 'target').map(check => check.pass), targetFailures: result.targetFailures,
  scenarioExit: scenario.status, contractExit: contract.status, invariantContractSha256: bindings.originalInvariantContractSha256 }, null, 2));
