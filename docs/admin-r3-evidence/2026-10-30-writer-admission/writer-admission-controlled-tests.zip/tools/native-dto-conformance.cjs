const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const repo = path.resolve(__dirname, '../../probpera-literary-map');
const output = path.join(__dirname, process.argv[2] || 'native-dto-v1');
assert.equal(fs.existsSync(output), false); fs.mkdirSync(output, { recursive: true });
const nativeRequire = createRequire(path.join(repo, 'package.json'));
const ts = nativeRequire('typescript'), { createClient } = nativeRequire('@supabase/supabase-js');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const graph = new Map(), cache = new Map();
function load(file) {
  if (cache.has(file)) return cache.get(file);
  const filename = path.join(repo, file), bytes = fs.readFileSync(filename);
  graph.set(file, { module: file, sha256: hash(bytes) });
  const capture = path.join(output, 'sources', file); fs.mkdirSync(path.dirname(capture), { recursive: true }); fs.writeFileSync(capture, bytes);
  const code = ts.transpileModule(bytes.toString(), { fileName: filename, compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, esModuleInterop: true } }).outputText;
  const module = { exports: {} }; cache.set(file, module.exports);
  function requireActual(name) {
    if (name.startsWith('.')) {
      const target = path.resolve(path.dirname(filename), name);
      for (const ext of ['.ts', '.tsx', '/index.ts']) if (fs.existsSync(target + ext)) return load(path.relative(repo, target + ext).replaceAll('\\','/'));
    }
    return nativeRequire(name);
  }
  new Function('require','module','exports',code)(requireActual,module,module.exports);
  return module.exports;
}
async function main() {
  const api = load('apps/admin/lib/writer-translation-operation-rpc.ts');
  const nativeRoot = path.join(repo, '../work/writer-operation-sql-native');
  const filenames = ['native-receipts.json','concurrent-receipts.json','native-artifacts.json'];
  const raw = filenames.map(file => { const filename = path.join(nativeRoot, file), bytes = fs.readFileSync(filename); return { file, filename, bytes, sha256: hash(bytes), data: JSON.parse(bytes) }; });
  const checks = [], wire = [];
  function record(name, body) {
    try { body(); checks.push({name,pass:true}); } catch(error) { checks.push({name,pass:false,error:error.stack||String(error)}); }
  }
  function visit(value, label) {
    if (!value || typeof value !== 'object') return;
    if (value.version === 1 && typeof value.jobId === 'string' && typeof value.entityId === 'string') {
      record(label, () => assert.ok(api.parseWriterTranslationOperationReceipt(value, {countryId:value.countryId,writerId:value.writerId}, value), 'Actual parser must accept the unchanged native receipt'));
      return;
    }
    for (const [key, nested] of Object.entries(value)) visit(nested, `${label}/${key}`);
  }
  for (const source of raw.slice(0,2)) visit(source.data, source.file);
  for (const [index, artifact] of raw[2].data.entries()) {
    const before = JSON.stringify(artifact);
    const sdk = createClient('https://native-writer-receipt.fixture.invalid', 'synthetic-no-auth-session', {
      auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}, global:{fetch:async(resource,init={})=>{
        const url = new URL(typeof resource==='string'?resource:resource.url), args = JSON.parse(init.body);
        assert.equal(url.origin,'https://native-writer-receipt.fixture.invalid');
        assert.ok(url.pathname.endsWith('/rpc/get_writer_translation_operation_artifacts'));
        assert.deepEqual(args,{p_job_id:artifact.receipt.jobId,p_item_id:artifact.receipt.itemId,p_operation_id:artifact.receipt.operationId,p_intent_hash:artifact.receipt.intentHash,p_source_hash:artifact.receipt.sourceHash});
        wire.push({path:url.pathname,args}); return new Response(JSON.stringify(artifact),{status:200,headers:{'Content-Type':'application/json'}});
      }} });
    try {
      const parsed = await api.getWriterTranslationOperationArtifacts(sdk, artifact.receipt);
      assert.deepEqual(parsed,artifact); assert.equal(JSON.stringify(artifact),before);
      checks.push({name:`native-artifacts.json/${index}: actual wrapper+installed SDK accepts unchanged native envelope`,pass:true});
    } catch(error) { checks.push({name:`native-artifacts.json/${index}`,pass:false,error:error.stack||String(error)}); }
  }
  for (const source of raw) record(`Raw native bytes unchanged: ${source.file}`,()=>assert.equal(hash(fs.readFileSync(source.filename)),source.sha256));
  for (const source of graph.values()) record(`Runtime source unchanged: ${source.module}`,()=>assert.equal(hash(fs.readFileSync(path.join(repo,source.module))),source.sha256));
  const report = {checkedAt:new Date().toISOString(),checks,pass:checks.every(check=>check.pass),rawInputs:raw.map(({file,filename,sha256})=>({file,filename,sha256})),
    sources:[...graph.values()],wire,limitations:['Original native payloads are unchanged; actual TypeScript parser/get wrapper and installed SDK execute.',
      'Only local SDK response transport is controlled here. Native PostgreSQL execution belongs to the separately frozen SQL evidence; no service/provider/network call.']};
  fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({output,checks:checks.length,failed:checks.filter(check=>!check.pass),sources:graph.size,reportSha256:hash(fs.readFileSync(path.join(output,'report.json')))},null,2));
  process.exitCode=report.pass?0:1;
}
main().catch(error=>{console.error(error.stack||error);process.exitCode=2;});
