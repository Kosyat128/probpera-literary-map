const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { createRequire } = require('node:module');
const repo = path.resolve(__dirname, '../../probpera-literary-map');
const nativeRequire = createRequire(path.join(repo, 'package.json'));
const ts = nativeRequire('typescript');
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const oldFile = path.join(__dirname, 'original-fixtures/writer-batch-budget-cap.cjs');
const currentFile = path.join(repo, 'apps/admin/lib/fixtures/writer-batch-budget-cap.cjs');
const oldBytes = fs.readFileSync(oldFile), currentBytes = fs.readFileSync(currentFile);
assert.equal(sha(oldBytes),'1b5f9959c94b1a9ab3e80cb7df306defe9b72008be6c96b68d011efd68e2a22d');
function targets(bytes) {
  const source = ts.createSourceFile('fixture.cjs',bytes.toString(),ts.ScriptTarget.Latest,true,ts.ScriptKind.JS), found=[];
  function visit(node) {
    if(ts.isObjectLiteralExpression(node)) {
      const fields={};
      for(const property of node.properties) if(ts.isPropertyAssignment(property)) fields[property.name.getText(source)]=property.initializer;
      if(fields.category && ts.isStringLiteral(fields.category) && fields.category.text==='target') {
        assert.ok(fields.name && ts.isStringLiteral(fields.name)); assert.ok(fields.expected);
        found.push({name:fields.name.text,expected:fields.expected.getText(source)});
      }
    }
    ts.forEachChild(node,visit);
  }
  visit(source); return found;
}
const originalTargets=targets(oldBytes), adaptedTargets=targets(currentBytes);
assert.equal(originalTargets.length,4); assert.deepEqual(adaptedTargets,originalTargets);
const protectedFixtures=[
  ['apps/admin/lib/fixtures/library-batch-budget-cap.cjs','06aa8089f66b4e0e9ee044b7447d77c1b3e7167f018464069a22a8f949314795'],
  ['apps/admin/lib/fixtures/country-batch-budget-cap.cjs','495714edecd96860e1eb7d3f2dfd1232fdf486f7fc9621c68432a549753c3617'],
  ['docs/admin-r3-evidence/2026-10-29-profile-budgets/next-writer-admission-before.zip','44eceea641f3b19178a24b0824fa14b6adef0c77f4933db038d9a2404e498949'],
].map(([file,expected])=>{const actual=sha(fs.readFileSync(path.join(repo,file)));assert.equal(actual,expected);return{file,sha256:actual};});
const report={checkedAt:new Date().toISOString(),originalWriterFixtureSha256:sha(oldBytes),adaptedWriterFixtureSha256:sha(currentBytes),
  targetNamesAndExpectedValuesIdentical:true,originalTargets,protectedFixtures,
  scope:'Writer protocol observers follow actual new durable FINISH receipts and retain the four original expected values. Library/country fixture bytes and original admission BEFORE archive remain exact. SDK boundary changes are explicit; this is not an assertion that every old writer fixture byte is unchanged.'};
const output=path.join(__dirname,process.argv[2]||'test-adaptation-preservation-v1.json');
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output,sha256:sha(fs.readFileSync(output)),originalTargets},null,2));
