const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const repo = path.resolve(__dirname,'../../probpera-literary-map'), output = path.join(__dirname,process.argv[2]||'final-focused-v2');
assert.equal(fs.existsSync(output),false);fs.mkdirSync(output,{recursive:true});
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const files=[
 'apps/admin/lib/translation-response-artifacts.integration.test.ts','apps/admin/lib/writer-translation-operation-rpc.integration.test.ts',
 'apps/admin/lib/writer-admission.integration.test.ts','apps/admin/lib/writer-admission-routing.integration.test.ts',
 'apps/admin/lib/fixtures/writer-admission-boundary.cjs','apps/admin/lib/fixtures/writer-admission-runtime.cjs','apps/admin/lib/fixtures/writer-admission-cases.cjs',
 'apps/admin/lib/fixtures/writer-biography-machine-review.cjs','apps/admin/lib/fixtures/writer-batch-budget-cap.cjs',
 'apps/admin/lib/fixtures/profile-library-budget-controls.cjs','apps/admin/lib/profile-library-batch-budgets.integration.test.ts',
];
const snapshots=files.map(file=>{const bytes=fs.readFileSync(path.join(repo,file)),destination=path.join(output,'sources',file);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);return{file,sha256:sha(bytes)};});
const dependencyFile='apps/admin/lib/writer-biography-machine-review.integration.test.ts',dependencyBytes=fs.readFileSync(path.join(repo,dependencyFile));
const dependencyDestination=path.join(output,'dependencies',dependencyFile);fs.mkdirSync(path.dirname(dependencyDestination),{recursive:true});fs.writeFileSync(dependencyDestination,dependencyBytes);
const previousFull=fs.readdirSync(path.resolve(repo,'../work')).filter(name=>name.startsWith('writer-admission-maintained-'))
 .map(name=>path.resolve(repo,'../work',name,'writer-admission-cases-report.json')).filter(file=>fs.existsSync(file)).sort((a,b)=>fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs)[0];
const productionFiles=new Set(JSON.parse(fs.readFileSync(previousFull,'utf8')).sources.map(source=>source.module));
for(const file of ['apps/admin/lib/writer-translation-operation-marker.ts','apps/admin/app/(dashboard)/translations/resume-action.ts',
 'apps/admin/app/(dashboard)/editorial-database/page.tsx','apps/admin/app/(dashboard)/translations/page.tsx'])productionFiles.add(file);
const productionSources=[...productionFiles].sort().map(file=>{const bytes=fs.readFileSync(path.join(repo,file)),destination=path.join(output,'production-sources',file);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);return{file,sha256:sha(bytes)};});
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>/^(?:PATH|SystemRoot|windir|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i.test(key)));
const temp=path.join(output,'temp');fs.mkdirSync(temp);Object.assign(env,{TEMP:temp,TMP:temp});
const tests=files.filter(file=>file.endsWith('.integration.test.ts'));
tests.splice(4,0,'apps/admin/lib/writer-biography-machine-review.integration.test.ts');
const commands=[['typescript',path.join(repo,'node_modules/typescript/bin/tsc'),'--noEmit','--project','apps/admin/tsconfig.json'],
 ['focused-vitest',path.join(repo,'node_modules/vitest/vitest.mjs'),'run',...tests,'--reporter=dot']];
const results=[];
for(const [label,script,...args]of commands){
 const result=spawnSync(process.execPath,[script,...args],{cwd:repo,env,encoding:'utf8',timeout:60_000,maxBuffer:32*1024*1024});
 fs.writeFileSync(path.join(output,`${label}.stdout.log`),result.stdout||'');fs.writeFileSync(path.join(output,`${label}.stderr.log`),result.stderr||'');
 results.push({label,args:[script,...args],exitCode:result.status,signal:result.signal,error:result.error?.message||null});
}
const unchanged=snapshots.every(item=>sha(fs.readFileSync(path.join(repo,item.file)))===item.sha256);
const productionUnchanged=productionSources.every(item=>sha(fs.readFileSync(path.join(repo,item.file)))===item.sha256);
const receipt={checkedAt:new Date().toISOString(),results,unchanged,productionUnchanged,sources:snapshots,productionSources,
 selectedAssertionDependencies:[{file:dependencyFile,sha256:sha(dependencyBytes),unchanged:sha(fs.readFileSync(path.join(repo,dependencyFile)))===sha(dependencyBytes)}],
 scope:'Six focused integration files. No skips or changes to country/library fixtures; standalone React SSR action warning retained in stderr. This is controlled local acceptance, not managed Auth/DB/provider/browser/production acceptance.'};
fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({output,results,unchanged,receiptSha256:sha(fs.readFileSync(path.join(output,'receipt.json')))},null,2));
for(const item of results)assert.equal(item.exitCode,0,`${item.label} failed`);assert.equal(unchanged,true);assert.equal(productionUnchanged,true);
