import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdirSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { beforeAll, describe, expect, it } from "vitest";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");
const nativeRequire = createRequire(import.meta.url);
const { unzipSync } = nativeRequire("fflate") as { unzipSync(input: Uint8Array): Record<string, Uint8Array> };
const hash = (bytes: Uint8Array) => createHash("sha256").update(bytes).digest("hex");
const environment = () => Object.fromEntries(Object.entries(process.env).filter(([key]) =>
  /^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i.test(key))) as NodeJS.ProcessEnv;
const work = path.resolve(root, "../work");
type Check = { name: string; pass: boolean; error?: string };
const cases = [
  "Accepted unknown request blocks a fresh batch and creates no duplicate paid journal",
  "Unknown paid request retains a nonzero current cursor instead of committing next",
  "Deadline before the first provider dispatch keeps the nonzero cursor and costs zero calls",
  "A malformed BEGIN capability cannot authorize provider work in the actual helper",
  "Two concurrent helper admissions share one provider operation for the same revision",
  "Lost BEGIN acknowledgement confirms zero calls before a safe fresh attempt",
  "Lost dispatch acknowledgement never repeats or invents a provider request",
  "A retained raw first response is not a complete reviewed candidate and is not automatically resumed",
  "A lost final response acknowledgement recovers the complete paid body with zero further provider calls",
  "A lost FINISH acknowledgement reconciles the existing complete candidate without regeneration",
  "Completed paid candidate survives target CAS takeover without changing canonical author data",
  "Completed paid candidate survives manual English takeover without changing canonical author data",
  "Concurrent pending-slot takeover preserves both the existing slot and the new complete paid artifact",
  "Cancellation after accepted final review retains the complete paid body without claiming completion",
  "Manual current and already pending records cost no additional admission or provider work",
  "Default ordinary helper uses one four-pass attempt and repeats pending output at zero cost",
  "Shared writer batch permits three four-pass candidates and no thirteenth provider call",
  "Structured writer save persists RU and requests its ordinary build before provider admission",
  "Generic writer save persists source and requests its ordinary build before provider admission",
];

describe("M07 writer durable admission and completed private output integration", () => {
  let report: { checks: Check[]; unchanged: boolean; boundaryErrors: unknown[] };
  beforeAll(() => {
    mkdirSync(work, { recursive: true });
    const output = mkdtempSync(path.join(work, "writer-admission-maintained-"));
    const run = spawnSync(process.execPath, [path.join(root, "apps/admin/lib/fixtures/writer-admission-cases.cjs")], {
      cwd: root, env: { ...environment(), WRITER_ADMISSION_REPO: root, WRITER_ADMISSION_SOURCE_ROOT: root, WRITER_ADMISSION_OUTPUT_ROOT: output },
      encoding: "utf8", timeout: 60_000, maxBuffer: 16 * 1024 * 1024,
    });
    expect(run.error, run.stderr).toBeUndefined(); expect(run.stderr).toBe("");
    report = JSON.parse(readFileSync(path.join(output, "writer-admission-cases-report.json"), "utf8"));
    expect(report.checks.map(item => item.name)).toEqual(cases);
    expect(report.unchanged).toBe(true); expect(report.boundaryErrors).toEqual([]);
    expect(run.status, JSON.stringify(report.checks.filter(item => !item.pass))).toBe(0);
  }, 65_000);
  it.each(cases)("%s", name => {
    const result = report.checks.find(check => check.name === name);
    expect(result).toBeDefined(); expect(result!.pass, result!.error).toBe(true);
  });
});

describe.each(["before", "current"] as const)("M07 %s source with original frozen SAME invariant contract", mode => {
  it("executes actual algorithms and preserves the original assertions through the explicit SDK/observer adaptation", () => {
    mkdirSync(work, { recursive: true });
    const output = mkdtempSync(path.join(work, `writer-admission-same-${mode}-`));
    const archive = readFileSync(path.join(root, "docs/admin-r3-evidence/2026-10-29-profile-budgets/next-writer-admission-before.zip"));
    expect(hash(archive)).toBe("44eceea641f3b19178a24b0824fa14b6adef0c77f4933db038d9a2404e498949");
    const entries = unzipSync(archive), beforeRoot = path.join(output, "before-source");
    for (const [file, bytes] of Object.entries(entries)) {
      if (!file.startsWith("diagnostic-current/raw-graph/sources/")) continue;
      const destination = path.join(beforeRoot, file.slice("diagnostic-current/raw-graph/sources/".length));
      mkdirSync(path.dirname(destination), { recursive: true }); writeFileSync(destination, bytes, { flag: "wx" });
    }
    const contract = path.join(output, "original-contract.cjs");
    writeFileSync(contract, entries["writer-provider-admission.same-contract.cjs"], { flag: "wx" });
    expect(hash(readFileSync(contract))).toBe("239bf9786db1c2c998edb5a4b6092b4460d8b1b9efeace0c94071deffaccc3ea");
    const env = { ...environment(), WRITER_ADMISSION_REPO: root, WRITER_ADMISSION_SOURCE_ROOT: mode === "before" ? beforeRoot : root,
      WRITER_ADMISSION_OUTPUT_ROOT: path.join(output, "scenario") };
    const run = spawnSync(process.execPath, [path.join(root, "apps/admin/lib/fixtures/writer-admission-runtime.cjs")], {
      cwd: root, env, encoding: "utf8", timeout: 30_000, maxBuffer: 8 * 1024 * 1024,
    });
    expect(run.error, run.stderr).toBeUndefined(); expect(run.status, run.stderr).toBe(0);
    const resultFile = path.join(output, "contract-result.json");
    const check = spawnSync(process.execPath, [contract, path.join(output, "scenario/same-scenario-report.json"), resultFile], {
      cwd: root, env, encoding: "utf8", timeout: 30_000, maxBuffer: 8 * 1024 * 1024,
    });
    expect(check.error, check.stderr).toBeUndefined();
    const result = JSON.parse(readFileSync(resultFile, "utf8"));
    expect(result.controlFailures).toBe(0);
    expect(result.targetFailures).toBe(mode === "before" ? 2 : 0);
    expect(check.status, check.stderr).toBe(mode === "before" ? 1 : 0);
  }, 65_000);
});
