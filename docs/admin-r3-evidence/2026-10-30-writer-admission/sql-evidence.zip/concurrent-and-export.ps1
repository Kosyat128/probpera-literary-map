$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\writer-operation-sql-native'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-export.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8'
 $psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not the owned isolated cluster'}
 $database='writer_operations_v7_20261029'
 $sql="begin;set local role authenticated;select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);select public.writer_operation_fixture_begin('concurrent-writer');select pg_sleep(0.75);commit;"
 $raceFile=Join-Path $nativeRoot 'concurrent-session.sql'
 [IO.File]::WriteAllText($raceFile,$sql,[Text.UTF8Encoding]::new($false))
 $processes=@()
 foreach($serial in 1..2){
  $info=[Diagnostics.ProcessStartInfo]::new()
  $info.FileName=$psql;$info.UseShellExecute=$false;$info.CreateNoWindow=$true
  $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  foreach($argument in @('-h','127.0.0.1','-p','55438','-U','postgres','-d',$database,'--no-psqlrc','--set=ON_ERROR_STOP=1','-qAt','-f',$raceFile)){$info.ArgumentList.Add($argument)}
  $process=[Diagnostics.Process]::new();$process.StartInfo=$info
  $stopwatch=[Diagnostics.Stopwatch]::StartNew()
  if(-not $process.Start()){throw 'Concurrent client failed to start'}
  $processes+=@{serial=$serial;process=$process;stdout=$process.StandardOutput.ReadToEndAsync();stderr=$process.StandardError.ReadToEndAsync();clock=$stopwatch}
 }
 $receipts=@();$sessions=@()
 foreach($entry in $processes){
  if(-not $entry.process.WaitForExit(10000)){$entry.process.Kill();throw 'Concurrent owned client timed out'}
  $entry.clock.Stop();$stdout=$entry.stdout.GetAwaiter().GetResult();$stderr=$entry.stderr.GetAwaiter().GetResult()
  [IO.File]::WriteAllText((Join-Path $nativeRoot ('concurrent-'+$entry.serial+'.stdout.log')),$stdout)
  [IO.File]::WriteAllText((Join-Path $nativeRoot ('concurrent-'+$entry.serial+'.stderr.log')),$stderr)
  if($entry.process.ExitCode -ne 0){throw ('Concurrent SQL failed: '+$stderr)}
  $receiptLines=@($stdout -split "`n"|Where-Object{$_.TrimStart().StartsWith('{')})
  if($receiptLines.Count -ne 1){throw 'Unexpected concurrent receipt count'}
  $receipts+=($receiptLines[0]|ConvertFrom-Json)
  $sessions+=@{serial=$entry.serial;pid=$entry.process.Id;exitCode=$entry.process.ExitCode;elapsedMs=$entry.clock.ElapsedMilliseconds}
 }
 if(@($receipts|Where-Object{$_.canExecute}).Count -ne 1 -or @($receipts|Where-Object{-not $_.canExecute}).Count -ne 1){throw 'Concurrent admissions were not exclusive'}
 if($receipts[0].operationId -ne $receipts[1].operationId){throw 'Concurrent barrier identity differs'}
 [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');sessions=$sessions;receipts=$receipts;passed=$true;actualSessions=2;providerCalls=0}|ConvertTo-Json -Depth 30|Set-Content -LiteralPath(Join-Path $nativeRoot 'concurrent-receipts.json') -Encoding utf8
 $queries=@{
  'native-receipts.json'='select jsonb_object_agg(label,value) from public.writer_operation_fixture_results';
  'native-artifacts.json'="select jsonb_agg(public.get_writer_translation_operation_artifacts(job_id,item_id,operation_id,intent_hash,source_hash) order by entity_id) from premium_translation_private.writer_operation_artifacts where entity_id in ('operation-country:complete-writer','operation-country:slot-writer','operation-country:unknown-writer')";
  'native-functions.json'="select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'securityDefiner',p.prosecdef,'config',p.proconfig,'source',p.prosrc) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where (n.nspname='public' and (p.proname like '%writer_translation_operation%' or p.proname='writer_translation_operation_ready')) or (n.nspname='premium_translation_private' and p.proname like 'writer_operation_%')";
  'native-concurrent-count.json'="select jsonb_build_object('items',count(*),'active',count(*) filter(where staff_retry is not null)) from public.translation_job_items where entity_id='operation-country:concurrent-writer'";
 }
 foreach($filename in $queries.Keys){
  $query="select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);"+$queries[$filename]
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc $query
  if($LASTEXITCODE -ne 0){throw ('Export failed '+$filename)}
  $json=@($raw|Where-Object{ $_.StartsWith('{') -or $_.StartsWith('[')})
  if($json.Count -ne 1){throw ('Unexpected JSON export '+$filename)}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $filename),$json[0],[Text.UTF8Encoding]::new($false))
 }
 $available=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc -Atc "select count(*) from pg_available_extensions where name='plpgsql_check'"
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1'
 $env:SUPABASE_HOME='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\writer-operation-sql-native\cli-home'
 $cli='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\portable-db-tools\supabase-2.120.0\supabase.exe'
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$database+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors.log')
 $advisorExit=$LASTEXITCODE
 [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');target=('owned loopback '+$database);advisorsExitCode=$advisorExit;lintStatus='NOT_RUN_PLPGSQL_CHECK_UNAVAILABLE_NO_INSTALL';plpgsqlCheckAvailable=[int]$available;installedAnything=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-receipt.json') -Encoding utf8
 Write-Output 'ACTUAL_TWO_SESSION_EXCLUSIVE_ADMISSION_PASS'
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'export-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'export-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
