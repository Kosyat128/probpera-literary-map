\set ON_ERROR_STOP on
\pset tuples_only on
\pset format unaligned

create role anon nologin;
create role authenticated nologin;
create schema auth;
grant usage on schema auth to authenticated;

create table auth.users (id uuid primary key);

create or replace function auth.uid()
returns uuid
language sql
stable
set search_path = ''
as $$
  select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
$$;
grant execute on function auth.uid() to authenticated;

create type public.staff_role as enum ('owner', 'admin', 'editor');
create type public.article_status as enum (
  'draft', 'review', 'scheduled', 'published', 'hidden', 'archived'
);
create type public.article_translation_status as enum (
  'draft', 'review', 'approved', 'published', 'stale', 'archived'
);

create table public.staff_memberships (
  user_id uuid primary key references auth.users(id),
  role public.staff_role not null
);
create or replace function public.is_staff(
  allowed_roles public.staff_role[] default array[
    'owner'::public.staff_role,
    'admin'::public.staff_role,
    'editor'::public.staff_role
  ]
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.staff_memberships
    where user_id = (select auth.uid()) and role = any(allowed_roles)
  );
$$;
revoke all on function public.is_staff(public.staff_role[]) from public;
grant execute on function public.is_staff(public.staff_role[]) to authenticated;

create table public.categories (
  id uuid primary key,
  slug text not null unique
);

create table public.articles (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  title text not null check (char_length(title) between 3 and 240),
  subtitle text not null default '',
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  cover_external_url text,
  cover_alt text not null default '',
  category_id uuid references public.categories(id),
  status public.article_status not null default 'draft',
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,179}$'),
  legacy_path text unique,
  published_at timestamptz,
  scheduled_at timestamptz,
  featured boolean not null default false,
  show_on_homepage boolean not null default false,
  pinned boolean not null default false,
  sources jsonb not null default '[]'::jsonb,
  bibliography jsonb not null default '[]'::jsonb,
  seo_title text,
  seo_description text,
  seo_keywords text[] not null default '{}',
  canonical_url text,
  og_title text,
  og_description text,
  allow_indexing boolean not null default true,
  created_by uuid not null references auth.users(id),
  updated_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  check (status <> 'scheduled' or scheduled_at is not null),
  check (status <> 'published' or published_at is not null)
);

create table public.article_revisions (
  id bigint generated always as identity primary key,
  article_id uuid not null references public.articles(id) on delete cascade,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid,
  created_at timestamptz not null default now(),
  unique(article_id, revision_number)
);

create table public.article_translations (
  id uuid primary key default gen_random_uuid(),
  article_id uuid not null references public.articles(id) on delete cascade,
  locale text not null,
  title text not null check (char_length(title) between 3 and 240),
  subtitle text not null default '',
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  cover_alt text not null default '',
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{1,179}$'),
  sources jsonb not null default '[]'::jsonb,
  bibliography jsonb not null default '[]'::jsonb,
  seo_title text,
  seo_description text,
  seo_keywords text[] not null default '{}',
  canonical_url text,
  og_title text,
  og_description text,
  status public.article_translation_status not null default 'draft',
  source_content_hash text,
  source_article_updated_at timestamptz,
  reviewed_by uuid,
  reviewed_at timestamptz,
  approved_by uuid,
  approved_at timestamptz,
  published_at timestamptz,
  created_by uuid not null references auth.users(id),
  updated_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique(article_id, locale),
  unique(locale, slug),
  check (status not in ('approved', 'published') or approved_at is not null),
  check (status <> 'published' or published_at is not null)
);

create table public.article_translation_revisions (
  id bigint generated always as identity primary key,
  article_translation_id uuid not null references public.article_translations(id),
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid,
  created_at timestamptz not null default now(),
  unique(article_translation_id, revision_number)
);

create table public.redirects (
  id uuid primary key default gen_random_uuid(),
  source_path text not null unique,
  destination_path text not null,
  status_code smallint not null default 301,
  is_active boolean not null default true,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.admin_audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid,
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create table public.public_build_outbox (
  id bigint generated always as identity primary key,
  actor_id uuid,
  entity_type text not null,
  entity_id text not null,
  reason text not null,
  status text not null default 'requested',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = clock_timestamp(); return new; end;
$$;
create trigger articles_set_updated_at before update on public.articles
for each row execute function public.set_updated_at();
create trigger article_translations_set_updated_at before update on public.article_translations
for each row execute function public.set_updated_at();
create trigger redirects_set_updated_at before update on public.redirects
for each row execute function public.set_updated_at();

create or replace function public.capture_article_revision()
returns trigger language plpgsql security definer set search_path = '' as $$
declare n integer;
begin
  if old is not distinct from new then return new; end if;
  select coalesce(max(revision_number), 0) + 1 into n
  from public.article_revisions where article_id = old.id;
  insert into public.article_revisions(article_id, revision_number, snapshot, changed_by)
  values(old.id, n, to_jsonb(old), coalesce(new.updated_by, (select auth.uid())));
  return new;
end;
$$;
create trigger articles_capture_revision before update on public.articles
for each row execute function public.capture_article_revision();

create or replace function public.capture_article_translation_revision()
returns trigger language plpgsql security definer set search_path = '' as $$
declare n integer;
begin
  if old is not distinct from new then return new; end if;
  select coalesce(max(revision_number), 0) + 1 into n
  from public.article_translation_revisions
  where article_translation_id = old.id;
  insert into public.article_translation_revisions(
    article_translation_id, revision_number, snapshot, changed_by
  ) values(old.id, n, to_jsonb(old), coalesce(new.updated_by, (select auth.uid())));
  return new;
end;
$$;
create trigger article_translations_capture_revision
before update on public.article_translations
for each row execute function public.capture_article_translation_revision();

-- Mimic the important production behavior: changing the Russian source can
-- stale a released English translation before the explicit English save runs.
create or replace function public.fixture_sync_english_after_article()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'UPDATE' and old.title is distinct from new.title then
    update public.article_translations
    set status = 'stale', approved_by = null, approved_at = null,
        published_at = null, updated_by = new.updated_by
    where article_id = new.id and locale = 'en'
      and status in ('approved', 'published');
  end if;
  return new;
end;
$$;
create trigger articles_fixture_sync_english
after update on public.articles
for each row execute function public.fixture_sync_english_after_article();

create or replace function public.fixture_capture_outbox()
returns trigger language plpgsql security definer set search_path = '' as $$
declare row_data jsonb;
begin
  row_data := case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end;
  insert into public.public_build_outbox(actor_id, entity_type, entity_id, reason, metadata)
  values((select auth.uid()), tg_table_name,
    coalesce(row_data ->> 'id', row_data ->> 'article_id', tg_table_name),
    'database-' || lower(tg_op),
    jsonb_build_object('operation', lower(tg_op), 'table', tg_table_name));
  return case when tg_op = 'DELETE' then old else new end;
end;
$$;
create trigger articles_public_build_outbox after insert or update or delete on public.articles
for each row execute function public.fixture_capture_outbox();
create trigger article_translations_public_build_outbox after insert or update or delete on public.article_translations
for each row execute function public.fixture_capture_outbox();
create trigger redirects_public_build_outbox after insert or update or delete on public.redirects
for each row execute function public.fixture_capture_outbox();

alter table public.articles enable row level security;
alter table public.article_translations enable row level security;
alter table public.redirects enable row level security;
alter table public.admin_audit_log enable row level security;
grant usage on schema public to authenticated;
grant select, insert, update, delete on public.articles to authenticated;
grant select, insert, update, delete on public.article_translations to authenticated;
grant select, insert, update on public.redirects to authenticated;
grant select, insert on public.admin_audit_log to authenticated;
-- These are assertion-only reads in this isolated integration fixture. The
-- production privilege model remains unchanged.
grant select on public.article_revisions to authenticated;
grant select on public.article_translation_revisions to authenticated;
grant select on public.public_build_outbox to authenticated;
grant usage, select on all sequences in schema public to authenticated;

create policy "Staff read articles" on public.articles for select to authenticated
using (public.is_staff());
create policy "Staff create articles" on public.articles for insert to authenticated
with check (public.is_staff() and created_by = (select auth.uid()) and updated_by = (select auth.uid()));
create policy "Staff update articles" on public.articles for update to authenticated
using (public.is_staff()) with check (public.is_staff() and updated_by = (select auth.uid()));
create policy "Staff read article translations" on public.article_translations for select to authenticated
using (public.is_staff());
create policy "Staff create article translations" on public.article_translations for insert to authenticated
with check (public.is_staff() and created_by = (select auth.uid()) and updated_by = (select auth.uid()));
create policy "Staff update article translations" on public.article_translations for update to authenticated
using (public.is_staff()) with check (public.is_staff() and updated_by = (select auth.uid()));
create policy "Staff manage redirects" on public.redirects for all to authenticated
using (public.is_staff()) with check (public.is_staff() and created_by = (select auth.uid()));
create policy "Staff append audit log" on public.admin_audit_log for insert to authenticated
with check (public.is_staff() and actor_id = (select auth.uid()));

-- The migration's schema-health function expects these names to exist or be
-- safely probeable. Only public_build_outbox is referenced as a real relation.
create or replace function public.enqueue_public_build_request(text,text,text,jsonb)
returns bigint language sql as $$ select 1::bigint $$;
create or replace function public.move_homepage_block(uuid,text)
returns boolean language sql as $$ select true $$;


create role service_role nologin bypassrls;
create type public.page_status as enum ('draft','published','hidden');
create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 2 and 180),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,119}$'),
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  status public.page_status not null default 'draft',
  seo_title text,
  seo_description text,
  canonical_url text,
  allow_indexing boolean not null default true,
  created_by uuid not null references auth.users(id) on delete restrict,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.page_revisions (
  id bigint generated always as identity primary key,
  page_id uuid not null references public.pages(id) on delete cascade,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (page_id, revision_number)
);

alter table public.pages enable row level security;
alter table public.page_revisions enable row level security;
create policy "Public read published pages"
on public.pages for select
to anon, authenticated
using (
  (status = 'published' and deleted_at is null)
);

create policy "Staff manage pages"
on public.pages for all
to authenticated
using (public.is_staff())
with check (
  public.is_staff()
  and created_by is not null
  and updated_by = (select auth.uid())
);

create policy "Staff read page revisions"
on public.page_revisions for select
to authenticated
using (public.is_staff());


grant select, insert, update, delete on public.pages to authenticated;
grant select on public.page_revisions to authenticated;
create or replace function public.fixture_page_set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
create trigger pages_set_updated_at before update on public.pages
for each row execute function public.fixture_page_set_updated_at();
-- Version history for permanent CMS pages.
-- Article revisions were part of the initial CMS migration; pages use the
-- same immutable-snapshot model so every editorial change is recoverable.

create or replace function public.capture_page_revision()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_revision integer;
begin
  if old is not distinct from new then
    return new;
  end if;

  select coalesce(max(revision_number), 0) + 1
  into next_revision
  from public.page_revisions
  where page_id = old.id;

  insert into public.page_revisions (
    page_id,
    revision_number,
    snapshot,
    changed_by
  )
  values (
    old.id,
    next_revision,
    to_jsonb(old),
    coalesce(new.updated_by, (select auth.uid()))
  );

  return new;
end;
$$;

drop trigger if exists pages_capture_revision on public.pages;
create trigger pages_capture_revision
  before update on public.pages
  for each row execute function public.capture_page_revision();

create index if not exists page_revisions_page_idx
  on public.page_revisions(page_id, revision_number desc);

create trigger pages_public_build_outbox after insert or update or delete on public.pages
for each row execute function public.fixture_capture_outbox();
create or replace function public.capture_public_build_outbox()
returns trigger language plpgsql security definer set search_path = '' as $$
begin return case when tg_op = 'DELETE' then old else new end; end;
$$;
-- Save the canonical Russian article row and its optional English translation in
-- one PostgreSQL transaction. Existing revision and public-build outbox triggers
-- remain authoritative and therefore commit or roll back with this function.
--
-- The function is deliberately SECURITY INVOKER: authenticated staff keep the
-- existing RLS checks and no privileged service-role path is introduced.

create or replace function public.save_article_bundle(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz,
  p_article_payload jsonb,
  p_english_mode text default 'none',
  p_english_payload jsonb default null,
  p_expected_english_updated_at timestamptz default null,
  p_redirect_source_path text default null,
  p_redirect_destination_path text default null,
  p_replace_homepage boolean default false,
  p_audit_action text default null,
  p_audit_metadata jsonb default '{}'::jsonb,
  p_social_publish_requested boolean default false,
  p_social_metadata jsonb default '{}'::jsonb
)
returns table (
  article_id uuid,
  article_updated_at timestamptz,
  english_updated_at timestamptz,
  homepage_replaced integer
)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  current_article public.articles%rowtype;
  current_english public.article_translations%rowtype;
  saved_article public.articles%rowtype;
  saved_english public.article_translations%rowtype;
  has_article boolean := false;
  has_english boolean := false;
  article_keywords text[];
  english_keywords text[];
  replaced_count integer := 0;
  effective_audit_action text;
begin
  if actor_id is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;

  if p_article_payload is null
    or jsonb_typeof(p_article_payload) <> 'object' then
    raise exception using errcode = '22023', message = 'ARTICLE_PAYLOAD_REQUIRED';
  end if;

  if p_english_mode not in ('none', 'save', 'stale') then
    raise exception using errcode = '22023', message = 'INVALID_ENGLISH_MODE';
  end if;

  if p_english_mode = 'save'
    and (p_english_payload is null or jsonb_typeof(p_english_payload) <> 'object') then
    raise exception using errcode = '22023', message = 'ENGLISH_PAYLOAD_REQUIRED';
  end if;

  article_keywords := coalesce(
    array(
      select jsonb_array_elements_text(
        coalesce(p_article_payload -> 'seo_keywords', '[]'::jsonb)
      )
    ),
    '{}'::text[]
  );

  if p_english_mode = 'save' then
    english_keywords := coalesce(
      array(
        select jsonb_array_elements_text(
          coalesce(p_english_payload -> 'seo_keywords', '[]'::jsonb)
        )
      ),
      '{}'::text[]
    );
  end if;

  -- Lock and validate both rows before the article UPDATE. Updating an article
  -- can legitimately mark a released English translation stale through the
  -- existing sync trigger, which also changes its updated_at. Checking the
  -- English timestamp after that trigger would create a false conflict.
  if p_article_id is not null then
    select *
    into current_article
    from public.articles
    where id = p_article_id
    for update;
    has_article := found;

    if not has_article then
      raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
    end if;

    if p_expected_article_updated_at is null
      or current_article.updated_at is distinct from p_expected_article_updated_at then
      raise exception using errcode = 'P0001', message = 'ARTICLE_CONFLICT';
    end if;

    if p_english_mode in ('save', 'stale') then
      select english_translation.*
      into current_english
      from public.article_translations as english_translation
      where english_translation.article_id = p_article_id
        and english_translation.locale = 'en'
      for update;
      has_english := found;

      if has_english then
        if p_expected_english_updated_at is null
          or current_english.updated_at is distinct from p_expected_english_updated_at then
          raise exception using errcode = 'P0001', message = 'ENGLISH_CONFLICT';
        end if;
      elsif p_expected_english_updated_at is not null then
        raise exception using errcode = 'P0001', message = 'ENGLISH_CONFLICT';
      end if;
    end if;

    update public.articles
    set
      title = p_article_payload ->> 'title',
      subtitle = coalesce(p_article_payload ->> 'subtitle', ''),
      excerpt = coalesce(p_article_payload ->> 'excerpt', ''),
      slug = p_article_payload ->> 'slug',
      content_html = coalesce(p_article_payload ->> 'content_html', ''),
      content_json = coalesce(
        p_article_payload -> 'content_json',
        '{"type":"doc","content":[]}'::jsonb
      ),
      category_id = nullif(p_article_payload ->> 'category_id', '')::uuid,
      status = (p_article_payload ->> 'status')::public.article_status,
      scheduled_at = nullif(p_article_payload ->> 'scheduled_at', '')::timestamptz,
      published_at = nullif(p_article_payload ->> 'published_at', '')::timestamptz,
      cover_external_url = nullif(p_article_payload ->> 'cover_external_url', ''),
      cover_alt = coalesce(p_article_payload ->> 'cover_alt', ''),
      legacy_path = nullif(p_article_payload ->> 'legacy_path', ''),
      seo_title = nullif(p_article_payload ->> 'seo_title', ''),
      seo_description = nullif(p_article_payload ->> 'seo_description', ''),
      seo_keywords = article_keywords,
      canonical_url = nullif(p_article_payload ->> 'canonical_url', ''),
      og_title = nullif(p_article_payload ->> 'og_title', ''),
      og_description = nullif(p_article_payload ->> 'og_description', ''),
      allow_indexing = coalesce((p_article_payload ->> 'allow_indexing')::boolean, true),
      sources = coalesce(p_article_payload -> 'sources', '[]'::jsonb),
      bibliography = coalesce(p_article_payload -> 'bibliography', '[]'::jsonb),
      featured = coalesce((p_article_payload ->> 'featured')::boolean, false),
      show_on_homepage = coalesce(
        (p_article_payload ->> 'show_on_homepage')::boolean,
        false
      ),
      pinned = coalesce((p_article_payload ->> 'pinned')::boolean, false),
      updated_by = actor_id
    where id = p_article_id
    returning * into saved_article;
  else
    if p_expected_article_updated_at is not null then
      raise exception using errcode = 'P0001', message = 'ARTICLE_CONFLICT';
    end if;

    insert into public.articles (
      title,
      subtitle,
      excerpt,
      slug,
      content_html,
      content_json,
      category_id,
      status,
      scheduled_at,
      published_at,
      cover_external_url,
      cover_alt,
      legacy_path,
      seo_title,
      seo_description,
      seo_keywords,
      canonical_url,
      og_title,
      og_description,
      allow_indexing,
      sources,
      bibliography,
      featured,
      show_on_homepage,
      pinned,
      created_by,
      updated_by
    ) values (
      p_article_payload ->> 'title',
      coalesce(p_article_payload ->> 'subtitle', ''),
      coalesce(p_article_payload ->> 'excerpt', ''),
      p_article_payload ->> 'slug',
      coalesce(p_article_payload ->> 'content_html', ''),
      coalesce(
        p_article_payload -> 'content_json',
        '{"type":"doc","content":[]}'::jsonb
      ),
      nullif(p_article_payload ->> 'category_id', '')::uuid,
      (p_article_payload ->> 'status')::public.article_status,
      nullif(p_article_payload ->> 'scheduled_at', '')::timestamptz,
      nullif(p_article_payload ->> 'published_at', '')::timestamptz,
      nullif(p_article_payload ->> 'cover_external_url', ''),
      coalesce(p_article_payload ->> 'cover_alt', ''),
      nullif(p_article_payload ->> 'legacy_path', ''),
      nullif(p_article_payload ->> 'seo_title', ''),
      nullif(p_article_payload ->> 'seo_description', ''),
      article_keywords,
      nullif(p_article_payload ->> 'canonical_url', ''),
      nullif(p_article_payload ->> 'og_title', ''),
      nullif(p_article_payload ->> 'og_description', ''),
      coalesce((p_article_payload ->> 'allow_indexing')::boolean, true),
      coalesce(p_article_payload -> 'sources', '[]'::jsonb),
      coalesce(p_article_payload -> 'bibliography', '[]'::jsonb),
      coalesce((p_article_payload ->> 'featured')::boolean, false),
      coalesce((p_article_payload ->> 'show_on_homepage')::boolean, false),
      coalesce((p_article_payload ->> 'pinned')::boolean, false),
      actor_id,
      actor_id
    )
    returning * into saved_article;
  end if;

  if p_english_mode = 'save' then
    if has_english then
      update public.article_translations
      set
        title = p_english_payload ->> 'title',
        subtitle = coalesce(p_english_payload ->> 'subtitle', ''),
        excerpt = coalesce(p_english_payload ->> 'excerpt', ''),
        content_json = coalesce(
          p_english_payload -> 'content_json',
          '{"type":"doc","content":[]}'::jsonb
        ),
        content_html = coalesce(p_english_payload ->> 'content_html', ''),
        cover_alt = coalesce(p_english_payload ->> 'cover_alt', ''),
        slug = p_english_payload ->> 'slug',
        sources = coalesce(p_english_payload -> 'sources', '[]'::jsonb),
        bibliography = coalesce(
          p_english_payload -> 'bibliography',
          '[]'::jsonb
        ),
        seo_title = nullif(p_english_payload ->> 'seo_title', ''),
        seo_description = nullif(p_english_payload ->> 'seo_description', ''),
        seo_keywords = english_keywords,
        canonical_url = nullif(p_english_payload ->> 'canonical_url', ''),
        og_title = nullif(p_english_payload ->> 'og_title', ''),
        og_description = nullif(p_english_payload ->> 'og_description', ''),
        status = (p_english_payload ->> 'status')::public.article_translation_status,
        source_content_hash = nullif(
          p_english_payload ->> 'source_content_hash',
          ''
        ),
        source_article_updated_at = saved_article.updated_at,
        reviewed_by = case
          when nullif(p_english_payload ->> 'reviewed_at', '') is null
            then null
          else actor_id
        end,
        reviewed_at = nullif(p_english_payload ->> 'reviewed_at', '')::timestamptz,
        approved_by = case
          when nullif(p_english_payload ->> 'approved_at', '') is null
            then null
          else actor_id
        end,
        approved_at = nullif(p_english_payload ->> 'approved_at', '')::timestamptz,
        published_at = nullif(p_english_payload ->> 'published_at', '')::timestamptz,
        updated_by = actor_id,
        deleted_at = nullif(p_english_payload ->> 'deleted_at', '')::timestamptz
      where id = current_english.id
      returning * into saved_english;
    else
      insert into public.article_translations (
        article_id,
        locale,
        title,
        subtitle,
        excerpt,
        content_json,
        content_html,
        cover_alt,
        slug,
        sources,
        bibliography,
        seo_title,
        seo_description,
        seo_keywords,
        canonical_url,
        og_title,
        og_description,
        status,
        source_content_hash,
        source_article_updated_at,
        reviewed_by,
        reviewed_at,
        approved_by,
        approved_at,
        published_at,
        created_by,
        updated_by,
        deleted_at
      ) values (
        saved_article.id,
        'en',
        p_english_payload ->> 'title',
        coalesce(p_english_payload ->> 'subtitle', ''),
        coalesce(p_english_payload ->> 'excerpt', ''),
        coalesce(
          p_english_payload -> 'content_json',
          '{"type":"doc","content":[]}'::jsonb
        ),
        coalesce(p_english_payload ->> 'content_html', ''),
        coalesce(p_english_payload ->> 'cover_alt', ''),
        p_english_payload ->> 'slug',
        coalesce(p_english_payload -> 'sources', '[]'::jsonb),
        coalesce(p_english_payload -> 'bibliography', '[]'::jsonb),
        nullif(p_english_payload ->> 'seo_title', ''),
        nullif(p_english_payload ->> 'seo_description', ''),
        english_keywords,
        nullif(p_english_payload ->> 'canonical_url', ''),
        nullif(p_english_payload ->> 'og_title', ''),
        nullif(p_english_payload ->> 'og_description', ''),
        (p_english_payload ->> 'status')::public.article_translation_status,
        nullif(p_english_payload ->> 'source_content_hash', ''),
        saved_article.updated_at,
        case
          when nullif(p_english_payload ->> 'reviewed_at', '') is null
            then null
          else actor_id
        end,
        nullif(p_english_payload ->> 'reviewed_at', '')::timestamptz,
        case
          when nullif(p_english_payload ->> 'approved_at', '') is null
            then null
          else actor_id
        end,
        nullif(p_english_payload ->> 'approved_at', '')::timestamptz,
        nullif(p_english_payload ->> 'published_at', '')::timestamptz,
        actor_id,
        actor_id,
        nullif(p_english_payload ->> 'deleted_at', '')::timestamptz
      )
      returning * into saved_english;
    end if;
  elsif p_english_mode = 'stale' and has_english then
    update public.article_translations
    set
      status = 'stale',
      approved_by = null,
      approved_at = null,
      published_at = null,
      updated_by = actor_id
    where id = current_english.id
    returning * into saved_english;
  end if;

  if nullif(trim(coalesce(p_redirect_source_path, '')), '') is not null
    and nullif(trim(coalesce(p_redirect_destination_path, '')), '') is not null
    and p_redirect_source_path is distinct from p_redirect_destination_path then
    insert into public.redirects (
      source_path,
      destination_path,
      status_code,
      is_active,
      created_by
    ) values (
      p_redirect_source_path,
      p_redirect_destination_path,
      301,
      true,
      actor_id
    )
    on conflict (source_path) do update set
      destination_path = excluded.destination_path,
      status_code = 301,
      is_active = true,
      created_by = actor_id;
  end if;

  if p_replace_homepage
    and saved_article.status = 'published'
    and saved_article.show_on_homepage
    and saved_article.category_id is not null then
    update public.articles
    set
      show_on_homepage = false,
      updated_by = actor_id
    where category_id = saved_article.category_id
      and status = 'published'
      and show_on_homepage
      and id <> saved_article.id;
    get diagnostics replaced_count = row_count;
  end if;

  effective_audit_action := coalesce(
    nullif(trim(coalesce(p_audit_action, '')), ''),
    case when p_article_id is null then 'article.created' else 'article.updated' end
  );

  insert into public.admin_audit_log (
    actor_id,
    action,
    entity_type,
    entity_id,
    metadata
  ) values (
    actor_id,
    effective_audit_action,
    'article',
    saved_article.id::text,
    coalesce(p_audit_metadata, '{}'::jsonb)
  );

  if p_social_publish_requested then
    insert into public.admin_audit_log (
      actor_id,
      action,
      entity_type,
      entity_id,
      metadata
    ) values (
      actor_id,
      'social_publish.requested',
      'article',
      saved_article.id::text,
      coalesce(p_social_metadata, '{}'::jsonb)
    );
  end if;

  return query
  select
    saved_article.id,
    saved_article.updated_at,
    case
      when p_english_mode in ('save', 'stale') and saved_english.id is not null
        then saved_english.updated_at
      else null
    end,
    replaced_count;
end;
$$;

revoke all on function public.save_article_bundle(
  uuid,
  timestamptz,
  jsonb,
  text,
  jsonb,
  timestamptz,
  text,
  text,
  boolean,
  text,
  jsonb,
  boolean,
  jsonb
) from public;
grant execute on function public.save_article_bundle(
  uuid,
  timestamptz,
  jsonb,
  text,
  jsonb,
  timestamptz,
  text,
  text,
  boolean,
  text,
  jsonb,
  boolean,
  jsonb
) to authenticated;

-- Keep the staff-only schema health probe synchronized with this canonical RPC.
create or replace function public.get_editorial_schema_health()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when public.is_staff() then jsonb_build_object(
      'version', '20260822_zz_atomic_article_bundle',
      'checkedAt', now(),
      'outbox', to_regclass('public.public_build_outbox') is not null,
      'outboxRpc',
        to_regprocedure(
          'public.enqueue_public_build_request(text,text,text,jsonb)'
        ) is not null,
      'articleBundleRpc',
        to_regprocedure(
          'public.save_article_bundle(uuid,timestamptz,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
        ) is not null,
      'migrationLedger',
        to_regclass('public.probpera_schema_migrations') is not null,
      'publicationTriggers', (
        select count(*) = 21
        from pg_catalog.pg_trigger outbox_trigger
        join pg_catalog.pg_class relation
          on relation.oid = outbox_trigger.tgrelid
        join pg_catalog.pg_namespace namespace
          on namespace.oid = relation.relnamespace
        where namespace.nspname = 'public'
          and not outbox_trigger.tgisinternal
          and outbox_trigger.tgfoid =
            'public.capture_public_build_outbox()'::regprocedure
          and outbox_trigger.tgname =
            (relation.relname::text || '_public_build_outbox')::name
          and relation.relname = any(array[
            'articles',
            'article_tags',
            'article_translations',
            'pages',
            'homepage_blocks',
            'banners',
            'navigation_menus',
            'navigation_items',
            'redirects',
            'categories',
            'tags',
            'media_assets',
            'media_usages',
            'literary_works',
            'literary_work_translations',
            'literary_work_sources',
            'literary_work_external_ids',
            'book_editions',
            'writer_profile_overrides',
            'country_profile_overrides',
            'literary_work_cover_artworks'
          ]::name[])
      ),
      'staffEditorialReadPolicies', (
        select count(*) = 3
        from pg_catalog.pg_policies
        where schemaname = 'public'
          and cmd = 'SELECT'
          and roles = array['authenticated'::name]
          and position('is_staff' in coalesce(qual, '')) > 0
          and (
            (tablename = 'articles' and policyname = 'Staff read articles')
            or (
              tablename = 'article_translations'
              and policyname = 'Staff read article translations'
            )
            or (
              tablename = 'media_assets'
              and policyname = 'Staff read media metadata'
            )
          )
      ),
      'pendingPublicBuilds', (
        select count(*)
        from public.public_build_outbox
        where status in ('requested', 'dispatched', 'failed')
      ),
      'revisionHistory',
        to_regclass('public.admin_revision_history') is not null,
      'workTranslations',
        to_regclass('public.literary_work_translations') is not null,
      'workCoverArtworks',
        to_regclass('public.literary_work_cover_artworks') is not null,
      'countryOverrides',
        to_regclass('public.country_profile_overrides') is not null,
      'writerOverrides',
        to_regclass('public.writer_profile_overrides') is not null,
      'homepageMove',
        to_regprocedure('public.move_homepage_block(uuid,text)') is not null,
      'tagsUpdatedAt', exists (
        select 1
        from information_schema.columns
        where table_schema = 'public'
          and table_name = 'tags'
          and column_name = 'updated_at'
      )
    )
    else null
  end;
$$;

revoke all on function public.get_editorial_schema_health() from public;
grant execute on function public.get_editorial_schema_health()
  to authenticated;

-- Private working copies for editing an already published article without
-- mutating its public row until the normal atomic publication flow succeeds.

create table if not exists public.article_working_drafts (
  article_id uuid primary key
    references public.articles(id) on update cascade on delete cascade,
  base_article_updated_at timestamptz not null,
  payload jsonb not null,
  english_payload jsonb not null,
  expected_english_updated_at timestamptz,
  version bigint not null default 1,
  actor_id uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint article_working_drafts_payload_object_check
    check (jsonb_typeof(payload) = 'object'),
  constraint article_working_drafts_payload_size_check
    check (octet_length(payload::text) <= 5242880),
  constraint article_working_drafts_english_payload_check
    check (
      jsonb_typeof(english_payload) = 'object'
      and octet_length(english_payload::text) <= 5242880
      and (
        english_payload = '{"mode":"disabled"}'::jsonb
        or (
          english_payload ->> 'mode' = 'save'
          and jsonb_typeof(english_payload -> 'payload') = 'object'
        )
      )
    ),
  constraint article_working_drafts_version_check check (version > 0),
  constraint article_working_drafts_timestamp_order_check
    check (updated_at >= created_at)
);

create index if not exists article_working_drafts_updated_idx
  on public.article_working_drafts(updated_at desc, article_id);
create index if not exists article_working_drafts_actor_idx
  on public.article_working_drafts(actor_id, updated_at desc);

alter table public.article_working_drafts enable row level security;
alter table public.article_working_drafts force row level security;
revoke all on table public.article_working_drafts from public, anon, authenticated;
grant select on table public.article_working_drafts to authenticated;
grant all on table public.article_working_drafts to service_role;

-- Editors may prepare drafts and send them to review, but only owners/admins
-- may mutate the public/scheduled article rows.  Keep this boundary in RLS so
-- a handcrafted PostgREST/RPC request cannot bypass the server action check.
drop policy if exists "Staff create articles" on public.articles;
create policy "Staff create articles"
  on public.articles for insert to authenticated
  with check (
    public.is_staff()
    and created_by = (select auth.uid())
    and updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or status in ('draft', 'review')
    )
  );

drop policy if exists "Staff update articles" on public.articles;
create policy "Staff update articles"
  on public.articles for update to authenticated
  using (
    public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
    or (
      public.is_staff(array['editor'::public.staff_role])
      and status in ('draft', 'review')
    )
  )
  with check (
    updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review')
      )
    )
  );

-- Apply the same release boundary to article translations.  Editors may work
-- only inside an unpublished parent and may never manufacture an approved,
-- published or archived translation through direct PostgREST writes.
drop policy if exists "Staff create article translations"
  on public.article_translations;
create policy "Staff create article translations"
  on public.article_translations for insert to authenticated
  with check (
    created_by = (select auth.uid())
    and updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review')
        and approved_by is null
        and approved_at is null
        and published_at is null
        and deleted_at is null
        and exists (
          select 1
          from public.articles parent_article
          where parent_article.id = article_id
            and parent_article.status in ('draft', 'review')
            and parent_article.deleted_at is null
        )
      )
    )
  );

drop policy if exists "Staff update article translations"
  on public.article_translations;
create policy "Staff update article translations"
  on public.article_translations for update to authenticated
  using (
    public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
    or (
      public.is_staff(array['editor'::public.staff_role])
      and deleted_at is null
      and exists (
        select 1
        from public.articles parent_article
        where parent_article.id = article_id
          and parent_article.status in ('draft', 'review')
          and parent_article.deleted_at is null
      )
    )
  )
  with check (
    updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review', 'stale')
        and approved_by is null
        and approved_at is null
        and published_at is null
        and deleted_at is null
        and exists (
          select 1
          from public.articles parent_article
          where parent_article.id = article_id
            and parent_article.status in ('draft', 'review')
            and parent_article.deleted_at is null
        )
      )
    )
  );

drop policy if exists "Staff read article working drafts"
  on public.article_working_drafts;
create policy "Staff read article working drafts"
  on public.article_working_drafts
  for select to authenticated
  using (public.is_staff());

create or replace function public.save_article_working_draft(
  p_article_id uuid,
  p_base_article_updated_at timestamptz,
  p_payload jsonb,
  p_english_payload jsonb,
  p_expected_english_updated_at timestamptz,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_article public.articles%rowtype;
  current_english_updated_at timestamptz;
  current_draft public.article_working_drafts%rowtype;
  saved public.article_working_drafts%rowtype;
begin
  if actor is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'staff-required';
  end if;
  if p_article_id is null
    or p_base_article_updated_at is null
    or p_expected_version is null
    or p_expected_version < 0
    or jsonb_typeof(p_payload) is distinct from 'object'
    or octet_length(p_payload::text) > 5242880
    or (
      jsonb_typeof(p_english_payload) is distinct from 'object'
      or octet_length(p_english_payload::text) > 5242880
      or not (
        p_english_payload = '{"mode":"disabled"}'::jsonb
        or (
          p_english_payload ->> 'mode' = 'save'
          and jsonb_typeof(p_english_payload -> 'payload') = 'object'
        )
      )
    ) then
    raise exception using errcode = '22023', message = 'working-draft-invalid';
  end if;

  select * into current_article
  from public.articles
  where id = p_article_id
  for update;
  if not found or current_article.deleted_at is not null
    or current_article.status is distinct from 'published'::public.article_status then
    raise exception using errcode = 'P0001', message = 'published-article-required';
  end if;
  if current_article.updated_at is distinct from p_base_article_updated_at then
    raise exception using errcode = '40001', message = 'article-version-conflict';
  end if;

  select translation.updated_at into current_english_updated_at
  from public.article_translations translation
  where translation.article_id = p_article_id
    and translation.locale = 'en'
    and translation.deleted_at is null
  for update;
  if current_english_updated_at is distinct from p_expected_english_updated_at then
    raise exception using errcode = '40001', message = 'english-version-conflict';
  end if;

  select * into current_draft
  from public.article_working_drafts
  where article_id = p_article_id
  for update;
  if found then
    if current_draft.version is distinct from p_expected_version then
      raise exception using errcode = '40001', message = 'working-draft-version-conflict';
    end if;
    update public.article_working_drafts
    set base_article_updated_at = p_base_article_updated_at,
        payload = p_payload,
        english_payload = p_english_payload,
        expected_english_updated_at = p_expected_english_updated_at,
        version = current_draft.version + 1,
        actor_id = actor,
        updated_at = now()
    where article_id = p_article_id and version = p_expected_version
    returning * into saved;
  else
    if p_expected_version <> 0 then
      raise exception using errcode = '40001', message = 'working-draft-version-conflict';
    end if;
    insert into public.article_working_drafts (
      article_id, base_article_updated_at, payload, english_payload,
      expected_english_updated_at, version, actor_id
    ) values (
      p_article_id, p_base_article_updated_at, p_payload, p_english_payload,
      p_expected_english_updated_at, 1, actor
    ) returning * into saved;
  end if;

  if saved.article_id is null then
    raise exception using errcode = '40001', message = 'working-draft-version-conflict';
  end if;
  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor,
    'article.working_draft.saved',
    'article',
    saved.article_id::text,
    jsonb_build_object(
      'version', saved.version,
      'baseArticleUpdatedAt', saved.base_article_updated_at,
      'hasEnglish', saved.english_payload ->> 'mode' = 'save'
    )
  );
  return jsonb_build_object(
    'articleId', saved.article_id,
    'version', saved.version,
    'updatedAt', saved.updated_at
  );
end;
$$;

create or replace function public.discard_article_working_draft(
  p_article_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_version bigint;
begin
  if actor is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'staff-required';
  end if;
  if p_article_id is null or p_expected_version is null or p_expected_version < 1 then
    raise exception using errcode = '22023', message = 'working-draft-invalid';
  end if;
  select version into current_version
  from public.article_working_drafts
  where article_id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'working-draft-not-found';
  end if;
  if current_version is distinct from p_expected_version then
    raise exception using errcode = '40001', message = 'working-draft-version-conflict';
  end if;
  delete from public.article_working_drafts
  where article_id = p_article_id and version = p_expected_version;
  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor,
    'article.working_draft.discarded',
    'article',
    p_article_id::text,
    jsonb_build_object('version', p_expected_version)
  );
  return jsonb_build_object('articleId', p_article_id, 'discarded', true);
end;
$$;

create or replace function public.clear_article_working_draft_after_promotion()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  delete from public.article_working_drafts where article_id = new.id;
  return new;
end;
$$;

-- An existing privileged release must not erase a newer working copy.  The
-- guard makes the legacy bundle RPC fail closed whenever a working draft is
-- present; only the promotion RPC below installs the transaction-local CAS
-- evidence after locking article -> draft in the canonical order.
create or replace function public.guard_article_working_draft_promotion()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_draft_version bigint;
  expected_promotion text;
begin
  if new.status not in ('published', 'scheduled', 'hidden', 'archived') then
    return new;
  end if;

  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = new.id
  for update;
  if not found then
    return new;
  end if;

  expected_promotion := nullif(
    current_setting('probpera.expected_working_draft_promotion', true),
    ''
  );
  if expected_promotion is distinct from
    (new.id::text || ':' || current_draft_version::text) then
    raise exception using
      errcode = '40001',
      message = 'WORKING_DRAFT_CONFLICT';
  end if;
  return new;
end;
$$;

create or replace function public.promote_article_working_draft(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz,
  p_expected_working_draft_version bigint,
  p_article_payload jsonb,
  p_english_mode text,
  p_english_payload jsonb,
  p_expected_english_updated_at timestamptz,
  p_redirect_source_path text,
  p_redirect_destination_path text,
  p_replace_homepage boolean,
  p_audit_action text,
  p_audit_metadata jsonb,
  p_social_publish_requested boolean,
  p_social_metadata jsonb
)
returns table (
  article_id uuid,
  article_updated_at timestamptz,
  english_updated_at timestamptz,
  homepage_replaced integer
)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  current_article_updated_at timestamptz;
  current_draft_version bigint;
  has_working_draft boolean := false;
  target_status text := p_article_payload ->> 'status';
begin
  if (select auth.uid()) is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  if p_article_id is null
    or p_expected_article_updated_at is null
    or p_expected_working_draft_version is null
    or p_expected_working_draft_version < 0 then
    raise exception using errcode = '22023', message = 'PROMOTION_INPUT_INVALID';
  end if;
  if target_status is null
    or target_status not in ('published', 'scheduled', 'hidden', 'archived') then
    raise exception using errcode = '22023', message = 'PROMOTION_STATUS_REQUIRED';
  end if;

  select article.updated_at
  into current_article_updated_at
  from public.articles article
  where article.id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
  end if;
  if current_article_updated_at is distinct from p_expected_article_updated_at then
    raise exception using errcode = '40001', message = 'ARTICLE_CONFLICT';
  end if;

  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  has_working_draft := found;
  if (
    p_expected_working_draft_version = 0
    and has_working_draft
  ) or (
    p_expected_working_draft_version > 0
    and (
      not has_working_draft
      or current_draft_version is distinct from p_expected_working_draft_version
    )
  ) then
    raise exception using errcode = '40001', message = 'WORKING_DRAFT_CONFLICT';
  end if;

  perform set_config(
    'probpera.expected_working_draft_promotion',
    p_article_id::text || ':' || p_expected_working_draft_version::text,
    true
  );

  return query
  select bundle.article_id,
         bundle.article_updated_at,
         bundle.english_updated_at,
         bundle.homepage_replaced
  from public.save_article_bundle(
    p_article_id,
    p_expected_article_updated_at,
    p_article_payload,
    p_english_mode,
    p_english_payload,
    p_expected_english_updated_at,
    p_redirect_source_path,
    p_redirect_destination_path,
    p_replace_homepage,
    p_audit_action,
    p_audit_metadata,
    p_social_publish_requested,
    p_social_metadata
  ) bundle;
end;
$$;

drop trigger if exists articles_guard_working_draft_promotion
  on public.articles;
create trigger articles_guard_working_draft_promotion
before update on public.articles
for each row
when (new.status in ('published', 'scheduled', 'hidden', 'archived'))
execute function public.guard_article_working_draft_promotion();

drop trigger if exists articles_clear_working_draft_after_promotion
  on public.articles;
create trigger articles_clear_working_draft_after_promotion
after update on public.articles
for each row
when (new.status in ('published', 'scheduled', 'hidden', 'archived'))
execute function public.clear_article_working_draft_after_promotion();

revoke all on function public.save_article_working_draft(
  uuid, timestamptz, jsonb, jsonb, timestamptz, bigint
) from public, anon, authenticated, service_role;
revoke all on function public.discard_article_working_draft(uuid, bigint)
  from public, anon, authenticated, service_role;
revoke all on function public.clear_article_working_draft_after_promotion()
  from public, anon, authenticated, service_role;
revoke all on function public.guard_article_working_draft_promotion()
  from public, anon, authenticated, service_role;
revoke all on function public.promote_article_working_draft(
  uuid, timestamptz, bigint, jsonb, text, jsonb, timestamptz, text, text,
  boolean, text, jsonb, boolean, jsonb
) from public, anon, authenticated, service_role;
grant execute on function public.save_article_working_draft(
  uuid, timestamptz, jsonb, jsonb, timestamptz, bigint
) to authenticated;
grant execute on function public.discard_article_working_draft(uuid, bigint)
  to authenticated;
grant execute on function public.promote_article_working_draft(
  uuid, timestamptz, bigint, jsonb, text, jsonb, timestamptz, text, text,
  boolean, text, jsonb, boolean, jsonb
) to authenticated;

create or replace function public.assert_redirect_candidate(
  p_id uuid,
  p_source_path text,
  p_destination_path text,
  p_is_active boolean
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  normalized_source text := regexp_replace(p_source_path, '/+$', '');
  normalized_destination text := case
    when p_destination_path like '/%' then regexp_replace(p_destination_path, '/+$', '')
    else p_destination_path
  end;
begin
  normalized_source := case when normalized_source = '' then '/' else normalized_source end;
  normalized_destination := case when normalized_destination = '' then '/' else normalized_destination end;
  if char_length(normalized_source) > 500
    or char_length(normalized_destination) > 500
    or normalized_source !~ '^/(?:$|[^/\\])'
    or normalized_source ~ '[[:cntrl:]\\]'
    or not (
      normalized_destination ~ '^/(?:$|[^/\\])'
      or normalized_destination ~ '^https://[^/[:space:]]+(?:/.*)?$'
    )
    or normalized_destination ~ '[[:cntrl:]\\]' then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_PATH';
  end if;
  if normalized_source = normalized_destination then
    raise exception using errcode = 'P0001', message = 'REDIRECT_SELF_REFERENCE';
  end if;

  if p_is_active and exists (
    select 1 from public.redirects r
    where r.id is distinct from p_id and r.is_active
      and (
        r.source_path = normalized_source
        or (normalized_destination like '/%' and r.source_path = normalized_destination)
        or r.destination_path = normalized_source
      )
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_COLLISION_OR_CHAIN';
  end if;

  if p_is_active and exists (
    select 1 from public.pages p
    where p.deleted_at is null and p.status = 'published'
      and (
        '/stranitsy/' || p.slug = normalized_source
        or regexp_replace(
          regexp_replace(coalesce(p.canonical_url, ''), '^https://[^/]+', ''),
          '/+$', ''
        ) = normalized_source
      )
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_LIVE_ROUTE_COLLISION';
  end if;

  if p_is_active and exists (
    select 1 from public.articles a
    where a.deleted_at is null and a.status = 'published'
      and regexp_replace(
        regexp_replace(coalesce(a.canonical_url, ''), '^https://[^/]+', ''),
        '/+$', ''
      ) = normalized_source
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_LIVE_ROUTE_COLLISION';
  end if;
end;
$$;
create or replace function public.create_seo_redirect_guarded(
  p_source_path text,
  p_destination_path text,
  p_status_code smallint,
  p_is_active boolean
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  redirect_id uuid;
begin
  perform pg_advisory_xact_lock(188654771, 3);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  if p_status_code not in (301, 302, 307, 308) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_STATUS';
  end if;
  perform public.assert_redirect_candidate(null, p_source_path, p_destination_path, p_is_active);
  insert into public.redirects (
    source_path, destination_path, status_code, is_active, created_by
  ) values (
    coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/'),
    case when p_destination_path like '/%' then coalesce(nullif(regexp_replace(p_destination_path, '/+$', ''), ''), '/') else p_destination_path end,
    p_status_code, p_is_active, actor_user_id
  ) returning id into redirect_id;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id, metadata)
  values (actor_user_id, 'redirect.created', 'redirect', redirect_id::text,
    jsonb_build_object('sourcePath', p_source_path, 'destinationPath', p_destination_path,
      'statusCode', p_status_code, 'isActive', p_is_active));
  return redirect_id;
exception when unique_violation then
  raise exception using errcode = 'P0001', message = 'REDIRECT_SOURCE_EXISTS';
end;
$$;
create or replace function public.update_seo_redirect_guarded(
  p_id uuid,
  p_expected_updated_at timestamptz,
  p_source_path text,
  p_destination_path text,
  p_status_code smallint,
  p_is_active boolean
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  current_updated_at timestamptz;
begin
  perform pg_advisory_xact_lock(188654771, 3);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  select updated_at into current_updated_at from public.redirects where id = p_id for update;
  if current_updated_at is null or current_updated_at <> p_expected_updated_at then
    raise exception using errcode = 'P0001', message = 'REDIRECT_WRITE_CONFLICT';
  end if;
  if p_status_code not in (301, 302, 307, 308) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_STATUS';
  end if;
  perform public.assert_redirect_candidate(p_id, p_source_path, p_destination_path, p_is_active);
  update public.redirects set
    source_path = coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/'),
    destination_path = case when p_destination_path like '/%' then coalesce(nullif(regexp_replace(p_destination_path, '/+$', ''), ''), '/') else p_destination_path end,
    status_code = p_status_code,
    is_active = p_is_active
  where id = p_id;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id, metadata)
  values (actor_user_id, 'redirect.updated', 'redirect', p_id::text,
    jsonb_build_object('sourcePath', p_source_path, 'destinationPath', p_destination_path,
      'statusCode', p_status_code, 'isActive', p_is_active));
  return p_id;
exception when unique_violation then
  raise exception using errcode = 'P0001', message = 'REDIRECT_SOURCE_EXISTS';
end;
$$;
revoke all on function public.assert_redirect_candidate(uuid, text, text, boolean) from public, anon, authenticated;
revoke all on function public.create_seo_redirect_guarded(text, text, smallint, boolean) from public, anon, authenticated;
revoke all on function public.update_seo_redirect_guarded(uuid, timestamptz, text, text, smallint, boolean) from public, anon, authenticated;
grant execute on function public.create_seo_redirect_guarded(text, text, smallint, boolean) to authenticated;
grant execute on function public.update_seo_redirect_guarded(uuid, timestamptz, text, text, smallint, boolean) to authenticated;
revoke insert, update, delete on public.redirects from authenticated;
-- Keep public save/promotion SECURITY INVOKER and both protected tables read-only
-- to authenticated clients. Only the existing guarded operations may write.

create or replace function public.lock_article_working_draft_for_publication(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_article_updated_at timestamptz;
  current_draft_version bigint;
begin
  if (select auth.uid()) is null
    or not public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role]) then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  if p_article_id is null or p_expected_article_updated_at is null then
    raise exception using errcode = '22023', message = 'PROMOTION_INPUT_INVALID';
  end if;

  -- Match the save/promotion lock order even when this helper is called directly.
  select article.updated_at into current_article_updated_at
  from public.articles article
  where article.id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
  end if;
  if current_article_updated_at is distinct from p_expected_article_updated_at then
    raise exception using errcode = '40001', message = 'ARTICLE_CONFLICT';
  end if;

  select draft.version into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  return current_draft_version;
end;
$$;

revoke all on function public.lock_article_working_draft_for_publication(uuid, timestamptz)
  from public, anon, authenticated, service_role;
grant execute on function public.lock_article_working_draft_for_publication(uuid, timestamptz)
  to authenticated;

create or replace function public.upsert_article_redirect_guarded(
  p_source_path text,
  p_destination_path text
)
returns uuid
language plpgsql
security invoker
set search_path = ''
as $$
declare
  existing_redirect_id uuid;
  existing_updated_at timestamptz;
  normalized_source text := coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/');
begin
  if (select auth.uid()) is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  -- Share the SEO RPC lock before reading its CAS token. Never use a direct
  -- INSERT/UPDATE or SELECT FOR UPDATE on the read-only redirects table.
  perform pg_advisory_xact_lock(188654771, 3);
  select redirect.id, redirect.updated_at
  into existing_redirect_id, existing_updated_at
  from public.redirects redirect
  where redirect.source_path = normalized_source;
  if found then
    return public.update_seo_redirect_guarded(
      existing_redirect_id, existing_updated_at,
      p_source_path, p_destination_path, 301::smallint, true
    );
  end if;
  return public.create_seo_redirect_guarded(
    p_source_path, p_destination_path, 301::smallint, true
  );
end;
$$;

revoke all on function public.upsert_article_redirect_guarded(text, text)
  from public, anon, authenticated, service_role;
grant execute on function public.upsert_article_redirect_guarded(text, text)
  to authenticated;

-- Replace only the two reviewed statements. Fail closed on an unexpected
-- predecessor; retain every original role, payload, CAS, RLS and atomicity gate.
do $publication_permissions$
declare
  promotion_oid regprocedure := to_regprocedure(
    'public.promote_article_working_draft(uuid,timestamptz,bigint,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
  );
  bundle_oid regprocedure := to_regprocedure(
    'public.save_article_bundle(uuid,timestamptz,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
  );
  definition text;
  old_lock text := $old_lock$  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  has_working_draft := found;$old_lock$;
  new_lock text := $new_lock$  current_draft_version := public.lock_article_working_draft_for_publication(
    p_article_id, p_expected_article_updated_at
  );
  has_working_draft := current_draft_version is not null;$new_lock$;
  old_redirect text := $old_redirect$    insert into public.redirects (
      source_path,
      destination_path,
      status_code,
      is_active,
      created_by
    ) values (
      p_redirect_source_path,
      p_redirect_destination_path,
      301,
      true,
      actor_id
    )
    on conflict (source_path) do update set
      destination_path = excluded.destination_path,
      status_code = 301,
      is_active = true,
      created_by = actor_id;$old_redirect$;
  new_redirect text := $new_redirect$    perform public.upsert_article_redirect_guarded(
      p_redirect_source_path, p_redirect_destination_path
    );$new_redirect$;
begin
  if promotion_oid is null or bundle_oid is null
    or exists (select 1 from pg_proc where oid in (promotion_oid, bundle_oid) and prosecdef) then
    raise exception 'Expected SECURITY INVOKER article publication functions are missing';
  end if;

  definition := pg_get_functiondef(promotion_oid);
  if strpos(definition, old_lock) > 0 and strpos(definition, new_lock) = 0
    and (length(definition) - length(replace(definition, old_lock, ''))) = length(old_lock) then
    execute replace(definition, old_lock, new_lock);
  elsif strpos(definition, old_lock) > 0 or strpos(definition, new_lock) = 0 then
    raise exception 'Unexpected article promotion lock predecessor';
  end if;

  definition := pg_get_functiondef(bundle_oid);
  if strpos(definition, old_redirect) > 0 and strpos(definition, new_redirect) = 0
    and (length(definition) - length(replace(definition, old_redirect, ''))) = length(old_redirect) then
    execute replace(definition, old_redirect, new_redirect);
  elsif strpos(definition, old_redirect) > 0 or strpos(definition, new_redirect) = 0 then
    raise exception 'Unexpected article redirect write predecessor';
  end if;

  if exists (
    select 1 from pg_proc where oid in (promotion_oid, bundle_oid) and prosecdef
  ) or not (
    select prosecdef from pg_proc
    where oid = 'public.lock_article_working_draft_for_publication(uuid,timestamptz)'::regprocedure
  ) or (
    select prosecdef from pg_proc
    where oid = 'public.upsert_article_redirect_guarded(text,text)'::regprocedure
  ) then
    raise exception 'Article publication privilege boundaries changed';
  end if;
  if has_table_privilege('authenticated', 'public.article_working_drafts', 'INSERT,UPDATE,DELETE')
    or has_any_column_privilege('authenticated', 'public.article_working_drafts', 'UPDATE')
    or has_table_privilege('authenticated', 'public.redirects', 'INSERT,UPDATE,DELETE')
    or has_any_column_privilege('authenticated', 'public.redirects', 'UPDATE') then
    raise exception 'Protected article tables must remain read-only to authenticated clients';
  end if;
  if not has_function_privilege('authenticated',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or not has_function_privilege('authenticated',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE')
    or has_function_privilege('anon',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or has_function_privilege('service_role',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or has_function_privilege('anon',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE')
    or has_function_privilege('service_role',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE') then
    raise exception 'Article publication helper ACLs are invalid';
  end if;
end;
$publication_permissions$;


create table if not exists public.media_assets (
  id uuid primary key default gen_random_uuid(),
  bucket text not null default 'editorial-media',
  object_path text not null unique,
  original_name text not null,
  mime_type text not null,
  byte_size bigint not null check (byte_size > 0 and byte_size <= 26214400),
  width integer check (width is null or width > 0),
  height integer check (height is null or height > 0),
  alt_text text not null default '' check (char_length(alt_text) <= 500),
  caption text not null default '' check (char_length(caption) <= 1000),
  creator text not null default '',
  source_url text,
  license_name text not null default '',
  license_url text,
  focus_x numeric(5,4) not null default 0.5 check (focus_x between 0 and 1),
  focus_y numeric(5,4) not null default 0.5 check (focus_y between 0 and 1),
  collection_name text not null default 'Общее',
  uploaded_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.homepage_blocks (
  id uuid primary key default gen_random_uuid(),
  block_type text not null check (
    block_type in (
      'hero',
      'article-grid',
      'carousel',
      'editors-choice',
      'popular',
      'latest',
      'categories',
      'book-vs-screen',
      'literary-map',
      'awards',
      'subscription',
      'text'
    )
  ),
  title text not null default '',
  settings jsonb not null default '{}'::jsonb,
  display_order integer not null default 0,
  is_enabled boolean not null default true,
  background_style text not null default 'light' check (
    background_style in ('light', 'violet', 'orange', 'paper', 'transparent')
  ),
  background_media_id uuid references public.media_assets(id) on delete set null,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.fixture_homepage_set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
create trigger homepage_blocks_set_updated_at before update on public.homepage_blocks for each row execute function public.fixture_homepage_set_updated_at();
alter table public.homepage_blocks enable row level security;
create policy "Public read enabled homepage blocks"
on public.homepage_blocks for select
to anon, authenticated
using (is_enabled);

create policy "Staff manage homepage blocks"
on public.homepage_blocks for all
to authenticated
using (public.is_staff())
with check (public.is_staff() and updated_by = (select auth.uid()));


grant select on public.homepage_blocks to anon,authenticated; grant insert,update,delete on public.homepage_blocks to authenticated;
create or replace function public.save_site_copy_block(
  p_expected_updated_at timestamptz,
  p_payload jsonb,
  p_audit_metadata jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  block_id uuid;
  current_updated_at timestamptz;
begin
  perform pg_advisory_xact_lock(188654771, 2);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  if jsonb_typeof(p_payload) <> 'object'
    or p_payload #>> '{settings,systemKey}' <> 'site-copy-overrides'
    or p_payload ->> 'block_type' <> 'text' then
    raise exception using errcode = 'P0001', message = 'SITE_COPY_INVALID_PAYLOAD';
  end if;

  select id, updated_at into block_id, current_updated_at
  from public.homepage_blocks
  where settings @> '{"systemKey":"site-copy-overrides"}'::jsonb
  order by updated_at desc
  limit 1
  for update;

  if block_id is not null then
    if p_expected_updated_at is null
      or current_updated_at <> p_expected_updated_at then
      raise exception using errcode = 'P0001', message = 'SITE_COPY_WRITE_CONFLICT';
    end if;
    update public.homepage_blocks
    set block_type = p_payload ->> 'block_type',
        title = p_payload ->> 'title',
        settings = p_payload -> 'settings',
        display_order = (p_payload ->> 'display_order')::integer,
        is_enabled = (p_payload ->> 'is_enabled')::boolean,
        background_style = p_payload ->> 'background_style',
        background_media_id = nullif(p_payload ->> 'background_media_id', '')::uuid,
        updated_by = actor_user_id
    where id = block_id;
  else
    if p_expected_updated_at is not null then
      raise exception using errcode = 'P0001', message = 'SITE_COPY_WRITE_CONFLICT';
    end if;
    insert into public.homepage_blocks (
      block_type, title, settings, display_order, is_enabled,
      background_style, background_media_id, updated_by
    ) values (
      p_payload ->> 'block_type',
      p_payload ->> 'title',
      p_payload -> 'settings',
      (p_payload ->> 'display_order')::integer,
      (p_payload ->> 'is_enabled')::boolean,
      p_payload ->> 'background_style',
      nullif(p_payload ->> 'background_media_id', '')::uuid,
      actor_user_id
    ) returning id into block_id;
  end if;

  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor_user_id,
    case when coalesce((p_audit_metadata ->> 'inline_editor')::boolean, false)
      then 'site_copy.inline_updated' else 'site_copy.updated' end,
    'site_copy', block_id::text,
    coalesce(p_audit_metadata, '{}'::jsonb) || jsonb_build_object('storage', 'homepage_blocks')
  );
  return block_id;
exception
  when invalid_text_representation or numeric_value_out_of_range or not_null_violation
    or check_violation then
    raise exception using errcode = 'P0001', message = 'SITE_COPY_INVALID_PAYLOAD';
end;
$$;

-- Keep ordinary homepage blocks editable through their existing staff flows,
-- but make the singleton Site Copy row writable only by the security-definer
-- RPC above. Restrictive policies compose with the existing permissive staff
-- policy and protect both the old and proposed row on UPDATE.
drop policy if exists "Site Copy insert requires guarded RPC"
  on public.homepage_blocks;
create policy "Site Copy insert requires guarded RPC"
on public.homepage_blocks as restrictive for insert to authenticated
with check (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
);

drop policy if exists "Site Copy update requires guarded RPC"
  on public.homepage_blocks;
create policy "Site Copy update requires guarded RPC"
on public.homepage_blocks as restrictive for update to authenticated
using (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
)
with check (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
);

drop policy if exists "Site Copy delete requires guarded RPC"
  on public.homepage_blocks;
create policy "Site Copy delete requires guarded RPC"
on public.homepage_blocks as restrictive for delete to authenticated
using (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
);


revoke all on function public.save_site_copy_block(timestamptz, jsonb, jsonb) from public, anon, authenticated;
grant execute on function public.save_site_copy_block(timestamptz, jsonb, jsonb) to authenticated;
-- Нормализованный редакционный контур книжного архива.
-- Главным источником энциклопедических данных остаётся src/data/countries.
-- Эти таблицы дают CMS безопасный рабочий слой для проверки произведений,
-- конкретных изданий и ISBN без дублирования одной обложки на уровне произведения.

create table if not exists public.literary_works (
  id uuid primary key default gen_random_uuid(),
  legacy_id text not null unique check (char_length(legacy_id) between 2 and 180),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  title text not null check (char_length(title) between 1 and 300),
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{0,179}$'),
  original_title text not null default '' check (char_length(original_title) <= 300),
  first_published integer check (first_published between -3000 and 2100),
  original_language text not null default '' check (char_length(original_language) <= 120),
  genres text[] not null default '{}',
  tags text[] not null default '{}',
  description text not null default '' check (char_length(description) <= 5000),
  source_url text,
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (writer_id, slug)
);

create table if not exists public.book_editions (
  id uuid primary key default gen_random_uuid(),
  legacy_id text not null unique check (char_length(legacy_id) between 2 and 240),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  title text not null default '' check (char_length(title) <= 300),
  isbn_10 text check (
    isbn_10 is null
    or regexp_replace(isbn_10, '[^0-9Xx]', '', 'g') ~ '^[0-9]{9}[0-9Xx]$'
  ),
  isbn_13 text check (
    isbn_13 is null
    or regexp_replace(isbn_13, '[^0-9]', '', 'g') ~ '^[0-9]{13}$'
  ),
  publisher text not null default '' check (char_length(publisher) <= 240),
  publication_year integer check (publication_year between 1400 and 2100),
  language text not null default '' check (char_length(language) <= 120),
  format text not null default '' check (char_length(format) <= 120),
  page_count integer check (page_count is null or page_count > 0),
  cover_url text,
  cover_source_url text,
  cover_rights_status text not null default 'unverified'
    check (
      cover_rights_status in (
        'public-domain',
        'licensed',
        'permission',
        'editorial-original',
        'external-preview',
        'unverified'
      )
    ),
  license_name text not null default '' check (char_length(license_name) <= 240),
  license_url text,
  creator text not null default '' check (char_length(creator) <= 240),
  rights_holder text not null default '' check (char_length(rights_holder) <= 240),
  rights_checked_at date,
  source_url text,
  is_primary boolean not null default false,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (
    cover_url is null
    or (
      cover_source_url is not null
      and cover_rights_status <> 'unverified'
      and rights_checked_at is not null
    )
  )
);

create unique index if not exists literary_works_country_legacy_idx
  on public.literary_works(country_id, legacy_id);

create index if not exists literary_works_writer_idx
  on public.literary_works(country_id, writer_id, editorial_status);

create index if not exists literary_works_search_idx
  on public.literary_works
  using gin (
    to_tsvector(
      'simple',
      coalesce(title, '') || ' ' || coalesce(original_title, '') || ' ' ||
      coalesce(description, '')
    )
  );

create unique index if not exists book_editions_isbn_10_unique_idx
  on public.book_editions (
    regexp_replace(upper(isbn_10), '[^0-9X]', '', 'g')
  )
  where isbn_10 is not null;

create unique index if not exists book_editions_isbn_13_unique_idx
  on public.book_editions (
    regexp_replace(isbn_13, '[^0-9]', '', 'g')
  )
  where isbn_13 is not null;

create unique index if not exists book_editions_one_primary_idx
  on public.book_editions(work_id)
  where is_primary;

create index if not exists book_editions_work_idx
  on public.book_editions(work_id, publication_year desc);

drop trigger if exists literary_works_set_updated_at on public.literary_works;
create trigger literary_works_set_updated_at
  before update on public.literary_works
  for each row execute function public.set_updated_at();

drop trigger if exists book_editions_set_updated_at on public.book_editions;
create trigger book_editions_set_updated_at
  before update on public.book_editions
  for each row execute function public.set_updated_at();

alter table public.literary_works enable row level security;
alter table public.book_editions enable row level security;

create policy "Public read reviewed literary works"
on public.literary_works for select
to anon, authenticated
using (editorial_status in ('reviewed', 'verified'));

create policy "Staff manage literary works"
on public.literary_works for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Public read verified book editions"
on public.book_editions for select
to anon, authenticated
using (
  (
    cover_url is null
    or (
      cover_rights_status <> 'unverified'
      and cover_source_url is not null
      and rights_checked_at is not null
    )
  )
  and exists (
    select 1
    from public.literary_works
    where literary_works.id = book_editions.work_id
      and literary_works.editorial_status in ('reviewed', 'verified')
  )
);

create policy "Staff manage book editions"
on public.book_editions for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

-- Bilingual, source-aware publication workflow for literary works.
-- Discovery imports land in book_import_candidates. Only reviewed works with
-- complete RU/EN editorial text and provenance are visible through public RLS.

create table if not exists public.literary_work_translations (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  locale text not null check (locale in ('ru', 'en')),
  title text not null check (char_length(title) between 1 and 300),
  description text not null check (char_length(description) between 140 and 900),
  source_language text not null check (char_length(source_language) between 2 and 40),
  translation_method text not null
    check (
      translation_method in (
        'editorial-original',
        'human-translation',
        'licensed-source'
      )
    ),
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  source_urls text[] not null default '{}',
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, locale),
  check (
    editorial_status = 'draft'
    or (
      reviewed_at is not null
      and cardinality(source_urls) > 0
    )
  )
);

create table if not exists public.literary_work_sources (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  provider text not null check (char_length(provider) between 2 and 160),
  source_url text not null check (source_url ~ '^https://'),
  field_names text[] not null check (cardinality(field_names) > 0),
  license_name text,
  usage text not null
    check (usage in ('structured-data', 'reference-only', 'licensed-copy')),
  retrieved_at date not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, provider, source_url)
);

create table if not exists public.literary_work_external_ids (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  scheme text not null check (scheme ~ '^[a-z0-9][a-z0-9_-]{1,39}$'),
  external_id text not null check (char_length(external_id) between 1 and 180),
  source_url text not null check (source_url ~ '^https://'),
  created_at timestamptz not null default now(),
  unique (scheme, external_id),
  unique (work_id, scheme, external_id)
);

create table if not exists public.book_import_candidates (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider ~ '^[a-z0-9][a-z0-9_-]{1,39}$'),
  external_id text not null check (char_length(external_id) between 1 and 180),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  writer_key text not null check (char_length(writer_key) between 3 and 320),
  title text not null check (char_length(title) between 1 and 300),
  source_url text not null check (source_url ~ '^https://'),
  quality_score integer not null default 0 check (quality_score between 0 and 100),
  status text not null default 'candidate'
    check (status in ('candidate', 'rejected', 'reviewed', 'promoted')),
  rejection_reasons text[] not null default '{}',
  payload jsonb not null default '{}'::jsonb,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  promoted_work_id uuid references public.literary_works(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, external_id),
  check (
    status not in ('reviewed', 'promoted')
    or (reviewed_by is not null and reviewed_at is not null)
  ),
  check (status <> 'promoted' or promoted_work_id is not null)
);

create index if not exists literary_work_translations_public_idx
  on public.literary_work_translations(work_id, locale, editorial_status);
create index if not exists literary_work_sources_work_idx
  on public.literary_work_sources(work_id);
create index if not exists literary_work_external_ids_work_idx
  on public.literary_work_external_ids(work_id);
create index if not exists book_import_candidates_queue_idx
  on public.book_import_candidates(status, quality_score desc, created_at);
create index if not exists book_import_candidates_writer_idx
  on public.book_import_candidates(writer_key, status);

drop trigger if exists literary_work_translations_set_updated_at
  on public.literary_work_translations;
create trigger literary_work_translations_set_updated_at
  before update on public.literary_work_translations
  for each row execute function public.set_updated_at();

drop trigger if exists literary_work_sources_set_updated_at
  on public.literary_work_sources;
create trigger literary_work_sources_set_updated_at
  before update on public.literary_work_sources
  for each row execute function public.set_updated_at();

drop trigger if exists book_import_candidates_set_updated_at
  on public.book_import_candidates;
create trigger book_import_candidates_set_updated_at
  before update on public.book_import_candidates
  for each row execute function public.set_updated_at();

alter table public.literary_work_translations enable row level security;
alter table public.literary_work_sources enable row level security;
alter table public.literary_work_external_ids enable row level security;
alter table public.book_import_candidates enable row level security;

create or replace function public.is_publishable_literary_work(target_work_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1
    from public.literary_works as work
    where work.id = target_work_id
      and work.editorial_status in ('reviewed', 'verified')
      and exists (
        select 1
        from public.literary_work_sources as source
        where source.work_id = work.id
      )
      and not exists (
        select 1
        from public.literary_work_sources as source
        where source.work_id = work.id
          and (
            btrim(source.provider) = ''
            or source.source_url !~* '^https://'
            or cardinality(source.field_names) = 0
            or source.retrieved_at is null
          )
      )
      and 2 = (
        select count(distinct translation.locale)
        from public.literary_work_translations as translation
        where translation.work_id = work.id
          and translation.locale in ('ru', 'en')
          and translation.editorial_status in ('reviewed', 'verified')
          and translation.reviewed_at is not null
          and btrim(translation.title) <> ''
          and btrim(translation.source_language) <> ''
          and char_length(btrim(translation.description)) between 140 and 900
          and (
            select count(*)
            from regexp_matches(
              btrim(translation.description),
              '[.!?…]+([[:space:]]|$)',
              'g'
            )
          ) between 2 and 3
          and case
            when translation.locale = 'ru'
              then translation.description ~ '[А-Яа-яЁё]'
            when translation.locale = 'en'
              then translation.description ~ '[A-Za-z]'
                -- PostgreSQL ARE has no portable Unicode Script=Cyrillic class.
                -- Check every code point across the current Cyrillic blocks.
                and not exists (
                  select 1
                  from unnest(
                    string_to_array(
                      translation.title || translation.description,
                      null::text
                    )
                  ) as glyph(value)
                  where ascii(glyph.value) between 1024 and 1327
                    or ascii(glyph.value) between 7296 and 7311
                    or ascii(glyph.value) between 11744 and 11775
                    or ascii(glyph.value) between 42560 and 42655
                    or ascii(glyph.value) between 65070 and 65071
                    or ascii(glyph.value) between 122928 and 123023
                )
            else false
          end
          and position('Р°' in translation.description) = 0
          and position('Рµ' in translation.description) = 0
          and position('Рё' in translation.description) = 0
          and position('СЃ' in translation.description) = 0
          and position('С‚' in translation.description) = 0
          and position('вЂ' in translation.description) = 0
          and cardinality(translation.source_urls) > 0
          and not exists (
            select 1
            from unnest(translation.source_urls) as declared(source_url)
            where declared.source_url is null
              or btrim(declared.source_url) !~* '^https://'
              or not exists (
                select 1
                from public.literary_work_sources as source
                where source.work_id = translation.work_id
                  and source.source_url = btrim(declared.source_url)
              )
          )
          and (
            translation.translation_method <> 'licensed-source'
            or exists (
              select 1
              from unnest(translation.source_urls) as declared(source_url)
              join public.literary_work_sources as source
                on source.work_id = translation.work_id
               and source.source_url = btrim(declared.source_url)
              where source.usage = 'licensed-copy'
                and btrim(coalesce(source.license_name, '')) <> ''
            )
          )
      )
  );
$$;

revoke all on function public.is_publishable_literary_work(uuid) from public;
grant execute on function public.is_publishable_literary_work(uuid)
  to anon, authenticated;

drop policy if exists "Public read reviewed literary works"
  on public.literary_works;
drop policy if exists "Public read publishable literary works"
  on public.literary_works;
create policy "Public read publishable literary works"
on public.literary_works for select
to anon, authenticated
using (public.is_publishable_literary_work(id));

drop policy if exists "Public read publishable work translations"
  on public.literary_work_translations;
create policy "Public read publishable work translations"
on public.literary_work_translations for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work translations"
  on public.literary_work_translations;
create policy "Staff manage work translations"
on public.literary_work_translations for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Public read publishable work sources"
  on public.literary_work_sources;
create policy "Public read publishable work sources"
on public.literary_work_sources for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work sources"
  on public.literary_work_sources;
create policy "Staff manage work sources"
on public.literary_work_sources for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Public read publishable work external ids"
  on public.literary_work_external_ids;
create policy "Public read publishable work external ids"
on public.literary_work_external_ids for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work external ids"
  on public.literary_work_external_ids;
create policy "Staff manage work external ids"
on public.literary_work_external_ids for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Staff manage book import candidates"
  on public.book_import_candidates;
create policy "Staff manage book import candidates"
on public.book_import_candidates for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

-- Full editorial database overrides for countries plus missing history for
-- exact book editions. Static TypeScript records remain the audited fallback;
-- enabled CMS overrides are exported and applied last by the public build.

create table if not exists public.country_profile_overrides (
  id uuid primary key default gen_random_uuid(),
  country_id text not null unique
    check (char_length(country_id) between 2 and 120),
  fields jsonb not null default '{}'::jsonb,
  is_enabled boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (jsonb_typeof(fields) = 'object')
);

create index if not exists country_profile_overrides_public_idx
  on public.country_profile_overrides(country_id)
  where is_enabled;

drop trigger if exists country_profile_overrides_set_updated_at
  on public.country_profile_overrides;
create trigger country_profile_overrides_set_updated_at
  before update on public.country_profile_overrides
  for each row execute function public.set_updated_at();

create table if not exists public.country_profile_override_revisions (
  id bigint generated always as identity primary key,
  override_id uuid references public.country_profile_overrides(id)
    on delete set null,
  country_id text not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create index if not exists country_profile_override_revisions_country_idx
  on public.country_profile_override_revisions(country_id, revised_at desc);

create or replace function public.capture_country_profile_override_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  revision_actor uuid;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  if tg_op = 'UPDATE' then
    revision_actor := coalesce(new.updated_by, (select auth.uid()));
  else
    revision_actor := (select auth.uid());
  end if;
  insert into public.country_profile_override_revisions (
    override_id,
    country_id,
    snapshot,
    revised_by
  ) values (
    old.id,
    old.country_id,
    to_jsonb(old),
    revision_actor
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists country_profile_overrides_capture_revision
  on public.country_profile_overrides;
create trigger country_profile_overrides_capture_revision
  before update or delete on public.country_profile_overrides
  for each row execute function public.capture_country_profile_override_revision();


-- Durable editor-owned overrides for writer profiles and revision history for
-- both writers and literary works. The static country files remain the safe
-- fallback; published CMS values are applied last during the public build.

create table if not exists public.writer_profile_overrides (
  id uuid primary key default gen_random_uuid(),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  fields jsonb not null default '{}'::jsonb,
  is_enabled boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (country_id, writer_id),
  check (jsonb_typeof(fields) = 'object')
);

create index if not exists writer_profile_overrides_public_idx
  on public.writer_profile_overrides(country_id, writer_id)
  where is_enabled;

drop trigger if exists writer_profile_overrides_set_updated_at
  on public.writer_profile_overrides;
create trigger writer_profile_overrides_set_updated_at
  before update on public.writer_profile_overrides
  for each row execute function public.set_updated_at();

create table if not exists public.writer_profile_override_revisions (
  id bigint generated always as identity primary key,
  override_id uuid references public.writer_profile_overrides(id) on delete set null,
  country_id text not null,
  writer_id text not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create or replace function public.capture_writer_profile_override_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  revision_actor uuid;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  if tg_op = 'UPDATE' then
    revision_actor := coalesce(new.updated_by, (select auth.uid()));
  else
    revision_actor := (select auth.uid());
  end if;
  insert into public.writer_profile_override_revisions (
    override_id,
    country_id,
    writer_id,
    snapshot,
    revised_by
  ) values (
    old.id,
    old.country_id,
    old.writer_id,
    to_jsonb(old),
    revision_actor
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists writer_profile_overrides_capture_revision
  on public.writer_profile_overrides;
create trigger writer_profile_overrides_capture_revision
  before update or delete on public.writer_profile_overrides
  for each row execute function public.capture_writer_profile_override_revision();


-- Record AI-generated literary-work translations explicitly instead of
-- misclassifying them as human translations. Public publication rules remain
-- source-aware and still require reviewed/verified RU+EN records.

alter table public.literary_work_translations
  drop constraint if exists literary_work_translations_translation_method_check;

alter table public.literary_work_translations
  add constraint literary_work_translations_translation_method_check
  check (
    translation_method in (
      'editorial-original',
      'human-translation',
      'machine-translation',
      'licensed-source'
    )
  );

create or replace function public.premium_machine_translation_ready()
returns boolean
language sql
stable
security invoker
set search_path = ''
as $$
  select exists (
    select 1
    from pg_catalog.pg_constraint constraint_row
    join pg_catalog.pg_class relation
      on relation.oid = constraint_row.conrelid
    join pg_catalog.pg_namespace namespace
      on namespace.oid = relation.relnamespace
    where namespace.nspname = 'public'
      and relation.relname = 'literary_work_translations'
      and constraint_row.conname =
        'literary_work_translations_translation_method_check'
      and pg_catalog.pg_get_constraintdef(constraint_row.oid)
        like '%machine-translation%'
  );
$$;

revoke all on function public.premium_machine_translation_ready() from public;
grant execute on function public.premium_machine_translation_ready()
  to authenticated;

-- Preserve short, unreviewed draft text without changing publication rules.
-- Reviewed and verified descriptions retain the existing 140..900 limit.
do $literary_translation_draft_storage$
declare
  existing_constraint record;
  old_definition constant text :=
    'CHECK (((char_length(description) >= 140) AND (char_length(description) <= 900)))';
  target_definition constant text :=
    'CHECK ((((char_length(description) >= 140) AND (char_length(description) <= 900)) OR ((editorial_status = ''draft''::text) AND (reviewed_at IS NULL) AND ((char_length(description) >= 1) AND (char_length(description) <= 139)) AND (description ~ ''[^[:space:]]''::text))))';
begin
  lock table public.literary_work_translations
    in access exclusive mode nowait;

  select constraint_row.*,
    pg_catalog.pg_get_constraintdef(constraint_row.oid, false) as definition
  into existing_constraint
  from pg_catalog.pg_constraint constraint_row
  where constraint_row.conrelid =
      'public.literary_work_translations'::regclass
    and constraint_row.conname =
      'literary_work_translations_description_check';

  if not found
    or existing_constraint.contype <> 'c'
    or not existing_constraint.convalidated
    or not existing_constraint.conislocal
    or existing_constraint.coninhcount <> 0
    or existing_constraint.connoinherit
    or existing_constraint.condeferrable
    or existing_constraint.condeferred then
    raise exception 'Reviewed translation description constraint is missing or incompatible';
  end if;

  if existing_constraint.definition = target_definition then
    return;
  end if;
  if existing_constraint.definition <> old_definition then
    raise exception 'Translation description constraint differs from the reviewed predecessor';
  end if;

  alter table public.literary_work_translations
    drop constraint literary_work_translations_description_check;
  -- Adding a validated CHECK scans existing rows inside the same transaction.
  alter table public.literary_work_translations
    add constraint literary_work_translations_description_check check (
      char_length(description) between 140 and 900
      or (
        editorial_status = 'draft'
        and reviewed_at is null
        and char_length(description) between 1 and 139
        and description ~ '[^[:space:]]'
      )
    );
end;
$literary_translation_draft_storage$;

-- Private review candidates for books/countries. This is not a job queue.
-- Existing canonical rows, publication policies and public-build triggers are
-- unchanged. Only explicit human promotion writes canonical English.
create schema if not exists premium_translation_private;
revoke all on schema premium_translation_private from public, anon, authenticated;

create table public.premium_translation_working_drafts (
  id uuid primary key default gen_random_uuid(),
  version bigint not null default 1 check (version between 1 and 9007199254740991),
  entity_type text not null check (entity_type in ('literary_work', 'country')),
  entity_id text not null check (char_length(entity_id) between 1 and 120),
  target_locale text not null default 'en' check (target_locale = 'en'),
  human_review text not null default 'pending' check (human_review = 'pending'),
  source_hash text not null check (source_hash ~ '^[a-f0-9]{64}$'),
  candidate_hash text not null check (candidate_hash ~ '^[a-f0-9]{64}$'),
  source_revision jsonb not null check (jsonb_typeof(source_revision) = 'object'),
  target_revision jsonb not null check (jsonb_typeof(target_revision) = 'object'),
  source_snapshot jsonb not null check (jsonb_typeof(source_snapshot) = 'object'),
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  provenance jsonb not null check (jsonb_typeof(provenance) = 'object'),
  created_at timestamptz not null default clock_timestamp(),
  created_by uuid not null references auth.users(id) on delete restrict,
  unique (entity_type, entity_id, target_locale)
);
alter table public.premium_translation_working_drafts enable row level security;
alter table public.premium_translation_working_drafts force row level security;
-- No policies and no direct table grants: all access goes through the four
-- staff-checked RPCs. In particular no public content/outbox trigger exists.
revoke all on public.premium_translation_working_drafts from public, anon, authenticated;

create function premium_translation_private.assert_actor()
returns uuid language plpgsql security invoker set search_path = '' as $$
declare actor uuid := auth.uid();
begin
  if actor is null or not coalesce(public.is_staff(), false) then
    raise exception using errcode = '42501', message = 'Staff actor required';
  end if;
  return actor;
end;
$$;

create function premium_translation_private.assert_identity(kind text, identity text)
returns void language plpgsql immutable set search_path = '' as $$
begin
  if kind is null or kind not in ('literary_work','country') or identity is null
    or char_length(identity) not between 1 and 120
    or (kind = 'literary_work' and identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') then
    raise exception using errcode = '22023', message = 'Invalid candidate identity';
  end if;
end;
$$;

create function premium_translation_private.exact_object(value jsonb, keys text[])
returns boolean language sql immutable set search_path = '' as $$
  select coalesce(jsonb_typeof(value) = 'object' and value ?& keys
    and (value - keys) = '{}'::jsonb, false);
$$;

create function premium_translation_private.string_array(value jsonb, max_items integer, max_length integer)
returns boolean language plpgsql immutable set search_path = '' as $$
declare item jsonb;
begin
  if jsonb_typeof(value) is distinct from 'array' then return false; end if;
  if jsonb_array_length(value) > max_items then return false; end if;
  for item in select jsonb_array_elements(value) loop
    if jsonb_typeof(item) <> 'string' or char_length(item #>> '{}') > max_length then return false; end if;
  end loop;
  return true;
end;
$$;

create function premium_translation_private.valid_timestamp(value text)
returns boolean language plpgsql immutable set search_path = '' as $$
begin
  if value is null or value !~ '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$' then return false; end if;
  perform value::timestamptz;
  return true;
exception when invalid_datetime_format or datetime_field_overflow then return false;
end;
$$;

create function premium_translation_private.valid_revision(value jsonb)
returns boolean language plpgsql immutable set search_path = '' as $$
begin
  if not premium_translation_private.exact_object(value, array['id','updatedAt']) then return false; end if;
  if value->'id' = 'null'::jsonb then return value->'updatedAt' = 'null'::jsonb; end if;
  return coalesce(jsonb_typeof(value->'id') = 'string'
    and value->>'id' ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
    and jsonb_typeof(value->'updatedAt') = 'string'
    and premium_translation_private.valid_timestamp(value->>'updatedAt'), false);
end;
$$;

-- ECMAScript String.trim whitespace, matching the existing Zod generators.
-- Used only for validation; candidate bytes and source snapshots stay intact.
create function premium_translation_private.trim_text(value text)
returns text language sql immutable set search_path = '' as $$
  select btrim(value, E' \t\n\r\f' || chr(11) || chr(160) || chr(5760)
    || chr(8192) || chr(8193) || chr(8194) || chr(8195) || chr(8196)
    || chr(8197) || chr(8198) || chr(8199) || chr(8200) || chr(8201)
    || chr(8202) || chr(8232) || chr(8233) || chr(8239) || chr(8287)
    || chr(12288) || chr(65279));
$$;

create function premium_translation_private.valid_country_fields(value jsonb, translated boolean)
returns boolean language plpgsql immutable set search_path = '' as $$
declare key text; max_length integer; item jsonb;
begin
  if not premium_translation_private.exact_object(value, array['name','region','continent','officialLanguage','capital',
      'description','history','historicalNote','literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology']) then return false; end if;
  foreach key in array array['name','region','continent','officialLanguage','capital','description','history','historicalNote'] loop
    max_length := case key when 'name' then 160 when 'region' then 160 when 'continent' then 160
      when 'officialLanguage' then 300 when 'capital' then 200 when 'history' then 8000 else 4000 end;
    if jsonb_typeof(value->key) <> 'string' or (translated and char_length(value->>key) > max_length) then return false; end if;
  end loop;
  if char_length(premium_translation_private.trim_text(value->>'name')) = 0 then return false; end if;
  foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces'] loop
    if not premium_translation_private.string_array(value->key,
      case when translated then case when key in ('facts','literaryPlaces') then 80 else 40 end else 10000 end,
      case when translated then case key when 'facts' then 1000 when 'literaryPlaces' then 500 else 300 end else 100000 end)
      then return false; end if;
  end loop;
  foreach key in array array['timeline','chronology'] loop
    if jsonb_typeof(value->key) <> 'array' then return false; end if;
    if jsonb_array_length(value->key) > (case when translated then 100 else 10000 end) then return false; end if;
    for item in select jsonb_array_elements(value->key) loop
      if not premium_translation_private.exact_object(item,array['year','title','description'])
        or jsonb_typeof(item->'year') <> 'string' or jsonb_typeof(item->'title') <> 'string'
        or jsonb_typeof(item->'description') <> 'string' then return false; end if;
      if translated and (char_length(item->>'year') > 80 or char_length(item->>'title') > 500
        or char_length(item->>'description') > 2000) then return false; end if;
    end loop;
  end loop;
  if translated and exists(select 1 from unnest(string_to_array(value::text,null::text)) glyph
    where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
      or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
      or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023) then return false; end if;
  return true;
end;
$$;

create function premium_translation_private.assert_shape(kind text, snapshot jsonb, source_revision jsonb,
  target_revision jsonb, payload jsonb, provenance jsonb)
returns void language plpgsql immutable set search_path = '' as $$
declare key text; item jsonb; source_item jsonb; idx integer;
begin
  if not premium_translation_private.valid_revision(target_revision)
    or not premium_translation_private.exact_object(provenance,array['provider','translatorModel','reviewerModel',
      'translatorRequestId','reviewerRequestId','generatedAt']) then
    raise exception using errcode='22023', message='Invalid candidate shape';
  end if;
  if provenance->>'provider' not in ('cloudflare','openai') or jsonb_typeof(provenance->'provider') <> 'string'
    or jsonb_typeof(provenance->'translatorModel') <> 'string' or char_length(provenance->>'translatorModel') not between 1 and 300
    or jsonb_typeof(provenance->'generatedAt') <> 'string' or not premium_translation_private.valid_timestamp(provenance->>'generatedAt') then
    raise exception using errcode='22023', message='Invalid candidate provenance';
  end if;
  foreach key in array array['reviewerModel','translatorRequestId','reviewerRequestId'] loop
    if jsonb_typeof(provenance->key) not in ('string','null') or
      (key='reviewerModel' and jsonb_typeof(provenance->key)='string' and char_length(provenance->>key) not between 1 and 300) then
      raise exception using errcode='22023', message='Invalid candidate provenance';
    end if;
  end loop;
  if kind = 'literary_work' then
    if not premium_translation_private.exact_object(source_revision,array['workId','workUpdatedAt','russianId','russianUpdatedAt'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'workId','updatedAt',source_revision->'workUpdatedAt'))
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'russianId','updatedAt',source_revision->'russianUpdatedAt'))
      or source_revision->>'workId' is null or source_revision->>'russianId' is null or target_revision->>'id' is null
      or not premium_translation_private.exact_object(snapshot,array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl',
        'description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls'])
      or not premium_translation_private.exact_object(payload,array['description','sourceLanguage','sourceUrls','bibliographicTitle'])
      or not premium_translation_private.exact_object(payload->'bibliographicTitle',array['value','provider','sourceUrl','retrievedAt']) then
      raise exception using errcode='22023', message='Invalid book candidate shape';
    end if;
    foreach key in array array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','originalLanguage','sourceLanguage'] loop
      if jsonb_typeof(snapshot->key) <> 'string' then raise exception using errcode='22023', message='Invalid book source shape'; end if;
    end loop;
    if jsonb_typeof(snapshot->'firstPublished') not in ('number','null')
      or not premium_translation_private.string_array(snapshot->'sourceUrls',10000,100000)
      or jsonb_typeof(payload->'description') <> 'string' or char_length(payload->>'description') not between 140 and 900
      or char_length(premium_translation_private.trim_text(payload->>'description')) not between 140 and 900
      or exists(select 1 from unnest(string_to_array(payload->>'description',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or (select count(*) from regexp_matches(payload->>'description','[.!?:]+(?=\s|$)','g')) not between 2 and 3
      or payload->>'sourceLanguage' is distinct from 'Russian'
      or not premium_translation_private.string_array(payload->'sourceUrls',10000,100000) then
      raise exception using errcode='22023', message='Invalid book candidate content';
    end if;
    foreach key in array array['value','provider','sourceUrl'] loop
      if jsonb_typeof(payload->'bibliographicTitle'->key) <> 'string' or char_length(payload->'bibliographicTitle'->>key)=0 then
        raise exception using errcode='22023', message='Invalid title provenance';
      end if;
    end loop;
    if jsonb_typeof(payload#>'{bibliographicTitle,retrievedAt}') not in ('string','null') then
      raise exception using errcode='22023', message='Invalid title provenance';
    end if;
    for item in select jsonb_array_elements(payload->'sourceUrls') loop
      if item #>> '{}' !~ '^https://' then raise exception using errcode='22023', message='Invalid candidate source URL'; end if;
    end loop;
  else
    if not premium_translation_private.exact_object(source_revision,array['overrideId','overrideUpdatedAt','catalogSourceHash'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt'))
      or jsonb_typeof(source_revision->'catalogSourceHash') <> 'string'
      or source_revision->>'catalogSourceHash' is null or source_revision->>'catalogSourceHash' !~ '^[a-f0-9]{64}$'
      or not premium_translation_private.valid_country_fields(snapshot,false)
      or not premium_translation_private.exact_object(payload,array['fields'])
      or not premium_translation_private.valid_country_fields(payload->'fields',true) then
      raise exception using errcode='22023', message='Invalid country candidate shape';
    end if;
    foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology'] loop
      if jsonb_array_length(snapshot->key) <> jsonb_array_length(payload->'fields'->key) then
        raise exception using errcode='22023', message='Country candidate changed item count';
      end if;
      if key in ('timeline','chronology') then
        for idx in 0..jsonb_array_length(snapshot->key)-1 loop
          if snapshot->key->idx->'year' is distinct from payload->'fields'->key->idx->'year' then
            raise exception using errcode='22023', message='Country candidate changed year';
          end if;
        end loop;
      end if;
    end loop;
  end if;
end;
$$;

-- Locks and verifies live SQL state on BOTH stage and promotion. Country static
-- catalog content is application-owned: catalogSourceHash is an additional
-- trusted-app binding, not a claim that SQL can independently read TS catalogs.
create function premium_translation_private.assert_current(kind text, identity text, snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql security invoker set search_path = '' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype;
  en public.literary_work_translations%rowtype; title_source public.literary_work_sources%rowtype;
  country public.country_profile_overrides%rowtype; current_source jsonb; urls jsonb;
begin
  if kind = 'literary_work' then
    select * into work from public.literary_works where id=identity::uuid for update;
    if not found or work.editorial_status not in ('reviewed','verified')
      or source_revision->>'workId' is distinct from identity
      or work.updated_at is distinct from (source_revision->>'workUpdatedAt')::timestamptz then
      raise exception using errcode='40001',message='Book source changed';
    end if;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru' for update;
    if not found or ru.id is distinct from (source_revision->>'russianId')::uuid
      or ru.updated_at is distinct from (source_revision->>'russianUpdatedAt')::timestamptz
      or ru.editorial_status not in ('reviewed','verified') or cardinality(ru.source_urls)=0 then
      raise exception using errcode='40001',message='Russian source changed';
    end if;
    select * into en from public.literary_work_translations where work_id=work.id and locale='en' for update;
    if not found or en.id is distinct from (target_revision->>'id')::uuid
      or en.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
      or en.translation_method <> 'machine-translation'
      or btrim(en.title)='' or exists(select 1 from unnest(string_to_array(en.title,null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,value}' is distinct from btrim(en.title)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,sourceUrl}' is distinct from snapshot->>'verifiedEnglishTitleSourceUrl'
      or not coalesce(snapshot->>'verifiedEnglishTitleSourceUrl'=any(en.source_urls),false) then
      raise exception using errcode='40001',message='English target or title ownership changed';
    end if;
    select * into title_source from public.literary_work_sources
      where work_id=work.id and source_url=snapshot->>'verifiedEnglishTitleSourceUrl'
        and provider=payload#>>'{bibliographicTitle,provider}' and 'title'=any(field_names)
      order by id limit 1 for share;
    if not found or jsonb_build_object('value',btrim(en.title),'provider',title_source.provider,
      'sourceUrl',title_source.source_url,'retrievedAt',title_source.retrieved_at) is distinct from payload->'bibliographicTitle' then
      raise exception using errcode='40001',message='Bibliographic title provenance changed';
    end if;
    current_source := jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),
      'verifiedEnglishTitleSourceUrl',title_source.source_url,'description',ru.description,
      'originalTitle',coalesce(work.original_title,''),'firstPublished',work.first_published,
      'originalLanguage',coalesce(work.original_language,''),'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    if current_source is distinct from snapshot then raise exception using errcode='40001',message='Book source snapshot changed'; end if;
    -- Ordered JS Set union used by the existing helper, preserving source rights.
    select coalesce(jsonb_agg(url order by position),'[]'::jsonb) into urls from (
      select url,min(position) position from (
        select url,position from unnest(en.source_urls) with ordinality as english(url,position) where url ~ '^https://'
        union all select url,position+cardinality(en.source_urls) from unnest(ru.source_urls) with ordinality as russian(url,position)
      ) combined group by url
    ) unique_urls;
    if urls is distinct from payload->'sourceUrls' then raise exception using errcode='40001',message='Candidate source provenance changed'; end if;
  else
    if jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt') is distinct from target_revision then
      raise exception using errcode='40001',message='Country source and target revisions differ';
    end if;
    select * into country from public.country_profile_overrides where country_id=identity for update;
    if found then
      if country.id is distinct from (target_revision->>'id')::uuid
        or country.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz then
        raise exception using errcode='40001',message='Country override changed';
      end if;
      if country.fields ? 'translations' and jsonb_typeof(country.fields->'translations') <> 'object' then
        raise exception using errcode='40001',message='Country translation ownership is ambiguous';
      end if;
      if country.fields->'translations' ? 'en' and (
        country.fields#>>'{translations,en,locale}' is distinct from 'en'
        or country.fields#>>'{translations,en,method}' is distinct from 'machine-translation') then
        raise exception using errcode='40001',message='Manual country English is protected';
      end if;
    elsif target_revision->>'id' is not null then
      raise exception using errcode='40001',message='Country override disappeared';
    end if;
  end if;
end;
$$;

create function premium_translation_private.dto(candidate public.premium_translation_working_drafts)
returns jsonb language sql stable set search_path = '' as $$
  select jsonb_build_object('id',candidate.id,'version',candidate.version,'entityType',candidate.entity_type,'entityId',candidate.entity_id,
    'targetLocale',candidate.target_locale,'humanReview',candidate.human_review,'sourceHash',candidate.source_hash,'candidateHash',candidate.candidate_hash,
    'sourceRevision',candidate.source_revision,'targetRevision',candidate.target_revision,'sourceSnapshot',candidate.source_snapshot,
    'payload',candidate.payload,'provenance',candidate.provenance,'createdAt',candidate.created_at,'createdBy',candidate.created_by);
$$;

create function public.get_premium_translation_working_draft(p_entity_type text, p_entity_id text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare candidate public.premium_translation_working_drafts%rowtype;
begin
  perform premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en';
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,
    'draft',case when candidate.id is null then null else premium_translation_private.dto(candidate) end);
end;
$$;

create function public.stage_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_source_hash text, p_source_snapshot jsonb, p_source_revision jsonb, p_target_revision jsonb,
  p_payload jsonb, p_provenance jsonb, p_expected_draft_id uuid, p_expected_draft_version bigint)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; digest text;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_expected_draft_id is not null or p_expected_draft_version is distinct from 0
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$' then
    raise exception using errcode='22023',message='Invalid initial candidate request';
  end if;
  perform premium_translation_private.assert_shape(p_entity_type,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance);
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  if exists(select 1 from public.premium_translation_working_drafts where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en') then
    raise exception using errcode='40001',message='Pending candidate must be explicitly discarded';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,p_source_snapshot,p_source_revision,p_target_revision,p_payload);
  digest := encode(sha256(convert_to(jsonb_build_object('entityType',p_entity_type,'entityId',p_entity_id,'targetLocale','en',
    'sourceHash',p_source_hash,'sourceSnapshot',p_source_snapshot,'sourceRevision',p_source_revision,
    'targetRevision',p_target_revision,'payload',p_payload,'provenance',p_provenance)::text,'UTF8')),'hex');
  insert into public.premium_translation_working_drafts(entity_type,entity_id,source_hash,candidate_hash,source_snapshot,
    source_revision,target_revision,payload,provenance,created_by)
    values(p_entity_type,p_entity_id,p_source_hash,digest,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance,actor)
    returning * into candidate;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.staged',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',digest,'sourceHash',p_source_hash,'outcome','pending'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'draft',premium_translation_private.dto(candidate));
exception when unique_violation then raise exception using errcode='40001',message='Candidate changed concurrently';
end;
$$;

create function public.promote_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text, p_source_hash text,
  p_catalog_source_hash text, p_catalog_source_fields jsonb, p_confirm_human_review boolean)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; review_time timestamptz;
  canonical_id uuid; canonical_updated_at timestamptz; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; human jsonb; meta jsonb; english jsonb; next_fields jsonb; translations jsonb;
  catalog_translations jsonb; protected_english jsonb;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_confirm_human_review is distinct from true then raise exception using errcode='22023',message='Explicit human review is required'; end if;
  if (p_entity_type='literary_work' and p_catalog_source_fields is not null)
    or (p_entity_type='country' and (jsonb_typeof(p_catalog_source_fields) is distinct from 'object'
      or (p_catalog_source_fields ? 'translations' and jsonb_typeof(p_catalog_source_fields->'translations') is distinct from 'object'))) then
    raise exception using errcode='22023',message='Invalid current catalog shape';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash or candidate.source_hash is distinct from p_source_hash
    or (p_entity_type='literary_work' and p_catalog_source_hash is not null)
    or (p_entity_type='country' and candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash) then
    raise exception using errcode='40001',message='Candidate or source changed';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,candidate.source_snapshot,
    candidate.source_revision,candidate.target_revision,candidate.payload);
  review_time := clock_timestamp();
  human := jsonb_build_object('status','approved','reviewedBy',actor,'reviewedAt',review_time);
  if p_entity_type='literary_work' then
    select * into en from public.literary_work_translations where id=(candidate.target_revision->>'id')::uuid;
    meta := case when jsonb_typeof(en.metadata)='object' then en.metadata else '{}'::jsonb end;
    meta := meta || jsonb_build_object('premiumTranslation',
      (case when jsonb_typeof(meta->'premiumTranslation')='object' then meta->'premiumTranslation' else '{}'::jsonb end)
      || jsonb_build_object('sourceHash',candidate.source_hash,'provider',candidate.provenance->'provider',
        'translatorModel',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'generatedAt',candidate.provenance->'generatedAt','bibliographicTitle',candidate.payload->'bibliographicTitle',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time));
    update public.literary_work_translations set description=candidate.payload->>'description',source_language='Russian',
      translation_method='machine-translation',editorial_status='reviewed',reviewed_at=review_time::date,
      source_urls=array(select jsonb_array_elements_text(candidate.payload->'sourceUrls')),metadata=meta
      where id=en.id returning id,updated_at into canonical_id,canonical_updated_at;
  else
    select * into country from public.country_profile_overrides where country_id=p_entity_id;
    next_fields := coalesce(country.fields,'{}'::jsonb);
    catalog_translations := case when jsonb_typeof(p_catalog_source_fields->'translations')='object'
      then p_catalog_source_fields->'translations' else '{}'::jsonb end;
    translations := case when next_fields ? 'translations' then next_fields->'translations' else catalog_translations end;
    if translations ? 'en' then protected_english := translations->'en';
    elsif catalog_translations ? 'en' then protected_english := catalog_translations->'en'; end if;
    if protected_english is not null and (protected_english->>'locale' is distinct from 'en'
      or protected_english->>'method' is distinct from 'machine-translation') then
      raise exception using errcode='40001',message='Manual catalog English is protected';
    end if;
    select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into meta from jsonb_each(candidate.payload->'fields')
      where value <> '""'::jsonb and value <> '[]'::jsonb;
    english := (case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end)
      || jsonb_build_object('locale','en','status','reviewed','method','machine-translation','sourceHash',candidate.source_hash,
        'generatedAt',candidate.provenance->'generatedAt','provider',candidate.provenance->'provider',
        'model',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'fields',meta,'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    next_fields := next_fields || jsonb_build_object('translations',translations || jsonb_build_object('en',english));
    if country.id is null then
      insert into public.country_profile_overrides(country_id,fields,updated_by)
        values(p_entity_id,next_fields,actor) returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.country_profile_overrides set fields=next_fields,updated_by=actor
        where id=country.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.promoted',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
        'sourceHash',candidate.source_hash,'canonicalId',canonical_id,'outcome','promoted'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','promoted',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
    'canonicalId',canonical_id,'canonicalUpdatedAt',canonical_updated_at,'reviewedBy',actor,'reviewedAt',review_time);
exception when unique_violation then raise exception using errcode='40001',message='Canonical target changed concurrently';
end;
$$;

create function public.discard_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash then
    raise exception using errcode='40001',message='Candidate changed';
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.discarded',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,'outcome','discarded'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','discarded',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash);
end;
$$;

revoke all on all functions in schema premium_translation_private from public, anon, authenticated;
revoke all on function public.get_premium_translation_working_draft(text,text) from public, anon, authenticated;
revoke all on function public.stage_premium_translation_working_draft(text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,uuid,bigint) from public, anon, authenticated;
revoke all on function public.promote_premium_translation_working_draft(text,text,uuid,bigint,text,text,text,jsonb,boolean) from public, anon, authenticated;
revoke all on function public.discard_premium_translation_working_draft(text,text,uuid,bigint,text) from public, anon, authenticated;
grant execute on function public.get_premium_translation_working_draft(text,text) to authenticated;
grant execute on function public.stage_premium_translation_working_draft(text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,uuid,bigint) to authenticated;
grant execute on function public.promote_premium_translation_working_draft(text,text,uuid,bigint,text,text,text,jsonb,boolean) to authenticated;
grant execute on function public.discard_premium_translation_working_draft(text,text,uuid,bigint,text) to authenticated;

-- Extend the existing private review contract to writer biographies. No queue,
-- publication trigger or canonical row is created/changed by staging a candidate.
-- Earlier migrations and the book/country contracts remain unchanged.
alter table public.premium_translation_working_drafts
  drop constraint premium_translation_working_drafts_entity_type_check,
  add constraint premium_translation_working_drafts_entity_type_check
    check (entity_type in ('literary_work','country','writer_biography')),
  drop constraint premium_translation_working_drafts_entity_id_check,
  add constraint premium_translation_working_drafts_entity_id_check
    check (char_length(entity_id) between 1 and
      case when entity_type='writer_biography' then 301 else 120 end);

create or replace function premium_translation_private.assert_identity(kind text, identity text)
returns void language plpgsql immutable set search_path = '' as $$
declare country_identity text; writer_identity text;
begin
  if kind='writer_biography' then
    country_identity := split_part(identity,':',1);
    writer_identity := split_part(identity,':',2);
    if identity is null or char_length(identity)>301
      or identity is distinct from country_identity||':'||writer_identity
      or char_length(country_identity) not between 2 and 120
      or country_identity !~ '^[a-z0-9][a-z0-9_-]*$'
      or char_length(writer_identity) not between 2 and 180
      or writer_identity ~ '[[:space:][:cntrl:]/:]' then
      raise exception using errcode='22023',message='Invalid candidate identity';
    end if;
    return;
  end if;
  if kind is null or kind not in ('literary_work','country') or identity is null
    or char_length(identity) not between 1 and 120
    or (kind = 'literary_work' and identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') then
    raise exception using errcode = '22023', message = 'Invalid candidate identity';
  end if;
end;
$$;

-- Provider projection only. The complete raw source remains in russianProfile
-- and is copied unchanged at promotion, including rights and unknown metadata.
create function premium_translation_private.writer_source_projection(raw_sources jsonb)
returns jsonb language plpgsql immutable set search_path='' as $$
declare source jsonb; field jsonb; fields jsonb; projected jsonb; result jsonb := '[]'::jsonb;
  provider text; url text; usage text; retrieved text; key text;
begin
  if jsonb_typeof(raw_sources) is distinct from 'array' then return result; end if;
  for source in select jsonb_array_elements(raw_sources) loop
    if jsonb_typeof(source) is distinct from 'object' then continue; end if;
    provider := case when jsonb_typeof(source->'provider')='string' then premium_translation_private.trim_text(source->>'provider') else '' end;
    url := case when jsonb_typeof(source->'url')='string' then premium_translation_private.trim_text(source->>'url') else '' end;
    usage := case when jsonb_typeof(source->'usage')='string' then premium_translation_private.trim_text(source->>'usage') else '' end;
    retrieved := case when jsonb_typeof(source->'retrievedAt')='string' then premium_translation_private.trim_text(source->>'retrievedAt') else '' end;
    fields := '[]'::jsonb;
    if jsonb_typeof(source->'fields')='array' then
      for field in select jsonb_array_elements(source->'fields') loop
        if jsonb_typeof(field)='string' and premium_translation_private.trim_text(field#>>'{}') in
          ('identity','life-dates','biography-facts','awards','works') then
          fields := fields || jsonb_build_array(premium_translation_private.trim_text(field#>>'{}'));
        end if;
      end loop;
    end if;
    if provider='' or url !~* '^https://' or jsonb_array_length(fields)=0
      or usage not in ('structured-data','fact-check','licensed-copy') or retrieved='' then continue; end if;
    projected := jsonb_build_object('provider',provider,'url',url,'fields',fields,'usage',usage,'retrievedAt',retrieved);
    foreach key in array array['author','title','licenseName','licenseUrl'] loop
      if jsonb_typeof(source->key)='string' then projected := projected||jsonb_build_object(key,source->key); end if;
    end loop;
    result := result||jsonb_build_array(projected);
  end loop;
  return result;
end;
$$;

create function premium_translation_private.assert_writer_shape(snapshot jsonb, source_revision jsonb,
  target_revision jsonb, payload jsonb, provenance jsonb)
returns void language plpgsql immutable set search_path='' as $$
declare russian jsonb;
begin
  if not premium_translation_private.exact_object(source_revision,
      array['countryId','writerId','overrideId','overrideUpdatedAt','catalogSourceHash','replaceEnglishTombstone'])
    or jsonb_typeof(source_revision->'countryId') is distinct from 'string'
    or jsonb_typeof(source_revision->'writerId') is distinct from 'string'
    or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt'))
    or jsonb_typeof(source_revision->'catalogSourceHash') is distinct from 'string'
    or source_revision->>'catalogSourceHash' !~ '^[a-f0-9]{64}$'
    or jsonb_typeof(source_revision->'replaceEnglishTombstone') is distinct from 'boolean'
    or not premium_translation_private.exact_object(snapshot,array['writerName','text','sourceLanguage','sources','russianProfile','catalogFields'])
    or jsonb_typeof(snapshot->'writerName') is distinct from 'string'
    or jsonb_typeof(snapshot->'text') is distinct from 'string'
    or jsonb_typeof(snapshot->'sourceLanguage') is distinct from 'string'
    or jsonb_typeof(snapshot->'sources') is distinct from 'array'
    or jsonb_typeof(snapshot->'russianProfile') is distinct from 'object'
    or jsonb_typeof(snapshot->'catalogFields') is distinct from 'object'
    or not premium_translation_private.exact_object(payload,array['text'])
    or jsonb_typeof(payload->'text') is distinct from 'string'
    or char_length(payload->>'text') not between 120 and 1600
    or char_length(premium_translation_private.trim_text(payload->>'text')) not between 120 and 1600
    or jsonb_typeof(provenance->'reviewerModel') is distinct from 'string'
    or char_length(premium_translation_private.trim_text(provenance->>'reviewerModel')) not between 1 and 300 then
    raise exception using errcode='22023',message='Invalid writer candidate shape';
  end if;
  perform premium_translation_private.assert_identity('writer_biography',(source_revision->>'countryId')||':'||(source_revision->>'writerId'));
  russian := snapshot->'russianProfile';
  if russian->>'locale' is distinct from 'ru'
    or russian->>'method' is distinct from 'editorial-original'
    or coalesce(russian->>'status','') not in ('reviewed','verified')
    or jsonb_typeof(russian->'reviewedAt') is distinct from 'string' or russian->>'reviewedAt'=''
    or jsonb_typeof(russian->'text') is distinct from 'string'
    or jsonb_typeof(russian->'sourceLanguage') is distinct from 'string'
    or jsonb_typeof(russian->'sources') is distinct from 'array'
    or snapshot->>'text' is distinct from premium_translation_private.trim_text(russian->>'text')
    or snapshot->>'sourceLanguage' is distinct from premium_translation_private.trim_text(russian->>'sourceLanguage')
    or snapshot->'sources' is distinct from premium_translation_private.writer_source_projection(russian->'sources')
    or jsonb_array_length(snapshot->'sources')=0 then
    raise exception using errcode='22023',message='Invalid writer source provenance';
  end if;
end;
$$;

-- Catalog fields/hash are a trusted server reload binding, not a claim that SQL
-- can read the checked-in TypeScript catalog. SQL independently binds the live
-- override, its exact timestamp, the raw RU profile, and parent-map ownership.
create function premium_translation_private.assert_writer_current(identity text, snapshot jsonb,
  source_revision jsonb, target_revision jsonb)
returns void language plpgsql security invoker set search_path='' as $$
declare writer public.writer_profile_overrides%rowtype; effective jsonb; translations jsonb;
  raw_english jsonb; writer_name text; override_owned boolean;
begin
  if identity is distinct from (source_revision->>'countryId')||':'||(source_revision->>'writerId')
    or jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt') is distinct from target_revision then
    raise exception using errcode='40001',message='Writer source and target identities differ';
  end if;
  select * into writer from public.writer_profile_overrides
    where country_id=source_revision->>'countryId' and writer_id=source_revision->>'writerId' for update;
  if found then
    if writer.id is distinct from (target_revision->>'id')::uuid
      or writer.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz then
      raise exception using errcode='40001',message='Writer override changed';
    end if;
  elsif target_revision->>'id' is not null then
    raise exception using errcode='40001',message='Writer override disappeared';
  end if;
  effective := snapshot->'catalogFields'||coalesce(writer.fields,'{}'::jsonb);
  translations := effective->'biographyTranslations';
  if jsonb_typeof(translations) is distinct from 'object'
    or translations->'ru' is distinct from snapshot->'russianProfile' then
    raise exception using errcode='40001',message='Writer Russian source changed';
  end if;
  writer_name := coalesce(nullif(case when jsonb_typeof(effective->'fullName')='string'
      then premium_translation_private.trim_text(effective->>'fullName') end,''),
    nullif(case when jsonb_typeof(effective->'name')='string'
      then premium_translation_private.trim_text(effective->>'name') end,''),source_revision->>'writerId');
  if writer_name is distinct from snapshot->>'writerName' then
    raise exception using errcode='40001',message='Writer source identity changed';
  end if;
  override_owned := coalesce(writer.fields ? 'biographyTranslations',false);
  if override_owned and (not (translations ? 'en') or translations->'en'='null'::jsonb)
    and source_revision->'replaceEnglishTombstone' is distinct from 'true'::jsonb then
    raise exception using errcode='40001',message='Writer English tombstone is protected';
  end if;
  raw_english := translations->'en';
  if not override_owned and translations ? 'en' and raw_english='null'::jsonb then
    raise exception using errcode='40001',message='Ambiguous catalog writer English is protected';
  end if;
  if raw_english is not null and raw_english<>'null'::jsonb and
    (jsonb_typeof(raw_english) is distinct from 'object'
      or raw_english->>'locale' is distinct from 'en'
      or raw_english->>'method' is distinct from 'machine-translation'
      or jsonb_typeof(raw_english->'text') is distinct from 'string'
      or jsonb_typeof(raw_english->'sourceLanguage') is distinct from 'string'
      or coalesce(raw_english->>'status','') not in ('draft','reviewed','verified')
      or (raw_english ? 'translationMeta' and jsonb_typeof(raw_english->'translationMeta') is distinct from 'object')) then
    raise exception using errcode='40001',message='Manual or ambiguous writer English is protected';
  end if;
end;
$$;

create or replace function premium_translation_private.assert_shape(kind text, snapshot jsonb, source_revision jsonb,
  target_revision jsonb, payload jsonb, provenance jsonb)
returns void language plpgsql immutable set search_path = '' as $$
declare key text; item jsonb; source_item jsonb; idx integer;
begin
  if not premium_translation_private.valid_revision(target_revision)
    or not premium_translation_private.exact_object(provenance,array['provider','translatorModel','reviewerModel',
      'translatorRequestId','reviewerRequestId','generatedAt']) then
    raise exception using errcode='22023', message='Invalid candidate shape';
  end if;
  if provenance->>'provider' not in ('cloudflare','openai') or jsonb_typeof(provenance->'provider') <> 'string'
    or jsonb_typeof(provenance->'translatorModel') <> 'string' or char_length(provenance->>'translatorModel') not between 1 and 300
    or jsonb_typeof(provenance->'generatedAt') <> 'string' or not premium_translation_private.valid_timestamp(provenance->>'generatedAt') then
    raise exception using errcode='22023', message='Invalid candidate provenance';
  end if;
  foreach key in array array['reviewerModel','translatorRequestId','reviewerRequestId'] loop
    if jsonb_typeof(provenance->key) not in ('string','null') or
      (key='reviewerModel' and jsonb_typeof(provenance->key)='string' and char_length(provenance->>key) not between 1 and 300) then
      raise exception using errcode='22023', message='Invalid candidate provenance';
    end if;
  end loop;
  if kind='writer_biography' then
    perform premium_translation_private.assert_writer_shape(snapshot,source_revision,target_revision,payload,provenance);
    return;
  end if;
  if kind = 'literary_work' then
    if not premium_translation_private.exact_object(source_revision,array['workId','workUpdatedAt','russianId','russianUpdatedAt'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'workId','updatedAt',source_revision->'workUpdatedAt'))
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'russianId','updatedAt',source_revision->'russianUpdatedAt'))
      or source_revision->>'workId' is null or source_revision->>'russianId' is null or target_revision->>'id' is null
      or not premium_translation_private.exact_object(snapshot,array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl',
        'description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls'])
      or not premium_translation_private.exact_object(payload,array['description','sourceLanguage','sourceUrls','bibliographicTitle'])
      or not premium_translation_private.exact_object(payload->'bibliographicTitle',array['value','provider','sourceUrl','retrievedAt']) then
      raise exception using errcode='22023', message='Invalid book candidate shape';
    end if;
    foreach key in array array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','originalLanguage','sourceLanguage'] loop
      if jsonb_typeof(snapshot->key) <> 'string' then raise exception using errcode='22023', message='Invalid book source shape'; end if;
    end loop;
    if jsonb_typeof(snapshot->'firstPublished') not in ('number','null')
      or not premium_translation_private.string_array(snapshot->'sourceUrls',10000,100000)
      or jsonb_typeof(payload->'description') <> 'string' or char_length(payload->>'description') not between 140 and 900
      or char_length(premium_translation_private.trim_text(payload->>'description')) not between 140 and 900
      or exists(select 1 from unnest(string_to_array(payload->>'description',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or (select count(*) from regexp_matches(payload->>'description','[.!?:]+(?=\s|$)','g')) not between 2 and 3
      or payload->>'sourceLanguage' is distinct from 'Russian'
      or not premium_translation_private.string_array(payload->'sourceUrls',10000,100000) then
      raise exception using errcode='22023', message='Invalid book candidate content';
    end if;
    foreach key in array array['value','provider','sourceUrl'] loop
      if jsonb_typeof(payload->'bibliographicTitle'->key) <> 'string' or char_length(payload->'bibliographicTitle'->>key)=0 then
        raise exception using errcode='22023', message='Invalid title provenance';
      end if;
    end loop;
    if jsonb_typeof(payload#>'{bibliographicTitle,retrievedAt}') not in ('string','null') then
      raise exception using errcode='22023', message='Invalid title provenance';
    end if;
    for item in select jsonb_array_elements(payload->'sourceUrls') loop
      if item #>> '{}' !~ '^https://' then raise exception using errcode='22023', message='Invalid candidate source URL'; end if;
    end loop;
  else
    if not premium_translation_private.exact_object(source_revision,array['overrideId','overrideUpdatedAt','catalogSourceHash'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt'))
      or jsonb_typeof(source_revision->'catalogSourceHash') <> 'string'
      or source_revision->>'catalogSourceHash' is null or source_revision->>'catalogSourceHash' !~ '^[a-f0-9]{64}$'
      or not premium_translation_private.valid_country_fields(snapshot,false)
      or not premium_translation_private.exact_object(payload,array['fields'])
      or not premium_translation_private.valid_country_fields(payload->'fields',true) then
      raise exception using errcode='22023', message='Invalid country candidate shape';
    end if;
    foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology'] loop
      if jsonb_array_length(snapshot->key) <> jsonb_array_length(payload->'fields'->key) then
        raise exception using errcode='22023', message='Country candidate changed item count';
      end if;
      if key in ('timeline','chronology') then
        for idx in 0..jsonb_array_length(snapshot->key)-1 loop
          if snapshot->key->idx->'year' is distinct from payload->'fields'->key->idx->'year' then
            raise exception using errcode='22023', message='Country candidate changed year';
          end if;
        end loop;
      end if;
    end loop;
  end if;
end;
$$;

create or replace function premium_translation_private.assert_current(kind text, identity text, snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql security invoker set search_path = '' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype;
  en public.literary_work_translations%rowtype; title_source public.literary_work_sources%rowtype;
  country public.country_profile_overrides%rowtype; current_source jsonb; urls jsonb;
begin
  if kind='writer_biography' then
    perform premium_translation_private.assert_writer_current(identity,snapshot,source_revision,target_revision);
    return;
  end if;
  if kind = 'literary_work' then
    select * into work from public.literary_works where id=identity::uuid for update;
    if not found or work.editorial_status not in ('reviewed','verified')
      or source_revision->>'workId' is distinct from identity
      or work.updated_at is distinct from (source_revision->>'workUpdatedAt')::timestamptz then
      raise exception using errcode='40001',message='Book source changed';
    end if;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru' for update;
    if not found or ru.id is distinct from (source_revision->>'russianId')::uuid
      or ru.updated_at is distinct from (source_revision->>'russianUpdatedAt')::timestamptz
      or ru.editorial_status not in ('reviewed','verified') or cardinality(ru.source_urls)=0 then
      raise exception using errcode='40001',message='Russian source changed';
    end if;
    select * into en from public.literary_work_translations where work_id=work.id and locale='en' for update;
    if not found or en.id is distinct from (target_revision->>'id')::uuid
      or en.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
      or en.translation_method <> 'machine-translation'
      or btrim(en.title)='' or exists(select 1 from unnest(string_to_array(en.title,null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,value}' is distinct from btrim(en.title)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,sourceUrl}' is distinct from snapshot->>'verifiedEnglishTitleSourceUrl'
      or not coalesce(snapshot->>'verifiedEnglishTitleSourceUrl'=any(en.source_urls),false) then
      raise exception using errcode='40001',message='English target or title ownership changed';
    end if;
    select * into title_source from public.literary_work_sources
      where work_id=work.id and source_url=snapshot->>'verifiedEnglishTitleSourceUrl'
        and provider=payload#>>'{bibliographicTitle,provider}' and 'title'=any(field_names)
      order by id limit 1 for share;
    if not found or jsonb_build_object('value',btrim(en.title),'provider',title_source.provider,
      'sourceUrl',title_source.source_url,'retrievedAt',title_source.retrieved_at) is distinct from payload->'bibliographicTitle' then
      raise exception using errcode='40001',message='Bibliographic title provenance changed';
    end if;
    current_source := jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),
      'verifiedEnglishTitleSourceUrl',title_source.source_url,'description',ru.description,
      'originalTitle',coalesce(work.original_title,''),'firstPublished',work.first_published,
      'originalLanguage',coalesce(work.original_language,''),'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    if current_source is distinct from snapshot then raise exception using errcode='40001',message='Book source snapshot changed'; end if;
    -- Ordered JS Set union used by the existing helper, preserving source rights.
    select coalesce(jsonb_agg(url order by position),'[]'::jsonb) into urls from (
      select url,min(position) position from (
        select url,position from unnest(en.source_urls) with ordinality as english(url,position) where url ~ '^https://'
        union all select url,position+cardinality(en.source_urls) from unnest(ru.source_urls) with ordinality as russian(url,position)
      ) combined group by url
    ) unique_urls;
    if urls is distinct from payload->'sourceUrls' then raise exception using errcode='40001',message='Candidate source provenance changed'; end if;
  else
    if jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt') is distinct from target_revision then
      raise exception using errcode='40001',message='Country source and target revisions differ';
    end if;
    select * into country from public.country_profile_overrides where country_id=identity for update;
    if found then
      if country.id is distinct from (target_revision->>'id')::uuid
        or country.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz then
        raise exception using errcode='40001',message='Country override changed';
      end if;
      if country.fields ? 'translations' and jsonb_typeof(country.fields->'translations') <> 'object' then
        raise exception using errcode='40001',message='Country translation ownership is ambiguous';
      end if;
      if country.fields->'translations' ? 'en' and (
        country.fields#>>'{translations,en,locale}' is distinct from 'en'
        or country.fields#>>'{translations,en,method}' is distinct from 'machine-translation') then
        raise exception using errcode='40001',message='Manual country English is protected';
      end if;
    elsif target_revision->>'id' is not null then
      raise exception using errcode='40001',message='Country override disappeared';
    end if;
  end if;
end;
$$;

create or replace function public.promote_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text, p_source_hash text,
  p_catalog_source_hash text, p_catalog_source_fields jsonb, p_confirm_human_review boolean)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; review_time timestamptz;
  canonical_id uuid; canonical_updated_at timestamptz; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; human jsonb; meta jsonb; english jsonb; next_fields jsonb; translations jsonb;
  catalog_translations jsonb; protected_english jsonb; writer public.writer_profile_overrides%rowtype;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_confirm_human_review is distinct from true then raise exception using errcode='22023',message='Explicit human review is required'; end if;
  if (p_entity_type='writer_biography' and jsonb_typeof(p_catalog_source_fields) is distinct from 'object')
    or (p_entity_type='literary_work' and p_catalog_source_fields is not null)
    or (p_entity_type='country' and (jsonb_typeof(p_catalog_source_fields) is distinct from 'object'
      or (p_catalog_source_fields ? 'translations' and jsonb_typeof(p_catalog_source_fields->'translations') is distinct from 'object'))) then
    raise exception using errcode='22023',message='Invalid current catalog shape';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash or candidate.source_hash is distinct from p_source_hash
    or (p_entity_type='writer_biography' and (
      candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash
      or candidate.source_snapshot->'catalogFields' is distinct from p_catalog_source_fields))
    or (p_entity_type='literary_work' and p_catalog_source_hash is not null)
    or (p_entity_type='country' and candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash) then
    raise exception using errcode='40001',message='Candidate or source changed';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,candidate.source_snapshot,
    candidate.source_revision,candidate.target_revision,candidate.payload);
  review_time := clock_timestamp();
  human := jsonb_build_object('status','approved','reviewedBy',actor,'reviewedAt',review_time);
  if p_entity_type='writer_biography' then
    select * into writer from public.writer_profile_overrides
      where country_id=candidate.source_revision->>'countryId' and writer_id=candidate.source_revision->>'writerId';
    next_fields := coalesce(writer.fields,'{}'::jsonb);
    translations := case when next_fields ? 'biographyTranslations' then next_fields->'biographyTranslations'
      else p_catalog_source_fields->'biographyTranslations' end;
    english := case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
    meta := case when jsonb_typeof(english->'translationMeta')='object' then english->'translationMeta' else '{}'::jsonb end;
    meta := meta||jsonb_build_object('provider',candidate.provenance->'provider','model',candidate.provenance->'translatorModel',
      'reviewerModel',candidate.provenance->'reviewerModel','sourceHash',candidate.source_hash,
      'generatedAt',candidate.provenance->'generatedAt','translatorRequestId',candidate.provenance->'translatorRequestId',
      'reviewerRequestId',candidate.provenance->'reviewerRequestId','humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    english := english||jsonb_build_object('locale','en','text',candidate.payload->'text','sourceLanguage','Russian',
      'status','reviewed','method','machine-translation','reviewedAt',to_char(review_time at time zone 'UTC','YYYY-MM-DD'),
      'reviewer',actor::text,'translatedFromLocale','ru','sourceTextRights','project-original',
      'sources',candidate.source_snapshot#>'{russianProfile,sources}','translationMeta',meta);
    next_fields := next_fields||jsonb_build_object('biographyTranslations',translations||jsonb_build_object('en',english));
    if writer.id is null then
      insert into public.writer_profile_overrides(country_id,writer_id,fields,updated_by)
        values(candidate.source_revision->>'countryId',candidate.source_revision->>'writerId',next_fields,actor)
        returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.writer_profile_overrides set fields=next_fields,updated_by=actor
        where id=writer.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  elsif p_entity_type='literary_work' then
    select * into en from public.literary_work_translations where id=(candidate.target_revision->>'id')::uuid;
    meta := case when jsonb_typeof(en.metadata)='object' then en.metadata else '{}'::jsonb end;
    meta := meta || jsonb_build_object('premiumTranslation',
      (case when jsonb_typeof(meta->'premiumTranslation')='object' then meta->'premiumTranslation' else '{}'::jsonb end)
      || jsonb_build_object('sourceHash',candidate.source_hash,'provider',candidate.provenance->'provider',
        'translatorModel',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'generatedAt',candidate.provenance->'generatedAt','bibliographicTitle',candidate.payload->'bibliographicTitle',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time));
    update public.literary_work_translations set description=candidate.payload->>'description',source_language='Russian',
      translation_method='machine-translation',editorial_status='reviewed',reviewed_at=review_time::date,
      source_urls=array(select jsonb_array_elements_text(candidate.payload->'sourceUrls')),metadata=meta
      where id=en.id returning id,updated_at into canonical_id,canonical_updated_at;
  else
    select * into country from public.country_profile_overrides where country_id=p_entity_id;
    next_fields := coalesce(country.fields,'{}'::jsonb);
    catalog_translations := case when jsonb_typeof(p_catalog_source_fields->'translations')='object'
      then p_catalog_source_fields->'translations' else '{}'::jsonb end;
    translations := case when next_fields ? 'translations' then next_fields->'translations' else catalog_translations end;
    if translations ? 'en' then protected_english := translations->'en';
    elsif catalog_translations ? 'en' then protected_english := catalog_translations->'en'; end if;
    if protected_english is not null and (protected_english->>'locale' is distinct from 'en'
      or protected_english->>'method' is distinct from 'machine-translation') then
      raise exception using errcode='40001',message='Manual catalog English is protected';
    end if;
    select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into meta from jsonb_each(candidate.payload->'fields')
      where value <> '""'::jsonb and value <> '[]'::jsonb;
    english := (case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end)
      || jsonb_build_object('locale','en','status','reviewed','method','machine-translation','sourceHash',candidate.source_hash,
        'generatedAt',candidate.provenance->'generatedAt','provider',candidate.provenance->'provider',
        'model',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'fields',meta,'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    next_fields := next_fields || jsonb_build_object('translations',translations || jsonb_build_object('en',english));
    if country.id is null then
      insert into public.country_profile_overrides(country_id,fields,updated_by)
        values(p_entity_id,next_fields,actor) returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.country_profile_overrides set fields=next_fields,updated_by=actor
        where id=country.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.promoted',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
        'sourceHash',candidate.source_hash,'canonicalId',canonical_id,'outcome','promoted'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','promoted',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
    'canonicalId',canonical_id,'canonicalUpdatedAt',canonical_updated_at,'reviewedBy',actor,'reviewedAt',review_time);
exception when unique_violation then raise exception using errcode='40001',message='Canonical target changed concurrently';
end;
$$;

-- New helpers are implementation details. Existing public RPC grants remain
-- unchanged; CREATE OR REPLACE retains them, and no new public endpoint is added.
revoke all on function premium_translation_private.writer_source_projection(jsonb) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_writer_shape(jsonb,jsonb,jsonb,jsonb,jsonb) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_writer_current(text,jsonb,jsonb,jsonb) from public,anon,authenticated;

-- Extend the existing private review protocol to Site Copy. Staging does not
-- write canonical settings or request publication. Existing book/country/writer
-- branches, RPC signatures, table/RPC grants and RLS remain unchanged.
alter table public.premium_translation_working_drafts
  drop constraint premium_translation_working_drafts_entity_type_check,
  add constraint premium_translation_working_drafts_entity_type_check
    check (entity_type in ('literary_work','country','writer_biography','site_copy'));

create or replace function premium_translation_private.assert_identity(kind text, identity text)
returns void language plpgsql immutable set search_path = '' as $$
declare country_identity text; writer_identity text;
begin
  if kind='site_copy' then
    if identity is null or identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' then
      raise exception using errcode='22023',message='Invalid candidate identity';
    end if;
    return;
  end if;
  if kind='writer_biography' then
    country_identity := split_part(identity,':',1);
    writer_identity := split_part(identity,':',2);
    if identity is null or char_length(identity)>301
      or identity is distinct from country_identity||':'||writer_identity
      or char_length(country_identity) not between 2 and 120
      or country_identity !~ '^[a-z0-9][a-z0-9_-]*$'
      or char_length(writer_identity) not between 2 and 180
      or writer_identity ~ '[[:space:][:cntrl:]/:]' then
      raise exception using errcode='22023',message='Invalid candidate identity';
    end if;
    return;
  end if;
  if kind is null or kind not in ('literary_work','country') or identity is null
    or char_length(identity) not between 1 and 120
    or (kind = 'literary_work' and identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') then
    raise exception using errcode = '22023', message = 'Invalid candidate identity';
  end if;
end;
$$;

-- Match JavaScript/Zod maxima without altering source text: astral Unicode
-- characters occupy two UTF-16 code units, all other characters occupy one.
create function premium_translation_private.site_copy_utf16_length(value text)
returns integer language sql immutable strict set search_path='' as $$
  select char_length(value)+(select count(*)::integer
    from unnest(string_to_array(value,null::text)) glyph where ascii(glyph)>65535);
$$;

-- Full raw settings are the canonical binding. Selected item text/hash is the
-- trusted server/provider projection, not a claim that SQL reads the UI catalog.
create function premium_translation_private.assert_site_copy_shape(snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql immutable set search_path='' as $$
declare item jsonb; source_item jsonb; idx integer; keys text[] := array[]::text[]; item_key text;
begin
  if not premium_translation_private.exact_object(source_revision,array['blockId','blockUpdatedAt'])
    or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'blockId','updatedAt',source_revision->'blockUpdatedAt'))
    or source_revision->>'blockId' is null
    or jsonb_build_object('id',source_revision->'blockId','updatedAt',source_revision->'blockUpdatedAt') is distinct from target_revision
    or not premium_translation_private.exact_object(snapshot,array['settings','items'])
    or jsonb_typeof(snapshot->'settings') is distinct from 'object'
    or snapshot#>>'{settings,systemKey}' is distinct from 'site-copy-overrides'
    or jsonb_typeof(snapshot->'items') is distinct from 'array'
    or not premium_translation_private.exact_object(payload,array['items'])
    or jsonb_typeof(payload->'items') is distinct from 'array' then
    raise exception using errcode='22023',message='Invalid Site Copy candidate shape';
  end if;
  if jsonb_array_length(snapshot->'items') not between 1 and 50
    or jsonb_array_length(payload->'items') is distinct from jsonb_array_length(snapshot->'items') then
    raise exception using errcode='22023',message='Invalid Site Copy item count';
  end if;
  for idx in 0..jsonb_array_length(snapshot->'items')-1 loop
    source_item := snapshot->'items'->idx; item := payload->'items'->idx;
    if not premium_translation_private.exact_object(source_item,array['key','text','sourceHash'])
      or not premium_translation_private.exact_object(item,array['key','text'])
      or jsonb_typeof(source_item->'key') is distinct from 'string'
      or jsonb_typeof(source_item->'text') is distinct from 'string'
      or jsonb_typeof(source_item->'sourceHash') is distinct from 'string'
      or source_item->>'sourceHash' !~ '^[a-f0-9]{64}$'
      or jsonb_typeof(item->'key') is distinct from 'string'
      or jsonb_typeof(item->'text') is distinct from 'string'
      or item->'key' is distinct from source_item->'key'
      or premium_translation_private.site_copy_utf16_length(source_item->>'text') not between 1 and 4000
      or char_length(premium_translation_private.trim_text(source_item->>'text'))=0
      or premium_translation_private.site_copy_utf16_length(item->>'text') not between 1 and 4000
      or char_length(premium_translation_private.trim_text(item->>'text'))=0 then
      raise exception using errcode='22023',message='Invalid Site Copy item shape';
    end if;
    item_key := source_item->>'key';
    if premium_translation_private.site_copy_utf16_length(item_key) not between 1 and 1200
      or item_key is distinct from premium_translation_private.trim_text(item_key)
      or item_key ~ '[[:cntrl:]]'
      or item_key ~* '(^|\.)(__proto__|prototype|constructor)(\.|$)'
      or item_key=any(keys)
      or exists(select 1 from unnest(string_to_array(item->>'text',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023) then
      raise exception using errcode='22023',message='Invalid Site Copy key or English text';
    end if;
    keys := array_append(keys,item_key);
  end loop;
end;
$$;

-- Durable private provider output survives a concurrent canonical edit or
-- deletion. Validate the recorded source/ownership here; only promotion reloads
-- and locks the current singleton and enforces its full settings/CAS binding.
create function premium_translation_private.assert_site_copy_recorded(snapshot jsonb)
returns void language plpgsql immutable set search_path='' as $$
declare copy jsonb; premium jsonb; machine jsonb; source_item jsonb; item_key text; marker jsonb;
begin
  copy := snapshot->'settings'->'siteCopy'; premium := snapshot->'settings'->'premiumTranslation';
  if jsonb_typeof(copy) is distinct from 'object'
    or jsonb_typeof(copy->'ru') is distinct from 'object'
    or (copy ? 'en' and copy->'en'<>'null'::jsonb and jsonb_typeof(copy->'en') is distinct from 'object')
    or (premium is not null and premium<>'null'::jsonb and jsonb_typeof(premium) is distinct from 'object') then
    raise exception using errcode='40001',message='Site Copy locale or metadata ownership is ambiguous';
  end if;
  machine := premium->'siteCopyEn';
  if machine is not null and machine<>'null'::jsonb and jsonb_typeof(machine) is distinct from 'object' then
    raise exception using errcode='40001',message='Site Copy machine metadata is malformed';
  end if;
  for source_item in select jsonb_array_elements(snapshot->'items') loop
    item_key := source_item->>'key'; marker := machine->item_key;
    if not (copy->'ru' ? item_key) or jsonb_typeof(copy->'ru'->item_key) is distinct from 'string'
      or char_length(premium_translation_private.trim_text(copy->'ru'->>item_key))=0 then
      raise exception using errcode='40001',message='Site Copy Russian key changed';
    end if;
    if (machine ? item_key) and jsonb_typeof(marker) is distinct from 'object' then
      raise exception using errcode='40001',message='Site Copy selected machine metadata is malformed';
    end if;
    if copy->'en' ? item_key and (jsonb_typeof(copy->'en'->item_key) is distinct from 'string'
      or jsonb_typeof(marker) is distinct from 'object'
      or jsonb_typeof(marker->'sourceHash') is distinct from 'string'
      or marker->>'sourceHash' !~ '^[a-f0-9]{64}$') then
      raise exception using errcode='40001',message='Manual or ambiguous Site Copy English is protected';
    end if;
  end loop;
end;
$$;

create function premium_translation_private.assert_site_copy_current(identity text,
  snapshot jsonb, source_revision jsonb, target_revision jsonb)
returns void language plpgsql security invoker set search_path='' as $$
declare block public.homepage_blocks%rowtype; singleton_count bigint; copy jsonb;
  premium jsonb; machine jsonb; source_item jsonb; item_key text; marker jsonb;
begin
  if (source_revision->>'blockId')::uuid is distinct from identity::uuid
    or jsonb_build_object('id',source_revision->'blockId','updatedAt',source_revision->'blockUpdatedAt') is distinct from target_revision then
    raise exception using errcode='40001',message='Site Copy source and target identities differ';
  end if;
  -- Same singleton boundary as save_site_copy_block. All candidate writers take
  -- their per-entity lock before this singleton lock and then the canonical row.
  perform pg_advisory_xact_lock(188654771, 2);
  select count(*) into singleton_count from public.homepage_blocks
    where settings @> '{"systemKey":"site-copy-overrides"}'::jsonb;
  if singleton_count<>1 then
    raise exception using errcode='40001',message='Site Copy master is missing or ambiguous';
  end if;
  select * into block from public.homepage_blocks where id=identity::uuid for update;
  if not found or block.settings#>>'{systemKey}' is distinct from 'site-copy-overrides'
    or block.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
    or block.settings is distinct from snapshot->'settings' then
    raise exception using errcode='40001',message='Site Copy settings or revision changed';
  end if;
  perform premium_translation_private.assert_site_copy_recorded(snapshot);
end;
$$;

create or replace function premium_translation_private.assert_shape(kind text, snapshot jsonb, source_revision jsonb,
  target_revision jsonb, payload jsonb, provenance jsonb)
returns void language plpgsql immutable set search_path = '' as $$
declare key text; item jsonb; source_item jsonb; idx integer;
begin
  if not premium_translation_private.valid_revision(target_revision)
    or not premium_translation_private.exact_object(provenance,array['provider','translatorModel','reviewerModel',
      'translatorRequestId','reviewerRequestId','generatedAt']) then
    raise exception using errcode='22023', message='Invalid candidate shape';
  end if;
  if provenance->>'provider' not in ('cloudflare','openai') or jsonb_typeof(provenance->'provider') <> 'string'
    or jsonb_typeof(provenance->'translatorModel') <> 'string' or char_length(provenance->>'translatorModel') not between 1 and 300
    or jsonb_typeof(provenance->'generatedAt') <> 'string' or not premium_translation_private.valid_timestamp(provenance->>'generatedAt') then
    raise exception using errcode='22023', message='Invalid candidate provenance';
  end if;
  foreach key in array array['reviewerModel','translatorRequestId','reviewerRequestId'] loop
    if jsonb_typeof(provenance->key) not in ('string','null') or
      (key='reviewerModel' and jsonb_typeof(provenance->key)='string' and char_length(provenance->>key) not between 1 and 300) then
      raise exception using errcode='22023', message='Invalid candidate provenance';
    end if;
  end loop;
  if kind='site_copy' then
    perform premium_translation_private.assert_site_copy_shape(snapshot,source_revision,target_revision,payload);
    return;
  end if;
  if kind='writer_biography' then
    perform premium_translation_private.assert_writer_shape(snapshot,source_revision,target_revision,payload,provenance);
    return;
  end if;
  if kind = 'literary_work' then
    if not premium_translation_private.exact_object(source_revision,array['workId','workUpdatedAt','russianId','russianUpdatedAt'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'workId','updatedAt',source_revision->'workUpdatedAt'))
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'russianId','updatedAt',source_revision->'russianUpdatedAt'))
      or source_revision->>'workId' is null or source_revision->>'russianId' is null or target_revision->>'id' is null
      or not premium_translation_private.exact_object(snapshot,array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl',
        'description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls'])
      or not premium_translation_private.exact_object(payload,array['description','sourceLanguage','sourceUrls','bibliographicTitle'])
      or not premium_translation_private.exact_object(payload->'bibliographicTitle',array['value','provider','sourceUrl','retrievedAt']) then
      raise exception using errcode='22023', message='Invalid book candidate shape';
    end if;
    foreach key in array array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','originalLanguage','sourceLanguage'] loop
      if jsonb_typeof(snapshot->key) <> 'string' then raise exception using errcode='22023', message='Invalid book source shape'; end if;
    end loop;
    if jsonb_typeof(snapshot->'firstPublished') not in ('number','null')
      or not premium_translation_private.string_array(snapshot->'sourceUrls',10000,100000)
      or jsonb_typeof(payload->'description') <> 'string' or char_length(payload->>'description') not between 140 and 900
      or char_length(premium_translation_private.trim_text(payload->>'description')) not between 140 and 900
      or exists(select 1 from unnest(string_to_array(payload->>'description',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or (select count(*) from regexp_matches(payload->>'description','[.!?:]+(?=\s|$)','g')) not between 2 and 3
      or payload->>'sourceLanguage' is distinct from 'Russian'
      or not premium_translation_private.string_array(payload->'sourceUrls',10000,100000) then
      raise exception using errcode='22023', message='Invalid book candidate content';
    end if;
    foreach key in array array['value','provider','sourceUrl'] loop
      if jsonb_typeof(payload->'bibliographicTitle'->key) <> 'string' or char_length(payload->'bibliographicTitle'->>key)=0 then
        raise exception using errcode='22023', message='Invalid title provenance';
      end if;
    end loop;
    if jsonb_typeof(payload#>'{bibliographicTitle,retrievedAt}') not in ('string','null') then
      raise exception using errcode='22023', message='Invalid title provenance';
    end if;
    for item in select jsonb_array_elements(payload->'sourceUrls') loop
      if item #>> '{}' !~ '^https://' then raise exception using errcode='22023', message='Invalid candidate source URL'; end if;
    end loop;
  else
    if not premium_translation_private.exact_object(source_revision,array['overrideId','overrideUpdatedAt','catalogSourceHash'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt'))
      or jsonb_typeof(source_revision->'catalogSourceHash') <> 'string'
      or source_revision->>'catalogSourceHash' is null or source_revision->>'catalogSourceHash' !~ '^[a-f0-9]{64}$'
      or not premium_translation_private.valid_country_fields(snapshot,false)
      or not premium_translation_private.exact_object(payload,array['fields'])
      or not premium_translation_private.valid_country_fields(payload->'fields',true) then
      raise exception using errcode='22023', message='Invalid country candidate shape';
    end if;
    foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology'] loop
      if jsonb_array_length(snapshot->key) <> jsonb_array_length(payload->'fields'->key) then
        raise exception using errcode='22023', message='Country candidate changed item count';
      end if;
      if key in ('timeline','chronology') then
        for idx in 0..jsonb_array_length(snapshot->key)-1 loop
          if snapshot->key->idx->'year' is distinct from payload->'fields'->key->idx->'year' then
            raise exception using errcode='22023', message='Country candidate changed year';
          end if;
        end loop;
      end if;
    end loop;
  end if;
end;
$$;

create or replace function premium_translation_private.assert_current(kind text, identity text, snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql security invoker set search_path = '' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype;
  en public.literary_work_translations%rowtype; title_source public.literary_work_sources%rowtype;
  country public.country_profile_overrides%rowtype; current_source jsonb; urls jsonb;
begin
  if kind='site_copy' then
    perform premium_translation_private.assert_site_copy_current(identity,snapshot,source_revision,target_revision);
    return;
  end if;
  if kind='writer_biography' then
    perform premium_translation_private.assert_writer_current(identity,snapshot,source_revision,target_revision);
    return;
  end if;
  if kind = 'literary_work' then
    select * into work from public.literary_works where id=identity::uuid for update;
    if not found or work.editorial_status not in ('reviewed','verified')
      or source_revision->>'workId' is distinct from identity
      or work.updated_at is distinct from (source_revision->>'workUpdatedAt')::timestamptz then
      raise exception using errcode='40001',message='Book source changed';
    end if;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru' for update;
    if not found or ru.id is distinct from (source_revision->>'russianId')::uuid
      or ru.updated_at is distinct from (source_revision->>'russianUpdatedAt')::timestamptz
      or ru.editorial_status not in ('reviewed','verified') or cardinality(ru.source_urls)=0 then
      raise exception using errcode='40001',message='Russian source changed';
    end if;
    select * into en from public.literary_work_translations where work_id=work.id and locale='en' for update;
    if not found or en.id is distinct from (target_revision->>'id')::uuid
      or en.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
      or en.translation_method <> 'machine-translation'
      or btrim(en.title)='' or exists(select 1 from unnest(string_to_array(en.title,null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,value}' is distinct from btrim(en.title)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,sourceUrl}' is distinct from snapshot->>'verifiedEnglishTitleSourceUrl'
      or not coalesce(snapshot->>'verifiedEnglishTitleSourceUrl'=any(en.source_urls),false) then
      raise exception using errcode='40001',message='English target or title ownership changed';
    end if;
    select * into title_source from public.literary_work_sources
      where work_id=work.id and source_url=snapshot->>'verifiedEnglishTitleSourceUrl'
        and provider=payload#>>'{bibliographicTitle,provider}' and 'title'=any(field_names)
      order by id limit 1 for share;
    if not found or jsonb_build_object('value',btrim(en.title),'provider',title_source.provider,
      'sourceUrl',title_source.source_url,'retrievedAt',title_source.retrieved_at) is distinct from payload->'bibliographicTitle' then
      raise exception using errcode='40001',message='Bibliographic title provenance changed';
    end if;
    current_source := jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),
      'verifiedEnglishTitleSourceUrl',title_source.source_url,'description',ru.description,
      'originalTitle',coalesce(work.original_title,''),'firstPublished',work.first_published,
      'originalLanguage',coalesce(work.original_language,''),'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    if current_source is distinct from snapshot then raise exception using errcode='40001',message='Book source snapshot changed'; end if;
    -- Ordered JS Set union used by the existing helper, preserving source rights.
    select coalesce(jsonb_agg(url order by position),'[]'::jsonb) into urls from (
      select url,min(position) position from (
        select url,position from unnest(en.source_urls) with ordinality as english(url,position) where url ~ '^https://'
        union all select url,position+cardinality(en.source_urls) from unnest(ru.source_urls) with ordinality as russian(url,position)
      ) combined group by url
    ) unique_urls;
    if urls is distinct from payload->'sourceUrls' then raise exception using errcode='40001',message='Candidate source provenance changed'; end if;
  else
    if jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt') is distinct from target_revision then
      raise exception using errcode='40001',message='Country source and target revisions differ';
    end if;
    select * into country from public.country_profile_overrides where country_id=identity for update;
    if found then
      if country.id is distinct from (target_revision->>'id')::uuid
        or country.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz then
        raise exception using errcode='40001',message='Country override changed';
      end if;
      if country.fields ? 'translations' and jsonb_typeof(country.fields->'translations') <> 'object' then
        raise exception using errcode='40001',message='Country translation ownership is ambiguous';
      end if;
      if country.fields->'translations' ? 'en' and (
        country.fields#>>'{translations,en,locale}' is distinct from 'en'
        or country.fields#>>'{translations,en,method}' is distinct from 'machine-translation') then
        raise exception using errcode='40001',message='Manual country English is protected';
      end if;
    elsif target_revision->>'id' is not null then
      raise exception using errcode='40001',message='Country override disappeared';
    end if;
  end if;
end;
$$;

create or replace function public.stage_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_source_hash text, p_source_snapshot jsonb, p_source_revision jsonb, p_target_revision jsonb,
  p_payload jsonb, p_provenance jsonb, p_expected_draft_id uuid, p_expected_draft_version bigint)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; digest text;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_expected_draft_id is not null or p_expected_draft_version is distinct from 0
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$' then
    raise exception using errcode='22023',message='Invalid initial candidate request';
  end if;
  perform premium_translation_private.assert_shape(p_entity_type,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance);
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  if exists(select 1 from public.premium_translation_working_drafts where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en') then
    raise exception using errcode='40001',message='Pending candidate must be explicitly discarded';
  end if;
  if p_entity_type='site_copy' then
    if p_source_revision->>'blockId' is distinct from p_entity_id or p_target_revision->>'id' is distinct from p_entity_id then
      raise exception using errcode='22023',message='Site Copy recorded identity differs';
    end if;
    perform premium_translation_private.assert_site_copy_recorded(p_source_snapshot);
  else
    perform premium_translation_private.assert_current(p_entity_type,p_entity_id,p_source_snapshot,p_source_revision,p_target_revision,p_payload);
  end if;
  digest := encode(sha256(convert_to(jsonb_build_object('entityType',p_entity_type,'entityId',p_entity_id,'targetLocale','en',
    'sourceHash',p_source_hash,'sourceSnapshot',p_source_snapshot,'sourceRevision',p_source_revision,
    'targetRevision',p_target_revision,'payload',p_payload,'provenance',p_provenance)::text,'UTF8')),'hex');
  insert into public.premium_translation_working_drafts(entity_type,entity_id,source_hash,candidate_hash,source_snapshot,
    source_revision,target_revision,payload,provenance,created_by)
    values(p_entity_type,p_entity_id,p_source_hash,digest,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance,actor)
    returning * into candidate;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.staged',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',digest,'sourceHash',p_source_hash,'outcome','pending'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'draft',premium_translation_private.dto(candidate));
exception when unique_violation then raise exception using errcode='40001',message='Candidate changed concurrently';
end;
$$;

create or replace function public.promote_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text, p_source_hash text,
  p_catalog_source_hash text, p_catalog_source_fields jsonb, p_confirm_human_review boolean)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; review_time timestamptz;
  canonical_id uuid; canonical_updated_at timestamptz; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; human jsonb; meta jsonb; english jsonb; next_fields jsonb; translations jsonb;
  catalog_translations jsonb; protected_english jsonb; writer public.writer_profile_overrides%rowtype;
  block public.homepage_blocks%rowtype; item jsonb; source_item jsonb; item_key text; machine jsonb; item_meta jsonb; idx integer;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_confirm_human_review is distinct from true then raise exception using errcode='22023',message='Explicit human review is required'; end if;
  if (p_entity_type='writer_biography' and jsonb_typeof(p_catalog_source_fields) is distinct from 'object')
    or (p_entity_type in ('literary_work','site_copy') and p_catalog_source_fields is not null)
    or (p_entity_type='country' and (jsonb_typeof(p_catalog_source_fields) is distinct from 'object'
      or (p_catalog_source_fields ? 'translations' and jsonb_typeof(p_catalog_source_fields->'translations') is distinct from 'object'))) then
    raise exception using errcode='22023',message='Invalid current catalog shape';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash or candidate.source_hash is distinct from p_source_hash
    or (p_entity_type='writer_biography' and (
      candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash
      or candidate.source_snapshot->'catalogFields' is distinct from p_catalog_source_fields))
    or (p_entity_type in ('literary_work','site_copy') and p_catalog_source_hash is not null)
    or (p_entity_type='country' and candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash) then
    raise exception using errcode='40001',message='Candidate or source changed';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,candidate.source_snapshot,
    candidate.source_revision,candidate.target_revision,candidate.payload);
  review_time := clock_timestamp();
  human := jsonb_build_object('status','approved','reviewedBy',actor,'reviewedAt',review_time);
  if p_entity_type='site_copy' then
    select * into block from public.homepage_blocks where id=p_entity_id::uuid;
    translations := block.settings->'siteCopy';
    english := case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
    meta := case when jsonb_typeof(block.settings->'premiumTranslation')='object' then block.settings->'premiumTranslation' else '{}'::jsonb end;
    machine := case when jsonb_typeof(meta->'siteCopyEn')='object' then meta->'siteCopyEn' else '{}'::jsonb end;
    for idx in 0..jsonb_array_length(candidate.payload->'items')-1 loop
      item := candidate.payload->'items'->idx; source_item := candidate.source_snapshot->'items'->idx; item_key := item->>'key';
      item_meta := coalesce(machine->item_key,'{}'::jsonb)||jsonb_build_object('sourceHash',source_item->'sourceHash',
        'provider',candidate.provenance->'provider','model',candidate.provenance->'translatorModel',
        'reviewerModel',candidate.provenance->'reviewerModel','generatedAt',candidate.provenance->'generatedAt',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
      machine := machine||jsonb_build_object(item_key,item_meta);
      english := english||jsonb_build_object(item_key,item->'text');
    end loop;
    next_fields := block.settings||jsonb_build_object('siteCopy',translations||jsonb_build_object('en',english),
      'premiumTranslation',meta||jsonb_build_object('siteCopyEn',machine));
    update public.homepage_blocks set settings=next_fields,updated_by=actor where id=block.id
      returning id,updated_at into canonical_id,canonical_updated_at;
  elsif p_entity_type='writer_biography' then
    select * into writer from public.writer_profile_overrides
      where country_id=candidate.source_revision->>'countryId' and writer_id=candidate.source_revision->>'writerId';
    next_fields := coalesce(writer.fields,'{}'::jsonb);
    translations := case when next_fields ? 'biographyTranslations' then next_fields->'biographyTranslations'
      else p_catalog_source_fields->'biographyTranslations' end;
    english := case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
    meta := case when jsonb_typeof(english->'translationMeta')='object' then english->'translationMeta' else '{}'::jsonb end;
    meta := meta||jsonb_build_object('provider',candidate.provenance->'provider','model',candidate.provenance->'translatorModel',
      'reviewerModel',candidate.provenance->'reviewerModel','sourceHash',candidate.source_hash,
      'generatedAt',candidate.provenance->'generatedAt','translatorRequestId',candidate.provenance->'translatorRequestId',
      'reviewerRequestId',candidate.provenance->'reviewerRequestId','humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    english := english||jsonb_build_object('locale','en','text',candidate.payload->'text','sourceLanguage','Russian',
      'status','reviewed','method','machine-translation','reviewedAt',to_char(review_time at time zone 'UTC','YYYY-MM-DD'),
      'reviewer',actor::text,'translatedFromLocale','ru','sourceTextRights','project-original',
      'sources',candidate.source_snapshot#>'{russianProfile,sources}','translationMeta',meta);
    next_fields := next_fields||jsonb_build_object('biographyTranslations',translations||jsonb_build_object('en',english));
    if writer.id is null then
      insert into public.writer_profile_overrides(country_id,writer_id,fields,updated_by)
        values(candidate.source_revision->>'countryId',candidate.source_revision->>'writerId',next_fields,actor)
        returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.writer_profile_overrides set fields=next_fields,updated_by=actor
        where id=writer.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  elsif p_entity_type='literary_work' then
    select * into en from public.literary_work_translations where id=(candidate.target_revision->>'id')::uuid;
    meta := case when jsonb_typeof(en.metadata)='object' then en.metadata else '{}'::jsonb end;
    meta := meta || jsonb_build_object('premiumTranslation',
      (case when jsonb_typeof(meta->'premiumTranslation')='object' then meta->'premiumTranslation' else '{}'::jsonb end)
      || jsonb_build_object('sourceHash',candidate.source_hash,'provider',candidate.provenance->'provider',
        'translatorModel',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'generatedAt',candidate.provenance->'generatedAt','bibliographicTitle',candidate.payload->'bibliographicTitle',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time));
    update public.literary_work_translations set description=candidate.payload->>'description',source_language='Russian',
      translation_method='machine-translation',editorial_status='reviewed',reviewed_at=review_time::date,
      source_urls=array(select jsonb_array_elements_text(candidate.payload->'sourceUrls')),metadata=meta
      where id=en.id returning id,updated_at into canonical_id,canonical_updated_at;
  else
    select * into country from public.country_profile_overrides where country_id=p_entity_id;
    next_fields := coalesce(country.fields,'{}'::jsonb);
    catalog_translations := case when jsonb_typeof(p_catalog_source_fields->'translations')='object'
      then p_catalog_source_fields->'translations' else '{}'::jsonb end;
    translations := case when next_fields ? 'translations' then next_fields->'translations' else catalog_translations end;
    if translations ? 'en' then protected_english := translations->'en';
    elsif catalog_translations ? 'en' then protected_english := catalog_translations->'en'; end if;
    if protected_english is not null and (protected_english->>'locale' is distinct from 'en'
      or protected_english->>'method' is distinct from 'machine-translation') then
      raise exception using errcode='40001',message='Manual catalog English is protected';
    end if;
    select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into meta from jsonb_each(candidate.payload->'fields')
      where value <> '""'::jsonb and value <> '[]'::jsonb;
    english := (case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end)
      || jsonb_build_object('locale','en','status','reviewed','method','machine-translation','sourceHash',candidate.source_hash,
        'generatedAt',candidate.provenance->'generatedAt','provider',candidate.provenance->'provider',
        'model',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'fields',meta,'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    next_fields := next_fields || jsonb_build_object('translations',translations || jsonb_build_object('en',english));
    if country.id is null then
      insert into public.country_profile_overrides(country_id,fields,updated_by)
        values(p_entity_id,next_fields,actor) returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.country_profile_overrides set fields=next_fields,updated_by=actor
        where id=country.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.promoted',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
        'sourceHash',candidate.source_hash,'canonicalId',canonical_id,'outcome','promoted'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','promoted',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
    'canonicalId',canonical_id,'canonicalUpdatedAt',canonical_updated_at,'reviewedBy',actor,'reviewedAt',review_time);
exception when unique_violation then raise exception using errcode='40001',message='Canonical target changed concurrently';
end;
$$;

-- Read-only recovery discovery includes candidates whose canonical master was
-- deleted. Keyset paging exposes only identities, never private source/payload.
create function public.list_site_copy_premium_translation_working_drafts(
  p_after_id uuid default null, p_limit integer default 10)
returns jsonb language plpgsql security definer set search_path='' as $$
declare identities jsonb; last_id uuid; has_more boolean;
begin
  perform premium_translation_private.assert_actor();
  if p_limit is null or p_limit not between 1 and 10 then
    raise exception using errcode='22023',message='Invalid Site Copy candidate page size';
  end if;
  with requested as (
    select id,entity_id from public.premium_translation_working_drafts
    where entity_type='site_copy' and (p_after_id is null or id>p_after_id)
    order by id limit p_limit+1
  ), visible as (
    select id,entity_id from requested order by id limit p_limit
  )
  select coalesce(jsonb_agg(entity_id order by id),'[]'::jsonb),
    (select id from visible order by id desc limit 1),
    (select count(*)>p_limit from requested)
    into identities,last_id,has_more from visible;
  return jsonb_build_object('schemaVersion',1,'entityIds',identities,
    'nextCursor',case when has_more then last_id else null end);
end;
$$;
revoke all on function public.list_site_copy_premium_translation_working_drafts(uuid,integer) from public,anon,authenticated;
grant execute on function public.list_site_copy_premium_translation_working_drafts(uuid,integer) to authenticated;


revoke all on function premium_translation_private.site_copy_utf16_length(text) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_site_copy_shape(jsonb,jsonb,jsonb,jsonb) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_site_copy_recorded(jsonb) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_site_copy_current(text,jsonb,jsonb,jsonb) from public,anon,authenticated;

-- Isolated native PG contract. The builder prepends unchanged canonical SQL and
-- the actual new migration. Auth/staff and public-build capture are local only.
create function public.premium_fixture_assert(ok boolean, label text)
returns void language plpgsql as $$ begin
  if ok is distinct from true then raise exception 'PREMIUM ASSERT: %',label; end if;
end; $$;
create function public.premium_fixture_error(statement text, expected text)
returns void language plpgsql as $$ declare seen text; begin
  begin execute statement; exception when others then get stacked diagnostics seen=returned_sqlstate; end;
  if seen is distinct from expected then raise exception 'Expected SQLSTATE %, got %',expected,coalesce(seen,'success'); end if;
end; $$;

create table public.premium_fixture_outbox(kind text, identity text);
create function public.premium_fixture_capture() returns trigger language plpgsql security definer as $$
begin insert into public.premium_fixture_outbox values(tg_table_name,new.id::text); return new; end; $$;
create trigger premium_fixture_book_outbox after update on public.literary_work_translations
  for each row execute function public.premium_fixture_capture();
create trigger premium_fixture_country_outbox after insert or update on public.country_profile_overrides
  for each row execute function public.premium_fixture_capture();

insert into auth.users(id) values('11111111-1111-4111-8111-111111111111'),('22222222-2222-4222-8222-222222222222'),('33333333-3333-4333-8333-333333333333');
insert into public.staff_memberships(user_id,role) values('11111111-1111-4111-8111-111111111111','editor'),('22222222-2222-4222-8222-222222222222','admin');
insert into public.literary_works(id,legacy_id,country_id,writer_id,title,slug,original_title,first_published,original_language,editorial_status,metadata,updated_at)
values('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','premium-fixture-work','fixture-country','fixture-author','Исходное название','premium-fixture-work','Original identity',1920,'Russian','reviewed',
 '{"authorPreserve":{"id":"authored"},"rights":{"owner":"author"}}','2026-10-08T10:00:00.123456Z');
insert into public.literary_work_sources(work_id,provider,source_url,field_names,usage,retrieved_at,metadata)
values('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','verified-bibliography','https://fixture.test/title',array['title'],'reference-only','2026-10-08','{"rights":"title-only"}'),
 ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','editorial-source','https://fixture.test/ru',array['description'],'reference-only','2026-10-08','{"rights":"reference"}');
insert into public.literary_work_translations(id,work_id,locale,title,description,source_language,translation_method,editorial_status,source_urls,reviewed_at,metadata,updated_at)
values('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','ru','Исходное название',
 'Русский литературный текст описывает вымышленное произведение и его литературное значение для проверки сохранности редакторских данных. Второе предложение сохраняет исходное авторское содержание и подтверждённые сведения.',
 'Russian','editorial-original','reviewed',array['https://fixture.test/ru'],'2026-10-08','{"authored":"RU immutable"}','2026-10-08T10:00:00.123457Z'),
 ('cccccccc-cccc-4ccc-8ccc-cccccccccccc','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','en','Exact Verified English Title',
 'This previously admitted English description remains available to public readers while a separate candidate awaits a human decision. Its second sentence preserves the existing reviewed editorial account and all bibliographic identifiers.',
 'Russian','machine-translation','reviewed',array['https://fixture.test/title','https://fixture.test/ru'],'2026-10-07',
 '{"authored":{"owner":"editor"},"rights":{"license":"unchanged"},"premiumTranslation":{"custom":"retained","bibliographicTitle":{"value":"Exact Verified English Title","sourceUrl":"https://fixture.test/title"}}}',
 '2026-10-08T10:00:00.123458Z');
grant select on public.literary_works,public.literary_work_translations,public.literary_work_sources to anon,authenticated;
alter table public.country_profile_overrides enable row level security;
create policy premium_fixture_country_public on public.country_profile_overrides for select to anon,authenticated using(is_enabled);
grant select on public.country_profile_overrides to anon,authenticated;

create table public.premium_fixture_saved(name text primary key, value jsonb not null);
create function public.premium_fixture_args(kind text, identity text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; source jsonb; source_revision jsonb; target_revision jsonb; payload jsonb;
begin
  if kind='literary_work' then
    select * into work from public.literary_works where id=identity::uuid;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru';
    select * into en from public.literary_work_translations where work_id=work.id and locale='en';
    source:=jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),'verifiedEnglishTitleSourceUrl','https://fixture.test/title',
      'description',ru.description,'originalTitle',work.original_title,'firstPublished',work.first_published,'originalLanguage',work.original_language,
      'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    source_revision:=jsonb_build_object('workId',work.id,'workUpdatedAt',work.updated_at,'russianId',ru.id,'russianUpdatedAt',ru.updated_at);
    target_revision:=jsonb_build_object('id',en.id,'updatedAt',en.updated_at);
    payload:=jsonb_build_object('description',
      'This structurally valid candidate incorrectly states that the fictional book was written on the Moon by a committee of astronomers. A human editor must check the facts and sources before this deliberately wrong account can replace the reviewed text.',
      'sourceLanguage','Russian','sourceUrls',jsonb_build_array('https://fixture.test/title','https://fixture.test/ru'),
      'bibliographicTitle',jsonb_build_object('value',en.title,'provider','verified-bibliography','sourceUrl','https://fixture.test/title','retrievedAt','2026-10-08'));
  else
    select * into country from public.country_profile_overrides where country_id=identity;
    source:=jsonb_build_object('name','Страна','region','Регион','continent','Континент','officialLanguage','Язык','capital','Столица',
      'description','Редакторский текст страны','history','','historicalNote','','literaryPeriods',jsonb_build_array('Период'),
      'literaryMovements','[]'::jsonb,'periods','[]'::jsonb,'facts',jsonb_build_array('Факт'),'literaryPlaces','[]'::jsonb,
      'timeline',jsonb_build_array(jsonb_build_object('year','1900','title','Событие','description','Описание')),'chronology','[]'::jsonb);
    source_revision:=jsonb_build_object('overrideId',country.id,'overrideUpdatedAt',country.updated_at,'catalogSourceHash',repeat('b',64));
    target_revision:=jsonb_build_object('id',country.id,'updatedAt',country.updated_at);
    payload:=jsonb_build_object('fields',jsonb_build_object('name','Country','region','Region','continent','Continent','officialLanguage','Language','capital','Capital',
      'description','A separate English candidate.','history','','historicalNote','','literaryPeriods',jsonb_build_array('Period'),
      'literaryMovements','[]'::jsonb,'periods','[]'::jsonb,'facts',jsonb_build_array('Fact'),'literaryPlaces','[]'::jsonb,
      'timeline',jsonb_build_array(jsonb_build_object('year','1900','title','Event','description','Description')),'chronology','[]'::jsonb));
  end if;
  return jsonb_build_object('kind',kind,'identity',identity,'sourceHash',repeat('a',64),'source',source,'sourceRevision',source_revision,
    'targetRevision',target_revision,'payload',payload,'provenance',jsonb_build_object('provider','cloudflare','translatorModel','fixture-translator',
      'reviewerModel','fixture-reviewer','translatorRequestId','req-1','reviewerRequestId',null,'generatedAt','2026-10-08T10:10:00.123456Z'));
end; $$;
create function public.premium_fixture_stage(args jsonb)
returns jsonb language sql security invoker as $$
 select public.stage_premium_translation_working_draft(args->>'kind',args->>'identity',args->>'sourceHash',args->'source',args->'sourceRevision',
   args->'targetRevision',args->'payload',args->'provenance',null,0);
$$;
create function public.premium_fixture_promote(draft jsonb, catalog jsonb default null, confirm boolean default true)
returns jsonb language sql security invoker as $$
 select public.promote_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash',draft->>'sourceHash',
   case when draft->>'entityType'='country' then draft#>>'{sourceRevision,catalogSourceHash}' else null end,catalog,confirm);
$$;
create function public.premium_fixture_discard(draft jsonb)
returns jsonb language sql security invoker as $$
 select public.discard_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash');
$$;
grant select,insert,update,delete on public.premium_fixture_saved to authenticated;

-- Actual role ACL, including no actor and nonstaff actor, applies to every RPC.
do $$ declare fn regprocedure; begin
 perform public.premium_fixture_assert((select relrowsecurity and relforcerowsecurity from pg_class where oid='public.premium_translation_working_drafts'::regclass),'private force RLS');
 perform public.premium_fixture_assert(not exists(select 1 from pg_trigger where tgrelid='public.premium_translation_working_drafts'::regclass and not tgisinternal),'no private triggers');
 perform public.premium_fixture_assert(not has_schema_privilege('authenticated','premium_translation_private','USAGE'),'private helper schema');
 for fn in select oid::regprocedure from pg_proc where proname in ('get_premium_translation_working_draft','stage_premium_translation_working_draft','promote_premium_translation_working_draft','discard_premium_translation_working_draft') loop
   perform public.premium_fixture_assert(not has_function_privilege('anon',fn,'EXECUTE') and has_function_privilege('authenticated',fn,'EXECUTE'),'RPC grants');
 end loop;
 set local role anon;
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country','fixture-country')$q$,'42501');
 reset role;
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','','true');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country','fixture-country')$q$,'42501');
 perform set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country','fixture-country')$q$,'42501');
 perform public.premium_fixture_error($q$select public.stage_premium_translation_working_draft('country','fixture-country',null,null,null,null,null,null,null,0)$q$,'42501');
 perform public.premium_fixture_error($q$select public.promote_premium_translation_working_draft('country','fixture-country',null,1,null,null,null,null,true)$q$,'42501');
 perform public.premium_fixture_error($q$select public.discard_premium_translation_working_draft('country','fixture-country',null,1,null)$q$,'42501');
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error('insert into public.premium_translation_working_drafts(entity_id) values(''forbidden'')','42501');
 perform public.premium_fixture_error('update public.premium_translation_working_drafts set version=2','42501');
 perform public.premium_fixture_error('delete from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('country','fixture-country')=
   '{"schemaVersion":1,"entityType":"country","entityId":"fixture-country","draft":null}'::jsonb,'explicit absent envelope');
end; $$;
select 'M07_T05_NATIVE_ACL_ACTOR_PASS';

-- Server refuses malformed JSON, forged snapshots and changed bibliography.
do $$ declare a jsonb; bad jsonb; begin
 a:=public.premium_fixture_args('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 for bad in select value from jsonb_array_elements(jsonb_build_array(
   jsonb_set(a,'{payload,extra}','true'),jsonb_set(a,'{source,extra}','true'),jsonb_set(a,'{sourceRevision,extra}','true'),
   jsonb_set(a,'{targetRevision,updatedAt}','null'),jsonb_set(a,'{provenance,reviewedBy}','"forged"'),
   jsonb_set(a,'{provenance,provider}','null'),jsonb_set(a,'{provenance,generatedAt}','"2026-10-08"'),
   jsonb_set(a,'{payload,description}','"Too short."'),jsonb_set(a,'{payload,sourceUrls}','[1]'),
   jsonb_set(a,'{payload,description}',to_jsonb(rpad('A. B.',140,' '))),
   jsonb_set(a,'{payload,description}',to_jsonb(rpad('A. B.',140,chr(160)))),
   jsonb_set(a,'{sourceRevision,workUpdatedAt}','"2026-10-08T10:00:00"')
 )) loop perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023'); end loop;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',jsonb_set(a,'{source,russianTitle}','"forged"')),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',jsonb_set(a,'{payload,bibliographicTitle,provider}','"forged"')),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',jsonb_set(a,'{payload,sourceUrls}','["https://fixture.test/title"]')),'40001');
 a:=public.premium_fixture_args('country','fixture-country');
 for bad in select value from jsonb_array_elements(jsonb_build_array(
   jsonb_set(a,'{payload,fields,extra}','true'),jsonb_set(a,'{payload,fields,facts}','[]'),
   jsonb_set(a,'{payload,fields,timeline,0,year}','"1901"'),jsonb_set(a,'{payload,fields,name}','"Страна"'),
   jsonb_set(a,'{payload,fields,name}',to_jsonb(E' \t\r\n'||chr(160)||chr(65279))),
   jsonb_set(a,'{payload,fields,timeline,0,extra}','true'),jsonb_set(a,'{sourceRevision,catalogSourceHash}','"bad"')
 )) loop perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023'); end loop;
end; $$;
select 'M07_T05_NATIVE_SHAPE_SOURCE_PASS';

do $$ declare a jsonb; bad jsonb; kind text; key text; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach kind in array array['literary_work','country'] loop
   a:=public.premium_fixture_args(kind,case when kind='country' then 'null-shape' else 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa' end);
   foreach key in array array['source','sourceRevision','targetRevision','payload','provenance'] loop
     bad:=jsonb_set(a,array[key],'null'::jsonb);
     perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
     bad:=a-key;
     perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
   end loop;
 end loop;
end; $$;
select 'M07_T05_NATIVE_NULL_BOUNDARY_PASS';

insert into public.premium_fixture_saved values('before-work',(select to_jsonb(w) from public.literary_works w)),
 ('before-ru',(select to_jsonb(t) from public.literary_work_translations t where locale='ru')),
 ('before-en',(select to_jsonb(t) from public.literary_work_translations t where locale='en')),
 ('before-sources',(select jsonb_agg(to_jsonb(s) order by id) from public.literary_work_sources s));
truncate public.premium_fixture_outbox;
do $$ declare a jsonb; d jsonb; actual_hash text; begin
 a:=public.premium_fixture_args('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(a)->'draft';
 insert into public.premium_fixture_saved values('book-pending',d),('book-args',a);
 perform public.premium_fixture_assert(d->>'humanReview'='pending' and d->>'createdBy'='11111111-1111-4111-8111-111111111111','server actor pending');
 perform public.premium_fixture_assert(d->'sourceRevision'=a->'sourceRevision' and d->'targetRevision'=a->'targetRevision' and d->'payload'=a->'payload'
   and d->'provenance'=a->'provenance' and d->'sourceSnapshot'=a->'source','exact ACK full precision');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa')->'draft'=d,'exact saved read');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,null,false)',d),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,null,null)',d),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',jsonb_set(d,'{candidateHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',jsonb_set(d,'{sourceHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{version}','2')),'40001');
 reset role;
 select encode(sha256(convert_to(jsonb_build_object('entityType',d->'entityType','entityId',d->'entityId','targetLocale','en',
   'sourceHash',d->'sourceHash','sourceSnapshot',d->'sourceSnapshot','sourceRevision',d->'sourceRevision','targetRevision',d->'targetRevision',
   'payload',d->'payload','provenance',d->'provenance')::text,'UTF8')),'hex') into actual_hash;
 perform public.premium_fixture_assert(d->>'candidateHash'=actual_hash,'entire immutable candidate hash');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stage no canonical outbox');
 perform public.premium_fixture_assert((select to_jsonb(w)=(select value from public.premium_fixture_saved where name='before-work') from public.literary_works w),'stage complete work');
 perform public.premium_fixture_assert((select to_jsonb(t)=(select value from public.premium_fixture_saved where name='before-ru') from public.literary_work_translations t where locale='ru'),'stage complete RU');
 perform public.premium_fixture_assert((select to_jsonb(t)=(select value from public.premium_fixture_saved where name='before-en') from public.literary_work_translations t where locale='en'),'stage complete EN');
 set local role anon;
 perform public.premium_fixture_assert((select count(*)=1 from public.literary_work_translations where locale='en'),'existing admitted machine remains public');
end; $$;
select 'M07_T05_NATIVE_PRIVATE_PENDING_PASS';

-- Each stale-source/target test rolls the canonical mutation back in a nested
-- subtransaction after observing the actual RPC conflict, retaining one receipt.
do $$ declare d jsonb; field text; begin
 select value into d from public.premium_fixture_saved where name='book-pending';
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 foreach field in array array['work','ru','en','manual','title','title-source'] loop
   begin
     if field='work' then update public.literary_works set original_title='changed';
     elsif field='ru' then update public.literary_work_translations set description=description||' ' where locale='ru';
     elsif field='en' then update public.literary_work_translations set description=description||' ' where locale='en';
     elsif field='manual' then update public.literary_work_translations set translation_method='human-translation' where locale='en';
     elsif field='title' then update public.literary_work_translations set title='New verified title' where locale='en';
     else delete from public.literary_work_sources where provider='verified-bibliography'; end if;
     set local role authenticated;
     perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',d),'40001');
     reset role;
     raise exception using errcode='P0002',message='rollback test drift';
   exception when no_data_found then null; end;
 end loop;
 -- Manual target also prevents initial staging, independent of pending check.
 begin
   delete from public.premium_translation_working_drafts;
   update public.literary_work_translations set translation_method='human-translation' where locale='en';
   set local role authenticated;
   perform public.premium_fixture_error($q$select public.premium_fixture_stage(public.premium_fixture_args('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'))$q$,'40001');
   reset role;
   raise exception using errcode='P0002',message='rollback manual control';
 exception when no_data_found then null; end;
end; $$;
select 'M07_T05_NATIVE_BOOK_CAS_MANUAL_PASS';

do $$ declare d jsonb; receipt jsonb; before_en jsonb; begin
 select value into d from public.premium_fixture_saved where name='book-pending';
 select value into before_en from public.premium_fixture_saved where name='before-en';
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 receipt:=public.premium_fixture_promote(d);
 insert into public.premium_fixture_saved values('book-promoted',receipt);
 perform public.premium_fixture_assert(receipt->>'state'='promoted' and receipt->>'reviewedBy'='22222222-2222-4222-8222-222222222222','human actor receipt');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('literary_work',d->>'entityId')->'draft'='null'::jsonb,'consumed exact book');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',d),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',d),'40001');
 reset role;
 perform public.premium_fixture_assert((select description=d#>>'{payload,description}' and title=before_en->>'title'
   and metadata->'authored'=before_en#>'{metadata,authored}' and metadata->'rights'=before_en#>'{metadata,rights}'
   and metadata#>>'{premiumTranslation,custom}'='retained' and editorial_status='reviewed'
   and metadata#>>'{premiumTranslation,humanReview,reviewedBy}'=receipt->>'reviewedBy'
   and metadata#>>'{premiumTranslation,humanReview,reviewedAt}'=receipt->>'reviewedAt'
   and metadata#>>'{premiumTranslation,translatorModel}'='fixture-translator'
   from public.literary_work_translations where locale='en'),'stored payload + preserved metadata + real human provenance');
 perform public.premium_fixture_assert((select to_jsonb(w)=(select value from public.premium_fixture_saved where name='before-work') from public.literary_works w),'promote work preserved');
 perform public.premium_fixture_assert((select to_jsonb(t)=(select value from public.premium_fixture_saved where name='before-ru') from public.literary_work_translations t where locale='ru'),'promote RU preserved');
 perform public.premium_fixture_assert((select jsonb_agg(to_jsonb(s) order by id)=(select value from public.premium_fixture_saved where name='before-sources') from public.literary_work_sources s),'sources rights preserved');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one canonical promotion');
end; $$;
select 'M07_T05_NATIVE_BOOK_PROMOTION_PASS';

-- Country absent override: no canonical insertion before approval. The trusted
-- current catalog includes other locales which must survive the new EN override.
truncate public.premium_fixture_outbox;
do $$ declare d jsonb; receipt jsonb; catalog jsonb := '{"name":"Страна","translations":{"ru":{"authored":"RU"},"fr":{"authored":"FR"}}}'; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','fixture-country'))->'draft';
 insert into public.premium_fixture_saved values('country-pending',d);
 reset role;
 perform public.premium_fixture_assert((select count(*)=0 from public.country_profile_overrides),'pending country absent unchanged');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'country pending no outbox');
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,'[]'),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,'{"translations":"opaque authored data"}'),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',jsonb_set(d,'{sourceRevision,catalogSourceHash}',to_jsonb(repeat('c',64))),catalog),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,'{"translations":{"en":null}}'),'40001');
 receipt:=public.premium_fixture_promote(d,catalog);
 insert into public.premium_fixture_saved values('country-promoted',receipt);
 reset role;
 perform public.premium_fixture_assert((select fields#>'{translations,ru}'=catalog#>'{translations,ru}' and fields#>'{translations,fr}'=catalog#>'{translations,fr}'
   and fields#>>'{translations,en,status}'='reviewed' and fields#>>'{translations,en,method}'='machine-translation'
   and fields#>>'{translations,en,humanReview,reviewedBy}'=receipt->>'reviewedBy'
   and not (fields#>'{translations,en,fields}')?'history' and not (fields#>'{translations,en,fields}')?'chronology'
   from public.country_profile_overrides where country_id='fixture-country'),'catalog locales + compact fields + human review');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one new country approval');
end; $$;
select 'M07_T05_NATIVE_COUNTRY_CATALOG_PASS';

insert into public.country_profile_overrides(country_id,fields,is_enabled,updated_by) values
 ('own-machine','{"name":"Авторская страна","coordinates":[10,20],"rights":{"source":"retain"},"translations":{"fr":{"human":"FR"},"en":{"locale":"en","method":"machine-translation","status":"reviewed","custom":"retain"}}}',false,'11111111-1111-4111-8111-111111111111'),
 ('hidden-human','{"translations":{"fr":{"human":"FR"}}}',true,'11111111-1111-4111-8111-111111111111'),
 ('own-human','{"translations":{"en":{"locale":"en","method":"human-translation","fields":{"name":"Human country"}}}}',true,'11111111-1111-4111-8111-111111111111');
insert into public.premium_fixture_saved values('country-before',(select to_jsonb(c) from public.country_profile_overrides c where country_id='own-machine'));
truncate public.premium_fixture_outbox;
do $$ declare d jsonb; receipt jsonb; before_country jsonb; field text; catalog jsonb := '{"translations":{"en":{"locale":"en","method":"human-translation"},"de":{"keep":"base"}}}'; begin
 select value into before_country from public.premium_fixture_saved where name='country-before';
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 perform public.premium_fixture_error($q$select public.premium_fixture_stage(public.premium_fixture_args('country','own-human'))$q$,'40001');
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','hidden-human'))->'draft';
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,catalog),'40001');
 perform public.premium_fixture_discard(d);
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','own-machine'))->'draft';
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(c)=before_country from public.country_profile_overrides c where country_id='own-machine'),'whole override unchanged while pending');
 foreach field in array array['source','manual','delete'] loop
   begin
     if field='source' then update public.country_profile_overrides set fields=fields||'{"name":"changed"}' where country_id='own-machine';
     elsif field='manual' then update public.country_profile_overrides set fields=jsonb_set(fields,'{translations,en,method}','"human-translation"') where country_id='own-machine';
     else delete from public.country_profile_overrides where country_id='own-machine'; end if;
     set local role authenticated;
     perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,catalog),'40001');
     reset role;
     raise exception using errcode='P0002',message='rollback country drift';
   exception when no_data_found then null; end;
 end loop;
 set local role authenticated;
 receipt:=public.premium_fixture_promote(d,catalog);
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,catalog),'40001');
 reset role;
 perform public.premium_fixture_assert((select not is_enabled and fields-'translations'=(before_country->'fields')-'translations'
   and fields#>'{translations,fr}'=before_country#>'{fields,translations,fr}' and not (fields->'translations')?'de'
   and fields#>>'{translations,en,custom}'='retain' and fields#>>'{translations,en,reviewedBy}'=receipt->>'reviewedBy'
   from public.country_profile_overrides where country_id='own-machine'),'own machine precedence preserves override map flags rights');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'country canonical writes only approval');
end; $$;
select 'M07_T05_NATIVE_COUNTRY_CAS_MANUAL_PASS';

-- Lost stage ACK is recoverable through exact get; stale candidate can be
-- discarded even after a manual winner, but wrong version/hash cannot consume.
truncate public.premium_fixture_outbox;
do $$ declare d jsonb; later jsonb; before_country jsonb; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_stage(public.premium_fixture_args('country','late-override'));
 d:=public.get_premium_translation_working_draft('country','late-override')->'draft';
 reset role;
 insert into public.country_profile_overrides(country_id,fields) values('late-override','{"translations":{"en":{"locale":"en","method":"human-translation","fields":{"name":"Manual winner"}}}}');
 select to_jsonb(c) into before_country from public.country_profile_overrides c where country_id='late-override';
 truncate public.premium_fixture_outbox;
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,''{}''::jsonb)',d),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{candidateHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('country','late-override')->'draft'=d,'stale still inspectable');
 perform public.premium_fixture_assert(public.premium_fixture_discard(d)->>'state'='discarded','exact stale discard');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',d),'40001');
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(c)=before_country from public.country_profile_overrides c where country_id='late-override'),'discard preserves manual winner');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'discard no canonical outbox');
 set local role authenticated;
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','restage'))->'draft';
 perform public.premium_fixture_discard(d);
 later:=public.premium_fixture_stage(public.premium_fixture_args('country','restage'))->'draft';
 perform public.premium_fixture_assert(later->>'id'<>d->>'id','restage fresh identity');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',d),'40001');
 perform public.premium_fixture_discard(later);
end; $$;
select 'M07_T05_NATIVE_DISCARD_REPLAY_PASS';

do $$ begin
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_translation_working_drafts),'all candidates consumed explicitly');
 perform public.premium_fixture_assert(not exists(select 1 from public.admin_audit_log where action like 'premium_translation.candidate.%'
   and (metadata-array['draftId','version','candidateHash','sourceHash','canonicalId','outcome'])<>'{}'::jsonb),'audit only IDs hashes outcomes');
 perform public.premium_fixture_assert((select count(*)>5 from public.admin_audit_log where action like 'premium_translation.candidate.%'),'durable audit outcomes');
 perform public.premium_fixture_assert(not exists(select 1 from public.admin_audit_log where action like 'premium_translation.candidate.%' and
   metadata::text like '%astronomers%'),'no candidate prose in audit');
end; $$;
select 'M07_T05_NATIVE_AUDIT_FINAL_PASS';
select 'M07_T05_DTO='||jsonb_object_agg(name,value)::text from public.premium_fixture_saved
 where name in ('book-pending','country-pending','book-promoted','country-promoted','book-args');
select 'M07_T05_SUMMARY='||jsonb_build_object('groups',10,'providerCalls',0,'canonicalStagingWrites',0,
 'pendingNeverOverwritten',true,'explicitReviewActor',true,'protectedManualAndAdmittedMachine',true,
 'countryCatalogBoundary','trusted application reload; SQL override CAS and ownership','allCandidatesConsumed',true)::text;

-- Additive native PostgreSQL fixture. Run after the unchanged book/country
-- fixture, actual writer table/revision prefix, and both private migrations.
-- Auth/staff and outbox capture are synthetic local boundaries, not managed E2E.
reset role;
create trigger premium_fixture_writer_outbox after insert or update on public.writer_profile_overrides
  for each row execute function public.premium_fixture_capture();

create function public.writer_private_fixture_catalog()
returns jsonb language sql immutable as $$
select '{"fullName":"  Иван Автор  ","name":"Автор","rights":{"owner":"author","permission":"unchanged"},
 "biographyTranslations":{"ru":{"locale":"ru","text":"  Иван Автор родился в 1900 году и работал в Архиве. Он создал роман в 1930 году, преподавал литературу и подготовил исследование сохранившихся рукописей.  ",
 "sourceLanguage":" Russian ","status":"reviewed","method":"editorial-original","reviewedAt":"2026-10-01","reviewer":"Human RU editor",
 "sourceTextRights":"project-original","rights":{"license":"RAW RU RIGHTS"},"custom":{"nested":[null,true,"RAW RU VALUE"]},
 "sources":[{"provider":" Archive ","url":"https://fixture.test/writer","fields":["biography-facts"],"usage":"fact-check","retrievedAt":"2026-10-01",
   "author":"Original researcher","title":"Raw archive title","licenseName":"Permission","licenseUrl":"https://fixture.test/permission",
   "customRights":{"permissionId":"RAW-SOURCE-RIGHTS","conditions":["full-credit"]}}]},
 "en":{"locale":"en","text":"Previously admitted machine English remains visible while a private candidate awaits explicit human review. This existing biography and its metadata must remain untouched during staging.",
 "sourceLanguage":"Russian","status":"reviewed","method":"machine-translation","reviewedAt":"2026-10-02","sourceTextRights":"project-original",
 "customEnglish":{"editor":"EN AUTHOR METADATA"},"rights":{"credit":"KEEP EN RIGHTS"},
 "sources":[{"url":"https://fixture.test/previous-source","custom":"previous provenance"}],
 "translationMeta":{"customMachine":{"preserve":"EN META"},"generatedAt":"2026-10-01T01:00:00Z"}},
 "fr":{"locale":"fr","text":"Texte original conservé","rights":"OTHER LOCALE RIGHTS"}}}'::jsonb;
$$;

create function public.writer_private_fixture_args(identity text, catalog jsonb default public.writer_private_fixture_catalog(), replacement boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
declare writer public.writer_profile_overrides%rowtype; effective jsonb; russian jsonb; source jsonb;
begin
 select * into writer from public.writer_profile_overrides where country_id=split_part(identity,':',1) and writer_id=split_part(identity,':',2);
 effective:=catalog||coalesce(writer.fields,'{}'::jsonb); russian:=effective#>'{biographyTranslations,ru}';
 source:=jsonb_build_object('writerName',coalesce(nullif(btrim(effective->>'fullName'),''),nullif(btrim(effective->>'name'),''),split_part(identity,':',2)),
   'text',btrim(russian->>'text'),'sourceLanguage',btrim(russian->>'sourceLanguage'),
   'sources','[{"provider":"Archive","url":"https://fixture.test/writer","fields":["biography-facts"],"usage":"fact-check","retrievedAt":"2026-10-01","author":"Original researcher","title":"Raw archive title","licenseName":"Permission","licenseUrl":"https://fixture.test/permission"}]'::jsonb,
   'russianProfile',russian,'catalogFields',catalog);
 return jsonb_build_object('kind','writer_biography','identity',identity,'sourceHash',repeat('a',64),'source',source,
   'sourceRevision',jsonb_build_object('countryId',split_part(identity,':',1),'writerId',split_part(identity,':',2),
     'overrideId',writer.id,'overrideUpdatedAt',writer.updated_at,'catalogSourceHash',repeat('b',64),'replaceEnglishTombstone',replacement),
   'targetRevision',jsonb_build_object('id',writer.id,'updatedAt',writer.updated_at),
   'payload',jsonb_build_object('text','Ivan Author was born in 1900 and worked at the Archive, where he studied surviving manuscripts. He wrote a novel in 1930 and also taught literature during his scholarly career.'),
   'provenance',jsonb_build_object('provider','cloudflare','translatorModel','fixture-translator','reviewerModel','fixture-reviewer',
     'translatorRequestId','writer-request','reviewerRequestId',null,'generatedAt','2026-10-01T01:00:00.123456Z'));
end;
$$;
create function public.writer_private_fixture_promote(draft jsonb, catalog jsonb default public.writer_private_fixture_catalog(), confirm boolean default true)
returns jsonb language sql security invoker as $$
 select public.promote_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash',draft->>'sourceHash',draft#>>'{sourceRevision,catalogSourceHash}',catalog,confirm);
$$;

-- No new public API/grants, helper schema access, direct DML, or trigger leak.
do $$ declare fn regprocedure; begin
 perform public.premium_fixture_assert((select relrowsecurity and relforcerowsecurity from pg_class where oid='public.premium_translation_working_drafts'::regclass),'writer private force RLS');
 perform public.premium_fixture_assert(not exists(select 1 from pg_trigger where tgrelid='public.premium_translation_working_drafts'::regclass and not tgisinternal),'writer stage has no publication trigger');
 for fn in select oid::regprocedure from pg_proc where pronamespace='premium_translation_private'::regnamespace loop
   perform public.premium_fixture_assert(not has_function_privilege('anon',fn,'EXECUTE') and not has_function_privilege('authenticated',fn,'EXECUTE'),'writer helpers private');
 end loop;
 set local role anon;
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one')$q$,'42501');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','','true');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one')$q$,'42501');
 perform set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one')$q$,'42501');
 perform public.premium_fixture_error($q$select public.premium_fixture_stage(public.writer_private_fixture_args('fixture-country:writer-one'))$q$,'42501');
 perform public.premium_fixture_error($q$select public.promote_premium_translation_working_draft('writer_biography','fixture-country:writer-one',null,1,null,null,null,'{}',true)$q$,'42501');
 perform public.premium_fixture_error($q$select public.discard_premium_translation_working_draft('writer_biography','fixture-country:writer-one',null,1,null)$q$,'42501');
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error($q$insert into public.premium_translation_working_drafts(entity_id) values('writer-direct')$q$,'42501');
 perform public.premium_fixture_error('update public.premium_translation_working_drafts set version=2','42501');
 perform public.premium_fixture_error('delete from public.premium_translation_working_drafts','42501');
end; $$;
select 'M07_WRITER_NATIVE_ACL_PASS';

-- The public/canonical row and revision/outbox graph do not change on stage.
insert into public.writer_profile_overrides(id,country_id,writer_id,fields,is_enabled,updated_at)
 values('dddddddd-dddd-4ddd-8ddd-dddddddddddd','fixture-country','writer-one',public.writer_private_fixture_catalog()||'{"authoredOverride":{"keep":"ALL FIELDS"}}',false,'2026-10-09T10:00:00.123456Z');
do $$ declare a jsonb; d jsonb; staged jsonb; read_receipt jsonb; before_row jsonb; revision_count bigint; receipt jsonb; after_row jsonb; begin
 select to_jsonb(w) into before_row from public.writer_profile_overrides w where writer_id='writer-one';
 select count(*) into revision_count from public.writer_profile_override_revisions;
 truncate public.premium_fixture_outbox;
 a:=public.writer_private_fixture_args('fixture-country:writer-one');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 staged:=public.premium_fixture_stage(a); d:=staged->'draft';
 read_receipt:=public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one');
 perform public.premium_fixture_assert(d->>'humanReview'='pending','writer pending review');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one')->'draft'=d,'writer retained exact draft');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb,public.writer_private_fixture_catalog(),false)',d),'22023');
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(w)=before_row from public.writer_profile_overrides w where writer_id='writer-one'),'stage preserves full disabled canonical row');
 perform public.premium_fixture_assert((select count(*)=revision_count from public.writer_profile_override_revisions),'stage no canonical revision');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stage no publication outbox');
 insert into public.premium_fixture_saved values('writer-pending',d),('writer-args',a),('writer-stage',staged),('writer-read',read_receipt);
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 set local timezone='Pacific/Kiritimati';
 receipt:=public.writer_private_fixture_promote(d);
 reset role;
 select to_jsonb(w) into after_row from public.writer_profile_overrides w where writer_id='writer-one';
 perform public.premium_fixture_assert(after_row->'is_enabled'='false'::jsonb,'promotion retains disabled flag');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,ru}'=before_row#>'{fields,biographyTranslations,ru}','raw RU including spaces and rights retained');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,fr}'=before_row#>'{fields,biographyTranslations,fr}','other locale retained');
 perform public.premium_fixture_assert(((after_row->'fields')-'biographyTranslations')=((before_row->'fields')-'biographyTranslations'),'unrelated override fields retained');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,en,sources}'=before_row#>'{fields,biographyTranslations,ru,sources}','raw source rights inherited without projection');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,en,rights}'=before_row#>'{fields,biographyTranslations,en,rights}','EN rights retained');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,en,customEnglish}'=before_row#>'{fields,biographyTranslations,en,customEnglish}','EN unknown metadata retained');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,en,translationMeta,customMachine}'=before_row#>'{fields,biographyTranslations,en,translationMeta,customMachine}','machine unknown metadata retained');
 perform public.premium_fixture_assert(after_row#>>'{fields,biographyTranslations,en,text}'=a#>>'{payload,text}','exact candidate text promoted');
 perform public.premium_fixture_assert(after_row#>>'{fields,biographyTranslations,en,reviewedAt}'=to_char((receipt->>'reviewedAt')::timestamptz at time zone 'UTC','YYYY-MM-DD'),'human review date UTC');
 perform public.premium_fixture_assert(after_row#>>'{fields,biographyTranslations,en,translationMeta,humanReview,reviewedBy}'='22222222-2222-4222-8222-222222222222','reviewer is current human actor');
 perform public.premium_fixture_assert((select count(*)=revision_count+1 from public.writer_profile_override_revisions),'one promotion revision');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one promotion outbox');
 perform public.premium_fixture_assert(not exists(select 1 from public.premium_translation_working_drafts where id=(d->>'id')::uuid),'promotion consumes private candidate');
 insert into public.premium_fixture_saved values('writer-promoted',receipt),('writer-after',after_row);
end; $$;
select 'M07_WRITER_NATIVE_STAGE_PROMOTE_PRESERVATION_PASS';

-- Malformed source/payload/reviewer and mismatched writer/source/target identity.
do $$ declare a jsonb; bad jsonb; begin
 a:=public.writer_private_fixture_args('fixture-country:writer-one');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 bad:=jsonb_set(a,'{provenance,reviewerModel}','null');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
 bad:=jsonb_set(a,'{payload,text}','"Too short"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
 bad:=jsonb_set(a,'{source,sources,0,licenseName}','"Forged permission"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
 bad:=jsonb_set(a,'{source,russianProfile,rights,license}','"Forged raw rights"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'40001');
 bad:=jsonb_set(a,'{sourceRevision,writerId}','"writer-other"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'40001');
 bad:=jsonb_set(a,'{targetRevision,id}','"eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'40001');
 bad:=jsonb_set(a,'{sourceRevision,replaceEnglishTombstone}','"true"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer:other')$q$,'22023');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer/other')$q$,'22023');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer other')$q$,'22023');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country',repeat('a',121))$q$,'22023');
end; $$;
select 'M07_WRITER_NATIVE_SHAPE_IDENTITY_PASS';

-- Authored/ambiguous EN and parent-map tombstones must not be overwritten.
do $$ declare catalog jsonb; a jsonb; d jsonb; value jsonb; before_row jsonb; begin
 catalog:=public.writer_private_fixture_catalog();
 foreach value in array array['"human-translation"'::jsonb,'"editorial-original"'::jsonb,'"licensed-source"'::jsonb,'null'::jsonb] loop
   a:=public.writer_private_fixture_args('fixture-country:manual-catalog',jsonb_set(catalog,'{biographyTranslations,en,method}',value));
   set local role authenticated;
   perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
   perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
   reset role;
 end loop;
 a:=public.writer_private_fixture_args('fixture-country:null-catalog',jsonb_set(catalog,'{biographyTranslations,en}','null'));
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 reset role;
 foreach value in array array['null'::jsonb,'"legacy metadata"'::jsonb,'[]'::jsonb] loop
   a:=public.writer_private_fixture_args('fixture-country:ambiguous-metadata',jsonb_set(catalog,'{biographyTranslations,en,translationMeta}',value));
   set local role authenticated;
   perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
   reset role;
 end loop;
 insert into public.writer_profile_overrides(country_id,writer_id,fields)
   values('fixture-country','tombstone',jsonb_build_object('biographyTranslations',jsonb_build_object('ru',catalog#>'{biographyTranslations,ru}')));
 a:=public.writer_private_fixture_args('fixture-country:tombstone');
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 reset role;
 update public.writer_profile_overrides set fields=jsonb_set(fields,'{biographyTranslations,en}','null') where writer_id='tombstone';
 a:=public.writer_private_fixture_args('fixture-country:tombstone');
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 reset role;
 select to_jsonb(w) into before_row from public.writer_profile_overrides w where writer_id='tombstone';
 a:=public.writer_private_fixture_args('fixture-country:tombstone',catalog,true);
 set local role authenticated;
 d:=public.premium_fixture_stage(a)->'draft';
 perform public.premium_fixture_discard(d);
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(w)=before_row from public.writer_profile_overrides w where writer_id='tombstone'),'explicit replacement staging/discard retains tombstone');
 set local role authenticated;
 d:=public.premium_fixture_stage(a)->'draft';
 perform public.writer_private_fixture_promote(d);
 reset role;
 perform public.premium_fixture_assert((select fields#>'{biographyTranslations,ru}'=before_row#>'{fields,biographyTranslations,ru}' from public.writer_profile_overrides where writer_id='tombstone'),'replacement retains raw authored RU');
 update public.writer_profile_overrides set fields=jsonb_set(fields,'{biographyTranslations,en,method}','"human-translation"') where writer_id='tombstone';
 a:=public.writer_private_fixture_args('fixture-country:tombstone',catalog,true);
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 reset role;
 foreach value in array array['{}'::jsonb,'null'::jsonb] loop
   update public.writer_profile_overrides set fields=jsonb_build_object('biographyTranslations',value) where writer_id='tombstone';
   a:=public.writer_private_fixture_args('fixture-country:tombstone',catalog,true);
   set local role authenticated;
   perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'22023');
   reset role;
 end loop;
end; $$;
select 'M07_WRITER_NATIVE_OWNERSHIP_TOMBSTONES_PASS';

-- Exact microsecond CAS, takeover, disappearance, raw source change, catalog
-- change and absent-to-present target all refuse promotion; discard still works.
do $$ declare a jsonb; d jsonb; changed jsonb; case_name text; before_row jsonb; begin
 foreach case_name in array array['microsecond','manual','source','deleted','catalog','absent'] loop
   if case_name<>'absent' then
     insert into public.writer_profile_overrides(country_id,writer_id,fields,updated_at)
       values('fixture-country','stale-'||case_name,public.writer_private_fixture_catalog(),'2026-10-09T10:00:00.123456Z');
   end if;
   a:=public.writer_private_fixture_args('fixture-country:stale-'||case_name);
   set local role authenticated;
   perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
   d:=public.premium_fixture_stage(a)->'draft';
   reset role;
   if case_name='microsecond' then
     alter table public.writer_profile_overrides disable trigger writer_profile_overrides_set_updated_at;
     update public.writer_profile_overrides set updated_at=updated_at+interval '1 microsecond' where writer_id='stale-'||case_name;
     alter table public.writer_profile_overrides enable trigger writer_profile_overrides_set_updated_at;
   elsif case_name='manual' then
     update public.writer_profile_overrides set fields=jsonb_set(fields,'{biographyTranslations,en,method}','"human-translation"') where writer_id='stale-'||case_name;
   elsif case_name='source' then
     -- Keep the timestamp fixed to prove full raw source equality is independent.
     alter table public.writer_profile_overrides disable trigger writer_profile_overrides_set_updated_at;
     update public.writer_profile_overrides set fields=jsonb_set(fields,'{biographyTranslations,ru,rights,license}','"changed raw source rights"') where writer_id='stale-'||case_name;
     alter table public.writer_profile_overrides enable trigger writer_profile_overrides_set_updated_at;
   elsif case_name='deleted' then
     delete from public.writer_profile_overrides where writer_id='stale-'||case_name;
   elsif case_name='absent' then
     insert into public.writer_profile_overrides(country_id,writer_id,fields) values('fixture-country','stale-absent',public.writer_private_fixture_catalog());
   end if;
   select to_jsonb(w) into before_row from public.writer_profile_overrides w where writer_id='stale-'||case_name;
   truncate public.premium_fixture_outbox;
   changed:=case when case_name='catalog' then jsonb_set(public.writer_private_fixture_catalog(),'{rights,permission}','"changed catalog rights"') else public.writer_private_fixture_catalog() end;
   set local role authenticated;
   perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb,%L::jsonb)',d,changed),'40001');
   perform public.premium_fixture_assert(public.get_premium_translation_working_draft('writer_biography','fixture-country:stale-'||case_name)->'draft'=d,'stale candidate retained');
   perform public.premium_fixture_assert(public.premium_fixture_discard(d)->>'state'='discarded','stale candidate discard');
   reset role;
   perform public.premium_fixture_assert((select to_jsonb(w) from public.writer_profile_overrides w where writer_id='stale-'||case_name) is not distinct from before_row,'stale discard preserves source winner');
   perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stale failure/discard no outbox');
 end loop;
end; $$;
select 'M07_WRITER_NATIVE_STALE_DISCARD_PASS';

-- Long Unicode identifiers, cross-country selection and new override creation.
do $$ declare identity text; a jsonb; d jsonb; wrong jsonb; receipt jsonb; begin
 identity:=repeat('a',120)||':'||repeat(chr(128512),180);
 a:=public.writer_private_fixture_args(identity);
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(a)->'draft';
 perform public.premium_fixture_assert(d->>'entityId'=identity,'301-codepoint writer identity accepted');
 receipt:=public.premium_fixture_discard(d);
 reset role;
 insert into public.premium_fixture_saved values('writer-long-pending',d),('writer-long-args',a),('writer-discarded',receipt);
 set local role authenticated;
 a:=public.writer_private_fixture_args('fixture-country:new-writer');
 d:=public.premium_fixture_stage(a)->'draft';
 wrong:=jsonb_set(d,'{entityId}','"other-country:new-writer"');
 perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb)',wrong),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',wrong),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{candidateHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{version}','2')),'40001');
 receipt:=public.writer_private_fixture_promote(d);
 perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb)',d),'40001');
 receipt:=public.get_premium_translation_working_draft('writer_biography','fixture-country:new-writer');
 reset role;
 perform public.premium_fixture_assert((select fields#>'{biographyTranslations,ru}'=public.writer_private_fixture_catalog()#>'{biographyTranslations,ru}' from public.writer_profile_overrides where writer_id='new-writer'),'new override retains raw catalog RU');
 perform public.premium_fixture_assert((select fields#>'{biographyTranslations,fr}'=public.writer_private_fixture_catalog()#>'{biographyTranslations,fr}' from public.writer_profile_overrides where writer_id='new-writer'),'new override retains other catalog locales');
 insert into public.premium_fixture_saved values('writer-absent',receipt);
end; $$;
select 'M07_WRITER_NATIVE_IDENTITY_NEW_OVERRIDE_PASS';

create function public.writer_private_fixture_fail_update() returns trigger language plpgsql as $$
begin raise exception using errcode='23514',message='Synthetic canonical writer failure'; end; $$;
create trigger writer_fixture_failure before update on public.writer_profile_overrides
  for each row when (old.writer_id='rollback-writer') execute function public.writer_private_fixture_fail_update();
insert into public.writer_profile_overrides(country_id,writer_id,fields) values('fixture-country','rollback-writer',public.writer_private_fixture_catalog());
do $$ declare d jsonb; before_row jsonb; audit_count bigint; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(public.writer_private_fixture_args('fixture-country:rollback-writer'))->'draft';
 reset role;
 select to_jsonb(w) into before_row from public.writer_profile_overrides w where writer_id='rollback-writer';
 select count(*) into audit_count from public.admin_audit_log;
 truncate public.premium_fixture_outbox;
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb)',d),'23514');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('writer_biography','fixture-country:rollback-writer')->'draft'=d,'failed promotion retains candidate');
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(w)=before_row from public.writer_profile_overrides w where writer_id='rollback-writer'),'failed promotion retains canonical bytes');
 perform public.premium_fixture_assert((select count(*)=audit_count from public.admin_audit_log),'failed promotion no audit receipt');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'failed promotion no outbox');
 set local role authenticated;
 perform public.premium_fixture_discard(d);
end; $$;
select 'M07_WRITER_NATIVE_ROLLBACK_PASS';

do $$ begin
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_translation_working_drafts),'all writer candidates consumed explicitly');
 perform public.premium_fixture_assert(not exists(select 1 from public.admin_audit_log where action like 'premium_translation.candidate.%'
   and (metadata-array['draftId','version','candidateHash','sourceHash','canonicalId','outcome'])<>'{}'::jsonb),'writer audit only identities hashes outcomes');
end; $$;
select 'M07_WRITER_DTO='||jsonb_object_agg(name,value)::text from public.premium_fixture_saved where name like 'writer-%';
select 'M07_WRITER_SUMMARY='||jsonb_build_object('groups',7,'providerCalls',0,'canonicalStagingWrites',0,'rawSourceRightsPreserved',true,
 'catalogBoundary','trusted application reload, exact hash and raw fields comparison','managedAuthPostgrestVerified',false)::text;

-- Synthetic data only. Run after the unchanged book/country/writer fixtures,
-- actual homepage definitions/guards and the additive Site Copy migration.
create trigger premium_fixture_site_copy_outbox after update on public.homepage_blocks
  for each row execute function public.premium_fixture_capture();

insert into public.media_assets(id,object_path,original_name,mime_type,byte_size,uploaded_by)
values('99999999-9999-4999-8999-999999999999','fixture/site-copy.png','site-copy.png','image/png',1,'11111111-1111-4111-8111-111111111111');

create function public.site_copy_fixture_settings()
returns jsonb language sql immutable set search_path='' as $$
 select jsonb_build_object('systemKey','site-copy-overrides','siteCopy',jsonb_build_object(
   'ru',jsonb_build_object('intro',E'  Исходный \u2014 текст\r\nс новой строкой  ','cta','Открыть карту','manual','Ручной русский'),
   'en',jsonb_build_object('intro','Existing machine copy','manual','Keep authored English','unrelated',jsonb_build_object('raw',true)),
   'fr',jsonb_build_object('intro','  Français intact  ','rights',jsonb_build_array('éditeur',null)),
   'localeExtension',jsonb_build_object('preserve',true)),
   'premiumTranslation',jsonb_build_object('siteCopyEn',jsonb_build_object(
     'intro',jsonb_build_object('sourceHash',repeat('a',64),'customMachine',jsonb_build_object('rights','keep')),
     'unselected',jsonb_build_object('raw','preserved')),'customPremium',jsonb_build_array('keep',null)),
   'unknownSettings',jsonb_build_object('empty',jsonb_build_array(),'rights',jsonb_build_object('owner','editor')))
$$;

insert into public.homepage_blocks(id,block_type,title,settings,display_order,is_enabled,background_style,background_media_id,updated_by,updated_at)
values('dddddddd-dddd-4ddd-8ddd-dddddddddddd','text','Authored title',public.site_copy_fixture_settings(),-17,false,'paper',
 '99999999-9999-4999-8999-999999999999','11111111-1111-4111-8111-111111111111','2026-10-29T10:00:00.123456Z');

create function public.site_copy_fixture_args()
returns jsonb language plpgsql security definer set search_path='' as $$
declare block public.homepage_blocks%rowtype;
begin
 select * into block from public.homepage_blocks where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 return jsonb_build_object('kind','site_copy','identity',block.id,'sourceHash',repeat('b',64),
   'source',jsonb_build_object('settings',block.settings,'items',jsonb_build_array(
     jsonb_build_object('key','intro','text',E'Исходный \u2014 текст\nс новой строкой','sourceHash',repeat('c',64)),
     jsonb_build_object('key','cta','text','Открыть карту','sourceHash',repeat('d',64)))),
   'sourceRevision',jsonb_build_object('blockId',block.id,'blockUpdatedAt',block.updated_at),
   'targetRevision',jsonb_build_object('id',block.id,'updatedAt',block.updated_at),
   'payload',jsonb_build_object('items',jsonb_build_array(
     jsonb_build_object('key','intro','text','Separate English copy awaiting explicit human review.'),
     jsonb_build_object('key','cta','text','Open the map'))),
   'provenance',jsonb_build_object('provider','openai','translatorModel','controlled-translator','reviewerModel',null,
     'translatorRequestId','controlled-translation','reviewerRequestId',null,'generatedAt','2026-10-29T10:00:01.123456Z'));
end;
$$;
create function public.site_copy_fixture_promote(draft jsonb, confirm_review boolean default true)
returns jsonb language sql security invoker set search_path='' as $$
 select public.promote_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash',draft->>'sourceHash',null,null,confirm_review);
$$;

do $$ declare fn record; begin
 perform public.premium_fixture_assert((select relrowsecurity and relforcerowsecurity from pg_class where oid='public.premium_translation_working_drafts'::regclass),'Site Copy private force RLS');
 for fn in select oid::regprocedure as signature from pg_proc where proname in
   ('get_premium_translation_working_draft','stage_premium_translation_working_draft','promote_premium_translation_working_draft','discard_premium_translation_working_draft') loop
   perform public.premium_fixture_assert(not has_function_privilege('anon',fn.signature,'execute'),'anon RPC denied');
   perform public.premium_fixture_assert(has_function_privilege('authenticated',fn.signature,'execute'),'authenticated RPC retained');
 end loop;
 set local role anon;
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts()','42501');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('site_copy','dddddddd-dddd-4ddd-8ddd-dddddddddddd')$q$,'42501');
 reset role;
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts()','42501');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('site_copy','dddddddd-dddd-4ddd-8ddd-dddddddddddd')$q$,'42501');
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('site_copy','not-a-block-uuid')$q$,'22023');
 reset role;
end; $$;
select 'M07_SITE_COPY_NATIVE_ACL_PASS';

do $$ declare a jsonb; staged jsonb; d jsonb; receipt jsonb; before_row jsonb; after_row jsonb; begin
 select to_jsonb(b) into before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 a:=public.site_copy_fixture_args(); truncate public.premium_fixture_outbox;
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 staged:=public.premium_fixture_stage(a); d:=staged->'draft';
 perform public.premium_fixture_assert(d->>'humanReview'='pending','Site Copy stage pending');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('site_copy',d->>'entityId')->'draft'=d,'Site Copy exact private read');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb,false)',d),'22023');
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(b)=before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'stage preserves entire canonical block');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stage emits no canonical outbox');
 insert into public.premium_fixture_saved values('site-copy-args',a),('site-copy-stage',staged),
   ('site-copy-read',public.get_premium_translation_working_draft('site_copy',d->>'entityId'));
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 set local timezone='Pacific/Kiritimati';
 receipt:=public.site_copy_fixture_promote(d);
 reset role;
 select to_jsonb(b) into after_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 perform public.premium_fixture_assert((after_row-array['settings','updated_at','updated_by','created_at'])=(before_row-array['settings','updated_at','updated_by','created_at'])
   and (after_row->>'created_at')::timestamptz=(before_row->>'created_at')::timestamptz,'all block attrs retained across timezone rendering');
 perform public.premium_fixture_assert(after_row#>'{settings,siteCopy,ru}'=before_row#>'{settings,siteCopy,ru}','raw RU spaces CRLF and long dash preserved');
 perform public.premium_fixture_assert(after_row#>'{settings,siteCopy,fr}'=before_row#>'{settings,siteCopy,fr}','raw French and rights preserved');
 perform public.premium_fixture_assert(((after_row#>'{settings,siteCopy}')-array['en'])=((before_row#>'{settings,siteCopy}')-array['en']),'other locale maps preserved');
 perform public.premium_fixture_assert(after_row#>'{settings,siteCopy,en,manual}'=before_row#>'{settings,siteCopy,en,manual}','unselected manual English retained');
 perform public.premium_fixture_assert(after_row#>'{settings,siteCopy,en,unrelated}'=before_row#>'{settings,siteCopy,en,unrelated}','unselected malformed raw English retained');
 perform public.premium_fixture_assert(after_row#>>'{settings,siteCopy,en,intro}'=a#>>'{payload,items,0,text}' and after_row#>>'{settings,siteCopy,en,cta}'='Open the map','selected candidate text exact');
 perform public.premium_fixture_assert(after_row#>'{settings,premiumTranslation,siteCopyEn,intro,customMachine}'=before_row#>'{settings,premiumTranslation,siteCopyEn,intro,customMachine}','selected unknown machine metadata retained');
 perform public.premium_fixture_assert(after_row#>'{settings,premiumTranslation,siteCopyEn,unselected}'=before_row#>'{settings,premiumTranslation,siteCopyEn,unselected}','unselected machine metadata retained');
 perform public.premium_fixture_assert(((after_row#>'{settings,premiumTranslation}')-'siteCopyEn')=((before_row#>'{settings,premiumTranslation}')-'siteCopyEn'),'other premium metadata retained');
 perform public.premium_fixture_assert(((after_row->'settings')-array['siteCopy','premiumTranslation'])=((before_row->'settings')-array['siteCopy','premiumTranslation']),'other raw settings retained');
 perform public.premium_fixture_assert(after_row#>>'{settings,premiumTranslation,siteCopyEn,intro,humanReview,reviewedBy}'='22222222-2222-4222-8222-222222222222','reviewer is actual current actor');
 perform public.premium_fixture_assert(after_row#>'{settings,premiumTranslation,siteCopyEn,intro,reviewerModel}'='null'::jsonb,'configured no model reviewer accepted without claiming review');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one canonical promotion outbox');
 perform public.premium_fixture_assert(not exists(select 1 from public.premium_translation_working_drafts where id=(d->>'id')::uuid),'explicit promotion consumes private draft');
 insert into public.premium_fixture_saved values('site-copy-promoted',receipt),('site-copy-after',after_row);
end; $$;
select 'M07_SITE_COPY_NATIVE_PRESERVATION_PASS';

do $$ declare a jsonb; modified jsonb; case_name text; begin
 a:=public.site_copy_fixture_args();
 foreach case_name in array array['empty','too-many','reorder','duplicate','extra-item-key','bad-hash','null-source-id','mismatched-revision','wrong-request-identity','bad-timestamp','unsafe-key','cyrillic-output'] loop
  modified:=a;
  case case_name
   when 'empty' then modified:=jsonb_set(modified,'{source,items}','[]');
   when 'too-many' then modified:=jsonb_set(modified,'{source,items}',(select jsonb_agg(a#>'{source,items,0}') from generate_series(1,51)));
   when 'reorder' then modified:=jsonb_set(modified,'{payload,items}',jsonb_build_array(a#>'{payload,items,1}',a#>'{payload,items,0}'));
   when 'duplicate' then modified:=jsonb_set(jsonb_set(modified,'{payload,items,1,key}','"intro"'),'{source,items,1,key}','"intro"');
   when 'extra-item-key' then modified:=jsonb_set(modified,'{payload,items,0}',(a#>'{payload,items,0}')||'{"extra":true}');
   when 'bad-hash' then modified:=jsonb_set(modified,'{source,items,0,sourceHash}','"bad"');
   when 'null-source-id' then modified:=jsonb_set(modified,'{sourceRevision,blockId}','null');
   when 'mismatched-revision' then modified:=jsonb_set(modified,'{targetRevision,updatedAt}','"2026-10-28T01:00:00Z"');
   when 'wrong-request-identity' then modified:=jsonb_set(modified,'{identity}','"eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee"');
   when 'bad-timestamp' then modified:=jsonb_set(modified,'{sourceRevision,blockUpdatedAt}','"not-a-time"');
   when 'unsafe-key' then modified:=jsonb_set(jsonb_set(modified,'{payload,items,0,key}','"__proto__.polluted"'),'{source,items,0,key}','"__proto__.polluted"');
   when 'cyrillic-output' then modified:=jsonb_set(modified,'{payload,items,0,text}','"Русский вместо перевода"');
  end case;
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',modified),'22023');
  reset role;
 end loop;
end; $$;
select 'M07_SITE_COPY_NATIVE_SHAPE_PASS';

do $$ declare a jsonb; d jsonb; invalid jsonb; item_key text; case_name text; begin
 foreach case_name in array array['key','source','payload'] loop
  a:=public.site_copy_fixture_args();
  a:=jsonb_set(a,'{source,items}',jsonb_build_array(a#>'{source,items,0}'));
  a:=jsonb_set(a,'{payload,items}',jsonb_build_array(a#>'{payload,items,0}'));
  if case_name='key' then
   item_key:='k'||repeat('😀',599)||'a';
   a:=jsonb_set(jsonb_set(a,'{source,items,0,key}',to_jsonb(item_key)),'{payload,items,0,key}',to_jsonb(item_key));
   a:=jsonb_set(a,'{source,settings,siteCopy,ru}',(a#>'{source,settings,siteCopy,ru}')||jsonb_build_object(item_key,'Новый исходный текст'));
   invalid:=jsonb_set(jsonb_set(a,'{source,items,0,key}',to_jsonb(item_key||'a')),'{payload,items,0,key}',to_jsonb(item_key||'a'));
   invalid:=jsonb_set(invalid,'{source,settings,siteCopy,ru}',(a#>'{source,settings,siteCopy,ru}')||jsonb_build_object(item_key||'a','Новый исходный текст'));
  elsif case_name='source' then
   a:=jsonb_set(a,'{source,items,0,text}',to_jsonb(repeat('😀',2000)));
   invalid:=jsonb_set(a,'{source,items,0,text}',to_jsonb(repeat('😀',2000)||'a'));
  else
   a:=jsonb_set(a,'{payload,items,0,text}',to_jsonb(repeat('😀',2000)));
   invalid:=jsonb_set(a,'{payload,items,0,text}',to_jsonb(repeat('😀',2000)||'a'));
  end if;
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',invalid),'22023');
  d:=public.premium_fixture_stage(a)->'draft';
  insert into public.premium_fixture_saved values('site-copy-boundary-'||case_name,d);
  perform public.premium_fixture_discard(d); reset role;
 end loop;
end; $$;
select 'M07_SITE_COPY_NATIVE_UTF16_LIMITS_PASS';

do $$ declare a jsonb; base jsonb; modified jsonb; raw_en jsonb; case_name text; begin
 base:=public.site_copy_fixture_settings();
 foreach raw_en in array array['null'::jsonb,'""'::jsonb,'{}'::jsonb,'[]'::jsonb,'42'::jsonb,'"Manual English"'::jsonb] loop
  modified:=jsonb_set(base#-'{premiumTranslation,siteCopyEn,intro}','{siteCopy,en,intro}',raw_en);
  update public.homepage_blocks set settings=modified where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'; a:=public.site_copy_fixture_args();
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001'); reset role;
 end loop;
 foreach case_name in array array['locale-array','en-array','premium-array','machine-array','selected-null','selected-array','invalid-marker','missing-russian','non-string-russian'] loop
  modified:=base;
  case case_name
   when 'locale-array' then modified:=jsonb_set(base,'{siteCopy}','[]');
   when 'en-array' then modified:=jsonb_set(base,'{siteCopy,en}','[]');
   when 'premium-array' then modified:=jsonb_set(base,'{premiumTranslation}','[]');
   when 'machine-array' then modified:=jsonb_set(base,'{premiumTranslation,siteCopyEn}','[]');
   when 'selected-null' then modified:=jsonb_set(base,'{premiumTranslation,siteCopyEn,intro}','null');
   when 'selected-array' then modified:=jsonb_set(base,'{premiumTranslation,siteCopyEn,intro}','[]');
   when 'invalid-marker' then modified:=jsonb_set(base,'{premiumTranslation,siteCopyEn,intro,sourceHash}','"bad"');
   when 'missing-russian' then modified:=base#-'{siteCopy,ru,intro}';
   when 'non-string-russian' then modified:=jsonb_set(base,'{siteCopy,ru,intro}','{}');
  end case;
  update public.homepage_blocks set settings=modified where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'; a:=public.site_copy_fixture_args();
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001'); reset role;
 end loop;
 update public.homepage_blocks set settings=base where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
end; $$;
select 'M07_SITE_COPY_NATIVE_OWNERSHIP_PASS';

do $$ declare a jsonb; d jsonb; old_row jsonb; case_name text; begin
 foreach case_name in array array['raw-source','raw-fr','unknown-metadata'] loop
  update public.homepage_blocks set settings=public.site_copy_fixture_settings() where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  a:=public.site_copy_fixture_args(); set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  d:=public.premium_fixture_stage(a)->'draft'; reset role;
  case case_name
   when 'raw-source' then update public.homepage_blocks set settings=jsonb_set(settings,'{siteCopy,ru,intro}','"Изменённый исходник"') where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
   when 'raw-fr' then update public.homepage_blocks set settings=jsonb_set(settings,'{siteCopy,fr,intro}','"French changed"') where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
   when 'unknown-metadata' then update public.homepage_blocks set settings=settings||'{"extraRaw":true}' where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  end case;
  truncate public.premium_fixture_outbox; select to_jsonb(b) into old_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
  perform public.premium_fixture_assert(public.get_premium_translation_working_draft('site_copy',d->>'entityId')->'draft'=d,'stale pending remains readable');
  perform public.premium_fixture_discard(d); reset role;
  perform public.premium_fixture_assert((select to_jsonb(b)=old_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'stale promote/discard canonical unchanged');
  perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stale discard emits no outbox');
 end loop;
 update public.homepage_blocks set settings=public.site_copy_fixture_settings() where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
end; $$;
select 'M07_SITE_COPY_NATIVE_STALE_DISCARD_PASS';

do $$ declare a jsonb; d jsonb; begin
 a:=public.site_copy_fixture_args(); set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(a)->'draft'; reset role;
 insert into public.homepage_blocks(id,block_type,title,settings,updated_by) values
  ('eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee','text','Duplicate master',public.site_copy_fixture_settings(),'11111111-1111-4111-8111-111111111111');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
 perform public.premium_fixture_discard(d);
 d:=public.premium_fixture_stage(a)->'draft';
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
 perform public.premium_fixture_discard(d); reset role;
 delete from public.homepage_blocks where id='eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';
end; $$;
select 'M07_SITE_COPY_NATIVE_DUPLICATE_MASTER_PASS';

do $$ declare a jsonb; d jsonb; before_row jsonb; changed_row jsonb; case_name text; recovery_page jsonb; begin
 foreach case_name in array array['russian-takeover','english-takeover','deleted-master'] loop
  update public.homepage_blocks set settings=public.site_copy_fixture_settings() where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  a:=public.site_copy_fixture_args();
  select to_jsonb(b) into before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  case case_name
   when 'russian-takeover' then update public.homepage_blocks set settings=jsonb_set(settings,'{siteCopy,ru,intro}','"Новый ручной русский"') where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
   when 'english-takeover' then update public.homepage_blocks set settings=jsonb_set(settings#-'{premiumTranslation,siteCopyEn,intro}','{siteCopy,en,intro}','"New authored English"') where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
   when 'deleted-master' then delete from public.homepage_blocks where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  end case;
  select to_jsonb(b) into changed_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  truncate public.premium_fixture_outbox;
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  d:=public.premium_fixture_stage(a)->'draft';
  perform public.premium_fixture_assert(d->'sourceSnapshot'=a->'source','provider output survives concurrent source/target takeover');
  perform public.premium_fixture_assert(public.get_premium_translation_working_draft('site_copy',d->>'entityId')->'draft'=d,'concurrent stale output remains inspectable');
  if case_name='deleted-master' then
   recovery_page:=public.list_site_copy_premium_translation_working_drafts();
   perform public.premium_fixture_assert(recovery_page=jsonb_build_object('schemaVersion',1,'entityIds',jsonb_build_array(d->>'entityId'),'nextCursor',null),'deleted master candidate remains discoverable after reload');
   insert into public.premium_fixture_saved values('site-copy-list-deleted-master',recovery_page);
  end if;
  perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
  perform public.premium_fixture_discard(d); reset role;
  perform public.premium_fixture_assert((select to_jsonb(b) from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd') is not distinct from changed_row,'stale stage and failed promotion preserve concurrent canonical state');
  perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stale provider output never emits canonical outbox');
  if case_name='deleted-master' then
   insert into public.homepage_blocks select * from jsonb_populate_record(null::public.homepage_blocks,before_row);
  end if;
 end loop;
 update public.homepage_blocks set settings=public.site_copy_fixture_settings() where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
end; $$;
select 'M07_SITE_COPY_NATIVE_DURABLE_STALE_OUTPUT_PASS';

-- Separate real transactions ensure the actual now()-based foundation trigger
-- creates a new revision, without replacing it with a fixture timestamp rule.
do $$ declare d jsonb; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(public.site_copy_fixture_args())->'draft';
 insert into public.premium_fixture_saved values('site-copy-cas-candidate',d);
end; $$;
update public.homepage_blocks set settings=settings where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
do $$ declare d jsonb; begin
 select value into d from public.premium_fixture_saved where name='site-copy-cas-candidate';
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
 perform public.premium_fixture_discard(d);
end; $$;
select 'M07_SITE_COPY_NATIVE_EXACT_CAS_PASS';

do $$ declare a jsonb; d jsonb; n integer; identity text; page jsonb; seen jsonb:='[]'; expected jsonb; cursor_id uuid;
  before_canonical jsonb; audit_count bigint; last_expected uuid;
begin
 a:=public.site_copy_fixture_args();
 for n in 1..11 loop
  identity:='90000000-0000-4000-8000-'||lpad(n::text,12,'0');
  a:=jsonb_set(jsonb_set(jsonb_set(a,'{identity}',to_jsonb(identity)),'{sourceRevision,blockId}',to_jsonb(identity)),'{targetRevision,id}',to_jsonb(identity));
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_stage(a); reset role;
 end loop;
 select jsonb_agg(entity_id order by id) into expected from public.premium_translation_working_drafts where entity_type='site_copy';
 select to_jsonb(b) into before_canonical from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 select count(*) into audit_count from public.admin_audit_log;
 truncate public.premium_fixture_outbox;
 cursor_id:=null; n:=0;
 loop
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  page:=public.list_site_copy_premium_translation_working_drafts(cursor_id,3); reset role;
  perform public.premium_fixture_assert(premium_translation_private.exact_object(page,array['schemaVersion','entityIds','nextCursor']),'list exact response exposes no source/payload');
  perform public.premium_fixture_assert(jsonb_array_length(page->'entityIds') between 1 and 3,'list requested bounded page size');
  seen:=seen||(page->'entityIds'); n:=n+1;
  if n=1 then
   select id into last_expected from public.premium_translation_working_drafts where entity_type='site_copy' order by id offset 2 limit 1;
   perform public.premium_fixture_assert(page->>'nextCursor'=last_expected::text,'list cursor is last visible draft UUID');
   insert into public.premium_fixture_saved values('site-copy-list-page-1',page);
  end if;
  exit when page->'nextCursor'='null'::jsonb;
  cursor_id:=(page->>'nextCursor')::uuid;
  if n>4 then raise exception 'Unexpected pagination loop'; end if;
 end loop;
 perform public.premium_fixture_assert(n=4 and seen=expected,'keyset list visits all eleven candidate identities once in draft order');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts(null,0)','22023');
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts(null,11)','22023');
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts(null,null)','22023');
 page:=public.list_site_copy_premium_translation_working_drafts(null,10);
 perform public.premium_fixture_assert(jsonb_array_length(page->'entityIds')=10 and page->>'nextCursor' is not null,'list max ten page has continuation');
 insert into public.premium_fixture_saved values('site-copy-list-max-page',page);
 page:=public.list_site_copy_premium_translation_working_drafts((page->>'nextCursor')::uuid,10);
 perform public.premium_fixture_assert(jsonb_array_length(page->'entityIds')=1 and page->'nextCursor'='null'::jsonb,'list final page has exact null cursor');
 insert into public.premium_fixture_saved values('site-copy-list-max-last-page',page);
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(b)=before_canonical from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'read-only list canonical unchanged');
 perform public.premium_fixture_assert((select count(*)=audit_count from public.admin_audit_log),'read-only list audit unchanged');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'read-only list outbox unchanged');
 for d in select premium_translation_private.dto(c) from public.premium_translation_working_drafts c where entity_type='site_copy' loop
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_discard(d); reset role;
 end loop;
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 page:=public.list_site_copy_premium_translation_working_drafts();
 perform public.premium_fixture_assert(page='{"schemaVersion":1,"entityIds":[],"nextCursor":null}'::jsonb,'empty list exact null cursor');
 insert into public.premium_fixture_saved values('site-copy-list-empty',page);
 a:=public.site_copy_fixture_args(); identity:='ABCDEFAB-CDEF-4ABC-8DEF-ABCDEFABCDEF';
 a:=jsonb_set(jsonb_set(jsonb_set(a,'{identity}',to_jsonb(identity)),'{sourceRevision,blockId}',to_jsonb(identity)),'{targetRevision,id}',to_jsonb(identity));
 d:=public.premium_fixture_stage(a)->'draft';
 page:=public.list_site_copy_premium_translation_working_drafts();
 perform public.premium_fixture_assert(page->'entityIds'=jsonb_build_array(identity),'list retains stored UUID identity case for exact get');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('site_copy',identity)->'draft'=d,'listed uppercase identity remains exactly readable');
 insert into public.premium_fixture_saved values('site-copy-list-uppercase',page);
 perform public.premium_fixture_discard(d);
end; $$;
select 'M07_SITE_COPY_NATIVE_READONLY_DISCOVERY_PAGING_PASS';

create function public.site_copy_fixture_reject_update() returns trigger language plpgsql set search_path='' as $$
begin raise exception using errcode='P0099',message='controlled canonical failure'; end; $$;
do $$ declare a jsonb; d jsonb; before_row jsonb; audit_count bigint; begin
 a:=public.site_copy_fixture_args(); set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(a)->'draft'; reset role;
 select to_jsonb(b) into before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 select count(*) into audit_count from public.admin_audit_log;
 truncate public.premium_fixture_outbox;
 create trigger site_copy_fixture_reject_update before update on public.homepage_blocks for each row execute function public.site_copy_fixture_reject_update();
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'P0099'); reset role;
 drop trigger site_copy_fixture_reject_update on public.homepage_blocks;
 perform public.premium_fixture_assert((select to_jsonb(b)=before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'failed promotion rolls back canonical');
 perform public.premium_fixture_assert((select count(*)=audit_count from public.admin_audit_log),'failed promotion rolls back audit');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'failed promotion rolls back outbox');
 perform public.premium_fixture_assert((select premium_translation_private.dto(c)=d from public.premium_translation_working_drafts c where id=(d->>'id')::uuid),'failed promotion retains exact private candidate');
 insert into public.premium_fixture_saved values('site-copy-lock-candidate',d);
end; $$;
select 'M07_SITE_COPY_NATIVE_ROLLBACK_PASS';

select 'M07_SITE_COPY_NATIVE_SUMMARY',jsonb_build_object('groups',11,'providerCalls',0,'managedAuthPostgrest',false);
