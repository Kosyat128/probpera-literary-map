import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const repo=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map`;
const work=path.resolve(repo,'../work/writer-operation-sql-native');
const out=path.resolve(repo,'../work/writer-operation-sql-evidence-20261029-sol');
const hash=x=>createHash('sha256').update(x).digest('hex');
const readJson=name=>JSON.parse(fs.readFileSync(path.join(work,name),'utf8').replace(/^\uFEFF/,''));
const manifest=readJson('source-manifest.json');
const receipts=readJson('native-receipts.json');
const native=readJson('native-functions.json');
const migration=fs.readFileSync(path.join(repo,'supabase/migrations/20261029202308_writer_translation_operation_admission.sql'),'utf8');
const nativeBinding=native.map(fn=>{
 const unqualified=fn.name.slice(0,fn.name.indexOf('('));
 const name=unqualified.includes('.')?unqualified:'public.'+unqualified;
 const start=migration.indexOf('create function '+name+'(');
 const bodyStart=migration.indexOf('as $$',start)+5;
 const bodyEnd=migration.indexOf('$$;',bodyStart);
 if(start<0||bodyStart<5||bodyEnd<0)throw Error('Native function absent from migration '+name);
 const exact=migration.slice(bodyStart,bodyEnd);
 if(exact!==fn.source)throw Error('Native function differs from migration '+name);
 return {name:fn.name,bodySha256:hash(exact),searchPathPinned:fn.config?.includes('search_path=""'),securityDefiner:fn.securityDefiner};
});
const advisorText=fs.readFileSync(path.join(work,'security-advisors.log'),'utf8').replace(/^\uFEFF/,'');
const advisor=JSON.parse(advisorText.split(/\r?\n/).find(line=>line.startsWith('{')));
const ownNames=new Set(native.map(fn=>fn.name.slice(0,fn.name.indexOf('(')).split('.').at(-1)));
const ownFindings=advisor.results.filter(x=>ownNames.has(x.metadata?.name)||x.metadata?.name==='writer_operation_artifacts');
if(ownFindings.length)throw Error('New production schema advisor findings '+JSON.stringify(ownFindings));
const summary={atUtc:new Date().toISOString(),scope:'Isolated PostgreSQL17.11 synthetic native writer admission protocol; no provider, managed API, production, credentials or service creation',
 migrationSha256:hash(migration),fixtureSha256:hash(fs.readFileSync(path.join(repo,'scripts/database/fixtures/writer-translation-operation-admission.sql'))),
 nativeFixture:{exitCode:0,labels:Object.keys(receipts),labelCount:Object.keys(receipts).length,oldPrivateFixtures:'executed unchanged before new controls'},
 actualConcurrentAdmissions:{...readJson('native-concurrent-count.json'),...readJson('concurrent-receipts.json')},
 nativeFunctionSourceBinding:nativeBinding,
 advisors:{...readJson('advisors-lint-receipt.json'),findingCount:advisor.results.length,newProductionFindings:ownFindings,
  inheritedFixtureFindings:advisor.results.map(x=>({name:x.name,level:x.level,object:x.metadata?.schema+'.'+x.metadata?.name}))},
 cleanup:[readJson('new-cleanup.json'),readJson('export-cleanup.json')],
 boundaries:[
  'Existing jobs/items/attempts remain operational metadata only; private raw responses do not establish validated candidate status.',
  'Unknown admissions do not expire; a lost dispatch ACK can conservatively block an unsent request. No provider billing/acceptance/exactly-once delivery claim.',
  'Partial pass replay, failed-only retries, durable scan stabilization and T13 operator recovery UI are deferred.',
  'Security advisors exit1 is retained for inherited synthetic fixture findings, not reported as PASS. plpgsql_check is absent; database lint was NOT RUN and nothing was installed.',
  'Privileged database owner is outside the trigger threat boundary; current authenticated ACL and service direct journal tamper controls execute in native fixture.',
  'Portable source replay requires the documented pre-existing local PG/Node/CLI tool entry points; no dependencies or tool binaries are included.'
 ]};
fs.writeFileSync(path.join(work,'native-summary.json'),JSON.stringify(summary,null,2));
fs.mkdirSync(out,{recursive:true});
for(const file of ['build-probe.mjs','pack-evidence.mjs','run-probe.ps1','concurrent-and-export.ps1','fixture.sql','source-manifest.json','new-run.log',
 'native-receipts.json','native-artifacts.json','native-functions.json','native-concurrent-count.json','native-summary.json','concurrent-session.sql',
 'concurrent-1.stdout.log','concurrent-2.stdout.log','concurrent-1.stderr.log','concurrent-2.stderr.log','concurrent-receipts.json',
 'security-advisors.log','advisors-lint-receipt.json','new-cleanup.json','export-cleanup.json','new-cleanup.log','export-cleanup.log']){
 fs.copyFileSync(path.join(work,file),path.join(out,file));
}
const sourceMap=new Map([...manifest.foundation.sources,...manifest.sources].map(s=>[s.file,s]));
for(const source of sourceMap.values()){
 const bytes=fs.readFileSync(path.join(repo,source.file));if(hash(bytes)!==source.sha256)throw Error('Source drift '+source.file);
 const target=path.join(out,'sources',source.file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes);
}
const original=path.resolve(repo,'../work/site-copy-sql-native');
fs.mkdirSync(path.join(out,'foundation'),{recursive:true});
for(const file of ['fixture.sql','fixture-manifest.json'])fs.copyFileSync(path.join(original,file),path.join(out,'foundation',file));
fs.copyFileSync(path.resolve(repo,'../work/build-site-copy-native-fixture.mjs'),path.join(out,'foundation','build-site-copy-native-fixture.mjs'));
fs.writeFileSync(path.join(out,'README.txt'),`Writer provider admission native evidence, 2026-10-29, GPT-6.1 Sol Ultra\n\nActual final v7 fixture exit0, ${summary.nativeFixture.labelCount} result groups plus two independent concurrent psql sessions (one admission, one blocked, exactly one active item). Full native function bodies match the CLI-generated additive migration. Existing immutable source SQL and byte-unchanged legacy private fixtures execute in the disposable database.\n\nRead native-summary.json for exact boundaries. Advisors FAIL findings belong to the inherited synthetic local fixture; zero new production-schema findings. SQL lint NOT RUN: portable PG has no plpgsql_check, none installed. No paid/network/provider/managed API/prod run.\n\nReplay: build-probe.mjs documents original repo/parentwork paths and dependencies; sources/ includes exact input bytes and foundation/ includes frozen original fixture. Rebase its repo/out paths to extracted sources and owned scratch, and supply owned portable PG17 / local Supabase CLI paths. run-probe.ps1 refuses an existing database or live/reused foreign PID, then starts loopback only, verifies data_directory, runs fixture and stops exact owned PID in finally. concurrent-and-export.ps1 opens the same owned synthetic database for two sessions and metadata/advisor exports, then stops it. No DB data, deps, binaries, credentials or CLI state included.\n`);
const files=[];
function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,entry.name);if(entry.isDirectory())walk(f);else{const b=fs.readFileSync(f);files.push({file:path.relative(out,f).replaceAll('\\','/'),bytes:b.length,sha256:hash(b)});}}}
walk(out);files.sort((a,b)=>a.file.localeCompare(b.file));
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),files,sourceCount:sourceMap.size},null,2));
console.log(JSON.stringify({out,fileCount:files.length,sourceCount:sourceMap.size,nativeFunctions:nativeBinding.length,labels:summary.nativeFixture.labelCount,advisorFindings:advisor.results.length,newProductionFindings:ownFindings.length}));
