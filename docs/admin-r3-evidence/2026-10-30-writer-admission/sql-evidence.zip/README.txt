Writer provider admission native evidence, 2026-10-29, GPT-6.1 Sol Ultra

Actual final v7 fixture exit0, 12 result groups plus two independent concurrent psql sessions (one admission, one blocked, exactly one active item). Full native function bodies match the CLI-generated additive migration. Existing immutable source SQL and byte-unchanged legacy private fixtures execute in the disposable database.

Read native-summary.json for exact boundaries. Advisors FAIL findings belong to the inherited synthetic local fixture; zero new production-schema findings. SQL lint NOT RUN: portable PG has no plpgsql_check, none installed. No paid/network/provider/managed API/prod run.

Replay: build-probe.mjs documents original repo/parentwork paths and dependencies; sources/ includes exact input bytes and foundation/ includes frozen original fixture. Rebase its repo/out paths to extracted sources and owned scratch, and supply owned portable PG17 / local Supabase CLI paths. run-probe.ps1 refuses an existing database or live/reused foreign PID, then starts loopback only, verifies data_directory, runs fixture and stops exact owned PID in finally. concurrent-and-export.ps1 opens the same owned synthetic database for two sessions and metadata/advisor exports, then stops it. No DB data, deps, binaries, credentials or CLI state included.
