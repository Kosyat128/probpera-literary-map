import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const repo=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map`;
const out=path.resolve(repo,'../work/writer-operation-sql-native');
const sha=x=>createHash('sha256').update(x).digest('hex');
const site=path.resolve(repo,'../work/site-copy-sql-native');
const manifest=JSON.parse(fs.readFileSync(path.join(site,'fixture-manifest.json'),'utf8'));
for(const s of manifest.sources)if(sha(fs.readFileSync(path.join(repo,s.file)))!==s.sha256)throw Error('Frozen native source drift '+s.file);
let foundation=fs.readFileSync(path.join(site,'fixture.sql'),'utf8');
if(sha(foundation)!==manifest.sqlSha256)throw Error('Frozen native fixture bytes changed');
foundation=foundation.replace(/^create role (anon|authenticated|service_role).*;\r?\n/gm,'');
const sources=[];
const read=file=>{const bytes=fs.readFileSync(path.join(repo,file));sources.push({file,sha256:sha(bytes)});const dst=path.join(out,'sources',file);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,bytes);return bytes.toString('utf8');};
const sql=[foundation,...[
 'supabase/migrations/20260901_zz_translation_operations.sql',
 'supabase/migrations/20260901_zz_translation_operations_runtime.sql',
 'supabase/migrations/20261007235851_admin_article_translation_scan_completion.sql',
 'supabase/migrations/20261008005802_admin_article_translation_item_retry.sql',
 'supabase/migrations/20261008021735_admin_article_translation_item_retry_journal.sql',
 'supabase/migrations/20261008031428_admin_article_translation_item_retry_candidate.sql',
 'supabase/migrations/20261008043647_admin_article_machine_english_draft.sql',
 'supabase/migrations/20261008082627_admin_article_translation_sync_admission.sql',
 'supabase/migrations/20261029194216_profile_translation_operation_budget.sql',
 'supabase/migrations/20261029202308_writer_translation_operation_admission.sql',
 'scripts/database/fixtures/writer-translation-operation-admission.sql',
].map(read)].join('\n');
fs.writeFileSync(path.join(out,'fixture.sql'),sql);
fs.writeFileSync(path.join(out,'source-manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),sources,foundation:manifest,foundationSha256:manifest.sqlSha256,fixtureSha256:sha(sql)},null,2));
let runner=fs.readFileSync(path.resolve(repo,'../work/profile-budget-sql-native/run-new-probe.ps1'),'utf8');
runner=runner.replaceAll('profile-budget-sql-native','writer-operation-sql-native').replaceAll('profile_budget_new_20261029',process.argv[2]||'writer_operations_v1_20261029').replaceAll('new-fixture.sql','fixture.sql');
fs.writeFileSync(path.join(out,'run-probe.ps1'),runner);
console.log(JSON.stringify({out,sources:sources.length,fixtureSha256:sha(sql)}));
