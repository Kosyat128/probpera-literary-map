NEXT UNRESOLVED BEFORE: library + country unknown-provider-result admission, GPT-6.1 Sol Ultra

This archive reproduces an outstanding defect; it is NOT current acceptance PASS. Each actual batch action uses the actual helper (library safe wrapper included), structural/ownership/source validators, premium translator+reviewer, budgets, installed Supabase SDK and native Next redirect. One eligible source plus one protected manual-English sentinel isolate the target.

For BOTH kinds, the first controlled request is accepted then loses delivery. A fresh actual action on identical canonical/source revisions makes TWO additional same-source calls (translation+review). There is no pre-dispatch durable identity; only a later dead_letter run summary. Canonical authored RU/EN, manual text, all source/rights/custom metadata and revision tokens remain exact. No canonical machine write or public build occurs.

Execution/preservation/binding failures=0. Immutable SAME control failures=0, target failures=4 (two per kind), all diagnostic/contract exit codes=1 by design. The original and frozen replay have exact graph hashes and identical controlled request/source/pass traces. Library17 modules; country16. Actual caps remain library4/16 and country2/8; writer code is outside this fixture.

Replay entry point (Node v24.18.1 and already-installed repository dependencies required; no installation/network):
  Set NEXT_ADMISSION_REPO to the repository with package.json/node_modules.
  Set NEXT_ADMISSION_OUTPUT_ROOT to a fresh output folder.
  For frozen sources set NEXT_LIBRARY_SOURCE_ROOT=<archive>/diagnostic-before/library/raw-graph/sources and NEXT_COUNTRY_SOURCE_ROOT=<archive>/diagnostic-before/country/raw-graph/sources.
  Run node admission-loss-diagnostic.cjs (expected exit1, executionFailures0, targetFailures4).
  Run node admission-loss.same-contract.cjs <new-output>/report.json <fresh-acceptance.json> (expected exit1, controlFailures0,targetFailures4).
No process environment credentials are passed into the actual source loader. Auth/session, catalog, in-memory PostgREST transport and AI binding are synthetic. global fetch and unhandled source boundaries fail closed. No real provider/DB/Auth/RLS/browser/build/social/production request is executed.

The immutable SAME invariant contract is separate from the defect-specific diagnostic. A future CURRENT harness must explicitly document boundary/observation changes and freeze their source delta; never call a modified whole diagnostic an identical replay. Raw provider responses, budgets and final private staging here are controlled transport receipts, not native database acceptance. The support/*.cjs files are byte-for-byte original maintained budget fixture declarations: only their declaration prefixes are reused, before their original main/assertions.

See provenance.json for exact source/package bindings and package-manifest.json for every archived file hash. No binaries, node_modules, secrets or database data are included. Root retains ownership of checkpoint/README documentation; this task adds only the requested evidence ZIP and JSON manifest/receipt to docs.
