const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {createRequire}=require('node:module');
const {execFileSync}=require('node:child_process');
const repo=path.resolve(process.env.NEXT_ADMISSION_REPO||path.join(__dirname,'../../probpera-literary-map'));
const output=path.resolve(process.env.NEXT_ADMISSION_OUTPUT_ROOT||path.join(__dirname,'diagnostic-before'));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
assert.equal(fs.existsSync(output),false,'Never overwrite original diagnostic evidence');
fs.mkdirSync(output,{recursive:true});
const nativeRequire=createRequire(path.join(repo,'package.json'));
const {createClient}=nativeRequire('@supabase/supabase-js');
const {isRedirectError}=nativeRequire('next/dist/client/components/redirect-error');
const {getURLFromRedirectError}=nativeRequire('next/dist/client/components/redirect');
const response=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json'}});
const checks=[];
const record=(kind,name,category,body)=>{try{body();checks.push({kind,name,category,pass:true});}catch(error){checks.push({kind,name,category,pass:false,error:error.stack||String(error)});}};
const packages=['@supabase/supabase-js','typescript','next','zod'].map(name=>{
 const packagePath=path.join(repo,'node_modules',name,'package.json'),bytes=fs.readFileSync(packagePath);
 return{name,version:JSON.parse(bytes).version,packagePath,packageSha256:sha(bytes)};
});
const cases=[];
async function runCase(kind){
 const sourceRoot=path.resolve(process.env[kind==='library'?'NEXT_LIBRARY_SOURCE_ROOT':'NEXT_COUNTRY_SOURCE_ROOT']||repo);
 const caseOutput=path.join(output,kind);fs.mkdirSync(caseOutput);
 const support=path.join(__dirname,'support',kind+'-budget.cjs'),supportBytes=fs.readFileSync(support),supportText=supportBytes.toString();
 const expected=kind==='library'?'2b83662ac50f9c94d35c86e4a18ee5f778553bfaaddaa6e0f1cf7b7dadeefe22':'0599ab41ec2102a8db45a8a9716f9dad9564c04c9bafea8cb7d79236fcb8e377';
 assert.equal(sha(supportBytes),expected,'Exact original maintained budget fixture declarations');
 const boundary=supportText.indexOf('\nasync function main()');assert.ok(boundary>0);
 const fixtureProcess={env:kind==='library'?{LIBRARY_BUDGET_REPO:repo,LIBRARY_BUDGET_SOURCE_ROOT:sourceRoot,LIBRARY_BUDGET_OUTPUT_ROOT:path.join(caseOutput,'raw-graph')}
  :{COUNTRY_BUDGET_REPO:repo,COUNTRY_BUDGET_SOURCE_ROOT:sourceRoot,COUNTRY_BUDGET_OUTPUT_ROOT:path.join(caseOutput,'raw-graph')}};
 const exports=kind==='library'?'entries,description':'countries,russian,english';
 const runtime=new Function('require','__dirname','__filename','process',supportText.slice(0,boundary)+
  '\nreturn {load,mocks,ai,fetchBoundary,graph,wire,runs,writes,builds,revalidations,actorId,stamp,'+exports+'};')
  (require,path.dirname(support),support,fixtureProcess);
 if(kind==='library'){
  runtime.entries.splice(2);
  runtime.entries[1].english.translation_method='human-translation';
  runtime.entries[1].english.metadata.manualRights={holder:'Synthetic manual author',permission:'Keep exact manual English'};
 }else{
  runtime.countries.splice(2);
  runtime.countries[1].row.fields.translations.en.method='human-translation';
  runtime.countries[1].row.fields.translations.en.manualRights={holder:'Synthetic manual author',permission:'Keep exact manual English'};
  runtime.mocks['@/lib/editorial-catalog']={async loadEditorialCatalog(){return{version:1,countries:structuredClone(runtime.countries.map(({id,label,fields})=>({id,label,fields})))}}};
 }
 const canonical=()=>structuredClone(kind==='library'?runtime.entries:runtime.countries);
 const before=canonical(),providerCalls=[],timeline=[],audits=[],stages=[],snapshots=[],privateCandidates=new Map();
 const targetId=kind==='library'?runtime.entries[0].work.id:runtime.countries[0].id;
 const manualId=kind==='library'?runtime.entries[1].work.id:runtime.countries[1].id;
 let phase='setup',serial=0,journalSerial=0;
 const fetchBoundary=async(resource,init={})=>{
  const url=new URL(typeof resource==='string'?resource:resource.url);
  assert.equal(url.origin,`https://${kind}-budget.fixture.invalid`,'No external source/DB origin is reachable');
  const method=init.method||'GET',name=url.pathname.split('/').at(-1),body=init.body?JSON.parse(init.body):null;
  timeline.push({phase,event:'sdk-boundary',method,name});
  const track=()=>runtime.wire.push({method,path:url.pathname,query:Object.fromEntries(url.searchParams),body:structuredClone(body)});
  if(name==='profile_translation_budget_ready'){track();return response(true);}
  if(name==='get_premium_translation_working_draft'){
   track();return response({schemaVersion:1,entityType:body.p_entity_type,entityId:body.p_entity_id,draft:privateCandidates.get(body.p_entity_type+':'+body.p_entity_id)||null});
  }
  if(name==='stage_premium_translation_working_draft'){
   track();const key=body.p_entity_type+':'+body.p_entity_id;
   assert.equal(privateCandidates.has(key),false,'Private candidates are never silently replaced');
   const draft={id:'12345678-1234-4234-8234-000000000001',version:1,entityType:body.p_entity_type,entityId:body.p_entity_id,
    targetLocale:'en',humanReview:'pending',sourceHash:body.p_source_hash,candidateHash:sha(JSON.stringify(body)),
    sourceSnapshot:body.p_source_snapshot,sourceRevision:body.p_source_revision,targetRevision:body.p_target_revision,
    payload:body.p_payload,provenance:body.p_provenance,createdAt:new Date().toISOString(),createdBy:runtime.actorId};
   privateCandidates.set(key,structuredClone(draft));stages.push({phase,body:structuredClone(body)});
   return response({schemaVersion:1,entityType:draft.entityType,entityId:draft.entityId,draft});
  }
  if(name==='admin_audit_log'&&method==='POST'){track();audits.push({phase,body:structuredClone(body)});return response(null,201);}
  const result=await runtime.fetchBoundary(resource,init);
  if(name==='record_translation_sync_run'){
   timeline.push({phase,event:'posthoc-run-record'});
   return response(`cccccccc-cccc-4ccc-8ccc-${String(++journalSerial).padStart(12,'0')}`);
  }
  return result;
 };
 const sdk=createClient(`https://${kind}-budget.fixture.invalid`,'synthetic-no-auth-session',{
  auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},global:{fetch:fetchBoundary}});
 runtime.mocks['@/lib/supabase/server']={async createServerSupabaseClient(){return sdk;}};
 runtime.ai.run=async(model,input)=>{
  const content=JSON.parse(input.messages[1].content),source=content.SOURCE_DATA;
  const row=kind==='library'?runtime.entries.find(e=>e.russian.title===source.russianTitle):runtime.countries.find(e=>e.fields.name===source.name);
  assert.ok(row,'Actual validated provider source identifies a fixture entity');
  const entityId=kind==='library'?row.work.id:row.id;
  assert.equal(entityId,targetId,'Protected manual-English sentinel must never reach the provider');
  if(kind==='library'){
   assert.equal(source.verifiedEnglishTitle,row.english.title);
   assert.equal(source.verifiedEnglishTitleSourceUrl,row.sources[0].source_url);
   assert.deepEqual(source.sourceUrls,row.russian.source_urls);
  }
  const pass=Object.hasOwn(content,'INVALID_DRAFT_TRANSLATION')?'repair':Object.hasOwn(content,'DRAFT_TRANSLATION')?'review':'translation';
  const call={phase,serial:++serial,entityId,model,pass,source:structuredClone(source),sourceSha256:sha(JSON.stringify(source)),
   requestSha256:sha(JSON.stringify(input)),acceptedByControlledBoundary:true,delivery:serial===1?'lost-after-acceptance':'returned'};
  providerCalls.push(call);timeline.push({phase,event:'controlled-provider-accepted',serial:call.serial,entityId,pass});
  if(serial===1){const error=new Error('Controlled request accepted; response delivery lost');error.name='TimeoutError';throw error;}
  return{id:`controlled-${kind}-admission-${serial}`,response:JSON.stringify(kind==='library'?{description:runtime.description}:row.generated),usage:{prompt_tokens:10,completion_tokens:10}};
 };
 const actionFile=kind==='library'?'apps/admin/app/(dashboard)/translations/actions.ts':'apps/admin/app/(dashboard)/translations/country-actions.ts';
 const actionName=kind==='library'?'translatePremiumLibraryBatchAction':'translatePremiumCountryBatchAction';
 const actions=runtime.load(actionFile);
 const invoke=async label=>{
  phase=label;const callsBefore=providerCalls.length,runsBefore=runtime.runs.length;let redirect;
  try{await actions[actionName](new FormData());throw Error('Actual action returned without a native redirect');}
  catch(error){assert.equal(isRedirectError(error),true,error.stack);redirect=getURLFromRedirectError(error);}
  const result={phase,redirect,params:Object.fromEntries(new URL(redirect,'https://fixture.invalid').searchParams),
   addedProviderCalls:providerCalls.length-callsBefore,addedSameSourceCalls:providerCalls.slice(callsBefore).filter(c=>c.entityId===targetId).length,
   newRuns:structuredClone(runtime.runs.slice(runsBefore)),privateCandidates:privateCandidates.size,stages:stages.length};
  snapshots.push(result);return result;
 };
 const first=await invoke('first-action');
 record(kind,'First actual action accepts one request then loses response delivery','execution',()=>{
  assert.equal(first.addedProviderCalls,1);assert.equal(providerCalls[0].delivery,'lost-after-acceptance');
  assert.equal(first.privateCandidates,0);assert.equal(first.stages,0);assert.equal(first.newRuns.length,1);
  assert.ok(first.newRuns[0].p_outcomes.some(o=>o.status==='dead_letter'));
 });
 record(kind,'First failure preserves full canonical/source/revision/manual/rights data','preservation',()=>assert.deepEqual(canonical(),before));
 const second=await invoke('second-fresh-action');
 record(kind,'Both invocations finish with native redirects and no missing boundary','execution',()=>{
  assert.equal(snapshots.length,2);assert.ok(snapshots.every(s=>s.redirect.includes('/translations')));
  assert.ok(snapshots.every(s=>s.params.errorCode!=='translation_run_record_unconfirmed'));
 });
 record(kind,'Diagnostic observes two real premium passes of only the same source','diagnostic',()=>{
  assert.equal(second.addedProviderCalls,2);assert.equal(second.addedSameSourceCalls,2);
  assert.deepEqual(providerCalls.slice(1).map(c=>c.pass),['translation','review']);
  assert.ok(providerCalls.every(c=>c.entityId===targetId&&c.sourceSha256===providerCalls[0].sourceSha256));
  assert.equal(providerCalls[1].requestSha256,providerCalls[0].requestSha256);
  assert.equal(second.privateCandidates,1);assert.equal(second.stages,1);
 });
 record(kind,'Canonical manual EN/RU/sources/rights/revisions remain exact and no public build occurs','preservation',()=>{
  assert.deepEqual(canonical(),before);assert.equal(runtime.writes.length,0);assert.equal(runtime.builds.length,0);
  assert.equal(providerCalls.filter(c=>c.entityId===manualId).length,0);
 });
 record(kind,'NEXT target: fresh identical-source invocation must dispatch zero new requests','target',()=>assert.equal(second.addedSameSourceCalls,0));
 record(kind,'NEXT target: durable operation identity must exist before provider dispatch','target',()=>{
  const accepted=timeline.findIndex(e=>e.event==='controlled-provider-accepted');
  assert.ok(timeline.slice(0,accepted).some(e=>e.event==='sdk-boundary'&&e.method==='POST'&&/begin|dispatch|admission/iu.test(e.name)));
 });
 const sources=[...runtime.graph.values()].sort((a,b)=>a.module.localeCompare(b.module));
 record(kind,'Executed source graph capture equals actual source before and after run','binding',()=>{
  for(const s of sources){assert.equal(sha(fs.readFileSync(path.join(sourceRoot,s.module))),s.sha256);assert.equal(sha(fs.readFileSync(path.join(caseOutput,'raw-graph/sources',s.module))),s.sha256);}
 });
 const ownChecks=checks.filter(c=>c.kind===kind);
 const result={kind,mode:'NEXT UNRESOLVED BEFORE defect reproduction, never current acceptance PASS',checkedAt:new Date().toISOString(),sourceRoot,
  targetId,manualId,checks:ownChecks,executionFailures:ownChecks.filter(c=>!c.pass&&c.category!=='target').length,
  targetFailures:ownChecks.filter(c=>!c.pass&&c.category==='target').length,providerCalls,snapshots,timeline,audits,stages,wire:runtime.wire,
  canonicalBefore:before,canonicalAfter:canonical(),canonicalMachineWrites:runtime.writes.length,publicBuildRequests:runtime.builds.length,
  sources,sourceCount:sources.length,packages,supportSha256:sha(supportBytes),fixtureSha256:sha(fs.readFileSync(__filename)),
  limitations:['Actual action/helper/safe wrapper/validators/premium runtime/probe/budgets/SDK/native Next redirect execute; no helper/provider algorithm stubs.',
   'Auth/catalog/PostgREST/provider transport are controlled; acceptance then immediate TimeoutError models lost delivery, not a real invoice or wall-clock timeout.',
   'One eligible source and one protected manual-English sentinel isolate only same-source repeats. No intentional CAS drift or authored-data mutation.',
   'No real network/provider/Auth/database/RLS/public build/production/environment provisioning. This is unresolved BEFORE evidence, not acceptance of library/country durability.']};
 fs.writeFileSync(path.join(caseOutput,'report.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 fs.writeFileSync(path.join(caseOutput,'manifest.json'),JSON.stringify({kind,sources,packages,supportSha256:result.supportSha256,fixtureSha256:result.fixtureSha256},null,2)+'\n',{flag:'wx'});
 cases.push(result);
}
(async()=>{
 for(const kind of ['library','country'])await runCase(kind);
 const report={mode:'NEXT UNRESOLVED BEFORE; target failures preserved',checkedAt:new Date().toISOString(),head:execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim(),
  node:process.version,cases,executionFailures:cases.reduce((n,c)=>n+c.executionFailures,0),targetFailures:cases.reduce((n,c)=>n+c.targetFailures,0),fixtureSha256:sha(fs.readFileSync(__filename))};
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({output,executionFailures:report.executionFailures,targetFailures:report.targetFailures,cases:cases.map(c=>({kind:c.kind,sources:c.sourceCount,calls:c.providerCalls.length,first:c.snapshots[0].addedSameSourceCalls,fresh:c.snapshots[1].addedSameSourceCalls,executionFailures:c.executionFailures,targetFailures:c.targetFailures}))},null,2));
 process.exitCode=report.executionFailures?2:report.targetFailures?1:0;
})().catch(error=>{fs.writeFileSync(path.join(output,'diagnostic-error.json'),JSON.stringify({error:error.stack||String(error),cases},null,2));console.error(error.stack||error);process.exitCode=2;});
