const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=__dirname,repo=path.resolve(root,'../../probpera-literary-map');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const read=file=>JSON.parse(fs.readFileSync(path.join(root,file),'utf8'));
const original=read('diagnostic-before/report.json'),replay=read('frozen-before-replay/report.json');
const acceptance=read('same-before-acceptance.json'),frozenAcceptance=read('same-frozen-acceptance.json');
assert.equal(original.executionFailures,0);assert.equal(replay.executionFailures,0);
assert.equal(original.targetFailures,4);assert.equal(replay.targetFailures,4);
for(const result of [acceptance,frozenAcceptance]){assert.equal(result.controlFailures,0);assert.equal(result.targetFailures,4);}
for(const file of ['diagnostic-before.exit.txt','frozen-before-replay.exit.txt','same-before-acceptance.exit.txt','same-frozen-acceptance.exit.txt'])assert.equal(fs.readFileSync(path.join(root,file),'utf8').trim(),'1');
const cases=[];
for(const kind of ['library','country']){
 const before=original.cases.find(c=>c.kind===kind),after=replay.cases.find(c=>c.kind===kind);
 assert.deepEqual(before.sources,after.sources);assert.equal(before.fixtureSha256,after.fixtureSha256);
 assert.equal(before.supportSha256,after.supportSha256);
 assert.deepEqual(before.canonicalBefore,before.canonicalAfter);assert.deepEqual(after.canonicalBefore,after.canonicalAfter);
 assert.deepEqual(before.canonicalBefore,after.canonicalBefore);
 const trace=r=>r.providerCalls.map(({phase,entityId,pass,model,sourceSha256,requestSha256,delivery,acceptedByControlledBoundary})=>({phase,entityId,pass,model,sourceSha256,requestSha256,delivery,acceptedByControlledBoundary}));
 assert.deepEqual(trace(before),trace(after));
 const manual=before.canonicalBefore.find(value=>kind==='library'?value.work.id===before.manualId:value.id===before.manualId);
 const manualEnglish=kind==='library'?manual.english:manual.row.fields.translations.en;
 assert.equal(kind==='library'?manualEnglish.translation_method:manualEnglish.method,'human-translation');
 assert.equal((kind==='library'?manualEnglish.metadata:manualEnglish).manualRights.permission,'Keep exact manual English');
 const bindings=before.sources.map(source=>{
  const currentSha256=sha(fs.readFileSync(path.join(repo,source.module)));
  const capturedSha256=sha(fs.readFileSync(path.join(root,'diagnostic-before',kind,'raw-graph/sources',source.module)));
  const replaySha256=sha(fs.readFileSync(path.join(root,'frozen-before-replay',kind,'raw-graph/sources',source.module)));
  assert.equal(currentSha256,source.sha256);assert.equal(capturedSha256,source.sha256);assert.equal(replaySha256,source.sha256);
  return{...source,currentSha256,capturedSha256,replaySha256};
 });
 const budgetKey=kind==='library'?'libraryBudget':'countryBudget';
 cases.push({kind,sourceCount:bindings.length,graphAggregateSha256:sha(JSON.stringify(before.sources)),bindings,
  firstAcceptedLostCalls:before.snapshots[0].addedSameSourceCalls,freshSameSourceCalls:before.snapshots[1].addedSameSourceCalls,
  totalControlledProviderCalls:before.providerCalls.length,sourcePayloadAndRequestTracesIdenticalOnFrozenReplay:true,
  runtimeExecutionFailures:0,invariantControlFailures:0,invariantTargetFailures:2,
  canonicalManualSourceRightsAndRevisionsExact:true,canonicalMachineWrites:0,publicBuildRequests:0,
  actualBudgetFirst:before.snapshots[0].newRuns[0].p_resume_cursor[budgetKey],actualBudgetFresh:before.snapshots[1].newRuns[0].p_resume_cursor[budgetKey],
  actualBibliographicReads:kind==='library'?before.wire.filter(w=>w.method==='GET'&&w.path.endsWith('/literary_work_sources')).map(w=>({path:w.path,query:w.query})):undefined});
}
const provenance={checkedAt:new Date().toISOString(),head:original.head,mode:'NEXT UNRESOLVED BEFORE DEFECT REPRODUCTION; NOT CURRENT ACCEPTANCE PASS',
 immutableContractSha256:acceptance.contractSha256,scenarioSha256:original.fixtureSha256,
 controls:{runtimeExecutionFailures:0,invariantControlFailures:0,targetFailures:4,diagnosticExit:1,frozenReplayExit:1,contractBeforeExit:1,contractFrozenExit:1},
 cases,packages:original.cases[0].packages,
 scope:'Exact executed source graph and immutable SAME invariants only. Concurrent whole-worktree state is not claimed unchanged. Controlled acceptance/lost delivery is not a real provider invoice or network lifecycle.'};
fs.writeFileSync(path.join(root,'provenance.json'),JSON.stringify(provenance,null,2)+'\n',{flag:'wx'});
fs.writeFileSync(path.join(root,'README.txt'),`NEXT UNRESOLVED BEFORE: library + country unknown-provider-result admission, GPT-6.1 Sol Ultra\n\nThis archive reproduces an outstanding defect; it is NOT current acceptance PASS. Each actual batch action uses the actual helper (library safe wrapper included), structural/ownership/source validators, premium translator+reviewer, budgets, installed Supabase SDK and native Next redirect. One eligible source plus one protected manual-English sentinel isolate the target.\n\nFor BOTH kinds, the first controlled request is accepted then loses delivery. A fresh actual action on identical canonical/source revisions makes TWO additional same-source calls (translation+review). There is no pre-dispatch durable identity; only a later dead_letter run summary. Canonical authored RU/EN, manual text, all source/rights/custom metadata and revision tokens remain exact. No canonical machine write or public build occurs.\n\nExecution/preservation/binding failures=0. Immutable SAME control failures=0, target failures=4 (two per kind), all diagnostic/contract exit codes=1 by design. The original and frozen replay have exact graph hashes and identical controlled request/source/pass traces. Library17 modules; country16. Actual caps remain library4/16 and country2/8; writer code is outside this fixture.\n\nReplay entry point (Node v${process.versions.node} and already-installed repository dependencies required; no installation/network):\n  Set NEXT_ADMISSION_REPO to the repository with package.json/node_modules.\n  Set NEXT_ADMISSION_OUTPUT_ROOT to a fresh output folder.\n  For frozen sources set NEXT_LIBRARY_SOURCE_ROOT=<archive>/diagnostic-before/library/raw-graph/sources and NEXT_COUNTRY_SOURCE_ROOT=<archive>/diagnostic-before/country/raw-graph/sources.\n  Run node admission-loss-diagnostic.cjs (expected exit1, executionFailures0, targetFailures4).\n  Run node admission-loss.same-contract.cjs <new-output>/report.json <fresh-acceptance.json> (expected exit1, controlFailures0,targetFailures4).\nNo process environment credentials are passed into the actual source loader. Auth/session, catalog, in-memory PostgREST transport and AI binding are synthetic. global fetch and unhandled source boundaries fail closed. No real provider/DB/Auth/RLS/browser/build/social/production request is executed.\n\nThe immutable SAME invariant contract is separate from the defect-specific diagnostic. A future CURRENT harness must explicitly document boundary/observation changes and freeze their source delta; never call a modified whole diagnostic an identical replay. Raw provider responses, budgets and final private staging here are controlled transport receipts, not native database acceptance. The support/*.cjs files are byte-for-byte original maintained budget fixture declarations: only their declaration prefixes are reused, before their original main/assertions.\n\nSee provenance.json for exact source/package bindings and package-manifest.json for every archived file hash. No binaries, node_modules, secrets or database data are included. Root retains ownership of checkpoint/README documentation; this task adds only the requested evidence ZIP and JSON manifest/receipt to docs.\n`,{flag:'wx'});
const files=[];
function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const full=path.join(dir,e.name);if(e.isDirectory())walk(full);else if(e.name!=='package-manifest.json'){const bytes=fs.readFileSync(full);files.push({file:path.relative(root,full).replaceAll('\\','/'),bytes:bytes.length,sha256:sha(bytes)});}}}
walk(root);files.sort((a,b)=>a.file.localeCompare(b.file));
const manifest={atUtc:new Date().toISOString(),mode:provenance.mode,head:original.head,scenarioSha256:provenance.scenarioSha256,
 immutableContractSha256:provenance.immutableContractSha256,cases:cases.map(({kind,sourceCount,graphAggregateSha256})=>({kind,sourceCount,graphAggregateSha256})),files};
fs.writeFileSync(path.join(root,'package-manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({root,files:files.length,mode:manifest.mode,cases:manifest.cases,controlFailures:0,targetFailures:4},null,2));
