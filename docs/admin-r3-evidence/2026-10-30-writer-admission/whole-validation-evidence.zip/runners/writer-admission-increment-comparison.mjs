import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const work=path.dirname(fileURLToPath(import.meta.url));
const previousFile=path.join(work,'profile-budget-final-validation-v2/source-before.json');
const currentFile=path.join(work,'writer-admission-final-validation-v1/source-before.json');
const previous=JSON.parse(fs.readFileSync(previousFile,'utf8'));
const current=JSON.parse(fs.readFileSync(currentFile,'utf8'));
const sha=b=>createHash('sha256').update(b).digest('hex');
const before=new Map(previous.files.filter(f=>!f.path.startsWith('docs/')).map(f=>[f.path,f]));
const after=new Map(current.files.filter(f=>!f.path.startsWith('docs/')).map(f=>[f.path,f]));
const changed=[...after.values()].filter(f=>before.has(f.path)&&JSON.stringify(before.get(f.path))!==JSON.stringify(f));
const added=[...after.values()].filter(f=>!before.has(f.path));
const removed=[...before.values()].filter(f=>!after.has(f.path));
const expectedChanges=[
 'apps/admin/app/(dashboard)/editorial-database/actions.ts',
 'apps/admin/app/(dashboard)/editorial-database/page.tsx',
 'apps/admin/app/(dashboard)/translations/actions.ts',
 'apps/admin/app/(dashboard)/translations/page.tsx',
 'apps/admin/app/(dashboard)/translations/resume-action.ts',
 'apps/admin/lib/auto-translate-writer-biography.ts',
 'apps/admin/lib/premium-english-translation.ts',
 'apps/admin/lib/fixtures/writer-biography-machine-review.cjs',
 'apps/admin/lib/fixtures/writer-batch-budget-cap.cjs',
 'apps/admin/lib/fixtures/profile-library-budget-controls.cjs',
 'apps/admin/lib/profile-library-batch-budgets.integration.test.ts',
].sort();
const expectedAdditions=[
 'apps/admin/lib/fixtures/writer-admission-boundary.cjs',
 'apps/admin/lib/fixtures/writer-admission-cases.cjs',
 'apps/admin/lib/fixtures/writer-admission-runtime.cjs',
 'apps/admin/lib/translation-response-artifacts.integration.test.ts',
 'apps/admin/lib/writer-translation-operation-rpc.integration.test.ts',
 'apps/admin/lib/writer-admission.integration.test.ts',
 'apps/admin/lib/writer-admission-routing.integration.test.ts',
 'apps/admin/lib/writer-translation-operation-rpc.ts',
 'apps/admin/lib/writer-translation-operation.ts',
 'apps/admin/lib/writer-translation-operation-marker.ts',
 'scripts/database/fixtures/writer-translation-operation-admission.sql',
 'supabase/migrations/20261029202308_writer_translation_operation_admission.sql',
].sort();
assert.deepEqual(changed.map(f=>f.path).sort(),expectedChanges);
assert.deepEqual(added.map(f=>f.path).sort(),expectedAdditions);
assert.deepEqual(removed,[]);
assert.equal(previous.head,current.head);
const result={status:'PASS',capturedAt:new Date().toISOString(),head:current.head,previousManifestSha256:sha(fs.readFileSync(previousFile)),currentManifestSha256:sha(fs.readFileSync(currentFile)),previousSourceCount:before.size,currentSourceCount:after.size,previousSourceFingerprint:previous.validationSourceSha256,currentSourceFingerprint:current.validationSourceSha256,changedExisting:changed.map(f=>({path:f.path,beforeSha256:before.get(f.path).sha256,afterSha256:f.sha256})),added,removed,unchangedOriginalSourceCount:before.size-changed.length,comparisonExclusion:'docs/ only. All non-doc tracked plus owned source/test/SQL files compared.',allChangesMatchDeclaredIncrement:true};
fs.writeFileSync(path.join(work,'writer-admission-final-validation-v1/increment-source-comparison.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,changed:changed.length,added:added.length,removed:removed.length,unchangedOriginalSourceCount:result.unchangedOriginalSourceCount,sourceCount:after.size,fingerprint:current.validationSourceSha256}));
