import datetime, hashlib, json, pathlib, zipfile

repo = pathlib.Path(r'C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map')
work = repo.parent / 'work'
out = work / 'writer-admission-final-validation-v1'
destination = repo / 'docs/admin-r3-evidence/2026-10-30-writer-admission'
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda name: json.loads((out / name).read_text(encoding='utf-8-sig'))
write = lambda name, value: (out / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

tests = read('selected-tests-summary.json')
receipt = read('selected-tests-receipt.json')
gates = read('gates-summary.json')
drift = read('source-drift.json')
preservation = read('baseline-preservation.json')
increment = read('increment-source-comparison.json')
before = read('source-before.json')
after = read('source-after-tests.json')
assert receipt.get('finishedAt') and receipt['status'] in ['PASS', 'FAIL']
assert drift['zeroValidationSourceDrift'] and before['validationSourceSha256'] == after['validationSourceSha256']
assert before['head'] == after['head'] and preservation['pass'] and increment['status'] == 'PASS'
for gate in gates['receipts']:
    individual = read(gate['id'] + '-receipt.json')
    assert individual.get('finishedAt') and individual['status'] == gate['status']

baseline_archive = repo / 'docs/admin-r3-evidence/2026-10-29-profile-budgets/whole-validation-evidence.zip'
assert sha(baseline_archive.read_bytes()) == '383dcab8d3789600025c07ca796ab98bbca28714232ddd78dd08971fcc559d07'
with zipfile.ZipFile(baseline_archive) as z:
    baseline_tests_bytes = z.read('final/selected-tests-summary.json')
    baseline_tests = json.loads(baseline_tests_bytes)
    baseline_text = z.read('final/gate-readonly-hyphens.log')

def failures(report):
    return sorted([
        {'fullName': failure['fullName'], 'firstErrors': [message.replace('\r\n', '\n').split('\n')[0] for message in failure.get('failureMessages', [])]}
        for file in report.get('failedFiles', []) for failure in file.get('assertionFailures', [])
    ], key=lambda item: item['fullName'])

comparison = {'sameFailureCasesAndFirstErrors': failures(tests) == failures(baseline_tests), 'baseline': failures(baseline_tests), 'current': failures(tests), 'sourceArchiveSha256': sha(baseline_archive.read_bytes()), 'claim': 'Exact case names and first diagnostic line after line-ending normalization only. Full raw reports retained; no skip or substitute BEFORE.'}
write('baseline-failure-comparison.json', comparison)
assert comparison['sameFailureCasesAndFirstErrors'] and tests['numFailedTests'] == 6
text = (out / 'gate-readonly-hyphens.log').read_bytes()
text_comparison = {'byteIdenticalToBaseline': text == baseline_text, 'baselineSha256': sha(baseline_text), 'currentSha256': sha(text), 'findingCount': sum(line.startswith('- ') for line in text.decode('utf-8-sig').splitlines()), 'normalizerWriteFlagUsed': False}
write('readonly-gate-baseline-comparison.json', text_comparison)
assert text_comparison['byteIdenticalToBaseline'] and text_comparison['findingCount'] == 41
assert gates['passed'] == 4 and all(g['status'] == 'PASS' or g['id'] == 'gate-readonly-hyphens' for g in gates['receipts'])

external = []
for name in ['writer-admission-controlled-tests.zip', 'sql-evidence.zip', 'next-library-country-admission-before.zip']:
    file = destination / name
    assert file.exists()
    external.append({'path': name, 'bytes': file.stat().st_size, 'sha256': sha(file.read_bytes())})

summary = {
    'schemaVersion': 1, 'checkedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': before['head'],
    'classification': 'LOCAL_INCREMENT_VERIFIED_WITH_KNOWN_INHERITED_FAILURES_NOT_FULL_R3_ACCEPTANCE',
    'tests': {'files': tests['testFileCount'], 'total': tests['numTotalTests'], 'passed': tests['numPassedTests'], 'failed': tests['numFailedTests'], 'pending': tests['numPendingTests'], 'todo': tests['numTodoTests'], 'exitCode': receipt['exitCode'], 'sameSixHistoricalFailures': comparison['sameFailureCasesAndFirstErrors']},
    'gates': {**gates, 'readonlyLogByteIdenticalToBaseline': text_comparison['byteIdenticalToBaseline'], 'readonlyFindingCount': 41},
    'source': {'nonDocFileCount': after['validationSourceCount'], 'nonDocFingerprint': after['validationSourceSha256'], 'fullFileCount': after['trackedFileCount'], 'broadBeforeFullAggregate': before['aggregateSha256'], 'broadAfterFullAggregate': after['aggregateSha256'], 'zeroValidationSourceDrift': True, 'changedExistingVersusPreviousSlice': len(increment['changedExisting']), 'addedVersusPreviousSlice': len(increment['added']), 'unchangedPreviousFiles': increment['unchangedOriginalSourceCount'], 'exclusion': 'docs/ only; tracked docs remain hashed and drift reported explicitly, new docs/evidence outside owned source inventory.'},
    'preservation': {'pass': True, 'normalizers': len(preservation['normalizers']), 'rulesAndTests': len(preservation['normalizerRulesAndTests']), 'ASTScopes': len(preservation['normalizerImportAndCallScopes']), 'oldMigrations': len(preservation['oldMigrations']), 'telegramPaths': len(preservation['independentTelegram']), 'packageFiles': len(preservation['packages']), 'writeFlagUsed': False},
    'externalArchives': external,
    'limitations': ['Six M02 failures require absent original .tmp/m02-operation-wiring-before captures; no fabricated baseline or ignored assertion.', 'Readonly text gate remains FAIL with the exact previous41 findings; excluded subsystem unchanged.', 'This204-file broad selection executes on the final frozen source; controlled boundary adaptations and historical failures have separate explicit source bindings in the controlled-tests archive.', 'Native SQL uses isolated PostgreSQL17.11 and synthetic Auth/staff boundaries; fifteen inherited fixture advisor findings and unavailable lint remain raw, with zero findings on new production objects.', 'Writer admission blocks unknown duplicates and retains private paid bodies/completed candidates. Partial-pass replay, global cost/concurrency budgets, stable T12 scanning and full T13 operator retry are not established.', 'Library/country still reproduce the accepted-request duplicate defect in their separate frozen BEFORE archive.', 'No authenticated managed/browser E2E, paid provider, production migration/deploy, push or PR acceptance is claimed. Full26-module/230-criterion goal remains pending.'],
}
write('validation-summary.json', summary)

entries = {}
for directory, prefix in [('writer-admission-final-validation-v1', 'final')]:
    for file in (work / directory).iterdir():
        if file.is_file() and file.suffix in ['.json', '.log', '.txt', '.md'] and file.name != 'evidence-package-manifest.json':
            entries[prefix + '/' + file.name] = file.read_bytes()
for name in ['writer-admission-final-validation-v1-runner.mjs', 'writer-admission-final-preservation.mjs', 'writer-admission-increment-comparison.mjs', 'writer-admission-targeted-runner.mjs', 'package-writer-admission-final-validation.py']:
    entries['runners/' + name] = (work / name).read_bytes()
entries['baseline/selected-tests-summary.json'] = baseline_tests_bytes
entries['baseline/gate-readonly-hyphens.log'] = baseline_text
entries['README.md'] = b'''# Whole-admin validation for the writer admission increment

Final204-file suite and five gates execute on the final frozen source fingerprint
recorded in final/validation-summary.json. Six inherited historical M02 fixture
errors remain FAIL. The readonly text gate remains the exact41-file baseline
FAIL; four other gates pass. No skip or replacement BEFORE was introduced.

The separate controlled-tests archive preserves original/adapted BEFORE failures,
final CURRENT proof using the exact original invariant contract, actual native
DTO replay, intermediate failures and their explicitly bounded corrections.
Its underlying source/test boundaries remain distinct from this broad selection.

Native SQL, paired runtime tests and the next library/country admission BEFORE
capture are separate archives, hashed in final/validation-summary.json. The next
BEFORE defect is not acceptance PASS. No managed/live service, paid provider,
production release or full26-module/230-criterion acceptance is claimed.

The supplied runners require the locked repository dependencies and contain
historical absolute workspace paths. Adapt paths deliberately, keep the safe
child environment and use fresh output labels when replaying. Verify internal
hashes before extracting into an empty scratch directory. Credentials, caches,
dependencies, generated-byte backups and native database binaries/data are absent.
'''
manifest = {'schemaVersion': 1, 'head': before['head'], 'classification': summary['classification'], 'sourceFingerprint': after['validationSourceSha256'], 'entries': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(entries.items())]}
manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
entries['manifest.json'] = manifest_bytes
archive = destination / 'whole-validation-evidence.zip'
assert not archive.exists(), 'Never overwrite historical evidence'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(entries.items()): z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(entries)
    for item in manifest['entries']:
        data = z.read(item['path'])
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
    assert z.read('manifest.json') == manifest_bytes
package = {'archive': archive.name, 'sha256': sha(archive.read_bytes()), 'bytes': archive.stat().st_size, 'members': len(entries), 'verifiedPayloadMembers': len(manifest['entries']), 'manifestSha256': sha(manifest_bytes), 'sourceFingerprint': after['validationSourceSha256'], 'tests': summary['tests'], 'gatesPassed': gates['passed'], 'gatesTotal': gates['total']}
(destination / 'whole-validation-evidence.receipt.json').write_text(json.dumps(package, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
write('evidence-package-manifest.json', manifest)
print(json.dumps(package, ensure_ascii=True))
