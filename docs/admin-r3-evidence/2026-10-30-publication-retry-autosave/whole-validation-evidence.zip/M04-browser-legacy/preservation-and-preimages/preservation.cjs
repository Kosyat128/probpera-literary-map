// Static syntax-tree/source inspection only: no emit, typecheck, app load or tests.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const work=path.dirname(__dirname),repo=path.resolve(work,'../probpera-literary-map'),native=createRequire(path.join(repo,'package.json')),ts=native('typescript');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),name='apps/admin/app/(dashboard)/publication/publication-load-errors.integration.test.ts';
const original=fs.readFileSync(path.join(__dirname,'before',name),'utf8'),current=fs.readFileSync(path.join(repo,name),'utf8');
function root(n){if(ts.isAwaitExpression(n)||ts.isCallExpression(n)||ts.isPropertyAccessExpression(n))return root(n.expression);return ts.isIdentifier(n)?n.text:'';}
function inspect(text){const source=ts.createSourceFile(name,text,ts.ScriptTarget.Latest,true),tests=[],assertions=[];
 function visit(n){if(ts.isCallExpression(n)&&root(n)==='it'&&n.arguments.length>=2&&ts.isStringLiteral(n.arguments[0])){const callback=n.arguments.find(a=>ts.isArrowFunction(a)||ts.isFunctionExpression(a));if(callback)tests.push({name:n.arguments[0].text,body:callback.getText(source)});}
  if(ts.isExpressionStatement(n)&&root(n.expression)==='expect')assertions.push(n.expression.getText(source));ts.forEachChild(n,visit);}
 visit(source);return{tests,assertions};}
const before=inspect(original),after=inspect(current),oldPredicate='status === "deployed" ? 0 : 1',newPredicate='status === "failed" ? 1 : 0';
const callbackDiffs=before.tests.flatMap((r,i)=>r.name!==after.tests[i]?.name||r.body!==after.tests[i]?.body?[{name:r.name,onlyApprovedPredicateChanged:r.body.replace(oldPredicate,newPredicate)===after.tests[i]?.body}]:[]);
const assertionDiffs=before.assertions.flatMap((r,i)=>r!==after.assertions[i]?[{index:i,onlyApprovedPredicateChanged:r.replace(oldPredicate,newPredicate)===after.assertions[i]}]:[]);
const action='apps/admin/app/(dashboard)/publication/actions.ts',a0=fs.readFileSync(path.join(__dirname,'before',action),'utf8'),a1=fs.readFileSync(path.join(repo,action),'utf8'),full='export async function requestFullPublicBuildAction';
const protectedFiles=['apps/admin/lib/publication.ts','apps/admin/lib/public-build.ts'].map(file=>({file,byteExact:fs.readFileSync(path.join(__dirname,'before',file)).equals(fs.readFileSync(path.join(repo,file)))}));
const vendorFiles=['node_modules/next/dist/compiled/react-dom/cjs/react-dom-server-legacy.node.development.js','node_modules/next/dist/compiled/react-dom/cjs/react-dom-server-legacy.node.production.js','node_modules/next/dist/compiled/react/cjs/react-jsx-runtime.development.js'];
const vendor=vendorFiles.map(file=>{const b=fs.readFileSync(path.join(repo,file));return{file,sha256:sha(b),usesSameNextReact:b.toString().includes('require("next/dist/compiled/react")')};});
const proof={classification:'STATIC_M04_SOURCE_AND_OLD_UI_ASSERTION_PRESERVATION_NOT_TEST_EXECUTION',checkedAt:new Date().toISOString(),originalTestFileSha256:sha(Buffer.from(original)),currentTestFileSha256:sha(Buffer.from(current)),
 originalCaseDeclarations:before.tests.length,currentCaseDeclarations:after.tests.length,originalFullAssertionExpressions:before.assertions.length,callbackDiffs,assertionDiffs,
 onlyTwoExpandedStatusIntentsSuperseded:callbackDiffs.length===1&&callbackDiffs[0].name==='accepts SQL nullable provider/times for %s'&&callbackDiffs[0].onlyApprovedPredicateChanged&&assertionDiffs.length===1&&assertionDiffs[0].onlyApprovedPredicateChanged,
 defaultFixtureTransition:'requested -> failed root with exact raw updated_at and explicit native NULL pair; four original positive read/ID expanded cases retain full callback/assertion bytes. This fixture authority change is explicit, not original-input equality.',
 fullRebuildFunctionWholeTextExact:a0.slice(a0.indexOf(full))===a1.slice(a1.indexOf(full)),protectedFiles,vendor,
 setupScope:'Actual Next-compiled React/JSX/server renderer consistently replace React18 only in the legacy SSR fixture. No client-component stub, module cache, timeout, package or provider spy weakening.',
 noEmitOrTypecheckOrAppExecution:true};
proof.pass=proof.onlyTwoExpandedStatusIntentsSuperseded&&proof.fullRebuildFunctionWholeTextExact&&protectedFiles.every(r=>r.byteExact)&&vendor.every(r=>r.usesSameNextReact);
fs.writeFileSync(path.join(__dirname,'preservation.json'),JSON.stringify(proof,null,2)+'\n');console.log(JSON.stringify({pass:proof.pass,originalCaseDeclarations:before.tests.length,originalAssertions:before.assertions.length,callbackDiffs,assertionDiffs,sha256:sha(fs.readFileSync(path.join(__dirname,'preservation.json')))}));if(!proof.pass)process.exitCode=1;
