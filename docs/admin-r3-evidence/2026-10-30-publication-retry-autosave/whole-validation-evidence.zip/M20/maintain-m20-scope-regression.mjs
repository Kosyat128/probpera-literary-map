import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const work = path.dirname(fileURLToPath(import.meta.url)), repo = path.resolve(work, '../probpera-literary-map');
const before = path.join(work, 'm20-autosave-scope-before-ljoeFx');
const destination = path.join(repo, 'apps/admin/tests/browser/recovery-autosave-scope-browser.mjs');
const entry = path.join(repo, 'apps/admin/tests/browser/fixtures/recovery-autosave-scope-entry.jsx');
if (fs.existsSync(destination) || fs.existsSync(entry)) throw Error('Do not replace an earlier maintained regression');
const original = fs.readFileSync(path.join(before, 'producer.mjs'), 'utf8');
const replacements = [
  ["const work = path.dirname(fileURLToPath(import.meta.url));\nconst repo = path.resolve(work, '../probpera-literary-map');", "const own = path.dirname(fileURLToPath(import.meta.url));\nconst repo = path.resolve(own, '../../../..');\nconst work = path.resolve(repo, '../work');\nconst stageIndex = process.argv.indexOf('--stage');\nconst stage = stageIndex < 0 ? null : process.argv[stageIndex + 1];\nassert.ok(stage === 'BEFORE' || stage === 'AFTER', 'Pass an explicit --stage BEFORE or AFTER');"],
  ["fs.mkdtempSync(path.join(work, 'm20-autosave-scope-before-'))", "fs.mkdtempSync(path.join(work, 'm20-autosave-scope-' + stage.toLowerCase() + '-'))"],
  ["const entry = path.join(work, 'm20-autosave-scope-before-entry.jsx');", "const entry = path.join(own, 'fixtures/recovery-autosave-scope-entry.jsx');"],
  ["classification: 'GENUINE_BEFORE_ACTUAL_REACT_CHROME_RECOVERY_AUTOSAVE_TIMERS_CONTROLLED_ACTIONS_NOT_FULL_EDITOR_DB_OR_AUTH'", "classification: 'ACTUAL_REACT_CHROME_RECOVERY_AUTOSAVE_TIMERS_CONTROLLED_ACTIONS_NOT_FULL_EDITOR_DB_OR_AUTH', stage"]
];
let maintained = original;
for (const [from, to] of replacements) {
  if (maintained.split(from).length !== 2) throw Error('Expected one producer location: ' + from);
  maintained = maintained.replace(from, to);
}
fs.writeFileSync(destination, maintained, { flag: 'wx' });
fs.copyFileSync(path.join(before, 'entry.jsx'), entry, fs.constants.COPYFILE_EXCL);
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const scenarioBlock = value => value.slice(value.indexOf('const scenarios ='), value.indexOf('  for (const row of sources.values())'));
if (scenarioBlock(maintained) !== scenarioBlock(original)) throw Error('Never change original scenarios, observations or oracle checks');
fs.writeFileSync(path.join(work, 'm20-autosave-scope-maintained-preservation.json'), JSON.stringify({
  classification: 'EXACT_GENUINE_BEFORE_SCENARIOS_AND_ALL34_ORACLE_CHECKS_RETAINED_WITH_RUNTIME_PATH_STAGE_ADAPTER_ONLY',
  checkedAt: new Date().toISOString(), originalProducerSha256: hash(Buffer.from(original)), maintainedProducerSha256: hash(Buffer.from(maintained)),
  originalEntrySha256: hash(fs.readFileSync(path.join(before, 'entry.jsx'))), maintainedEntrySha256: hash(fs.readFileSync(entry)),
  scenarioBlockSha256: hash(Buffer.from(scenarioBlock(original))), scenarioBlockExact: true, setupOnlyReplacementCount: replacements.length,
  originalResult: { total: 34, passed: 23, failed: 11, targetFailures: 8, controlFailures: 1, preservationFailures: 2 },
  currentExecution: 'NOT_RUN'
}, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ destination, entry, scenarioBlockExact: true, setupOnlyReplacementCount: replacements.length }));
