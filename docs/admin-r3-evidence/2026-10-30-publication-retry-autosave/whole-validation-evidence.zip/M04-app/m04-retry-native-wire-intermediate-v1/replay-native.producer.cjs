// Parent-only exact native wire replay. No SQL/Auth/provider connections.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const work=path.resolve(__dirname,'..'),repo=path.resolve(work,'../probpera-literary-map'),native=createRequire(path.join(repo,'package.json'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),args=process.argv.slice(2),arg=name=>args[args.indexOf(name)+1];
if(!args.includes('--execute-controlled')){console.log(JSON.stringify({status:'PREPARED_NOT_EXECUTED'}));process.exit(0);}
assert(args.includes('--rows')&&args.includes('--sha256')&&args.includes('--output'));
const source=path.resolve(arg('--rows')),expected=arg('--sha256'),output=path.resolve(arg('--output'));
assert(!path.relative(work,source).startsWith('..')&&!path.relative(work,output).startsWith('..')&&!fs.existsSync(output));
const raw=fs.readFileSync(source);assert.equal(sha(raw),expected);const rows=JSON.parse(raw);assert(Array.isArray(rows)&&rows.length>0);
const allowed=/^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i;
for(const key of Object.keys(process.env))if(!allowed.test(key))delete process.env[key];
Object.assign(process.env,{CI:'1',NODE_ENV:'test',NEXT_TELEMETRY_DISABLED:'1',NO_COLOR:'1'});
const {createPublicationRetryRuntime,captureSources}=require(path.join(repo,'apps/admin/lib/fixtures/publication-retry-runtime.cjs'));
const runtime=createPublicationRetryRuntime(),api=runtime.load('apps/admin/lib/publication-retry-rpc.ts'),contract=runtime.load('apps/admin/lib/publication-retry-contract.ts');
const {createClient}=native('@supabase/supabase-js'),wire=[],checks=[];
function client(row,phase){return createClient('https://m04-native-replay.invalid','synthetic-local-public-fixture-key',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},global:{fetch:async(url,init={})=>{
 const request={url:String(url),method:init.method,args:JSON.parse(String(init.body))};assert.equal(request.url,'https://m04-native-replay.invalid/rest/v1/rpc/'+row.rpc);assert.equal(request.method,'POST');assert.deepEqual(request.args,row.args);
 wire.push({row:rows.indexOf(row),phase,role:row.role,actorId:row.actorId,request,response:structuredClone(row.error||row.response)});
 return new Response(JSON.stringify(row.error||row.response),{status:row.error?400:200,headers:{'content-type':'application/json'}});
 }}});}
(async()=>{
 fs.mkdirSync(output,{recursive:false});const startedAt=new Date().toISOString();
 let direct=0,typed=0,nativeSuccess=0,nativeError=0,typedReceipt=0,typedNativeError=0,preSdkRefusal=0;
 for(const [index,row] of rows.entries()){
  assert.equal(row.rpc,'admit_public_build_retry');assert.deepEqual(Object.keys(row.args).sort(),['p_expected_updated_at','p_outbox_id','p_retry_operation_id']);
  const input={outboxId:row.args.p_outbox_id,operationId:row.args.p_retry_operation_id,expectedUpdatedAt:row.args.p_expected_updated_at};
  const inputValid=contract.publicationRetryInputSchema.safeParse(input).success;assert.equal(inputValid,row.typedInputValid,'Native input-valid classification drift at row'+index);
  const actorValid=contract.publicationRetryInputSchema.shape.operationId.safeParse(row.actorId).success;assert(actorValid,'Intermediate export caller UUID must be explicit');
  const directResponse=await client(row,'direct-installed-SDK').rpc(row.rpc,row.args);direct++;
  if(row.error){assert.equal(directResponse.error?.code,row.error.code);assert.equal(directResponse.error?.message,row.error.message);nativeError++;}
  else{assert.equal(directResponse.error,null);assert.deepEqual(directResponse.data,row.response);nativeSuccess++;}
  const before=wire.length;
  if(!inputValid){await assert.rejects(api.admitPublicationRetry(client(row,'typed-invalid-must-not-send'),input,row.actorId));assert.equal(wire.length,before);preSdkRefusal++;}
  else if(row.error){await assert.rejects(api.admitPublicationRetry(client(row,'actual-strict-typed-wrapper'),input,row.actorId));assert.equal(wire.length,before+1);typed++;typedNativeError++;}
  else{const result=await api.admitPublicationRetry(client(row,'actual-strict-typed-wrapper'),input,row.actorId);assert.deepEqual(result,row.response);assert.equal(wire.length,before+1);typed++;typedReceipt++;}
  checks.push({row:index,inputValid,actorValid,nativeOutcome:row.response?.outcome||null,nativeErrorCode:row.error?.code||null,pass:true});
 }
 const sources=captureSources(output),packages=['@supabase/supabase-js','next','zod','typescript'].map(name=>{const p=path.join(repo,'node_modules',name,'package.json'),b=fs.readFileSync(p);return{name,version:JSON.parse(b).version,bytes:b.length,sha256:sha(b)};});
 const report={classification:'ACTUAL_NATIVE_RAW_WIRE_THROUGH_INSTALLED_SDK_AND_ACTUAL_TYPED_ADAPTER_CONTROLLED_HTTP_NOT_MANAGED_AUTH_POSTGREST_OR_PROVIDER',startedAt,finishedAt:new Date().toISOString(),nativeInput:{path:source,sha256:sha(raw),rows:rows.length,stage:path.basename(source).includes('intermediate')?'INTERMEDIATE_NATIVE_SEQUENTIAL_NOT_FINAL_RACES':'FINAL_ONLY_IF_NATIVE_RECEIPT_CONFIRMS'},
  counts:{directSdk:direct,typedSdk:typed,nativeSuccess,nativeError,typedReceiptParsed:typedReceipt,typedNativeErrorRefused:typedNativeError,nativeOnlyInvalidInputStoppedBeforeTypedSdk:preSdkRefusal,totalWireRequests:wire.length},checks,wire,sources:sources.sources,packages,
  environment:'OS allowlist only plus CI/NODE_ENV=test/no telemetry/no color; inherited keys removed before package/app loads',
  limitations:['Native error.code and raw psql stderr are preserved; controlled HTTP400 envelope is a replay adaptation, not an observed managed PostgREST response.','typedInputValid describes three request scalars only. Actor UUID is separately validated. Neither proves current fresh staff eligibility or real managed JWT authorization.','rawSqlInputOperationId preserves any SQL uppercase input separately; exact SDK request comparison uses the canonical args exported after PostgreSQL UUID normalization.','Only native success rows are parsed DTO successes. Native error rows are expected adapter refusals; invalid native-only inputs cause zero typed-wrapper SDK requests.','No native DB, real provider, browser, managed Auth, live PostgREST or extra paid work executes during this replay.'],pass:true};
 fs.writeFileSync(path.join(output,'conformance.json'),JSON.stringify(report,null,2)+'\n');fs.copyFileSync(source,path.join(output,'native-input.raw.json'));fs.copyFileSync(__filename,path.join(output,'replay-native.producer.cjs'));
 console.log(JSON.stringify({output,nativeRows:rows.length,...report.counts,sourceCount:report.sources.length,sha256:sha(fs.readFileSync(path.join(output,'conformance.json'))),pass:true}));
})().catch(error=>{fs.mkdirSync(output,{recursive:true});fs.writeFileSync(path.join(output,'failure.json'),JSON.stringify({error:String(error.stack||error),checks,wire,pass:false},null,2)+'\n');console.error(error.stack||error);process.exitCode=1;});
