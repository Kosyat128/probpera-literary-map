import { spawnSync } from "node:child_process";
import { createHash, randomBytes } from "node:crypto";
import { createReadStream, existsSync, mkdirSync, readFileSync, realpathSync, unlinkSync, writeFileSync } from "node:fs";
import path from "node:path";
import { createServer } from "node:net";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";

const repoRoot = realpathSync(path.resolve(path.dirname(fileURLToPath(import.meta.url)), ".."));
const toolsRoot = realpathSync(path.join(repoRoot, ".tmp", "m02-postgres-tools"));
const archiveSha256 = "80379b2c04d51c30225532e0ae04509899141e9957ed096fe749d7fd9df8f82f";
const port = 54329;
const database = "m02_contract";
const username = "m02_fixture";
const cleanEnv = Object.fromEntries(Object.entries(process.env).filter(([key]) =>
  !/^PG/iu.test(key) && !/^(?:DATABASE_URL|SUPABASE_DB_URL|SUPABASE_DATABASE_URL|POSTGRES_URL)$/iu.test(key)));
const pwsh = "pwsh.exe";
const subst = path.join(process.env.SystemRoot || "C:\\Windows", "System32", "subst.exe");

function within(root, target) {
  const relative = path.relative(root, target);
  return relative !== "" && !relative.startsWith("..") && !path.isAbsolute(relative);
}
if (!within(path.join(repoRoot, ".tmp"), toolsRoot)) throw new Error("Portable tools outside this task scratch");

const options = { case: "publication-r2", sql: null, markers: [] };
for (const arg of process.argv.slice(2)) {
  if (arg.startsWith("--case=")) options.case = arg.slice(7);
  else if (arg.startsWith("--sql=")) options.sql = arg.slice(6);
  else if (arg.startsWith("--expect-marker=")) options.markers.push(arg.slice(16));
  else throw new Error(`Unsupported argument: ${arg}`);
}
if (!/^[a-z0-9][a-z0-9-]{0,70}$/u.test(options.case)) throw new Error("Invalid fixture case name");
if (options.markers.some(marker => !/^[A-Z][A-Z0-9_]{1,120}$/u.test(marker))) throw new Error("Invalid expected fixture marker");
if (!options.sql && options.markers.length === 0) options.markers = [
  "LEGACY_DRAFT_LOCK_PERMISSION_FAILURE_CONFIRMED",
  "LEGACY_REDIRECT_PERMISSION_FAILURE_CONFIRMED",
  "ARTICLE_PUBLICATION_PERMISSIONS_OK",
];
if (options.sql && options.markers.length === 0) throw new Error("An explicit SQL fixture must specify at least one expected marker");

if (!options.case.startsWith("m07-t04-sql-")) throw new Error("T04 native case prefix required");
const runId = `${options.case}-${new Date().toISOString().replace(/[^0-9]/gu, "")}-${process.pid}-${randomBytes(4).toString("hex")}`;
const caseRoot = path.join(toolsRoot, "native-cases", runId);
if (!within(toolsRoot, caseRoot)) throw new Error("Fixture case path outside exact tools root");
mkdirSync(caseRoot, { recursive: true });
const reportPath = path.join(caseRoot, "result.json");
const report = {
  case: options.case, runId, repoRoot, toolsRoot, caseRoot,
  startedAtUtc: new Date().toISOString(), status: "RUNNING",
  transport: { host: "127.0.0.1", port, database, username, pgEnvironment: "cleared in child process only", passwordsLogged: false },
  limitations: ["Isolated PostgreSQL fixture only", "auth.users/auth.uid/is_staff are synthetic stubs", "Revision/public-build outbox capture triggers are synthetic fixtures; PostgreSQL transaction and RLS statements execute natively", "No real GoTrue/Auth/production project", "No actual PostgREST/network outcome exercised"],
  commands: [], markers: {}, cleanup: {},
};
let alias = null;
let aliasCreated = false;
let aliasCluster = null;
let aliasCase = null;
let secret = null;
let sequence = 0;
let startAttempted = false;

const writeJson = (filename, value) => writeFileSync(filename, JSON.stringify(value, null, 2) + "\n", "utf8");
const saveReport = () => writeJson(reportPath, report);
const redact = value => secret ? String(value || "").replaceAll(secret, "[fixture-secret]") : String(value || "");
async function sha256File(filename) {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(filename)) hash.update(chunk);
  return hash.digest("hex");
}
async function assertLoopbackPortFree() {
  const listener = createServer();
  await new Promise((resolve, reject) => {
    listener.once("error", reject);
    listener.listen({ host: "127.0.0.1", port, exclusive: true }, resolve);
  });
  await new Promise((resolve, reject) => listener.close(error => error ? reject(error) : resolve()));
  report.transport.portPreflight = "available";
}
function native(label, command, args, settings = {}) {
  const logBase = `${String(++sequence).padStart(2, "0")}-${label}`;
  const result = spawnSync(command, args, {
    cwd: repoRoot, env: cleanEnv, encoding: "utf8", windowsHide: true,
    maxBuffer: 64 * 1024 * 1024, timeout: 30_000, ...settings,
  });
  writeFileSync(path.join(caseRoot, `${logBase}.stdout.log`), redact(result.stdout), "utf8");
  writeFileSync(path.join(caseRoot, `${logBase}.stderr.log`), redact(result.stderr), "utf8");
  report.commands.push({ label, command, args, status: result.status, signal: result.signal,
    error: redact(result.error?.message), stdout: `${logBase}.stdout.log`, stderr: `${logBase}.stderr.log`, windowsHide: true });
  saveReport();
  if (result.status !== 0 || result.error) throw new Error(`${label}: ${redact(result.error?.message || result.stderr || result.stdout)}`);
  return result;
}
const psPrelude = `
Add-Type -TypeDefinition 'using System; using System.Text; using System.Runtime.InteropServices; public static class M02DriveQuery { [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] public static extern uint QueryDosDevice(string name, StringBuilder target, int capacity); }';
`;
function driveState(letter) {
  const code = `${psPrelude}
$taskDrive=$env:M02_ALIAS;
$taskTarget=[System.Text.StringBuilder]::new(4096);
$taskLength=[M02DriveQuery]::QueryDosDevice($taskDrive,$taskTarget,4096);
$taskVolume=[System.IO.DriveInfo]::GetDrives().Name -contains ($taskDrive + '\\');
$taskPSDrive=[bool](Get-PSDrive -Name $taskDrive.Substring(0,1) -ErrorAction SilentlyContinue);
$taskSubst=(@(& $env:M02_SUBST_EXE) -join "\n") -match ('(?m)^' + [regex]::Escape($taskDrive));
$taskJson=[pscustomobject]@{alias=$taskDrive;occupied=($taskLength -gt 0 -or $taskVolume -or $taskPSDrive -or $taskSubst);deviceTarget=$taskTarget.ToString()} | ConvertTo-Json -Compress
[Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($taskJson))
`;
  const result = native(`drive-${letter}`, pwsh, ["-NoProfile", "-NonInteractive", "-Command", code], {
    env: { ...cleanEnv, M02_ALIAS: `${letter}:`, M02_SUBST_EXE: subst },
  });
  return JSON.parse(Buffer.from(result.stdout.trim(), "base64").toString("utf8"));
}
function assertOwnedAlias() {
  const state = driveState(alias[0]);
  if (!state.deviceTarget.startsWith("\\??\\")) throw new Error("Alias has no verified task-owned SUBST target");
  const target = path.resolve(state.deviceTarget.slice(4));
  if (target.toLowerCase() !== toolsRoot.toLowerCase()) throw new Error("Alias no longer maps to the exact task tools root");
}

async function existingPublicationSql() {
  const entry = path.join(repoRoot, "scripts", "database", "article-publication-permissions.integration.test.mjs");
  const bundle = await build({
    entryPoints: [entry], absWorkingDir: repoRoot, bundle: true, platform: "node", format: "esm", write: false,
    plugins: [{ name: "m02-structural-vitest-only", setup(builder) {
      builder.onResolve({ filter: /^vitest$/ }, () => ({ path: "vitest", namespace: "m02-noop" }));
      builder.onLoad({ filter: /.*/, namespace: "m02-noop" }, () => ({
        contents: "export const describe=()=>{}; export const it=Object.assign(()=>{}, {skip:()=>{}}); export const expect=()=>{throw Error('Test execution forbidden in structural import')};",
        loader: "js",
      }));
    } }],
  });
  const code = bundle.outputFiles[0].text;
  const module = await import(`data:text/javascript;base64,${Buffer.from(code, "utf8").toString("base64")}`);
  if (typeof module.articlePublicationPermissionsSql !== "function") throw new Error("Actual fixture builder export missing");
  report.source = { mode: "existing-exported-builder", file: path.relative(repoRoot, entry), sha256: await sha256File(entry),
    vitest: "isolated no-op registration only; callbacks never executed", bundleSha256: createHash("sha256").update(code).digest("hex") };
  return module.articlePublicationPermissionsSql();
}

function psql(label, input, db = database, suffix = []) {
  return native(label, `${alias}\\pgsql\\bin\\psql.exe`, [
    "--host=127.0.0.1", `--port=${port}`, `--username=${username}`, `--dbname=${db}`,
    "--no-password", "--no-psqlrc", "--set=ON_ERROR_STOP=1", ...suffix,
  ], { input, timeout: 120_000, env: { ...cleanEnv, PGPASSFILE: `${aliasCase}\\fixture.pgpass`, PGCLIENTENCODING: "UTF8", PGSSLMODE: "disable" } });
}

const probeSql = `
select json_build_object(
  'serverVersion',current_setting('server_version'), 'serverEncoding',current_setting('server_encoding'),
  'address',inet_server_addr(), 'port',inet_server_port(),
  'roles',(select json_agg(json_build_object('name',rolname,'superuser',rolsuper,'bypassRls',rolbypassrls,'canLogin',rolcanlogin) order by rolname)
    from pg_catalog.pg_roles where rolname not like 'pg_%'),
  'tables',(select json_agg(json_build_object('schema',n.nspname,'name',c.relname,'rls',c.relrowsecurity,'forceRls',c.relforcerowsecurity) order by n.nspname,c.relname)
    from pg_catalog.pg_class c join pg_catalog.pg_namespace n on n.oid=c.relnamespace
    where c.relkind='r' and (n.nspname='probpera_editor_operations' or n.nspname='public' and
      (c.relname like 'article%' or c.relname like '%receipt%' or c.relname like '%operation%' or c.relname in ('redirects','admin_audit_log','pages')))),
  'outerRpcs',(select json_agg(json_build_object('name',p.proname,'securityDefiner',p.prosecdef) order by p.proname)
    from pg_catalog.pg_proc p join pg_catalog.pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname in ('save_article_bundle','promote_article_working_draft')),
  'directWrites',json_build_object(
    'draftInsert',case when to_regclass('public.article_working_drafts') is null then null else has_table_privilege('authenticated','public.article_working_drafts','INSERT') end,
    'draftUpdate',case when to_regclass('public.article_working_drafts') is null then null else has_table_privilege('authenticated','public.article_working_drafts','UPDATE') end,
    'draftDelete',case when to_regclass('public.article_working_drafts') is null then null else has_table_privilege('authenticated','public.article_working_drafts','DELETE') end,
    'redirectInsert',case when to_regclass('public.redirects') is null then null else has_table_privilege('authenticated','public.redirects','INSERT') end,
    'redirectUpdate',case when to_regclass('public.redirects') is null then null else has_table_privilege('authenticated','public.redirects','UPDATE') end
  )
);
`;

try {
  process.chdir(repoRoot);
  const provenance = JSON.parse(readFileSync(path.join(toolsRoot, "download-provenance.json"), "utf8"));
  const extracted = JSON.parse(readFileSync(path.join(toolsRoot, "extract-provenance.json"), "utf8"));
  if (provenance.archiveSha256 !== archiveSha256 || provenance.actualBytes !== 381531864) throw new Error("Unverified portable archive provenance");
  report.archive = { uri: provenance.archiveUri, sha256: archiveSha256, bytes: provenance.actualBytes };
  await assertLoopbackPortFree();
  report.toolHashes = [];
  for (const executable of extracted.requiredExecutables) {
    const toolPath = path.join(toolsRoot, "pgsql", "bin", executable.name);
    const sha256 = await sha256File(toolPath);
    if (sha256 !== executable.sha256) throw new Error(`Portable ${executable.name} differs from verified extraction`);
    report.toolHashes.push({ name: executable.name, sha256 });
  }
  for (const candidate of ["P", "Q", "R", "S"]) {
    if (!driveState(candidate).occupied) { alias = `${candidate}:`; break; }
  }
  if (!alias) throw new Error("No free task-only ASCII alias; existing mappings preserved");
  native("create-owned-alias", subst, [alias, toolsRoot]);
  aliasCreated = true;
  assertOwnedAlias();
  const linkedHash = await sha256File(`${alias}\\postgresql-17.11-5-windows-x64-binaries.zip`);
  if (linkedHash !== archiveSha256) throw new Error("Linked archive bytes differ from verified official ZIP");
  aliasCase = `${alias}\\native-cases\\${runId}`;
  aliasCluster = `${aliasCase}\\cluster`;
  report.alias = { letter: alias, source: toolsRoot, ownership: "created by this invocation after absence check", linkedArchiveHash: linkedHash };
  const version = native("postgres-version", `${alias}\\pgsql\\bin\\postgres.exe`, ["--version"]).stdout.trim();
  if (version !== "postgres (PostgreSQL) 17.11") throw new Error(`Unexpected native engine version: ${version}`);
  report.postgresVersion = version;
  const head = native("git-head", "git", ["rev-parse", "HEAD"]).stdout.trim();
  const branch = native("git-branch", "git", ["branch", "--show-current"]).stdout.trim();
  report.context = { head, branch, runnerSha256: await sha256File(fileURLToPath(import.meta.url)) };

  let sql;
  if (options.sql) {
    if (path.isAbsolute(options.sql)) throw new Error("SQL input must be an explicit repository-relative fixture path");
    const filename = realpathSync(path.resolve(repoRoot, options.sql));
    if (!within(repoRoot, filename) || !filename.endsWith(".sql")) throw new Error("SQL input outside task repository or not a .sql fixture");
    sql = readFileSync(filename, "utf8");
    report.source = { mode: "explicit-local-sql", file: path.relative(repoRoot, filename), sha256: await sha256File(filename) };
  } else sql = await existingPublicationSql();
  report.sqlSha256 = createHash("sha256").update(sql, "utf8").digest("hex");
  writeFileSync(path.join(caseRoot, "executed-fixture.sql"), sql, "utf8");
  report.sqlBytes = Buffer.byteLength(sql, "utf8");
  secret = randomBytes(32).toString("hex");
  const initPassword = path.join(caseRoot, "init-password.txt");
  writeFileSync(initPassword, secret + "\n", "utf8");
  writeFileSync(path.join(caseRoot, "fixture.pgpass"), `127.0.0.1:${port}:*:${username}:${secret}\n`, "utf8");
  try {
    native("initdb", `${alias}\\pgsql\\bin\\initdb.exe`, [
      "-D", aliasCluster, "-L", `${alias}\\pgsql\\share`, `--username=${username}`,
      "--auth-host=scram-sha-256", "--auth-local=scram-sha-256", `--pwfile=${aliasCase}\\init-password.txt`,
      "--encoding=UTF8", "--locale=C", "--no-instructions", "--no-clean",
    ]);
  } finally { if (existsSync(initPassword)) unlinkSync(initPassword); }
  startAttempted = true;
  native("pg-start", `${alias}\\pgsql\\bin\\pg_ctl.exe`, [
    "start", "-D", aliasCluster, "-l", `${aliasCase}\\server.log`,
    "-o", `-h 127.0.0.1 -p ${port} -c logging_collector=off`, "-w", "-t", "25",
  ], { stdio: "ignore" });
  native("pg-owned-status", `${alias}\\pgsql\\bin\\pg_ctl.exe`, ["status", "-D", aliasCluster]);
  const pidLines = readFileSync(path.join(caseRoot, "cluster", "postmaster.pid"), "utf8").split(/\r?\n/u);
  report.serverPid = Number(pidLines[0]);
  if (pidLines[3] !== String(port)) throw new Error("Owned cluster started on an unexpected port");
  psql("create-fixture-db", `CREATE DATABASE ${database} WITH TEMPLATE template0 ENCODING UTF8;\n`, "postgres");
  const result = psql("fixture-contract", sql);
  for (const marker of options.markers) {
    report.markers[marker] = result.stdout.includes(marker);
    if (!report.markers[marker]) throw new Error(`Actual SQL output missing required marker: ${marker}`);
  }
  const security = psql("actual-role-rls-probe", probeSql, database, ["--tuples-only", "--no-align"]);
  report.security = JSON.parse(security.stdout.trim());
  for (const name of ["anon", "authenticated"]) {
    const role = report.security.roles?.find(role => role.name === name);
    if (!role || role.superuser || role.bypassRls) throw new Error(`Fixture ${name} bypasses actual PostgreSQL RLS`);
  }
  if (!options.sql) {
    for (const name of ["articles", "article_translations", "redirects", "admin_audit_log", "article_working_drafts"]) {
      const table = report.security.tables?.find(table => table.name === name);
      if (!table?.rls || name === "article_working_drafts" && !table.forceRls) throw new Error(`Actual protected RLS missing for ${name}`);
    }
    if (Object.values(report.security.directWrites).some(value => value !== false)) throw new Error("Existing R2 direct-write guard reopened");
    if (report.security.outerRpcs?.length !== 2 || report.security.outerRpcs.some(rpc => rpc.securityDefiner)) throw new Error("Existing R2 outer RPCs lost SECURITY INVOKER");
  }
  report.status = "PASS";
} catch (error) {
  report.status = "FAIL";
  report.error = redact(error?.stack || error);
} finally {
  try {
    if (startAttempted && aliasCluster && existsSync(path.join(caseRoot, "cluster", "postmaster.pid"))) {
      assertOwnedAlias();
      const pidLines = readFileSync(path.join(caseRoot, "cluster", "postmaster.pid"), "utf8").split(/\r?\n/u);
      const dataPath = pidLines[1]?.replaceAll("/", "\\").toLowerCase();
      if (dataPath !== aliasCluster.toLowerCase() || pidLines[3] !== String(port)) throw new Error("Refusing to stop an unexpected cluster");
      native("pg-stop-owned", `${alias}\\pgsql\\bin\\pg_ctl.exe`, ["stop", "-D", aliasCluster, "-m", "fast", "-w", "-t", "25"]);
      if (existsSync(path.join(caseRoot, "cluster", "postmaster.pid"))) throw new Error("Owned fixture PID remains after stop");
    }
    report.cleanup.serverStopped = !existsSync(path.join(caseRoot, "cluster", "postmaster.pid"));
    if (report.cleanup.serverStopped) { await assertLoopbackPortFree(); report.cleanup.portFreeAfterStop = true; }
    if (aliasCreated) {
      assertOwnedAlias();
      if (!report.cleanup.serverStopped) throw new Error("Cannot release alias while owned server remains");
      native("remove-owned-alias", subst, [alias, "/D"]);
      report.cleanup.aliasRemoved = !driveState(alias[0]).occupied;
      if (!report.cleanup.aliasRemoved) throw new Error("Owned alias remains after release");
    }
  } catch (error) {
    report.status = "FAIL";
    report.cleanup.error = redact(error?.stack || error);
  }
  report.finishedAtUtc = new Date().toISOString();
  report.cleanup.workspaceFilesPreserved = true;
  saveReport();
  writeFileSync(path.join(repoRoot, ".tmp", `${runId}-pointer.json`), JSON.stringify({ reportPath, case: options.case, runId, status: report.status }, null, 2)+"\n", {flag:"wx"});
}
console.log(JSON.stringify({ status: report.status, case: options.case, reportPath, postgresVersion: report.postgresVersion,
  markers: report.markers, sqlSha256: report.sqlSha256, cleanup: report.cleanup, error: report.error || report.cleanup.error }, null, 2));
process.exitCode = report.status === "PASS" ? 0 : 1;
