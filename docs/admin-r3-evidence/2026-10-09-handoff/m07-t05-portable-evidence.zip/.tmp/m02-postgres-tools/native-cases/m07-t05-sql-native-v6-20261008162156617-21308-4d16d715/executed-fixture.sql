\set ON_ERROR_STOP on
\pset tuples_only on
\pset format unaligned

create role anon nologin;
create role authenticated nologin;
create schema auth;
grant usage on schema auth to authenticated;

create table auth.users (id uuid primary key);

create or replace function auth.uid()
returns uuid
language sql
stable
set search_path = ''
as $$
  select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
$$;
grant execute on function auth.uid() to authenticated;

create type public.staff_role as enum ('owner', 'admin', 'editor');
create type public.article_status as enum (
  'draft', 'review', 'scheduled', 'published', 'hidden', 'archived'
);
create type public.article_translation_status as enum (
  'draft', 'review', 'approved', 'published', 'stale', 'archived'
);

create table public.staff_memberships (
  user_id uuid primary key references auth.users(id),
  role public.staff_role not null
);
create or replace function public.is_staff(
  allowed_roles public.staff_role[] default array[
    'owner'::public.staff_role,
    'admin'::public.staff_role,
    'editor'::public.staff_role
  ]
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.staff_memberships
    where user_id = (select auth.uid()) and role = any(allowed_roles)
  );
$$;
revoke all on function public.is_staff(public.staff_role[]) from public;
grant execute on function public.is_staff(public.staff_role[]) to authenticated;

create table public.categories (
  id uuid primary key,
  slug text not null unique
);

create table public.articles (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  title text not null check (char_length(title) between 3 and 240),
  subtitle text not null default '',
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  cover_external_url text,
  cover_alt text not null default '',
  category_id uuid references public.categories(id),
  status public.article_status not null default 'draft',
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,179}$'),
  legacy_path text unique,
  published_at timestamptz,
  scheduled_at timestamptz,
  featured boolean not null default false,
  show_on_homepage boolean not null default false,
  pinned boolean not null default false,
  sources jsonb not null default '[]'::jsonb,
  bibliography jsonb not null default '[]'::jsonb,
  seo_title text,
  seo_description text,
  seo_keywords text[] not null default '{}',
  canonical_url text,
  og_title text,
  og_description text,
  allow_indexing boolean not null default true,
  created_by uuid not null references auth.users(id),
  updated_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  check (status <> 'scheduled' or scheduled_at is not null),
  check (status <> 'published' or published_at is not null)
);

create table public.article_revisions (
  id bigint generated always as identity primary key,
  article_id uuid not null references public.articles(id) on delete cascade,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid,
  created_at timestamptz not null default now(),
  unique(article_id, revision_number)
);

create table public.article_translations (
  id uuid primary key default gen_random_uuid(),
  article_id uuid not null references public.articles(id) on delete cascade,
  locale text not null,
  title text not null check (char_length(title) between 3 and 240),
  subtitle text not null default '',
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  cover_alt text not null default '',
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{1,179}$'),
  sources jsonb not null default '[]'::jsonb,
  bibliography jsonb not null default '[]'::jsonb,
  seo_title text,
  seo_description text,
  seo_keywords text[] not null default '{}',
  canonical_url text,
  og_title text,
  og_description text,
  status public.article_translation_status not null default 'draft',
  source_content_hash text,
  source_article_updated_at timestamptz,
  reviewed_by uuid,
  reviewed_at timestamptz,
  approved_by uuid,
  approved_at timestamptz,
  published_at timestamptz,
  created_by uuid not null references auth.users(id),
  updated_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique(article_id, locale),
  unique(locale, slug),
  check (status not in ('approved', 'published') or approved_at is not null),
  check (status <> 'published' or published_at is not null)
);

create table public.article_translation_revisions (
  id bigint generated always as identity primary key,
  article_translation_id uuid not null references public.article_translations(id),
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid,
  created_at timestamptz not null default now(),
  unique(article_translation_id, revision_number)
);

create table public.redirects (
  id uuid primary key default gen_random_uuid(),
  source_path text not null unique,
  destination_path text not null,
  status_code smallint not null default 301,
  is_active boolean not null default true,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.admin_audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid,
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create table public.public_build_outbox (
  id bigint generated always as identity primary key,
  actor_id uuid,
  entity_type text not null,
  entity_id text not null,
  reason text not null,
  status text not null default 'requested',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = clock_timestamp(); return new; end;
$$;
create trigger articles_set_updated_at before update on public.articles
for each row execute function public.set_updated_at();
create trigger article_translations_set_updated_at before update on public.article_translations
for each row execute function public.set_updated_at();
create trigger redirects_set_updated_at before update on public.redirects
for each row execute function public.set_updated_at();

create or replace function public.capture_article_revision()
returns trigger language plpgsql security definer set search_path = '' as $$
declare n integer;
begin
  if old is not distinct from new then return new; end if;
  select coalesce(max(revision_number), 0) + 1 into n
  from public.article_revisions where article_id = old.id;
  insert into public.article_revisions(article_id, revision_number, snapshot, changed_by)
  values(old.id, n, to_jsonb(old), coalesce(new.updated_by, (select auth.uid())));
  return new;
end;
$$;
create trigger articles_capture_revision before update on public.articles
for each row execute function public.capture_article_revision();

create or replace function public.capture_article_translation_revision()
returns trigger language plpgsql security definer set search_path = '' as $$
declare n integer;
begin
  if old is not distinct from new then return new; end if;
  select coalesce(max(revision_number), 0) + 1 into n
  from public.article_translation_revisions
  where article_translation_id = old.id;
  insert into public.article_translation_revisions(
    article_translation_id, revision_number, snapshot, changed_by
  ) values(old.id, n, to_jsonb(old), coalesce(new.updated_by, (select auth.uid())));
  return new;
end;
$$;
create trigger article_translations_capture_revision
before update on public.article_translations
for each row execute function public.capture_article_translation_revision();

-- Mimic the important production behavior: changing the Russian source can
-- stale a released English translation before the explicit English save runs.
create or replace function public.fixture_sync_english_after_article()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'UPDATE' and old.title is distinct from new.title then
    update public.article_translations
    set status = 'stale', approved_by = null, approved_at = null,
        published_at = null, updated_by = new.updated_by
    where article_id = new.id and locale = 'en'
      and status in ('approved', 'published');
  end if;
  return new;
end;
$$;
create trigger articles_fixture_sync_english
after update on public.articles
for each row execute function public.fixture_sync_english_after_article();

create or replace function public.fixture_capture_outbox()
returns trigger language plpgsql security definer set search_path = '' as $$
declare row_data jsonb;
begin
  row_data := case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end;
  insert into public.public_build_outbox(actor_id, entity_type, entity_id, reason, metadata)
  values((select auth.uid()), tg_table_name,
    coalesce(row_data ->> 'id', row_data ->> 'article_id', tg_table_name),
    'database-' || lower(tg_op),
    jsonb_build_object('operation', lower(tg_op), 'table', tg_table_name));
  return case when tg_op = 'DELETE' then old else new end;
end;
$$;
create trigger articles_public_build_outbox after insert or update or delete on public.articles
for each row execute function public.fixture_capture_outbox();
create trigger article_translations_public_build_outbox after insert or update or delete on public.article_translations
for each row execute function public.fixture_capture_outbox();
create trigger redirects_public_build_outbox after insert or update or delete on public.redirects
for each row execute function public.fixture_capture_outbox();

alter table public.articles enable row level security;
alter table public.article_translations enable row level security;
alter table public.redirects enable row level security;
alter table public.admin_audit_log enable row level security;
grant usage on schema public to authenticated;
grant select, insert, update, delete on public.articles to authenticated;
grant select, insert, update, delete on public.article_translations to authenticated;
grant select, insert, update on public.redirects to authenticated;
grant select, insert on public.admin_audit_log to authenticated;
-- These are assertion-only reads in this isolated integration fixture. The
-- production privilege model remains unchanged.
grant select on public.article_revisions to authenticated;
grant select on public.article_translation_revisions to authenticated;
grant select on public.public_build_outbox to authenticated;
grant usage, select on all sequences in schema public to authenticated;

create policy "Staff read articles" on public.articles for select to authenticated
using (public.is_staff());
create policy "Staff create articles" on public.articles for insert to authenticated
with check (public.is_staff() and created_by = (select auth.uid()) and updated_by = (select auth.uid()));
create policy "Staff update articles" on public.articles for update to authenticated
using (public.is_staff()) with check (public.is_staff() and updated_by = (select auth.uid()));
create policy "Staff read article translations" on public.article_translations for select to authenticated
using (public.is_staff());
create policy "Staff create article translations" on public.article_translations for insert to authenticated
with check (public.is_staff() and created_by = (select auth.uid()) and updated_by = (select auth.uid()));
create policy "Staff update article translations" on public.article_translations for update to authenticated
using (public.is_staff()) with check (public.is_staff() and updated_by = (select auth.uid()));
create policy "Staff manage redirects" on public.redirects for all to authenticated
using (public.is_staff()) with check (public.is_staff() and created_by = (select auth.uid()));
create policy "Staff append audit log" on public.admin_audit_log for insert to authenticated
with check (public.is_staff() and actor_id = (select auth.uid()));

-- The migration's schema-health function expects these names to exist or be
-- safely probeable. Only public_build_outbox is referenced as a real relation.
create or replace function public.enqueue_public_build_request(text,text,text,jsonb)
returns bigint language sql as $$ select 1::bigint $$;
create or replace function public.move_homepage_block(uuid,text)
returns boolean language sql as $$ select true $$;


create role service_role nologin bypassrls;
create type public.page_status as enum ('draft','published','hidden');
create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 2 and 180),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,119}$'),
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  status public.page_status not null default 'draft',
  seo_title text,
  seo_description text,
  canonical_url text,
  allow_indexing boolean not null default true,
  created_by uuid not null references auth.users(id) on delete restrict,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.page_revisions (
  id bigint generated always as identity primary key,
  page_id uuid not null references public.pages(id) on delete cascade,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (page_id, revision_number)
);

alter table public.pages enable row level security;
alter table public.page_revisions enable row level security;
create policy "Public read published pages"
on public.pages for select
to anon, authenticated
using (
  (status = 'published' and deleted_at is null)
);

create policy "Staff manage pages"
on public.pages for all
to authenticated
using (public.is_staff())
with check (
  public.is_staff()
  and created_by is not null
  and updated_by = (select auth.uid())
);

create policy "Staff read page revisions"
on public.page_revisions for select
to authenticated
using (public.is_staff());


grant select, insert, update, delete on public.pages to authenticated;
grant select on public.page_revisions to authenticated;
create or replace function public.fixture_page_set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
create trigger pages_set_updated_at before update on public.pages
for each row execute function public.fixture_page_set_updated_at();
-- Version history for permanent CMS pages.
-- Article revisions were part of the initial CMS migration; pages use the
-- same immutable-snapshot model so every editorial change is recoverable.

create or replace function public.capture_page_revision()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_revision integer;
begin
  if old is not distinct from new then
    return new;
  end if;

  select coalesce(max(revision_number), 0) + 1
  into next_revision
  from public.page_revisions
  where page_id = old.id;

  insert into public.page_revisions (
    page_id,
    revision_number,
    snapshot,
    changed_by
  )
  values (
    old.id,
    next_revision,
    to_jsonb(old),
    coalesce(new.updated_by, (select auth.uid()))
  );

  return new;
end;
$$;

drop trigger if exists pages_capture_revision on public.pages;
create trigger pages_capture_revision
  before update on public.pages
  for each row execute function public.capture_page_revision();

create index if not exists page_revisions_page_idx
  on public.page_revisions(page_id, revision_number desc);

create trigger pages_public_build_outbox after insert or update or delete on public.pages
for each row execute function public.fixture_capture_outbox();
create or replace function public.capture_public_build_outbox()
returns trigger language plpgsql security definer set search_path = '' as $$
begin return case when tg_op = 'DELETE' then old else new end; end;
$$;
-- Save the canonical Russian article row and its optional English translation in
-- one PostgreSQL transaction. Existing revision and public-build outbox triggers
-- remain authoritative and therefore commit or roll back with this function.
--
-- The function is deliberately SECURITY INVOKER: authenticated staff keep the
-- existing RLS checks and no privileged service-role path is introduced.

create or replace function public.save_article_bundle(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz,
  p_article_payload jsonb,
  p_english_mode text default 'none',
  p_english_payload jsonb default null,
  p_expected_english_updated_at timestamptz default null,
  p_redirect_source_path text default null,
  p_redirect_destination_path text default null,
  p_replace_homepage boolean default false,
  p_audit_action text default null,
  p_audit_metadata jsonb default '{}'::jsonb,
  p_social_publish_requested boolean default false,
  p_social_metadata jsonb default '{}'::jsonb
)
returns table (
  article_id uuid,
  article_updated_at timestamptz,
  english_updated_at timestamptz,
  homepage_replaced integer
)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  current_article public.articles%rowtype;
  current_english public.article_translations%rowtype;
  saved_article public.articles%rowtype;
  saved_english public.article_translations%rowtype;
  has_article boolean := false;
  has_english boolean := false;
  article_keywords text[];
  english_keywords text[];
  replaced_count integer := 0;
  effective_audit_action text;
begin
  if actor_id is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;

  if p_article_payload is null
    or jsonb_typeof(p_article_payload) <> 'object' then
    raise exception using errcode = '22023', message = 'ARTICLE_PAYLOAD_REQUIRED';
  end if;

  if p_english_mode not in ('none', 'save', 'stale') then
    raise exception using errcode = '22023', message = 'INVALID_ENGLISH_MODE';
  end if;

  if p_english_mode = 'save'
    and (p_english_payload is null or jsonb_typeof(p_english_payload) <> 'object') then
    raise exception using errcode = '22023', message = 'ENGLISH_PAYLOAD_REQUIRED';
  end if;

  article_keywords := coalesce(
    array(
      select jsonb_array_elements_text(
        coalesce(p_article_payload -> 'seo_keywords', '[]'::jsonb)
      )
    ),
    '{}'::text[]
  );

  if p_english_mode = 'save' then
    english_keywords := coalesce(
      array(
        select jsonb_array_elements_text(
          coalesce(p_english_payload -> 'seo_keywords', '[]'::jsonb)
        )
      ),
      '{}'::text[]
    );
  end if;

  -- Lock and validate both rows before the article UPDATE. Updating an article
  -- can legitimately mark a released English translation stale through the
  -- existing sync trigger, which also changes its updated_at. Checking the
  -- English timestamp after that trigger would create a false conflict.
  if p_article_id is not null then
    select *
    into current_article
    from public.articles
    where id = p_article_id
    for update;
    has_article := found;

    if not has_article then
      raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
    end if;

    if p_expected_article_updated_at is null
      or current_article.updated_at is distinct from p_expected_article_updated_at then
      raise exception using errcode = 'P0001', message = 'ARTICLE_CONFLICT';
    end if;

    if p_english_mode in ('save', 'stale') then
      select english_translation.*
      into current_english
      from public.article_translations as english_translation
      where english_translation.article_id = p_article_id
        and english_translation.locale = 'en'
      for update;
      has_english := found;

      if has_english then
        if p_expected_english_updated_at is null
          or current_english.updated_at is distinct from p_expected_english_updated_at then
          raise exception using errcode = 'P0001', message = 'ENGLISH_CONFLICT';
        end if;
      elsif p_expected_english_updated_at is not null then
        raise exception using errcode = 'P0001', message = 'ENGLISH_CONFLICT';
      end if;
    end if;

    update public.articles
    set
      title = p_article_payload ->> 'title',
      subtitle = coalesce(p_article_payload ->> 'subtitle', ''),
      excerpt = coalesce(p_article_payload ->> 'excerpt', ''),
      slug = p_article_payload ->> 'slug',
      content_html = coalesce(p_article_payload ->> 'content_html', ''),
      content_json = coalesce(
        p_article_payload -> 'content_json',
        '{"type":"doc","content":[]}'::jsonb
      ),
      category_id = nullif(p_article_payload ->> 'category_id', '')::uuid,
      status = (p_article_payload ->> 'status')::public.article_status,
      scheduled_at = nullif(p_article_payload ->> 'scheduled_at', '')::timestamptz,
      published_at = nullif(p_article_payload ->> 'published_at', '')::timestamptz,
      cover_external_url = nullif(p_article_payload ->> 'cover_external_url', ''),
      cover_alt = coalesce(p_article_payload ->> 'cover_alt', ''),
      legacy_path = nullif(p_article_payload ->> 'legacy_path', ''),
      seo_title = nullif(p_article_payload ->> 'seo_title', ''),
      seo_description = nullif(p_article_payload ->> 'seo_description', ''),
      seo_keywords = article_keywords,
      canonical_url = nullif(p_article_payload ->> 'canonical_url', ''),
      og_title = nullif(p_article_payload ->> 'og_title', ''),
      og_description = nullif(p_article_payload ->> 'og_description', ''),
      allow_indexing = coalesce((p_article_payload ->> 'allow_indexing')::boolean, true),
      sources = coalesce(p_article_payload -> 'sources', '[]'::jsonb),
      bibliography = coalesce(p_article_payload -> 'bibliography', '[]'::jsonb),
      featured = coalesce((p_article_payload ->> 'featured')::boolean, false),
      show_on_homepage = coalesce(
        (p_article_payload ->> 'show_on_homepage')::boolean,
        false
      ),
      pinned = coalesce((p_article_payload ->> 'pinned')::boolean, false),
      updated_by = actor_id
    where id = p_article_id
    returning * into saved_article;
  else
    if p_expected_article_updated_at is not null then
      raise exception using errcode = 'P0001', message = 'ARTICLE_CONFLICT';
    end if;

    insert into public.articles (
      title,
      subtitle,
      excerpt,
      slug,
      content_html,
      content_json,
      category_id,
      status,
      scheduled_at,
      published_at,
      cover_external_url,
      cover_alt,
      legacy_path,
      seo_title,
      seo_description,
      seo_keywords,
      canonical_url,
      og_title,
      og_description,
      allow_indexing,
      sources,
      bibliography,
      featured,
      show_on_homepage,
      pinned,
      created_by,
      updated_by
    ) values (
      p_article_payload ->> 'title',
      coalesce(p_article_payload ->> 'subtitle', ''),
      coalesce(p_article_payload ->> 'excerpt', ''),
      p_article_payload ->> 'slug',
      coalesce(p_article_payload ->> 'content_html', ''),
      coalesce(
        p_article_payload -> 'content_json',
        '{"type":"doc","content":[]}'::jsonb
      ),
      nullif(p_article_payload ->> 'category_id', '')::uuid,
      (p_article_payload ->> 'status')::public.article_status,
      nullif(p_article_payload ->> 'scheduled_at', '')::timestamptz,
      nullif(p_article_payload ->> 'published_at', '')::timestamptz,
      nullif(p_article_payload ->> 'cover_external_url', ''),
      coalesce(p_article_payload ->> 'cover_alt', ''),
      nullif(p_article_payload ->> 'legacy_path', ''),
      nullif(p_article_payload ->> 'seo_title', ''),
      nullif(p_article_payload ->> 'seo_description', ''),
      article_keywords,
      nullif(p_article_payload ->> 'canonical_url', ''),
      nullif(p_article_payload ->> 'og_title', ''),
      nullif(p_article_payload ->> 'og_description', ''),
      coalesce((p_article_payload ->> 'allow_indexing')::boolean, true),
      coalesce(p_article_payload -> 'sources', '[]'::jsonb),
      coalesce(p_article_payload -> 'bibliography', '[]'::jsonb),
      coalesce((p_article_payload ->> 'featured')::boolean, false),
      coalesce((p_article_payload ->> 'show_on_homepage')::boolean, false),
      coalesce((p_article_payload ->> 'pinned')::boolean, false),
      actor_id,
      actor_id
    )
    returning * into saved_article;
  end if;

  if p_english_mode = 'save' then
    if has_english then
      update public.article_translations
      set
        title = p_english_payload ->> 'title',
        subtitle = coalesce(p_english_payload ->> 'subtitle', ''),
        excerpt = coalesce(p_english_payload ->> 'excerpt', ''),
        content_json = coalesce(
          p_english_payload -> 'content_json',
          '{"type":"doc","content":[]}'::jsonb
        ),
        content_html = coalesce(p_english_payload ->> 'content_html', ''),
        cover_alt = coalesce(p_english_payload ->> 'cover_alt', ''),
        slug = p_english_payload ->> 'slug',
        sources = coalesce(p_english_payload -> 'sources', '[]'::jsonb),
        bibliography = coalesce(
          p_english_payload -> 'bibliography',
          '[]'::jsonb
        ),
        seo_title = nullif(p_english_payload ->> 'seo_title', ''),
        seo_description = nullif(p_english_payload ->> 'seo_description', ''),
        seo_keywords = english_keywords,
        canonical_url = nullif(p_english_payload ->> 'canonical_url', ''),
        og_title = nullif(p_english_payload ->> 'og_title', ''),
        og_description = nullif(p_english_payload ->> 'og_description', ''),
        status = (p_english_payload ->> 'status')::public.article_translation_status,
        source_content_hash = nullif(
          p_english_payload ->> 'source_content_hash',
          ''
        ),
        source_article_updated_at = saved_article.updated_at,
        reviewed_by = case
          when nullif(p_english_payload ->> 'reviewed_at', '') is null
            then null
          else actor_id
        end,
        reviewed_at = nullif(p_english_payload ->> 'reviewed_at', '')::timestamptz,
        approved_by = case
          when nullif(p_english_payload ->> 'approved_at', '') is null
            then null
          else actor_id
        end,
        approved_at = nullif(p_english_payload ->> 'approved_at', '')::timestamptz,
        published_at = nullif(p_english_payload ->> 'published_at', '')::timestamptz,
        updated_by = actor_id,
        deleted_at = nullif(p_english_payload ->> 'deleted_at', '')::timestamptz
      where id = current_english.id
      returning * into saved_english;
    else
      insert into public.article_translations (
        article_id,
        locale,
        title,
        subtitle,
        excerpt,
        content_json,
        content_html,
        cover_alt,
        slug,
        sources,
        bibliography,
        seo_title,
        seo_description,
        seo_keywords,
        canonical_url,
        og_title,
        og_description,
        status,
        source_content_hash,
        source_article_updated_at,
        reviewed_by,
        reviewed_at,
        approved_by,
        approved_at,
        published_at,
        created_by,
        updated_by,
        deleted_at
      ) values (
        saved_article.id,
        'en',
        p_english_payload ->> 'title',
        coalesce(p_english_payload ->> 'subtitle', ''),
        coalesce(p_english_payload ->> 'excerpt', ''),
        coalesce(
          p_english_payload -> 'content_json',
          '{"type":"doc","content":[]}'::jsonb
        ),
        coalesce(p_english_payload ->> 'content_html', ''),
        coalesce(p_english_payload ->> 'cover_alt', ''),
        p_english_payload ->> 'slug',
        coalesce(p_english_payload -> 'sources', '[]'::jsonb),
        coalesce(p_english_payload -> 'bibliography', '[]'::jsonb),
        nullif(p_english_payload ->> 'seo_title', ''),
        nullif(p_english_payload ->> 'seo_description', ''),
        english_keywords,
        nullif(p_english_payload ->> 'canonical_url', ''),
        nullif(p_english_payload ->> 'og_title', ''),
        nullif(p_english_payload ->> 'og_description', ''),
        (p_english_payload ->> 'status')::public.article_translation_status,
        nullif(p_english_payload ->> 'source_content_hash', ''),
        saved_article.updated_at,
        case
          when nullif(p_english_payload ->> 'reviewed_at', '') is null
            then null
          else actor_id
        end,
        nullif(p_english_payload ->> 'reviewed_at', '')::timestamptz,
        case
          when nullif(p_english_payload ->> 'approved_at', '') is null
            then null
          else actor_id
        end,
        nullif(p_english_payload ->> 'approved_at', '')::timestamptz,
        nullif(p_english_payload ->> 'published_at', '')::timestamptz,
        actor_id,
        actor_id,
        nullif(p_english_payload ->> 'deleted_at', '')::timestamptz
      )
      returning * into saved_english;
    end if;
  elsif p_english_mode = 'stale' and has_english then
    update public.article_translations
    set
      status = 'stale',
      approved_by = null,
      approved_at = null,
      published_at = null,
      updated_by = actor_id
    where id = current_english.id
    returning * into saved_english;
  end if;

  if nullif(trim(coalesce(p_redirect_source_path, '')), '') is not null
    and nullif(trim(coalesce(p_redirect_destination_path, '')), '') is not null
    and p_redirect_source_path is distinct from p_redirect_destination_path then
    insert into public.redirects (
      source_path,
      destination_path,
      status_code,
      is_active,
      created_by
    ) values (
      p_redirect_source_path,
      p_redirect_destination_path,
      301,
      true,
      actor_id
    )
    on conflict (source_path) do update set
      destination_path = excluded.destination_path,
      status_code = 301,
      is_active = true,
      created_by = actor_id;
  end if;

  if p_replace_homepage
    and saved_article.status = 'published'
    and saved_article.show_on_homepage
    and saved_article.category_id is not null then
    update public.articles
    set
      show_on_homepage = false,
      updated_by = actor_id
    where category_id = saved_article.category_id
      and status = 'published'
      and show_on_homepage
      and id <> saved_article.id;
    get diagnostics replaced_count = row_count;
  end if;

  effective_audit_action := coalesce(
    nullif(trim(coalesce(p_audit_action, '')), ''),
    case when p_article_id is null then 'article.created' else 'article.updated' end
  );

  insert into public.admin_audit_log (
    actor_id,
    action,
    entity_type,
    entity_id,
    metadata
  ) values (
    actor_id,
    effective_audit_action,
    'article',
    saved_article.id::text,
    coalesce(p_audit_metadata, '{}'::jsonb)
  );

  if p_social_publish_requested then
    insert into public.admin_audit_log (
      actor_id,
      action,
      entity_type,
      entity_id,
      metadata
    ) values (
      actor_id,
      'social_publish.requested',
      'article',
      saved_article.id::text,
      coalesce(p_social_metadata, '{}'::jsonb)
    );
  end if;

  return query
  select
    saved_article.id,
    saved_article.updated_at,
    case
      when p_english_mode in ('save', 'stale') and saved_english.id is not null
        then saved_english.updated_at
      else null
    end,
    replaced_count;
end;
$$;

revoke all on function public.save_article_bundle(
  uuid,
  timestamptz,
  jsonb,
  text,
  jsonb,
  timestamptz,
  text,
  text,
  boolean,
  text,
  jsonb,
  boolean,
  jsonb
) from public;
grant execute on function public.save_article_bundle(
  uuid,
  timestamptz,
  jsonb,
  text,
  jsonb,
  timestamptz,
  text,
  text,
  boolean,
  text,
  jsonb,
  boolean,
  jsonb
) to authenticated;

-- Keep the staff-only schema health probe synchronized with this canonical RPC.
create or replace function public.get_editorial_schema_health()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when public.is_staff() then jsonb_build_object(
      'version', '20260822_zz_atomic_article_bundle',
      'checkedAt', now(),
      'outbox', to_regclass('public.public_build_outbox') is not null,
      'outboxRpc',
        to_regprocedure(
          'public.enqueue_public_build_request(text,text,text,jsonb)'
        ) is not null,
      'articleBundleRpc',
        to_regprocedure(
          'public.save_article_bundle(uuid,timestamptz,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
        ) is not null,
      'migrationLedger',
        to_regclass('public.probpera_schema_migrations') is not null,
      'publicationTriggers', (
        select count(*) = 21
        from pg_catalog.pg_trigger outbox_trigger
        join pg_catalog.pg_class relation
          on relation.oid = outbox_trigger.tgrelid
        join pg_catalog.pg_namespace namespace
          on namespace.oid = relation.relnamespace
        where namespace.nspname = 'public'
          and not outbox_trigger.tgisinternal
          and outbox_trigger.tgfoid =
            'public.capture_public_build_outbox()'::regprocedure
          and outbox_trigger.tgname =
            (relation.relname::text || '_public_build_outbox')::name
          and relation.relname = any(array[
            'articles',
            'article_tags',
            'article_translations',
            'pages',
            'homepage_blocks',
            'banners',
            'navigation_menus',
            'navigation_items',
            'redirects',
            'categories',
            'tags',
            'media_assets',
            'media_usages',
            'literary_works',
            'literary_work_translations',
            'literary_work_sources',
            'literary_work_external_ids',
            'book_editions',
            'writer_profile_overrides',
            'country_profile_overrides',
            'literary_work_cover_artworks'
          ]::name[])
      ),
      'staffEditorialReadPolicies', (
        select count(*) = 3
        from pg_catalog.pg_policies
        where schemaname = 'public'
          and cmd = 'SELECT'
          and roles = array['authenticated'::name]
          and position('is_staff' in coalesce(qual, '')) > 0
          and (
            (tablename = 'articles' and policyname = 'Staff read articles')
            or (
              tablename = 'article_translations'
              and policyname = 'Staff read article translations'
            )
            or (
              tablename = 'media_assets'
              and policyname = 'Staff read media metadata'
            )
          )
      ),
      'pendingPublicBuilds', (
        select count(*)
        from public.public_build_outbox
        where status in ('requested', 'dispatched', 'failed')
      ),
      'revisionHistory',
        to_regclass('public.admin_revision_history') is not null,
      'workTranslations',
        to_regclass('public.literary_work_translations') is not null,
      'workCoverArtworks',
        to_regclass('public.literary_work_cover_artworks') is not null,
      'countryOverrides',
        to_regclass('public.country_profile_overrides') is not null,
      'writerOverrides',
        to_regclass('public.writer_profile_overrides') is not null,
      'homepageMove',
        to_regprocedure('public.move_homepage_block(uuid,text)') is not null,
      'tagsUpdatedAt', exists (
        select 1
        from information_schema.columns
        where table_schema = 'public'
          and table_name = 'tags'
          and column_name = 'updated_at'
      )
    )
    else null
  end;
$$;

revoke all on function public.get_editorial_schema_health() from public;
grant execute on function public.get_editorial_schema_health()
  to authenticated;

-- Private working copies for editing an already published article without
-- mutating its public row until the normal atomic publication flow succeeds.

create table if not exists public.article_working_drafts (
  article_id uuid primary key
    references public.articles(id) on update cascade on delete cascade,
  base_article_updated_at timestamptz not null,
  payload jsonb not null,
  english_payload jsonb not null,
  expected_english_updated_at timestamptz,
  version bigint not null default 1,
  actor_id uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint article_working_drafts_payload_object_check
    check (jsonb_typeof(payload) = 'object'),
  constraint article_working_drafts_payload_size_check
    check (octet_length(payload::text) <= 5242880),
  constraint article_working_drafts_english_payload_check
    check (
      jsonb_typeof(english_payload) = 'object'
      and octet_length(english_payload::text) <= 5242880
      and (
        english_payload = '{"mode":"disabled"}'::jsonb
        or (
          english_payload ->> 'mode' = 'save'
          and jsonb_typeof(english_payload -> 'payload') = 'object'
        )
      )
    ),
  constraint article_working_drafts_version_check check (version > 0),
  constraint article_working_drafts_timestamp_order_check
    check (updated_at >= created_at)
);

create index if not exists article_working_drafts_updated_idx
  on public.article_working_drafts(updated_at desc, article_id);
create index if not exists article_working_drafts_actor_idx
  on public.article_working_drafts(actor_id, updated_at desc);

alter table public.article_working_drafts enable row level security;
alter table public.article_working_drafts force row level security;
revoke all on table public.article_working_drafts from public, anon, authenticated;
grant select on table public.article_working_drafts to authenticated;
grant all on table public.article_working_drafts to service_role;

-- Editors may prepare drafts and send them to review, but only owners/admins
-- may mutate the public/scheduled article rows.  Keep this boundary in RLS so
-- a handcrafted PostgREST/RPC request cannot bypass the server action check.
drop policy if exists "Staff create articles" on public.articles;
create policy "Staff create articles"
  on public.articles for insert to authenticated
  with check (
    public.is_staff()
    and created_by = (select auth.uid())
    and updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or status in ('draft', 'review')
    )
  );

drop policy if exists "Staff update articles" on public.articles;
create policy "Staff update articles"
  on public.articles for update to authenticated
  using (
    public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
    or (
      public.is_staff(array['editor'::public.staff_role])
      and status in ('draft', 'review')
    )
  )
  with check (
    updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review')
      )
    )
  );

-- Apply the same release boundary to article translations.  Editors may work
-- only inside an unpublished parent and may never manufacture an approved,
-- published or archived translation through direct PostgREST writes.
drop policy if exists "Staff create article translations"
  on public.article_translations;
create policy "Staff create article translations"
  on public.article_translations for insert to authenticated
  with check (
    created_by = (select auth.uid())
    and updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review')
        and approved_by is null
        and approved_at is null
        and published_at is null
        and deleted_at is null
        and exists (
          select 1
          from public.articles parent_article
          where parent_article.id = article_id
            and parent_article.status in ('draft', 'review')
            and parent_article.deleted_at is null
        )
      )
    )
  );

drop policy if exists "Staff update article translations"
  on public.article_translations;
create policy "Staff update article translations"
  on public.article_translations for update to authenticated
  using (
    public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
    or (
      public.is_staff(array['editor'::public.staff_role])
      and deleted_at is null
      and exists (
        select 1
        from public.articles parent_article
        where parent_article.id = article_id
          and parent_article.status in ('draft', 'review')
          and parent_article.deleted_at is null
      )
    )
  )
  with check (
    updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review', 'stale')
        and approved_by is null
        and approved_at is null
        and published_at is null
        and deleted_at is null
        and exists (
          select 1
          from public.articles parent_article
          where parent_article.id = article_id
            and parent_article.status in ('draft', 'review')
            and parent_article.deleted_at is null
        )
      )
    )
  );

drop policy if exists "Staff read article working drafts"
  on public.article_working_drafts;
create policy "Staff read article working drafts"
  on public.article_working_drafts
  for select to authenticated
  using (public.is_staff());

create or replace function public.save_article_working_draft(
  p_article_id uuid,
  p_base_article_updated_at timestamptz,
  p_payload jsonb,
  p_english_payload jsonb,
  p_expected_english_updated_at timestamptz,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_article public.articles%rowtype;
  current_english_updated_at timestamptz;
  current_draft public.article_working_drafts%rowtype;
  saved public.article_working_drafts%rowtype;
begin
  if actor is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'staff-required';
  end if;
  if p_article_id is null
    or p_base_article_updated_at is null
    or p_expected_version is null
    or p_expected_version < 0
    or jsonb_typeof(p_payload) is distinct from 'object'
    or octet_length(p_payload::text) > 5242880
    or (
      jsonb_typeof(p_english_payload) is distinct from 'object'
      or octet_length(p_english_payload::text) > 5242880
      or not (
        p_english_payload = '{"mode":"disabled"}'::jsonb
        or (
          p_english_payload ->> 'mode' = 'save'
          and jsonb_typeof(p_english_payload -> 'payload') = 'object'
        )
      )
    ) then
    raise exception using errcode = '22023', message = 'working-draft-invalid';
  end if;

  select * into current_article
  from public.articles
  where id = p_article_id
  for update;
  if not found or current_article.deleted_at is not null
    or current_article.status is distinct from 'published'::public.article_status then
    raise exception using errcode = 'P0001', message = 'published-article-required';
  end if;
  if current_article.updated_at is distinct from p_base_article_updated_at then
    raise exception using errcode = '40001', message = 'article-version-conflict';
  end if;

  select translation.updated_at into current_english_updated_at
  from public.article_translations translation
  where translation.article_id = p_article_id
    and translation.locale = 'en'
    and translation.deleted_at is null
  for update;
  if current_english_updated_at is distinct from p_expected_english_updated_at then
    raise exception using errcode = '40001', message = 'english-version-conflict';
  end if;

  select * into current_draft
  from public.article_working_drafts
  where article_id = p_article_id
  for update;
  if found then
    if current_draft.version is distinct from p_expected_version then
      raise exception using errcode = '40001', message = 'working-draft-version-conflict';
    end if;
    update public.article_working_drafts
    set base_article_updated_at = p_base_article_updated_at,
        payload = p_payload,
        english_payload = p_english_payload,
        expected_english_updated_at = p_expected_english_updated_at,
        version = current_draft.version + 1,
        actor_id = actor,
        updated_at = now()
    where article_id = p_article_id and version = p_expected_version
    returning * into saved;
  else
    if p_expected_version <> 0 then
      raise exception using errcode = '40001', message = 'working-draft-version-conflict';
    end if;
    insert into public.article_working_drafts (
      article_id, base_article_updated_at, payload, english_payload,
      expected_english_updated_at, version, actor_id
    ) values (
      p_article_id, p_base_article_updated_at, p_payload, p_english_payload,
      p_expected_english_updated_at, 1, actor
    ) returning * into saved;
  end if;

  if saved.article_id is null then
    raise exception using errcode = '40001', message = 'working-draft-version-conflict';
  end if;
  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor,
    'article.working_draft.saved',
    'article',
    saved.article_id::text,
    jsonb_build_object(
      'version', saved.version,
      'baseArticleUpdatedAt', saved.base_article_updated_at,
      'hasEnglish', saved.english_payload ->> 'mode' = 'save'
    )
  );
  return jsonb_build_object(
    'articleId', saved.article_id,
    'version', saved.version,
    'updatedAt', saved.updated_at
  );
end;
$$;

create or replace function public.discard_article_working_draft(
  p_article_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_version bigint;
begin
  if actor is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'staff-required';
  end if;
  if p_article_id is null or p_expected_version is null or p_expected_version < 1 then
    raise exception using errcode = '22023', message = 'working-draft-invalid';
  end if;
  select version into current_version
  from public.article_working_drafts
  where article_id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'working-draft-not-found';
  end if;
  if current_version is distinct from p_expected_version then
    raise exception using errcode = '40001', message = 'working-draft-version-conflict';
  end if;
  delete from public.article_working_drafts
  where article_id = p_article_id and version = p_expected_version;
  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor,
    'article.working_draft.discarded',
    'article',
    p_article_id::text,
    jsonb_build_object('version', p_expected_version)
  );
  return jsonb_build_object('articleId', p_article_id, 'discarded', true);
end;
$$;

create or replace function public.clear_article_working_draft_after_promotion()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  delete from public.article_working_drafts where article_id = new.id;
  return new;
end;
$$;

-- An existing privileged release must not erase a newer working copy.  The
-- guard makes the legacy bundle RPC fail closed whenever a working draft is
-- present; only the promotion RPC below installs the transaction-local CAS
-- evidence after locking article -> draft in the canonical order.
create or replace function public.guard_article_working_draft_promotion()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_draft_version bigint;
  expected_promotion text;
begin
  if new.status not in ('published', 'scheduled', 'hidden', 'archived') then
    return new;
  end if;

  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = new.id
  for update;
  if not found then
    return new;
  end if;

  expected_promotion := nullif(
    current_setting('probpera.expected_working_draft_promotion', true),
    ''
  );
  if expected_promotion is distinct from
    (new.id::text || ':' || current_draft_version::text) then
    raise exception using
      errcode = '40001',
      message = 'WORKING_DRAFT_CONFLICT';
  end if;
  return new;
end;
$$;

create or replace function public.promote_article_working_draft(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz,
  p_expected_working_draft_version bigint,
  p_article_payload jsonb,
  p_english_mode text,
  p_english_payload jsonb,
  p_expected_english_updated_at timestamptz,
  p_redirect_source_path text,
  p_redirect_destination_path text,
  p_replace_homepage boolean,
  p_audit_action text,
  p_audit_metadata jsonb,
  p_social_publish_requested boolean,
  p_social_metadata jsonb
)
returns table (
  article_id uuid,
  article_updated_at timestamptz,
  english_updated_at timestamptz,
  homepage_replaced integer
)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  current_article_updated_at timestamptz;
  current_draft_version bigint;
  has_working_draft boolean := false;
  target_status text := p_article_payload ->> 'status';
begin
  if (select auth.uid()) is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  if p_article_id is null
    or p_expected_article_updated_at is null
    or p_expected_working_draft_version is null
    or p_expected_working_draft_version < 0 then
    raise exception using errcode = '22023', message = 'PROMOTION_INPUT_INVALID';
  end if;
  if target_status is null
    or target_status not in ('published', 'scheduled', 'hidden', 'archived') then
    raise exception using errcode = '22023', message = 'PROMOTION_STATUS_REQUIRED';
  end if;

  select article.updated_at
  into current_article_updated_at
  from public.articles article
  where article.id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
  end if;
  if current_article_updated_at is distinct from p_expected_article_updated_at then
    raise exception using errcode = '40001', message = 'ARTICLE_CONFLICT';
  end if;

  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  has_working_draft := found;
  if (
    p_expected_working_draft_version = 0
    and has_working_draft
  ) or (
    p_expected_working_draft_version > 0
    and (
      not has_working_draft
      or current_draft_version is distinct from p_expected_working_draft_version
    )
  ) then
    raise exception using errcode = '40001', message = 'WORKING_DRAFT_CONFLICT';
  end if;

  perform set_config(
    'probpera.expected_working_draft_promotion',
    p_article_id::text || ':' || p_expected_working_draft_version::text,
    true
  );

  return query
  select bundle.article_id,
         bundle.article_updated_at,
         bundle.english_updated_at,
         bundle.homepage_replaced
  from public.save_article_bundle(
    p_article_id,
    p_expected_article_updated_at,
    p_article_payload,
    p_english_mode,
    p_english_payload,
    p_expected_english_updated_at,
    p_redirect_source_path,
    p_redirect_destination_path,
    p_replace_homepage,
    p_audit_action,
    p_audit_metadata,
    p_social_publish_requested,
    p_social_metadata
  ) bundle;
end;
$$;

drop trigger if exists articles_guard_working_draft_promotion
  on public.articles;
create trigger articles_guard_working_draft_promotion
before update on public.articles
for each row
when (new.status in ('published', 'scheduled', 'hidden', 'archived'))
execute function public.guard_article_working_draft_promotion();

drop trigger if exists articles_clear_working_draft_after_promotion
  on public.articles;
create trigger articles_clear_working_draft_after_promotion
after update on public.articles
for each row
when (new.status in ('published', 'scheduled', 'hidden', 'archived'))
execute function public.clear_article_working_draft_after_promotion();

revoke all on function public.save_article_working_draft(
  uuid, timestamptz, jsonb, jsonb, timestamptz, bigint
) from public, anon, authenticated, service_role;
revoke all on function public.discard_article_working_draft(uuid, bigint)
  from public, anon, authenticated, service_role;
revoke all on function public.clear_article_working_draft_after_promotion()
  from public, anon, authenticated, service_role;
revoke all on function public.guard_article_working_draft_promotion()
  from public, anon, authenticated, service_role;
revoke all on function public.promote_article_working_draft(
  uuid, timestamptz, bigint, jsonb, text, jsonb, timestamptz, text, text,
  boolean, text, jsonb, boolean, jsonb
) from public, anon, authenticated, service_role;
grant execute on function public.save_article_working_draft(
  uuid, timestamptz, jsonb, jsonb, timestamptz, bigint
) to authenticated;
grant execute on function public.discard_article_working_draft(uuid, bigint)
  to authenticated;
grant execute on function public.promote_article_working_draft(
  uuid, timestamptz, bigint, jsonb, text, jsonb, timestamptz, text, text,
  boolean, text, jsonb, boolean, jsonb
) to authenticated;

create or replace function public.assert_redirect_candidate(
  p_id uuid,
  p_source_path text,
  p_destination_path text,
  p_is_active boolean
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  normalized_source text := regexp_replace(p_source_path, '/+$', '');
  normalized_destination text := case
    when p_destination_path like '/%' then regexp_replace(p_destination_path, '/+$', '')
    else p_destination_path
  end;
begin
  normalized_source := case when normalized_source = '' then '/' else normalized_source end;
  normalized_destination := case when normalized_destination = '' then '/' else normalized_destination end;
  if char_length(normalized_source) > 500
    or char_length(normalized_destination) > 500
    or normalized_source !~ '^/(?:$|[^/\\])'
    or normalized_source ~ '[[:cntrl:]\\]'
    or not (
      normalized_destination ~ '^/(?:$|[^/\\])'
      or normalized_destination ~ '^https://[^/[:space:]]+(?:/.*)?$'
    )
    or normalized_destination ~ '[[:cntrl:]\\]' then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_PATH';
  end if;
  if normalized_source = normalized_destination then
    raise exception using errcode = 'P0001', message = 'REDIRECT_SELF_REFERENCE';
  end if;

  if p_is_active and exists (
    select 1 from public.redirects r
    where r.id is distinct from p_id and r.is_active
      and (
        r.source_path = normalized_source
        or (normalized_destination like '/%' and r.source_path = normalized_destination)
        or r.destination_path = normalized_source
      )
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_COLLISION_OR_CHAIN';
  end if;

  if p_is_active and exists (
    select 1 from public.pages p
    where p.deleted_at is null and p.status = 'published'
      and (
        '/stranitsy/' || p.slug = normalized_source
        or regexp_replace(
          regexp_replace(coalesce(p.canonical_url, ''), '^https://[^/]+', ''),
          '/+$', ''
        ) = normalized_source
      )
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_LIVE_ROUTE_COLLISION';
  end if;

  if p_is_active and exists (
    select 1 from public.articles a
    where a.deleted_at is null and a.status = 'published'
      and regexp_replace(
        regexp_replace(coalesce(a.canonical_url, ''), '^https://[^/]+', ''),
        '/+$', ''
      ) = normalized_source
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_LIVE_ROUTE_COLLISION';
  end if;
end;
$$;
create or replace function public.create_seo_redirect_guarded(
  p_source_path text,
  p_destination_path text,
  p_status_code smallint,
  p_is_active boolean
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  redirect_id uuid;
begin
  perform pg_advisory_xact_lock(188654771, 3);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  if p_status_code not in (301, 302, 307, 308) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_STATUS';
  end if;
  perform public.assert_redirect_candidate(null, p_source_path, p_destination_path, p_is_active);
  insert into public.redirects (
    source_path, destination_path, status_code, is_active, created_by
  ) values (
    coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/'),
    case when p_destination_path like '/%' then coalesce(nullif(regexp_replace(p_destination_path, '/+$', ''), ''), '/') else p_destination_path end,
    p_status_code, p_is_active, actor_user_id
  ) returning id into redirect_id;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id, metadata)
  values (actor_user_id, 'redirect.created', 'redirect', redirect_id::text,
    jsonb_build_object('sourcePath', p_source_path, 'destinationPath', p_destination_path,
      'statusCode', p_status_code, 'isActive', p_is_active));
  return redirect_id;
exception when unique_violation then
  raise exception using errcode = 'P0001', message = 'REDIRECT_SOURCE_EXISTS';
end;
$$;
create or replace function public.update_seo_redirect_guarded(
  p_id uuid,
  p_expected_updated_at timestamptz,
  p_source_path text,
  p_destination_path text,
  p_status_code smallint,
  p_is_active boolean
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  current_updated_at timestamptz;
begin
  perform pg_advisory_xact_lock(188654771, 3);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  select updated_at into current_updated_at from public.redirects where id = p_id for update;
  if current_updated_at is null or current_updated_at <> p_expected_updated_at then
    raise exception using errcode = 'P0001', message = 'REDIRECT_WRITE_CONFLICT';
  end if;
  if p_status_code not in (301, 302, 307, 308) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_STATUS';
  end if;
  perform public.assert_redirect_candidate(p_id, p_source_path, p_destination_path, p_is_active);
  update public.redirects set
    source_path = coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/'),
    destination_path = case when p_destination_path like '/%' then coalesce(nullif(regexp_replace(p_destination_path, '/+$', ''), ''), '/') else p_destination_path end,
    status_code = p_status_code,
    is_active = p_is_active
  where id = p_id;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id, metadata)
  values (actor_user_id, 'redirect.updated', 'redirect', p_id::text,
    jsonb_build_object('sourcePath', p_source_path, 'destinationPath', p_destination_path,
      'statusCode', p_status_code, 'isActive', p_is_active));
  return p_id;
exception when unique_violation then
  raise exception using errcode = 'P0001', message = 'REDIRECT_SOURCE_EXISTS';
end;
$$;
revoke all on function public.assert_redirect_candidate(uuid, text, text, boolean) from public, anon, authenticated;
revoke all on function public.create_seo_redirect_guarded(text, text, smallint, boolean) from public, anon, authenticated;
revoke all on function public.update_seo_redirect_guarded(uuid, timestamptz, text, text, smallint, boolean) from public, anon, authenticated;
grant execute on function public.create_seo_redirect_guarded(text, text, smallint, boolean) to authenticated;
grant execute on function public.update_seo_redirect_guarded(uuid, timestamptz, text, text, smallint, boolean) to authenticated;
revoke insert, update, delete on public.redirects from authenticated;
-- Keep public save/promotion SECURITY INVOKER and both protected tables read-only
-- to authenticated clients. Only the existing guarded operations may write.

create or replace function public.lock_article_working_draft_for_publication(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_article_updated_at timestamptz;
  current_draft_version bigint;
begin
  if (select auth.uid()) is null
    or not public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role]) then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  if p_article_id is null or p_expected_article_updated_at is null then
    raise exception using errcode = '22023', message = 'PROMOTION_INPUT_INVALID';
  end if;

  -- Match the save/promotion lock order even when this helper is called directly.
  select article.updated_at into current_article_updated_at
  from public.articles article
  where article.id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
  end if;
  if current_article_updated_at is distinct from p_expected_article_updated_at then
    raise exception using errcode = '40001', message = 'ARTICLE_CONFLICT';
  end if;

  select draft.version into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  return current_draft_version;
end;
$$;

revoke all on function public.lock_article_working_draft_for_publication(uuid, timestamptz)
  from public, anon, authenticated, service_role;
grant execute on function public.lock_article_working_draft_for_publication(uuid, timestamptz)
  to authenticated;

create or replace function public.upsert_article_redirect_guarded(
  p_source_path text,
  p_destination_path text
)
returns uuid
language plpgsql
security invoker
set search_path = ''
as $$
declare
  existing_redirect_id uuid;
  existing_updated_at timestamptz;
  normalized_source text := coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/');
begin
  if (select auth.uid()) is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  -- Share the SEO RPC lock before reading its CAS token. Never use a direct
  -- INSERT/UPDATE or SELECT FOR UPDATE on the read-only redirects table.
  perform pg_advisory_xact_lock(188654771, 3);
  select redirect.id, redirect.updated_at
  into existing_redirect_id, existing_updated_at
  from public.redirects redirect
  where redirect.source_path = normalized_source;
  if found then
    return public.update_seo_redirect_guarded(
      existing_redirect_id, existing_updated_at,
      p_source_path, p_destination_path, 301::smallint, true
    );
  end if;
  return public.create_seo_redirect_guarded(
    p_source_path, p_destination_path, 301::smallint, true
  );
end;
$$;

revoke all on function public.upsert_article_redirect_guarded(text, text)
  from public, anon, authenticated, service_role;
grant execute on function public.upsert_article_redirect_guarded(text, text)
  to authenticated;

-- Replace only the two reviewed statements. Fail closed on an unexpected
-- predecessor; retain every original role, payload, CAS, RLS and atomicity gate.
do $publication_permissions$
declare
  promotion_oid regprocedure := to_regprocedure(
    'public.promote_article_working_draft(uuid,timestamptz,bigint,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
  );
  bundle_oid regprocedure := to_regprocedure(
    'public.save_article_bundle(uuid,timestamptz,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
  );
  definition text;
  old_lock text := $old_lock$  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  has_working_draft := found;$old_lock$;
  new_lock text := $new_lock$  current_draft_version := public.lock_article_working_draft_for_publication(
    p_article_id, p_expected_article_updated_at
  );
  has_working_draft := current_draft_version is not null;$new_lock$;
  old_redirect text := $old_redirect$    insert into public.redirects (
      source_path,
      destination_path,
      status_code,
      is_active,
      created_by
    ) values (
      p_redirect_source_path,
      p_redirect_destination_path,
      301,
      true,
      actor_id
    )
    on conflict (source_path) do update set
      destination_path = excluded.destination_path,
      status_code = 301,
      is_active = true,
      created_by = actor_id;$old_redirect$;
  new_redirect text := $new_redirect$    perform public.upsert_article_redirect_guarded(
      p_redirect_source_path, p_redirect_destination_path
    );$new_redirect$;
begin
  if promotion_oid is null or bundle_oid is null
    or exists (select 1 from pg_proc where oid in (promotion_oid, bundle_oid) and prosecdef) then
    raise exception 'Expected SECURITY INVOKER article publication functions are missing';
  end if;

  definition := pg_get_functiondef(promotion_oid);
  if strpos(definition, old_lock) > 0 and strpos(definition, new_lock) = 0
    and (length(definition) - length(replace(definition, old_lock, ''))) = length(old_lock) then
    execute replace(definition, old_lock, new_lock);
  elsif strpos(definition, old_lock) > 0 or strpos(definition, new_lock) = 0 then
    raise exception 'Unexpected article promotion lock predecessor';
  end if;

  definition := pg_get_functiondef(bundle_oid);
  if strpos(definition, old_redirect) > 0 and strpos(definition, new_redirect) = 0
    and (length(definition) - length(replace(definition, old_redirect, ''))) = length(old_redirect) then
    execute replace(definition, old_redirect, new_redirect);
  elsif strpos(definition, old_redirect) > 0 or strpos(definition, new_redirect) = 0 then
    raise exception 'Unexpected article redirect write predecessor';
  end if;

  if exists (
    select 1 from pg_proc where oid in (promotion_oid, bundle_oid) and prosecdef
  ) or not (
    select prosecdef from pg_proc
    where oid = 'public.lock_article_working_draft_for_publication(uuid,timestamptz)'::regprocedure
  ) or (
    select prosecdef from pg_proc
    where oid = 'public.upsert_article_redirect_guarded(text,text)'::regprocedure
  ) then
    raise exception 'Article publication privilege boundaries changed';
  end if;
  if has_table_privilege('authenticated', 'public.article_working_drafts', 'INSERT,UPDATE,DELETE')
    or has_any_column_privilege('authenticated', 'public.article_working_drafts', 'UPDATE')
    or has_table_privilege('authenticated', 'public.redirects', 'INSERT,UPDATE,DELETE')
    or has_any_column_privilege('authenticated', 'public.redirects', 'UPDATE') then
    raise exception 'Protected article tables must remain read-only to authenticated clients';
  end if;
  if not has_function_privilege('authenticated',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or not has_function_privilege('authenticated',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE')
    or has_function_privilege('anon',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or has_function_privilege('service_role',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or has_function_privilege('anon',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE')
    or has_function_privilege('service_role',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE') then
    raise exception 'Article publication helper ACLs are invalid';
  end if;
end;
$publication_permissions$;


-- Нормализованный редакционный контур книжного архива.
-- Главным источником энциклопедических данных остаётся src/data/countries.
-- Эти таблицы дают CMS безопасный рабочий слой для проверки произведений,
-- конкретных изданий и ISBN без дублирования одной обложки на уровне произведения.

create table if not exists public.literary_works (
  id uuid primary key default gen_random_uuid(),
  legacy_id text not null unique check (char_length(legacy_id) between 2 and 180),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  title text not null check (char_length(title) between 1 and 300),
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{0,179}$'),
  original_title text not null default '' check (char_length(original_title) <= 300),
  first_published integer check (first_published between -3000 and 2100),
  original_language text not null default '' check (char_length(original_language) <= 120),
  genres text[] not null default '{}',
  tags text[] not null default '{}',
  description text not null default '' check (char_length(description) <= 5000),
  source_url text,
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (writer_id, slug)
);

create table if not exists public.book_editions (
  id uuid primary key default gen_random_uuid(),
  legacy_id text not null unique check (char_length(legacy_id) between 2 and 240),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  title text not null default '' check (char_length(title) <= 300),
  isbn_10 text check (
    isbn_10 is null
    or regexp_replace(isbn_10, '[^0-9Xx]', '', 'g') ~ '^[0-9]{9}[0-9Xx]$'
  ),
  isbn_13 text check (
    isbn_13 is null
    or regexp_replace(isbn_13, '[^0-9]', '', 'g') ~ '^[0-9]{13}$'
  ),
  publisher text not null default '' check (char_length(publisher) <= 240),
  publication_year integer check (publication_year between 1400 and 2100),
  language text not null default '' check (char_length(language) <= 120),
  format text not null default '' check (char_length(format) <= 120),
  page_count integer check (page_count is null or page_count > 0),
  cover_url text,
  cover_source_url text,
  cover_rights_status text not null default 'unverified'
    check (
      cover_rights_status in (
        'public-domain',
        'licensed',
        'permission',
        'editorial-original',
        'external-preview',
        'unverified'
      )
    ),
  license_name text not null default '' check (char_length(license_name) <= 240),
  license_url text,
  creator text not null default '' check (char_length(creator) <= 240),
  rights_holder text not null default '' check (char_length(rights_holder) <= 240),
  rights_checked_at date,
  source_url text,
  is_primary boolean not null default false,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (
    cover_url is null
    or (
      cover_source_url is not null
      and cover_rights_status <> 'unverified'
      and rights_checked_at is not null
    )
  )
);

create unique index if not exists literary_works_country_legacy_idx
  on public.literary_works(country_id, legacy_id);

create index if not exists literary_works_writer_idx
  on public.literary_works(country_id, writer_id, editorial_status);

create index if not exists literary_works_search_idx
  on public.literary_works
  using gin (
    to_tsvector(
      'simple',
      coalesce(title, '') || ' ' || coalesce(original_title, '') || ' ' ||
      coalesce(description, '')
    )
  );

create unique index if not exists book_editions_isbn_10_unique_idx
  on public.book_editions (
    regexp_replace(upper(isbn_10), '[^0-9X]', '', 'g')
  )
  where isbn_10 is not null;

create unique index if not exists book_editions_isbn_13_unique_idx
  on public.book_editions (
    regexp_replace(isbn_13, '[^0-9]', '', 'g')
  )
  where isbn_13 is not null;

create unique index if not exists book_editions_one_primary_idx
  on public.book_editions(work_id)
  where is_primary;

create index if not exists book_editions_work_idx
  on public.book_editions(work_id, publication_year desc);

drop trigger if exists literary_works_set_updated_at on public.literary_works;
create trigger literary_works_set_updated_at
  before update on public.literary_works
  for each row execute function public.set_updated_at();

drop trigger if exists book_editions_set_updated_at on public.book_editions;
create trigger book_editions_set_updated_at
  before update on public.book_editions
  for each row execute function public.set_updated_at();

alter table public.literary_works enable row level security;
alter table public.book_editions enable row level security;

create policy "Public read reviewed literary works"
on public.literary_works for select
to anon, authenticated
using (editorial_status in ('reviewed', 'verified'));

create policy "Staff manage literary works"
on public.literary_works for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Public read verified book editions"
on public.book_editions for select
to anon, authenticated
using (
  (
    cover_url is null
    or (
      cover_rights_status <> 'unverified'
      and cover_source_url is not null
      and rights_checked_at is not null
    )
  )
  and exists (
    select 1
    from public.literary_works
    where literary_works.id = book_editions.work_id
      and literary_works.editorial_status in ('reviewed', 'verified')
  )
);

create policy "Staff manage book editions"
on public.book_editions for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

-- Bilingual, source-aware publication workflow for literary works.
-- Discovery imports land in book_import_candidates. Only reviewed works with
-- complete RU/EN editorial text and provenance are visible through public RLS.

create table if not exists public.literary_work_translations (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  locale text not null check (locale in ('ru', 'en')),
  title text not null check (char_length(title) between 1 and 300),
  description text not null check (char_length(description) between 140 and 900),
  source_language text not null check (char_length(source_language) between 2 and 40),
  translation_method text not null
    check (
      translation_method in (
        'editorial-original',
        'human-translation',
        'licensed-source'
      )
    ),
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  source_urls text[] not null default '{}',
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, locale),
  check (
    editorial_status = 'draft'
    or (
      reviewed_at is not null
      and cardinality(source_urls) > 0
    )
  )
);

create table if not exists public.literary_work_sources (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  provider text not null check (char_length(provider) between 2 and 160),
  source_url text not null check (source_url ~ '^https://'),
  field_names text[] not null check (cardinality(field_names) > 0),
  license_name text,
  usage text not null
    check (usage in ('structured-data', 'reference-only', 'licensed-copy')),
  retrieved_at date not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, provider, source_url)
);

create table if not exists public.literary_work_external_ids (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  scheme text not null check (scheme ~ '^[a-z0-9][a-z0-9_-]{1,39}$'),
  external_id text not null check (char_length(external_id) between 1 and 180),
  source_url text not null check (source_url ~ '^https://'),
  created_at timestamptz not null default now(),
  unique (scheme, external_id),
  unique (work_id, scheme, external_id)
);

create table if not exists public.book_import_candidates (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider ~ '^[a-z0-9][a-z0-9_-]{1,39}$'),
  external_id text not null check (char_length(external_id) between 1 and 180),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  writer_key text not null check (char_length(writer_key) between 3 and 320),
  title text not null check (char_length(title) between 1 and 300),
  source_url text not null check (source_url ~ '^https://'),
  quality_score integer not null default 0 check (quality_score between 0 and 100),
  status text not null default 'candidate'
    check (status in ('candidate', 'rejected', 'reviewed', 'promoted')),
  rejection_reasons text[] not null default '{}',
  payload jsonb not null default '{}'::jsonb,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  promoted_work_id uuid references public.literary_works(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, external_id),
  check (
    status not in ('reviewed', 'promoted')
    or (reviewed_by is not null and reviewed_at is not null)
  ),
  check (status <> 'promoted' or promoted_work_id is not null)
);

create index if not exists literary_work_translations_public_idx
  on public.literary_work_translations(work_id, locale, editorial_status);
create index if not exists literary_work_sources_work_idx
  on public.literary_work_sources(work_id);
create index if not exists literary_work_external_ids_work_idx
  on public.literary_work_external_ids(work_id);
create index if not exists book_import_candidates_queue_idx
  on public.book_import_candidates(status, quality_score desc, created_at);
create index if not exists book_import_candidates_writer_idx
  on public.book_import_candidates(writer_key, status);

drop trigger if exists literary_work_translations_set_updated_at
  on public.literary_work_translations;
create trigger literary_work_translations_set_updated_at
  before update on public.literary_work_translations
  for each row execute function public.set_updated_at();

drop trigger if exists literary_work_sources_set_updated_at
  on public.literary_work_sources;
create trigger literary_work_sources_set_updated_at
  before update on public.literary_work_sources
  for each row execute function public.set_updated_at();

drop trigger if exists book_import_candidates_set_updated_at
  on public.book_import_candidates;
create trigger book_import_candidates_set_updated_at
  before update on public.book_import_candidates
  for each row execute function public.set_updated_at();

alter table public.literary_work_translations enable row level security;
alter table public.literary_work_sources enable row level security;
alter table public.literary_work_external_ids enable row level security;
alter table public.book_import_candidates enable row level security;

create or replace function public.is_publishable_literary_work(target_work_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1
    from public.literary_works as work
    where work.id = target_work_id
      and work.editorial_status in ('reviewed', 'verified')
      and exists (
        select 1
        from public.literary_work_sources as source
        where source.work_id = work.id
      )
      and not exists (
        select 1
        from public.literary_work_sources as source
        where source.work_id = work.id
          and (
            btrim(source.provider) = ''
            or source.source_url !~* '^https://'
            or cardinality(source.field_names) = 0
            or source.retrieved_at is null
          )
      )
      and 2 = (
        select count(distinct translation.locale)
        from public.literary_work_translations as translation
        where translation.work_id = work.id
          and translation.locale in ('ru', 'en')
          and translation.editorial_status in ('reviewed', 'verified')
          and translation.reviewed_at is not null
          and btrim(translation.title) <> ''
          and btrim(translation.source_language) <> ''
          and char_length(btrim(translation.description)) between 140 and 900
          and (
            select count(*)
            from regexp_matches(
              btrim(translation.description),
              '[.!?…]+([[:space:]]|$)',
              'g'
            )
          ) between 2 and 3
          and case
            when translation.locale = 'ru'
              then translation.description ~ '[А-Яа-яЁё]'
            when translation.locale = 'en'
              then translation.description ~ '[A-Za-z]'
                -- PostgreSQL ARE has no portable Unicode Script=Cyrillic class.
                -- Check every code point across the current Cyrillic blocks.
                and not exists (
                  select 1
                  from unnest(
                    string_to_array(
                      translation.title || translation.description,
                      null::text
                    )
                  ) as glyph(value)
                  where ascii(glyph.value) between 1024 and 1327
                    or ascii(glyph.value) between 7296 and 7311
                    or ascii(glyph.value) between 11744 and 11775
                    or ascii(glyph.value) between 42560 and 42655
                    or ascii(glyph.value) between 65070 and 65071
                    or ascii(glyph.value) between 122928 and 123023
                )
            else false
          end
          and position('Р°' in translation.description) = 0
          and position('Рµ' in translation.description) = 0
          and position('Рё' in translation.description) = 0
          and position('СЃ' in translation.description) = 0
          and position('С‚' in translation.description) = 0
          and position('вЂ' in translation.description) = 0
          and cardinality(translation.source_urls) > 0
          and not exists (
            select 1
            from unnest(translation.source_urls) as declared(source_url)
            where declared.source_url is null
              or btrim(declared.source_url) !~* '^https://'
              or not exists (
                select 1
                from public.literary_work_sources as source
                where source.work_id = translation.work_id
                  and source.source_url = btrim(declared.source_url)
              )
          )
          and (
            translation.translation_method <> 'licensed-source'
            or exists (
              select 1
              from unnest(translation.source_urls) as declared(source_url)
              join public.literary_work_sources as source
                on source.work_id = translation.work_id
               and source.source_url = btrim(declared.source_url)
              where source.usage = 'licensed-copy'
                and btrim(coalesce(source.license_name, '')) <> ''
            )
          )
      )
  );
$$;

revoke all on function public.is_publishable_literary_work(uuid) from public;
grant execute on function public.is_publishable_literary_work(uuid)
  to anon, authenticated;

drop policy if exists "Public read reviewed literary works"
  on public.literary_works;
drop policy if exists "Public read publishable literary works"
  on public.literary_works;
create policy "Public read publishable literary works"
on public.literary_works for select
to anon, authenticated
using (public.is_publishable_literary_work(id));

drop policy if exists "Public read publishable work translations"
  on public.literary_work_translations;
create policy "Public read publishable work translations"
on public.literary_work_translations for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work translations"
  on public.literary_work_translations;
create policy "Staff manage work translations"
on public.literary_work_translations for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Public read publishable work sources"
  on public.literary_work_sources;
create policy "Public read publishable work sources"
on public.literary_work_sources for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work sources"
  on public.literary_work_sources;
create policy "Staff manage work sources"
on public.literary_work_sources for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Public read publishable work external ids"
  on public.literary_work_external_ids;
create policy "Public read publishable work external ids"
on public.literary_work_external_ids for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work external ids"
  on public.literary_work_external_ids;
create policy "Staff manage work external ids"
on public.literary_work_external_ids for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Staff manage book import candidates"
  on public.book_import_candidates;
create policy "Staff manage book import candidates"
on public.book_import_candidates for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

-- Full editorial database overrides for countries plus missing history for
-- exact book editions. Static TypeScript records remain the audited fallback;
-- enabled CMS overrides are exported and applied last by the public build.

create table if not exists public.country_profile_overrides (
  id uuid primary key default gen_random_uuid(),
  country_id text not null unique
    check (char_length(country_id) between 2 and 120),
  fields jsonb not null default '{}'::jsonb,
  is_enabled boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (jsonb_typeof(fields) = 'object')
);

create index if not exists country_profile_overrides_public_idx
  on public.country_profile_overrides(country_id)
  where is_enabled;

drop trigger if exists country_profile_overrides_set_updated_at
  on public.country_profile_overrides;
create trigger country_profile_overrides_set_updated_at
  before update on public.country_profile_overrides
  for each row execute function public.set_updated_at();

create table if not exists public.country_profile_override_revisions (
  id bigint generated always as identity primary key,
  override_id uuid references public.country_profile_overrides(id)
    on delete set null,
  country_id text not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create index if not exists country_profile_override_revisions_country_idx
  on public.country_profile_override_revisions(country_id, revised_at desc);

create or replace function public.capture_country_profile_override_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  revision_actor uuid;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  if tg_op = 'UPDATE' then
    revision_actor := coalesce(new.updated_by, (select auth.uid()));
  else
    revision_actor := (select auth.uid());
  end if;
  insert into public.country_profile_override_revisions (
    override_id,
    country_id,
    snapshot,
    revised_by
  ) values (
    old.id,
    old.country_id,
    to_jsonb(old),
    revision_actor
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists country_profile_overrides_capture_revision
  on public.country_profile_overrides;
create trigger country_profile_overrides_capture_revision
  before update or delete on public.country_profile_overrides
  for each row execute function public.capture_country_profile_override_revision();


-- Record AI-generated literary-work translations explicitly instead of
-- misclassifying them as human translations. Public publication rules remain
-- source-aware and still require reviewed/verified RU+EN records.

alter table public.literary_work_translations
  drop constraint if exists literary_work_translations_translation_method_check;

alter table public.literary_work_translations
  add constraint literary_work_translations_translation_method_check
  check (
    translation_method in (
      'editorial-original',
      'human-translation',
      'machine-translation',
      'licensed-source'
    )
  );

create or replace function public.premium_machine_translation_ready()
returns boolean
language sql
stable
security invoker
set search_path = ''
as $$
  select exists (
    select 1
    from pg_catalog.pg_constraint constraint_row
    join pg_catalog.pg_class relation
      on relation.oid = constraint_row.conrelid
    join pg_catalog.pg_namespace namespace
      on namespace.oid = relation.relnamespace
    where namespace.nspname = 'public'
      and relation.relname = 'literary_work_translations'
      and constraint_row.conname =
        'literary_work_translations_translation_method_check'
      and pg_catalog.pg_get_constraintdef(constraint_row.oid)
        like '%machine-translation%'
  );
$$;

revoke all on function public.premium_machine_translation_ready() from public;
grant execute on function public.premium_machine_translation_ready()
  to authenticated;

-- Preserve short, unreviewed draft text without changing publication rules.
-- Reviewed and verified descriptions retain the existing 140..900 limit.
do $literary_translation_draft_storage$
declare
  existing_constraint record;
  old_definition constant text :=
    'CHECK (((char_length(description) >= 140) AND (char_length(description) <= 900)))';
  target_definition constant text :=
    'CHECK ((((char_length(description) >= 140) AND (char_length(description) <= 900)) OR ((editorial_status = ''draft''::text) AND (reviewed_at IS NULL) AND ((char_length(description) >= 1) AND (char_length(description) <= 139)) AND (description ~ ''[^[:space:]]''::text))))';
begin
  lock table public.literary_work_translations
    in access exclusive mode nowait;

  select constraint_row.*,
    pg_catalog.pg_get_constraintdef(constraint_row.oid, false) as definition
  into existing_constraint
  from pg_catalog.pg_constraint constraint_row
  where constraint_row.conrelid =
      'public.literary_work_translations'::regclass
    and constraint_row.conname =
      'literary_work_translations_description_check';

  if not found
    or existing_constraint.contype <> 'c'
    or not existing_constraint.convalidated
    or not existing_constraint.conislocal
    or existing_constraint.coninhcount <> 0
    or existing_constraint.connoinherit
    or existing_constraint.condeferrable
    or existing_constraint.condeferred then
    raise exception 'Reviewed translation description constraint is missing or incompatible';
  end if;

  if existing_constraint.definition = target_definition then
    return;
  end if;
  if existing_constraint.definition <> old_definition then
    raise exception 'Translation description constraint differs from the reviewed predecessor';
  end if;

  alter table public.literary_work_translations
    drop constraint literary_work_translations_description_check;
  -- Adding a validated CHECK scans existing rows inside the same transaction.
  alter table public.literary_work_translations
    add constraint literary_work_translations_description_check check (
      char_length(description) between 140 and 900
      or (
        editorial_status = 'draft'
        and reviewed_at is null
        and char_length(description) between 1 and 139
        and description ~ '[^[:space:]]'
      )
    );
end;
$literary_translation_draft_storage$;

-- Private review candidates for books/countries. This is not a job queue.
-- Existing canonical rows, publication policies and public-build triggers are
-- unchanged. Only explicit human promotion writes canonical English.
create schema if not exists premium_translation_private;
revoke all on schema premium_translation_private from public, anon, authenticated;

create table public.premium_translation_working_drafts (
  id uuid primary key default gen_random_uuid(),
  version bigint not null default 1 check (version between 1 and 9007199254740991),
  entity_type text not null check (entity_type in ('literary_work', 'country')),
  entity_id text not null check (char_length(entity_id) between 1 and 120),
  target_locale text not null default 'en' check (target_locale = 'en'),
  human_review text not null default 'pending' check (human_review = 'pending'),
  source_hash text not null check (source_hash ~ '^[a-f0-9]{64}$'),
  candidate_hash text not null check (candidate_hash ~ '^[a-f0-9]{64}$'),
  source_revision jsonb not null check (jsonb_typeof(source_revision) = 'object'),
  target_revision jsonb not null check (jsonb_typeof(target_revision) = 'object'),
  source_snapshot jsonb not null check (jsonb_typeof(source_snapshot) = 'object'),
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  provenance jsonb not null check (jsonb_typeof(provenance) = 'object'),
  created_at timestamptz not null default clock_timestamp(),
  created_by uuid not null references auth.users(id) on delete restrict,
  unique (entity_type, entity_id, target_locale)
);
alter table public.premium_translation_working_drafts enable row level security;
alter table public.premium_translation_working_drafts force row level security;
-- No policies and no direct table grants: all access goes through the four
-- staff-checked RPCs. In particular no public content/outbox trigger exists.
revoke all on public.premium_translation_working_drafts from public, anon, authenticated;

create function premium_translation_private.assert_actor()
returns uuid language plpgsql security invoker set search_path = '' as $$
declare actor uuid := auth.uid();
begin
  if actor is null or not coalesce(public.is_staff(), false) then
    raise exception using errcode = '42501', message = 'Staff actor required';
  end if;
  return actor;
end;
$$;

create function premium_translation_private.assert_identity(kind text, identity text)
returns void language plpgsql immutable set search_path = '' as $$
begin
  if kind is null or kind not in ('literary_work','country') or identity is null
    or char_length(identity) not between 1 and 120
    or (kind = 'literary_work' and identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') then
    raise exception using errcode = '22023', message = 'Invalid candidate identity';
  end if;
end;
$$;

create function premium_translation_private.exact_object(value jsonb, keys text[])
returns boolean language sql immutable set search_path = '' as $$
  select coalesce(jsonb_typeof(value) = 'object' and value ?& keys
    and (value - keys) = '{}'::jsonb, false);
$$;

create function premium_translation_private.string_array(value jsonb, max_items integer, max_length integer)
returns boolean language plpgsql immutable set search_path = '' as $$
declare item jsonb;
begin
  if jsonb_typeof(value) is distinct from 'array' then return false; end if;
  if jsonb_array_length(value) > max_items then return false; end if;
  for item in select jsonb_array_elements(value) loop
    if jsonb_typeof(item) <> 'string' or char_length(item #>> '{}') > max_length then return false; end if;
  end loop;
  return true;
end;
$$;

create function premium_translation_private.valid_timestamp(value text)
returns boolean language plpgsql immutable set search_path = '' as $$
begin
  if value is null or value !~ '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$' then return false; end if;
  perform value::timestamptz;
  return true;
exception when invalid_datetime_format or datetime_field_overflow then return false;
end;
$$;

create function premium_translation_private.valid_revision(value jsonb)
returns boolean language plpgsql immutable set search_path = '' as $$
begin
  if not premium_translation_private.exact_object(value, array['id','updatedAt']) then return false; end if;
  if value->'id' = 'null'::jsonb then return value->'updatedAt' = 'null'::jsonb; end if;
  return coalesce(jsonb_typeof(value->'id') = 'string'
    and value->>'id' ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
    and jsonb_typeof(value->'updatedAt') = 'string'
    and premium_translation_private.valid_timestamp(value->>'updatedAt'), false);
end;
$$;

-- ECMAScript String.trim whitespace, matching the existing Zod generators.
-- Used only for validation; candidate bytes and source snapshots stay intact.
create function premium_translation_private.trim_text(value text)
returns text language sql immutable set search_path = '' as $$
  select btrim(value, E' \t\n\r\f' || chr(11) || chr(160) || chr(5760)
    || chr(8192) || chr(8193) || chr(8194) || chr(8195) || chr(8196)
    || chr(8197) || chr(8198) || chr(8199) || chr(8200) || chr(8201)
    || chr(8202) || chr(8232) || chr(8233) || chr(8239) || chr(8287)
    || chr(12288) || chr(65279));
$$;

create function premium_translation_private.valid_country_fields(value jsonb, translated boolean)
returns boolean language plpgsql immutable set search_path = '' as $$
declare key text; max_length integer; item jsonb;
begin
  if not premium_translation_private.exact_object(value, array['name','region','continent','officialLanguage','capital',
      'description','history','historicalNote','literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology']) then return false; end if;
  foreach key in array array['name','region','continent','officialLanguage','capital','description','history','historicalNote'] loop
    max_length := case key when 'name' then 160 when 'region' then 160 when 'continent' then 160
      when 'officialLanguage' then 300 when 'capital' then 200 when 'history' then 8000 else 4000 end;
    if jsonb_typeof(value->key) <> 'string' or (translated and char_length(value->>key) > max_length) then return false; end if;
  end loop;
  if char_length(premium_translation_private.trim_text(value->>'name')) = 0 then return false; end if;
  foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces'] loop
    if not premium_translation_private.string_array(value->key,
      case when translated then case when key in ('facts','literaryPlaces') then 80 else 40 end else 10000 end,
      case when translated then case key when 'facts' then 1000 when 'literaryPlaces' then 500 else 300 end else 100000 end)
      then return false; end if;
  end loop;
  foreach key in array array['timeline','chronology'] loop
    if jsonb_typeof(value->key) <> 'array' then return false; end if;
    if jsonb_array_length(value->key) > (case when translated then 100 else 10000 end) then return false; end if;
    for item in select jsonb_array_elements(value->key) loop
      if not premium_translation_private.exact_object(item,array['year','title','description'])
        or jsonb_typeof(item->'year') <> 'string' or jsonb_typeof(item->'title') <> 'string'
        or jsonb_typeof(item->'description') <> 'string' then return false; end if;
      if translated and (char_length(item->>'year') > 80 or char_length(item->>'title') > 500
        or char_length(item->>'description') > 2000) then return false; end if;
    end loop;
  end loop;
  if translated and exists(select 1 from unnest(string_to_array(value::text,null::text)) glyph
    where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
      or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
      or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023) then return false; end if;
  return true;
end;
$$;

create function premium_translation_private.assert_shape(kind text, snapshot jsonb, source_revision jsonb,
  target_revision jsonb, payload jsonb, provenance jsonb)
returns void language plpgsql immutable set search_path = '' as $$
declare key text; item jsonb; source_item jsonb; idx integer;
begin
  if not premium_translation_private.valid_revision(target_revision)
    or not premium_translation_private.exact_object(provenance,array['provider','translatorModel','reviewerModel',
      'translatorRequestId','reviewerRequestId','generatedAt']) then
    raise exception using errcode='22023', message='Invalid candidate shape';
  end if;
  if provenance->>'provider' not in ('cloudflare','openai') or jsonb_typeof(provenance->'provider') <> 'string'
    or jsonb_typeof(provenance->'translatorModel') <> 'string' or char_length(provenance->>'translatorModel') not between 1 and 300
    or jsonb_typeof(provenance->'generatedAt') <> 'string' or not premium_translation_private.valid_timestamp(provenance->>'generatedAt') then
    raise exception using errcode='22023', message='Invalid candidate provenance';
  end if;
  foreach key in array array['reviewerModel','translatorRequestId','reviewerRequestId'] loop
    if jsonb_typeof(provenance->key) not in ('string','null') or
      (key='reviewerModel' and jsonb_typeof(provenance->key)='string' and char_length(provenance->>key) not between 1 and 300) then
      raise exception using errcode='22023', message='Invalid candidate provenance';
    end if;
  end loop;
  if kind = 'literary_work' then
    if not premium_translation_private.exact_object(source_revision,array['workId','workUpdatedAt','russianId','russianUpdatedAt'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'workId','updatedAt',source_revision->'workUpdatedAt'))
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'russianId','updatedAt',source_revision->'russianUpdatedAt'))
      or source_revision->>'workId' is null or source_revision->>'russianId' is null or target_revision->>'id' is null
      or not premium_translation_private.exact_object(snapshot,array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl',
        'description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls'])
      or not premium_translation_private.exact_object(payload,array['description','sourceLanguage','sourceUrls','bibliographicTitle'])
      or not premium_translation_private.exact_object(payload->'bibliographicTitle',array['value','provider','sourceUrl','retrievedAt']) then
      raise exception using errcode='22023', message='Invalid book candidate shape';
    end if;
    foreach key in array array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','originalLanguage','sourceLanguage'] loop
      if jsonb_typeof(snapshot->key) <> 'string' then raise exception using errcode='22023', message='Invalid book source shape'; end if;
    end loop;
    if jsonb_typeof(snapshot->'firstPublished') not in ('number','null')
      or not premium_translation_private.string_array(snapshot->'sourceUrls',10000,100000)
      or jsonb_typeof(payload->'description') <> 'string' or char_length(payload->>'description') not between 140 and 900
      or char_length(premium_translation_private.trim_text(payload->>'description')) not between 140 and 900
      or exists(select 1 from unnest(string_to_array(payload->>'description',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or (select count(*) from regexp_matches(payload->>'description','[.!?:]+(?=\s|$)','g')) not between 2 and 3
      or payload->>'sourceLanguage' is distinct from 'Russian'
      or not premium_translation_private.string_array(payload->'sourceUrls',10000,100000) then
      raise exception using errcode='22023', message='Invalid book candidate content';
    end if;
    foreach key in array array['value','provider','sourceUrl'] loop
      if jsonb_typeof(payload->'bibliographicTitle'->key) <> 'string' or char_length(payload->'bibliographicTitle'->>key)=0 then
        raise exception using errcode='22023', message='Invalid title provenance';
      end if;
    end loop;
    if jsonb_typeof(payload#>'{bibliographicTitle,retrievedAt}') not in ('string','null') then
      raise exception using errcode='22023', message='Invalid title provenance';
    end if;
    for item in select jsonb_array_elements(payload->'sourceUrls') loop
      if item #>> '{}' !~ '^https://' then raise exception using errcode='22023', message='Invalid candidate source URL'; end if;
    end loop;
  else
    if not premium_translation_private.exact_object(source_revision,array['overrideId','overrideUpdatedAt','catalogSourceHash'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt'))
      or jsonb_typeof(source_revision->'catalogSourceHash') <> 'string'
      or source_revision->>'catalogSourceHash' is null or source_revision->>'catalogSourceHash' !~ '^[a-f0-9]{64}$'
      or not premium_translation_private.valid_country_fields(snapshot,false)
      or not premium_translation_private.exact_object(payload,array['fields'])
      or not premium_translation_private.valid_country_fields(payload->'fields',true) then
      raise exception using errcode='22023', message='Invalid country candidate shape';
    end if;
    foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology'] loop
      if jsonb_array_length(snapshot->key) <> jsonb_array_length(payload->'fields'->key) then
        raise exception using errcode='22023', message='Country candidate changed item count';
      end if;
      if key in ('timeline','chronology') then
        for idx in 0..jsonb_array_length(snapshot->key)-1 loop
          if snapshot->key->idx->'year' is distinct from payload->'fields'->key->idx->'year' then
            raise exception using errcode='22023', message='Country candidate changed year';
          end if;
        end loop;
      end if;
    end loop;
  end if;
end;
$$;

-- Locks and verifies live SQL state on BOTH stage and promotion. Country static
-- catalog content is application-owned: catalogSourceHash is an additional
-- trusted-app binding, not a claim that SQL can independently read TS catalogs.
create function premium_translation_private.assert_current(kind text, identity text, snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql security invoker set search_path = '' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype;
  en public.literary_work_translations%rowtype; title_source public.literary_work_sources%rowtype;
  country public.country_profile_overrides%rowtype; current_source jsonb; urls jsonb;
begin
  if kind = 'literary_work' then
    select * into work from public.literary_works where id=identity::uuid for update;
    if not found or work.editorial_status not in ('reviewed','verified')
      or source_revision->>'workId' is distinct from identity
      or work.updated_at is distinct from (source_revision->>'workUpdatedAt')::timestamptz then
      raise exception using errcode='40001',message='Book source changed';
    end if;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru' for update;
    if not found or ru.id is distinct from (source_revision->>'russianId')::uuid
      or ru.updated_at is distinct from (source_revision->>'russianUpdatedAt')::timestamptz
      or ru.editorial_status not in ('reviewed','verified') or cardinality(ru.source_urls)=0 then
      raise exception using errcode='40001',message='Russian source changed';
    end if;
    select * into en from public.literary_work_translations where work_id=work.id and locale='en' for update;
    if not found or en.id is distinct from (target_revision->>'id')::uuid
      or en.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
      or en.translation_method <> 'machine-translation'
      or btrim(en.title)='' or exists(select 1 from unnest(string_to_array(en.title,null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,value}' is distinct from btrim(en.title)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,sourceUrl}' is distinct from snapshot->>'verifiedEnglishTitleSourceUrl'
      or not coalesce(snapshot->>'verifiedEnglishTitleSourceUrl'=any(en.source_urls),false) then
      raise exception using errcode='40001',message='English target or title ownership changed';
    end if;
    select * into title_source from public.literary_work_sources
      where work_id=work.id and source_url=snapshot->>'verifiedEnglishTitleSourceUrl'
        and provider=payload#>>'{bibliographicTitle,provider}' and 'title'=any(field_names)
      order by id limit 1 for share;
    if not found or jsonb_build_object('value',btrim(en.title),'provider',title_source.provider,
      'sourceUrl',title_source.source_url,'retrievedAt',title_source.retrieved_at) is distinct from payload->'bibliographicTitle' then
      raise exception using errcode='40001',message='Bibliographic title provenance changed';
    end if;
    current_source := jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),
      'verifiedEnglishTitleSourceUrl',title_source.source_url,'description',ru.description,
      'originalTitle',coalesce(work.original_title,''),'firstPublished',work.first_published,
      'originalLanguage',coalesce(work.original_language,''),'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    if current_source is distinct from snapshot then raise exception using errcode='40001',message='Book source snapshot changed'; end if;
    -- Ordered JS Set union used by the existing helper, preserving source rights.
    select coalesce(jsonb_agg(url order by position),'[]'::jsonb) into urls from (
      select url,min(position) position from (
        select url,position from unnest(en.source_urls) with ordinality as english(url,position) where url ~ '^https://'
        union all select url,position+cardinality(en.source_urls) from unnest(ru.source_urls) with ordinality as russian(url,position)
      ) combined group by url
    ) unique_urls;
    if urls is distinct from payload->'sourceUrls' then raise exception using errcode='40001',message='Candidate source provenance changed'; end if;
  else
    if jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt') is distinct from target_revision then
      raise exception using errcode='40001',message='Country source and target revisions differ';
    end if;
    select * into country from public.country_profile_overrides where country_id=identity for update;
    if found then
      if country.id is distinct from (target_revision->>'id')::uuid
        or country.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz then
        raise exception using errcode='40001',message='Country override changed';
      end if;
      if country.fields ? 'translations' and jsonb_typeof(country.fields->'translations') <> 'object' then
        raise exception using errcode='40001',message='Country translation ownership is ambiguous';
      end if;
      if country.fields->'translations' ? 'en' and (
        country.fields#>>'{translations,en,locale}' is distinct from 'en'
        or country.fields#>>'{translations,en,method}' is distinct from 'machine-translation') then
        raise exception using errcode='40001',message='Manual country English is protected';
      end if;
    elsif target_revision->>'id' is not null then
      raise exception using errcode='40001',message='Country override disappeared';
    end if;
  end if;
end;
$$;

create function premium_translation_private.dto(candidate public.premium_translation_working_drafts)
returns jsonb language sql stable set search_path = '' as $$
  select jsonb_build_object('id',candidate.id,'version',candidate.version,'entityType',candidate.entity_type,'entityId',candidate.entity_id,
    'targetLocale',candidate.target_locale,'humanReview',candidate.human_review,'sourceHash',candidate.source_hash,'candidateHash',candidate.candidate_hash,
    'sourceRevision',candidate.source_revision,'targetRevision',candidate.target_revision,'sourceSnapshot',candidate.source_snapshot,
    'payload',candidate.payload,'provenance',candidate.provenance,'createdAt',candidate.created_at,'createdBy',candidate.created_by);
$$;

create function public.get_premium_translation_working_draft(p_entity_type text, p_entity_id text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare candidate public.premium_translation_working_drafts%rowtype;
begin
  perform premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en';
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,
    'draft',case when candidate.id is null then null else premium_translation_private.dto(candidate) end);
end;
$$;

create function public.stage_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_source_hash text, p_source_snapshot jsonb, p_source_revision jsonb, p_target_revision jsonb,
  p_payload jsonb, p_provenance jsonb, p_expected_draft_id uuid, p_expected_draft_version bigint)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; digest text;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_expected_draft_id is not null or p_expected_draft_version is distinct from 0
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$' then
    raise exception using errcode='22023',message='Invalid initial candidate request';
  end if;
  perform premium_translation_private.assert_shape(p_entity_type,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance);
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  if exists(select 1 from public.premium_translation_working_drafts where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en') then
    raise exception using errcode='40001',message='Pending candidate must be explicitly discarded';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,p_source_snapshot,p_source_revision,p_target_revision,p_payload);
  digest := encode(sha256(convert_to(jsonb_build_object('entityType',p_entity_type,'entityId',p_entity_id,'targetLocale','en',
    'sourceHash',p_source_hash,'sourceSnapshot',p_source_snapshot,'sourceRevision',p_source_revision,
    'targetRevision',p_target_revision,'payload',p_payload,'provenance',p_provenance)::text,'UTF8')),'hex');
  insert into public.premium_translation_working_drafts(entity_type,entity_id,source_hash,candidate_hash,source_snapshot,
    source_revision,target_revision,payload,provenance,created_by)
    values(p_entity_type,p_entity_id,p_source_hash,digest,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance,actor)
    returning * into candidate;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.staged',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',digest,'sourceHash',p_source_hash,'outcome','pending'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'draft',premium_translation_private.dto(candidate));
exception when unique_violation then raise exception using errcode='40001',message='Candidate changed concurrently';
end;
$$;

create function public.promote_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text, p_source_hash text,
  p_catalog_source_hash text, p_catalog_source_fields jsonb, p_confirm_human_review boolean)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; review_time timestamptz;
  canonical_id uuid; canonical_updated_at timestamptz; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; human jsonb; meta jsonb; english jsonb; next_fields jsonb; translations jsonb;
  catalog_translations jsonb; protected_english jsonb;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_confirm_human_review is distinct from true then raise exception using errcode='22023',message='Explicit human review is required'; end if;
  if (p_entity_type='literary_work' and p_catalog_source_fields is not null)
    or (p_entity_type='country' and (jsonb_typeof(p_catalog_source_fields) is distinct from 'object'
      or (p_catalog_source_fields ? 'translations' and jsonb_typeof(p_catalog_source_fields->'translations') is distinct from 'object'))) then
    raise exception using errcode='22023',message='Invalid current catalog shape';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash or candidate.source_hash is distinct from p_source_hash
    or (p_entity_type='literary_work' and p_catalog_source_hash is not null)
    or (p_entity_type='country' and candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash) then
    raise exception using errcode='40001',message='Candidate or source changed';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,candidate.source_snapshot,
    candidate.source_revision,candidate.target_revision,candidate.payload);
  review_time := clock_timestamp();
  human := jsonb_build_object('status','approved','reviewedBy',actor,'reviewedAt',review_time);
  if p_entity_type='literary_work' then
    select * into en from public.literary_work_translations where id=(candidate.target_revision->>'id')::uuid;
    meta := case when jsonb_typeof(en.metadata)='object' then en.metadata else '{}'::jsonb end;
    meta := meta || jsonb_build_object('premiumTranslation',
      (case when jsonb_typeof(meta->'premiumTranslation')='object' then meta->'premiumTranslation' else '{}'::jsonb end)
      || jsonb_build_object('sourceHash',candidate.source_hash,'provider',candidate.provenance->'provider',
        'translatorModel',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'generatedAt',candidate.provenance->'generatedAt','bibliographicTitle',candidate.payload->'bibliographicTitle',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time));
    update public.literary_work_translations set description=candidate.payload->>'description',source_language='Russian',
      translation_method='machine-translation',editorial_status='reviewed',reviewed_at=review_time::date,
      source_urls=array(select jsonb_array_elements_text(candidate.payload->'sourceUrls')),metadata=meta
      where id=en.id returning id,updated_at into canonical_id,canonical_updated_at;
  else
    select * into country from public.country_profile_overrides where country_id=p_entity_id;
    next_fields := coalesce(country.fields,'{}'::jsonb);
    catalog_translations := case when jsonb_typeof(p_catalog_source_fields->'translations')='object'
      then p_catalog_source_fields->'translations' else '{}'::jsonb end;
    translations := case when next_fields ? 'translations' then next_fields->'translations' else catalog_translations end;
    if translations ? 'en' then protected_english := translations->'en';
    elsif catalog_translations ? 'en' then protected_english := catalog_translations->'en'; end if;
    if protected_english is not null and (protected_english->>'locale' is distinct from 'en'
      or protected_english->>'method' is distinct from 'machine-translation') then
      raise exception using errcode='40001',message='Manual catalog English is protected';
    end if;
    select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into meta from jsonb_each(candidate.payload->'fields')
      where value <> '""'::jsonb and value <> '[]'::jsonb;
    english := (case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end)
      || jsonb_build_object('locale','en','status','reviewed','method','machine-translation','sourceHash',candidate.source_hash,
        'generatedAt',candidate.provenance->'generatedAt','provider',candidate.provenance->'provider',
        'model',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'fields',meta,'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    next_fields := next_fields || jsonb_build_object('translations',translations || jsonb_build_object('en',english));
    if country.id is null then
      insert into public.country_profile_overrides(country_id,fields,updated_by)
        values(p_entity_id,next_fields,actor) returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.country_profile_overrides set fields=next_fields,updated_by=actor
        where id=country.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.promoted',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
        'sourceHash',candidate.source_hash,'canonicalId',canonical_id,'outcome','promoted'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','promoted',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
    'canonicalId',canonical_id,'canonicalUpdatedAt',canonical_updated_at,'reviewedBy',actor,'reviewedAt',review_time);
exception when unique_violation then raise exception using errcode='40001',message='Canonical target changed concurrently';
end;
$$;

create function public.discard_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash then
    raise exception using errcode='40001',message='Candidate changed';
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.discarded',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,'outcome','discarded'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','discarded',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash);
end;
$$;

revoke all on all functions in schema premium_translation_private from public, anon, authenticated;
revoke all on function public.get_premium_translation_working_draft(text,text) from public, anon, authenticated;
revoke all on function public.stage_premium_translation_working_draft(text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,uuid,bigint) from public, anon, authenticated;
revoke all on function public.promote_premium_translation_working_draft(text,text,uuid,bigint,text,text,text,jsonb,boolean) from public, anon, authenticated;
revoke all on function public.discard_premium_translation_working_draft(text,text,uuid,bigint,text) from public, anon, authenticated;
grant execute on function public.get_premium_translation_working_draft(text,text) to authenticated;
grant execute on function public.stage_premium_translation_working_draft(text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,uuid,bigint) to authenticated;
grant execute on function public.promote_premium_translation_working_draft(text,text,uuid,bigint,text,text,text,jsonb,boolean) to authenticated;
grant execute on function public.discard_premium_translation_working_draft(text,text,uuid,bigint,text) to authenticated;

-- Isolated native PG contract. The builder prepends unchanged canonical SQL and
-- the actual new migration. Auth/staff and public-build capture are local only.
create function public.premium_fixture_assert(ok boolean, label text)
returns void language plpgsql as $$ begin
  if ok is distinct from true then raise exception 'PREMIUM ASSERT: %',label; end if;
end; $$;
create function public.premium_fixture_error(statement text, expected text)
returns void language plpgsql as $$ declare seen text; begin
  begin execute statement; exception when others then get stacked diagnostics seen=returned_sqlstate; end;
  if seen is distinct from expected then raise exception 'Expected SQLSTATE %, got %',expected,coalesce(seen,'success'); end if;
end; $$;

create table public.premium_fixture_outbox(kind text, identity text);
create function public.premium_fixture_capture() returns trigger language plpgsql security definer as $$
begin insert into public.premium_fixture_outbox values(tg_table_name,new.id::text); return new; end; $$;
create trigger premium_fixture_book_outbox after update on public.literary_work_translations
  for each row execute function public.premium_fixture_capture();
create trigger premium_fixture_country_outbox after insert or update on public.country_profile_overrides
  for each row execute function public.premium_fixture_capture();

insert into auth.users(id) values('11111111-1111-4111-8111-111111111111'),('22222222-2222-4222-8222-222222222222'),('33333333-3333-4333-8333-333333333333');
insert into public.staff_memberships(user_id,role) values('11111111-1111-4111-8111-111111111111','editor'),('22222222-2222-4222-8222-222222222222','admin');
insert into public.literary_works(id,legacy_id,country_id,writer_id,title,slug,original_title,first_published,original_language,editorial_status,metadata,updated_at)
values('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','premium-fixture-work','fixture-country','fixture-author','Исходное название','premium-fixture-work','Original identity',1920,'Russian','reviewed',
 '{"authorPreserve":{"id":"authored"},"rights":{"owner":"author"}}','2026-10-08T10:00:00.123456Z');
insert into public.literary_work_sources(work_id,provider,source_url,field_names,usage,retrieved_at,metadata)
values('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','verified-bibliography','https://fixture.test/title',array['title'],'reference-only','2026-10-08','{"rights":"title-only"}'),
 ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','editorial-source','https://fixture.test/ru',array['description'],'reference-only','2026-10-08','{"rights":"reference"}');
insert into public.literary_work_translations(id,work_id,locale,title,description,source_language,translation_method,editorial_status,source_urls,reviewed_at,metadata,updated_at)
values('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','ru','Исходное название',
 'Русский литературный текст описывает вымышленное произведение и его литературное значение для проверки сохранности редакторских данных. Второе предложение сохраняет исходное авторское содержание и подтверждённые сведения.',
 'Russian','editorial-original','reviewed',array['https://fixture.test/ru'],'2026-10-08','{"authored":"RU immutable"}','2026-10-08T10:00:00.123457Z'),
 ('cccccccc-cccc-4ccc-8ccc-cccccccccccc','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','en','Exact Verified English Title',
 'This previously admitted English description remains available to public readers while a separate candidate awaits a human decision. Its second sentence preserves the existing reviewed editorial account and all bibliographic identifiers.',
 'Russian','machine-translation','reviewed',array['https://fixture.test/title','https://fixture.test/ru'],'2026-10-07',
 '{"authored":{"owner":"editor"},"rights":{"license":"unchanged"},"premiumTranslation":{"custom":"retained","bibliographicTitle":{"value":"Exact Verified English Title","sourceUrl":"https://fixture.test/title"}}}',
 '2026-10-08T10:00:00.123458Z');
grant select on public.literary_works,public.literary_work_translations,public.literary_work_sources to anon,authenticated;
alter table public.country_profile_overrides enable row level security;
create policy premium_fixture_country_public on public.country_profile_overrides for select to anon,authenticated using(is_enabled);
grant select on public.country_profile_overrides to anon,authenticated;

create table public.premium_fixture_saved(name text primary key, value jsonb not null);
create function public.premium_fixture_args(kind text, identity text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; source jsonb; source_revision jsonb; target_revision jsonb; payload jsonb;
begin
  if kind='literary_work' then
    select * into work from public.literary_works where id=identity::uuid;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru';
    select * into en from public.literary_work_translations where work_id=work.id and locale='en';
    source:=jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),'verifiedEnglishTitleSourceUrl','https://fixture.test/title',
      'description',ru.description,'originalTitle',work.original_title,'firstPublished',work.first_published,'originalLanguage',work.original_language,
      'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    source_revision:=jsonb_build_object('workId',work.id,'workUpdatedAt',work.updated_at,'russianId',ru.id,'russianUpdatedAt',ru.updated_at);
    target_revision:=jsonb_build_object('id',en.id,'updatedAt',en.updated_at);
    payload:=jsonb_build_object('description',
      'This structurally valid candidate incorrectly states that the fictional book was written on the Moon by a committee of astronomers. A human editor must check the facts and sources before this deliberately wrong account can replace the reviewed text.',
      'sourceLanguage','Russian','sourceUrls',jsonb_build_array('https://fixture.test/title','https://fixture.test/ru'),
      'bibliographicTitle',jsonb_build_object('value',en.title,'provider','verified-bibliography','sourceUrl','https://fixture.test/title','retrievedAt','2026-10-08'));
  else
    select * into country from public.country_profile_overrides where country_id=identity;
    source:=jsonb_build_object('name','Страна','region','Регион','continent','Континент','officialLanguage','Язык','capital','Столица',
      'description','Редакторский текст страны','history','','historicalNote','','literaryPeriods',jsonb_build_array('Период'),
      'literaryMovements','[]'::jsonb,'periods','[]'::jsonb,'facts',jsonb_build_array('Факт'),'literaryPlaces','[]'::jsonb,
      'timeline',jsonb_build_array(jsonb_build_object('year','1900','title','Событие','description','Описание')),'chronology','[]'::jsonb);
    source_revision:=jsonb_build_object('overrideId',country.id,'overrideUpdatedAt',country.updated_at,'catalogSourceHash',repeat('b',64));
    target_revision:=jsonb_build_object('id',country.id,'updatedAt',country.updated_at);
    payload:=jsonb_build_object('fields',jsonb_build_object('name','Country','region','Region','continent','Continent','officialLanguage','Language','capital','Capital',
      'description','A separate English candidate.','history','','historicalNote','','literaryPeriods',jsonb_build_array('Period'),
      'literaryMovements','[]'::jsonb,'periods','[]'::jsonb,'facts',jsonb_build_array('Fact'),'literaryPlaces','[]'::jsonb,
      'timeline',jsonb_build_array(jsonb_build_object('year','1900','title','Event','description','Description')),'chronology','[]'::jsonb));
  end if;
  return jsonb_build_object('kind',kind,'identity',identity,'sourceHash',repeat('a',64),'source',source,'sourceRevision',source_revision,
    'targetRevision',target_revision,'payload',payload,'provenance',jsonb_build_object('provider','cloudflare','translatorModel','fixture-translator',
      'reviewerModel','fixture-reviewer','translatorRequestId','req-1','reviewerRequestId',null,'generatedAt','2026-10-08T10:10:00.123456Z'));
end; $$;
create function public.premium_fixture_stage(args jsonb)
returns jsonb language sql security invoker as $$
 select public.stage_premium_translation_working_draft(args->>'kind',args->>'identity',args->>'sourceHash',args->'source',args->'sourceRevision',
   args->'targetRevision',args->'payload',args->'provenance',null,0);
$$;
create function public.premium_fixture_promote(draft jsonb, catalog jsonb default null, confirm boolean default true)
returns jsonb language sql security invoker as $$
 select public.promote_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash',draft->>'sourceHash',
   case when draft->>'entityType'='country' then draft#>>'{sourceRevision,catalogSourceHash}' else null end,catalog,confirm);
$$;
create function public.premium_fixture_discard(draft jsonb)
returns jsonb language sql security invoker as $$
 select public.discard_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash');
$$;
grant select,insert,update,delete on public.premium_fixture_saved to authenticated;

-- Actual role ACL, including no actor and nonstaff actor, applies to every RPC.
do $$ declare fn regprocedure; begin
 perform public.premium_fixture_assert((select relrowsecurity and relforcerowsecurity from pg_class where oid='public.premium_translation_working_drafts'::regclass),'private force RLS');
 perform public.premium_fixture_assert(not exists(select 1 from pg_trigger where tgrelid='public.premium_translation_working_drafts'::regclass and not tgisinternal),'no private triggers');
 perform public.premium_fixture_assert(not has_schema_privilege('authenticated','premium_translation_private','USAGE'),'private helper schema');
 for fn in select oid::regprocedure from pg_proc where proname in ('get_premium_translation_working_draft','stage_premium_translation_working_draft','promote_premium_translation_working_draft','discard_premium_translation_working_draft') loop
   perform public.premium_fixture_assert(not has_function_privilege('anon',fn,'EXECUTE') and has_function_privilege('authenticated',fn,'EXECUTE'),'RPC grants');
 end loop;
 set local role anon;
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country','fixture-country')$q$,'42501');
 reset role;
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','','true');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country','fixture-country')$q$,'42501');
 perform set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country','fixture-country')$q$,'42501');
 perform public.premium_fixture_error($q$select public.stage_premium_translation_working_draft('country','fixture-country',null,null,null,null,null,null,null,0)$q$,'42501');
 perform public.premium_fixture_error($q$select public.promote_premium_translation_working_draft('country','fixture-country',null,1,null,null,null,null,true)$q$,'42501');
 perform public.premium_fixture_error($q$select public.discard_premium_translation_working_draft('country','fixture-country',null,1,null)$q$,'42501');
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error('insert into public.premium_translation_working_drafts(entity_id) values(''forbidden'')','42501');
 perform public.premium_fixture_error('update public.premium_translation_working_drafts set version=2','42501');
 perform public.premium_fixture_error('delete from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('country','fixture-country')=
   '{"schemaVersion":1,"entityType":"country","entityId":"fixture-country","draft":null}'::jsonb,'explicit absent envelope');
end; $$;
select 'M07_T05_NATIVE_ACL_ACTOR_PASS';

-- Server refuses malformed JSON, forged snapshots and changed bibliography.
do $$ declare a jsonb; bad jsonb; begin
 a:=public.premium_fixture_args('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 for bad in select value from jsonb_array_elements(jsonb_build_array(
   jsonb_set(a,'{payload,extra}','true'),jsonb_set(a,'{source,extra}','true'),jsonb_set(a,'{sourceRevision,extra}','true'),
   jsonb_set(a,'{targetRevision,updatedAt}','null'),jsonb_set(a,'{provenance,reviewedBy}','"forged"'),
   jsonb_set(a,'{provenance,provider}','null'),jsonb_set(a,'{provenance,generatedAt}','"2026-10-08"'),
   jsonb_set(a,'{payload,description}','"Too short."'),jsonb_set(a,'{payload,sourceUrls}','[1]'),
   jsonb_set(a,'{payload,description}',to_jsonb(rpad('A. B.',140,' '))),
   jsonb_set(a,'{payload,description}',to_jsonb(rpad('A. B.',140,chr(160)))),
   jsonb_set(a,'{sourceRevision,workUpdatedAt}','"2026-10-08T10:00:00"')
 )) loop perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023'); end loop;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',jsonb_set(a,'{source,russianTitle}','"forged"')),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',jsonb_set(a,'{payload,bibliographicTitle,provider}','"forged"')),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',jsonb_set(a,'{payload,sourceUrls}','["https://fixture.test/title"]')),'40001');
 a:=public.premium_fixture_args('country','fixture-country');
 for bad in select value from jsonb_array_elements(jsonb_build_array(
   jsonb_set(a,'{payload,fields,extra}','true'),jsonb_set(a,'{payload,fields,facts}','[]'),
   jsonb_set(a,'{payload,fields,timeline,0,year}','"1901"'),jsonb_set(a,'{payload,fields,name}','"Страна"'),
   jsonb_set(a,'{payload,fields,name}',to_jsonb(E' \t\r\n'||chr(160)||chr(65279))),
   jsonb_set(a,'{payload,fields,timeline,0,extra}','true'),jsonb_set(a,'{sourceRevision,catalogSourceHash}','"bad"')
 )) loop perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023'); end loop;
end; $$;
select 'M07_T05_NATIVE_SHAPE_SOURCE_PASS';

do $$ declare a jsonb; bad jsonb; kind text; key text; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach kind in array array['literary_work','country'] loop
   a:=public.premium_fixture_args(kind,case when kind='country' then 'null-shape' else 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa' end);
   foreach key in array array['source','sourceRevision','targetRevision','payload','provenance'] loop
     bad:=jsonb_set(a,array[key],'null'::jsonb);
     perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
     bad:=a-key;
     perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
   end loop;
 end loop;
end; $$;
select 'M07_T05_NATIVE_NULL_BOUNDARY_PASS';

insert into public.premium_fixture_saved values('before-work',(select to_jsonb(w) from public.literary_works w)),
 ('before-ru',(select to_jsonb(t) from public.literary_work_translations t where locale='ru')),
 ('before-en',(select to_jsonb(t) from public.literary_work_translations t where locale='en')),
 ('before-sources',(select jsonb_agg(to_jsonb(s) order by id) from public.literary_work_sources s));
truncate public.premium_fixture_outbox;
do $$ declare a jsonb; d jsonb; actual_hash text; begin
 a:=public.premium_fixture_args('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(a)->'draft';
 insert into public.premium_fixture_saved values('book-pending',d),('book-args',a);
 perform public.premium_fixture_assert(d->>'humanReview'='pending' and d->>'createdBy'='11111111-1111-4111-8111-111111111111','server actor pending');
 perform public.premium_fixture_assert(d->'sourceRevision'=a->'sourceRevision' and d->'targetRevision'=a->'targetRevision' and d->'payload'=a->'payload'
   and d->'provenance'=a->'provenance' and d->'sourceSnapshot'=a->'source','exact ACK full precision');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa')->'draft'=d,'exact saved read');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,null,false)',d),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,null,null)',d),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',jsonb_set(d,'{candidateHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',jsonb_set(d,'{sourceHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{version}','2')),'40001');
 reset role;
 select encode(sha256(convert_to(jsonb_build_object('entityType',d->'entityType','entityId',d->'entityId','targetLocale','en',
   'sourceHash',d->'sourceHash','sourceSnapshot',d->'sourceSnapshot','sourceRevision',d->'sourceRevision','targetRevision',d->'targetRevision',
   'payload',d->'payload','provenance',d->'provenance')::text,'UTF8')),'hex') into actual_hash;
 perform public.premium_fixture_assert(d->>'candidateHash'=actual_hash,'entire immutable candidate hash');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stage no canonical outbox');
 perform public.premium_fixture_assert((select to_jsonb(w)=(select value from public.premium_fixture_saved where name='before-work') from public.literary_works w),'stage complete work');
 perform public.premium_fixture_assert((select to_jsonb(t)=(select value from public.premium_fixture_saved where name='before-ru') from public.literary_work_translations t where locale='ru'),'stage complete RU');
 perform public.premium_fixture_assert((select to_jsonb(t)=(select value from public.premium_fixture_saved where name='before-en') from public.literary_work_translations t where locale='en'),'stage complete EN');
 set local role anon;
 perform public.premium_fixture_assert((select count(*)=1 from public.literary_work_translations where locale='en'),'existing admitted machine remains public');
end; $$;
select 'M07_T05_NATIVE_PRIVATE_PENDING_PASS';

-- Each stale-source/target test rolls the canonical mutation back in a nested
-- subtransaction after observing the actual RPC conflict, retaining one receipt.
do $$ declare d jsonb; field text; begin
 select value into d from public.premium_fixture_saved where name='book-pending';
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 foreach field in array array['work','ru','en','manual','title','title-source'] loop
   begin
     if field='work' then update public.literary_works set original_title='changed';
     elsif field='ru' then update public.literary_work_translations set description=description||' ' where locale='ru';
     elsif field='en' then update public.literary_work_translations set description=description||' ' where locale='en';
     elsif field='manual' then update public.literary_work_translations set translation_method='human-translation' where locale='en';
     elsif field='title' then update public.literary_work_translations set title='New verified title' where locale='en';
     else delete from public.literary_work_sources where provider='verified-bibliography'; end if;
     set local role authenticated;
     perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',d),'40001');
     reset role;
     raise exception using errcode='P0002',message='rollback test drift';
   exception when no_data_found then null; end;
 end loop;
 -- Manual target also prevents initial staging, independent of pending check.
 begin
   delete from public.premium_translation_working_drafts;
   update public.literary_work_translations set translation_method='human-translation' where locale='en';
   set local role authenticated;
   perform public.premium_fixture_error($q$select public.premium_fixture_stage(public.premium_fixture_args('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'))$q$,'40001');
   reset role;
   raise exception using errcode='P0002',message='rollback manual control';
 exception when no_data_found then null; end;
end; $$;
select 'M07_T05_NATIVE_BOOK_CAS_MANUAL_PASS';

do $$ declare d jsonb; receipt jsonb; before_en jsonb; begin
 select value into d from public.premium_fixture_saved where name='book-pending';
 select value into before_en from public.premium_fixture_saved where name='before-en';
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 receipt:=public.premium_fixture_promote(d);
 insert into public.premium_fixture_saved values('book-promoted',receipt);
 perform public.premium_fixture_assert(receipt->>'state'='promoted' and receipt->>'reviewedBy'='22222222-2222-4222-8222-222222222222','human actor receipt');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('literary_work',d->>'entityId')->'draft'='null'::jsonb,'consumed exact book');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',d),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',d),'40001');
 reset role;
 perform public.premium_fixture_assert((select description=d#>>'{payload,description}' and title=before_en->>'title'
   and metadata->'authored'=before_en#>'{metadata,authored}' and metadata->'rights'=before_en#>'{metadata,rights}'
   and metadata#>>'{premiumTranslation,custom}'='retained' and editorial_status='reviewed'
   and metadata#>>'{premiumTranslation,humanReview,reviewedBy}'=receipt->>'reviewedBy'
   and metadata#>>'{premiumTranslation,humanReview,reviewedAt}'=receipt->>'reviewedAt'
   and metadata#>>'{premiumTranslation,translatorModel}'='fixture-translator'
   from public.literary_work_translations where locale='en'),'stored payload + preserved metadata + real human provenance');
 perform public.premium_fixture_assert((select to_jsonb(w)=(select value from public.premium_fixture_saved where name='before-work') from public.literary_works w),'promote work preserved');
 perform public.premium_fixture_assert((select to_jsonb(t)=(select value from public.premium_fixture_saved where name='before-ru') from public.literary_work_translations t where locale='ru'),'promote RU preserved');
 perform public.premium_fixture_assert((select jsonb_agg(to_jsonb(s) order by id)=(select value from public.premium_fixture_saved where name='before-sources') from public.literary_work_sources s),'sources rights preserved');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one canonical promotion');
end; $$;
select 'M07_T05_NATIVE_BOOK_PROMOTION_PASS';

-- Country absent override: no canonical insertion before approval. The trusted
-- current catalog includes other locales which must survive the new EN override.
truncate public.premium_fixture_outbox;
do $$ declare d jsonb; receipt jsonb; catalog jsonb := '{"name":"Страна","translations":{"ru":{"authored":"RU"},"fr":{"authored":"FR"}}}'; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','fixture-country'))->'draft';
 insert into public.premium_fixture_saved values('country-pending',d);
 reset role;
 perform public.premium_fixture_assert((select count(*)=0 from public.country_profile_overrides),'pending country absent unchanged');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'country pending no outbox');
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,'[]'),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,'{"translations":"opaque authored data"}'),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',jsonb_set(d,'{sourceRevision,catalogSourceHash}',to_jsonb(repeat('c',64))),catalog),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,'{"translations":{"en":null}}'),'40001');
 receipt:=public.premium_fixture_promote(d,catalog);
 insert into public.premium_fixture_saved values('country-promoted',receipt);
 reset role;
 perform public.premium_fixture_assert((select fields#>'{translations,ru}'=catalog#>'{translations,ru}' and fields#>'{translations,fr}'=catalog#>'{translations,fr}'
   and fields#>>'{translations,en,status}'='reviewed' and fields#>>'{translations,en,method}'='machine-translation'
   and fields#>>'{translations,en,humanReview,reviewedBy}'=receipt->>'reviewedBy'
   and not (fields#>'{translations,en,fields}')?'history' and not (fields#>'{translations,en,fields}')?'chronology'
   from public.country_profile_overrides where country_id='fixture-country'),'catalog locales + compact fields + human review');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one new country approval');
end; $$;
select 'M07_T05_NATIVE_COUNTRY_CATALOG_PASS';

insert into public.country_profile_overrides(country_id,fields,is_enabled,updated_by) values
 ('own-machine','{"name":"Авторская страна","coordinates":[10,20],"rights":{"source":"retain"},"translations":{"fr":{"human":"FR"},"en":{"locale":"en","method":"machine-translation","status":"reviewed","custom":"retain"}}}',false,'11111111-1111-4111-8111-111111111111'),
 ('hidden-human','{"translations":{"fr":{"human":"FR"}}}',true,'11111111-1111-4111-8111-111111111111'),
 ('own-human','{"translations":{"en":{"locale":"en","method":"human-translation","fields":{"name":"Human country"}}}}',true,'11111111-1111-4111-8111-111111111111');
insert into public.premium_fixture_saved values('country-before',(select to_jsonb(c) from public.country_profile_overrides c where country_id='own-machine'));
truncate public.premium_fixture_outbox;
do $$ declare d jsonb; receipt jsonb; before_country jsonb; field text; catalog jsonb := '{"translations":{"en":{"locale":"en","method":"human-translation"},"de":{"keep":"base"}}}'; begin
 select value into before_country from public.premium_fixture_saved where name='country-before';
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 perform public.premium_fixture_error($q$select public.premium_fixture_stage(public.premium_fixture_args('country','own-human'))$q$,'40001');
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','hidden-human'))->'draft';
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,catalog),'40001');
 perform public.premium_fixture_discard(d);
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','own-machine'))->'draft';
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(c)=before_country from public.country_profile_overrides c where country_id='own-machine'),'whole override unchanged while pending');
 foreach field in array array['source','manual','delete'] loop
   begin
     if field='source' then update public.country_profile_overrides set fields=fields||'{"name":"changed"}' where country_id='own-machine';
     elsif field='manual' then update public.country_profile_overrides set fields=jsonb_set(fields,'{translations,en,method}','"human-translation"') where country_id='own-machine';
     else delete from public.country_profile_overrides where country_id='own-machine'; end if;
     set local role authenticated;
     perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,catalog),'40001');
     reset role;
     raise exception using errcode='P0002',message='rollback country drift';
   exception when no_data_found then null; end;
 end loop;
 set local role authenticated;
 receipt:=public.premium_fixture_promote(d,catalog);
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,catalog),'40001');
 reset role;
 perform public.premium_fixture_assert((select not is_enabled and fields-'translations'=(before_country->'fields')-'translations'
   and fields#>'{translations,fr}'=before_country#>'{fields,translations,fr}' and not (fields->'translations')?'de'
   and fields#>>'{translations,en,custom}'='retain' and fields#>>'{translations,en,reviewedBy}'=receipt->>'reviewedBy'
   from public.country_profile_overrides where country_id='own-machine'),'own machine precedence preserves override map flags rights');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'country canonical writes only approval');
end; $$;
select 'M07_T05_NATIVE_COUNTRY_CAS_MANUAL_PASS';

-- Lost stage ACK is recoverable through exact get; stale candidate can be
-- discarded even after a manual winner, but wrong version/hash cannot consume.
truncate public.premium_fixture_outbox;
do $$ declare d jsonb; later jsonb; before_country jsonb; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_stage(public.premium_fixture_args('country','late-override'));
 d:=public.get_premium_translation_working_draft('country','late-override')->'draft';
 reset role;
 insert into public.country_profile_overrides(country_id,fields) values('late-override','{"translations":{"en":{"locale":"en","method":"human-translation","fields":{"name":"Manual winner"}}}}');
 select to_jsonb(c) into before_country from public.country_profile_overrides c where country_id='late-override';
 truncate public.premium_fixture_outbox;
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,''{}''::jsonb)',d),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{candidateHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('country','late-override')->'draft'=d,'stale still inspectable');
 perform public.premium_fixture_assert(public.premium_fixture_discard(d)->>'state'='discarded','exact stale discard');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',d),'40001');
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(c)=before_country from public.country_profile_overrides c where country_id='late-override'),'discard preserves manual winner');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'discard no canonical outbox');
 set local role authenticated;
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','restage'))->'draft';
 perform public.premium_fixture_discard(d);
 later:=public.premium_fixture_stage(public.premium_fixture_args('country','restage'))->'draft';
 perform public.premium_fixture_assert(later->>'id'<>d->>'id','restage fresh identity');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',d),'40001');
 perform public.premium_fixture_discard(later);
end; $$;
select 'M07_T05_NATIVE_DISCARD_REPLAY_PASS';

do $$ begin
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_translation_working_drafts),'all candidates consumed explicitly');
 perform public.premium_fixture_assert(not exists(select 1 from public.admin_audit_log where action like 'premium_translation.candidate.%'
   and (metadata-array['draftId','version','candidateHash','sourceHash','canonicalId','outcome'])<>'{}'::jsonb),'audit only IDs hashes outcomes');
 perform public.premium_fixture_assert((select count(*)>5 from public.admin_audit_log where action like 'premium_translation.candidate.%'),'durable audit outcomes');
 perform public.premium_fixture_assert(not exists(select 1 from public.admin_audit_log where action like 'premium_translation.candidate.%' and
   metadata::text like '%astronomers%'),'no candidate prose in audit');
end; $$;
select 'M07_T05_NATIVE_AUDIT_FINAL_PASS';
select 'M07_T05_DTO='||jsonb_object_agg(name,value)::text from public.premium_fixture_saved
 where name in ('book-pending','country-pending','book-promoted','country-promoted','book-args');
select 'M07_T05_SUMMARY='||jsonb_build_object('groups',10,'providerCalls',0,'canonicalStagingWrites',0,
 'pendingNeverOverwritten',true,'explicitReviewActor',true,'protectedManualAndAdmittedMachine',true,
 'countryCatalogBoundary','trusted application reload; SQL override CAS and ownership','allCandidatesConsumed',true)::text;
