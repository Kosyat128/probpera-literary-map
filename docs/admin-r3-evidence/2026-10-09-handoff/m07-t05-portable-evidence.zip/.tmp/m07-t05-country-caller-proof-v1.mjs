import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const hash = x => createHash('sha256').update(x).digest('hex');
const file = path => ({path,sha256:hash(readFileSync(path)),bytes:readFileSync(path).length});
const read = path => JSON.parse(readFileSync(path,'utf8'));
const prefix = '.tmp/m07-t05-country-caller-';
const before = read(prefix+'before-v3-metadata.json'), current = read(prefix+'current-v3-metadata.json');
const beforeResult=read(prefix+'before-v3-results.json'), currentResult=read(prefix+'current-v3-results.json');
assert.equal(beforeResult.numTotalTests,2); assert.equal(beforeResult.numFailedTests,2);
assert.equal(currentResult.numTotalTests,2); assert.equal(currentResult.numPassedTests,2);
assert.equal(read(prefix+'before-v3-command.json').result.exit_code,1);
assert.equal(read(prefix+'current-v3-command.json').result.exit_code,0);
assert.equal(before.fixture.sha256,current.fixture.sha256);
assert.equal(before.fixture.sha256,hash(readFileSync('apps/admin/lib/country-translation-source-binding.integration.test.ts')));
assert(before.sourceUnchanged && current.sourceUnchanged);
assert.deepEqual(before.sources.map(x=>x.module),current.sources.map(x=>x.module));
const delta=before.sources.filter((x,i)=>x.sha256!==current.sources[i].sha256).map((x,i)=>({before:x,current:current.sources.find(y=>y.module===x.module)}));
assert.equal(delta.length,1); assert.equal(delta[0].before.module,'apps/admin/app/(dashboard)/editorial-database/actions.ts');
for(const [i,trace] of before.traces.entries()) {
  assert.equal(trace.providerCalls,2); assert.equal(trace.view.status,'pending'); assert.equal(trace.view.canPromote,false);
  assert.equal(current.traces[i].providerCalls,2); assert.equal(current.traces[i].view.canPromote,true);
  assert.deepEqual(trace.row,current.traces[i].row);
  assert.deepEqual(trace.draft.sourceSnapshot,current.traces[i].draft.sourceSnapshot);
  assert.notEqual(trace.draft.sourceRevision.catalogSourceHash,current.traces[i].draft.sourceRevision.catalogSourceHash);
}
const capture=file(prefix+'before-v2-actions.ts');
assert.equal(capture.sha256,'74fa587dfb9f70665feb102243d3380ffcc52cc0a7ee78a62ed7c283a6241614');
const supplement={schemaVersion:1,checkedAt:new Date().toISOString(),scope:'Exact unmodified caller snapshot captured before its one-line correction; supplement to capture382, not an original-07ed graph replay',files:[{source:'apps/admin/app/(dashboard)/editorial-database/actions.ts',proof:capture.path,sha256:capture.sha256,bytes:capture.bytes}]};
writeFileSync(prefix+'supplement-v1.json',JSON.stringify(supplement,null,2));
const proof={schemaVersion:1,checkedAt:new Date().toISOString(),scope:current.scope,fixture:current.fixture,
  supplement:file(prefix+'supplement-v1.json'),before:{total:2,passed:0,failed:2},current:{total:2,passed:2,failed:0},
  actualModuleCount:current.sources.length,sharedModulesUnchanged:current.sources.length-1,sourceDelta:delta,
  traces:{sameSavedRow:true,sameEffectiveRussian:true,providerDispatchesPerCase:2,beforeReviewable:false,currentReviewable:true},
  boundary:'Actual save action/form parser/helper/provider transport/runtime gate/review domain/Supabase SDK. Controlled Auth, catalog content, Supabase SDK fetch, Cloudflare AI.run, external public-build trigger. The explicit RU save requests one controlled build; the private candidate is not canonical English.',
  evidence:['before-v3-command.json','before-v3-results.json','before-v3-metadata.json','current-v3-command.json','current-v3-results.json','current-v3-metadata.json'].map(s=>file(prefix+s)),
  notVerified:['Real Auth/DB/RLS/provider/deployment','Whole original07ed runtime replay']};
writeFileSync(prefix+'same-v1-proof.json',JSON.stringify(proof,null,2));
console.log(JSON.stringify({proof:file(prefix+'same-v1-proof.json'),supplement:file(prefix+'supplement-v1.json'),counts:proof.current,actualModuleCount:proof.actualModuleCount}));
