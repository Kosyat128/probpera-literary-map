import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';

const [mode, label] = process.argv.slice(2);
assert.ok(['current'].includes(mode) && /^[a-z0-9-]+$/u.test(label ?? ''));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const hashFile = file => sha(readFileSync(file));
const manifestPath = '.tmp/m07-t05-before/manifest.json';
const manifestHash = '4329a58bf91d2cd402bfe329b65fb9a3464514a760f72b89678370d8f41dab7f';
assert.equal(hashFile(manifestPath), manifestHash);
const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
const capture = new Map(manifest.files.map(row => [row.source, row]));
const fixture = 'apps/admin/lib/literary-work-machine-review.integration.test.ts';
const fixtureHash = hashFile(fixture);
const prefix = '.tmp/m07-t05-book-' + label;
const artifacts = Object.fromEntries(['results.json', 'evidence.json', 'command.json', 'command.log', 'fixture.ts'].map(suffix => [suffix, prefix + '-' + suffix]));
for (const file of Object.values(artifacts)) assert.equal(existsSync(file), false, 'Immutable artifact exists: ' + file);
writeFileSync(artifacts['fixture.ts'], readFileSync(fixture), { flag: 'wx' });
const start = new Map(manifest.files.filter(row => !row.source.endsWith('.md')).map(row => [row.source, hashFile(row.source)]));
for (const file of ['apps/admin/lib/premium-translation-working-draft.ts']) start.set(file, hashFile(file));
const ownedTemp = path.resolve(prefix + '-child-temp');
mkdirSync(ownedTemp, { recursive: true });
const guardDirectory=path.resolve(prefix+'-fs-guard'); mkdirSync(guardDirectory,{recursive:true});
const guardPath=path.resolve('.tmp/m07-t05-portable-before-guard-v1.cjs');
const env = { ...process.env, NODE_OPTIONS: '--require='+JSON.stringify(guardPath), M07_T05_PORTABLE_GUARD_DIR: guardDirectory, TEMP: ownedTemp, TMP: ownedTemp,
  PATH: path.dirname(process.execPath) + path.delimiter + process.env.PATH,
  M07_BOOK_REVIEW_EVIDENCE: path.resolve(artifacts['evidence.json']),
  PREMIUM_TRANSLATION_PROVIDER: 'cloudflare', OPENAI_AUTO_TRANSLATE_ARTICLES: 'true', OPENAI_PREMIUM_TRANSLATION_REVIEW: 'true',
  ADMIN_BASE_PATH: '', PUBLIC_SITE_ORIGIN: 'https://probpera.ru' };
if (mode === 'before') env.M07_BOOK_REVIEW_BASELINE_ROOT = path.resolve('.tmp/m07-t05-before/raw');
else delete env.M07_BOOK_REVIEW_BASELINE_ROOT;
const args = ['node_modules/vitest/vitest.mjs', 'run', '--config', 'vitest.config.ts', fixture,
  '--maxWorkers=1', '--reporter=json', '--outputFile=' + path.resolve(artifacts['results.json'])];
const startedAt = new Date().toISOString();
let output = '';
const result = await new Promise((resolve, reject) => {
  const child = spawn(process.execPath, args, { cwd: process.cwd(), env, windowsHide: true });
  console.log(JSON.stringify({ mode, label, child: child.pid, startedAt }));
  const timer = setInterval(() => console.log(JSON.stringify({ running: label, pid: child.pid, outputBytes: Buffer.byteLength(output) })), 15000);
  child.stdout.on('data', bytes => output += bytes);
  child.stderr.on('data', bytes => output += bytes);
  child.on('error', error => { clearInterval(timer); reject(error); });
  child.on('close', (exitCode, signal) => { clearInterval(timer); resolve({ exitCode, signal }); });
});
writeFileSync(artifacts['command.log'], output, { flag: 'wx' });
const evidence = existsSync(artifacts['evidence.json']) ? JSON.parse(readFileSync(artifacts['evidence.json'], 'utf8')) : null;
const report = existsSync(artifacts['results.json']) ? JSON.parse(readFileSync(artifacts['results.json'], 'utf8')) : null;
const graphDirectory = prefix + '-actual-sources';
mkdirSync(graphDirectory, { recursive: true });
const graph = (evidence?.sourceGraph ?? []).map(row => {
  const actual = path.resolve(row.source), expected = mode === 'before' ? capture.get(row.module)?.sha256 : start.get(row.module);
  const copy = path.join(graphDirectory, row.module);
  mkdirSync(path.dirname(copy), { recursive: true });
  writeFileSync(copy, readFileSync(actual), { flag: 'wx' });
  return { ...row, expectedSha256: expected ?? null, afterSha256: hashFile(actual), executedCopy: copy.replaceAll('\\', '/'),
    sourceBound: expected === row.sha256 && hashFile(actual) === row.sha256 };
});
const counts = report ? { total: report.numTotalTests, passed: report.numPassedTests, failed: report.numFailedTests,
  pending: report.numPendingTests, todo: report.numTodoTests ?? 0 } : null;
const failures = report?.testResults.flatMap(suite => suite.assertionResults.filter(row => row.status === 'failed').map(row => ({ name: row.fullName, messages: row.failureMessages }))) ?? [];
const proof = { checkedAt: new Date().toISOString(), mode, label, startedAt, ...result,
  command: [process.execPath, ...args], fixture: { path: fixture, sha256: fixtureHash, unchanged: hashFile(fixture) === fixtureHash, copy: artifacts['fixture.ts'] },
  capture: { path: manifestPath, sha256: manifestHash, files: manifest.files.length, unchanged: hashFile(manifestPath) === manifestHash, sourceFingerprint: manifest.sourceFingerprint },
  ownedChildTemp: ownedTemp, counts, failures, graph, sourceUnchanged: evidence?.sourceUnchanged === true && graph.length > 0 && graph.every(row => row.sourceBound),
  artifacts: Object.entries(artifacts).filter(([suffix]) => suffix !== 'command.json').map(([role, file]) => ({ role, path: file, sha256: existsSync(file) ? hashFile(file) : null })),
  limitations: evidence?.scope ?? ['No fixture evidence saved; not acceptance'] };
const guardReports=readdirSync(guardDirectory).map(name=>{ const file=path.join(guardDirectory,name); return {...JSON.parse(readFileSync(file,'utf8')),proof:file,sha256:hashFile(file)}; });
proof.portability={guard:{path:guardPath,sha256:hashFile(guardPath)},reports:guardReports,passed:guardReports.length>0&&guardReports.every(row=>row.selfTestPassed===true&&row.executionDenied.length===0)};
assert.equal(proof.portability.passed,true,'Portable guard must execute and forbid all BEFORE reads');
writeFileSync(artifacts['command.json'], JSON.stringify(proof, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ mode, label, ...result, counts, fixtureHash, sourceUnchanged: proof.sourceUnchanged, actualModules: graph.length,
  command: artifacts['command.json'], sha256: hashFile(artifacts['command.json']), failures: failures.map(row => row.name) }));
process.exitCode = result.exitCode ?? 1;
