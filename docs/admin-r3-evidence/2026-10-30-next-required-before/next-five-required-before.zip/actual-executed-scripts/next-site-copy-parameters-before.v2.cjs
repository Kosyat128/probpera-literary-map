// PREPARED ONLY. Strict current-source BEFORE; execute only after root release.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../probpera-literary-map'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const sourceRoot=fs.realpathSync.native(process.env.NEXT_SITE_COPY_PARAMETER_SOURCE_ROOT||repo);
const snapshotFile=process.env.NEXT_SITE_COPY_PARAMETER_SNAPSHOT;assert.ok(snapshotFile,'Frozen root snapshot required');
const snapshotBytes=fs.readFileSync(snapshotFile),snapshot=JSON.parse(snapshotBytes.toString().replace(/^\uFEFF/u,''));
assert.match(snapshot.validationSourceSha256||'',/^[a-f0-9]{64}$/u);
const frozen=new Map(snapshot.files.map(row=>[row.path,row]));
const requested=process.env.NEXT_SITE_COPY_PARAMETER_OUTPUT;assert.ok(requested,'Fresh parent output required');
const out=path.join(fs.realpathSync.native(path.dirname(path.resolve(requested))),path.basename(requested));
const work=fs.realpathSync.native(__dirname),relative=path.relative(work,out);assert.ok(relative&&!relative.startsWith('..')&&!path.isAbsolute(relative));
assert.equal(fs.existsSync(out),false);fs.mkdirSync(out);
process.env.SITE_COPY_ADMISSION_REPO=repo;process.env.SITE_COPY_ADMISSION_SOURCE_ROOT=sourceRoot;process.env.SITE_COPY_ADMISSION_OUTPUT_ROOT=path.join(out,'actual-runtime');
const runtime=require(path.join(sourceRoot,'apps/admin/lib/fixtures/site-copy-admission-runtime.cjs'));
const dictionaryFile='src/i18n/InterfaceLanguage.tsx',applicationFile='src/App.tsx',catalogFile='apps/admin/catalog-assets/interface-copy-catalog.json';
const catalogText=fs.readFileSync(path.join(sourceRoot,catalogFile),'utf8'),dictionary=fs.readFileSync(path.join(sourceRoot,dictionaryFile),'utf8'),application=fs.readFileSync(path.join(sourceRoot,applicationFile),'utf8');
const count='{count} карточка уже прошла публикационную проверку по открытым авторитетным источникам';
const queued='Ещё {count} запись остаётся в редакционной очереди; автоматически собранные черновики не публикуются до ручной проверки';
for(const s of[count,queued])assert.ok(dictionary.includes(JSON.stringify(s))&&application.includes(JSON.stringify(s)));
for(const caller of['readyBiographyCount','editorialQueueCount'])assert.ok(application.includes(`.replace("{count}", number(${caller}))`));
const cases=[
 {name:'M24-T03 missing actual publication count',kind:'target',russian:count,english:'Writer profile checked',required:['count']},
 {name:'M24-T03 missing actual editorial queue count',kind:'target',russian:queued,english:'Records await review',required:['count']},
 {name:'M24-T03 compatible actual publication count',kind:'control',russian:count,english:'The {count} writer profile has been checked',required:['count']},
 {name:'M24-T03 plain copy has no invented parameters',kind:'control',russian:'Поиск',english:'Search',required:[]},
];
const results=[];
(async()=>{
 for(const input of cases){
  const view=runtime.createSiteCopyAdmissionRuntime({onProvider:async({value})=>{const body=JSON.parse(value.response);body.items=body.items.map(item=>({...item,text:input.english}));value.response=JSON.stringify(body);}});
  view.mocks['./admin-catalog-assets']={readAdminCatalogText:async name=>{assert.equal(name,'interface-copy-catalog.json');return catalogText;}};
  const catalog=view.loaded.load('apps/admin/lib/site-copy-catalog.ts');view.mocks['@/lib/site-copy-catalog']=catalog;view.mocks['./site-copy-catalog']=catalog;
  const definitions=await catalog.loadAllSiteCopyCatalog(),key='interface.'+input.russian;assert.ok(definitions.some(row=>row.key===key&&row.defaultRu===input.russian));
  const row=view.snapshot();row.settings.siteCopy.ru={[key]:input.russian};delete row.settings.siteCopy.en[key];delete row.settings.premiumTranslation.siteCopyEn[key];view.setRow(row);
  const validationEvents=[],contract=view.loaded.load('apps/admin/lib/site-copy-translation-contract.ts'),validate=contract.validateSiteCopyTranslationCandidate;
  // Observation only: all decisions and returned/raised values are original.
  contract.validateSiteCopyTranslationCandidate=function(...args){const event={source:structuredClone(args[0]),payload:structuredClone(args[1])};validationEvents.push(event);try{const value=validate.apply(this,args);event.accepted=true;return value;}catch(error){event.accepted=false;event.error={name:error.name,message:error.message,code:error.code||error.errorCode||null,stack:error.stack};throw error;}};
  const approval=view.loaded.load('apps/admin/lib/premium-translation-review.ts'),approve=approval.approvePremiumTranslationReview,approvalEvents=[];
  approval.approvePremiumTranslationReview=async function(...args){const event={entityType:args[0].entityType,entityId:args[0].entityId};approvalEvents.push(event);try{const value=await approve.apply(this,args);event.accepted=true;return value;}catch(error){event.accepted=false;event.error={name:error.name,message:error.message,code:error.code||error.errorCode||null,stack:error.stack};throw error;}};
  const before=view.stateSnapshot(),result=await view.helper(),draft=view.candidate();
  assert.deepEqual(view.snapshot(),before.canonical);assert.equal(view.builds.length,0);
  // This is the intended BEFORE admission/approval trigger. An unrelated early
  // failure is UNEXERCISED and never a green parameter-protection result.
  assert.ok(draft,'UNEXERCISED_BEFORE: helper did not produce a real private candidate');
  assert.deepEqual(view.requests.map(c=>c.pass),['translation','review']);
  const candidate=draft.payload.items.find(item=>item.key===key)?.text;assert.equal(candidate,input.english);
  const ops=[...view.admission.operations.values()];assert.equal(ops.length,1);assert.equal(ops[0].calls.length,2);
  assert.ok(ops[0].calls.every(call=>call.metadata.responseReceivedAt!==null&&call.responseArtifact!==null));
  const review=await view.loadReview();assert.equal(review.status,'pending','UNEXERCISED_BEFORE: private review unavailable');
  const beforeApproval={calls:view.requests.length,wire:view.wire.length,validations:validationEvents.length};
  const redirect=await view.reviewAction(view.reviewForm(true));assert.equal(approvalEvents.length,1,'Actual human-approval core must be reached');
  const publishedEnglish=view.publicView().en[key]??null,promoted=view.promotions.length>0;
  const relevantErrors=validationEvents.slice(beforeApproval.validations).filter(event=>event.accepted===false&&event.source.some(item=>item.key===key));
  const specificRefusal=!promoted&&approvalEvents[0].accepted===false&&relevantErrors.some(event=>/parameter|placeholder|variable|переменн|параметр/iu.test([event.error.code,event.error.message].join(' ')));
  const missingAfterApply=input.required.filter(name=>!publishedEnglish?.includes('{'+name+'}'));
  const pass=input.kind==='target'?specificRefusal:promoted&&publishedEnglish===input.english&&missingAfterApply.length===0;
  assert.equal(view.requests.length,beforeApproval.calls,'Human approval must never regenerate translation');
  results.push({name:input.name,kind:input.kind,status:pass?'PASS':'FAIL',key,source:input.russian,required:input.required,result,candidate,review,redirect,
   strictBeforeTrigger:{privateCandidate:true,actualTwoPassTranslation:true,allBodiesAcknowledged:true,actualApprovalCoreReached:true},specificRefusal,validationEvents,approvalEvents,
   promoted,publishedEnglish,missingAfterApply,providerCalls:view.requests.length,wire:view.wire,builds:view.builds,canonicalBefore:before.canonical,canonicalAfter:view.snapshot()});
 }
 const bindings=runtime.sourceBindings(),references=[dictionaryFile,applicationFile,catalogFile].map(file=>{const bytes=fs.readFileSync(path.join(sourceRoot,file)),destination=path.join(out,'reference-sources',file);fs.mkdirSync(path.dirname(destination),{recursive:true});fs.writeFileSync(destination,bytes);return{file,bytes:bytes.length,sha256:sha(bytes),role:file===catalogFile?'actual managed parser input':'source-only actual caller reference; not browser execution'};});
 for(const row of[...bindings,...references]){assert.equal(row.sha256,frozen.get(row.file)?.sha256);assert.equal(row.bytes,frozen.get(row.file)?.size);}
 const report={classification:'STRICT_BEFORE_ACTUAL_HELPER_PRIVATE_CANDIDATE_AND_HUMAN_APPROVAL_NOT_NATIVE_OR_BROWSER',producedAt:new Date().toISOString(),sealedInput:{snapshotSha256:sha(snapshotBytes),validationSourceSha256:snapshot.validationSourceSha256},producerSha256:sha(fs.readFileSync(__filename)),results,bindings,references,
  limits:['Original producer remains unexecuted and unchanged. Missing candidate, unrelated refusal or broken plain/compatible control is not a parameter PASS.',
  'This strict BEFORE requires actual candidate admission. A later legitimate helper-stage parameter rejection needs its own declared direct-validator/helper regression, not a silently weakened trigger.',
  'Only two actual count keys are targets; page/total/plural/rich-text are not fabricated. No actual public caller/browser, DB, provider or production publication executes.']};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');fs.copyFileSync(__filename,path.join(out,'producer.cjs'));console.log(JSON.stringify({out,results:results.map(r=>({name:r.name,status:r.status,specificRefusal:r.specificRefusal}))}));
})().catch(error=>{fs.writeFileSync(path.join(out,'unexercised-or-execution-failure.json'),JSON.stringify({classification:'NOT_A_PARAMETER_PASS',error:error.stack,results},null,2));console.error(error.stack);process.exitCode=2;});
