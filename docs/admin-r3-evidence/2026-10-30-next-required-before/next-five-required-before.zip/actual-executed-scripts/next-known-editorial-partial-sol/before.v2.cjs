/* Prepared only. Run after the root seals current source, with its exact snapshot. */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const kinds=['writer','library','country','site_copy'];
const plan={classification:'PARENT_ONLY_PREPARED_SOURCE_ONLY_NOT_EXECUTED',trigger:'Actual first translation validates, actual review response and its final repair are invalid; every body is delivered/ACKed, original default budget is not exhausted. Invoke the same ordinary helper again on unchanged source.',
 kinds,targets:['writer','library','country'],control:'site_copy',providerCalls:0,databaseConnections:0,
 execution:'node before.v2.cjs --execute-controlled --source-root <sealed-current-or-exact-captured-source> --snapshot <root-source-before.json> --output <fresh-parent-dir>',
 distinction:'This is a new known validator-failure oracle. The existing unchanged a63 deadline/unknown partial guards remain separate, already passing; no paid partial continuation is implied.'};
fs.mkdirSync(__dirname,{recursive:true});fs.writeFileSync(path.join(__dirname,'prepared-plan.v2.json'),JSON.stringify(plan,null,2));
if(!process.argv.includes('--execute-controlled')){console.log(JSON.stringify(plan));process.exit(0);}
const option=name=>{const at=process.argv.indexOf(name);assert.ok(at>=0&&process.argv[at+1],`Missing ${name}`);return process.argv[at+1]};
const sourceRoot=fs.realpathSync.native(option('--source-root')),snapshotFile=path.resolve(option('--snapshot')),requested=path.resolve(option('--output'));
const out=path.join(fs.realpathSync.native(path.dirname(requested)),path.basename(requested)),work=fs.realpathSync.native(path.resolve(repo,'../work')),relative=path.relative(work,out);
assert.ok(relative&&!relative.startsWith('..')&&!path.isAbsolute(relative));assert.equal(fs.existsSync(out),false);fs.mkdirSync(out);
const snapshotBytes=fs.readFileSync(snapshotFile),snapshot=JSON.parse(snapshotBytes.toString().replace(/^\uFEFF/u,''));
assert.match(snapshot.validationSourceSha256||'',/^[a-f0-9]{64}$/u,'Use the root sealed global snapshot with validationSourceSha256');
const expected=new Map(snapshot.files.map(row=>[row.path,row.sha256]));
const historicalSupportArchives=['docs/admin-r3-evidence/2026-10-29-profile-budgets/next-writer-admission-before.zip','docs/admin-r3-evidence/2026-10-30-writer-admission/next-library-country-admission-before.zip'].map(file=>{const bytes=fs.readFileSync(path.join(repo,file));return{file,bytes:bytes.length,sha256:sha(bytes),role:'Immutable historical fixture-support prefix only; current application algorithms come exclusively from the sealed sourceRoot.'}});
for(const [prefix,name]of[['WRITER_ADMISSION','writer'],['CATALOG_ADMISSION','catalog'],['SITE_COPY_ADMISSION','site-copy']]){
 process.env[prefix+'_REPO']=repo;process.env[prefix+'_SOURCE_ROOT']=sourceRoot;process.env[prefix+'_OUTPUT_ROOT']=path.join(out,name+'-runtime');
}
process.env.NODE_ENV='production';
const support=['apps/admin/lib/fixtures/writer-admission-runtime.cjs','apps/admin/lib/fixtures/catalog-admission-runtime.cjs','apps/admin/lib/fixtures/site-copy-admission-runtime.cjs'];
for(const file of support){const actual=sha(fs.readFileSync(path.join(sourceRoot,file)));assert.equal(actual,expected.get(file),`Runtime differs from sealed root snapshot: ${file}`);}
const writer=require(path.join(sourceRoot,support[0])),catalog=require(path.join(sourceRoot,support[1])),sitecopy=require(path.join(sourceRoot,support[2]));
const graph=new Map(),cases=[];
function bind(file,role){const bytes=fs.readFileSync(path.join(sourceRoot,file)),actual=sha(bytes);assert.equal(actual,expected.get(file),`Input differs from sealed root snapshot ${file}`);const earlier=graph.get(file);if(earlier){assert.equal(earlier.sha256,actual);if(!earlier.roles.includes(role))earlier.roles.push(role);}else graph.set(file,{file,bytes:bytes.length,sha256:actual,roles:[role]});}
for(const file of support)bind(file,'executed-controlled-runtime');
for(const file of['apps/admin/lib/fixtures/site-copy-admission-cases.cjs','apps/admin/lib/site-copy-admission.integration.test.ts','apps/admin/lib/site-copy-translation-operation-rpc.integration.test.ts'])bind(file,'sitecopy-runtime-read-input-not-executed-test-cases');
function wire(view){return structuredClone(view.wire);}
function calls(view){return structuredClone(view.providerCalls);}
function operations(kind,view){return structuredClone([...(kind==='site_copy'?view.admission.operations:view.server.operations).values()]);}
function countWire(rows,family){return rows.filter(row=>family.test(row.path||row.name||'')).length;}
const rpc={begin:/\/(?:begin_writer_translation_operation|begin_catalog_translation_operation|begin_site_copy_translation_operation)$/u,
 dispatch:/\/record_(?:writer|catalog|site_copy)_translation_operation_dispatch$/u,response:/\/record_(?:writer|catalog|site_copy)_translation_operation_response$/u,
 finish:/\/finish_(?:writer|catalog|site_copy)_translation_operation$/u};
const counters=(view,kind)=>({providerCalls:view.providerCalls.length,translationCalls:view.providerCalls.filter(c=>c.pass==='translation').length,
 begin:countWire(view.wire,rpc.begin),dispatch:countWire(view.wire,rpc.dispatch),response:countWire(view.wire,rpc.response),finish:countWire(view.wire,rpc.finish),
 candidates:kind==='site_copy'?(view.privateDraft?1:0):view.privateCandidates.size,canonicalWrites:kind==='site_copy'?view.mutations.length:view.writes.length,publicBuilds:view.builds.length});
async function scenario(kind){
 const options={candidates:1,onProvider:async({call})=>{options.invalidEveryPass=call.pass!=='translation';}};
 const view=kind==='writer'?writer.setup(options):kind==='site_copy'?sitecopy.createSiteCopyAdmissionRuntime({invalidPasses:[2,3,5,6]}):catalog.setup(kind,options);
 const measuredBudgets=[];
 if(kind==='site_copy'){const api=view.loaded.load('apps/admin/lib/translation-operation-budget.ts'),create=api.createTranslationOperationBudget;
  api.createTranslationOperationBudget=input=>{const budget=create(input);measuredBudgets.push({input:structuredClone(input),budget});return budget;};}
 const canonical=()=>kind==='site_copy'?view.snapshot():view.canonical(),canonicalBefore=canonical(),initial=counters(view,kind);
 const first=await view.helper(),firstCounts=counters(view,kind),firstWire=wire(view),firstProvider=calls(view),firstOps=operations(kind,view);
 const firstStored=firstOps[0];assert.ok(firstStored,'Actual durable admission must exist');
 const firstCall=firstStored.calls[0],firstArtifact=firstCall.responseArtifact||firstCall.artifact;
 assert.ok(firstArtifact&&Object.hasOwn(firstArtifact,'body'),'Actual first translator body must be retained');
 assert.deepEqual(firstProvider.map(call=>call.pass),['translation','review','repair'],'The specific three-pass known failure trigger must actually execute');
 assert.equal(firstCounts.candidates,0,'No complete editorial candidate was produced');
 const load=file=>(kind==='site_copy'?view.loaded.load: view.load)(file);
 const parsed=load('apps/admin/lib/premium-english-translation.ts').retainedPremiumTranslationResponseValue(firstStored.provider||firstStored.configuration.provider,firstArtifact.body,'translation');
 const validate=value=>kind==='writer'?load('apps/admin/lib/auto-translate-writer-biography.ts').validateWriterBiographyTranslationCandidate(value,firstStored.sourceSnapshot)
  :kind==='library'?load('apps/admin/lib/auto-translate-literary-work.ts').validateLiteraryWorkTranslationCandidate(value)
  :kind==='country'?load('apps/admin/lib/auto-translate-country-profile.ts').validateCountryTranslationCandidate(firstStored.sourceSnapshot,value)
  :load('apps/admin/lib/auto-translate-site-copy.ts').validateRetainedSiteCopyTranslation(firstStored.sourceSnapshot.items,value);
 const validated=validate(parsed),knownEditorialFailures=[];
 for(const call of firstStored.calls.slice(1)){
  const artifact=call.responseArtifact||call.artifact;assert.ok(artifact&&Object.hasOwn(artifact,'body'),'Every failed editorial body was retained');
  const pass=call.metadata?.pass||call.pass;let rejected=false,message=null;
  try{validate(load('apps/admin/lib/premium-english-translation.ts').retainedPremiumTranslationResponseValue(firstStored.provider||firstStored.configuration.provider,artifact.body,pass));}catch(error){rejected=true;message=error.message;}
  assert.equal(rejected,true,'Actual original validator must reject review and repair');knownEditorialFailures.push({pass,rejected,message,artifact});
 }
 const observedBudgets=()=> (kind==='site_copy'?measuredBudgets:view.budgets).map(row=>({input:row.input,snapshot:row.budget.snapshot()}));
 const budgetsBefore=observedBudgets();assert.ok(budgetsBefore.length>0);
 assert.ok(budgetsBefore.every(row=>row.snapshot.elapsedMs<row.snapshot.deadlineMs&&row.snapshot.providerCalls<=4),'No clock exhaustion or inflated default caps');
 assert.deepEqual(budgetsBefore[0].input,{maxAttempts:1,maxProviderCalls:4,deadlineMs:kind==='site_copy'?45000:300000});
 assert.deepEqual(canonical(),canonicalBefore);assert.equal(firstCounts.canonicalWrites,0);assert.equal(firstCounts.publicBuilds,0);
 const wireBoundary=view.wire.length,providerBoundary=view.providerCalls.length;
 const second=await view.helper(),after=counters(view,kind),canonicalAfter=canonical();
 assert.deepEqual(canonicalAfter,canonicalBefore);assert.equal(after.canonicalWrites,0);assert.equal(after.publicBuilds,0);
 const finalOps=operations(kind,view);
 const identity=op=>op.operationId||op.receipt?.operationId;
 const dispatchIdentity=call=>call.id||call.metadata?.callId;
 const oldIds=new Set(firstOps.map(identity)),oldCalls=new Set(firstOps.flatMap(op=>op.calls.map(dispatchIdentity)));
 assert.ok([...oldIds,...oldCalls].every(id=>typeof id==='string'&&id.length>0),'Observe real stored operation/call identities, not only RPC counts');
 const newLogicalOperationIds=finalOps.map(identity).filter(id=>!oldIds.has(id));
 const newDispatchCallIds=finalOps.flatMap(op=>op.calls.map(dispatchIdentity)).filter(id=>!oldCalls.has(id));
 const rows=view.graph.values();
 for(const row of rows){const file=row.file||row.module,actual=sha(fs.readFileSync(path.join(sourceRoot,file)));assert.equal(actual,row.sha256,`Executed source drift ${file}`);bind(file,'actual-helper-or-free-original-validator-control');}
 for(const entry of Object.values(require.cache)){if(entry.filename.startsWith(path.join(sourceRoot,'apps/admin/lib/fixtures')+path.sep))bind(path.relative(sourceRoot,entry.filename).replaceAll('\\','/'),'executed-controlled-CJS-dependency');}
 return{kind,classification:kind==='site_copy'?'CURRENT_SAFETY_CONTROL':'PROPOSED_REGRESSION_TARGET_NOT_ASSUMED_FAIL',first,second,initial,firstCounts,after,
 deltas:Object.fromEntries(Object.keys(after).map(key=>[key,after[key]-firstCounts[key]])),
 validatedFirstTranslation:validated,knownEditorialFailures,firstRawTranslatorBody:firstArtifact,firstWire,secondWire:wire(view).slice(wireBoundary),wire:wire(view),
 firstProviderCalls:firstProvider,secondProviderCalls:calls(view).slice(providerBoundary),providerCalls:calls(view),
 firstOperations:firstOps,finalOperations:finalOps,newLogicalOperationIds,newDispatchCallIds,firstBudgets:budgetsBefore,finalBudgets:observedBudgets(),
 canonicalBefore,canonicalAfter,sameSourceUnchanged:true,defaultHelperRepeated:true};
}
(async()=>{
 for(const kind of kinds){cases.push(await scenario(kind));fs.writeFileSync(path.join(out,'report.partial.json'),JSON.stringify({cases},null,2));}
 const sources=[...graph.values()].sort((a,b)=>a.file.localeCompare(b.file));
 for(const row of sources){const bytes=fs.readFileSync(path.join(sourceRoot,row.file));assert.equal(sha(bytes),row.sha256);const target=path.join(out,'sources',row.file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:'wx'});}
 const oracleFile=path.join(__dirname,'same-contract.v2.cjs'),oracleBytes=fs.readFileSync(oracleFile);
 fs.writeFileSync(path.join(out,'same-contract.cjs'),oracleBytes,{flag:'wx'});fs.writeFileSync(path.join(out,'producer.cjs'),fs.readFileSync(__filename),{flag:'wx'});
 const report={checkedAt:new Date().toISOString(),classification:'GENUINE_CONTROLLED_KNOWN_EDITORIAL_FAILURE_V2_NO_DEFECT_ASSUMPTION',sourceRoot,
  sealedInput:{snapshotSha256:sha(snapshotBytes),validationSourceSha256:snapshot.validationSourceSha256},producerSha256:sha(fs.readFileSync(__filename)),oracleSha256:sha(oracleBytes),
  cases,sources,sourceCount:sources.length,historicalSupportArchives,sourceDrift:false,realProviderCalls:0,
  limitations:['Actual production builders/helpers/premium parser/budgets and installed SDK execute with synthetic provider/storage/Auth boundaries. This does not prove native SQL, provider HTTP, managed backend or UI operator authorization.',
   'BEGIN replay count is diagnostic only. The oracle forbids new stored logical operation/call identities, translator/provider calls and canonical/publication mutations.',
   'No actual paid continuation is attempted; the second invocation is the ordinary same-source helper. The oracle checks that this cannot blindly regenerate an already acknowledged valid translator output.',
   'T11 budget safety holds and T13 addressed failed-item/operator commands are separate; no stronger service-role authority or elapsed deadline reset is inferred.']};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));fs.writeFileSync(path.join(out,'source-manifest.json'),JSON.stringify({sourceFingerprint:sha(Buffer.from(JSON.stringify(sources))),sources,sealedInput:report.sealedInput},null,2));
 console.log(JSON.stringify({out,cases:cases.map(c=>({kind:c.kind,first:c.firstCounts,after:c.after,deltas:c.deltas})),sourceCount:sources.length,oracleSha256:report.oracleSha256}));
})().catch(error=>{fs.writeFileSync(path.join(out,'execution-failure.json'),JSON.stringify({error:error.stack,cases},null,2));console.error(error.stack);process.exitCode=2;});
