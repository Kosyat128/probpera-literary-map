const fs=require('node:fs'),assert=require('node:assert/strict');
const report=JSON.parse(fs.readFileSync(process.argv[2],'utf8')),checks=[];
assert.equal(report.results.length,4);
for(const row of report.results){
 assert.deepEqual(row.strictBeforeTrigger,{privateCandidate:true,actualTwoPassTranslation:true,allBodiesAcknowledged:true,actualApprovalCoreReached:true});
 const pass=row.kind==='target'?row.specificRefusal===true&&!row.promoted:row.promoted&&row.candidate===row.publishedEnglish&&row.missingAfterApply.length===0;
 checks.push({name:row.name,category:row.kind,pass});
}
console.log(JSON.stringify({classification:'STRICT_PARAMETERS_SAME_CONTRACT_ORACLE',checks}));
process.exitCode=checks.every(row=>row.pass)?0:1;
