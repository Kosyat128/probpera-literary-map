// PREPARED ONLY. Execution requires an explicit later root release and --execute-controlled.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const here=__dirname,sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const args=process.argv.slice(2),get=name=>{const index=args.indexOf(name);return index<0?null:args[index+1];};
if(!args.includes('--execute-controlled')) {
  console.log(JSON.stringify({status:'PREPARED_NOT_EXECUTED',controlledScenarios:0,notice:'Wait for explicit root release. No TypeScript, SDK, app module, DB or provider was loaded.'}));
  process.exit(0);
}
const dependencyRoot=path.resolve(get('--dependency-root')||''),manifestPath=path.resolve(get('--manifest')||path.join(here,'manifest.json'));
const outputArg=get('--output');if(!get('--dependency-root')||!outputArg)throw Error('Require --dependency-root and fresh --output');
const output=path.resolve(outputArg),work=path.resolve(here,'..');
if(!output.startsWith(work+path.sep)||fs.existsSync(output))throw Error('Output must be fresh and inside parent work');
const manifest=JSON.parse(fs.readFileSync(manifestPath)),sourceRoot=path.resolve(get('--source-root')||path.join(here,'capture'));
const bindings=new Map(manifest.files.map(row=>[row.file,row]));
const oraclePath=path.join(here,'same-contract.cjs');
if(sha(fs.readFileSync(oraclePath))!==manifest.oracleSha256)throw Error('Changed independent oracle');
for(const row of manifest.files) {
  const bytes=fs.readFileSync(path.join(sourceRoot,row.file));
  if(sha(bytes)!==row.sha256||bytes.length!==row.bytes)throw Error('Source capture drift '+row.file);
}
const nativeRequire=createRequire(path.join(dependencyRoot,'package.json'));
for(const row of manifest.packages)if(sha(fs.readFileSync(path.join(dependencyRoot,'node_modules',row.name,'package.json')))!==row.sha256)throw Error('Installed package identity changed '+row.name);
const ts=nativeRequire('typescript'),{createClient}=nativeRequire('@supabase/supabase-js');
const redirectErrors=nativeRequire('next/dist/client/components/redirect-error'),redirectInfo=nativeRequire('next/dist/client/components/redirect');
const {evaluate}=require(oraclePath),actorId='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',entityId='bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const clone=value=>structuredClone(value),clock=()=>new Date().toISOString();
const scenarios=[
  {name:'invalid nonnumeric address',kind:'invalid',id:'bad',invalidBeforeRead:true},
  {name:'invalid zero address',kind:'invalid',id:'0',invalidBeforeRead:true},
  {name:'missing event address',kind:'invalid',id:'999'},
  {name:'bigint overflow address',kind:'invalid',id:'9223372036854775808'},
  {name:'no staff session',kind:'invalid',id:'42',noSession:true,invalidBeforeRead:true},
  {name:'read permission refusal',kind:'invalid',id:'42',readDenied:true},
  {name:'direct deployed retry',kind:'terminal',initialStatus:'deployed'},
  {name:'known dispatched operation is still active',kind:'active',initialStatus:'dispatched'},
  {name:'failed source completes after the addressed read',kind:'race',initialStatus:'failed'},
  {name:'accepted external launch has an unconfirmed mark then retry',kind:'mark-unknown',initialStatus:'failed'},
  {name:'known failed retry positive control',kind:'failed-control',initialStatus:'failed'},
  {name:'two deliberate fresh full releases remain separate',kind:'full-control',initialStatus:'deployed'},
  {name:'two different same-entity failed events remain separate',kind:'distinct-control',initialStatus:'failed'},
];
function runtime(scenario) {
  const canonical={ru:{title:'Original source',body:'Exact manually authored Russian',sources:['https://source.invalid/one']},
    en:{title:'Manual English',body:'Keep manual text',method:'human-translation'},rights:{owner:'Synthetic editor',license:'permission'}};
  const sourceEvent={id:'42',actor_id:actorId,entity_type:'article',entity_id:entityId,reason:'article.updated',status:scenario.initialStatus||'failed',
    metadata:{authored:clone(canonical)},attempt_count:1,provider:scenario.initialStatus==='dispatched'?'deploy-hook':null,
    requested_at:clock(),dispatched_at:scenario.initialStatus==='dispatched'?clock():null,deployed_at:scenario.initialStatus==='deployed'?clock():null};
  const events=new Map([['42',sourceEvent]]);if(scenario.kind==='distinct-control')events.set('43',{...clone(sourceEvent),id:'43'});
  const originalIntents=[...events.values()].map(({id,actor_id,entity_type,entity_id,reason,metadata})=>({id,actor_id,entity_type,entity_id,reason,metadata:clone(metadata)}));
  const trace={scenario:clone(scenario),canonicalBefore:clone(canonical),canonicalAfter:null,commands:[],wire:[],rpc:[],external:[],audit:[],editorialWrites:[],
    translationCalls:[],transitions:[],protocolErrors:[],appended:[],sourceGraph:[],markFailures:0,firstAcceptedOutboxId:null,authCalls:0,serverClientCalls:0,revalidation:[]};
  let nextId=1001,lastEnqueued=null,raceInjected=false;
  const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json'}});
  const dbFetch=async (input,init={})=>{
    const url=new URL(String(input)),method=init.method||'GET',body=init.body?JSON.parse(String(init.body)):null;
    const row={method,pathname:url.pathname,search:url.search,body:clone(body),response:null};trace.wire.push(row);
    if(url.origin!=='https://m04-publication.invalid') {trace.protocolErrors.push('Uncontrolled SDK origin');throw Error('Uncontrolled SDK origin');}
    if(url.pathname==='/rest/v1/public_build_outbox'&&method==='GET') {
      const value=url.searchParams.get('id');if(!value?.startsWith('eq.'))throw Error('Missing exact addressed ID');
      const id=value.slice(3);
      if(!/^[1-9]\d*$/.test(id)||BigInt(id)>9223372036854775807n) {row.response={code:'22003'};return json({code:'22003',message:'PRIVATE_M04_TRANSPORT_DETAIL bigint range'},400);}
      if(scenario.readDenied) {row.response={code:'42501'};return json({code:'42501',message:'PRIVATE_M04_TRANSPORT_DETAIL denied'},403);}
      const event=events.get(id),data=event?[{id:event.id,entity_type:event.entity_type,entity_id:event.entity_id,reason:event.reason,status:event.status}]:[];
      row.response=clone(data);
      if(scenario.kind==='race'&&event&&!raceInjected) {
        raceInjected=true;trace.transitions.push({kind:'after-read-before-enqueue',id,from:event.status,to:'deployed',at:clock()});event.status='deployed';event.deployed_at=clock();
      }
      return json(data);
    }
    if(url.pathname.startsWith('/rest/v1/rpc/')&&method==='POST') {
      const name=url.pathname.slice('/rest/v1/rpc/'.length);trace.rpc.push({name,args:clone(body)});
      if(name==='enqueue_public_build_request') {
        // Explicit contract boundary only: the actual captured SQL always appends an event.
        // No status/retry/idempotency guard is implemented by this transport.
        const event={id:String(nextId++),actor_id:actorId,entity_type:body.p_entity_type,entity_id:body.p_entity_id,reason:body.p_reason,
          status:'requested',metadata:clone(body.p_metadata),attempt_count:0,provider:null,requested_at:clock(),dispatched_at:null,deployed_at:null};
        events.set(event.id,event);lastEnqueued=event.id;trace.appended.push(event);row.response=Number(event.id);return json(Number(event.id));
      }
      if(name==='mark_public_build_dispatched') {
        if(scenario.kind==='mark-unknown'&&trace.commands.length===0) {trace.markFailures++;row.response={code:'57014'};return json({code:'57014',message:'PRIVATE_M04_TRANSPORT_DETAIL mark unavailable'},503);}
        const event=events.get(String(body.p_outbox_id)),found=Boolean(event&&['requested','dispatched','failed'].includes(event.status));
        if(found){event.status='dispatched';event.provider=String(body.p_provider).trim().slice(0,80);event.attempt_count++;event.dispatched_at=clock();}
        row.response=found;return json(found);
      }
      trace.protocolErrors.push('Uncontrolled RPC '+name);throw Error('Uncontrolled RPC '+name);
    }
    if(url.pathname==='/rest/v1/admin_audit_log'&&method==='POST'){trace.audit.push(clone(body));row.response=null;return new Response(null,{status:201});}
    trace.editorialWrites.push({method,path:url.pathname,body:clone(body)});trace.protocolErrors.push('Uncontrolled table request');throw Error('Uncontrolled table request');
  };
  const externalFetch=async (input,init={})=>{
    const url=new URL(String(input)),body=init.body?JSON.parse(String(init.body)):null;
    if(url.origin!=='https://api.cloudflare.com'||url.pathname!=='/fixture/no-network-deploy-hook'||init.method!=='POST') {
      trace.protocolErrors.push('Uncontrolled external target');throw Error('Uncontrolled external target');
    }
    trace.external.push({origin:url.origin,pathname:url.pathname,method:init.method,body,controlledAccepted:true,at:clock(),precedingEnqueuedOutboxId:lastEnqueued});
    if(!trace.firstAcceptedOutboxId)trace.firstAcceptedOutboxId=lastEnqueued;
    return json({accepted:true});
  };
  const sdk=createClient('https://m04-publication.invalid','synthetic-local-public-fixture-key',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},db:{retry:false},global:{fetch:dbFetch}});
  const env={deployHookUrl:'https://api.cloudflare.com/fixture/no-network-deploy-hook',deployHookToken:'',githubDeployToken:'',githubRepository:'',githubDeployWorkflow:'',githubDeployRef:''};
  const mocks={
    '@/lib/auth':{requireStaff:async()=>{trace.authCalls++;return scenario.noSession?null:{user:{id:actorId},role:'owner'};}},
    '@/lib/supabase/server':{createServerSupabaseClient:async()=>{trace.serverClientCalls++;return sdk;}},
    '@/lib/auto-translate-published-article-premium':{ensurePublishedArticlePremiumEnglish:async value=>{trace.translationCalls.push({actorId:value.actorId,articleId:value.articleId,hasSupabase:Boolean(value.supabase)});throw Error('Retry must not translate article');}},
    '@/lib/env':{adminEnv:env},'next/cache':{revalidatePath:value=>trace.revalidation.push(value)},
  };
  const loaded=new Map();
  function load(file) {
    if(loaded.has(file))return loaded.get(file).exports;
    const entry=bindings.get(file);if(!entry||entry.role!=='actual-runtime-source')throw Error('Uncaptured application source '+file);
    const bytes=fs.readFileSync(path.join(sourceRoot,file));if(sha(bytes)!==entry.sha256)throw Error('Source changed while executing '+file);
    trace.sourceGraph.push({file,bytes:bytes.length,sha256:sha(bytes)});
    const compiled=ts.transpileModule(bytes.toString(),{fileName:file,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText;
    const module={exports:{}};loaded.set(file,module);
    const require=name=>{
      if(Object.hasOwn(mocks,name))return mocks[name];
      let target=name.startsWith('@/')?'apps/admin/'+name.slice(2):name.startsWith('.')?path.posix.normalize(path.posix.join(path.posix.dirname(file),name)):null;
      if(target){for(const suffix of ['','.ts','.tsx','/index.ts'])if(bindings.get(target+suffix)?.role==='actual-runtime-source')return load(target+suffix);throw Error('Uncaptured local dependency '+name+' from '+file);}
      return nativeRequire(name);
    };
    new Function('require','module','exports','fetch',compiled)(require,module,module.exports,externalFetch);return module.exports;
  }
  const actions=load('apps/admin/app/(dashboard)/publication/actions.ts');
  async function run(type='retry',id=scenario.id||'42') {
    const form=new FormData();form.set('outbox_id',id);form.set('catalog_q','fixture %_');form.set('catalog_status','failed');form.set('catalog_page','3');
    const command={type,form:Object.fromEntries(form),externalBefore:trace.external.length,rpcBefore:trace.rpc.length,redirect:null,error:null};
    try{await actions[type==='full'?'requestFullPublicBuildAction':'retryPublicationAction'](form);command.error={name:'MissingRedirect',message:'Action returned without a native redirect'};}
    catch(error){if(redirectErrors.isRedirectError(error))command.redirect=redirectInfo.getURLFromRedirectError(error);else command.error={name:error?.name||typeof error,message:String(error?.message||error)};}
    command.externalAfter=trace.external.length;command.rpcAfter=trace.rpc.length;trace.commands.push(command);
  }
  async function execute() {
    if(scenario.kind==='full-control'){await run('full');await run('full');}
    else if(scenario.kind==='distinct-control'){await run('retry','42');await run('retry','43');}
    else if(scenario.kind==='mark-unknown'){await run();if(!trace.firstAcceptedOutboxId)throw Error('First accepted outbox was not observed');trace.firstUnconfirmedEvent=clone(events.get(trace.firstAcceptedOutboxId));await run('retry',trace.firstAcceptedOutboxId);}
    else await run();
    trace.canonicalAfter=clone(canonical);
    trace.originalIntentPreserved=originalIntents.every(original=>{const event=events.get(original.id);return JSON.stringify(original)===JSON.stringify({id:event.id,actor_id:event.actor_id,entity_type:event.entity_type,entity_id:event.entity_id,reason:event.reason,metadata:event.metadata});});
    trace.finalEvents=clone([...events.values()]);trace.appended=clone(trace.appended);return trace;
  }
  return {execute};
}
(async()=>{
  fs.mkdirSync(output,{recursive:false});const traces=[],checks=[],executionErrors=[];
  for(const scenario of scenarios) {
    try{const trace=await runtime(scenario).execute();traces.push(trace);checks.push(...evaluate(trace).map(row=>({scenario:scenario.name,...row})));for(const command of trace.commands)if(command.error)executionErrors.push({scenario:scenario.name,stage:'action',...command.error});}
    catch(error){executionErrors.push({scenario:scenario.name,name:error?.name,message:String(error?.stack||error)});}
  }
  const role=name=>({total:checks.filter(row=>row.role===name).length,failed:checks.filter(row=>row.role===name&&!row.pass).length});
  const report={checkedAt:clock(),classification:'ACTUAL_M04_ACTION_HELPER_SDK_CONTROLLED_BEFORE_RESULT_NOT_NATIVE_DB_BROWSER_OR_ACCEPTANCE',
    manifestSha256:sha(fs.readFileSync(manifestPath)),oracleSha256:manifest.oracleSha256,sourceRoot,dependencyRoot,scenarios:scenarios.length,traces,checks,executionErrors,
    summary:{checks:checks.length,passed:checks.filter(row=>row.pass).length,failed:checks.filter(row=>!row.pass).length,target:role('target'),control:role('control'),preservation:role('preservation')},
    atomicReplay:{status:'NOT_RUN_PROTOCOL_ABSENT',detail:'Current form/API has no supported retry operationId/expected source event version. No invented field is sent; same-operationId replay acceptance requires a separately designed real native protocol.'},
    limitations:manifest.limitations,realNetworkRequests:0,realDatabaseConnections:0,realProviderCalls:0};
  fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({output,summary:report.summary,executionErrors:executionErrors.length,atomicReplay:report.atomicReplay.status}));
  process.exitCode=executionErrors.length?2:report.summary.failed?1:0;
})().catch(error=>{console.error(error.stack||error);process.exitCode=2;});
