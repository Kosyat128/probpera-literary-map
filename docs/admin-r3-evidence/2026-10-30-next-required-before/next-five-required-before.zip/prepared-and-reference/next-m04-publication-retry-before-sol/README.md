# Prepared M04 publication retry BEFORE

PREPARED, NOT EXECUTED. Wait for root release after the current validation seal.
No scenario, compiler, SDK module, database, browser or provider has run during preparation.

The producer will execute the captured actual retry/full-release actions,
requestPublicBuild, public-build, outbound URL guard, navigation and catalog
helpers. Installed Supabase SDK/Next/Zod/TypeScript remain actual. Only Auth,
SDK transport and the external HTTP boundary are controlled. Every local
application dependency must exist in the capture; there is no fallback to the
current application checkout. Source and installed package identities are
verified before the future run. The independent oracle observes real calls;
the transport does not implement the desired retry guard.

Targets: direct deployed retry, a known active dispatched event, completion
after the addressed read, and an accepted external launch whose mark failed
followed by an explicitly addressed retry of the actual appended event.
Controls: invalid/missing/overflow/denied addresses, a legitimate failed retry,
two deliberate fresh full releases and two different events for the same entity.
Every scenario preserves synthetic canonical RU/EN/rights and original event
intent. These tests do not require global event deduplication: trigger events
and separate explicit release intentions remain separate.

The current SQL enqueue routine deliberately appends an explicit event and
coexists with row triggers. Its signature has no retry operationId/CAS binding
to an older event. Consequently the same-operationId half of M04-T16 is
explicitly NOT_RUN_PROTOCOL_ABSENT. No invented form field or mock guard is
used to manufacture that proof. The controlled after-read transition is a
boundary fault injection, not a real PostgreSQL concurrency test.

After release, an explicit invocation would be:

    node before.cjs --execute-controlled --dependency-root <installed-repo> --output <fresh-parent-work-directory>

No command was executed. A target failing later would be a scoped BEFORE
observation, not acceptance of the eventual fix. Real DB/RLS/concurrency and
authenticated browser publication/delivery remain required separately.

Do not weaken the existing M04-T17 validation/capability fallback, coalesce
different events by entityId, disable row triggers, translate manual EN or
rewrite authored source/rights/normalizers. No key setup, commit, push, deploy
or live external launch is involved.
