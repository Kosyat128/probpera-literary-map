# NEXT preparation only

No controlled scenario or database connection has run. Only `node --check` and the default preparation branch were used. Do not call this a reproduced failure yet.

After the current site-copy whole verification is sealed, the root can run:

```powershell
node before.cjs --execute-controlled --source-root <sealed-current-or-exact-captured-source> --snapshot <root-source-before.json> --output <fresh-parent-work-dir>
node same-contract.cjs <fresh-parent-work-dir>/report.json
```

Use a sanitized test environment and installed existing dependencies. The snapshot must have the root's `validationSourceSha256` and complete `files` bindings. Every executed/read application or fixture dependency must match that snapshot. The producer captures exact source bytes, raw SDK requests, provider pass records, retained bodies, original/final operation snapshots, ordinary helper results, original budget inputs/snapshots, before/after canonical values and all BEGIN/reservation/response/finish/provider deltas. It never asserts that a defect must occur.

The new trigger is deliberately different from the existing unchanged a63 oracle: a valid translator body is acknowledged; review and final repair are both delivered but rejected by the actual original validator; the original default budget has not expired. Then the same ordinary unaddressed helper is called once more. Writer/library/country are proposed regression targets; site-copy is a safety control. The new independent oracle checks zero added translation/provider/BEGIN calls and exact canonical/publication preservation. No old source or oracle is reconstructed from CURRENT.

Provider invalidity is controlled only at the existing synthetic response boundary. Actual builders, models, source hashes, validators, premium parser, budgets, coordinator and installed SDK execute. First translation validity and both editorial failures are independently checked through the original production validator. Writer/book/country default1/4/300000 and site-copy1/4/45000 are measured unchanged. No caller receives paid partial-continuation authority.

M07-T11 requires bounded shared accounting, no calls after stop/deadline and truthful incomplete state. It does not itself require automatic or paid partial continuation. M07-T13 separately requires an explicit failed item/version command distinct from scan continuation; the current selection/action is article-specific. A valid retained partial body with unknown delivery, cancellation or an expired original deadline remains held. A fresh UUID is not proof that the original request did not happen.

This package does not implement or prove native SQL, operator UI/admin-E2E, service-role leases, a new retry budget or a deadline reset. The root's independent placeholder producer is a different NEXT candidate and is not duplicated here.
