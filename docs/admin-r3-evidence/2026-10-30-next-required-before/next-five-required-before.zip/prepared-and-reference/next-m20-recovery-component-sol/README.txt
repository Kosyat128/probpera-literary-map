PREPARED ONLY. Not executed, compiled, browser-started or syntax-checked.

Actual runner mechanism: installed esbuild + Playwright with a fresh headless Chrome context, using actual Next-compiled React/ReactDOM and real React.act. This follows the existing maintained article-operation-browser.mjs mechanism. It imports current RecoveryController, EditorRecoveryPanel and autosave helpers unchanged. Only declared server actions are deferred synthetic boundaries. No hook/helper clone decides the result.

Future execution ONLY AFTER ROOT RELEASE, with the exact completed frozen snapshot and a new workspace output directory:
node before.mjs --execute-controlled --source-root <absolute sealed source root> --snapshot <root source-before.json> --output <fresh existing-work-parent/new-output>
node same-contract.cjs <new-output/report.json>

Eight scenarios: two targets M20-T07 resolved lookup ok:false and M20-T10 reachable explicit delete button returning ok:true/deleted:false. Controls: rejected lookup, confirmed empty lookup, exact deleted:true, rejected delete, late old-locator failure after new-locator successful empty read. A further M20-T08 scope control delays old explicit discard, switches the actual locator, loads a new recovery, then confirms the old deletion; it checks the new card and exact new ID/session/sequence/hash through another real button event. That second action stays pending. No failure is assumed before execution. All preserve authored parent input, forbid unsolicited restore and check page errors.

Both actual editor caller sources are captured and checked against the frozen snapshot, including current savedAfterSubmit=false. Automatic canonical-cleanup/receipt authority is NOT a target. The parent entry uses the same false prop. Full editors, actual Auth, database, canonical commit and full admin E2E are not exercised or claimed.

The explicit execution path bundles only after the release flag, uses an ephemeral 127.0.0.1 server and fresh temporary browser context, blocks external requests, awaits browser/server closure and writes cleanup. No real provider/storage/production writes occur. Original NEXT producers and the initial acceptance inventory are preserved.
