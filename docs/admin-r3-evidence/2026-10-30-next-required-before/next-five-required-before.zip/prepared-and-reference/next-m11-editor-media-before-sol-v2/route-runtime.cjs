// Loaded only by the explicit future execution path. Never run during preparation.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function seedRows(){return Array.from({length:137},(_,offset)=>{
  const index=offset+1,label=String(index).padStart(3,'0');return {
    id:`00000000-0000-4000-8000-${String(index).padStart(12,'0')}`,bucket:'editorial-media',object_path:`fixture/asset-${label}.svg`,original_name:`original-${label}.png`,
    alt_text:`Asset ${label}`,caption:`Caption ${label}`,collection_name:`Collection ${label}`,creator:'Synthetic author',source_url:'https://source.invalid/one',
    license_name:'permission',license_url:'https://source.invalid/permission',width:800,height:600,created_at:new Date(Date.UTC(2026,0,1,0,0,137-index)).toISOString(),deleted_at:null,
  };
}).map((row,index)=>index===136?{...row,original_name:'filename-needle-137.png'}:index===135?{...row,caption:'caption-needle-136'}:index===134?{...row,collection_name:'collection-needle-135'}:index===133?{...row,alt_text:'literal %_\\ item'}:index===132?{...row,alt_text:'literal XX item'}:row);}
function like(pattern){let result='';for(let i=0;i<pattern.length;i++){const c=pattern[i];if(c==='\\'&&i+1<pattern.length)result+=pattern[++i].replace(/[.*+?^${}()|[\]\\]/g,'\\$&');else if(c==='%')result+='.*';else if(c==='_')result+='.';else result+=c.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}return new RegExp('^'+result+'$','iu');}
function createMediaRouteRuntime({dependencyRoot,sourceRoot,manifest,empty=false}) {
  const requireNative=createRequire(path.join(dependencyRoot,'package.json')),ts=requireNative('typescript'),{createClient}=requireNative('@supabase/supabase-js');
  const rows=empty?[]:seedRows(),wire=[],protocolErrors=[],sourceGraph=[];
  const sdk=createClient('https://m11-media.invalid','synthetic-local-public-fixture-key',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},db:{retry:false},global:{fetch:async(input,init={})=>{
    const url=new URL(String(input)),entry={method:init.method||'GET',pathname:url.pathname,query:[...url.searchParams],responseIds:[]};wire.push(entry);
    if(url.origin!=='https://m11-media.invalid'||url.pathname!=='/rest/v1/media_assets'||entry.method!=='GET'){protocolErrors.push(entry);throw Error('Uncontrolled SDK transport');}
    let found=rows.slice();
    for(const [key,value]of url.searchParams){
      if(['select','order','limit','offset'].includes(key))continue;
      if(key==='deleted_at'&&value==='is.null'){found=found.filter(row=>row.deleted_at===null);continue;}
      if(['alt_text','caption','collection_name','original_name'].includes(key)&&value.startsWith('ilike.')){const re=like(value.slice(6));found=found.filter(row=>re.test(row[key]||''));continue;}
      protocolErrors.push({unknownFilter:key,value});throw Error('Unsupported actual query filter; adapt only after reading its real protocol');
    }
    const order=url.searchParams.get('order')||'';
    if(order)found.sort((a,b)=>{for(const clause of order.split(',')){const [key,direction]=clause.split('.');const compare=String(a[key]).localeCompare(String(b[key]));if(compare)return direction==='desc'?-compare:compare;}return 0;});
    const total=found.length,offset=Number(url.searchParams.get('offset')||0),limit=Number(url.searchParams.get('limit')||1000);
    if(!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(limit)||limit<0||limit>1000)throw Error('Unsafe fixture range');
    found=found.slice(offset,offset+limit);entry.responseIds=found.map(row=>row.id);
    const columns=(url.searchParams.get('select')||'*').split(',');
    if(!columns.includes('*'))found=found.map(row=>Object.fromEntries(columns.map(key=>[key,row[key]])));
    return new Response(JSON.stringify(found),{status:200,headers:{'content-type':'application/json','content-range':`${offset}-${Math.max(offset,offset+found.length-1)}/${total}`}});
  }}});
  const files=new Map(manifest.files.map(row=>[row.file,row])),loaded=new Map();
  const mocks={'@/lib/auth':{requireStaff:async()=>({user:{id:'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'},role:'owner'})},'@/lib/supabase/server':{createServerSupabaseClient:async()=>sdk}};
  function load(file){if(loaded.has(file))return loaded.get(file).exports;const expected=files.get(file);if(!expected||expected.role!=='actual-runtime-source')throw Error('Uncaptured local module '+file);
    const bytes=fs.readFileSync(path.join(sourceRoot,file));if(hash(bytes)!==expected.sha256)throw Error('Source drift '+file);sourceGraph.push({file,sha256:hash(bytes),bytes:bytes.length});
    const code=ts.transpileModule(bytes.toString(),{fileName:file,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,esModuleInterop:true}}).outputText;
    const module={exports:{}};loaded.set(file,module);const require=name=>{if(Object.hasOwn(mocks,name))return mocks[name];if(name.startsWith('@/')||name.startsWith('.'))throw Error('Unexpected uncaptured server import '+name);return requireNative(name);};
    new Function('require','module','exports',code)(require,module,module.exports);return module.exports;
  }
  const GET=load('apps/admin/app/api/media/assets/route.ts').GET;
  return {wire,protocolErrors,sourceGraph,rows,handle:request=>GET(request)};
}
module.exports={createMediaRouteRuntime,seedRows};
