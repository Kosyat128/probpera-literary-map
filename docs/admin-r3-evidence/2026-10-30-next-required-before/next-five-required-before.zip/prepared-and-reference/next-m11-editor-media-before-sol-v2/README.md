# Prepared actual EditorMediaDialog BEFORE

PREPARED, NOT EXECUTED. No syntax check, TypeScript transpilation, esbuild,
browser, API, SDK, database, provider or scenario has run during preparation.
Wait for explicit root release after the current source validation seal.

This bounded producer mounts the captured actual EditorMediaDialog and its
existing useEditorDialogFocus in installed Next React/Chrome. The local API
handler executes the captured actual GET route through installed Supabase SDK
serialization and real Request/Response objects. Only Auth, PostgREST storage
and external HTTP/image responses are controlled. All137 synthetic permitted
rows have actual original_name/alt/caption/collection fields; the transport
obeys the actual received query, ordering and limit. It does not add missing
pagination or search in the product.

Prepared12 scenarios cover unsearched61/137 reach and exact selection callback,
first-card and alt positives, original filename/caption/collection, literal
percent/underscore/backslash, malformed HTTP200 versus confirmedempty, native
focus/Tab/Escape/return and a deferred old-query versus new-query control.
Page windows must remain60-or-smaller: loading all137 at once does not satisfy
the pagination oracle. No new focus hook replaces the existing production hook.

The wrapper records the actual onSelectAsset callback. It does not claim full
TipTap insertion, server media-reference CAS or persisted Article/DB proof.
The HTTP200 corruption is an explicit boundary fault after the actual route,
not a claim that native PostgREST generated that malformed reply.

M11-T11 real upload/queue completion and refresh is deliberately NOT_RUN in this
minimal slice. useEditorMediaWorkflow/editor-image-upload are captured references,
not executed substitutes. No invented refresh prop/event or synthetic uploader
is used to fake that acceptance. Full actual upload workflow and native DB/RLS
remain separate later checks; existing focus and late-query controls are real
component/browser behaviors within the scoped harness.

After release only:

    node browser-before.mjs --execute-controlled --dependency-root <installed-repo> --output <fresh-parent-work-directory>

Capture-only source mapping is strict, with no fallback to current application
files. Existing installed dependencies are used; nothing is installed or fetched.
Every unexpected transport/import is an execution/control failure. A future
changed API query protocol requires explicit faithful transport adaptation;
the current fixture does not silently manufacture a passing new RPC/filter.

No production/browser/DB/RLS/full-M11 acceptance or defect reproduction is
claimed before actual execution. No maintained source, author content,
normalizer, key, commit, push or deployment is changed by this preparation.
