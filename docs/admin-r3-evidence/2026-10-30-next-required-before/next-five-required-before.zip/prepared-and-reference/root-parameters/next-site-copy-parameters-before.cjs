// Parent-only genuine BEFORE producer. Run only after the current stage freezes.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../probpera-literary-map');
const sourceRoot=path.resolve(process.env.NEXT_SITE_COPY_PARAMETER_SOURCE_ROOT||repo);
const snapshotFile=process.env.NEXT_SITE_COPY_PARAMETER_SNAPSHOT;
assert.ok(snapshotFile,'An actual frozen source-before.json is required');
const snapshot=JSON.parse(fs.readFileSync(snapshotFile,'utf8')),frozen=new Map(snapshot.files.map(row=>[row.path,row]));
const out=process.env.NEXT_SITE_COPY_PARAMETER_OUTPUT;
assert.ok(out,'An explicit fresh output directory is required');
assert.equal(fs.existsSync(out),false,'Never replace an earlier BEFORE');fs.mkdirSync(out,{recursive:true});
process.env.SITE_COPY_ADMISSION_REPO=repo;process.env.SITE_COPY_ADMISSION_SOURCE_ROOT=sourceRoot;
process.env.SITE_COPY_ADMISSION_OUTPUT_ROOT=path.join(out,'actual-runtime');
const runtime=require(path.join(sourceRoot,'apps/admin/lib/fixtures/site-copy-admission-runtime.cjs'));
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const dictionaryFile='src/i18n/InterfaceLanguage.tsx',applicationFile='src/App.tsx';
const catalogFile='apps/admin/catalog-assets/interface-copy-catalog.json';
const catalogText=fs.readFileSync(path.join(sourceRoot,catalogFile),'utf8');
const dictionary=fs.readFileSync(path.join(sourceRoot,dictionaryFile),'utf8');
const application=fs.readFileSync(path.join(sourceRoot,applicationFile),'utf8');
const count='{count} карточка уже прошла публикационную проверку по открытым авторитетным источникам';
const queued='Ещё {count} запись остаётся в редакционной очереди; автоматически собранные черновики не публикуются до ручной проверки';
assert.ok(dictionary.includes(JSON.stringify(queued))&&dictionary.includes(JSON.stringify(count)));
assert.ok(application.includes(JSON.stringify(queued))&&application.includes(JSON.stringify(count)));
assert.ok(application.includes('.replace("{count}", number(readyBiographyCount))'));
assert.ok(application.includes('.replace("{count}", number(editorialQueueCount))'));
const results=[];
(async()=>{
 for(const input of [{name:'Real publication count variable survives a machine candidate',russian:count,english:'Writer profile checked',required:['count']},
  {name:'Real editorial queue count variable survives a machine candidate',russian:queued,english:'Records await review',required:['count']},
  {name:'Plain copy has no invented required variables',russian:'Поиск',english:'Search',required:[]}]){
  const view=runtime.createSiteCopyAdmissionRuntime({onProvider:async({value})=>{
    const body=JSON.parse(value.response);body.items=body.items.map(item=>({...item,text:input.english}));value.response=JSON.stringify(body);
  }});
  // Actual managed-catalog parser/merge execute; only asset transport is local.
  view.mocks['./admin-catalog-assets']={readAdminCatalogText:async name=>{
    assert.equal(name,'interface-copy-catalog.json');return catalogText;
  }};
  const catalog=view.loaded.load('apps/admin/lib/site-copy-catalog.ts');
  view.mocks['@/lib/site-copy-catalog']=catalog;view.mocks['./site-copy-catalog']=catalog;
  const definitions=await catalog.loadAllSiteCopyCatalog();
  const row=view.snapshot(),key='interface.'+input.russian;
  assert.ok(definitions.some(definition=>definition.key===key),'The case must use an actual managed key');
  row.settings.siteCopy.ru={[key]:input.russian};delete row.settings.siteCopy.en[key];delete row.settings.premiumTranslation.siteCopyEn[key];view.setRow(row);
  const before=view.stateSnapshot();const result=await view.helper();const draft=view.candidate();
  assert.deepEqual(view.snapshot(),before.canonical);assert.equal(view.builds.length,0);
  const candidate=draft?.payload?.items?.find(item=>item.key===key)?.text??null;
  const missing=input.required.filter(name=>!candidate?.includes('{'+name+'}'));
  const review=draft?await view.loadReview():null;
  const redirect=draft?await view.reviewAction(view.reviewForm(true)):null;
  const publicAfter=view.publicView(),publishedEnglish=publicAfter.en[key]??null;
  const promoted=view.promotions.length>0;
  const missingAfterApply=input.required.filter(name=>!publishedEnglish?.includes('{'+name+'}'));
  const pass=input.required.length?!promoted||missingAfterApply.length===0:promoted&&publishedEnglish===input.english;
  results.push({name:input.name,status:pass?'PASS':'FAIL',key,source:input.russian,required:input.required,missing,
    result,candidate,review,redirect,promoted,publishedEnglish,missingAfterApply,
    providerCalls:view.requests.length,wire:view.wire,builds:view.builds,
    canonicalBefore:before.canonical,canonicalAfter:view.snapshot(),helperSourceAndPublicationUnchanged:true});
 }
 const bindings=runtime.sourceBindings();
 const references=[dictionaryFile,applicationFile,catalogFile].map(file=>{const bytes=fs.readFileSync(path.join(sourceRoot,file));const dest=path.join(out,'reference-sources',file);
  fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,bytes);return{file,bytes:bytes.length,sha256:sha(bytes),
   role:file===catalogFile?'Actual managed catalog input through original parser/merge':'Production variable/caller source reference; source-only context, not browser execution'};});
 for(const row of [...bindings,...references]){
  assert.equal(row.sha256,frozen.get(row.file)?.sha256,'Executed/reference source differs from the actual frozen snapshot: '+row.file);
  assert.equal(row.bytes,frozen.get(row.file)?.size,'Frozen source size differs: '+row.file);
 }
 const report={classification:'GENUINE_FROZEN_HELPER_AND_HUMAN_REVIEW_BEFORE_REAL_PARAMETERS_CONTROLLED_SDK_NOT_NATIVE_OR_BROWSER',
  producedAt:new Date().toISOString(),sealedSourceFingerprint:snapshot.validationSourceSha256,
  oracle:'Incompatible real named variables must not pass the actual explicit human-approval action; plain text must still apply',
  producerSha256:sha(fs.readFileSync(__filename)),results,bindings,references,
  passed:results.filter(r=>r.status==='PASS').length,failed:results.filter(r=>r.status==='FAIL').length,
  limits:['Actual maintained helper, catalog parser/merge, human review/read/action, provider wrapper, journal and installed SDK execute; asset transport/provider/auth/RPC database are controlled synthetic boundaries.',
   'Only two proven count replacement sites are acceptance targets; page/total exists in the catalog but has no proven current caller and is not a runtime failure claim.',
   'The helper alone must leave canonical source/publication unchanged. Explicit approval is then attempted against the synthetic boundary and its real action outcome/public English is recorded; no real publication or provider runs.',
   'This is an independently versioned next-task oracle; existing a63/cf1 targets and assertions are unchanged.']};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({out,passed:report.passed,failed:report.failed,bindings:bindings.length,sha256:sha(fs.readFileSync(path.join(out,'report.json')))}));
 process.exitCode=report.failed?1:0;
})().catch(error=>{fs.writeFileSync(path.join(out,'execution-error.txt'),String(error.stack)+'\n');console.error(error);process.exitCode=2;});
