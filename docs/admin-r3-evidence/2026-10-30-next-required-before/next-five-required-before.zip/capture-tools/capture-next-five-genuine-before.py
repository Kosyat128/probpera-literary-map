"""Freeze genuine executed BEFORE bytes before any product edit. No tests/compression."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,shutil
work=Path(__file__).resolve().parent;repo=work.parent/'probpera-literary-map'
run=work/'next-controlled-before-execution-2026-10-30T14-33-42-330Z'
stage=work/'next-five-controlled-before-capsule-2026-10-30-b0b79'
assert not stage.exists();stage.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
snapshot_path=work/'site-copy-durable-final-validation-v3/source-before.json';snapshot=read(snapshot_path)
fp='b0b79b534a1f02c326b951224d2b82482840c5397acb1d99afe7930532efda38';assert snapshot['validationSourceSha256']==fp
frozen={r['path']:r for r in snapshot['files']};payload={};folded=set();sources={};packages=set()
def put(name,b):
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts and ':' not in name and '\\' not in name
 if name in payload:assert payload[name]['sha256']==sha(b);return
 assert name.casefold() not in folded;folded.add(name.casefold());target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 payload[name]={'path':name,'bytes':len(b),'sha256':sha(b)}
def tree(source,prefix):
 assert source.is_dir(),source
 for p in sorted(source.rglob('*')):
  relative=p.relative_to(source)
  if not p.is_file() or any(x in ['temp','tmp','node_modules','.git'] for x in relative.parts):continue
  assert not p.is_symlink();put(prefix+'/'+relative.as_posix(),p.read_bytes())
def relative_name(value):
 if not isinstance(value,str):return None
 value=value.replace('\\','/')
 if '/probpera-literary-map/' in value:value=value.split('/probpera-literary-map/',1)[1]
 return value if value in frozen else None
def collect(value,origin):
 if isinstance(value,list):
  for x in value:collect(x,origin)
 elif isinstance(value,dict):
  name=relative_name(value.get('file',value.get('path',value.get('module'))))
  expected=value.get('sha256')
  if name and isinstance(expected,str) and len(expected)==64:
   b=(repo/name).read_bytes();assert sha(b)==expected==frozen[name]['sha256'],(name,origin)
   assert len(b)==frozen[name].get('size',frozen[name].get('bytes'))
   put('physical-current-b0b79/'+name,b)
   row=sources.setdefault(name,{'file':name,'bytes':len(b),'sha256':sha(b),'observations':[]})
   row['observations'].append({'origin':origin,'role':value.get('role'),'roles':value.get('roles')})
  if isinstance(value.get('name'),str) and isinstance(value.get('version'),str) and (repo/'node_modules'/value['name']/'package.json').is_file():packages.add(value['name'])
  for x in value.values():collect(x,origin)
summary=read(run/'execution-summary.json');assert summary['sourceFingerprint']==fp
tree(run,'actual-execution-v1')
producer_dirs=['next-m20-recovery-component-sol','next-known-editorial-partial-sol','next-m04-publication-retry-before-sol','next-m04-publication-retry-before-sol-v2','next-m11-editor-media-before-sol']
for name in producer_dirs:tree(work/name,'prepared-and-reference/'+name)
for p in run.rglob('*.json'):
 if not any(x in ['temp','tmp'] for x in p.relative_to(run).parts):collect(read(p),'execution/'+p.relative_to(run).as_posix())
for name in producer_dirs:
 for p in (work/name).rglob('*.json'):
  if p.name in ['manifest.json','scope.json','prepared-plan.json','prepared-plan.v2.json','implementation-readiness.json']:collect(read(p),'prepared/'+str(p.relative_to(work)))
executed=[]
for record in summary['records']:
 text=record['script'].replace('\\','/');relative=text.split('/work/',1)[1];p=work/relative;b=p.read_bytes()
 assert sha(b)==record['scriptSha256'],('Executed script overwritten',relative)
 put('actual-executed-scripts/'+relative,b);executed.append({'file':relative,'sha256':sha(b),'commandId':record['id']})
 # Preserve known helper siblings of root-level producers/oracles without broad work-tree copies.
 if p.parent==work:
  for candidate in work.glob('next-site-copy-parameters*'):
   if candidate.is_file() and candidate.suffix in ['.cjs','.json','.md','.txt']:put('prepared-and-reference/root-parameters/'+candidate.name,candidate.read_bytes())
support=[]
for row in read(run/'known-partial/report.json')['historicalSupportArchives']:
 p=repo/row['file'];b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes']
 put('immutable-historical-support/'+row['file'],b);support.append(row)
for name in ['@supabase/supabase-js','@supabase/postgrest-js','typescript','next','zod','react','react-dom','esbuild','playwright','playwright-core']:
 if (repo/'node_modules'/name/'package.json').is_file():packages.add(name)
package_rows=[]
for name in sorted(packages):
 p=repo/'node_modules'/name/'package.json';b=p.read_bytes();d=json.loads(b);put('installed-package-identities/'+name+'/package.json',b);package_rows.append({'name':name,'version':d['version'],'bytes':len(b),'sha256':sha(b),'scope':'Installed package manifest identity, not entire vendor-tree integrity'})
for name in ['package.json','package-lock.json','apps/admin/package.json']:
 b=(repo/name).read_bytes();assert sha(b)==frozen[name]['sha256'];put('physical-current-b0b79/'+name,b)
 sources.setdefault(name,{'file':name,'bytes':len(b),'sha256':sha(b),'observations':[{'role':'frozen-package-manifest'}]})
put('provenance/source-before-b0b79.json',snapshot_path.read_bytes())
put('provenance/environment-policy.json',(json.dumps({'scope':'Exact actual CLI records preserve cwd,args,start/finish,exit,logsha and sanitized environment policy. No plaintext credential environment capture.','actualRecords':summary['records'],'credentialsInherited':False,'extraExecutionByCapture':0},ensure_ascii=False,indent=2)+'\n').encode())
inventory=sorted(sources.values(),key=lambda x:x['file']);put('SOURCE-CAPTURE.json',(json.dumps({'classification':'GENUINE_EXECUTED_AND_REFERENCE_SOURCES_WITH_ORIGINAL_ROLES_PHYSICALLY_CAPTURED_BEFORE_EDITS','globalFingerprint':fp,'sources':inventory,'sourceCount':len(inventory),'executedScripts':executed,'packages':package_rows,'historicalSupportArchives':support},ensure_ascii=False,indent=2)+'\n').encode())
put('README.md',b'Genuine five controlled BEFORE capsule staging, not acceptance. Original M11 malformed asset causes actual React parent crash, followed by observer inputValue failure/exit2; both facts retained without a setup-bug relabel. ObserverV2 count/null-only amendment is pending separately. All current executed/reference source bytes are copied before product edits and bound to b0b79. Synthetic Auth/SDK/external effects, native DB/browser scopes remain explicitly separate. Immutable historical support archives supply fixture prefixes only, not current application algorithms. No source reconstruction, test rerun, normalizer edit, real provider or compression occurred during capture.\n')
manifest={'classification':'GENUINE_FIVE_BEFORE_STAGING_SOURCE_CAPTURE_PASS_PENDING_M11_OBSERVER_V2_AND_FINAL_SEAL','globalFingerprint':fp,'sourceCount':len(inventory),'payloadCount':len(payload),'payload':sorted(payload.values(),key=lambda x:x['path'])}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();put('CAPTURE-MANIFEST.json',manifest_bytes)
for row in payload.values():
 b=(stage/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
for row in inventory:assert sha((repo/row['file']).read_bytes())==row['sha256']==sha((stage/'physical-current-b0b79'/row['file']).read_bytes())
receipt={'classification':'PHYSICAL_GENUINE_BEFORE_CAPTURE_VERIFIED_ROOT_RELEASE_READY_PENDING_M11_V2_APPEND_NOT_SEALED','capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':str(stage),'globalFingerprint':fp,'manifestSha256':sha(manifest_bytes),'payloadsIncludingCaptureManifest':len(payload),'physicalSources':len(inventory),'executedScripts':len(executed),'packages':len(package_rows),'allCopiedPayloadsReadback':True,'sourceDrift':0,'m11OriginalCrashAndObserverExit2Preserved':True,'m11ObserverV2':'PENDING_APPEND_SEPARATE_NEW_INPUTS_NO_REWRITE','compression':False,'testsExecutedByCapture':0}
target=work/'next-five-controlled-before-capture-receipt.json';assert not target.exists();target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({**receipt,'receiptSha256':sha(target.read_bytes())}))
