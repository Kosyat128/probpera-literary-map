"""Append genuine observerV2 host evidence, then seal BEFORE without executing code."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,shutil,zipfile
work=Path(__file__).resolve().parent;repo=work.parent/'probpera-literary-map'
stage=work/'next-five-controlled-before-capsule-2026-10-30-b0b79'
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
initial_receipt=work/'next-five-controlled-before-capture-receipt.json';initial=read(initial_receipt)
assert sha(initial_receipt.read_bytes())=='417e28395d3a80f5ac80b61345018302eeecb1d6c9db6a8653e68bd4b0729bf9'
assert sha((stage/'CAPTURE-MANIFEST.json').read_bytes())==initial['manifestSha256']=='25d6421716a853723e0843b6f4ecf1a514737446874dffdcd66fbf85f3274c39'
original_manifest=read(stage/'CAPTURE-MANIFEST.json')
for row in original_manifest['payload']:
 b=(stage/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
def put(name,b):
 target=stage/name
 assert not target.exists(),target
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
def tree(source,prefix):
 assert source.is_dir()
 for p in sorted(source.rglob('*')):
  rel=p.relative_to(source)
  if not p.is_file() or any(x in ['temp','tmp','node_modules','.git'] for x in rel.parts):continue
  assert not p.is_symlink();put(prefix+'/'+rel.as_posix(),p.read_bytes())
host=work/'next-m11-observer-v2-execution-2026-10-30T14-40-41-470Z'
denied=work/'next-m11-observer-v2-execution-2026-10-30T14-40-06-499Z'
prepared=work/'next-m11-editor-media-before-sol-v2'
report_bytes=(host/'m11/report.json').read_bytes();classification_bytes=(host/'classification.json').read_bytes()
assert sha(report_bytes)=='ef61930957c05df9bc3d5cf3c29243d6fb1ac9190bb132d75453bd2a730eb126'
classification=json.loads(classification_bytes);r=read(host/'receipt.json')
assert r['sourceSubsetCurrentBefore'] and r['sourceSubsetCurrentAfter'] and r['exitCode']==1
assert r['producerSha256']==sha((prepared/'browser-before.mjs').read_bytes())
assert r['manifestSha256']==sha((prepared/'manifest.json').read_bytes())
assert classification['summary']=={'scenarios':12,'checks':71,'failed':9,'targetFailures':8,'executionFailures':0}
tree(host,'actual-m11-observer-v2-host-execution')
tree(denied,'separate-m11-observer-v2-restricted-host-denial')
tree(prepared,'prepared-and-reference/next-m11-editor-media-before-sol-v2')
snapshot=read(stage/'provenance/source-before-b0b79.json');frozen={r['path']:r for r in snapshot['files']}
source_rows=[]
for row in read(prepared/'manifest.json')['files']:
 name=row['file'];captured=prepared/'capture'/name
 assert captured.is_file(),captured
 b=captured.read_bytes();assert sha(b)==row['sha256']==frozen[name]['sha256']
 old=stage/'physical-current-b0b79'/name
 if old.exists():assert old.read_bytes()==b
 else:put('physical-current-b0b79/'+name,b)
 source_rows.append(row)
put('provenance/m11-observer-v2-source-capture.json',(json.dumps({'classification':'GENUINE_CAPTURED_B0B79_M11_SOURCE_AND_OBSERVER_ONLY_VERSION_SEPARATION','sources':source_rows,'hostReceiptSha256':sha((host/'receipt.json').read_bytes()),'reportSha256':sha(report_bytes),'classificationSha256':sha(classification_bytes),'originalM11CrashObserverExit2Preserved':True,'restrictedHostDenialSeparate':True,'scope':'No application recovery boundary/cache/timeout/source change. ObserverV2 uses count/null observation and the same captured app fault/source; source bytes come from genuine prepared capture, not later reconstruction. Actual malformed response may destroy parent React tree; that original defect is retained.'},ensure_ascii=False,indent=2)+'\n').encode())
for name in ['capture-next-five-genuine-before.py','seal-next-five-genuine-before.py']:
 put('capture-tools/'+name,(work/name).read_bytes())
put('provenance/initial-capture-root-release-receipt.json',initial_receipt.read_bytes())
payload=[];folded=set()
for p in sorted(stage.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink();name=p.relative_to(stage).as_posix();path=PurePosixPath(name)
 assert not path.is_absolute() and '..' not in path.parts and ':' not in name and '\\' not in name and name.casefold() not in folded
 folded.add(name.casefold());b=p.read_bytes();payload.append({'path':name,'bytes':len(b),'sha256':sha(b)})
manifest={'schemaVersion':1,'classification':'SEALED_GENUINE_FIVE_BEFORE_WITH_ORIGINAL_M11_CRASH_AND_OBSERVER_V2_SEPARATE_NOT_ACCEPTANCE','globalFingerprint':snapshot['validationSourceSha256'],
 'initialCaptureManifestSha256':initial['manifestSha256'],'initialCaptureReceiptSha256':sha(initial_receipt.read_bytes()),'initialPhysicalSources':initial['physicalSources'],'m11V2CapturedSources':len(source_rows),
 'payloadCount':len(payload),'payload':payload,'qualifications':['Actualbefore results are scoped defect observations, not acceptance. All current executed/reference sources were captured before product edits; no source reconstruction.','OriginalM11actualReactcrash and laterobserverexit2 remain original. Restricted-host denial is separate environmental startup evidence; observerV2 actualhost run has12scenarios/71checks/9fail/8targets/0executionfailures.','NativeDB/RLS/locks/provider-delivery/invoice/browser scopes stay exactly declared per producer. Historical support archives are fixture prefixes only, not current application source.']}
mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
assert not (stage/'FINAL-BEFORE-MANIFEST.json').exists();(stage/'FINAL-BEFORE-MANIFEST.json').write_bytes(mb)
destination=repo/'docs/admin-r3-evidence/2026-10-30-next-required-before';destination.mkdir(parents=True,exist_ok=True)
archive=destination/'next-five-required-before.zip';manifest_target=destination/'next-five-required-before.manifest.json';receipt_target=destination/'next-five-required-before.receipt.json'
assert not any(p.exists() for p in [archive,manifest_target,receipt_target])
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for row in payload:z.write(stage/row['path'],row['path'])
 z.writestr('FINAL-BEFORE-MANIFEST.json',mb)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(payload)+1==len(set(z.namelist()))==len({n.casefold() for n in z.namelist()})
 for row in payload:
  b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
manifest_target.write_bytes(mb)
receipt={'classification':'SEALED_GENUINE_BEFORE_FIVE_SCOPES_PRODUCT_FAILURES_PRESERVED_NOT_ACCEPTANCE','archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'payloads':len(payload),'archiveEntries':len(payload)+1,'manifestSha256':sha(mb),'globalFingerprint':snapshot['validationSourceSha256'],'initialPhysicalSources':91,'m11ObserverV2ReportSha256':sha(report_bytes),'m11ObserverV2ClassificationSha256':sha(classification_bytes),'sourceReconstruction':False,'testsExecutedBySeal':0,'originalM11CrashObserverExit2Preserved':True,'restrictedHostDenialSeparate':True}
receipt_target.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({**receipt,'receiptSha256':sha(receipt_target.read_bytes()),'path':str(archive)}))
