"use server";

import { revalidatePath } from "next/cache";
import { unstable_rethrow } from "next/navigation";
import { z } from "zod";

import { runLibraryTranslationScan, libraryTranslationScanOrdinal } from "@/lib/library-translation-scan";
import { runProfileTranslationScan } from "@/lib/profile-translation-scan";
import { profileTranslationScanOrdinal } from "@/lib/profile-translation-scan-rpc";
import { ensureSiteCopyEnglishTranslation } from "@/lib/auto-translate-site-copy-private";
import { requireStaff } from "@/lib/auth";
import { redirect } from "@/lib/navigation";
import { createServerSupabaseClient } from "@/lib/supabase/server";
import { translationBackfillCursorParams } from "@/lib/translation-backfill-cursor";
import { translationErrorCode } from "@/lib/translation-errors";
import { translationOperationBudgetNotice } from "@/lib/translation-operation-budget-notice";
import { premiumTranslationRuntimeGate } from "@/lib/translation-runtime-gate";
import { recordTranslationSyncRun } from "@/lib/translation-run-record";

const SITE_COPY_SYSTEM_KEY = "site-copy-overrides";

function translationsUrl(values: Record<string, string | number | null | undefined>) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(values)) {
    if (value !== null && value !== undefined && String(value)) {
      params.set(key, String(value));
    }
  }
  return `/translations${params.size ? `?${params}` : ""}`;
}

export async function translatePremiumLibraryBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  const result = await runLibraryTranslationScan({ supabase, actorId: session.user.id,
    scanIntent: String(formData.get("libraryScanIntent") || "").trim() || null,
    jobId: String(formData.get("libraryJob") || "").trim() || null,
    legacyCursor: String(formData.get("libraryCursor") ?? "0") });
  revalidatePath("/translations");
  revalidatePath("/library");
  redirect(translationsUrl({ ...cursorParams,
    libraryJob: result.recoveryJobId,
    libraryCursor: result.receipt ? libraryTranslationScanOrdinal(result.receipt) : cursorParams.libraryCursor,
    errorCode: result.errorCode,
    success: result.receipt === null && result.processed === 0 ? null :
      (result.errorCode && result.errorCode !== "translation_scan_complete" ? "Пакет книг приостановлен. Подтверждённые итоги: " : "Книги: ") +
      `подтверждённо просмотрено ${result.processed}, подтверждённых машинных черновиков ${result.translated}, ожидают проверки ${result.reviewPending}, устаревших ${result.stale}, актуальных ${result.current}, ручных ${result.manual}, пропущено ${result.skipped}, ошибок ${result.failed}. Машинные черновики не опубликованы.` +
      (result.receipt?.exhausted && result.receipt.status !== "cancelled" && result.receipt.status !== "cancelling"
        ? " Сохранённый набор просмотрен; новые записи войдут в новый обход." : "") +
      translationOperationBudgetNotice(result.budget, result.stopReason),
  }));
}
export async function translatePremiumWriterBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  const result = await runProfileTranslationScan({ supabase, actorId: session.user.id, kind: "writer",
    scanIntent: String(formData.get("writerScanIntent") || "").trim() || null,
    jobId: String(formData.get("writerJob") || "").trim() || null,
    legacyCursor: String(formData.get("writerCursor") ?? "0") });
  revalidatePath("/translations");
  revalidatePath("/editorial-database");
  redirect(translationsUrl({ ...cursorParams,
    writerJob: result.recoveryJobId,
    writerCursor: result.receipt ? profileTranslationScanOrdinal(result.receipt) : cursorParams.writerCursor,
    errorCode: result.errorCode,
    success: result.receipt === null && result.processed === 0 ? null :
      (result.errorCode && result.errorCode !== "translation_scan_complete" ? "Пакет биографий приостановлен. Подтверждённые итоги: " : "Биографии: ") +
      `подтверждённо просмотрено ${result.processed}, подтверждённых машинных черновиков ${result.translated}, ожидают проверки ${result.reviewPending}, устаревших ${result.stale}, актуальных ${result.current}, ручных ${result.manual}, пропущено ${result.skipped}, ошибок ${result.failed}. Машинные черновики не опубликованы.` +
      (result.receipt?.exhausted && result.receipt.status !== "cancelled" && result.receipt.status !== "cancelling"
        ? " Сохранённый набор просмотрен; новые записи войдут в новый обход." : "") +
      translationOperationBudgetNotice(result.budget, result.stopReason),
  }));
}

export async function translatePremiumSiteCopyBatchAction(formData: FormData) {
  const session = await requireStaff();
  if (!session?.user) redirect("/login");
  const cursorParams = translationBackfillCursorParams(formData);
  const supabase = await createServerSupabaseClient();
  if (!supabase) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_unavailable" }));
  }
  if (!(await premiumTranslationRuntimeGate(supabase))) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "translation_not_configured" }));
  }
  const response = await supabase.from("homepage_blocks").select("id,settings,updated_at")
    .contains("settings", { systemKey: SITE_COPY_SYSTEM_KEY })
    .order("updated_at", { ascending: false }).limit(2);
  const rows = z.array(z.object({ id: z.string().uuid(), settings: z.record(z.string(), z.unknown()),
    updated_at: z.string().datetime({ offset: true }) })).max(1).safeParse(response.data);
  if (response.error || !rows.success) {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_read_failed" }));
  }
  const existing = rows.data[0];
  if (!existing) {
    redirect(translationsUrl({ ...cursorParams,
      success: "Тексты сайта: русских CMS-переопределений для перевода пока нет." }));
  }
  const result = await ensureSiteCopyEnglishTranslation({ supabase, actorId: session.user.id,
    blockId: existing.id, runtimeApproved: true });
  try {
    await recordTranslationSyncRun({ supabase, kind: "site_copy", items: [{ entityId: existing.id,
      state: result.state === "not-ready" ? "not-configured" : result.state,
      error: result.error, model: result.model }] });
  } catch {
    redirect(translationsUrl({ ...cursorParams, errorCode: "database_write_failed" }));
  }
  revalidatePath("/translations");
  revalidatePath("/site-copy");
  if (result.state === "failed" || result.state === "not-ready" || result.state === "not-configured" ||
      result.state === "conflict") {
    redirect(translationsUrl({ ...cursorParams, errorCode: result.state === "conflict" ? "write_conflict"
      : result.state === "not-ready" ? "translation_migration_required"
        : result.state === "not-configured" ? "translation_not_configured" : translationErrorCode(result.error) }));
  }
  const success = result.state === "translated" || result.state === "review-pending"
    ? "Тексты сайта: машинный черновик сохранён и ожидает вашей проверки. Он не опубликован."
    : result.state === "stale"
      ? "Тексты сайта: сохранённый машинный черновик устарел. Проверьте или отклоните его перед новым переводом."
      : result.state === "manual" ? "Тексты сайта: ручной английский текст сохранён без изменений."
        : "Тексты сайта: новых строк для перевода нет.";
  redirect(translationsUrl({ ...cursorParams, success }));
}
