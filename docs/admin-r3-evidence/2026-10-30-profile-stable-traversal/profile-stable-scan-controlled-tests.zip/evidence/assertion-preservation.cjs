const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto'), assert = require('node:assert/strict');
const repo = path.resolve(__dirname, '../../probpera-literary-map'), ts = require(path.join(repo, 'node_modules/typescript'));
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, 'legacy-original/manifest.json'), 'utf8'));
const rootedExpect = value => {while (ts.isCallExpression(value) || ts.isPropertyAccessExpression(value) || ts.isElementAccessExpression(value)) value = value.expression; return ts.isIdentifier(value) && value.text === 'expect';};
function scopes(bytes, filename) {
  const source = ts.createSourceFile(filename, bytes.toString(), ts.ScriptTarget.Latest, true, filename.endsWith('.ts') ? ts.ScriptKind.TS : ts.ScriptKind.JS);
  const assertions = [], normalizationCalls = [], normalizationDeclarations = [];
  function walk(node) {
    if (ts.isCallExpression(node)) {
      const name = node.expression.getText(source);
      if (name.startsWith('assert.') || rootedExpect(node.expression) || name === 'resultCheck' || name === 'equal') assertions.push(node.getText(source));
      if (/normaliz|publicAdmission/u.test(name)) normalizationCalls.push(node.getText(source));
    }
    if ((ts.isFunctionDeclaration(node) || ts.isVariableDeclaration(node) || ts.isMethodDeclaration(node)) && node.name && /normaliz|publicAdmission/u.test(node.name.getText(source))) normalizationDeclarations.push(node.getText(source));
    ts.forEachChild(node, walk);
  }
  walk(source); return {assertions, normalizationCalls, normalizationDeclarations};
}
const checks = manifest.map(row => {
  const oldBytes = fs.readFileSync(path.join(__dirname, 'legacy-original', row.file)), currentBytes = fs.readFileSync(path.join(repo, row.file));
  assert.equal(sha(oldBytes), row.sha256);
  const before = scopes(oldBytes, row.file), after = scopes(currentBytes, row.file);
  const addedCompatibilityAssertions = row.file.endsWith('/catalog-admission-runtime.cjs');
  if (addedCompatibilityAssertions) {
    let cursor = 0;
    for (const expression of after.assertions) if (expression === before.assertions[cursor]) cursor++;
    assert.equal(cursor, before.assertions.length, row.file + ': every old full assertion remains exact in order');
    assert.equal(after.assertions.length - before.assertions.length, 5, 'Only five explicit support-probe/current-journal checks are added');
  } else assert.deepEqual(after.assertions, before.assertions, row.file + ': full assertions');
  assert.deepEqual(after.normalizationCalls, before.normalizationCalls, row.file + ': normalizer/public admission calls');
  assert.deepEqual(after.normalizationDeclarations, before.normalizationDeclarations, row.file + ': normalizer/public admission declarations');
  return {file: row.file, beforeSha256: row.sha256, currentSha256: sha(currentBytes), fullAssertions: before.assertions.length,
    currentFullAssertions: after.assertions.length, addedCompatibilityAssertions: addedCompatibilityAssertions ? 5 : 0,
    normalizationCalls: before.normalizationCalls.length, normalizationDeclarations: before.normalizationDeclarations.length, exact: true};
});
const result = {classification: 'FULL_ASSERTION_EXPRESSIONS_MATCHERS_AND_NORMALIZER_PUBLIC_ADMISSION_SCOPES_EXACT', passed: true, checks,
  scope: 'SDK fixture setup/read declarations/actual protocol observation only. Genuine original archives remain unchanged; no test omission or normalization edit.'};
const output = path.join(__dirname, 'assertion-preservation.json'); fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({output, sha256: sha(fs.readFileSync(output)), checks}));
