// Parent-only next-slice diagnostic. Never edits maintained sources or uses live services.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict'),{createRequire}=require('node:module');
const repo=process.cwd(),work=path.resolve(repo,'../work'),out=path.join(work,'retry-partial-pass-before-'+new Date().toISOString().replace(/[:.]/g,'-'));
fs.mkdirSync(out);const native=createRequire(path.join(repo,'package.json')),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const sources=new Map(),support=[];
function remember(file,expected){const b=fs.readFileSync(path.join(repo,file)),h=sha(b);if(expected)assert.equal(h,expected,file);if(sources.has(file))assert.equal(sources.get(file).sha256,h,file);else{const dest=path.join(out,'sources',file);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,b);sources.set(file,{file,bytes:b.length,sha256:h});}return b;}
for(const file of ['docs/admin-r3-task-package/modules/M07.md','docs/admin-r3-task-package/modules/M24.md'])remember(file);
for(const prefix of ['WRITER_ADMISSION','CATALOG_ADMISSION']){process.env[prefix+'_REPO']=repo;process.env[prefix+'_SOURCE_ROOT']=repo;process.env[prefix+'_OUTPUT_ROOT']=path.join(out,prefix.toLowerCase());}
for(const f of ['apps/admin/lib/fixtures/writer-admission-runtime.cjs','apps/admin/lib/fixtures/writer-admission-boundary.cjs','apps/admin/lib/fixtures/catalog-admission-runtime.cjs','apps/admin/lib/fixtures/catalog-admission-boundary.cjs','apps/admin/lib/fixtures/library-translation-scan-boundary.cjs','apps/admin/lib/fixtures/profile-translation-scan-boundary.cjs'])remember(f);
const writer=native(path.join(repo,'apps/admin/lib/fixtures/writer-admission-runtime.cjs')),catalog=native(path.join(repo,'apps/admin/lib/fixtures/catalog-admission-runtime.cjs'));
function graph(view){for(const r of view.graph.values())remember(r.module||r.file,r.sha256);}
function operations(view){return structuredClone([...view.server.operations.values()]);}
const scenarios=[];
async function heldCase(kind,mode){
 let view;
 const options=mode==='unknown'?{unknownFirst:true}:mode==='complete-recovery'?{lostFinalResponseAck:true}:kind==='writer'?{onProvider:async({call})=>{if(call.pass==='translation')view.clock.now=300001;}}:{deadlineAfterTranslation:true};
 view=kind==='writer'?writer.setup(options):catalog.setup(kind,options);
 const before=view.canonical(),first=await view.helper(),firstCalls=view.providerCalls.length,firstOps=operations(view),firstCandidates=view.privateCandidates.size;
 const second=await view.helper(),secondCalls=view.providerCalls.length;
 assert.deepEqual(view.canonical(),before);assert.equal(view.writes.length,0);assert.equal(view.builds.length,0);
 graph(view);
 if(mode==='complete-recovery'){assert.equal(secondCalls,2);assert.equal(view.privateCandidates.size,1);assert.ok(['translated','review-pending'].includes(second.state));}
 else {assert.equal(firstCalls,1);assert.equal(secondCalls,1);assert.equal(view.privateCandidates.size,0);assert.equal(view.server.operations.size,1);}
 const row={kind,mode,first,second,firstProviderCalls:firstCalls,totalProviderCalls:secondCalls,passes:view.providerCalls.map(c=>c.pass),firstCandidates,finalCandidates:view.privateCandidates.size,
   firstOperations:firstOps,finalOperations:operations(view),providerCalls:structuredClone(view.providerCalls),wire:structuredClone(view.wire),timeline:structuredClone(view.timeline),budgets:view.budgets.map(b=>({input:b.input,snapshot:b.budget.snapshot()})),
   canonicalBefore:before,canonicalAfter:view.canonical(),canonicalWrites:0,publicBuildRequests:0,
   interpretation:mode==='confirmed-partial'?'SAFE_HOLD_NO_REGENERATION_BUT_NO_EXPOSED_CONFIRMED_PASS_CONTINUATION':mode==='unknown'?'REQUIRED_UNKNOWN_OUTCOME_HOLD':'EXISTING_COMPLETE_ARTIFACT_RECOVERY_WITHOUT_REGENERATION'};
 scenarios.push(row);
}

// Reuse the existing faithful site-copy Auth/catalog/installed-SDK boundary.
// The only support adaptation exposes its existing synthetic AI boundary; no
// production algorithm, normalizer, DTO, source seed or acceptance assertion changes.
const siteFile='apps/admin/lib/fixtures/site-copy-machine-review.cjs',siteOriginal=remember(siteFile).toString('utf8');
const boundary=siteOriginal.indexOf('\nasync function main()');assert(boundary>0);
const expose='wire, builds, mutations, stages, promotions, discards, runs, events, loaded,';
assert.equal(siteOriginal.slice(0,boundary).split(expose).length,2);
const sitePrefix=siteOriginal.slice(0,boundary).replace(expose,'ai, '+expose);
fs.writeFileSync(path.join(out,'site-copy-support-original.cjs'),siteOriginal);fs.writeFileSync(path.join(out,'site-copy-support-adapted-prefix.cjs'),sitePrefix);
const fixtureProcess={env:{SITE_COPY_REPO:repo,SITE_COPY_SOURCE_ROOT:repo,SITE_COPY_OUTPUT_ROOT:path.join(out,'site-copy-sources')}};
const site=new Function('require','__dirname','__filename','process',sitePrefix+'\nreturn {fixture,graph,actorId,blockId,key,englishText};')(native,path.join(repo,'apps/admin/lib/fixtures'),path.join(repo,siteFile),fixtureProcess);
support.push({file:siteFile,originalSha256:sha(Buffer.from(siteOriginal)),adaptedPrefixSha256:sha(Buffer.from(sitePrefix)),adaptation:'Expose existing synthetic ai object only. A clock reads controlled completed calls, or a wrapper drops the first already returned synthetic response. Actual helpers/SDK/validators remain unchanged.'});
async function siteCase(mode){
 const v=site.fixture(),before=v.snapshot(),original=v.ai.run.bind(v.ai),delivered=[];
 v.ai.run=async(...args)=>{const value=await original(...args);delivered.push(structuredClone(value));if(mode==='unknown'&&delivered.length===1){const error=new Error('Controlled accepted synthetic response delivery lost');error.name='TimeoutError';throw error;}return value;};
 const budgetApi=v.loaded.load('apps/admin/lib/translation-operation-budget.ts');
 const budget=mode==='confirmed-partial'?budgetApi.createTranslationOperationBudget({maxAttempts:1,maxProviderCalls:4,deadlineMs:45000,now:()=>v.providerCalls.length?45001:0}):undefined;
 const first=await v.invoke(budget?{operationBudget:budget}:{}),firstCalls=v.providerCalls.length,firstDraft=v.privateDraft,firstWire=structuredClone(v.wire),firstStageCount=v.stages.length;
 const second=await v.invoke();
 assert.equal(firstCalls,1);assert.equal(v.providerCalls.length,3);assert.deepEqual(v.providerCalls.map(c=>c.pass),['translation','translation','review']);
 assert.equal(firstDraft,null);assert.equal(firstStageCount,0);assert.equal(v.stages.length,1);assert.equal(second.state,'translated');
 assert.deepEqual(v.snapshot(),before);assert.equal(v.mutations.length,0);assert.equal(v.builds.length,0);
 assert.deepEqual(v.providerCalls[0].source,v.providerCalls[1].source);
 for(const r of site.graph.values())remember(r.file,r.sha256);
 scenarios.push({kind:'site_copy',mode,first,second,firstProviderCalls:firstCalls,totalProviderCalls:v.providerCalls.length,passes:v.providerCalls.map(c=>c.pass),firstCandidate:firstDraft,firstStageCount,
   finalCandidate:v.privateDraft,providerCalls:v.providerCalls,controlledReturnedProviderBodies:delivered,firstWire,wire:v.wire,stages:v.stages,
   firstBudget:budget?.snapshot()||null,canonicalBefore:before,canonicalAfter:v.snapshot(),canonicalWrites:0,publicBuildRequests:0,
   target:{name:mode==='unknown'?'Unknown accepted delivery cannot cause another translation without reconciliation':'Confirmed completed translator pass must not be regenerated after reviewer has not started',pass:false,
     actual:'A fresh invocation repeats the identical source translation, then review. No per-call private journal/response was written before the first stop.'}});
}
async function main(){
 for(const kind of ['writer','library','country'])for(const mode of ['confirmed-partial','unknown','complete-recovery'])await heldCase(kind,mode);
 await siteCase('confirmed-partial');await siteCase('unknown');
 for(const r of sources.values())assert.equal(sha(fs.readFileSync(path.join(repo,r.file))),r.sha256,'Captured source drift '+r.file);
 const packages=['@supabase/supabase-js','typescript','next','zod'].map(name=>({name,version:JSON.parse(fs.readFileSync(path.join(repo,'node_modules',name,'package.json'),'utf8')).version}));
 const report={classification:'GENUINE_CURRENT_PARENT_ONLY_NEXT_SLICE_BEFORE_NOT_ACCEPTANCE',capturedAt:new Date().toISOString(),sourceRoot:repo,scenarios,sourceBindings:[...sources.values()].sort((a,b)=>a.file.localeCompare(b.file)),packages,supportAdaptation:support,
   summary:{scenarioCount:scenarios.length,siteCopyTargetFailures:scenarios.filter(r=>r.kind==='site_copy'&&!r.target.pass).length,writerCatalogRequiredUnknownHolds:3,writerCatalogConfirmedPartialHolds:3,writerCatalogCompleteRecoveryControls:3,liveProviderCalls:0,canonicalWrites:0,publicBuildRequests:0,executionFailures:0},
   limitations:['Controlled Auth/KV/canonical data/SDK fetch and synthetic AI only; no live database/provider/billing/browser acceptance.',
     'Writer/catalog repeated helpers prove safe holds, not an explicit reviewer-only retry command. Missing operator path is separately established from actual UI/RPC source; do not claim unsafe automatic resume is required.',
     'Site-copy dropped delivery is an explicit synthetic acceptance-and-response-loss boundary; no live external acceptance is inferred.',
     'Article addressed retry is existing separate functionality, not disproved or replaced by these profile/site-copy scenarios. Full M07-T03/T13 ten-item8+2 UI acceptance remains a separate obligation.']};
 fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
 const receipt={output:out,reportSha256:sha(fs.readFileSync(path.join(out,'report.json'))),sourceBindings:sources.size,...report.summary};fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
}
main().catch(error=>{fs.writeFileSync(path.join(out,'execution-error.json'),JSON.stringify({classification:'PARENT_HARNESS_EXECUTION_DIAGNOSTIC_NOT_APPLICATION_TARGET',error:error.stack},null,2)+'\n');console.error(error.stack||String(error));process.exitCode=2;});
