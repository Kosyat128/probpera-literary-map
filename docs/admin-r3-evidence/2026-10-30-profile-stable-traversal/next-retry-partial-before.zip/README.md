# Genuine next-slice BEFORE: partial passes and addressed retry

The original eleven actual-helper/installed-SDK scenarios preserve44 captured
source inputs, raw operation/private-body/wire/canonical/budget reports and the
complete original observer. Two site-copy safety targets fail: a confirmed
translator response discarded before required review and an accepted synthetic
response whose delivery is dropped. The next invocation repeats translation.
All eleven canonical/publication controls and nine writer/catalog safety and
complete-recovery controls pass. This is retained negative proof, not acceptance.

The original44 capture is immutable. The portable runner adds path parameters
only; heldCase/siteCase full function/assertion bytes remain exact. One otherwise
omitted transitive CJS boundary is explicitly supplemented from bytes matching
the independent original9df snapshot. Prior archive dependencies are bundled.
An independent rerun uses captured sources, the bundled archive inputs and the
actual installed packages selected through NODE_PATH. Unknown-outcome controls
do not authorize automatic continuation or payment.

The current1af observer differs only in one declared test-support module fixed
for fresh POST fidelity elsewhere; every production input remains unchanged.
Its eleven actual helper outcomes and the unchanged safety oracle retain the
same two target failures. Do not replace original BEFORE with CURRENT.

requirements-current-missing-map.json distinguishes existing article addressed
retry, missing non-article failed-item/version UI retry, correct unknown holds,
missing explicit partial-pass continuation and the reproduced site-copy journal
gap. Source-only article partial-body findings are not runtime claims. No source,
normalizer, database, key, paid provider or production action was changed here.

Final bundle adds the independent extracted-candidate rerun proof; original runner/source/response bytes remain preserved. The safety oracle still returns exactly two target failures and no failed controls.
