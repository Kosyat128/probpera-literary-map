const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { createRequire } = require('node:module');
const { execFileSync } = require('node:child_process');

// Actual actions, helpers, DTOs, provider validation and exporter execute. The
// installed Supabase SDK has a synthetic fetch boundary; no live service runs.
const repo = process.env.SITE_COPY_REPO || path.resolve(__dirname, '../../../..');
const sourceRoot = process.env.SITE_COPY_SOURCE_ROOT || repo;
const outRoot = process.env.SITE_COPY_OUTPUT_ROOT || null;
const nativeRequire = createRequire(path.join(repo, 'package.json'));
const ts = nativeRequire('typescript');
const { createClient } = nativeRequire('@supabase/supabase-js');
const { isRedirectError } = nativeRequire('next/dist/client/components/redirect-error');
const { getURLFromRedirectError } = nativeRequire('next/dist/client/components/redirect');
const sha = value => createHash('sha256').update(value).digest('hex');
const digest = value => sha(JSON.stringify(value));
const equal = (left, right) => {
  try { assert.deepEqual(left, right); return true; } catch { return false; }
};
const graph = new Map(), compiledCache = new Map(), traces = [], checks = [];
const helperFile = 'apps/admin/lib/auto-translate-site-copy-private.ts';
const contractFile = 'apps/admin/lib/site-copy-translation-contract.ts';
const actorId = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const blockId = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const draftId = 'dddddddd-dddd-4ddd-8ddd-dddddddddddd';
const stamp = '2026-10-29T10:00:00.123456+00:00';
const key = 'interface.Поиск';
const russianText = 'Найти книги в каталоге';
const englishText = 'Find books in the catalogue';
const canonicalEnglish = 'Previously accepted English';
const forbid = () => { throw new Error('Uncontrolled network or unrelated branch forbidden in site-copy fixture'); };
global.fetch = forbid;
const captured = new Map();
if (path.resolve(sourceRoot) !== path.resolve(repo)) {
  const original = JSON.parse(fs.readFileSync(path.join(sourceRoot, 'source-manifest.json'), 'utf8'));
  for (const row of original.sources) captured.set(row.file, row.sha256);
  const supplement = path.join(sourceRoot, 'supplement-manifest.json');
  if (fs.existsSync(supplement)) for (const row of JSON.parse(fs.readFileSync(supplement, 'utf8'))) {
    if (captured.has(row.file)) assert.equal(captured.get(row.file), row.sha256);
    captured.set(row.file, row.sha256);
  }
  for (const [file, hash] of captured) assert.equal(sha(fs.readFileSync(path.join(sourceRoot, file))), hash, file);
}
if (outRoot) {
  fs.mkdirSync(outRoot, { recursive: true });
  assert.equal(fs.existsSync(path.join(outRoot, 'report.json')), false, 'Use a fresh output directory');
}
function sourceBytes(file) {
  if (captured.size) assert.ok(captured.has(file), `Uncaptured BEFORE dependency: ${file}`);
  const bytes = fs.readFileSync(path.join(sourceRoot, file)), hash = sha(bytes);
  if (captured.has(file)) assert.equal(hash, captured.get(file), file);
  if (graph.has(file)) assert.equal(graph.get(file).sha256, hash, `Executed source drift: ${file}`);
  else {
    graph.set(file, { file, sha256: hash });
    if (outRoot) {
      const target = path.join(outRoot, 'sources', file); fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, bytes, { flag: 'wx' });
    }
  }
  return bytes;
}
function modules(mocks) {
  const cache = new Map();
  const fixtureProcess = { env: { PREMIUM_TRANSLATION_PROVIDER: 'cloudflare', ADMIN_BASE_PATH: '',
    OPENAI_AUTO_TRANSLATE_SITE_COPY: 'true', OPENAI_PREMIUM_TRANSLATION_REVIEW: 'true' } };
  function load(file) {
    if (cache.has(file)) return cache.get(file);
    const filename = path.join(sourceRoot, file), bytes = sourceBytes(file);
    const cacheKey = `${file}:${sha(bytes)}`;
    if (!compiledCache.has(cacheKey)) compiledCache.set(cacheKey, ts.transpileModule(bytes.toString('utf8'), {
      fileName: filename.replace(/\.mjs$/u, '.js'), compilerOptions: {
        target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX,
        esModuleInterop: true, allowJs: true,
      },
    }).outputText);
    const compiled = compiledCache.get(cacheKey);
    const module = { exports: {} }; cache.set(file, module.exports);
    function localRequire(name) {
      if (Object.hasOwn(mocks, name)) return mocks[name];
      const target = name.startsWith('@/') ? path.join(sourceRoot, 'apps/admin', name.slice(2))
        : name.startsWith('.') ? path.resolve(path.dirname(filename), name) : null;
      if (!target) return nativeRequire(name);
      for (const extension of ['', '.ts', '.tsx', '.mjs', '/index.ts']) {
        const candidate = target + extension;
        if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return load(path.relative(sourceRoot, candidate).replaceAll('\\', '/'));
      }
      throw new Error(`Actual dependency absent: ${name} from ${file}`);
    }
    new Function('require', 'module', 'exports', 'process', 'fetch', compiled)(localRequire, module, module.exports, fixtureProcess, forbid);
    cache.set(file, module.exports); return module.exports;
  }
  return { load };
}
function check(name, condition, expected, actual, category = 'target') {
  checks.push({ name, pass: !!condition, expected, actual, category });
}
function matches(row, params) {
  return [...params].every(([field, value]) => !value.startsWith('eq.') || String(row[field]) === value.slice(3));
}
function fixture(options = {}) {
  const settings = { systemKey: 'site-copy-overrides', version: 1,
    siteCopy: { ru: { [key]: russianText }, en: { [key]: canonicalEnglish },
      fr: { [key]: 'Texte humain \u2014 droits réservés' }, customLocaleMetadata: { owner: 'Keep locale metadata', list: [1, null, 'Ω'] } },
    premiumTranslation: { siteCopyEn: { [key]: { sourceHash: 'a'.repeat(64), model: 'old-model',
      reviewerModel: 'old-reviewer', generatedAt: '2026-10-28T10:00:00.000Z' } }, customRights: { keep: true, values: ['RU', 'EN', 'FR'] } },
    authoredSettings: { owner: 'Human editor', permission: ['Keep exact full JSON', { revision: 17 }], whitespace: '  Keep raw spacing  ' } };
  if (options.manual) delete settings.premiumTranslation.siteCopyEn[key];
  if (options.englishValue !== undefined || options.nullEnglish) settings.siteCopy.en[key] = options.nullEnglish ? null : options.englishValue;
  if (options.badMarker) settings.premiumTranslation.siteCopyEn[key] = { sourceHash: options.badMarker };
  if (options.badMap) settings.siteCopy.en = options.badMap;
  if (options.badMetadata) settings.premiumTranslation = options.badMetadata;
  if (options.nullMetadata) settings.premiumTranslation = null;
  if (options.absentEnglish) delete settings.siteCopy.en[key];
  if (options.current) settings.premiumTranslation.siteCopyEn[key].sourceHash = digest({ key, text: russianText });
  let row = { id: blockId, updated_at: stamp, is_enabled: true, block_type: 'text', title: 'Системные тексты сайта',
    display_order: 2_000_000_000, background_style: 'transparent', background_media_id: null, settings };
  if (options.missingCanonical) row = null;
  const before = structuredClone(row), wire = [], builds = [], providerCalls = [], mutations = [], stages = [], promotions = [], discards = [], runs = [], events = [];
  let privateDraft = null, tick = 0, readCount = 0, loaded;
  function newStamp() { tick++; return `2026-10-29T10:${String(tick).padStart(2, '0')}:00.123456+00:00`; }
  const snapshot = () => structuredClone(row);
  const readEnvelope = identity => ({ schemaVersion: 1, entityType: identity.p_entity_type, entityId: identity.p_entity_id, draft: structuredClone(privateDraft) });
  const fetchBoundary = async (resource, init = {}) => {
    const url = new URL(typeof resource === 'string' ? resource : resource.url);
    assert.equal(url.origin, 'https://site-copy.fixture.invalid');
    const method = init.method || 'GET', table = url.pathname.split('/').at(-1), payload = init.body ? JSON.parse(init.body) : null;
    wire.push({ method, path: url.pathname, query: Object.fromEntries(url.searchParams), payload: structuredClone(payload) });
    let data = null, error = null;
    if (url.pathname.includes('/rpc/')) {
      if (table === 'record_translation_sync_run') { runs.push(structuredClone(payload)); data = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc'; }
      else if (table === 'get_premium_translation_working_draft') {
        data = readEnvelope(payload);
        if (options.readIssue === 'unavailable') error = { code: '42883', message: 'Controlled private RPC unavailable' };
        else if (options.readIssue === 'missing') data = {};
        else if (options.readIssue === 'null') data = null;
        else if (options.readIssue === 'malformed') data.draft = { broken: true };
      } else if (table === 'stage_premium_translation_working_draft') {
        stages.push(structuredClone(payload));
        const revision = payload.p_source_revision;
        // Private staging retains valid paid output after a live source/CAS
        // change. Only explicit promotion below compares against live values.
        assert.equal(revision.blockId, blockId);
        assert.equal(payload.p_target_revision.id, blockId);
        assert.equal(payload.p_target_revision.updatedAt, revision.blockUpdatedAt);
        assert.equal(payload.p_source_hash, digest(payload.p_source_snapshot.items));
        if (privateDraft) error = { code: '40001', message: 'Controlled existing candidate conflict' };
        else {
          privateDraft = { id: draftId, version: 1, entityType: payload.p_entity_type, entityId: payload.p_entity_id,
            targetLocale: 'en', humanReview: 'pending', sourceHash: payload.p_source_hash, candidateHash: digest(payload),
            sourceRevision: structuredClone(revision), targetRevision: structuredClone(payload.p_target_revision),
            sourceSnapshot: structuredClone(payload.p_source_snapshot), payload: structuredClone(payload.p_payload),
            provenance: structuredClone(payload.p_provenance), createdAt: '2026-10-29T11:00:00.000Z', createdBy: actorId };
          data = readEnvelope(payload);
          if (options.stageIssue === 'lost-ack') error = { code: '57014', message: 'Controlled committed stage ACK loss' };
          else if (options.stageIssue === 'malformed-ack') data.draft.version = 0;
        }
      } else if (table === 'promote_premium_translation_working_draft') {
        promotions.push(structuredClone(payload)); assert.ok(privateDraft, 'Candidate must exist');
        const candidate = structuredClone(privateDraft), expected = { id: row.id, updatedAt: row.updated_at };
        if (payload.p_draft_id !== candidate.id || payload.p_expected_version !== candidate.version || payload.p_candidate_hash !== candidate.candidateHash ||
            !equal(candidate.sourceSnapshot.settings, row.settings) || !equal(candidate.targetRevision, expected)) {
          error = { code: '40001', message: 'Controlled candidate or source changed' };
        } else {
          assert.equal(payload.p_confirm_human_review, true); assert.equal(payload.p_source_hash, candidate.sourceHash);
          const nextSettings = structuredClone(row.settings);
          for (const item of candidate.payload.items) {
            nextSettings.siteCopy.en[item.key] = item.text;
            const sourceItem = candidate.sourceSnapshot.items.find(source => source.key === item.key);
            nextSettings.premiumTranslation.siteCopyEn[item.key] = { sourceHash: sourceItem.sourceHash,
              model: candidate.provenance.translatorModel, reviewerModel: candidate.provenance.reviewerModel,
              generatedAt: candidate.provenance.generatedAt, reviewedAt: '2026-10-29T12:00:00.000Z', reviewedBy: actorId };
          }
          row = { ...row, settings: nextSettings, updated_at: newStamp() };
          mutations.push({ method: 'controlled-rpc-promote', row: structuredClone(row) }); privateDraft = null;
          data = { schemaVersion: 1, entityType: candidate.entityType, entityId: candidate.entityId, state: 'promoted', draftId: candidate.id,
            version: candidate.version, candidateHash: candidate.candidateHash, canonicalId: options.promoteIssue === 'wrong-target'
              ? 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee' : row.id, canonicalUpdatedAt: row.updated_at,
            reviewedBy: options.promoteIssue === 'wrong-actor' ? 'ffffffff-ffff-4fff-8fff-ffffffffffff' : actorId, reviewedAt: row.updated_at };
          if (options.promoteIssue === 'lost-ack') error = { code: '57014', message: 'Controlled committed promotion ACK loss' };
        }
      } else if (table === 'discard_premium_translation_working_draft') {
        discards.push(structuredClone(payload)); assert.ok(privateDraft);
        assert.equal(payload.p_draft_id, privateDraft.id); assert.equal(payload.p_expected_version, privateDraft.version); assert.equal(payload.p_candidate_hash, privateDraft.candidateHash);
        data = { schemaVersion: 1, entityType: privateDraft.entityType, entityId: privateDraft.entityId, state: 'discarded',
          draftId: privateDraft.id, version: privateDraft.version, candidateHash: privateDraft.candidateHash }; privateDraft = null;
      } else if (table === 'save_site_copy_block') {
        if (row ? payload.p_expected_updated_at !== row.updated_at : payload.p_expected_updated_at !== null) error = { code: '40001', message: 'SITE_COPY_WRITE_CONFLICT' };
        else {
          row = { ...(row || { id: blockId }), ...structuredClone(payload.p_payload), updated_at: newStamp() };
          mutations.push({ method: 'controlled-rpc-save', row: structuredClone(row) }); events.push('accepted-ru-save'); data = row.id;
        }
      } else throw new Error(`Unexpected controlled RPC: ${table}`);
    } else if (method === 'GET' && table === 'homepage_blocks') {
      readCount++;
      const rows = options.duplicateRows ? [row, { ...structuredClone(row), id: 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee' }] : [row];
      data = rows.filter(candidate => candidate && matches(candidate, url.searchParams)).map(candidate => structuredClone(candidate));
      if (url.searchParams.has('limit')) data = data.slice(0, Number(url.searchParams.get('limit')));
      const issue = readCount === 1 ? options.firstReadIssue : readCount === 2 ? options.latestReadIssue : null;
      if (issue === 'unavailable') error = { code: '57014', message: 'Controlled canonical read unavailable' };
      else if (issue === 'malformed') data = [{ ...structuredClone(row), id: null }];
      else if (issue === 'null') data = null;
    } else if (method === 'PATCH' && table === 'homepage_blocks') {
      mutations.push({ method, payload: structuredClone(payload), query: Object.fromEntries(url.searchParams) });
      if (matches(row, url.searchParams)) { row = { ...row, ...structuredClone(payload), updated_at: newStamp() }; data = [structuredClone(row)]; }
      else data = [];
    } else if (method === 'POST' && table === 'admin_audit_log') data = null;
    else throw new Error(`Unexpected controlled transport ${method} ${table}`);
    return new Response(JSON.stringify(error || data), { status: error ? 409 : 200, headers: { 'Content-Type': 'application/json' } });
  };
  const sdk = createClient('https://site-copy.fixture.invalid', 'controlled-no-live-auth', {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }, global: { fetch: fetchBoundary },
  });
  const ai = { async run(model, input) {
    const body = JSON.parse(input.messages[1].content), pass = body.INVALID_DRAFT_TRANSLATION ? 'repair' : body.DRAFT_TRANSLATION ? 'review' : 'translation';
    providerCalls.push({ model, pass, source: structuredClone(body.SOURCE_DATA) });
    events.push(`provider-${pass}`);
    if (options.providerFailure) throw new Error('Controlled provider failure after accepted RU save');
    if (options.changeDuringProvider && providerCalls.length === 2) {
      row.settings.siteCopy.ru[key] = 'Изменённый русский текст'; row.updated_at = newStamp();
    }
    if (options.manualDuringProvider && providerCalls.length === 2) {
      row.settings.siteCopy.en[key] = 'Human editor takeover'; delete row.settings.premiumTranslation.siteCopyEn[key]; row.updated_at = newStamp();
    }
    const items = body.SOURCE_DATA.items.map(item => ({ key: item.key, text: options.badProvider ? 'Неверный русский ответ' : englishText }));
    return { id: `controlled-site-copy-${providerCalls.length}`, response: JSON.stringify({ items }), usage: { prompt_tokens: 11, completion_tokens: 13 } };
  } };
  const mocks = {
    '@opennextjs/cloudflare': { getCloudflareContext: () => ({ env: { AI: ai } }) },
    '@/lib/auth': { requireStaff: async () => ({ user: { id: actorId }, profile: { role: 'owner' } }) },
    '@/lib/supabase/server': { createServerSupabaseClient: async () => sdk },
    '@/lib/translation-runtime-gate': { premiumTranslationRuntimeGate: async () => { if (options.gateThrow) throw new Error('Controlled runtime transport failure'); return !options.gateOff; } },
    './translation-runtime-gate': { premiumTranslationRuntimeGate: async () => { if (options.gateThrow) throw new Error('Controlled runtime transport failure'); return !options.gateOff; } },
    '@/lib/publication': { requestPublicBuild: async input => { events.push('public-request'); builds.push({ ...input, supabase: '[installed SDK]' }); return { state: 'queued' }; } },
    '@/lib/site-copy-catalog': { loadAllSiteCopyKeys: async () => new Set([key]) },
    '@/lib/editorial-catalog': { loadEditorialCatalog: forbid, editorialCountry: forbid, editorialWriter: forbid },
    '@/lib/auto-translate-literary-work-safe': {}, '@/lib/auto-translate-writer-biography': {},
    './auto-translate-country-profile': { countryProfileTranslationSource: forbid, validateCountryTranslationCandidate: forbid },
    './auto-translate-literary-work': { validateLiteraryWorkTranslationCandidate: forbid },
    './auto-translate-writer-biography': { validateWriterBiographyTranslationCandidate: forbid, writerBiographyTranslationOwnership: forbid, writerBiographyTranslationSource: forbid },
    './writer-biography-edit': { writerBiographySourceIdentity: forbid },
    'next/cache': { revalidatePath() {} },
  };
  loaded = modules(mocks);
  if (options.legacyCurrentRaw) {
    row.settings.siteCopy.ru[key] = '  Найти книги\r\n\u2014 в каталоге  ';
    const projected = loaded.load('apps/admin/lib/site-copy-storage.ts').readSiteCopyValues(row.settings.siteCopy).ru[key];
    row.settings.premiumTranslation.siteCopyEn[key].sourceHash = digest({ key, text: projected });
    Object.assign(before, structuredClone(row));
  }
  if (options.rawCanonical) {
    row.settings.siteCopy.ru[key] = '  Найти книги\r\n\u2014 в каталоге  ';
    row.settings.siteCopy.en[key] = '  Previously accepted \u2014 English\r\nwith raw spacing  ';
    row.settings.siteCopy.ru['interface.Право'] = '';
    row.settings.siteCopy.en['interface.Право'] = { rights: ['Keep raw authored value', null] };
    Object.assign(before, structuredClone(row));
  }
  if (options.savePreservation) {
    row.settings.siteCopy.ru[key] = '  Основной русский\r\n\u2014 текст  ';
    row.settings.siteCopy.en[key] = '  Human English \u2014 draft\r\nwith author spacing  ';
    row.settings.siteCopy.ru['interface.Сосед'] = '  Соседний русский\r\n\u2014 текст  ';
    row.settings.siteCopy.en['interface.Сосед'] = '  Accepted neighbour \u2014 English\r\nwith original spacing  ';
    row.settings.siteCopy.ru['interface.Пустой'] = '  \r\n  ';
    row.settings.siteCopy.en['interface.Пустой'] = null;
    const projected = loaded.load('apps/admin/lib/site-copy-storage.ts').readSiteCopyValues(row.settings.siteCopy);
    row.settings.premiumTranslation.siteCopyEn['interface.Сосед'] = { sourceHash: digest({ key: 'interface.Сосед', text: projected.ru['interface.Сосед'] }),
      model: 'admitted-neighbour', authorRights: { owner: 'Keep exact neighbour metadata' } };
    row.settings.premiumTranslation.siteCopyEn['interface.Пустой'] = { sourceHash: 'f'.repeat(64), authorRights: { owner: 'Keep tombstone marker' } };
    if (options.savePreservation === 'english-only') row.settings.premiumTranslation.siteCopyEn[key] = { sourceHash: digest({ key, text: projected.ru[key] }), model: 'admitted-original' };
    else delete row.settings.premiumTranslation.siteCopyEn[key];
    Object.assign(before, structuredClone(row));
  }
  const publicView = () => loaded.load('scripts/site-copy-overrides.mjs').extractSiteCopyFromHomepageBlocks([row]).siteCopy;
  async function action(file, name, form) {
    try { await loaded.load(file)[name](form); throw new Error('Action did not redirect'); }
    catch (error) { assert.equal(isRedirectError(error), true, error.stack); return new URL(getURLFromRedirectError(error), 'https://admin.fixture.invalid').href; }
  }
  const invoke = (extra = {}) => loaded.load(helperFile).ensureSiteCopyEnglishTranslation({ supabase: sdk, actorId, blockId, ...extra });
  const batch = () => action('apps/admin/app/(dashboard)/translations/actions.ts', 'translatePremiumSiteCopyBatchAction', new FormData());
  const save = () => {
    const form = new FormData(); form.set('expected_updated_at', row?.updated_at || stamp);
    form.append('copy_key', key); form.append('copy_ru', `${russianText} \u2014 новое`); form.append('copy_en', canonicalEnglish);
    return action('apps/admin/app/(dashboard)/site-copy/actions.ts', 'saveSiteCopyAction', form);
  };
  const saveProjected = (change = {}) => {
    const projected = loaded.load('apps/admin/lib/site-copy-storage.ts').readSiteCopyValues(row.settings.siteCopy);
    const form = new FormData(); form.set('expected_updated_at', row.updated_at);
    for (const copyKey of Object.keys(row.settings.siteCopy.ru)) {
      form.append('copy_key', copyKey);
      form.append('copy_ru', copyKey === key && Object.hasOwn(change, 'ru') ? change.ru : projected.ru[copyKey] || '');
      form.append('copy_en', copyKey === key && Object.hasOwn(change, 'en') ? change.en : projected.en[copyKey] || '');
    }
    return action('apps/admin/app/(dashboard)/site-copy/actions.ts', 'saveSiteCopyAction', form);
  };
  const loadReview = () => loaded.load('apps/admin/lib/premium-translation-review.ts').loadPremiumTranslationReview({ supabase: sdk, entityType: 'site_copy', entityId: blockId });
  const reviewForm = (confirm = true, extra = {}) => {
    assert.ok(privateDraft); const form = new FormData();
    for (const [field, value] of Object.entries({ entity_type: 'site_copy', entity_id: blockId, draft_id: privateDraft.id,
      expected_version: String(privateDraft.version), candidate_hash: privateDraft.candidateHash, return_to: 'site-copy',
      ...(confirm ? { confirm_human_review: 'yes' } : {}), ...extra })) form.set(field, value);
    return form;
  };
  const reviewAction = (form, discard = false) => action('apps/admin/app/(dashboard)/translations/premium-review-actions.ts',
    discard ? 'discardPremiumTranslationWorkingDraftAction' : 'approvePremiumTranslationWorkingDraftAction', form);
  const renderReview = view => {
    const { renderToStaticMarkup } = nativeRequire('react-dom/server'), { createElement } = nativeRequire('react'), { load: loadHtml } = nativeRequire('cheerio');
    const Panel = loaded.load('apps/admin/components/PremiumTranslationReviewPanel.tsx').default;
    const html = renderToStaticMarkup(createElement(Panel, { view, returnTo: 'site-copy' })), dom = loadHtml(html);
    return { html, checkboxes: dom('[name="confirm_human_review"]').length,
      required: dom('[name="confirm_human_review"]').is('[required]'), identity: dom('[name="entity_id"]').first().attr('value'),
      approvalForms: dom('form').filter((_, element) => dom(element).find('[name="confirm_human_review"]').length).length };
  };
  return { invoke, batch, save, saveProjected, loadReview, reviewForm, reviewAction, renderReview, snapshot, before, publicView, providerCalls,
    ai, wire, builds, mutations, stages, promotions, discards, runs, events, loaded,
    changeSource() { row.settings.siteCopy.ru[key] = 'Другой русский исходник'; row.updated_at = newStamp(); },
    changeRawSettings() { row.settings.authoredSettings.permission.push({ changedRights: true }); row.updated_at = newStamp(); },
    changeTarget() { row.updated_at = newStamp(); },
    manualTakeover() { row.settings.siteCopy.en[key] = 'Human editor takeover'; delete row.settings.premiumTranslation.siteCopyEn[key]; row.updated_at = newStamp(); },
    get privateDraft() { return structuredClone(privateDraft); } };
}
function record(name, view, result) {
  traces.push({ name, result, originalRow: view.before, rowAfter: view.snapshot(), publicAfter: view.publicView(),
    privateDraft: view.privateDraft, providerCalls: view.providerCalls, wire: view.wire, builds: view.builds, mutations: view.mutations, events: view.events });
}
