// Same safety oracle for genuine BEFORE and a later, separately declared CURRENT observer.
const fs=require('node:fs'),assert=require('node:assert/strict');
const report=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
assert.equal(report.scenarios.length,11);
const checks=[];
for(const row of report.scenarios){
 const name=`${row.kind}/${row.mode}`;
 checks.push({name:name+':canonical-and-publication-preserved',category:'preservation',pass:JSON.stringify(row.canonicalBefore)===JSON.stringify(row.canonicalAfter)&&row.canonicalWrites===0&&row.publicBuildRequests===0});
 if(row.kind==='site_copy'){
  const translations=row.providerCalls.filter(c=>c.pass==='translation').length;
  checks.push({name:name+':no-regeneration-of-same-source',category:'target',pass:translations===1,
   expected:'One original translator call; an unknown outcome remains held. A confirmed partial pass may be continued only through a separately authorized fresh source/config/call-budget protocol.',actual:{translations,totalProviderCalls:row.totalProviderCalls,passes:row.passes}});
 }else{
  const complete=row.mode==='complete-recovery';
  checks.push({name:name+':existing-safety-control',category:'control',pass:complete?row.totalProviderCalls===2&&row.finalCandidates===1:row.totalProviderCalls===1&&row.finalCandidates===0,
   scope:complete?'Complete retained result recovers without regeneration':'A read/fresh helper invocation is not an explicit authority to resume an unfinished paid operation'});
 }
}
const summary={checks:checks.length,pass:checks.filter(c=>c.pass).length,fail:checks.filter(c=>!c.pass).length,targetFail:checks.filter(c=>!c.pass&&c.category==='target').length,preservationFail:checks.filter(c=>!c.pass&&c.category==='preservation').length,controlFail:checks.filter(c=>!c.pass&&c.category==='control').length};
process.stdout.write(JSON.stringify({contractVersion:1,checks,summary},null,2)+'\n');process.exitCode=summary.fail?1:0;
