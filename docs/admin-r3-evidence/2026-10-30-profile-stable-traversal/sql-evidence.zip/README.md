# Profile stable traversal: native proof

This archive contains actual isolated PG17 core requests/results, ten real
two-session groups, two real three-session lock graphs, native five-RPC wire
receipts, complete old-routine/table/index comparison and advisor/cleanup logs.
The exact final source inputs and their scope are in summary.json.

All earlier failed files and successful intermediate versions are retained with
their original manifests. A v4 fixture helper with search_path='' first used an
unqualified SET CONSTRAINTS; its corrected local fixture-only retry is declared
and the full final fixture runs from a fresh database. No paid routine was
replaced to make a fixture pass. No omitted/reconstructed baseline is used.

The final committed10000 measurement includes COMMIT/deferred validation and
actual pg_stat function counters. A20 job-insert bound is not10000 item events.
The full immutable manifest is proved before RETURN and again at root COMMIT;
strict immediate child lineage prevents bypass by a direct future UUID.

Inspect separate controlled/SDK and full-source validation artifacts before
making any application acceptance claim. This native artifact does not finish
M07, the26-module R3 goal, managed acceptance or real environment setup.
