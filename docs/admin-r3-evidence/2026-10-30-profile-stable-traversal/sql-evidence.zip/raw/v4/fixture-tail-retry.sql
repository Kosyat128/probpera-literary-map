-- Immediate child/root proofs plus one root committed full-chain assertion.
-- Each deliberately malformed construction is contained in a subtransaction.
create or replace function public.profile_scan_fixture_reject_eager_child(mode text)
returns boolean language plpgsql set search_path='' as $$
declare template public.translation_jobs%rowtype;root_id uuid:=gen_random_uuid();child_id uuid:=gen_random_uuid();
 root_marker jsonb;child_marker jsonb;child_kind text:='country';child_provider text:='cloudflare';child_actor uuid;
 child_total integer:=1;rejected boolean:=false;
begin
 select * into template from public.translation_jobs where resume_cursor#>>'{profileScan,windowIndex}'='0' and resume_cursor#>>'{profileScan,totalMembership}'='501' limit 1;
 child_actor:=template.requested_by;
 root_marker:=template.resume_cursor->'profileScan'||jsonb_build_object('scanId',root_id,'nextPosition',0,'exhausted',false,'activeChild',null,'lastTransition',null,'successorJobId',child_id);
 select resume_cursor->'profileScan' into child_marker from public.translation_jobs where id=(template.resume_cursor#>>'{profileScan,successorJobId}')::uuid;
 child_marker:=child_marker||jsonb_build_object('scanId',root_id,'predecessorJobId',root_id,'nextPosition',0,'exhausted',false,'activeChild',null,'lastTransition',null);
 case mode
 when 'without-root' then null;
 when 'outside-index' then child_marker:=child_marker||'{"windowIndex":2}';
 when 'root-configuration' then child_marker:=jsonb_set(child_marker,'{configurationHash}',to_jsonb(repeat('c',64)));
 when 'root-manifest' then child_marker:=jsonb_set(child_marker,'{fullManifestHash}',to_jsonb(repeat('c',64)));
 when 'root-kind' then child_kind:='writer';
 when 'root-provider' then child_provider:='openai';
 when 'root-actor' then child_actor:='22222222-2222-4222-8222-222222222222';
 when 'root-count' then child_total:=500;child_marker:=child_marker||jsonb_build_object('totalMembership',1001,'windowCount',3,'lastWindow',false,'successorJobId',gen_random_uuid(),'catalogSourceHashes',root_marker->'catalogSourceHashes');
 when 'wrong-predecessor' then child_marker:=jsonb_set(child_marker,'{predecessorJobId}',to_jsonb(gen_random_uuid()));
 when 'wrong-parent-pointer' then root_marker:=jsonb_set(root_marker,'{successorJobId}',to_jsonb(gen_random_uuid()));
 when 'missing-middle' then
  root_marker:=root_marker||jsonb_build_object('totalMembership',1001,'windowCount',3,'successorJobId',gen_random_uuid());
  child_marker:=child_marker||jsonb_build_object('totalMembership',1001,'windowCount',3,'windowIndex',2,'predecessorJobId',root_marker->'successorJobId');
 when 'missing-last' then null;
 when 'missing-members' then null;
 when 'committed-additional' then
  root_id:=template.id;child_marker:=child_marker||jsonb_build_object('scanId',root_id,'predecessorJobId',root_id);
 else raise exception 'Unknown native malformed eager case';end case;
 begin
  if mode not in ('without-root','committed-additional') then
   insert into public.translation_jobs(id,kind,provider,status,total_items,succeeded_items,failed_items,requested_by,started_at,version,resume_cursor)
    values(root_id,'country','cloudflare','reviewing',500,0,0,template.requested_by,clock_timestamp(),1,jsonb_build_object('profileScan',root_marker));
  end if;
  if mode<>'missing-last' then
   insert into public.translation_jobs(id,kind,provider,status,total_items,succeeded_items,failed_items,requested_by,started_at,version,resume_cursor)
    values(child_id,child_kind,child_provider,'reviewing',child_total,0,0,child_actor,clock_timestamp(),1,jsonb_build_object('profileScan',child_marker));
  end if;
  set constraints public.translation_profile_scan_committed_chain immediate;
 exception when insufficient_privilege then rejected:=true;
 end;
 assert rejected and not exists(select 1 from public.translation_jobs where id=child_id);
 if mode<>'committed-additional' then assert not exists(select 1 from public.translation_jobs where id=root_id);end if;
 return true;
end; $$;
do $$ declare mode text;cases jsonb:='[]';before_count bigint;r jsonb;rejected boolean:=false;root_id uuid;begin
 foreach mode in array array['without-root','outside-index','root-configuration','root-manifest','root-kind','root-provider','root-actor','root-count','wrong-predecessor','wrong-parent-pointer','missing-middle','missing-last','missing-members','committed-additional'] loop
  assert public.profile_scan_fixture_reject_eager_child(mode);cases:=cases||to_jsonb(mode);
 end loop;
 select count(*) into before_count from public.translation_jobs;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 begin
  set constraints public.translation_profile_scan_committed_chain immediate;
  perform public.begin_profile_translation_scan(gen_random_uuid(),'country',public.profile_scan_fixture_config('country'),public.profile_scan_fixture_manifest('country',2));
 exception when insufficient_privilege then rejected:=true;
 end;
 assert rejected and (select count(*)=before_count from public.translation_jobs);
 set constraints public.translation_profile_scan_committed_chain deferred;
 set local role authenticated;
 r:=public.profile_scan_fixture_begin('country',public.profile_scan_fixture_manifest('country',2));
 set constraints public.translation_profile_scan_committed_chain immediate;
 assert r->'totalItems'='2'::jsonb;reset role;
 select id into root_id from public.translation_jobs where resume_cursor#>>'{profileScan,windowIndex}'='0' and resume_cursor#>>'{profileScan,totalMembership}'='501' limit 1;
 perform public.premium_fixture_error(format('delete from public.translation_jobs where id=%L',root_id),'42501');
 perform public.premium_fixture_error(format('update public.translation_jobs set resume_cursor=jsonb_set(resume_cursor,''{profileScan,fullManifestHash}'',to_jsonb(repeat(''c'',64))),version=version+1 where id=%L',root_id),'42501');
 insert into public.profile_scan_fixture_results values('eager-root-child-forgeries',jsonb_build_object('rejected',cases,'allRolledBack',true,'setImmediateBeforeCompleteRejected',true,'setImmediateAfterCompletePassed',true,'committedDeleteAndReplacementDenied',true));
end; $$;
select 'M07_PROFILE_SCAN_EAGER_ROOT_AND_CHILD_PROOFS_PASS';
