select jsonb_object_agg(label,value) from public.profile_scan_fixture_baseline;
