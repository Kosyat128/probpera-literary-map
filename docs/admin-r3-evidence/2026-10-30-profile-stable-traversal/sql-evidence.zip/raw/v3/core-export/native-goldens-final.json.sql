select coalesce(jsonb_agg(jsonb_build_object('rpc',rpc,'args',args,'response',response) order by at_time,id),'[]') from public.profile_scan_fixture_wire;
