﻿$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\profile-scan-sql-native\v5'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-final.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8'
 $psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not the owned isolated cluster'}
 $database='profile_scan_v5_20261030'

 foreach($name in @('native-baseline.json','native-cases-final.json','native-goldens-final.json','native-functions-final.json','native-tables-final.json','native-indexes-final.json','native-constraints-final.json')){
  $file=Join-Path $nativeRoot ($name+'.sql')
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f $file 2> (Join-Path $nativeRoot ($name+'.stderr.log'))
  if($LASTEXITCODE -ne 0){throw ('Native export failed '+$name)}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $name),($raw -join "
"),[Text.UTF8Encoding]::new($false))
 }
 $available=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc -Atc "select count(*) from pg_available_extensions where name='plpgsql_check'"
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1'
 $env:SUPABASE_HOME='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\profile-scan-sql-native\v5\cli-home'
 $cli='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\portable-db-tools\supabase-2.120.0\supabase.exe'
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$database+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors-final.log')
 $advisorExit=$LASTEXITCODE
 [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');target=('owned loopback '+$database);advisorsExitCode=$advisorExit;lintStatus='NOT_RUN_PLPGSQL_CHECK_UNAVAILABLE_NO_INSTALL';plpgsqlCheckAvailable=[int]$available;installedAnything=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-final.json') -Encoding utf8
 Write-Output 'FINAL_PROFILE_NATIVE_METADATA_ACL_INDEXES_ADVISORS_EXPORTED'
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'final-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'final-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
