set track_functions='all';
select pg_stat_reset_single_function_counters('probpera_translation_operations.profile_scan_insert_chain_guard()'::regprocedure);
select pg_stat_reset_single_function_counters('probpera_translation_operations.profile_scan_assert_chain(uuid)'::regprocedure);
\timing on
begin;
set local role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
select jsonb_build_object('scanId',r->'scanId','totalMembership',r->'totalMembership','windowCount',r->'windowCount') from(select public.begin_profile_translation_scan(gen_random_uuid(),'writer',public.profile_scan_fixture_config('writer'),public.profile_scan_fixture_manifest('writer',10000))r)s;
commit;
select pg_stat_force_next_flush();
select pg_stat_clear_snapshot();
select jsonb_build_object('function',funcname,'calls',calls,'totalTimeMs',total_time,'selfTimeMs',self_time) from pg_stat_user_functions where funcid in ('probpera_translation_operations.profile_scan_insert_chain_guard()'::regprocedure,'probpera_translation_operations.profile_scan_assert_chain(uuid)'::regprocedure) order by funcname;
