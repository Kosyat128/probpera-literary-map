# Parent-only profile adapter draft

`profile-translation-scan-rpc.draft.ts` is a proposed adapter for a future `apps/admin/lib/profile-translation-scan-rpc.ts`; its relative imports deliberately target that future location. `rpc-contract.json` defines the five proposed native RPCs, exact arguments, metadata DTOs, bounds and eager construction requirements. No maintained source, migration or profile implementation is created here.

The full ordered tuple/hash manifest is frozen at BEGIN, with<=10000 records/4MiB and<=500 per window. Reject overflow; never truncate. Country IDs retain the existing working-draft limit of120 UTF-16 code units. Writer IDs retain the existing identity parser's180 Unicode code-point limit (up to360 UTF-16 units). Preserve exact identities and old JavaScript catalogSourceHash strings; native full/window JSONB fingerprints remain opaque.

The major difference from the library protocol is eager successors. A profile window already has a successor pointer while it is unfinished. Attachment must allow that immutable pointer, and continuation can follow it only after current membership is fully disposed and no child remains. Copying the library engine's pointer-based shortcut would skip unfinished profile windows.

Atomic eager lineage needs a committed-state integrity check because both predecessor and successor IDs cannot all exist at the first row insertion. The proposed contract allocates every job ID, inserts all windows/items in one transaction and uses a new deferred constraint trigger only on job INSERT (at most20 invocations), plus an explicit final chain check before BEGIN returns. Immediate immutable item guards and a complete initial count with unique contiguous legal positions prevent later insert/delete; job updates verify local proofs. This avoids a full deferred chain check on each of10000 items. It is a design tradeoff awaiting native verification, not an implemented trigger. There is no public construction bypass, GUC bypass or new column.

The prior `b92b...` draft and `d06a...` contract, with their earlier43-check result, are preserved under `prior-b92b-d06/`.

Nested child receipts use the actual existing writer or country parser. Attached children match exact member catalog hash, tuple, actor/provider/config and public CURRENT cursor. FINISHED receipts expose NEXT except the old zero-call skipped case, which remains CURRENT. The native attachment must also check private confirmed NEXT. Observed foreign/different-config metadata remains a hold with no capabilities or private-body access.

This prep is grounded in the unchanged a988 contract and genuine5489 BEFORE. The current library-updated profile diagnostic still has six failing coverage/no-repeat targets out of eight. A global catalog fingerprint stale-stop is not a substitute for original-member coverage. Native DB/ACL/concurrency, full actual action/helper integration, admin E2E, item/version retry and M07/R3 acceptance remain unverified.
