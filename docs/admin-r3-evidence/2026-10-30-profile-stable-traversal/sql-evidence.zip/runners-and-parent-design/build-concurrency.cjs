const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const version=process.argv[2];assert.match(version||'',/^v\d+$/);
const out=path.resolve(__dirname,'../profile-scan-sql-native',version),template=fs.readFileSync(path.join(out,'export.ps1'),'utf8').replace(/^\uFEFF/,'');
const start=template.indexOf(' foreach($name in @(');assert(start>0);
let prefix=template.slice(0,start).replaceAll('postgres-final.log','postgres-concurrency.log').replace('$started=$false','$started=$false;$exitCode=1');
let tail=template.slice(template.indexOf('}finally{')).replaceAll('final-cleanup','concurrency-cleanup');
const body=`
 & 'C:\\Users\\Костя\\AppData\\Local\\Programs\\Python\\Python314\\python.exe' 'C:\\Users\\685F~1\\DOCUME~1\\Codex\\2026-1~1\\v\\work\\m07-t12-profile-adapter-draft-20261030-sol\\profile-concurrency.py' '${version}'
 $exitCode=$LASTEXITCODE
 if($exitCode -ne 0){throw 'Actual concurrent SQL session assertions failed; raw files retained'}
`;
fs.writeFileSync(path.join(out,'run-concurrency.ps1'),'\uFEFF'+prefix+body+tail+'\nexit $exitCode\n');
console.log(JSON.stringify({classification:'PREPARED_NOT_EXECUTED',file:path.join(out,'run-concurrency.ps1')}));
