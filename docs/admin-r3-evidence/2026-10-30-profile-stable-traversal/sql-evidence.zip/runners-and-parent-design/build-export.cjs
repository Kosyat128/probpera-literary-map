const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const version=process.argv[2];assert.match(version||'',/^v\d+$/);
const root=path.resolve(__dirname,'../profile-scan-sql-native'),out=path.join(root,version),prior=path.resolve(__dirname,'../library-scan-sql-native/export-final.ps1');
const template=fs.readFileSync(prior,'utf8'),split=template.indexOf(' $queries=@{');assert(split>0);
let prefix=template.slice(0,split).replaceAll('library-scan-sql-native','profile-scan-sql-native\\'+version).replaceAll('library_scan_v8_20261030',`profile_scan_${version}_20261030`);
const functions=`select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'source',p.prosrc,'securityDefiner',p.prosecdef,'config',p.proconfig,'acl',p.proacl) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in ('premium_translation_private','probpera_translation_operations') or(n.nspname='public' and p.proname not like '%fixture%' and(p.proname like '%translation%' or p.proname like '%premium%'))`;
const tables=`select jsonb_agg(jsonb_build_object('name',c.oid::regclass::text,'acl',c.relacl,'forceRls',c.relforcerowsecurity,'rls',c.relrowsecurity,'columns',(select jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull) order by a.attnum) from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped)) order by c.oid::regclass::text) from pg_class c where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass)`;
const indexes=`select jsonb_agg(jsonb_build_object('schema',n.nspname,'name',ci.relname,'definition',pg_get_indexdef(ci.oid)) order by n.nspname,ci.relname) from pg_index i join pg_class c on c.oid=i.indrelid join pg_class ci on ci.oid=i.indexrelid join pg_namespace n on n.oid=ci.relnamespace where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass)`;
const queries={
 'native-baseline.json':'select jsonb_object_agg(label,value) from public.profile_scan_fixture_baseline',
 'native-cases-final.json':'select jsonb_object_agg(label,value) from public.profile_scan_fixture_results',
 'native-goldens-final.json':"select coalesce(jsonb_agg(jsonb_build_object('rpc',rpc,'args',args,'response',response) order by at_time,id),'[]') from public.profile_scan_fixture_wire",
 'native-functions-final.json':functions,'native-tables-final.json':tables,'native-indexes-final.json':indexes,
 'native-constraints-final.json':"select jsonb_agg(jsonb_build_object('name',tgname,'table',tgrelid::regclass::text,'type',tgtype,'deferrable',tgdeferrable,'initiallyDeferred',tginitdeferred,'function',tgfoid::regprocedure::text,'definition',pg_get_triggerdef(oid)) order by tgname) from pg_trigger where tgname like '%profile_scan%'",
};
for(const[name,sql]of Object.entries(queries))fs.writeFileSync(path.join(out,name+'.sql'),sql+';\n');
let body=`
 foreach($name in @(${Object.keys(queries).map(name=>`'${name}'`).join(',')})){
  $file=Join-Path $nativeRoot ($name+'.sql')
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f $file 2> (Join-Path $nativeRoot ($name+'.stderr.log'))
  if($LASTEXITCODE -ne 0){throw ('Native export failed '+$name)}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $name),($raw -join "\n"),[Text.UTF8Encoding]::new($false))
 }
`;
const advisorsStart=template.indexOf(' $available='),advisorsEnd=template.indexOf(" Write-Output 'FINAL_LIBRARY_NATIVE",advisorsStart);assert(advisorsStart>0&&advisorsEnd>advisorsStart);
body+=template.slice(advisorsStart,advisorsEnd).replaceAll('library-scan-sql-native','profile-scan-sql-native\\'+version);
body+=" Write-Output 'FINAL_PROFILE_NATIVE_METADATA_ACL_INDEXES_ADVISORS_EXPORTED'\n";
const tail=template.slice(template.indexOf('}finally{')).replaceAll('library-scan-sql-native','profile-scan-sql-native\\'+version);
fs.writeFileSync(path.join(out,'export.ps1'),'\uFEFF'+prefix+body+tail);
console.log(JSON.stringify({classification:'EXPORT_PREPARED_NOT_EXECUTED',version,queries:Object.keys(queries).length}));
