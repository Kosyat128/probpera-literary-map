"""Reuse the exact parent harness primitives for two actual three-session graphs."""
import pathlib
base=pathlib.Path(__file__).with_name('profile-concurrency.py')
source=base.read_text(encoding='utf-8')
prefix=source.split('\ntry:\n    # Duplicate atomic eager chain:',1)[0]
assert len(prefix)<len(source)
prefix=prefix.replace("/version/'concurrency'", "/version/'three-session'")
exec(compile(prefix,str(base),'exec'),globals())
try:
    for kind in ['writer','country']:
        args_seed,scan,child=setup(kind,'three-session-'+token)
        cache='writer_operation_artifacts' if kind=='writer' else 'catalog_operation_artifacts'
        a=session(kind+'-three-cache',"begin;select operation_id from premium_translation_private."+cache+" where operation_id="+sql_literal(child['operationId'])+" for update;select pg_sleep(2.0);"+role+'select '+dispatch(kind,child)+';commit;')
        sleeping=barrier(a,True)
        b=session(kind+'-three-entity','begin;'+role+'select public.profile_scan_fixture_paid_begin('+sql_literal(kind)+','+json_literal(args_seed)+');commit;')
        waiting_b=barrier(b)
        c=session(kind+'-three-checkpoint','begin;'+role+'select public.profile_scan_fixture_free('+json_literal(scan)+",'skipped','source_missing');commit;")
        waiting_c=barrier(c)
        one,two,three=finish(a),finish(b),finish(c)
        assert one['receipt']['providerCalls']==1 and not two['receipt']['canExecute']
        assert three['receipt']['nextPosition']==0 and three['receipt']['transition']=='held'
        assert waiting_b['blockingPids']==[sleeping['pid']] and waiting_c['blockingPids']==[waiting_b['pid']]
        results[kind+'-cache-entity-checkpoint']={'sessions':[one,two,three],'actualCacheBarrier':sleeping,'actualEntityWait':waiting_b,'actualCheckpointWait':waiting_c,'deadlock':False}
        save()
    (out/'results.json').write_text(json.dumps({'classification':'ACTUAL_THREE_SESSION_CACHE_ENTITY_PARENT_GRAPH_NOT_MANAGED_E2E','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'groups':results,'pass':len(results),'fail':0,'providerCalls':0},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'pass':len(results),'fail':0,'groups':list(results),'out':str(out)}))
finally:
    for s in processes:
        if s['process'].poll() is None:
            s['process'].terminate()
            try:s['process'].wait(timeout=10)
            except subprocess.TimeoutExpired:s['process'].kill();s['process'].wait(timeout=10)
        if not s['stdout'].closed:s['stdout'].close()
        if not s['stderr'].closed:s['stderr'].close()
    (out/'session-cleanup.json').write_text(json.dumps({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sessions':[{'label':s['label'],'pid':s['process'].pid,'exitCode':s['process'].poll()} for s in processes],'allTerminal':all(s['process'].poll() is not None for s in processes)},indent=2)+'\n',encoding='utf-8')
