const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const here = __dirname;
const repo = path.resolve(here, '../../probpera-literary-map');
const libraryPath = path.join(repo, 'supabase/migrations/20261029235455_library_translation_stable_scan.sql');
const library = fs.readFileSync(libraryPath, 'utf8');
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
assert.equal(hash(Buffer.from(library)), '1966f749db15362b245d32b0e5b355b3f37dc4c154e2381c578b5ba11aba721b');
function extract(name) {
  const start = library.indexOf(`create function ${name}(`);
  assert(start >= 0, name);
  const end = library.indexOf('\nend; $$;', start);
  assert(end > start, name);
  return library.slice(start, end + '\nend; $$;'.length);
}
function once(text, before, after) {
  assert(text.includes(before), `Missing transformation: ${before.slice(0, 130)}`);
  assert.equal(text.indexOf(before), text.lastIndexOf(before), `Ambiguous transformation: ${before.slice(0, 80)}`);
  return text.replace(before, after);
}
const chunks = [];
chunks.push(`-- PARENT-ONLY PROFILE SQL DRAFT. NOT A MIGRATION. NOT EXECUTED/ACCEPTED.
-- Based on frozen library1966f749 + profile RPC contract91863703.
-- No old paid API/cache/guard/index or scalar DTO is replaced.
-- Future native validation and root release are required before CLI landing.
begin;

create function probpera_translation_operations.profile_scan_configuration_valid(kind text,v jsonb)
returns boolean language sql immutable security invoker set search_path='' as $$
 select case kind when 'writer' then premium_translation_private.writer_operation_configuration_valid(v,v->>'provider')
  when 'country' then premium_translation_private.catalog_operation_configuration_valid('country',v,v->>'provider') else false end;
$$;

create function probpera_translation_operations.profile_scan_record(kind text,entity text,catalog_hash text)
returns jsonb language plpgsql immutable security invoker set search_path='' as $$
begin
 if coalesce(catalog_hash,'')!~'^[a-f0-9]{64}$' then raise exception 'Invalid profile catalog hash' using errcode='22023';end if;
 if kind='writer' then
  perform premium_translation_private.assert_identity('writer_biography',entity);
  if exists(select 1 from unnest(string_to_array(split_part(entity,':',2),null::text)) glyph
   where ascii(glyph) between 0 and 31 or ascii(glyph) between 127 and 159 or premium_translation_private.trim_text(glyph)='') then
   raise exception 'Invalid profile writer identity' using errcode='22023';end if;
  return jsonb_build_object('countryId',split_part(entity,':',1),'writerId',split_part(entity,':',2),'catalogSourceHash',catalog_hash);
 elsif kind='country' then
  -- Existing country text is preserved; JavaScript length is UTF-16, not SQL code points.
  perform premium_translation_private.assert_identity('country',entity);
  if premium_translation_private.site_copy_utf16_length(entity) not between 1 and 120
   or entity is distinct from premium_translation_private.trim_text(entity)
   or exists(select 1 from unnest(string_to_array(entity,null::text)) glyph where ascii(glyph) between 0 and 31 or ascii(glyph) between 127 and 159) then
   raise exception 'Invalid profile country identity' using errcode='22023';end if;
  return jsonb_build_object('countryId',entity,'catalogSourceHash',catalog_hash);
 end if;
 raise exception 'Invalid profile kind' using errcode='22023';
end; $$;

create function probpera_translation_operations.profile_scan_manifest_valid(kind text,v jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare r jsonb;identity text;
begin
 if kind is null or kind not in ('writer','country') or jsonb_typeof(v) is distinct from 'array'
  or jsonb_array_length(v)>10000 or octet_length(v::text)>4194304 then return false;end if;
 for r in select value from jsonb_array_elements(v) loop
  if not premium_translation_private.exact_object(r,case when kind='writer' then array['countryId','writerId','catalogSourceHash'] else array['countryId','catalogSourceHash'] end)
   or jsonb_typeof(r->'countryId') is distinct from 'string' or jsonb_typeof(r->'catalogSourceHash') is distinct from 'string'
   or (kind='writer' and jsonb_typeof(r->'writerId') is distinct from 'string') then return false;end if;
  identity:=case when kind='writer' then (r->>'countryId')||':'||(r->>'writerId') else r->>'countryId' end;
  if probpera_translation_operations.profile_scan_record(kind,identity,r->>'catalogSourceHash') is distinct from r then return false;end if;
 end loop;
 return (select count(distinct case when kind='writer' then (value->>'countryId')||':'||(value->>'writerId') else value->>'countryId' end)=jsonb_array_length(v)
  from jsonb_array_elements(v));
exception when others then return false;
end; $$;

create function probpera_translation_operations.profile_scan_marker_valid(v jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare k text;n integer;windows integer;idx integer;expected integer;h jsonb;
begin
 if not premium_translation_private.exact_object(v,array['version','scanId','windowIndex','windowCount','totalMembership','predecessorJobId','successorJobId',
  'fullManifestHash','membershipHash','configurationHash','catalogSourceHashes','nextPosition','lastWindow','exhausted','activeChild','lastTransition'])
  or v->'version'<>'1'::jsonb or octet_length(v::text)>65536 then return false;end if;
 foreach k in array array['scanId','predecessorJobId','successorJobId'] loop
  if v->k<>'null'::jsonb and (jsonb_typeof(v->k)<>'string' or not probpera_translation_operations.retry_uuid((v->>k)::uuid)
   or v->>k<>((v->>k)::uuid)::text) then return false;end if;
 end loop;
 if v->'scanId'='null'::jsonb then return false;end if;
 foreach k in array array['windowIndex','windowCount','totalMembership','nextPosition'] loop
  if jsonb_typeof(v->k)<>'number' or coalesce(v->>k,'')!~'^[0-9]{1,5}$' then return false;end if;
 end loop;
 n:=(v->>'totalMembership')::integer;windows:=(v->>'windowCount')::integer;idx:=(v->>'windowIndex')::integer;
 if n>10000 or windows<>greatest(1,(n+499)/500) or windows>20 or idx>=windows then return false;end if;
 expected:=least(500,greatest(0,n-idx*500));
 if (v->>'nextPosition')::integer>expected or jsonb_typeof(v->'lastWindow')<>'boolean' or jsonb_typeof(v->'exhausted')<>'boolean'
  or v->'lastWindow' is distinct from to_jsonb(idx=windows-1)
  or (v->'exhausted'='true'::jsonb and (idx<>windows-1 or (v->>'nextPosition')::integer<>expected or v->'activeChild'<>'null'::jsonb))
  or (idx=0) is distinct from (v->'predecessorJobId'='null'::jsonb)
  or (idx=windows-1) is distinct from (v->'successorJobId'='null'::jsonb) then return false;end if;
 foreach k in array array['fullManifestHash','membershipHash','configurationHash'] loop
  if jsonb_typeof(v->k)<>'string' or coalesce(v->>k,'')!~'^[a-f0-9]{64}$' then return false;end if;
 end loop;
 if jsonb_typeof(v->'catalogSourceHashes')<>'array' or jsonb_array_length(v->'catalogSourceHashes')<>expected then return false;end if;
 for h in select value from jsonb_array_elements(v->'catalogSourceHashes') loop
  if jsonb_typeof(h)<>'string' or h#>>'{}'!~'^[a-f0-9]{64}$' then return false;end if;
 end loop;
 if v->'activeChild'<>'null'::jsonb then
  if not premium_translation_private.exact_object(v->'activeChild',array['binding','jobId','itemId','operationId','actorId','intentHash','sourceHash','configurationHash','initialProviderCalls','attachedAt'])
   or coalesce(v#>>'{activeChild,binding}','') not in ('attached','observed-blocked') or coalesce(v#>>'{activeChild,initialProviderCalls}','')!~'^[0-4]$'
   or coalesce(v#>>'{activeChild,intentHash}','')!~'^[a-f0-9]{64}$' or coalesce(v#>>'{activeChild,sourceHash}','')!~'^[a-f0-9]{64}$'
   or coalesce(v#>>'{activeChild,configurationHash}','')!~'^[a-f0-9]{64}$' then return false;end if;
  foreach k in array array['jobId','itemId','operationId','actorId'] loop
   if not probpera_translation_operations.retry_uuid((v->'activeChild'->>k)::uuid) then return false;end if;
  end loop;
  perform (v#>>'{activeChild,attachedAt}')::timestamptz;
 end if;
 if v->'lastTransition'<>'null'::jsonb then
  if not premium_translation_private.exact_object(v->'lastTransition',array['id','fingerprint','itemId','kind','operationId'])
   or not probpera_translation_operations.retry_uuid((v#>>'{lastTransition,id}')::uuid)
   or coalesce(v#>>'{lastTransition,fingerprint}','')!~'^[a-f0-9]{64}$'
   or coalesce(v#>>'{lastTransition,kind}','') not in ('created','attached','advanced','zero-call-held','held','successor','exhausted') then return false;end if;
 end if;
 return true;
exception when others then return false;
end; $$;

-- A CLOSED metadata projection, not a replacement paid receipt or private-body reader.
-- The old writer/country views and final receipts remain the sole child DTOs.
create function probpera_translation_operations.profile_scan_operation(p_kind text,p_entity_id text,p_operation_id uuid default null,p_active_only boolean default false)
returns table(operation_id uuid,job_id uuid,item_id uuid,actor_id uuid,entity_type text,entity_id text,provider text,source_hash text,intent_hash text,
 configuration_hash text,catalog_source_hash text,confirmed_cursor jsonb,current_cursor jsonb,provider_calls integer,has_pending boolean,final_receipt jsonb,receipt jsonb)
language plpgsql stable security invoker set search_path='' as $$
begin
 if p_kind='writer' then
  return query select a.operation_id,a.job_id,a.item_id,a.actor_id,'writer'::text,a.entity_id,a.provider,a.source_hash,a.intent_hash,a.configuration_hash,
   a.source_revision->>'catalogSourceHash',a.confirmed_cursor,j.resume_cursor-'writerOperation',jsonb_array_length(a.calls),
   exists(select 1 from jsonb_array_elements(a.calls) c where c#>'{metadata,responseReceivedAt}'='null'::jsonb),a.final_receipt,
   premium_translation_private.writer_operation_view(a,true,false,false)
  from premium_translation_private.writer_operation_artifacts a join public.translation_job_items i on i.id=a.item_id join public.translation_jobs j on j.id=a.job_id
  where a.entity_id=p_entity_id and (p_operation_id is null or a.operation_id=p_operation_id)
   and (not p_active_only or (i.staff_retry is not null and a.final_receipt is null))
  order by (i.staff_retry is not null) desc,a.created_at desc,a.operation_id desc limit 1;
 elsif p_kind='country' then
  return query select a.operation_id,a.job_id,a.item_id,a.actor_id,'country'::text,a.entity_id,a.provider,a.source_hash,a.intent_hash,a.configuration_hash,
   a.source_revision->>'catalogSourceHash',a.confirmed_cursor,j.resume_cursor-'catalogOperation',jsonb_array_length(a.calls),
   exists(select 1 from jsonb_array_elements(a.calls) c where c#>'{metadata,responseReceivedAt}'='null'::jsonb),a.final_receipt,
   premium_translation_private.catalog_operation_view(a,true,false,false)
  from premium_translation_private.catalog_operation_artifacts a join public.translation_job_items i on i.id=a.item_id join public.translation_jobs j on j.id=a.job_id
  where a.entity_type='country' and a.entity_id=p_entity_id and (p_operation_id is null or a.operation_id=p_operation_id)
   and (not p_active_only or (i.staff_retry is not null and a.final_receipt is null))
  order by (i.staff_retry is not null) desc,a.created_at desc,a.operation_id desc limit 1;
 else raise exception 'Invalid profile operation kind' using errcode='22023';end if;
end; $$;

create function probpera_translation_operations.profile_scan_entity_lock(kind text,entity text)
returns void language plpgsql volatile security invoker set search_path='' as $$
begin
 if kind='writer' then perform pg_advisory_xact_lock(hashtextextended('writer-operation:'||entity,7191));
 elsif kind='country' then perform pg_advisory_xact_lock(hashtextextended('catalog-operation:country:'||entity,7291));
 else raise exception 'Invalid profile lock kind' using errcode='22023';end if;
end; $$;

create function probpera_translation_operations.profile_scan_link(a jsonb,binding text)
returns jsonb language sql stable security invoker set search_path='' as $$
 select jsonb_build_object('binding',binding,'jobId',a->'job_id','itemId',a->'item_id','operationId',a->'operation_id','actorId',a->'actor_id',
  'intentHash',a->'intent_hash','sourceHash',a->'source_hash','configurationHash',a->'configuration_hash','initialProviderCalls',a->'provider_calls','attachedAt',clock_timestamp());
$$;

create function probpera_translation_operations.profile_scan_access(p_job_id uuid,p_lock boolean default false)
returns public.translation_jobs language plpgsql volatile security invoker set search_path='' as $$
declare actor uuid:=premium_translation_private.assert_actor();j public.translation_jobs%rowtype;
begin
 if not probpera_translation_operations.retry_uuid(p_job_id) then raise exception 'Invalid profile scan job' using errcode='22023';end if;
 if p_lock then select * into j from public.translation_jobs where id=p_job_id for update;
 else select * into j from public.translation_jobs where id=p_job_id;end if;
 if j.id is null then raise exception 'Profile scan job not found' using errcode='P0002';end if;
 if j.kind not in ('writer','country') or probpera_translation_operations.profile_scan_marker_valid(j.resume_cursor->'profileScan') is distinct from true then
  raise exception 'Not a stable profile scan' using errcode='22023';end if;
 if j.requested_by<>actor then raise exception 'Profile scan actor differs' using errcode='42501';end if;
 return j;
end; $$;

-- Metadata only. Past positions cannot rewind, so this takes no cache/ancestor row locks.
-- Eager successor UUIDs never authorize consuming an unfinished future window.
create function probpera_translation_operations.profile_scan_predecessors_ready(j public.translation_jobs)
returns boolean language sql stable security invoker set search_path='' as $$
 select not exists(select 1 from public.translation_jobs p where p.resume_cursor#>>'{profileScan,scanId}'=j.resume_cursor#>>'{profileScan,scanId}'
  and (p.resume_cursor#>>'{profileScan,windowIndex}')::integer<(j.resume_cursor#>>'{profileScan,windowIndex}')::integer
  and ((p.resume_cursor#>>'{profileScan,nextPosition}')::integer<>p.total_items or p.resume_cursor#>'{profileScan,activeChild}'<>'null'::jsonb));
$$;

create function probpera_translation_operations.profile_scan_assert_chain(p_scan_id uuid)
returns void language plpgsql volatile security invoker set search_path='' as $$
declare root public.translation_jobs%rowtype;j public.translation_jobs%rowtype;m jsonb;rm jsonb;ids uuid[];n integer;idx integer;
 manifest jsonb:='[]';part jsonb;cnt integer;distinct_count integer;item_count integer;
begin
 select * into root from public.translation_jobs where id=p_scan_id;rm:=root.resume_cursor->'profileScan';
 if root.id is null or probpera_translation_operations.profile_scan_marker_valid(rm) is distinct from true or rm->>'windowIndex'<>'0'
  or root.id::text<>rm->>'scanId' or root.kind not in ('writer','country') then raise exception 'Profile scan root proof missing' using errcode='42501';end if;
 select array_agg(id order by (resume_cursor#>>'{profileScan,windowIndex}')::integer),count(*) into ids,cnt
 from public.translation_jobs where resume_cursor#>>'{profileScan,scanId}'=p_scan_id::text;
 if cnt<>(rm->>'windowCount')::integer or cnt not between 1 and 20 then raise exception 'Profile window chain count differs' using errcode='42501';end if;
 for idx in 0..cnt-1 loop
  select * into j from public.translation_jobs where id=ids[idx+1];m:=j.resume_cursor->'profileScan';
  n:=least(500,greatest(0,(rm->>'totalMembership')::integer-idx*500));
  if j.kind<>root.kind or j.provider<>root.provider or j.requested_by<>root.requested_by or j.total_items<>n
   or probpera_translation_operations.profile_scan_marker_valid(m) is distinct from true or (m->>'windowIndex')::integer<>idx
   or m->'fullManifestHash' is distinct from rm->'fullManifestHash' or m->'configurationHash' is distinct from rm->'configurationHash'
   or m->'totalMembership' is distinct from rm->'totalMembership' or m->'windowCount' is distinct from rm->'windowCount'
   or m->>'predecessorJobId' is distinct from case when idx=0 then null else ids[idx]::text end
   or m->>'successorJobId' is distinct from case when idx=cnt-1 then null else ids[idx+2]::text end then
   raise exception 'Profile eager chain binding differs' using errcode='42501';end if;
  select count(*),coalesce(jsonb_agg(probpera_translation_operations.profile_scan_record(j.kind,i.entity_id,m->'catalogSourceHashes'->>i.position) order by i.position),'[]')
   into item_count,part from public.translation_job_items i where i.job_id=j.id;
  if item_count<>n or exists(select 1 from public.translation_job_items i where i.job_id=j.id and
   (i.position>=n or i.entity_type<>j.kind or (i.position<(m->>'nextPosition')::integer) is distinct from (i.status<>'reviewing')))
   or probpera_translation_operations.retry_fingerprint(part)<>m->>'membershipHash' then raise exception 'Profile immutable member proof differs' using errcode='42501';end if;
  manifest:=manifest||part;
 end loop;
 if jsonb_array_length(manifest)<>(rm->>'totalMembership')::integer or probpera_translation_operations.profile_scan_manifest_valid(root.kind,manifest) is distinct from true
  or probpera_translation_operations.retry_fingerprint(manifest)<>rm->>'fullManifestHash' then raise exception 'Profile full manifest proof differs' using errcode='42501';end if;
end; $$;

create function probpera_translation_operations.profile_scan_insert_chain_guard()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.resume_cursor?'profileScan' then perform probpera_translation_operations.profile_scan_assert_chain((new.resume_cursor#>>'{profileScan,scanId}')::uuid);end if;
 return new;
end; $$;

create function probpera_translation_operations.profile_scan_view(j public.translation_jobs,p_replayed boolean default false,p_transition text default 'read')
returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare m jsonb:=j.resume_cursor->'profileScan';members jsonb;part jsonb;member public.translation_job_items%rowtype;a record;
 link jsonb;child jsonb:='null';reason text;cnt integer;fingerprint text;
begin
 select coalesce(jsonb_agg(jsonb_build_object('itemId',i.id,'position',i.position,'entityId',i.entity_id,'status',i.status)
  ||probpera_translation_operations.profile_scan_record(j.kind,i.entity_id,m->'catalogSourceHashes'->>i.position) order by i.position),'[]'),
  count(*),probpera_translation_operations.retry_fingerprint(coalesce(jsonb_agg(probpera_translation_operations.profile_scan_record(j.kind,i.entity_id,m->'catalogSourceHashes'->>i.position) order by i.position),'[]'))
 into members,cnt,fingerprint from public.translation_job_items i where i.job_id=j.id;
 if cnt<>j.total_items or fingerprint<>m->>'membershipHash' or (m->>'nextPosition')::integer>cnt
  or exists(select 1 from public.translation_job_items i where i.job_id=j.id and (i.position<(m->>'nextPosition')::integer) is distinct from (i.status<>'reviewing')) then
  raise exception 'Profile scan membership differs' using errcode='40001';end if;
 select * into member from public.translation_job_items where job_id=j.id and position=(m->>'nextPosition')::integer;
 if m->'activeChild'<>'null'::jsonb then
  link:=m->'activeChild';select * into a from probpera_translation_operations.profile_scan_operation(j.kind,member.entity_id,(link->>'operationId')::uuid,false);
  if a.operation_id is null or a.job_id::text<>link->>'jobId' or a.item_id::text<>link->>'itemId' or a.intent_hash<>link->>'intentHash'
   or a.actor_id::text<>link->>'actorId' or a.source_hash<>link->>'sourceHash' or a.configuration_hash<>link->>'configurationHash' then
   raise exception 'Profile scan child binding differs' using errcode='40001';end if;
 elsif member.id is not null and p_transition not in ('advanced','zero-call-held') then
  select * into a from probpera_translation_operations.profile_scan_operation(j.kind,member.entity_id,null,true);
  if a.operation_id is not null then link:=probpera_translation_operations.profile_scan_link(to_jsonb(a),'observed-blocked');end if;
 else select * into a from probpera_translation_operations.profile_scan_operation(j.kind,'',null,true);
 end if;
 if a.operation_id is not null then
  child:=jsonb_build_object('binding',link->'binding','initialProviderCalls',link->'initialProviderCalls','receipt',a.receipt);
  if a.actor_id<>j.requested_by then reason:='child_owned_by_another_actor';
  elsif exists(select 1 from public.translation_jobs x where x.id<>j.id and x.resume_cursor#>>'{profileScan,activeChild,binding}'='attached'
   and x.resume_cursor#>>'{profileScan,activeChild,operationId}'=a.operation_id::text) then reason:='child_attached_to_another_scan';else reason:='child_pending';end if;
 end if;
 if j.cancel_requested_at is not null or j.status in ('cancelled','cancelling') then reason:='scan_stopped';
 elsif reason is null and (m->>'nextPosition')::integer=j.total_items and m->'exhausted'='false'::jsonb then reason:='window_complete';end if;
 return jsonb_build_object('version',1,'scanId',m->'scanId','jobId',j.id,'jobVersion',j.version::text,'actorId',j.requested_by,'kind',j.kind,'provider',j.provider,'status',j.status,
  'configurationHash',m->'configurationHash','fullManifestHash',m->'fullManifestHash','membershipHash',m->'membershipHash','totalMembership',m->'totalMembership',
  'windowCount',m->'windowCount','windowIndex',m->'windowIndex','predecessorJobId',m->'predecessorJobId','successorJobId',m->'successorJobId',
  'totalItems',j.total_items,'nextPosition',m->'nextPosition','lastWindow',m->'lastWindow','exhausted',m->'exhausted','members',members,'child',child,
  'replayed',p_replayed,'transition',p_transition,'blockReason',reason);
end; $$;

create unique index translation_profile_scan_window_unique on public.translation_jobs
 ((resume_cursor#>>'{profileScan,scanId}'),(resume_cursor#>>'{profileScan,windowIndex}')) where resume_cursor?'profileScan';
create unique index translation_profile_scan_successor_unique on public.translation_jobs
 ((resume_cursor#>>'{profileScan,predecessorJobId}')) where resume_cursor#>>'{profileScan,predecessorJobId}' is not null;
create unique index translation_profile_scan_attached_child_unique on public.translation_jobs
 ((resume_cursor#>>'{profileScan,activeChild,operationId}')) where resume_cursor#>>'{profileScan,activeChild,binding}'='attached';

create function public.begin_profile_translation_scan(p_scan_id uuid,p_kind text,p_configuration jsonb,p_manifest jsonb)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare actor uuid:=premium_translation_private.assert_actor();j public.translation_jobs%rowtype;ids uuid[];manifest_hash text;config_hash text;total integer;
 windows integer;idx integer;chunk jsonb;hashes jsonb;m jsonb;entry jsonb;stamp timestamptz:=clock_timestamp();
begin
 if not probpera_translation_operations.retry_uuid(p_scan_id) or probpera_translation_operations.profile_scan_configuration_valid(p_kind,p_configuration) is distinct from true
  or probpera_translation_operations.profile_scan_manifest_valid(p_kind,p_manifest) is distinct from true then raise exception 'Invalid profile scan intent' using errcode='22023';end if;
 manifest_hash:=probpera_translation_operations.retry_fingerprint(p_manifest);config_hash:=probpera_translation_operations.retry_fingerprint(p_configuration);
 perform pg_advisory_xact_lock(hashtextextended('profile-scan:'||p_scan_id::text,7451));
 select * into j from public.translation_jobs where id=p_scan_id for update;
 if j.id is not null then
  j:=probpera_translation_operations.profile_scan_access(p_scan_id,false);
  if j.kind<>p_kind or j.provider<>p_configuration->>'provider' or j.resume_cursor#>>'{profileScan,scanId}'<>p_scan_id::text
   or j.resume_cursor#>>'{profileScan,windowIndex}'<>'0' or j.resume_cursor#>>'{profileScan,configurationHash}'<>config_hash
   or j.resume_cursor#>>'{profileScan,fullManifestHash}'<>manifest_hash then raise exception 'Profile scan intent differs' using errcode='40001';end if;
  return probpera_translation_operations.profile_scan_view(j,true,'read');
 end if;
 total:=jsonb_array_length(p_manifest);windows:=greatest(1,(total+499)/500);ids:=array[p_scan_id];
 if windows>1 then for idx in 2..windows loop ids:=array_append(ids,gen_random_uuid());end loop;end if;
 -- All IDs exist in memory before any INSERT. Deferred job-only guards validate
 -- the final circular references, never a caller-controlled construction flag.
 for idx in 0..windows-1 loop
  select coalesce(jsonb_agg(value order by n),'[]'),coalesce(jsonb_agg(value->'catalogSourceHash' order by n),'[]') into chunk,hashes
   from jsonb_array_elements(p_manifest) with ordinality x(value,n) where n>idx*500 and n<=idx*500+500;
  m:=jsonb_build_object('version',1,'scanId',p_scan_id,'windowIndex',idx,'windowCount',windows,'totalMembership',total,
   'predecessorJobId',case when idx=0 then null else ids[idx] end,'successorJobId',case when idx=windows-1 then null else ids[idx+2] end,
   'fullManifestHash',manifest_hash,'membershipHash',probpera_translation_operations.retry_fingerprint(chunk),'configurationHash',config_hash,
   'catalogSourceHashes',hashes,'nextPosition',0,'lastWindow',idx=windows-1,'exhausted',total=0,'activeChild',null,'lastTransition',null);
  insert into public.translation_jobs(id,kind,provider,status,total_items,succeeded_items,failed_items,requested_by,started_at,completed_at,version,resume_cursor)
   values(ids[idx+1],p_kind,p_configuration->>'provider',case when total=0 then 'skipped' else 'reviewing' end,jsonb_array_length(chunk),0,0,actor,stamp,
    case when total=0 then stamp else null end,1,jsonb_build_object('profileScan',m)) returning * into j;
  insert into public.translation_job_items(job_id,position,entity_type,entity_id,status,attempt_count,max_attempts,staff_retry,lease_owner,lease_expires_at)
   select j.id,n-1,p_kind,case when p_kind='writer' then (value->>'countryId')||':'||(value->>'writerId') else value->>'countryId' end,
    'reviewing',0,1,null,null,null from jsonb_array_elements(chunk) with ordinality x(value,n);
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata) values(actor,'translation.profile_scan.window_created','translation_job',j.id::text,
   jsonb_build_object('scanId',p_scan_id,'kind',p_kind,'windowIndex',idx,'windowCount',windows,'totalMembership',total,'totalItems',j.total_items,
    'fullManifestHash',manifest_hash,'membershipHash',m->'membershipHash'));
 end loop;
 perform probpera_translation_operations.profile_scan_assert_chain(p_scan_id);
 select * into j from public.translation_jobs where id=p_scan_id;
 return probpera_translation_operations.profile_scan_view(j,false,'created');
end; $$;

create function public.get_profile_translation_scan(p_job_id uuid)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare j public.translation_jobs%rowtype;
begin
 j:=probpera_translation_operations.profile_scan_access(p_job_id,true);
 return probpera_translation_operations.profile_scan_view(j,false,'read');
end; $$;
`);

function common(text) {
 return text.replaceAll('library_scan','profile_scan').replaceAll('libraryScan','profileScan').replaceAll('Library','Profile').replaceAll('library','profile')
  .replaceAll('a premium_translation_private.catalog_operation_artifacts%rowtype','a record')
  .replaceAll('jsonb_array_length(a.calls)','a.provider_calls')
  .replaceAll("probpera_translation_operations.profile_scan_link(a,", "probpera_translation_operations.profile_scan_link(to_jsonb(a),");
}
let attach = common(extract('public.attach_library_translation_scan_operation'));
attach = once(attach,"perform pg_advisory_xact_lock(hashtextextended('catalog-operation:literary_work:'||i.entity_id,7291));","perform probpera_translation_operations.profile_scan_entity_lock(j.kind,i.entity_id);");
attach = once(attach,"if i.position<>(m->>'nextPosition')::integer then","if not probpera_translation_operations.profile_scan_predecessors_ready(j) or i.position<>(m->>'nextPosition')::integer then");
attach = once(attach,'select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation_id;',
 'select * into a from probpera_translation_operations.profile_scan_operation(j.kind,i.entity_id,p_operation_id,false);');
attach = attach.replaceAll("a.entity_type<>'literary_work'", 'a.entity_type<>j.kind');
attach = once(attach,"and not exists(select 1 from jsonb_array_elements(a.calls) c where c->'metadata'->'responseReceivedAt'='null'::jsonb)",
 "and not a.has_pending and a.catalog_source_hash=m->'catalogSourceHashes'->>i.position");
attach = once(attach,"a.confirmed_cursor=jsonb_build_object('profileCursor',(m->>'windowIndex')::bigint*500+i.position+1)",
 "a.confirmed_cursor=jsonb_build_object(case when j.kind='writer' then 'writerCursor' else 'countryCursor' end,(m->>'windowIndex')::integer*500+i.position+1)");
attach = once(attach,"exists(select 1 from public.translation_jobs c where c.id=a.job_id and c.resume_cursor-'catalogOperation'=jsonb_build_object('profileCursor',(m->>'windowIndex')::bigint*500+i.position))",
 "a.current_cursor=jsonb_build_object(case when j.kind='writer' then 'writerCursor' else 'countryCursor' end,(m->>'windowIndex')::integer*500+i.position)");
chunks.push(attach);

let checkpoint = common(extract('public.checkpoint_library_translation_scan_item'));
checkpoint = checkpoint.replace("('source_missing','ineligible','existing_candidate','database_read_failed')", "('source_missing','ineligible','existing_candidate','database_read_failed','catalog_changed')")
 .replace("or (p_observation->'sourceHash'", "or (p_observation->>'reason'='catalog_changed' and p_observation->>'state'<>'stale')\n   or (p_observation->'sourceHash'");
checkpoint = once(checkpoint,"perform pg_advisory_xact_lock(hashtextextended('catalog-operation:literary_work:'||i.entity_id,7291));","perform probpera_translation_operations.profile_scan_entity_lock(j.kind,i.entity_id);");
checkpoint = once(checkpoint,"if j.version<>p_expected_version or i.position<>(m->>'nextPosition')::integer or i.status<>'reviewing' then",
 "if not probpera_translation_operations.profile_scan_predecessors_ready(j) or j.version<>p_expected_version or i.position<>(m->>'nextPosition')::integer or i.status<>'reviewing' then");
checkpoint = once(checkpoint,"select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=(m#>>'{activeChild,operationId}')::uuid;",
 "select * into a from probpera_translation_operations.profile_scan_operation(j.kind,i.entity_id,(m#>>'{activeChild,operationId}')::uuid,false);");
checkpoint = once(checkpoint,"a:=probpera_translation_operations.profile_scan_active(i.entity_id);", "select * into a from probpera_translation_operations.profile_scan_operation(j.kind,i.entity_id,null,true);");
checkpoint = once(checkpoint,'select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation_id;',
 'select * into a from probpera_translation_operations.profile_scan_operation(j.kind,i.entity_id,p_operation_id,false);');
checkpoint = checkpoint.replaceAll("a.entity_type<>'literary_work'", 'a.entity_type<>j.kind');
checkpoint = once(checkpoint,"   if p_observation->>'reason'='source_missing' and exists(select 1 from public.literary_works where id=i.entity_id::uuid)\n    and exists(select 1 from public.literary_work_translations where work_id=i.entity_id::uuid and locale='ru') then\n    raise exception 'Profile source still exists' using errcode='40001';end if;",
 "   -- KV/catalog membership is authenticated application metadata, not an SQL\n   -- attestation of today's remote asset. Only the old owned admission/CAS can pay.");
checkpoint = once(checkpoint,"'position',i.position,'workId',i.entity_id,", "'position',i.position,'entityId',i.entity_id,'kind',j.kind,'catalogSourceHash',m->'catalogSourceHashes'->i.position,");
// The observation's discriminator has its own name; do not duplicate JSON key kind.
checkpoint = checkpoint.replace("'kind','profile-scan-observation'", "'type','profile-scan-observation'")
 .replaceAll("staff_retry_receipt->>'kind'", "staff_retry_receipt->>'type'");
chunks.push(checkpoint);

chunks.push(`create function public.continue_profile_translation_scan(p_window_job_id uuid,p_expected_version bigint,p_configuration jsonb)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare j public.translation_jobs%rowtype;successor public.translation_jobs%rowtype;m jsonb;
begin
 j:=probpera_translation_operations.profile_scan_access(p_window_job_id,true);m:=j.resume_cursor->'profileScan';
 if p_expected_version is null or p_expected_version<1 or probpera_translation_operations.profile_scan_configuration_valid(j.kind,p_configuration) is distinct from true then
  raise exception 'Invalid profile continuation configuration' using errcode='22023';end if;
 if probpera_translation_operations.retry_fingerprint(p_configuration)<>m->>'configurationHash' or p_configuration->>'provider'<>j.provider then
  raise exception 'Profile continuation configuration changed' using errcode='40001';end if;
 if j.cancel_requested_at is not null or j.status in ('cancelled','cancelling') then return probpera_translation_operations.profile_scan_view(j,false,'held');end if;
 -- The eager pointer is NOT a shortcut through unfinished members or a paid hold.
 if m->'activeChild'<>'null'::jsonb or (m->>'nextPosition')::integer<j.total_items then
  if j.version<>p_expected_version then raise exception 'Profile continuation version changed' using errcode='40001';end if;
  return probpera_translation_operations.profile_scan_view(j,false,'read');end if;
 if m->'exhausted'='true'::jsonb then return probpera_translation_operations.profile_scan_view(j,true,'exhausted');end if;
 if m->'successorJobId'='null'::jsonb then raise exception 'Profile eager successor missing' using errcode='40001';end if;
 -- Completed parent membership/pointer is immutable: an old accepted continuation
 -- ACK can replay the same successor without allocating or changing any row.
 successor:=probpera_translation_operations.profile_scan_access((m->>'successorJobId')::uuid,false);
 if successor.resume_cursor#>>'{profileScan,predecessorJobId}'<>j.id::text then raise exception 'Profile predecessor differs' using errcode='40001';end if;
 return probpera_translation_operations.profile_scan_view(successor,true,'successor');
end; $$;`);

let guard = common(extract('probpera_translation_operations.library_scan_guard'));
guard = guard.replace('a record;m jsonb;', 'a record;m jsonb;');
guard = once(guard,"new.kind<>'literary_work'", "new.kind not in ('writer','country')");
guard = once(guard,"or (m->>'nextPosition')::integer>new.total_items or (m->>'windowIndex')::bigint*500+new.total_items>999999999",
 "or new.total_items<>least(500,greatest(0,(m->>'totalMembership')::integer-(m->>'windowIndex')::integer*500)) or (m->>'nextPosition')::integer>new.total_items");
const insertStart = guard.indexOf("  if tg_op='INSERT' then\n   if (m->>'windowIndex')::integer=0 then");
const insertEnd = guard.indexOf('\n  if om is null', insertStart);
assert(insertStart>0 && insertEnd>insertStart);
guard = guard.slice(0,insertStart)+`  if tg_op='INSERT' then
   if new.version<>1 or (m->>'nextPosition')::integer<>0 or m->'activeChild'<>'null'::jsonb or m->'lastTransition'<>'null'::jsonb
    or new.succeeded_items<>0 or new.failed_items<>0 or new.cancel_requested_at is not null
    or ((m->>'windowIndex')::integer=0 and new.id::text<>m->>'scanId') then raise exception 'Invalid initial profile window' using errcode='42501';end if;
   -- Circular eager pointers receive their full committed proof from the deferred
   -- job-INSERT trigger, and from the explicit BEGIN assertion, never a GUC.
   return new;
  end if;`+guard.slice(insertEnd);
guard = once(guard,"(m-array['nextPosition','lastWindow','exhausted','activeChild','lastTransition','successorJobId'])<>\n      (om-array['nextPosition','lastWindow','exhausted','activeChild','lastTransition','successorJobId'])",
 "(m-array['nextPosition','exhausted','activeChild','lastTransition'])<>\n      (om-array['nextPosition','exhausted','activeChild','lastTransition'])");
guard = once(guard,"select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=(om#>>'{activeChild,operationId}')::uuid;",
 "select * into a from probpera_translation_operations.profile_scan_operation(old.kind,i.entity_id,(om#>>'{activeChild,operationId}')::uuid,false);");
guard = once(guard,"select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=(m#>>'{activeChild,operationId}')::uuid;",
 "select * into a from probpera_translation_operations.profile_scan_operation(new.kind,i.entity_id,(m#>>'{activeChild,operationId}')::uuid,false);");
guard = guard.replaceAll("a.entity_type<>'literary_work'", 'a.entity_type<>new.kind');
guard = once(guard,"or a.confirmed_cursor<>jsonb_build_object('profileCursor',(m->>'windowIndex')::bigint*500+i.position+1)",
 "or a.has_pending or a.catalog_source_hash<>m->'catalogSourceHashes'->>i.position\n      or a.confirmed_cursor<>jsonb_build_object(case when new.kind='writer' then 'writerCursor' else 'countryCursor' end,(m->>'windowIndex')::integer*500+i.position+1)");
guard = once(guard,"or not exists(select 1 from public.translation_jobs c where c.id=a.job_id and c.resume_cursor-'catalogOperation'=jsonb_build_object('profileCursor',(m->>'windowIndex')::bigint*500+i.position))",
 "or a.current_cursor<>jsonb_build_object(case when new.kind='writer' then 'writerCursor' else 'countryCursor' end,(m->>'windowIndex')::integer*500+i.position))");
guard = once(guard,'i.position)))) then','i.position))) then');
guard = once(guard,'a:=probpera_translation_operations.profile_scan_active(i.entity_id);',
 'select * into a from probpera_translation_operations.profile_scan_operation(new.kind,i.entity_id,null,true);');
const successorStart=guard.indexOf("  if m->'successorJobId' is distinct from om->'successorJobId' then");
const successorEnd=guard.indexOf('\n  return new;',successorStart);
assert(successorStart>0 && successorEnd>successorStart);
guard=guard.slice(0,successorStart)+`  if (new_position>old_position or (om->'activeChild'='null'::jsonb and m->'activeChild'<>'null'::jsonb))
   and not probpera_translation_operations.profile_scan_predecessors_ready(new) then raise exception 'Prior profile window is unfinished' using errcode='42501';end if;`+guard.slice(successorEnd);
guard=once(guard,"new.entity_type<>'literary_work' or new.entity_id<>new.entity_id::uuid::text or new.position>=j.total_items", "new.entity_type<>j.kind or new.position>=j.total_items");
guard=once(guard,"  if tg_op='INSERT' then\n   if new.status<>'reviewing'", "  perform probpera_translation_operations.profile_scan_record(j.kind,new.entity_id,j.resume_cursor->'profileScan'->'catalogSourceHashes'->>new.position);\n  if tg_op='INSERT' then\n   if new.status<>'reviewing'");
guard=guard.replaceAll("staff_retry_receipt->>'kind'='profile-scan-observation'", "staff_retry_receipt->>'type'='profile-scan-observation'")
 .replaceAll("r->>'kind' is distinct from 'profile-scan-observation'", "r->>'type' is distinct from 'profile-scan-observation'");
guard=once(guard,"array['version','kind','scanId','windowJobId','itemId','position','workId','transitionId','fingerprint','classification','state','errorCode','sourceHash','providerCalls','child']",
 "array['version','type','scanId','windowJobId','itemId','position','entityId','kind','catalogSourceHash','transitionId','fingerprint','classification','state','errorCode','sourceHash','providerCalls','child']");
guard=once(guard,"r->>'kind'<>'profile-scan-observation'", "r->>'type'<>'profile-scan-observation'");
guard=once(guard,"r->>'workId'<>i.entity_id", "r->>'entityId'<>i.entity_id or r->>'kind'<>j.kind or r->'catalogSourceHash' is distinct from j.resume_cursor->'profileScan'->'catalogSourceHashes'->i.position");
chunks.push(guard);

chunks.push(`-- One guard body is attached separately to the existing writer and country
-- artifact caches. Only a NEW reservation is checked; responses and FINISH keep
-- accepted output after stop. Ordinary unrelated operations are unchanged.
create function probpera_translation_operations.profile_scan_dispatch_guard()
returns trigger language plpgsql security definer set search_path='' as $$
declare j public.translation_jobs%rowtype;i public.translation_job_items%rowtype;m jsonb;kind text;
begin
 if jsonb_array_length(new.calls)<=jsonb_array_length(old.calls) then return new;end if;
 if tg_table_name='writer_operation_artifacts' then kind:='writer';
 else if new.entity_type<>'country' then return new;end if;kind:='country';end if;
 select * into j from public.translation_jobs where resume_cursor#>>'{profileScan,activeChild,binding}'='attached'
  and resume_cursor#>>'{profileScan,activeChild,operationId}'=new.operation_id::text for update;
 if j.id is null then return new;end if;
 m:=j.resume_cursor->'profileScan';select * into i from public.translation_job_items where job_id=j.id and position=(m->>'nextPosition')::integer;
 if j.kind<>kind or j.cancel_requested_at is not null or j.status in ('cancelled','cancelling') or j.status<>'reviewing' or i.id is null or i.status<>'reviewing'
  or i.entity_id<>new.entity_id or new.actor_id<>j.requested_by or new.provider<>j.provider or new.configuration_hash<>m->>'configurationHash'
  or new.source_revision->>'catalogSourceHash'<>m->'catalogSourceHashes'->>i.position
  or m#>>'{activeChild,jobId}'<>new.job_id::text or m#>>'{activeChild,itemId}'<>new.item_id::text or m#>>'{activeChild,intentHash}'<>new.intent_hash
  or not probpera_translation_operations.profile_scan_predecessors_ready(j) then raise exception 'Attached profile scan stopped before dispatch' using errcode='40001';end if;
 return new;
end; $$;

create trigger translation_jobs_profile_scan_integrity before insert or update or delete on public.translation_jobs
 for each row execute function probpera_translation_operations.profile_scan_guard();
create trigger translation_items_profile_scan_integrity before insert or update or delete on public.translation_job_items
 for each row execute function probpera_translation_operations.profile_scan_guard();
create trigger translation_attempts_profile_scan_integrity before insert or update or delete on public.translation_job_attempts
 for each row execute function probpera_translation_operations.profile_scan_guard();
-- ONLY job INSERT, maximum20 events per manifest. Never10000 item events.
create constraint trigger translation_profile_scan_committed_chain after insert on public.translation_jobs
 deferrable initially deferred for each row execute function probpera_translation_operations.profile_scan_insert_chain_guard();
create trigger writer_operation_profile_scan_dispatch before update on premium_translation_private.writer_operation_artifacts
 for each row execute function probpera_translation_operations.profile_scan_dispatch_guard();
create trigger catalog_operation_profile_scan_dispatch before update on premium_translation_private.catalog_operation_artifacts
 for each row execute function probpera_translation_operations.profile_scan_dispatch_guard();

revoke all on function probpera_translation_operations.profile_scan_configuration_valid(text,jsonb),
 probpera_translation_operations.profile_scan_record(text,text,text),probpera_translation_operations.profile_scan_manifest_valid(text,jsonb),
 probpera_translation_operations.profile_scan_marker_valid(jsonb),probpera_translation_operations.profile_scan_operation(text,text,uuid,boolean),
 probpera_translation_operations.profile_scan_entity_lock(text,text),probpera_translation_operations.profile_scan_link(jsonb,text),
 probpera_translation_operations.profile_scan_access(uuid,boolean),probpera_translation_operations.profile_scan_predecessors_ready(public.translation_jobs),
 probpera_translation_operations.profile_scan_status(uuid),
 probpera_translation_operations.profile_scan_assert_chain(uuid),probpera_translation_operations.profile_scan_insert_chain_guard(),
 probpera_translation_operations.profile_scan_view(public.translation_jobs,boolean,text),probpera_translation_operations.profile_scan_guard(),
 probpera_translation_operations.profile_scan_dispatch_guard() from public,anon,authenticated,service_role;

revoke all on function public.begin_profile_translation_scan(uuid,text,jsonb,jsonb),public.get_profile_translation_scan(uuid),
 public.attach_profile_translation_scan_operation(uuid,bigint,uuid,uuid,uuid,uuid,text,uuid),
 public.checkpoint_profile_translation_scan_item(uuid,bigint,uuid,uuid,jsonb,uuid),public.continue_profile_translation_scan(uuid,bigint,jsonb)
 from public,anon,authenticated,service_role;
grant execute on function public.begin_profile_translation_scan(uuid,text,jsonb,jsonb),public.get_profile_translation_scan(uuid),
 public.attach_profile_translation_scan_operation(uuid,bigint,uuid,uuid,uuid,uuid,text,uuid),
 public.checkpoint_profile_translation_scan_item(uuid,bigint,uuid,uuid,jsonb,uuid),public.continue_profile_translation_scan(uuid,bigint,jsonb) to authenticated;
commit;
`);

// Reuse only the existing reducer body in a new function. The old body is untouched.
const statusStart=library.indexOf('create function probpera_translation_operations.library_scan_status(');
const statusEnd=library.indexOf('\n$$;',statusStart)+'\n$$;'.length;
chunks.splice(1,0,library.slice(statusStart,statusEnd).replaceAll('library_scan_status','profile_scan_status'));
const output=chunks.join('\n\n');
assert(!output.includes('profile_scan_active('));
assert(!output.includes('profileCursor'));
assert(!output.includes('libraryScan'));
assert(![attach,checkpoint,guard].some(text=>text.includes('a.calls')));
const target=path.join(here,'profile-stable-scan.sql');fs.writeFileSync(target,output);
const sourceBindings=[libraryPath,path.join(here,'rpc-contract.json'),path.join(here,'profile-translation-scan-rpc.draft.ts'),
 path.resolve(here,'../m07-t12-profile-stable-design-20261030-sol/design.json')].map(file=>{const b=fs.readFileSync(file);return{file,bytes:b.length,sha256:hash(b)};});
fs.writeFileSync(path.join(here,'sql-draft-receipt.json'),JSON.stringify({classification:'PARENT_ONLY_NOT_EXECUTED_NOT_MIGRATION_NOT_ACCEPTANCE',
 atUtc:new Date().toISOString(),file:target,bytes:Buffer.byteLength(output),sha256:hash(Buffer.from(output)),sourceBindings,
 publicRpcs:5,deferredInsertEventsMax:20,manifestRecordsMax:10000,manifestBytesMax:4194304,markerBytesMax:65536,
 maintainedWrites:0,databaseExecutions:0,providerCalls:0,requiredNativeCases:['eager501/10000 construction and20-event bound','all exact legacy tuple/UTF16 edges','duplicate BEGIN and exact replay',
 'direct future-window consumption denied','unknown/foreign/persisted-observed/historical holds','current-next scalar and0call hold','cancel versus dispatch two sessions',
 'entity-cache-parent three-session lock order','deferred malformed-chain rollback without GUC','old routine/cache/index/ACL byte preservation','original a9886FAIL to0FAIL without weakening']},null,2));
console.log(JSON.stringify({target,bytes:Buffer.byteLength(output),sha256:hash(Buffer.from(output)),databaseExecutions:0,maintainedWrites:0}));
