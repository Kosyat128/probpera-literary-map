"""Seal current native-only proof after all final native/SDK checks are complete."""
import datetime, hashlib, json, pathlib, sys, zipfile

here=pathlib.Path(__file__).resolve().parent
work=here.parent
repo=work.parent/'probpera-literary-map'
root=work/'profile-scan-sql-native'
version=sys.argv[1]
assert version.startswith('v') and version[1:].isdigit()
final=root/version
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
source=read(final/'source-manifest.json')
run=read(final/'run-receipt.json')
assert run['exitCode']==0
cases=read(final/'native-cases-final.json')
assert cases['eager-root-child-forgeries']['allRolledBack'] and len(cases['eager-root-child-forgeries']['rejected'])==14
assert cases['eager-root-child-forgeries']['setImmediateBeforeCompleteRejected'] and cases['eager-root-child-forgeries']['setImmediateAfterCompletePassed']
con=read(final/'concurrency/results.json');three=read(final/'three-session/results.json')
assert con['pass']==10 and con['fail']==0 and three['pass']==2 and three['fail']==0
assert read(final/'concurrency/session-cleanup.json')['allTerminal'] and read(final/'three-session/session-cleanup.json')['allTerminal']
baseline=read(final/'native-baseline.json');current={r['name']:r for r in read(final/'native-functions-final.json')}
assert len(baseline['functions'])==139 and all(current[r['name']]==r for r in baseline['functions'])
assert len(baseline['tables'])==5 and baseline['tables']==read(final/'native-tables-final.json')
indexes={(r['schema'],r['name']):r for r in read(final/'native-indexes-final.json')}
assert len(baseline['indexes'])==24 and all(indexes[(r['schema'],r['name'])]==r for r in baseline['indexes'])
goldens=read(final/'native-goldens-final.json')
assert len({r['rpc'] for r in goldens})==5
def advisors(p):
    text=p.read_text(encoding='utf-8-sig')
    return json.loads(text[text.index('{'):])['results']
prior_advisors=advisors(work/'library-scan-sql-native/security-advisors-final.log')
current_advisors=advisors(final/'security-advisors-final.log')
key=lambda r:(r['name'],json.dumps(r.get('metadata'),sort_keys=True))
assert len(prior_advisors)==len(current_advisors)==15 and {key(r) for r in prior_advisors}=={key(r) for r in current_advisors}
cleanup=[]
for name in ['cleanup.json','final-cleanup.json','concurrency-cleanup.json','three-session-cleanup.json','measure-cleanup.json']:
    r=read(final/name)
    assert r['pgCtlExitCode']==0 and not r['processRemains'] and not r['pidFileRemains'] and not r['serviceCreated']
    cleanup.append({'file':name,**r})
measurement=read(final/'measure-10000.receipt.json')
assert measurement['exitCode']==0
new_stats=[]
for line in (final/'measure-10000.log').read_text(encoding='utf-8-sig').splitlines():
    if line.startswith('{'):
        value=json.loads(line)
        if 'function' in value:new_stats.append(value)
assert {r['function']:r['calls'] for r in new_stats}=={'profile_scan_insert_chain_guard':20,'profile_scan_assert_chain':2}
bindings={}
def gather(m):
    for r in m.get('sources',[]):
        if r['file'] in bindings:assert bindings[r['file']]['sha256']==r['sha256']
        bindings[r['file']]={'file':r['file'],'sha256':r['sha256'],'bytes':len((repo/r['file']).read_bytes())}
    if m.get('foundation'):gather(m['foundation'])
gather(source)
assert len(bindings)==39
entries={}
for r in bindings.values():
    b=(repo/r['file']).read_bytes();assert sha(b)==r['sha256'];entries['current-source/'+r['file']]=b
for p in root.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.json','.sql','.ps1','.log','.txt','.cjs','.py','.md'}:
        entries['raw/'+p.relative_to(root).as_posix()]=p.read_bytes()
for p in here.iterdir():
    if p.is_file() and p.suffix in {'.cjs','.py','.json','.ts','.md','.sql'}:
        entries['runners-and-parent-design/'+p.name]=p.read_bytes()
entries['prior-advisors/library-final.log']=(work/'library-scan-sql-native/security-advisors-final.log').read_bytes()
summary={
 'schemaVersion':1,'classification':'LOCAL_PROFILE_NATIVE_FINITE_SCAN_VERIFIED_NOT_FULL_M07_R3',
 'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'finalVersion':version,
 'nativeSourceInputs':list(sorted(bindings.values(),key=lambda r:r['file'])),
 'storedCoreLabels':len(cases),'coreLabelsIncludeSetupAndIntermediateReceipts':True,
 'concurrentGroups':{'twoSession':10,'threeSession':2,'providerCalls':0},
 'nativeGoldens':{'count':len(goldens),'sha256':sha((final/'native-goldens-final.json').read_bytes()),'rpcKinds':5},
 'oldPreservation':{'routineBodiesSecurityConfigAcl':139,'tableColumnsRlsAcl':5,'indexes':24,'allExact':True},
 'advisors':{'baseline':15,'current':15,'new':0,'removed':0,'exitCode':1,'lint':'NOT_RUN_PLPGSQL_CHECK_UNAVAILABLE_NO_INSTALL'},
 'committed10000Performance':{'originalMeasuredElapsedMs':33682.8266,'originalDeferredTriggerCalls':20,'originalDeferredTimeMs':29235.355,'current':measurement,'currentFunctionStats':new_stats,'noGlobalRuntimeGuarantee':True},
 'cleanup':cleanup,
 'limitations':[
  'Synthetic owned-loopback PG17 Auth/catalog/override rows only. No managed PostgREST/Auth/browser E2E or paid provider execution.',
  'Core result labels and concurrent groups overlap; they do not count acceptance criteria. Existing provider expense ledger is not cloned into logical parent observations.',
  'Catalog hashes are opaque original JavaScript strings supplied by the trusted server; PostgreSQL cannot attest remote KV freshness. Old owned admission/full-source CAS remains final expense authority.',
  'An eager finite initial manifest is limited10000 records/4MiB and20 windows500 each. Overflow rejects; no truncation or future-corpus membership guarantee.',
  'Root-only deferred full-chain proof is combined with immediate exact root/predecessor child insertion guards, immutable membership and unique finite indices; no GUC/xmin/table/role/column bypass.',
  'Cancellation affects the actual attached window; no automatic ancestor-to-active-successor cancellation, remote cancellation or billing guarantee.',
  'Raw55/37 prior exports and original v2 genuine syntax failure/v4 fixture search_path failure retain their original source scope; final current bytes require the named final version.',
  'Native source scope is39 SQL/fixture inputs, not the full application working tree. Actual SDK/DTO/action/UI proofs and broad gates are separately bound.',
  'Whole M07/M24/M04/M02/M13/R3 and all26 modules/230criteria remain pending; no commit/push/PR/production migration/deploy/social send or key setup.'
 ]
}
entries['summary.json']=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode()
entries['README.md']=('''# Profile stable traversal: native proof

This archive contains actual isolated PG17 core requests/results, ten real
two-session groups, two real three-session lock graphs, native five-RPC wire
receipts, complete old-routine/table/index comparison and advisor/cleanup logs.
The exact final source inputs and their scope are in summary.json.

All earlier failed files and successful intermediate versions are retained with
their original manifests. A v4 fixture helper with search_path='' first used an
unqualified SET CONSTRAINTS; its corrected local fixture-only retry is declared
and the full final fixture runs from a fresh database. No paid routine was
replaced to make a fixture pass. No omitted/reconstructed baseline is used.

The final committed10000 measurement includes COMMIT/deferred validation and
actual pg_stat function counters. A20 job-insert bound is not10000 item events.
The full immutable manifest is proved before RETURN and again at root COMMIT;
strict immediate child lineage prevents bypass by a direct future UUID.

Inspect separate controlled/SDK and full-source validation artifacts before
making any application acceptance claim. This native artifact does not finish
M07, the26-module R3 goal, managed acceptance or real environment setup.
''').encode()
manifest={'schemaVersion':1,'classification':summary['classification'],'finalVersion':version,
          'sourceInputs':summary['nativeSourceInputs'],
          'entries':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(entries.items())]}
entries['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
archive_path=root/'profile-sql-evidence.zip'
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for n,b in sorted(entries.items()):z.writestr(n,b)
with zipfile.ZipFile(archive_path) as z:
    names=z.namelist();assert len(names)==len(set(names))
    for r in manifest['entries']:
        b=z.read(r['path']);assert len(b)==r['bytes'] and sha(b)==r['sha256']
receipt={'archive':archive_path.name,'bytes':archive_path.stat().st_size,'sha256':sha(archive_path.read_bytes()),'payloads':len(manifest['entries']),
         'manifestSha256':sha(entries['manifest.json']),'currentSourceInputs':len(bindings),'storedCoreLabels':len(cases),'twoSessionGroups':10,'threeSessionGroups':2,
         'nativeGoldens':len(goldens),'sourceScope':'Native SQL/fixture39inputs only; global source/SDK/actions/UI separately verified','finalVersion':version}
(root/'profile-sql-evidence.receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
