const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const here=__dirname,repo=path.resolve(here,'../../probpera-literary-map'),sql=fs.readFileSync(path.join(here,'profile-stable-scan.sql'),'utf8');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),checks=[];
function check(name,fn){try{fn();checks.push({name,pass:true});}catch(e){checks.push({name,pass:false,error:String(e.message)});}}
const contract=JSON.parse(fs.readFileSync(path.join(here,'rpc-contract.json'),'utf8'));
const definitions=[...sql.matchAll(/create function ([a-z_]+\.[a-z_]+)\(([^)]*)\)/g)].map(m=>({name:m[1],args:m[2].replace(/\s+/g,' ').trim()}));
check('exact five public RPC argument names in contract order',()=>{
 const declared=definitions.filter(f=>f.name.startsWith('public.'));
 assert.equal(declared.length,5);
 for(const target of contract.rpc){const native=declared.find(f=>f.name===`public.${target.name}`);assert(native,target.name);
  const names=native.args.split(',').map(x=>x.trim().split(/\s+/)[0]);assert.deepEqual(names,Object.keys(target.args));}
});
check('all new internal functions explicitly revoked from PUBLIC/anon/authenticated/service_role',()=>{
 const list=sql.slice(sql.indexOf('revoke all on function probpera_translation_operations.profile_scan_configuration_valid'),sql.indexOf('revoke all on function public.begin_profile'));
 for(const f of definitions.filter(f=>!f.name.startsWith('public.')))assert(list.includes(`${f.name}(`),f.name);
 assert(list.includes('from public,anon,authenticated,service_role;'));
});
check('all public functions denied old roles and only explicitly granted authenticated EXECUTE',()=>{
 const list=sql.slice(sql.indexOf('revoke all on function public.begin_profile'));
 for(const f of definitions.filter(f=>f.name.startsWith('public.')))assert.equal((list.match(new RegExp(f.name.replaceAll('.','\\.')+'\\(','g'))||[]).length,2,f.name);
 assert(list.includes('from public,anon,authenticated,service_role;'));assert(list.includes('to authenticated;'));
});
check('no maintained function replacement, table/column/role creation, provider transport or GUC proof flag',()=>{
 assert(!/create\s+or\s+replace|alter\s+table|create\s+table|create\s+role|set_config\s*\(|current_setting\s*\(|\bhttp_(post|get)\s*\(/i.test(sql));
});
check('deferred constraint trigger is job INSERT only',()=>{
 assert(/create constraint trigger translation_profile_scan_committed_chain after insert on public\.translation_jobs\s+deferrable initially deferred for each row/.test(sql));
 assert.equal((sql.match(/create constraint trigger/g)||[]).length,1);
});
check('all UUIDs allocated before any BEGIN insertion and explicit complete chain assertion before return',()=>{
 const begin=sql.slice(sql.indexOf('create function public.begin_profile_translation_scan'),sql.indexOf('create function public.get_profile_translation_scan'));
 assert(begin.indexOf('ids:=array_append')<begin.indexOf('insert into public.translation_jobs'));
 assert(begin.indexOf('perform probpera_translation_operations.profile_scan_assert_chain(p_scan_id)')>begin.indexOf('insert into public.translation_job_items'));
});
check('immutable eager markers, bounded windows and exact per-window catalog hash array',()=>{
 assert(sql.includes("(m-array['nextPosition','exhausted','activeChild','lastTransition'])"));
 assert(sql.includes("jsonb_array_length(v->'catalogSourceHashes')<>expected"));
 assert(sql.includes('windows>20'));assert(sql.includes('jsonb_array_length(v)>10000'));assert(sql.includes('octet_length(v::text)>4194304'));
 assert(sql.includes('octet_length(v::text)>65536'));
});
check('fresh country UTF16 and writer exact old-identity validation; no normalization',()=>{
 assert(sql.includes('site_copy_utf16_length(entity) not between 1 and 120'));
 assert(sql.includes("assert_identity('writer_biography',entity)"));assert(sql.includes("assert_identity('country',entity)"));
 assert(!/lower\s*\(\s*entity|normalize|replace\s*\(\s*entity/i.test(sql));
});
check('ATTACH and checkpoint and dispatch all enforce predecessor metadata prefix',()=>{
 for(const name of ['public.attach_profile_translation_scan_operation','public.checkpoint_profile_translation_scan_item','probpera_translation_operations.profile_scan_dispatch_guard']){
  const start=sql.indexOf(`create function ${name}(`),end=sql.indexOf('\nend; $$;',start);assert(sql.slice(start,end).includes('profile_scan_predecessors_ready(j)'),name);
 }
});
check('CONTINUE checks unfinished current membership before eager successor traversal',()=>{
 const start=sql.indexOf('create function public.continue_profile_translation_scan('),end=sql.indexOf('\nend; $$;',start),body=sql.slice(start,end);
 assert(body.indexOf("m->'activeChild'<>'null'::jsonb")<body.indexOf('successor:=probpera_translation_operations.profile_scan_access'));
});
check('metadata-only child projection uses actual old writer and country views with no capabilities',()=>{
 assert(sql.includes('writer_operation_view(a,true,false,false)'));assert(sql.includes('catalog_operation_view(a,true,false,false)'));
 const start=sql.indexOf('create function probpera_translation_operations.profile_scan_operation('),end=sql.indexOf('\nend; $$;',start),body=sql.slice(start,end);
 assert(!/source_snapshot|raw_seed|responseArtifact|expected_override_fields|a\.candidate|a\.calls\s*(?:,|as)/.test(body));
});
check('old CURRENT/private NEXT cursor bindings unchanged by new family',()=>{
 assert(sql.includes("a.confirmed_cursor=jsonb_build_object(case when j.kind='writer' then 'writerCursor' else 'countryCursor' end"));
 assert(sql.includes("a.current_cursor=jsonb_build_object(case when j.kind='writer' then 'writerCursor' else 'countryCursor' end"));
 assert(sql.includes('a.provider_calls=0'));assert(sql.includes('and not a.has_pending'));
});
check('entity advisory precedes parent lock; no explicit child/canonical row-lock acquisition',()=>{
 for(const name of ['attach','checkpoint']){
  const start=sql.indexOf(`create function public.${name}_profile_translation_scan_`),end=sql.indexOf('\nend; $$;',start),body=sql.slice(start,end);
  assert(body.indexOf('profile_scan_entity_lock')<body.indexOf('profile_scan_access(p_window_job_id,true)'));
 }
 assert(!/from premium_translation_private\.[^;]+for update|from public\.(?:country_profile_overrides|writer_profile_overrides)[^;]+for update/i.test(sql));
});
check('SQL parentheses balanced outside comments/string literals (NOT native parse proof)',()=>{
 let depth=0,mode='code';
 for(let i=0;i<sql.length;i++){
  const c=sql[i],next=sql[i+1];
  if(mode==='line'){if(c==='\n')mode='code';continue;}
  if(mode==='block'){if(c==='*'&&next==='/'){mode='code';i++;}continue;}
  if(mode==='quote'){if(c==="'"&&next==="'"){i++;continue;}if(c==="'")mode='code';continue;}
  if(c==='-'&&next==='-'){mode='line';i++;continue;}if(c==='/'&&next==='*'){mode='block';i++;continue;}if(c==="'"){mode='quote';continue;}
  if(c==='(')depth++;else if(c===')'){depth--;assert(depth>=0,`unmatched close around ${i}`);}
 }
 assert.equal(depth,0);assert.notEqual(mode,'quote');assert.notEqual(mode,'block');
});
check('frozen library maintained bytes unchanged',()=>{
 const expected={'supabase/migrations/20261029235455_library_translation_stable_scan.sql':'1966f749db15362b245d32b0e5b355b3f37dc4c154e2381c578b5ba11aba721b',
 'scripts/database/fixtures/library-translation-stable-scan.sql':'2edbc32bf11d3541d85645966d5cad504b40b685c887dfdc959bb3e7144d62ce'};
 for(const [file,h]of Object.entries(expected))assert.equal(sha(fs.readFileSync(path.join(repo,file))),h);
});
const report={classification:'PARENT_STATIC_DRAFT_CHECKS_ONLY_NOT_NATIVE_NOT_ACCEPTANCE',atUtc:new Date().toISOString(),sqlSha256:sha(Buffer.from(sql)),sqlBytes:Buffer.byteLength(sql),
 declarations:definitions,checks,pass:checks.filter(c=>c.pass).length,fail:checks.filter(c=>!c.pass).length,databaseExecutions:0,maintainedWrites:0,providerCalls:0,
 limitations:'Text/shape/parenthesis checks only. PostgreSQL parse, runtime, roles, deferred trigger construction, isolation, old paid binding, performance, SDK/UI/SAME and broad acceptance are NOT_RUN.'};
fs.writeFileSync(path.join(here,'sql-draft-static-checks.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({pass:report.pass,fail:report.fail,sqlSha256:report.sqlSha256,failures:checks.filter(c=>!c.pass)}));
if(report.fail)process.exitCode=1;
