"""Actual owned-loopback concurrent SQL sessions, never provider traffic."""
import datetime, hashlib, json, os, pathlib, subprocess, sys, time, uuid

version=sys.argv[1]
assert version.startswith('v') and version[1:].isdigit()
work=pathlib.Path(__file__).resolve().parent.parent
out=work/'profile-scan-sql-native'/version/'concurrency'
out.mkdir(exist_ok=False)
owned=json.loads((work/'site-copy-sql-native/owned-cluster.json').read_text(encoding='utf-8-sig'))
assert owned['port']==55438 and owned['listenAddress']=='127.0.0.1' and not owned['service']
psql=pathlib.Path(owned['pgBin'])/'psql.exe'
database=f'profile_scan_{version}_20261030'
args=[str(psql),'-h','127.0.0.1','-p','55438','-U','postgres','-d',database,'--no-psqlrc','--set=ON_ERROR_STOP=1','-qAt']
env={k:v for k,v in os.environ.items() if k.upper() in {'SYSTEMROOT','WINDIR','COMSPEC','PATH','PATHEXT','TEMP','TMP','USERPROFILE','PROGRAMDATA','PROGRAMFILES','PROGRAMFILES(X86)','SYSTEMDRIVE','PROCESSOR_ARCHITECTURE'}}
env['PGCLIENTENCODING']='UTF8'
actor="select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);"
role="set local role authenticated;select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);"
sql_literal=lambda s:"'"+str(s).replace("'","''")+"'"
json_literal=lambda v:sql_literal(json.dumps(v,ensure_ascii=False,separators=(',',':')))+'::jsonb'
seq=0
processes=[]
results={}
def file_sql(label,sql):
    p=out/(label+'.sql');p.write_text(sql,encoding='utf-8');return p
def parse_json(text):
    found=[]
    for line in text.splitlines():
        if line.startswith(('{','[')):
            try:found.append(json.loads(line))
            except json.JSONDecodeError:pass
    return found[-1] if found else None
def query(sql,label=None):
    global seq
    seq+=1;label=label or f'query-{seq}'
    p=file_sql(label,sql)
    r=subprocess.run(args+['-f',str(p)],env=env,capture_output=True,encoding='utf-8',errors='strict',creationflags=subprocess.CREATE_NO_WINDOW)
    (out/(label+'.stdout.log')).write_text(r.stdout,encoding='utf-8');(out/(label+'.stderr.log')).write_text(r.stderr,encoding='utf-8')
    if r.returncode:raise RuntimeError(f'{label}: psql{r.returncode}: {r.stderr[-900:]}')
    return parse_json(r.stdout)
def session(label,sql):
    app='profile-'+label;p=file_sql(label,sql)
    stdout=(out/(label+'.stdout.log')).open('w',encoding='utf-8');stderr=(out/(label+'.stderr.log')).open('w',encoding='utf-8')
    proc=subprocess.Popen(args+['-f',str(p)],env={**env,'PGAPPNAME':app},stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    entry={'label':label,'application':app,'process':proc,'stdout':stdout,'stderr':stderr,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    processes.append(entry);return entry
def finish(s):
    code=s['process'].wait(timeout=35);s['stdout'].close();s['stderr'].close()
    text=(out/(s['label']+'.stdout.log')).read_text(encoding='utf-8');error=(out/(s['label']+'.stderr.log')).read_text(encoding='utf-8')
    if code:raise RuntimeError(f"{s['label']}: psql{code}: {error[-900:]}")
    return {'label':s['label'],'application':s['application'],'exitCode':code,'receipt':parse_json(text),'startedAt':s['startedAt'],'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def barrier(s,sleep=False):
    started=time.monotonic()
    while time.monotonic()-started<8:
        proof=query("select jsonb_build_object('pid',pid,'waiting',"+("wait_event='PgSleep'" if sleep else "cardinality(pg_blocking_pids(pid))>0")+",'blockingPids',pg_blocking_pids(pid),'waitEvent',wait_event) from pg_stat_activity where application_name="+sql_literal(s['application']))
        if proof and proof['waiting']:return proof
        assert s['process'].poll() is None, 'Session ended before barrier '+s['label']
        time.sleep(.04)
    raise RuntimeError('No actual database barrier '+s['label'])
def caught(expression):
    return "create temp table native_race_result(v jsonb);do $caught$ begin insert into native_race_result select "+expression+";exception when others then insert into native_race_result values(jsonb_build_object('errorCode',sqlstate));end;$caught$;select v from native_race_result;"
def save():
    (out/'results.partial.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def setup(kind,tag):
    a=query(actor+"select public.profile_scan_fixture_seed("+sql_literal(kind)+","+sql_literal(tag)+")")
    scan=query('begin;'+role+"select public.profile_scan_fixture_begin("+sql_literal(kind)+",public.profile_scan_fixture_member("+sql_literal(kind)+","+json_literal(a)+"));commit;")
    child=query('begin;'+role+"select public.profile_scan_fixture_paid_begin("+sql_literal(kind)+","+json_literal(a)+");commit;")
    scan=query('begin;'+role+"select public.profile_scan_fixture_attach("+json_literal(scan)+","+json_literal(child)+");commit;")
    return a,scan,child
def dispatch(kind,child,review=False):
    name='writer' if kind=='writer' else 'catalog'
    return 'public.record_'+name+"_translation_operation_dispatch("+','.join(sql_literal(child[k]) for k in ['jobId','itemId','operationId'])+",gen_random_uuid(),'cloudflare',"+sql_literal('fixture-reviewer' if review else 'fixture-translator')+','+sql_literal('review' if review else 'translation')+",repeat('c',64))"
token=str(int(time.time()))
try:
    # Duplicate atomic eager chain: second real transaction waits on BEGIN lock.
    scan_id=str(uuid.uuid4());kind='country'
    expr="public.begin_profile_translation_scan("+sql_literal(scan_id)+",'country',public.profile_scan_fixture_config('country'),public.profile_scan_fixture_manifest('country',501))"
    one=session('initial-one','begin;'+role+'select '+expr+';select pg_sleep(2.0);commit;');sleep=barrier(one,True)
    two=session('initial-two','begin;'+role+'select '+expr+';commit;');wait=barrier(two)
    a,b=finish(one),finish(two)
    count=query("select jsonb_build_object('jobs',count(*),'members',sum(total_items)) from public.translation_jobs where resume_cursor#>>'{profileScan,scanId}'="+sql_literal(scan_id))
    assert a['receipt']['jobId']==b['receipt']['jobId']==scan_id and a['receipt']['replayed']!=b['receipt']['replayed'] and count=={'jobs':2,'members':501}
    results['initial-eager-chain']={'sessions':[a,b],'actualWait':wait,'barrier':sleep,'count':count};save()
    # Reuse immutable completed501 native core to race the same existing successor.
    root=query("select value->'completedFirst' from public.profile_scan_fixture_results where label='eager-501'")
    expr="public.continue_profile_translation_scan("+sql_literal(root['jobId'])+','+root['jobVersion']+",public.profile_scan_fixture_config('country'))"
    one=session('successor-one','begin;'+role+'select '+expr+';select pg_sleep(2.0);commit;');sleep=barrier(one,True)
    two=session('successor-two','begin;'+role+'select '+expr+';commit;');wait=barrier(two);a,b=finish(one),finish(two)
    assert a['receipt']['jobId']==b['receipt']['jobId']==root['successorJobId']
    results['successor-replay']={'sessions':[a,b],'actualWait':wait,'barrier':sleep};save()
    for kind in ['writer','country']:
        scan=query('begin;'+role+"select public.profile_scan_fixture_begin("+sql_literal(kind)+",public.profile_scan_fixture_manifest("+sql_literal(kind)+",2));commit;")
        transition=str(uuid.uuid4());expr="public.profile_scan_fixture_free("+json_literal(scan)+",'manual',null,"+sql_literal(transition)+")"
        one=session(kind+'-checkpoint-one','begin;'+role+'select '+expr+';select pg_sleep(2.0);commit;');sleep=barrier(one,True)
        two=session(kind+'-checkpoint-two','begin;'+role+'select '+expr+';commit;');wait=barrier(two);a,b=finish(one),finish(two)
        count=query("select jsonb_build_object('observations',count(*)) from public.translation_job_attempts where item_id="+sql_literal(scan['members'][0]['itemId']))
        assert a['receipt']['nextPosition']==b['receipt']['nextPosition']==1 and count['observations']==1
        results[kind+'-checkpoint-idempotent']={'sessions':[a,b],'actualWait':wait,'count':count};save()
        # Native GET locks parent and cannot combine pre-checkpoint cursor/new members.
        scan=a['receipt'];expr="public.profile_scan_fixture_free("+json_literal(scan)+")"
        one=session(kind+'-coherence-checkpoint','begin;'+role+'select '+expr+';select pg_sleep(2.0);commit;');sleep=barrier(one,True)
        two=session(kind+'-coherence-get','begin;'+role+"select public.get_profile_translation_scan("+sql_literal(scan['jobId'])+");commit;");wait=barrier(two);a,b=finish(one),finish(two)
        assert b['receipt']['nextPosition']==2 and all(m['status']!='reviewing' for m in b['receipt']['members'])
        results[kind+'-get-coherent-prefix']={'sessions':[a,b],'actualWait':wait};save()
        # Cancellation commits first: no subsequent actual private reservation.
        args_seed,scan,child=setup(kind,'cancel-first-'+token)
        one=session(kind+'-cancel-first',"begin;select id from public.translation_jobs where id="+sql_literal(scan['jobId'])+" for update;select pg_sleep(2.0);"+role+"select public.request_translation_job_cancel("+sql_literal(scan['jobId'])+','+scan['jobVersion']+");commit;");sleep=barrier(one,True)
        two=session(kind+'-dispatch-wait','begin;'+role+caught(dispatch(kind,child))+'commit;');wait=barrier(two);a,b=finish(one),finish(two)
        cache='writer_operation_artifacts' if kind=='writer' else 'catalog_operation_artifacts'
        count=query("select jsonb_build_object('calls',jsonb_array_length(calls)) from premium_translation_private."+cache+" where operation_id="+sql_literal(child['operationId']))
        assert b['receipt']['errorCode']=='40001' and count['calls']==0
        finish_expr='public.finish_'+('writer' if kind=='writer' else 'catalog')+"_translation_operation("+','.join(sql_literal(child[k]) for k in ['jobId','itemId','operationId'])+",'{\"status\":\"skipped\",\"providerCalls\":0}',null)"
        done=query('begin;'+role+'select '+finish_expr+';commit;')
        current=query('begin;'+role+'select public.get_profile_translation_scan('+sql_literal(scan['jobId'])+');commit;')
        held=query('begin;'+role+'select public.profile_scan_fixture_checkpoint_child('+json_literal(current)+','+json_literal(done)+');commit;')
        assert held['nextPosition']==0 and held['child'] is None and held['transition']=='zero-call-held'
        results[kind+'-cancel-before-dispatch']={'sessions':[a,b],'actualWait':wait,'count':count,'zeroHeld':held};save()
        # Reservation commits first; accepted output survives parent cancel, review denied.
        args_seed,scan,child=setup(kind,'dispatch-first-'+token)
        one=session(kind+'-dispatch-first','begin;'+role+'select '+dispatch(kind,child)+';select pg_sleep(2.0);commit;');sleep=barrier(one,True)
        two=session(kind+'-cancel-wait','begin;'+role+'select public.request_translation_job_cancel('+sql_literal(scan['jobId'])+','+scan['jobVersion']+');commit;');wait=barrier(two);a,b=finish(one),finish(two)
        accepted=a['receipt']
        if kind=='writer':response=query('begin;'+role+'select public.writer_operation_fixture_response('+json_literal(accepted)+');commit;')
        else:
            metadata={'callId':accepted['pendingCallId'],'provider':'cloudflare','model':'fixture-translator','pass':'translation','httpStatus':None,'requestId':None,'responseId':'profile-native-after-cancel','inputTokens':5,'outputTokens':6}
            artifact={'version':1,'body':{'response':json.dumps(args_seed['payload']['fields'],ensure_ascii=False,separators=(',',':'))}}
            response=query('begin;'+role+'select public.record_catalog_translation_operation_response('+','.join(sql_literal(child[k]) for k in ['jobId','itemId','operationId'])+','+json_literal(metadata)+','+json_literal(artifact)+');commit;')
        denied=query('begin;'+role+caught(dispatch(kind,child,True))+'commit;')
        finish_expr='public.finish_'+('writer' if kind=='writer' else 'catalog')+"_translation_operation("+','.join(sql_literal(child[k]) for k in ['jobId','itemId','operationId'])+",'{\"status\":\"cancelled\",\"providerCalls\":1}',null)"
        done=query('begin;'+role+'select '+finish_expr+';commit;')
        current=query('begin;'+role+'select public.get_profile_translation_scan('+sql_literal(scan['jobId'])+');commit;')
        terminal=query('begin;'+role+'select public.profile_scan_fixture_checkpoint_child('+json_literal(current)+','+json_literal(done)+');commit;')
        retained=query("select jsonb_build_object('calls',jsonb_array_length(calls),'bodyRetained',calls->0->'responseArtifact'<>'null'::jsonb) from premium_translation_private."+cache+" where operation_id="+sql_literal(child['operationId']))
        assert denied['errorCode']=='40001' and retained['calls']==1 and retained['bodyRetained'] and terminal['status']=='cancelled'
        results[kind+'-dispatch-before-cancel']={'sessions':[a,b],'actualWait':wait,'response':response,'reviewDenied':denied,'retained':retained,'parentTerminal':terminal};save()
    (out/'results.json').write_text(json.dumps({'classification':'ACTUAL_OWNED_LOOPBACK_CONCURRENCY_NOT_MANAGED_E2E','atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'groups':results,'pass':len(results),'fail':0,'providerCalls':0},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'pass':len(results),'fail':0,'groups':list(results),'out':str(out)}))
finally:
    for s in processes:
        if s['process'].poll() is None:
            s['process'].terminate()
            try:s['process'].wait(timeout=10)
            except subprocess.TimeoutExpired:s['process'].kill();s['process'].wait(timeout=10)
        if not s['stdout'].closed:s['stdout'].close()
        if not s['stderr'].closed:s['stderr'].close()
    (out/'session-cleanup.json').write_text(json.dumps({'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sessions':[{'label':s['label'],'pid':s['process'].pid,'exitCode':s['process'].poll()} for s in processes],'allTerminal':all(s['process'].poll() is not None for s in processes)},indent=2)+'\n',encoding='utf-8')
