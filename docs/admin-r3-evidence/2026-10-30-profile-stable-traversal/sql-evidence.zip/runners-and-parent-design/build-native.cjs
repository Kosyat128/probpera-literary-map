// Parent helper only. Produces a loopback-owned runner; execution needs root release.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),out=path.resolve(__dirname,'../profile-scan-sql-native'),prior=path.resolve(__dirname,'../library-scan-sql-native');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
fs.mkdirSync(out,{recursive:true});
const version=process.argv[2];assert.match(version||'',/^v\d+$/);const database=`profile_scan_${version}_20261030`;
const migration=process.argv[3],fixture=process.argv[4];assert(migration&&fixture,'Supply exact CLI migration and maintained fixture after release');
const foundationManifest=read(path.join(prior,'final-source-manifest.json'));
function verify(m){for(const r of m.sources||[]){const b=fs.readFileSync(path.join(repo,r.file));assert.equal(sha(b),r.sha256,r.file);}if(m.foundation)verify(m.foundation);}
verify(foundationManifest);
const foundation=fs.readFileSync(path.join(prior,'fixture.sql'));assert.equal(sha(foundation),foundationManifest.fixtureSha256);
const baselineSql=`
reset role;
create table public.profile_scan_fixture_baseline(label text primary key,value jsonb not null);
insert into public.profile_scan_fixture_baseline values('functions',(select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'source',p.prosrc,'securityDefiner',p.prosecdef,'config',p.proconfig,'acl',p.proacl) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in ('premium_translation_private','probpera_translation_operations') or(n.nspname='public' and p.proname not like '%fixture%' and(p.proname like '%translation%' or p.proname like '%premium%'))));
insert into public.profile_scan_fixture_baseline values('tables',(select jsonb_agg(jsonb_build_object('name',c.oid::regclass::text,'acl',c.relacl,'forceRls',c.relforcerowsecurity,'rls',c.relrowsecurity,'columns',(select jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull) order by a.attnum) from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped)) order by c.oid::regclass::text) from pg_class c where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass)));
insert into public.profile_scan_fixture_baseline values('indexes',(select jsonb_agg(jsonb_build_object('schema',n.nspname,'name',ci.relname,'definition',pg_get_indexdef(ci.oid)) order by n.nspname,ci.relname) from pg_index i join pg_class c on c.oid=i.indrelid join pg_class ci on ci.oid=i.indexrelid join pg_namespace n on n.oid=ci.relnamespace where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass)));
`;
const sources=[];function source(file){const b=fs.readFileSync(path.join(repo,file));sources.push({file,bytes:b.length,sha256:sha(b)});const dest=path.join(out,'sources',file);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,b);return b;}
const bytes=Buffer.concat([foundation,Buffer.from(baselineSql),source(migration),Buffer.from('\n'),source(fixture)]);
const run=path.join(out,version);assert(!fs.existsSync(run),'Never overwrite a prior native run');fs.mkdirSync(run);
fs.writeFileSync(path.join(run,'fixture.sql'),bytes);
fs.writeFileSync(path.join(run,'source-manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),database,sources,foundation:foundationManifest,foundationSha256:sha(foundation),fixtureSha256:sha(bytes)},null,2));
const asciiRoot='C:\\Users\\685F~1\\DOCUME~1\\Codex\\2026-1~1\\v\\work\\profile-scan-sql-native\\'+version;
const powershell=`$ErrorActionPreference='Stop'
$nativeRoot='${asciiRoot}'
$clusterRoot='C:\\Users\\685F~1\\DOCUME~1\\Codex\\2026-1~1\\v\\work\\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory -or $owned.service){throw 'Unexpected owned isolated cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID still exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false;$exitCode=1
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned local PostgreSQL start failed'}
 $started=$true;$ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8';$psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not owned loopback cluster'}
 $database='${database}'
 $exists=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc "select count(*) from pg_database where datname='$database'"
 if($exists -ne '0'){throw 'Native database already exists; refusing reset'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc --set=ON_ERROR_STOP=1 -c "create database $database"
 if($LASTEXITCODE -ne 0){throw 'Native database creation failed'}
 $stamp=[DateTime]::UtcNow
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'fixture.sql') *> (Join-Path $nativeRoot 'run.log')
 $exitCode=$LASTEXITCODE
 [pscustomobject]@{database=$database;startedAt=$stamp.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');exitCode=$exitCode;elapsedMs=([DateTime]::UtcNow-$stamp).TotalMilliseconds;loopback='127.0.0.1';port=55438;providerCalls=0}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'run-receipt.json') -Encoding utf8
 Get-Content -LiteralPath(Join-Path $nativeRoot 'run.log')|Select-Object -Last 9
 Write-Output ('PSQL_EXIT='+$exitCode)
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
exit $exitCode
`;
fs.writeFileSync(path.join(run,'run.ps1'),'\uFEFF'+powershell);
console.log(JSON.stringify({classification:'PREPARED_NOT_EXECUTED',database,run,fixtureBytes:bytes.length,fixtureSha256:sha(bytes),sourceInputs:sources}));
