Stable writer/country tuple traversal, local verification only.

Final215-file whole suite:6768/6774 pass, same6 historical M02 missing-original failures, zero pending/todo. Four other gates pass; readonly log is the exact41 prior findings. No excluded normalizer edit.

V3raw6774/6758/16 and isolated unchanged117/117 remain retained; V4same-source full rerun resolves the10 timeout-only failures without timeout/cache/assertion/code edits. Original V3build/type checks are reused with exact full input-entry equality.

Original5489 BEFORE and original a988 contract are immutable; CURRENT preserves all8 actual coverage/no-repeat targets. Fresh-new-scan versus Continue and the support-only legacy graph probe are explicitly separated. Original unsupported action-graph control/fresh-trigger intermediate history remain visible.

See final/validation-summary.json and the separate controlled/native archives for precise contracts, source bindings and limitations. Full M07/R3 acceptance is not claimed.
