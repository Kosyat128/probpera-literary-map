from pathlib import Path
import datetime, hashlib, json, zipfile

work=Path(__file__).resolve().parent
repo=work.parent/'probpera-literary-map'
out=work/'profile-stable-scan-final-validation-v4'
gate_out=work/'profile-stable-scan-final-validation-v3'
folder=repo/'docs/admin-r3-evidence/2026-10-30-profile-stable-traversal'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((out/n).read_text(encoding='utf-8-sig'))
def write(n,v): (out/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

read_gate=lambda n:json.loads((gate_out/n).read_text(encoding='utf-8-sig'))
before,after,tests,receipt=[read(n) for n in ['source-before.json','source-after-tests.json','selected-tests-summary.json','selected-tests-receipt.json']]
gates,drift=read_gate('gates-summary.json'),read_gate('source-drift.json')
preservation,increment=read_gate('baseline-preservation.json'),read_gate('increment-source-comparison.json')
assert before['files']==after['files']==read_gate('source-before.json')['files']==read_gate('source-after-gates.json')['files']
write('unchanged-source-gate-reuse.json',{'classification':'EXACT_UNCHANGED_INPUTS_GATE_REUSE_WITHOUT_REEXECUTION','gateRun':'profile-stable-scan-final-validation-v3','testRun':'profile-stable-scan-final-validation-v4','allTrackedAndOwnedFileEntriesIdentical':True,'testAfterMatchesGateBeforeAndAfter':True,'scope':'Original gate receipts/logs/times remain intact. All6774 tests reran; build/type/client checks are reused only because every input entry is byte-identical.'})
fingerprint='1af04f3230b3395637a3e06090c1b25c72c66735d4c185be36c626374e4df02e'
assert before['validationSourceSha256']==after['validationSourceSha256']==fingerprint
assert before['head']==after['head']=='acb910d89133396e8e9794e91bd5db74128dab3b'
assert drift['zeroValidationSourceDrift'] and drift['zeroTrackedFileDrift']
assert tests['testFileCount']==215 and tests['numTotalTests']==6774 and tests['numPassedTests']==6768
assert tests['numFailedTests']==6 and tests['numPendingTests']==tests['numTodoTests']==0
assert receipt['finishedAt'] and preservation['pass'] and increment['status']=='PASS'
assert len(increment['changedExisting'])==18 and len(increment['added'])==11 and increment['unchangedOriginalSourceCount']==10447
assert after['validationSourceCount']==10476 and after['trackedFileCount']==10703
assert gates['passed']==4 and gates['total']==5 and gates['zeroValidationSourceDrift']
assert all(g['status']=='PASS' or g['id']=='gate-readonly-hyphens' for g in gates['receipts'])

prior=repo/'docs/admin-r3-evidence/2026-10-30-stable-traversal/whole-validation-evidence.zip'
assert sha(prior.read_bytes())=='549bd5b93aaf65da2ae913cdcedb9b233b4407f4f85a894987610cf3841fff28'
with zipfile.ZipFile(prior) as z:
 prior_test_bytes=z.read('final/selected-tests-summary.json')
 prior_tests=json.loads(prior_test_bytes)
 prior_text=z.read('final/gate-readonly-hyphens-after-doc-correction.log')
def failures(r):
 return sorted([{'fullName':c['fullName'],'firstErrors':[e.replace('\r\n','\n').split('\n')[0] for e in c.get('failureMessages',[])]}
  for f in r.get('failedFiles',[]) for c in f.get('assertionFailures',[])],key=lambda c:c['fullName'])
assert failures(tests)==failures(prior_tests)
comparison={'sameFailureCasesAndFirstErrors':True,'priorArchiveSha256':sha(prior.read_bytes()),'prior':failures(prior_tests),'current':failures(tests),
 'scope':'Exact six historical missing-original M02 failures; CRLF normalization only. No reconstruction, skip or substitute.'}
write('baseline-failure-comparison.json',comparison)
text=(gate_out/'gate-readonly-hyphens.log').read_bytes()
assert text==prior_text
assert sum(l.startswith('- ') for l in text.decode('utf-8-sig').splitlines())==41
write('readonly-gate-baseline-comparison.json',{'byteIdenticalToPreviousFinalBaseline':True,'sha256':sha(text),'findingCount':41,'normalizerWriteFlagUsed':False})

native_folder=work/'profile-scan-sql-native'
native=json.loads((native_folder/'native-summary-final.json').read_text(encoding='utf-8'))
assert native['nativeGoldens']['count']==56 and native['nativeGoldens']['sha256']=='e338b3303355bbc57cf4bcb9eee84d72fd1a5a889ab29d48bc15fd42af0cad15'
assert native['advisors']['current']==15 and native['advisors']['new']==native['advisors']['removed']==0
frozen={f['path']:f for f in after['files']}
for row in native['nativeSourceInputs']:
 assert sha((repo/row['file']).read_bytes())==row['sha256']==frozen[row['file']]['sha256']
native_binding={'sourceFingerprint':fingerprint,'currentNativeSourceInputs':len(native['nativeSourceInputs']),'allMatchFrozenAndCurrent':True,
 'nativeArchiveScope':'SQL-only; separate controlled evidence supplies raw goldens through installed SDK/strict parser and GET adapter. Other mutator wrappers have distinct controlled guards/action integration, not a claim of native end-to-end invocation.',
 'nativeGoldens':native['nativeGoldens'],'oldPreservation':native['oldPreservation'],'advisors':native['advisors']}
write('native-global-binding.json',native_binding)

external=[]
paths=[folder/'profile-stable-scan-controlled-tests.zip',folder/'sql-evidence.zip',folder/'next-retry-partial-before.zip',
 repo/'docs/admin-r3-evidence/2026-10-30-stable-traversal/next-profile-traversal-before.zip',
 repo/'docs/admin-r3-evidence/2026-10-30-stable-traversal/next-profile-traversal-current-1de717.zip']
for p in paths: external.append({'path':p.relative_to(repo).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
summary={'schemaVersion':1,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':before['head'],
 'classification':'LOCAL_STABLE_PROFILE_TRAVERSAL_VERIFIED_WITH_KNOWN_BASELINE_FAILURES_NOT_FULL_M07_R3',
 'source':{'fingerprint':fingerprint,'nonDocFiles':10476,'fullFrozenEntries':10703,'changedVersusDa9':18,'addedVersusDa9':11,'previousFilesExact':10447,'zeroDrift':True,
 'ownedScope':'All tracked files and every task-owned untracked file under apps/admin, scripts/database and supabase/migrations, including JSON fixtures. docs/ excluded only from source fingerprint.'},
 'tests':{'files':215,'total':6774,'passed':6768,'failed':6,'pending':0,'todo':0,'sameSixHistoricalM02Failures':True,'durationMs':receipt['durationMs']},
 'gates':{**gates,'reusedFromExactUnchangedInputs':'profile-stable-scan-final-validation-v3','readonlyFindings':41,'readonlyLogByteIdenticalToPreviousFinalBaseline':True},
 'native':native_binding,'externalArchives':external,
 'limits':['Full initial profile tuple/hash manifest is finite: at most10000 members/20 windows/4MiB. No truncation or immutable all-future corpus claim.',
 'Writer3 attempts/12 reservations/120 inspections and country2/8/30 keep300000ms budgets and original review/token contracts. No global concurrency/billing quota or service-role lease expansion is proved.',
 'Cancellation applies to the actual window; eager successors do not permit skipping an unfinished prefix or bypassing a stopped historical window.',
 'Original1032 country action-only dependency-graph control remains unsupported after removal of posthoc aggregation. Its original failure is retained. The explicitly versioned combined verification graph adds a separately executed zero-RPC empty legacy API compatibility probe, not an action dependency. The four behavioral assertions and genuine fresh POST semantics remain unchanged.',
 'Four legacy ordinal-routing intents were explicitly superseded by durable-manifest refusal; all other old assertions/normalizer/public-admission scopes remain preserved.',
 'Native SQL, SDK/strict-parser/GET replay, controlled mutator/action checks, SSR and focused scopes are distinct and overlap; none is230 acceptance criteria or a managed/browser end-to-end run.',
 'Partial-pass replay, addressed operator retry, global budgets, broader M07/M24/M04/M02/M13 and full26-module/230-criterion acceptance remain open.',
 'No real keys/setup, paid provider, production migration/deploy, push, PR, mass backfill or social send.']}
write('validation-summary.json',summary)

entries={'final/'+p.name:p.read_bytes() for p in out.iterdir() if p.is_file() and p.suffix in ['.json','.log','.txt','.md']}
for name in ['profile-stable-scan-final-validation-v4-runner.mjs','profile-stable-scan-increment-comparison-v3.mjs','profile-stable-scan-preservation-v3.mjs','package-profile-stable-scan-final-validation-v4.py','retain-profile-stable-scan-sql-evidence.py']:
 entries['runners/'+name]=(work/name).read_bytes()
for version in ['v1','v2']:
 d=work/('profile-stable-scan-final-validation-'+version)
 for p in d.iterdir():
  if p.is_file() and p.suffix in ['.json','.log','.txt','.md']: entries['history/snapshot-only-'+version+'/'+p.name]=p.read_bytes()
for p in gate_out.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.txt','.md']: entries['history/whole-v3-timeout-and-gates/'+p.name]=p.read_bytes()
previous_run=read_gate('selected-tests-summary.json')
assert previous_run['numTotalTests']==6774 and previous_run['numPassedTests']==6758 and previous_run['numFailedTests']==16 and previous_run['numPendingTests']==0
for name in ['baseline-preservation.json','increment-source-comparison.json','gates-summary.json','source-drift.json']:
 entries['reused-checks-v3/'+name]=(gate_out/name).read_bytes()
for p in gate_out.iterdir():
 if p.is_file() and p.name.startswith('gate-'):entries['reused-checks-v3/'+p.name]=p.read_bytes()
root_audit=work/'profile-stable-independent-audit-sol'
for p in root_audit.rglob('*.json'):
 entries['root/independent-audits/'+p.relative_to(root_audit).as_posix()]=p.read_bytes()
for p in root_audit.glob('library-isolated-*'):
 if not p.is_dir():continue
 for f in p.iterdir():
  if f.is_file() and f.suffix in ['.log','.txt']:entries['root/independent-audits/'+f.relative_to(root_audit).as_posix()]=f.read_bytes()
entries['root/next-retry-partial-before.receipt.json']=(folder/'next-retry-partial-before.receipt.json').read_bytes()
entries['history/snapshot-only-scope.txt']=b'V1 and V2 capture intermediate source inventories/protection. No whole broad suite or gates ran on them. Earlier focused failures and the V2 Continue-versus-fresh trigger defect retain their original scope in the controlled archive. V3whole completed with6historical+10timeout-only library failures; original unchanged117/117 isolated passed at5000ms. FinalV4 reruns all6774; same-source successful V3gates are explicitly reused. V3stale-tool-handle observation is corrected by producer receipts, not treated as a lost test report.\n'
entries['baseline/selected-tests-summary.json']=prior_test_bytes
entries['baseline/final-readonly.log']=prior_text
entries['root/profile-actions-unrelated-preservation.json']=(work/'profile-actions-unrelated-preservation.json').read_bytes()
entries['root/native-summary-final.json']=(native_folder/'native-summary-final.json').read_bytes()
entries['external-receipts/sql-evidence.receipt.json']=(folder/'sql-evidence.receipt.json').read_bytes()
entries['external-receipts/profile-stable-scan-controlled-tests.receipt.json']=(folder/'profile-stable-scan-controlled-tests.receipt.json').read_bytes()
entries['README.md']=('Stable writer/country tuple traversal, local verification only.\n\n'
 'Final215-file whole suite:6768/6774 pass, same6 historical M02 missing-original failures, zero pending/todo. Four other gates pass; readonly log is the exact41 prior findings. No excluded normalizer edit.\n\n'
 'V3raw6774/6758/16 and isolated unchanged117/117 remain retained; V4same-source full rerun resolves the10 timeout-only failures without timeout/cache/assertion/code edits. Original V3build/type checks are reused with exact full input-entry equality.\n\n'
 'Original5489 BEFORE and original a988 contract are immutable; CURRENT preserves all8 actual coverage/no-repeat targets. Fresh-new-scan versus Continue and the support-only legacy graph probe are explicitly separated. Original unsupported action-graph control/fresh-trigger intermediate history remain visible.\n\n'
 'See final/validation-summary.json and the separate controlled/native archives for precise contracts, source bindings and limitations. Full M07/R3 acceptance is not claimed.\n').encode()
manifest={'schemaVersion':1,'sourceFingerprint':fingerprint,'classification':summary['classification'],'entries':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(entries.items())]}
entries['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
target=folder/'whole-validation-evidence.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for n,b in sorted(entries.items()):z.writestr(n,b)
with zipfile.ZipFile(target) as z:
 for r in manifest['entries']:assert len(z.read(r['path']))==r['bytes'] and sha(z.read(r['path']))==r['sha256']
result={'archive':target.name,'sha256':sha(target.read_bytes()),'bytes':target.stat().st_size,'verifiedPayloads':len(manifest['entries']),
 'sourceFingerprint':fingerprint,'testFiles':215,'testsPassed':6768,'testsFailed':6,'sameSixHistoricalM02Failures':True,'gatesPassed':4,'gatesTotal':5,'readonlyBaselineFindings':41,'zeroSourceDrift':True}
(folder/'whole-validation-evidence.receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
