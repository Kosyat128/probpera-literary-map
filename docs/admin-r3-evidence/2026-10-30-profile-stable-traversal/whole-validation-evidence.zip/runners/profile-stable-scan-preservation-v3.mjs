import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const work=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(work,'../probpera-literary-map');
const out=path.join(work,'profile-stable-scan-final-validation-v3');
const ts=createRequire(path.join(root,'package.json'))('typescript');
const baseline=JSON.parse(fs.readFileSync(path.join(work,'continuation-validation/source-before.json'),'utf8'));
const initial=new Map(baseline.files.map(f=>[f.path,f]));
const sha=b=>createHash('sha256').update(b).digest('hex');
const compare=p=>({path:p,baselineSha256:initial.get(p)?.sha256??null,currentSha256:fs.existsSync(path.join(root,p))?sha(fs.readFileSync(path.join(root,p))):null});
const checked=paths=>paths.map(p=>{const v=compare(p);return {...v,unchanged:v.baselineSha256===v.currentSha256};});
const normalizers=['scripts/normalize-short-hyphens.mjs','scripts/lib/short-hyphens.mjs','apps/admin/lib/short-hyphens.ts','src/utils/shortHyphens.ts'];
const telegram=['scripts/lib/literary-news-media.test.mjs','scripts/lib/literary-news-social.mjs','scripts/lib/literary-news-social.test.mjs','scripts/lib/literary-news-telegram-footer.test.mjs','scripts/lib/literary-news-text-fallback.test.mjs','scripts/workers/literary-news-delivery-worker.test.mjs'];
const ruleTests=baseline.files.filter(f=>/(?:short.?hyphen|punctuation)/iu.test(f.path)&&!f.path.startsWith('docs/')).map(f=>f.path);
const oldMigrations=baseline.files.filter(f=>f.path.startsWith('supabase/migrations/')).map(f=>f.path);
function scopes(p,source){
 const text=source.replace(/\r\n?/gu,'\n'),sf=ts.createSourceFile(p,text,ts.ScriptTarget.Latest,true,p.endsWith('x')?ts.ScriptKind.TSX:ts.ScriptKind.TS),imports=[],calls=[];
 function visit(n){if(ts.isImportDeclaration(n)&&/short.?hyphen/iu.test(n.moduleSpecifier.getText(sf)))imports.push(n.getText(sf));if(ts.isCallExpression(n)&&/normalizeShortHyphens/u.test(n.expression.getText(sf)))calls.push(n.getText(sf));ts.forEachChild(n,visit);}visit(sf);return {imports,calls};
}
const callScopes=[];
for(const f of baseline.files){
 if(!/\.(?:[cm]?js|tsx?)$/u.test(f.path)||/\.test\./u.test(f.path)||normalizers.includes(f.path))continue;
 const current=fs.readFileSync(path.join(root,f.path),'utf8');
 if(!/normalizeShortHyphens|short-hyphens|shortHyphens/u.test(current))continue;
 const original=execFileSync('git',['show','HEAD:'+f.path],{cwd:root,encoding:'utf8',maxBuffer:16*1024*1024});
 const before=scopes(f.path,original),after=scopes(f.path,current);
 if(!before.calls.length&&!before.imports.length&&!after.calls.length&&!after.imports.length)continue;
 callScopes.push({path:f.path,wholeFileUnchanged:initial.get(f.path).sha256===sha(fs.readFileSync(path.join(root,f.path))),comparison:'AST import and call text after CRLF/LF normalization',before,after,unchanged:JSON.stringify(before)===JSON.stringify(after)});
}
const result={head:baseline.head,checkedAt:new Date().toISOString(),normalizers:checked(normalizers),normalizerRulesAndTests:checked(ruleTests),normalizerImportAndCallScopes:callScopes,oldMigrations:checked(oldMigrations),independentTelegram:checked(telegram),telegramPatch:checked(['docs/admin-r3-evidence/2026-10-09-handoff/independent-telegram.patch']),packages:checked(['package.json','package-lock.json','apps/admin/package.json']),allOriginalNonDocsChanges:checked(baseline.files.filter(f=>!f.path.startsWith('docs/')).map(f=>f.path)).filter(f=>!f.unchanged),normalizerWriteFlagUsed:false};
result.pass=[...result.normalizers,...result.normalizerRulesAndTests,...callScopes,...result.oldMigrations,...result.independentTelegram,...result.telegramPatch,...result.packages].every(v=>v.unchanged);
fs.writeFileSync(path.join(out,'baseline-preservation.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({pass:result.pass,normalizers:result.normalizers.length,rulesAndTests:result.normalizerRulesAndTests.length,callScopes:callScopes.length,oldMigrations:oldMigrations.length,telegram:telegram.length,packages:result.packages.length,intendedOriginalNonDocsChanges:result.allOriginalNonDocsChanges.map(x=>x.path)},null,2));process.exitCode=result.pass?0:1;
