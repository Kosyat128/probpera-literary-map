from pathlib import Path, PurePosixPath
import datetime, hashlib, json, zipfile
work=Path(__file__).resolve().parent
repo=work.parent/'probpera-literary-map'
source=work/'profile-scan-sql-native/profile-sql-evidence.zip'
folder=repo/'docs/admin-r3-evidence/2026-10-30-profile-stable-traversal'
sha=lambda b:hashlib.sha256(b).hexdigest()
expected='cc0ceb177384bea9ddf2a575fafd3a1dec629fe27c1b5de9601837b22a7601b6'
assert sha(source.read_bytes())==expected
snapshot=json.loads((work/'profile-stable-scan-final-validation-v1/source-before.json').read_text(encoding='utf-8'))
frozen={row['path']:row for row in snapshot['files']}
assert snapshot['validationSourceSha256']=='3011c18ee1b73a306883e28cee0791b0fe2e861526ca545b5db531443c9fa2c3'
with zipfile.ZipFile(source) as z:
 names=z.namelist();m=json.loads(z.read('manifest.json'));s=json.loads(z.read('summary.json'))
 assert len(names)==len(set(names))==989 and len(m['entries'])==988 and len(m['sourceInputs'])==39
 assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n and ':' not in n for n in names)
 assert set(names)=={row['path'] for row in m['entries']}|{'manifest.json'}
 for row in m['entries']:
  b=z.read(row['path']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
 for row in m['sourceInputs']:
  b=(repo/row['file']).read_bytes()
  assert len(b)==row['bytes'] and sha(b)==row['sha256']==frozen[row['file']]['sha256']
 assert s['storedCoreLabels']==21 and s['coreLabelsIncludeSetupAndIntermediateReceipts']
 assert s['concurrentGroups']['twoSession']==10 and s['concurrentGroups']['threeSession']==2
 assert s['nativeGoldens']['count']==56 and s['nativeGoldens']['sha256']=='e338b3303355bbc57cf4bcb9eee84d72fd1a5a889ab29d48bc15fd42af0cad15'
 assert s['oldPreservation']=={'routineBodiesSecurityConfigAcl':139,'tableColumnsRlsAcl':5,'indexes':24,'allExact':True}
 assert all(r['pgCtlExitCode']==0 and not r['processRemains'] and not r['pidFileRemains'] and not r['serviceCreated'] for r in s['cleanup'])
folder.mkdir(parents=True,exist_ok=True)
target=folder/'sql-evidence.zip'
with target.open('xb') as f:f.write(source.read_bytes())
assert sha(target.read_bytes())==expected
result={'status':'ROOT_INDEPENDENT_NATIVE_ARCHIVE_READBACK_PASS','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'archive':target.name,'bytes':target.stat().st_size,'sha256':expected,'verifiedPayloads':988,'safeUniquePaths':True,
 'sourceInputs':39,'allSourceBindingsMatchCurrentAndFrozenSnapshot':True,'validationSourceSha256':snapshot['validationSourceSha256'],
 'storedCoreLabels':s['storedCoreLabels'],'coreLabelsIncludeSetupAndIntermediateReceipts':True,
 'forgeryMatrixCases':14,'concurrentGroups':s['concurrentGroups'],'nativeGoldens':s['nativeGoldens'],
 'oldPreservation':s['oldPreservation'],'advisors':s['advisors'],'committed10000Performance':s['committed10000Performance'],
 'cleanup':s['cleanup'],'sdkScope':'Native-only archive. Installed SDK/DTO/action/UI acceptance belongs to the separate controlled evidence and final cross-artifact receipt.',
 'limitations':s['limitations']}
(folder/'sql-evidence.receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ['status','sha256','verifiedPayloads','sourceInputs','validationSourceSha256']}))
