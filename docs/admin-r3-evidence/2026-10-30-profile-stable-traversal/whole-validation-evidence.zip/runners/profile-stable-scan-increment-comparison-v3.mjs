import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const work=path.dirname(fileURLToPath(import.meta.url));
const priorPath=path.join(work,'library-stable-scan-final-validation-v2/source-before.json');
const currentPath=path.join(work,'profile-stable-scan-final-validation-v3/source-before.json');
const prior=JSON.parse(fs.readFileSync(priorPath,'utf8')),current=JSON.parse(fs.readFileSync(currentPath,'utf8'));
const hash=value=>createHash('sha256').update(value).digest('hex');
const before=new Map(prior.files.filter(f=>!f.path.startsWith('docs/')).map(f=>[f.path,f]));
const after=new Map(current.files.filter(f=>!f.path.startsWith('docs/')).map(f=>[f.path,f]));
const changed=[...after.values()].filter(f=>before.has(f.path)&&JSON.stringify(before.get(f.path))!==JSON.stringify(f));
const added=[...after.values()].filter(f=>!before.has(f.path));
const removed=[...before.values()].filter(f=>!after.has(f.path));
assert.equal(prior.validationSourceSha256,'da9ee3fa7dab3dd2ea1f5cc2f5c3aa174bf3c3b9061d2729fd3201fe21ccecbd');
assert.equal(prior.head,current.head);assert.deepEqual(removed,[]);
assert.deepEqual(changed.map(f=>f.path).sort(),["apps/admin/app/(dashboard)/translations/actions.ts", "apps/admin/app/(dashboard)/translations/country-actions.ts", "apps/admin/app/(dashboard)/translations/library-scan-ui.integration.test.ts", "apps/admin/app/(dashboard)/translations/page.tsx", "apps/admin/app/(dashboard)/translations/resume-action.ts", "apps/admin/lib/auto-translate-country-profile.ts", "apps/admin/lib/auto-translate-writer-biography.ts", "apps/admin/lib/catalog-admission-routing.integration.test.ts", "apps/admin/lib/country-profile-machine-review.integration.test.ts", "apps/admin/lib/fixtures/catalog-admission-runtime.cjs", "apps/admin/lib/fixtures/country-batch-budget-cap.cjs", "apps/admin/lib/fixtures/profile-library-budget-controls.cjs", "apps/admin/lib/fixtures/writer-admission-runtime.cjs", "apps/admin/lib/fixtures/writer-batch-budget-cap.cjs", "apps/admin/lib/fixtures/writer-biography-machine-review.cjs", "apps/admin/lib/profile-library-batch-budgets.integration.test.ts", "apps/admin/lib/writer-admission-routing.integration.test.ts", "apps/admin/lib/writer-translation-operation.ts"]);
assert.deepEqual(added.map(f=>f.path).sort(),["apps/admin/app/(dashboard)/translations/profile-scan-ui.integration.test.ts", "apps/admin/lib/fixtures/profile-translation-scan-boundary.cjs", "apps/admin/lib/fixtures/profile-translation-scan-cases.cjs", "apps/admin/lib/fixtures/profile-translation-scan-native-goldens.json", "apps/admin/lib/fixtures/profile-translation-scan-runtime.cjs", "apps/admin/lib/profile-translation-scan-rpc.integration.test.ts", "apps/admin/lib/profile-translation-scan-rpc.ts", "apps/admin/lib/profile-translation-scan.integration.test.ts", "apps/admin/lib/profile-translation-scan.ts", "scripts/database/fixtures/profile-translation-stable-scan.sql", "supabase/migrations/20261030072209_profile_translation_stable_scan.sql"]);
const result={status:'PASS',capturedAt:new Date().toISOString(),head:current.head,
 previousManifestSha256:hash(fs.readFileSync(priorPath)),currentManifestSha256:hash(fs.readFileSync(currentPath)),
 previousSourceCount:before.size,currentSourceCount:after.size,previousSourceFingerprint:prior.validationSourceSha256,currentSourceFingerprint:current.validationSourceSha256,
 changedExisting:changed.map(f=>({path:f.path,beforeSha256:before.get(f.path).sha256,afterSha256:f.sha256})),added,removed,
 unchangedOriginalSourceCount:before.size-changed.length,allChangesMatchDeclaredIncrement:true,
 comparisonExclusion:'docs/ only; every tracked/owned non-doc source compared.'};
fs.writeFileSync(path.join(work,'profile-stable-scan-final-validation-v3/increment-source-comparison.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:'PASS',changed:changed.length,added:added.length,unchangedPrevious:result.unchangedOriginalSourceCount,sourceCount:after.size,fingerprint:current.validationSourceSha256}));
