# Frozen-source final validation

This archive contains raw current test JSON, terminal command receipts/logs,
the exact selection, before/after source manifests, explicit drift reports and
preservation audits. validation-summary.json is an index, not a clean acceptance.

The broad suite remains FAILED on the same six genuine missing historical M02
fixture cases. The unchanged readonly text gate also remains FAILED. The other
four required gates passed. No skip, replacement baseline, formatter write or
weakened assertion was introduced. Compare baseline-failure-comparison.json and
readonly-gate-baseline-comparison.json against the preserved baseline inputs.

The first final run is retained unmodified under diagnostics/v1-new-failures:
6058/6070 with 12 failures. Six additional SSR failures came from expired
provider-probe mock timestamps. Exactly one timestamp field in each of two test
files changed to the current time; no assertion, guard or production code changed.
The correction receipt, independent whole-source comparison and 117/117 targeted
raw test report are included. The final V2 run executes the full selection again
on its own recorded source fingerprint; V1 has not been relabelled as passing.

The first five-gate run also retains its failed build receipt/log: compilation,
TypeScript and static rendering succeeded, then Windows denied a trace-copy
mkdir in generated standalone output. One narrow same-source build retry ran
with the identical child environment policy and local command in a context
allowed to create those generated directories. Its actual terminal result is
recorded separately; the other passing gates were not repeated. Final effective
gate status and post-retry source drift are explicit, without overwriting the
original three-of-five result.

Both recorded source fingerprints exclude docs/ only. The full6070 suite belongs
to its V2 pre-escape fingerprint. The final fingerprint differs in exactly two
new fixtures: Unicode source-literal escapes preserve all499 JavaScript literal
values and the full PostgreSQL stage arguments/candidate digest. Fresh controlled
runtime70/70, nativeSQL28 groups, DTO14 and a readonly text check on final files
supplement the V2 broad result. There was no full6070 rerun after these proven
presentation-only changes. All other10410 non-document source files, including
application and migration code, remain byte-identical to V2. Raw snapshots retain
tracked documents and explicit drift. This is not full M00-M25/230 acceptance.

The preservation report covers all four normalizers, 19 related rules/tests,
16 AST import/call scopes, 64 old migrations, six independent Telegram paths,
their saved patch and three package/lock files. A separate fresh BEFORE binding
checks Site Copy's seven direct normalizer call texts, submittedRows and both
library/writer batch function texts; only CRLF/LF is normalized in comparison.

The runner strips credentials from child environments and uses a workspace-only
temporary directory. Temporary caches, dependencies, native binaries, generated
byte backups, credentials and personal sessions are excluded from this archive.
Native SQL and controlled paired runtime evidence are packaged separately.

Verify archive/member hashes before extraction into an empty scratch directory.
Runners contain historical absolute paths and expect the corresponding current
repository plus locked dependencies; adapt paths deliberately and use fresh
output labels. Do not treat old command receipts as new execution results.
