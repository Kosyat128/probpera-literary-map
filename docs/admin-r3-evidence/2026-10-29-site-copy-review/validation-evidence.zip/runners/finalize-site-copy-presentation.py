import pathlib,json,hashlib,zipfile,datetime
repo=pathlib.Path(r'C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map');work=repo.parent/'work';out=work/'site-copy-final-validation-v2'
read=lambda name:json.loads((out/name).read_text(encoding='utf-8-sig'))
write=lambda name,value:(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
sha=lambda b:hashlib.sha256(b).hexdigest()
before=read('source-before.json');after=read('source-final-after-presentation.json')
old={item['path']:item for item in before['files']};changed=[item for item in after['files'] if item!=old.get(item['path'])]
non_doc=[item for item in changed if not item['path'].startswith('docs/')];docs=[item for item in changed if item['path'].startswith('docs/')]
cjs='apps/admin/lib/fixtures/site-copy-machine-review.cjs';sql='scripts/database/fixtures/site-copy-private-translation-review.sql'
assert sorted(item['path'] for item in non_doc)==sorted([cjs,sql]);assert len(before['files'])==len(after['files'])==10639
correction=read('fixture-literal-presentation-correction.json');assert correction['allExecutableLiteralValuesEqual'] and correction['literalCount']==499
with zipfile.ZipFile(work/'m07-site-copy-review-package-final5-20261029-sol.zip') as z:
 candidates=[name for name in z.namelist() if name.endswith('/site-copy-machine-review.cjs') or name=='site-copy-machine-review.cjs']
 originals=[z.read(name) for name in candidates if sha(z.read(name))==correction['beforeSha256']];assert originals;original=originals[0]
current=(repo/cjs).read_bytes();assert sha(original)==correction['beforeSha256'];assert sha(current)==correction['afterSha256']
assert original.decode('utf-8').count('\u2014')==9;assert current==original.decode('utf-8').replace('\u2014',r'\u2014').encode('utf-8')
sql_proof=json.loads((work/'site-copy-sql-native/presentation-literal-equivalence.json').read_text(encoding='utf-8-sig'))
assert sql_proof['actualNativeRun9AndRun10FullStageArgumentsDeepEqual'] and sql_proof['actualNativeCandidateDigestEqual'];assert sha((repo/sql).read_bytes())==sql_proof['afterSha256']
runtime=read('post-presentation-runtime.raw.json');assert runtime['success'] and runtime['numTotalTests']==runtime['numPassedTests']==70 and runtime['numFailedTests']==0
scope={'status':'VERIFIED_PRESENTATION_ONLY_FIXTURE_DELTA','checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'broadV2SourceFingerprint':before['validationSourceSha256'],'finalSourceFingerprint':after['validationSourceSha256'],'fullSnapshotFiles':after['trackedFileCount'],'nonDocFiles':after['validationSourceCount'],'fullAggregateBefore':before['aggregateSha256'],'fullAggregateAfter':after['aggregateSha256'],'nonDocChangedFiles':[{'path':item['path'],'beforeSha256':old[item['path']]['sha256'],'afterSha256':item['sha256']} for item in non_doc],'allOtherNonDocFilesByteIdentical':True,'unchangedNonDocFileCount':after['validationSourceCount']-2,'appProductionSourceBytesUnchanged':True,'zeroFullNonDocDrift':False,'documentChanges':docs,'cjs':{'literalReplacements':9,'all499ExecutableLiteralTemplateValuesEqual':True,'wholeSourceDifferenceOnlyUnicodeLiteralEscapes':True,'freshRuntimeTestsPassed':70,'freshRuntimeRawSha256':sha((out/'post-presentation-runtime.raw.json').read_bytes())},'sql':sql_proof,'full6070RerunAfterPresentation':False,'classification':'The full 6070 suite is bound to the explicit V2 pre-escape source fingerprint. Final sources have two deliberate new-fixture literal representation changes only, with identical executed values and fresh 70 runtime/28 SQL/14 DTO checks. No assertion, normalizer, production application, migration or old SQL changes occurred.'}
write('source-comparison-after-presentation.json',scope)
original_gates=read('gates-summary.json');build_gates=read('gates-final-summary.json');readonly=read('gate-readonly-hyphens-after-presentation-receipt.json');assert readonly['finishedAt'] and readonly['exitCode']==1
receipts=[{'id':readonly['id'],'status':readonly['status'],'exitCode':readonly['exitCode'],'durationMs':readonly['durationMs'],'originalReceipt':'gate-readonly-hyphens-receipt.json','note':'Original43 findings retained; two new fixture literal spellings corrected without changing executed data. Post-presentation41 findings compared exactly to baseline.'} if item['id']=='gate-readonly-hyphens' else item for item in build_gates['receipts']]
gates={**build_gates,'receipts':receipts,'passed':sum(item['status']=='PASS' for item in receipts),'total':5,'fullNonDocTreeIdenticalToBroadV2':False,'appProductionSourceBytesUnchanged':True,'sourceScopeReport':'source-comparison-after-presentation.json','originalReadonlyFailure':'43 findings, including two owned new fixtures; original log/receipt retained.','postPresentationReadonlyReceipt':'gate-readonly-hyphens-after-presentation-receipt.json','full6070RerunAfterPresentation':False}
gates['v2ZeroNonDocDriftThroughBuildRetry']=build_gates['zeroValidationSourceDrift']
gates['zeroValidationSourceDrift']=False
gates['knownTwoFixturePresentationChangesVerified']=True
write('gates-effective-final-summary.json',gates)
print(json.dumps({'status':scope['status'],'finalSourceFingerprint':scope['finalSourceFingerprint'],'broadV2SourceFingerprint':scope['broadV2SourceFingerprint'],'changedNewFixturesOnly':2,'appProductionSourceBytesUnchanged':True,'gates':f"{gates['passed']}/5"}))
