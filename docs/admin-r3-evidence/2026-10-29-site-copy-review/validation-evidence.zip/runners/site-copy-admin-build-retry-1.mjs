import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, mkdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';

const work = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(work, '../probpera-literary-map');
const out = path.join(work, 'site-copy-final-validation-v2');
mkdirSync(out, {recursive:true});
const hash = data => createHash('sha256').update(data).digest('hex');
const write = (name, value) => writeFileSync(path.join(out,name), JSON.stringify(value,null,2)+'\n');
const git = (...args) => execFileSync('git', args, {cwd:root, encoding:'utf8', maxBuffer:32*1024*1024}).trimEnd();
const head = git('rev-parse','HEAD');
const envAllow = /^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i;
const childEnv = Object.fromEntries(Object.entries(process.env).filter(([key]) => envAllow.test(key)));
const taskTemp=path.join(out,'temp'); mkdirSync(taskTemp,{recursive:true}); Object.assign(childEnv, {CI:'1',NEXT_TELEMETRY_DISABLED:'1',NO_COLOR:'1',TMP:taskTemp,TEMP:taskTemp});
const selectedHistorical = readFileSync(path.join(work,'historical-test-selection.txt'),'utf8').replace(/^\uFEFF/u,'').split(/\r?\n/u).filter(Boolean);
const addedTest = 'apps/admin/lib/writer-biography-machine-review.integration.test.ts';
const newOwned = git('ls-files','--others','--exclude-standard','-z').split('\0').filter(p=>/^(apps\/admin\/|scripts\/database\/|supabase\/migrations\/)/u.test(p) && /\.(?:ts|tsx|cjs|mjs|sql)$/u.test(p));
const selected = [...selectedHistorical.filter(name=>existsSync(path.join(root,name))), addedTest, 'apps/admin/lib/site-copy-machine-review.integration.test.ts', 'apps/admin/lib/site-copy-private-recovery-page.integration.test.ts'];
const missing = selectedHistorical.filter(name=>!existsSync(path.join(root,name)));

function snapshot(name) {
  const paths = [...new Set([...git('ls-files','-z').split('\0').filter(Boolean),...newOwned])].sort();
  const files = paths.map(filename => {
    const full = path.join(root,filename);
    if(!existsSync(full)) return {path:filename,missing:true};
    return {path:filename,size:statSync(full).size,sha256:hash(readFileSync(full))};
  });
  const validationFiles = files.filter(file=>!file.path.startsWith('docs/'));
  const value = {validationSourceCount:validationFiles.length,validationSourceSha256:hash(JSON.stringify(validationFiles)),validationComparisonExclusion:'docs/ only; full files remain in snapshot and document drift is reported separately',newOwnedFiles:newOwned,schemaVersion:1,capturedAt:new Date().toISOString(),head:git('rev-parse','HEAD'),branch:git('branch','--show-current'),trackedFileCount:files.length,aggregateSha256:hash(JSON.stringify(files)),status:git('status','--porcelain=v1','--untracked-files=all'),files};
  write(name,value);
  return value;
}

async function run(id,args,cwd=root) {
  const logPath=path.join(out,`${id}.log`);
  writeFileSync(logPath,'');
  const {appendFileSync} = await import('node:fs');
  const start=new Date();
  const receipt = {schemaVersion:1,id,head,executable:process.execPath,args,cwd,startedAt:start.toISOString(),log:logPath,environmentPolicy:'Allow only OS/runtime paths; CI=1, NEXT_TELEMETRY_DISABLED=1, NO_COLOR=1. No credentials inherited.',status:'RUNNING'};
  write(`${id}-receipt.json`,receipt);
  console.log(`START ${id} ${receipt.startedAt}`);
  return await new Promise(resolve=>{
    const child=spawn(process.execPath,args,{cwd,env:childEnv,windowsHide:true,stdio:['ignore','pipe','pipe']});
    child.stdout.on('data',chunk=>appendFileSync(logPath,chunk));
    child.stderr.on('data',chunk=>appendFileSync(logPath,chunk));
    child.once('error',error=>{receipt.spawnError=String(error);});
    child.once('close',(code,signal)=>{
      Object.assign(receipt,{finishedAt:new Date().toISOString(),durationMs:Date.now()-start.valueOf(),exitCode:code,signal,status:code===0?'PASS':'FAIL',logSha256:hash(readFileSync(logPath))});
      write(`${id}-receipt.json`,receipt);
      console.log(`END ${id} ${receipt.status} exit=${code} durationMs=${receipt.durationMs}`);
      resolve(receipt);
    });
  });
}


const npmCli=path.join(path.dirname(process.execPath),'node_modules/npm/bin/npm-cli.js');
const receipt=await run('gate-admin-build-retry-1',[npmCli,'run','admin:build']);
snapshot('source-after-build-retry-1.json');
process.exitCode=receipt.exitCode===0?0:1;
