import datetime,hashlib,json,pathlib,zipfile

repo=pathlib.Path(r'C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map')
work=repo.parent/'work';out=work/'site-copy-final-validation-v2'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda name:json.loads((out/name).read_text(encoding='utf-8-sig'))
write=lambda name,data:(out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
receipt=read('selected-tests-receipt.json');assert receipt['status'] in ['PASS','FAIL'] and receipt.get('finishedAt'),'Tests not terminal'
current=read('selected-tests-summary.json');gates=read('gates-effective-final-summary.json');drift=read('source-drift-final.json');before=read('source-before.json');after=read('source-final-after-presentation.json');presentation=read('source-comparison-after-presentation.json')
preservation=read('baseline-preservation.json');supplement=read('site-copy-preservation-supplement.json')
assert preservation['pass'] and supplement['status']=='PASS'
assert drift['zeroValidationSourceDrift'],'Unexpected non-document source drift'
assert before['validationSourceSha256']==presentation['broadV2SourceFingerprint']
assert after['validationSourceSha256']==presentation['finalSourceFingerprint'] and presentation['appProductionSourceBytesUnchanged']
assert len(presentation['nonDocChangedFiles'])==2 and presentation['allOtherNonDocFilesByteIdentical']
for name in ['gate-admin-build','gate-admin-typescript','gate-cloudflare-typescript','gate-client-secrets','gate-readonly-hyphens']:
 r=read(name+'-receipt.json');assert r['status'] in ['PASS','FAIL'] and r.get('finishedAt'),name+' not terminal'
baseline_path=repo/'docs/admin-r3-evidence/2026-10-09-writer-review/validation-evidence.zip'
assert sha(baseline_path.read_bytes())=='e411af9f41c00034517d93484ccbc67050aad278ac6bdebe0029658d330433c5'
with zipfile.ZipFile(baseline_path) as z:
 baseline_summary=z.read('baseline/selected-tests-summary.json');baseline=json.loads(baseline_summary)
 baseline_hyphens=z.read('baseline/gate-readonly-hyphens.log')
def failures(summary):
 result=[]
 for item in summary.get('failedFiles',[]):
  for failure in item.get('assertionFailures',[]):
   messages=failure.get('failureMessages',[])
   result.append({'fullName':failure['fullName'],'firstErrors':[message.replace('\r\n','\n').split('\n')[0] for message in messages]})
 return sorted(result,key=lambda value:value['fullName'])
baseline_failures=failures(baseline);current_failures=failures(current)
same=current_failures==baseline_failures
comparison={'sameFailureCasesAndExactFirstErrors':same,'normalization':'None beyond CRLF/LF in splitting the first diagnostic line; JSON is read explicitly as UTF-8.','baseline':{k:baseline.get(k) for k in ['testFileCount','numTotalTests','numPassedTests','numFailedTests']},'current':{k:current.get(k) for k in ['testFileCount','numTotalTests','numPassedTests','numFailedTests']},'baselineFailures':baseline_failures,'currentFailures':current_failures,'sourceArchive':{'path':str(baseline_path),'sha256':sha(baseline_path.read_bytes()),'member':'baseline/selected-tests-summary.json'},'boundary':'Complete failed case names and first error text match exactly; raw reports retain all diagnostic details. No fixture, assertion or selection was weakened.'}
write('baseline-failure-comparison.json',comparison)
hyphens=(out/'gate-readonly-hyphens-after-presentation.log').read_bytes()
original_hyphens=(out/'gate-readonly-hyphens.log').read_bytes()
hyphen_comparison={'byteIdenticalToBaseline':hyphens==baseline_hyphens,'baselineSha256':sha(baseline_hyphens),'currentSha256':sha(hyphens),'currentFindingCount':sum(line.startswith('- ') for line in hyphens.decode('utf-8-sig').splitlines()),'sourceArchive':str(baseline_path),'member':'baseline/gate-readonly-hyphens.log','formatterOrRuleChangesMade':False,'originalPrePresentationDiagnostic':{'findings':sum(line.startswith('- ') for line in original_hyphens.decode('utf-8-sig').splitlines()),'sha256':sha(original_hyphens),'log':'gate-readonly-hyphens.log','scope':'Original43 findings retained; only new fixture source Unicode literal spellings changed, preserving executed values. Final41 are exactly the historical baseline.'}}
write('readonly-gate-baseline-comparison.json',hyphen_comparison)
new_gate_failures=[item for item in gates['receipts'] if item['status']!='PASS' and not(item['id'] in ['gate-readonly-hyphens','gate-readonly-hyphens-after-presentation'] and hyphen_comparison['byteIdenticalToBaseline'])]
summary={'schemaVersion':1,'head':before['head'],'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'conclusion':'Fresh frozen-source broad validation retains known inherited failures; this is not an all-passing suite, clean five-gate acceptance or full R3 acceptance.','tests':{'terminalExitCode':receipt['exitCode'],'files':current['testFileCount'],'total':current['numTotalTests'],'passed':current['numPassedTests'],'failed':current['numFailedTests'],'pending':current.get('numPendingTests'),'todo':current.get('numTodoTests'),'sameSixHistoricalFixtureFailures':same,'newFailuresDetected':not same},'gates':{**gates,'readonlyBaselineComparison':hyphen_comparison,'newFailuresDetected':new_gate_failures},'source':{'snapshottedFiles':after['trackedFileCount'],'validationSourceFiles':after['validationSourceCount'],'nonDocFingerprint':after['validationSourceSha256'],'fullAggregateBefore':before['aggregateSha256'],'fullAggregateAfter':after['aggregateSha256'],'zeroValidationSourceDrift':drift['zeroValidationSourceDrift'],'documentChanges':drift['documentChanges'],'exclusion':'docs/ only; new documentation/evidence is outside the selected source inventory. Tracked document drift is reported explicitly.'},'preservation':{'pass':preservation['pass'],'normalizers':len(preservation['normalizers']),'rulesAndTests':len(preservation['normalizerRulesAndTests']),'ASTImportAndCallScopes':len(preservation['normalizerImportAndCallScopes']),'oldMigrations':len(preservation['oldMigrations']),'telegramPaths':len(preservation['independentTelegram']),'telegramPatch':preservation['telegramPatch'],'packages':len(preservation['packages']),'newSiteCopyDirectCalls':supplement['siteCopyActions']['normalizerCalls'],'submittedRowsUnchanged':supplement['siteCopyActions']['submittedRows']['unchanged'],'libraryWriterBatchFunctionsUnchanged':len(supplement['libraryAndWriterBatch']['functions'])},'limitations':['Six inherited M02 cases require genuine missing .tmp/m02-operation-wiring-before source captures. No replacement baseline was created.','The unchanged readonly text gate remains failed; the formatter/rules/tests/calls were preserved.','Controlled runtime/native SQL proof is packaged separately. No managed Auth/PostgREST, authenticated browser, paid provider, production migration/deployment or public-site acceptance is claimed.','The current 199-file selection is explicitly recorded and differs from historical mixed Telegram/admin selections.']}
summary['clockControlCorrection']=read('ssr-clock-control-proof.json')
summary['retainedFailedDiagnostic']={'directory':'diagnostics/v1-new-failures','files':199,'total':6070,'passed':6058,'failed':12,'scope':'Initial final run retained unmodified. Six additional SSR failures exposed expired provider-probe mock dates; only two mock timestamp fields were corrected, with no assertion/production edit. Targeted117 and fresh V2 broad proof are separate executions.'}
summary['tests']['sourceFingerprint']=before['validationSourceSha256']
summary['tests']['fullSuiteExecutedAfterFinalFixtureEscapes']=False
summary['source']={'snapshottedFiles':after['trackedFileCount'],'validationSourceFiles':after['validationSourceCount'],'broadV2SourceFingerprint':before['validationSourceSha256'],'finalSourceFingerprint':after['validationSourceSha256'],'fullAggregateBefore':before['aggregateSha256'],'fullAggregateFinal':after['aggregateSha256'],'zeroNonDocDriftThroughV2TestsAndBuildRetry':drift['zeroValidationSourceDrift'],'zeroFullNonDocDriftAtFinal':False,'appProductionSourceBytesUnchanged':True,'deliberateNewFixturePresentationChanges':presentation['nonDocChangedFiles'],'unchangedOtherNonDocFiles':presentation['unchangedNonDocFileCount'],'documentChanges':presentation['documentChanges'],'classification':presentation['classification'],'sourceScopeReport':'source-comparison-after-presentation.json'}
summary['finalPresentationVerification']={'actualCjsLiteralTemplateValuesEqual':499,'freshControlledRuntimeTests':70,'freshNativeSQLGroups':28,'freshDTOAssertions':14,'nativeArchive':{'file':'site-copy-private-sql-presentation-final-evidence.zip','sha256':sha((work/'site-copy-private-sql-presentation-final-evidence.zip').read_bytes())},'readonlyGateBaselineCount':41}
write('validation-summary.json',summary)
assert same,'New test failure detected; do not package as known-only'
assert not new_gate_failures,'New gate failure detected; do not mask it'
readme='''# Frozen-source final validation

This archive contains raw current test JSON, terminal command receipts/logs,
the exact selection, before/after source manifests, explicit drift reports and
preservation audits. validation-summary.json is an index, not a clean acceptance.

The broad suite remains FAILED on the same six genuine missing historical M02
fixture cases. The unchanged readonly text gate also remains FAILED. The other
four required gates passed. No skip, replacement baseline, formatter write or
weakened assertion was introduced. Compare baseline-failure-comparison.json and
readonly-gate-baseline-comparison.json against the preserved baseline inputs.

The first final run is retained unmodified under diagnostics/v1-new-failures:
6058/6070 with 12 failures. Six additional SSR failures came from expired
provider-probe mock timestamps. Exactly one timestamp field in each of two test
files changed to the current time; no assertion, guard or production code changed.
The correction receipt, independent whole-source comparison and 117/117 targeted
raw test report are included. The final V2 run executes the full selection again
on its own recorded source fingerprint; V1 has not been relabelled as passing.

The first five-gate run also retains its failed build receipt/log: compilation,
TypeScript and static rendering succeeded, then Windows denied a trace-copy
mkdir in generated standalone output. One narrow same-source build retry ran
with the identical child environment policy and local command in a context
allowed to create those generated directories. Its actual terminal result is
recorded separately; the other passing gates were not repeated. Final effective
gate status and post-retry source drift are explicit, without overwriting the
original three-of-five result.

Both recorded source fingerprints exclude docs/ only. The full6070 suite belongs
to its V2 pre-escape fingerprint. The final fingerprint differs in exactly two
new fixtures: Unicode source-literal escapes preserve all499 JavaScript literal
values and the full PostgreSQL stage arguments/candidate digest. Fresh controlled
runtime70/70, nativeSQL28 groups, DTO14 and a readonly text check on final files
supplement the V2 broad result. There was no full6070 rerun after these proven
presentation-only changes. All other10410 non-document source files, including
application and migration code, remain byte-identical to V2. Raw snapshots retain
tracked documents and explicit drift. This is not full M00-M25/230 acceptance.

The preservation report covers all four normalizers, 19 related rules/tests,
16 AST import/call scopes, 64 old migrations, six independent Telegram paths,
their saved patch and three package/lock files. A separate fresh BEFORE binding
checks Site Copy's seven direct normalizer call texts, submittedRows and both
library/writer batch function texts; only CRLF/LF is normalized in comparison.

The runner strips credentials from child environments and uses a workspace-only
temporary directory. Temporary caches, dependencies, native binaries, generated
byte backups, credentials and personal sessions are excluded from this archive.
Native SQL and controlled paired runtime evidence are packaged separately.

Verify archive/member hashes before extraction into an empty scratch directory.
Runners contain historical absolute paths and expect the corresponding current
repository plus locked dependencies; adapt paths deliberately and use fresh
output labels. Do not treat old command receipts as new execution results.
'''
(out/'README.md').write_text(readme,encoding='utf-8')
entries={}
for p in out.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.txt','.md'] and p.name!='evidence-package-manifest.json':entries[p.name]=p.read_bytes()
for name in ['site-copy-final-validation-runner.mjs','site-copy-final-validation-v2-runner.mjs','site-copy-final-preservation.mjs','site-copy-preservation-supplement.mjs','site-copy-clock-control-proof.mjs','site-copy-admin-build-retry-1.mjs','site-copy-presentation-readonly.mjs','finalize-site-copy-gates.mjs','finalize-site-copy-presentation.py','package-site-copy-final-validation.py']:
 entries['runners/'+name]=(work/name).read_bytes()
entries['baseline/selected-tests-summary.json']=baseline_summary
entries['baseline/gate-readonly-hyphens.log']=baseline_hyphens
entries['baseline/fresh-before-source-manifest.json']=(work/'m07-site-copy-review-before-20261029-sol/source-manifest.json').read_bytes()
entries['baseline/fresh-before-supplement-manifest.json']=(work/'m07-site-copy-review-before-20261029-sol/supplement-manifest.json').read_bytes()
for name in ['page-tests.json','page-tests-v2.json','page-tests-v3.json']:
 entries['focused/'+name]=(work/'m07-site-copy-validation'/name).read_bytes()
for name in ['package-summary.json','current/manifest.json','recovery/runtime/manifest.json']:
 entries['runtime-provenance/'+name]=(work/'m07-site-copy-review-package-final5-20261029-sol'/name).read_bytes()
for name in ['focused-tests.raw.json','focused-tests-receipt.json','focused-tests.log','focused-runtime-provenance.json']:
 entries['focused/'+name]=(work/'site-copy-final-validation'/name).read_bytes()
for name in ['ssr-probe-clock-corrected.raw.json','ssr-probe-fixture-clock-correction.json']:
 entries['clock-correction/'+name]=(work/'site-copy-final-validation'/name).read_bytes()
for name in ['presentation-literal-equivalence.json','native-report.json','fixture-manifest.json','dto-replay-report.json','cleanup-run-10.json','security-advisors-final-summary.json']:
 entries['native-presentation/'+name]=(work/'site-copy-sql-native'/name).read_bytes()
diagnostic=work/'site-copy-final-validation-v1-new-failures'
if diagnostic.is_dir():
 for p in diagnostic.iterdir():
  if p.is_file():entries['diagnostics/v1-new-failures/'+p.name]=p.read_bytes()
manifest={'schemaVersion':1,'head':before['head'],'createdAtUtc':summary['atUtc'],'classification':'FINAL_EXECUTED_VALIDATION_WITH_KNOWN_FAILURES','validationSourceSha256':after['validationSourceSha256'],'entries':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]}
manifest_bytes=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();(out/'evidence-package-manifest.json').write_bytes(manifest_bytes);entries['evidence-package-manifest.json']=manifest_bytes
zip_path=work/'site-copy-final-validation-evidence.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(zip_path) as z:
 for item in manifest['entries']:
  data=z.read(item['path']);assert len(data)==item['bytes'] and sha(data)==item['sha256']
print(json.dumps({'archive':str(zip_path),'sha256':sha(zip_path.read_bytes()),'bytes':zip_path.stat().st_size,'members':len(entries),'manifestMembersVerified':len(manifest['entries']),'sourceFingerprint':after['validationSourceSha256'],'tests':summary['tests'],'gatesPassed':gates['passed'],'gatesTotal':gates['total']},ensure_ascii=True))
