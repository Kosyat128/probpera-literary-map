import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const repo=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map`;
const out=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-sql-native`;
const sources=[];
const hash=b=>createHash('sha256').update(b).digest('hex');
const read=file=>{const b=fs.readFileSync(path.join(repo,file));sources.push({file,sha256:hash(b)});return b.toString('utf8').replace(/\r\n?/g,'\n');};
const table=(source,name)=>{const start=source.indexOf(`create table if not exists public.${name} (`);const end=source.indexOf('\n);',start);if(start<0||end<0)throw Error(name);return source.slice(start,end+4);};
const fn=(source,name)=>{const start=source.indexOf(`create or replace function public.${name}(`);const end=source.indexOf('\n$$;',start);if(start<0||end<0)throw Error(name);return source.slice(start,end+4);};
const {adminEditorOperationsContractSql}=await import(pathToFileURL(path.join(repo,'scripts/database/admin-editor-operations-contract.mjs')));
for(const file of ['scripts/database/admin-editor-operations-contract.mjs','scripts/database/fixtures/atomic-article-bundle-contract.sql',
 'supabase/migrations/20260730_page_revision_history.sql','supabase/migrations/20260822_zz_atomic_article_bundle.sql',
 'supabase/migrations/20260902_article_working_drafts.sql','supabase/migrations/20260905_article_publication_permissions.sql'])read(file);
const foundation=adminEditorOperationsContractSql().split('create or replace function public.fixture_apply_migration()')[0];
const cms=read('supabase/migrations/20260728_cms_foundation.sql');
const guards=read('supabase/migrations/20260901_zzz_admin_mutation_guards.sql');
const homepagePolicies=cms.slice(cms.indexOf('create policy "Public read enabled homepage blocks"'),cms.indexOf('create policy "Public read active banners"'));
const saveSiteCopy=guards.slice(guards.indexOf('create or replace function public.save_site_copy_block('),guards.indexOf('create or replace function public.assert_redirect_candidate('));
const saveAcl=guards.split('\n').filter(line=>/^(grant|revoke).*function public\.save_site_copy_block\(/.test(line)).join('\n');
const homepage=[table(cms,'media_assets'),table(cms,'homepage_blocks'),
  fn(cms,'set_updated_at').replace('public.set_updated_at(','public.fixture_homepage_set_updated_at('),
  'create trigger homepage_blocks_set_updated_at before update on public.homepage_blocks for each row execute function public.fixture_homepage_set_updated_at();',
  'alter table public.homepage_blocks enable row level security;',homepagePolicies,
  'grant select on public.homepage_blocks to anon,authenticated; grant insert,update,delete on public.homepage_blocks to authenticated;',
  saveSiteCopy,saveAcl].join('\n');
const library=read('supabase/migrations/20260730_literary_archive.sql');
const books=read('supabase/migrations/20260808_book_translations_and_import_staging.sql');
const country=read('supabase/migrations/20260813_editorial_database_admin.sql');
const writer=read('supabase/migrations/20260812_writer_and_work_revisions.sql');
const pieces=[foundation,homepage,library,books,country.slice(0,country.indexOf('create table if not exists public.book_edition_revisions')),
 writer.slice(0,writer.indexOf('alter table public.literary_works')),
 read('supabase/migrations/20260823_premium_machine_translation.sql'),read('supabase/migrations/20260914_literary_translation_draft_storage.sql'),
 read('supabase/migrations/20261008160000_premium_translation_working_drafts.sql'),
 read('supabase/migrations/20261009082816_writer_biography_private_translation_review.sql'),
 read('supabase/migrations/20261029181630_site_copy_private_translation_review.sql'),
 read('scripts/database/fixtures/premium-translation-working-drafts.sql'),
 read('scripts/database/fixtures/writer-biography-private-translation-review.sql'),
 read('scripts/database/fixtures/site-copy-private-translation-review.sql')];
const sql=pieces.join('\n');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'fixture.sql'),sql);
const manifest={atUtc:new Date().toISOString(),sources,sqlSha256:hash(sql),boundaries:[
 'Actual current canonical table/save guard/new migration SQL in isolated PostgreSQL17; synthetic Auth/staff and transactional publication capture.',
 'Book/country/writer fixtures execute byte-unchanged under the new migration.',
 'Actual media_assets/homepage_blocks definitions and singleton save advisory lock are included; no managed GoTrue/PostgREST/RLS API or production contact.',
 'Selected text/hash is a trusted server/provider projection; SQL independently binds raw settings, exact CAS, key existence/order, machine ownership and explicit staff review.'
]};fs.writeFileSync(path.join(out,'fixture-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({out,sources:sources.length,sqlSha256:manifest.sqlSha256}));
