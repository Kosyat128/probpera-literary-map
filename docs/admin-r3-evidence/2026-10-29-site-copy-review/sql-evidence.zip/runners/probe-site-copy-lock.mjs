import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
const out=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-sql-native`;
const owned=JSON.parse(fs.readFileSync(path.join(out,'owned-cluster.json'),'utf8').replace(/^\uFEFF/,''));
assert.equal(owned.port,55438);assert.equal(owned.listenAddress,'127.0.0.1');
const psql=path.join(owned.pgBin,'psql.exe');
const args=['-h','127.0.0.1','-p','55438','-U','postgres','-d','site_copy_private_fixture','--no-psqlrc','--set=ON_ERROR_STOP=1','-At'];
const query=(sql)=>execFileSync(psql,[...args,'-c',sql],{encoding:'utf8',windowsHide:true}).trim();
const before=JSON.parse(query("select jsonb_build_object('draft',(select premium_translation_private.dto(c) from public.premium_translation_working_drafts c where entity_type='site_copy'),'block',(select to_jsonb(b) from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'audit',(select count(*) from public.admin_audit_log),'outbox',(select count(*) from public.premium_fixture_outbox));"));
let holder;let holderOutput='';let holderErrors='';
try{
 holder=spawn(psql,[...args,'-c','begin;','-c','select pg_advisory_xact_lock(188654771, 2);','-c',"select 'LOCK_HELD';",'-c','select pg_sleep(2);','-c','rollback;'],{windowsHide:true});
 const held=new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>reject(Error('Owned singleton lock was not observed')),5000);
  holder.stdout.on('data',b=>{holderOutput+=b; if(holderOutput.includes('LOCK_HELD')){clearTimeout(timer);resolve();}});
  holder.stderr.on('data',b=>{holderErrors+=b;});
  holder.once('error',reject);holder.once('exit',code=>{if(code!==0){clearTimeout(timer);reject(Error('Owned lock holder failed '+code));}});
 });
 const holderCompleted=new Promise((resolve,reject)=>holder.once('exit',code=>code===0?resolve():reject(Error('Lock holder failed '+code))));
 await held;
 const start=performance.now();
 const contender=spawn(psql,[...args,'-c','set role authenticated;','-c',"select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);",'-c',"set statement_timeout='500ms';",'-c',"select public.site_copy_fixture_promote((select value from public.premium_fixture_saved where name='site-copy-lock-candidate'));"],{windowsHide:true});
 let contenderOutput='';let contenderErrors='';contender.stdout.on('data',b=>{contenderOutput+=b;});contender.stderr.on('data',b=>{contenderErrors+=b;});
 const exitCode=await new Promise((resolve,reject)=>{contender.once('error',reject);contender.once('exit',resolve);});
 const durationMs=performance.now()-start;
 assert.notEqual(exitCode,0);assert.match(contenderErrors,/statement timeout/i);assert.match(contenderErrors,/pg_advisory_xact_lock\(188654771, 2\)/);
 assert.ok(durationMs>=400&&durationMs<1900);
 await holderCompleted;
 const after=JSON.parse(query("select jsonb_build_object('draft',(select premium_translation_private.dto(c) from public.premium_translation_working_drafts c where entity_type='site_copy'),'block',(select to_jsonb(b) from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'audit',(select count(*) from public.admin_audit_log),'outbox',(select count(*) from public.premium_fixture_outbox));"));
 assert.deepEqual(after,before);
 const discarded=JSON.parse(query("set role authenticated; select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false); select public.premium_fixture_discard((select value from public.premium_fixture_saved where name='site-copy-lock-candidate'));" ).split('\n').at(-1));
 query(`insert into public.premium_fixture_saved values('site-copy-discarded',${"'"+JSON.stringify(discarded).replaceAll("'","''")+"'"}::jsonb);`);
 const report={status:'PASS',port:55438,contenderExitCode:exitCode,durationMs,boundary:'Actual candidate promotion blocks on the exact save_site_copy_block singleton advisory lock; timeout rolls back draft/canonical/audit/outbox.',singletonLock:[188654771,2],canonicalAndPrivateUnchanged:true,holderOutput,holderErrors,contenderOutput,contenderErrors};
 fs.writeFileSync(path.join(out,'singleton-lock-report.json'),JSON.stringify(report,null,2)+'\n');
 console.log('SITE_COPY_SHARED_SINGLETON_LOCK_PASS');
}finally{if(holder&&holder.exitCode===null)holder.kill();}
