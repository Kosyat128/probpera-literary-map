import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const repo=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map`;
const out=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-sql-native`;
const run=process.argv.find(a=>a.startsWith('--run='))?.split('=')[1]??'5';
const sourceFile='apps/admin/lib/premium-translation-working-draft.ts';
const bytes=fs.readFileSync(path.join(repo,sourceFile));const sha=b=>createHash('sha256').update(b).digest('hex');
const require=createRequire(pathToFileURL(path.join(repo,'apps/admin/package.json')));const ts=require('typescript');
const compiled=ts.transpileModule(bytes.toString('utf8'),{fileName:sourceFile,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}});
const module={exports:{}};new Function('require','module','exports',compiled.outputText)(require,module,module.exports);const api=module.exports;
const envelopeFile=`native-envelopes-run-${run}.json`;const envelopeBytes=fs.readFileSync(path.join(out,envelopeFile));
const envelopes=JSON.parse(envelopeBytes);const a=envelopes['site-copy-args'];const d=envelopes['site-copy-stage'].draft;
const identity={entityType:d.entityType,entityId:d.entityId};
const input={...identity,sourceHash:a.sourceHash,sourceSnapshot:a.source,sourceRevision:a.sourceRevision,targetRevision:a.targetRevision,payload:a.payload,provenance:a.provenance};
const consumed={...identity,draftId:d.id,version:d.version,candidateHash:d.candidateHash};
const promotion={...consumed,sourceHash:d.sourceHash,catalogSourceHash:null,catalogSourceFields:null,actorId:envelopes['site-copy-promoted'].reviewedBy};
const checks=[];const check=async(name,fn)=>{await fn();checks.push({name,status:'PASS'});console.log('PASS '+name);};
const rpc=(data,name,inspect=()=>{})=>({rpc:async(actual,args)=>{assert.equal(actual,name);inspect(args);return {data:structuredClone(data),error:null};}});
const unconfirmed=fn=>assert.rejects(fn,e=>e instanceof api.PremiumTranslationDraftError&&e.code==='unconfirmed');
await check('current actual schema accepts SQL UUIDs microseconds and configured nullable model reviewer',()=>{
 assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(d).success,true);assert.equal(d.provenance.reviewerModel,null);
 assert.match(d.createdAt,/\.\d{4,6}[+-]\d\d:\d\d$/);
 assert.equal(d.sourceSnapshot.settings.siteCopy.ru.intro,'  Исходный — текст\r\nс новой строкой  ');
});
await check('current actual read parser confirms native private envelope',async()=>{
 assert.deepEqual(await api.readPremiumTranslationWorkingDraft(rpc(envelopes['site-copy-read'],'get_premium_translation_working_draft'),identity),d);
});
await check('current actual stage parser confirms full raw settings source and exact transport arguments',async()=>{
 assert.deepEqual(await api.stagePremiumTranslationWorkingDraft(rpc(envelopes['site-copy-stage'],'stage_premium_translation_working_draft',args=>{
  assert.equal(args.p_expected_draft_id,null);assert.equal(args.p_expected_draft_version,0);assert.deepEqual(args.p_source_snapshot,a.source);
 }),input),d);
});
await check('current actual stage parser accepts reordered JSONB object fields without changing arrays',async()=>{
 const reordered=structuredClone(input);reordered.sourceSnapshot=Object.fromEntries(Object.entries(reordered.sourceSnapshot).reverse());
 assert.deepEqual(await api.stagePremiumTranslationWorkingDraft(rpc(envelopes['site-copy-stage'],'stage_premium_translation_working_draft'),reordered),d);
});
await check('current actual promotion parser accepts native current reviewer and exact timestamptz receipt',async()=>{
 const receipt=envelopes['site-copy-promoted'];
 assert.deepEqual(await api.promotePremiumTranslationWorkingDraft(rpc(receipt,'promote_premium_translation_working_draft',args=>{
  assert.equal(args.p_catalog_source_fields,null);assert.equal(args.p_catalog_source_hash,null);assert.equal(args.p_confirm_human_review,true);
 }),promotion),receipt);
 assert.equal(receipt.canonicalId,identity.entityId);assert.equal(receipt.reviewedBy,'22222222-2222-4222-8222-222222222222');
});
await check('current actual discard parser confirms native shared-lock candidate receipt',async()=>{
 const lock=envelopes['site-copy-lock-candidate'];const expected={entityType:lock.entityType,entityId:lock.entityId,draftId:lock.id,version:lock.version,candidateHash:lock.candidateHash};
 assert.deepEqual(await api.discardPremiumTranslationWorkingDraft(rpc(envelopes['site-copy-discarded'],'discard_premium_translation_working_draft'),expected),envelopes['site-copy-discarded']);
});
await check('current actual list adapter parses native deleted-source empty and exact stored uppercase identities',async()=>{
 for(const name of ['site-copy-list-deleted-master','site-copy-list-empty','site-copy-list-uppercase']){
  const page=envelopes[name];
  assert.deepEqual(await api.listSiteCopyPremiumTranslationWorkingDrafts(rpc(page,'list_site_copy_premium_translation_working_drafts',args=>{
   assert.deepEqual(args,{p_after_id:null,p_limit:10});
  })),page);
 }
});
await check('current actual list adapter follows native ten plus one keyset pages and forwards exact cursor',async()=>{
 const first=envelopes['site-copy-list-max-page'];const last=envelopes['site-copy-list-max-last-page'];
 assert.deepEqual(await api.listSiteCopyPremiumTranslationWorkingDrafts(rpc(first,'list_site_copy_premium_translation_working_drafts')),first);
 assert.deepEqual(await api.listSiteCopyPremiumTranslationWorkingDrafts(rpc(last,'list_site_copy_premium_translation_working_drafts',args=>{
  assert.deepEqual(args,{p_after_id:first.nextCursor,p_limit:10});
 }),first.nextCursor),last);
 assert.equal(new Set([...first.entityIds,...last.entityIds]).size,11);
});
await check('current actual list adapter rejects forged extra raw source fields and nonadvancing cursors',async()=>{
 const first=envelopes['site-copy-list-max-page'];
 for(const bad of [{...first,sourceSnapshot:{raw:'must never leak'}},{...first,entityIds:[...first.entityIds,first.entityIds[0]]}]){
  await unconfirmed(()=>api.listSiteCopyPremiumTranslationWorkingDrafts(rpc(bad,'list_site_copy_premium_translation_working_drafts')));
 }
 await unconfirmed(()=>api.listSiteCopyPremiumTranslationWorkingDrafts(rpc(first,'list_site_copy_premium_translation_working_drafts'),first.nextCursor));
});
await check('schema rejects SQL wire identity source target substitution duplicate/order changes',()=>{
 for(const modify of [x=>x.entityId='eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee',x=>x.targetRevision.updatedAt='2026-10-01T00:00:00Z',x=>x.payload.items.reverse(),x=>x.sourceSnapshot.items[1].key=x.sourceSnapshot.items[0].key]){
  const bad=structuredClone(d);modify(bad);assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(bad).success,false);
 }
});
await check('stage acknowledgement rejects dropped French rights raw settings or translated payload',async()=>{
 for(const modify of [x=>delete x.draft.sourceSnapshot.settings.siteCopy.fr.rights,x=>x.draft.sourceSnapshot.settings.siteCopy.ru.intro='normalized',x=>x.draft.payload.items[0].text='changed']){
  const bad=structuredClone(envelopes['site-copy-stage']);modify(bad);
  await unconfirmed(()=>api.stagePremiumTranslationWorkingDraft(rpc(bad,'stage_premium_translation_working_draft'),input));
 }
});
await check('promotion acknowledgement rejects different actor candidate version or selected entity',async()=>{
 for(const [key,value] of [['reviewedBy',d.createdBy],['version',2],['candidateHash','f'.repeat(64)],['entityId','eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee']]){
  const bad={...envelopes['site-copy-promoted'],[key]:value};await unconfirmed(()=>api.promotePremiumTranslationWorkingDraft(rpc(bad,'promote_premium_translation_working_draft'),promotion));
 }
});
await check('native and DTO agree at UTF16 key1200 text4000 limits and reject one more unit',()=>{
 for(const part of ['key','source','payload']){
  const draft=envelopes['site-copy-boundary-'+part];assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(draft).success,true);
  const invalid=structuredClone(draft);
  if(part==='key'){
   assert.equal(draft.sourceSnapshot.items[0].key.length,1200);invalid.sourceSnapshot.items[0].key+='a';invalid.payload.items[0].key+='a';
  } else if(part==='source'){
   assert.equal(draft.sourceSnapshot.items[0].text.length,4000);invalid.sourceSnapshot.items[0].text+='a';
  } else {
   assert.equal(draft.payload.items[0].text.length,4000);invalid.payload.items[0].text+='a';
  }
  assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(invalid).success,false);
 }
});
await check('current actual schema accepts freshly executed unchanged book country writer native compatibility',()=>{
 for(const name of ['writer-pending','book-pending','country-pending'])assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(envelopes[name]).success,true);
});
assert.equal(sha(fs.readFileSync(path.join(repo,sourceFile))),sha(bytes),'DTO source changed during replay');
const report={status:'PASS',exitCode:0,atUtc:new Date().toISOString(),source:{file:sourceFile,sha256:sha(bytes)},receipts:{file:envelopeFile,sha256:sha(envelopeBytes)},typescript:ts.version,assertions:checks,boundaries:['Actual current module transpiled unchanged; installed real Zod and Next navigation loaded.','Transport only replays actual local native PostgreSQL envelopes. No managed Auth/PostgREST/provider/browser/public deployment acceptance.','Book/country/writer envelopes come from the same fresh native run containing all unchanged 17 compatibility SQL groups.']};
fs.writeFileSync(path.join(out,'dto-replay-report.json'),JSON.stringify(report,null,2)+'\n');console.log('SITE_COPY_NATIVE_DTO_REPLAY_PASS='+checks.length);
