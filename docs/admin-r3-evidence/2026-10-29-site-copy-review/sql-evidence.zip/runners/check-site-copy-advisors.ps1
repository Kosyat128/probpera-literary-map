param([string]$Label='final')
$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$ownedPath=Join-Path $nativeRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
$expectedData=Join-Path $nativeRoot 'data'
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $expectedData){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Earlier PID still exists'}
$started=$false
try {
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $expectedData -l (Join-Path $nativeRoot 'postgres.log') -o '-h 127.0.0.1 -p 55438' start
 if($LASTEXITCODE -ne 0){throw 'Owned start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath (Join-Path $expectedData 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding UTF8
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1'
 $env:SUPABASE_HOME='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-cli-home'
 $cli='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\portable-db-tools\supabase-2.120.0\supabase.exe'
 $logName='security-advisors-'+$Label+'.log'
 & $cli db advisors --db-url 'postgresql://postgres@127.0.0.1:55438/site_copy_private_fixture?sslmode=disable' --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot $logName)
 $advisorsExit=$LASTEXITCODE
 [PSCustomObject]@{atUtc=[DateTime]::UtcNow.ToString('o');exitCode=$advisorsExit;target='owned isolated 127.0.0.1:55438/site_copy_private_fixture';type='security';log=$logName}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $nativeRoot ('security-advisors-'+$Label+'-receipt.json')) -Encoding UTF8
 $advisorLines=Get-Content -LiteralPath (Join-Path $nativeRoot $logName)
 $advisorJson=$advisorLines|Where-Object{$_ -match '^\{"results"'}|ConvertFrom-Json
 [PSCustomObject]@{exitCode=$advisorsExit;findings=@($advisorJson.results).Count;log=$logName}|ConvertTo-Json -Compress
 Write-Output ('ADVISORS_EXIT='+$advisorsExit)
} finally {
 if($started){
  if([int](Get-Content -LiteralPath (Join-Path $expectedData 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $expectedData -m fast stop *> (Join-Path $nativeRoot ('cleanup-advisors-'+$Label+'.log'))
  $stopExit=$LASTEXITCODE
  [PSCustomObject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPostmasterPid=$ownedPid;pgCtlExitCode=$stopExit;postmasterProcessRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath (Join-Path $expectedData 'postmaster.pid'));port=55438;windowsServiceCreated=$false;dataDirectory=$expectedData}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $nativeRoot ('cleanup-advisors-'+$Label+'.json')) -Encoding UTF8
  if($stopExit -ne 0){throw 'Owned cleanup failed'}
 }
}
