import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const repo=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map`;
const before=fs.readFileSync(path.join(repo,'supabase/migrations/20261009082816_writer_biography_private_translation_review.sql'),'utf8').replace(/\r\n?/g,'\n');
const target=path.join(repo,'supabase/migrations/20261029181630_site_copy_private_translation_review.sql');
const definition=name=>{const start=before.indexOf(`create or replace function ${name}(`);const end=before.indexOf('\n$$;',start);if(start<0||end<0)throw Error(name);return before.slice(start,end+4);};
const replaceOnce=(text,old,next)=>{if(text.split(old).length!==2)throw Error('Expected exactly one boundary: '+old);return text.replace(old,()=>next);};
const helpers=String.raw`
-- Match JavaScript/Zod maxima without altering source text: astral Unicode
-- characters occupy two UTF-16 code units, all other characters occupy one.
create function premium_translation_private.site_copy_utf16_length(value text)
returns integer language sql immutable strict set search_path='' as $$
  select char_length(value)+(select count(*)::integer
    from unnest(string_to_array(value,null::text)) glyph where ascii(glyph)>65535);
$$;

-- Full raw settings are the canonical binding. Selected item text/hash is the
-- trusted server/provider projection, not a claim that SQL reads the UI catalog.
create function premium_translation_private.assert_site_copy_shape(snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql immutable set search_path='' as $$
declare item jsonb; source_item jsonb; idx integer; keys text[] := array[]::text[]; item_key text;
begin
  if not premium_translation_private.exact_object(source_revision,array['blockId','blockUpdatedAt'])
    or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'blockId','updatedAt',source_revision->'blockUpdatedAt'))
    or source_revision->>'blockId' is null
    or jsonb_build_object('id',source_revision->'blockId','updatedAt',source_revision->'blockUpdatedAt') is distinct from target_revision
    or not premium_translation_private.exact_object(snapshot,array['settings','items'])
    or jsonb_typeof(snapshot->'settings') is distinct from 'object'
    or snapshot#>>'{settings,systemKey}' is distinct from 'site-copy-overrides'
    or jsonb_typeof(snapshot->'items') is distinct from 'array'
    or not premium_translation_private.exact_object(payload,array['items'])
    or jsonb_typeof(payload->'items') is distinct from 'array' then
    raise exception using errcode='22023',message='Invalid Site Copy candidate shape';
  end if;
  if jsonb_array_length(snapshot->'items') not between 1 and 50
    or jsonb_array_length(payload->'items') is distinct from jsonb_array_length(snapshot->'items') then
    raise exception using errcode='22023',message='Invalid Site Copy item count';
  end if;
  for idx in 0..jsonb_array_length(snapshot->'items')-1 loop
    source_item := snapshot->'items'->idx; item := payload->'items'->idx;
    if not premium_translation_private.exact_object(source_item,array['key','text','sourceHash'])
      or not premium_translation_private.exact_object(item,array['key','text'])
      or jsonb_typeof(source_item->'key') is distinct from 'string'
      or jsonb_typeof(source_item->'text') is distinct from 'string'
      or jsonb_typeof(source_item->'sourceHash') is distinct from 'string'
      or source_item->>'sourceHash' !~ '^[a-f0-9]{64}$'
      or jsonb_typeof(item->'key') is distinct from 'string'
      or jsonb_typeof(item->'text') is distinct from 'string'
      or item->'key' is distinct from source_item->'key'
      or premium_translation_private.site_copy_utf16_length(source_item->>'text') not between 1 and 4000
      or char_length(premium_translation_private.trim_text(source_item->>'text'))=0
      or premium_translation_private.site_copy_utf16_length(item->>'text') not between 1 and 4000
      or char_length(premium_translation_private.trim_text(item->>'text'))=0 then
      raise exception using errcode='22023',message='Invalid Site Copy item shape';
    end if;
    item_key := source_item->>'key';
    if premium_translation_private.site_copy_utf16_length(item_key) not between 1 and 1200
      or item_key is distinct from premium_translation_private.trim_text(item_key)
      or item_key ~ '[[:cntrl:]]'
      or item_key ~* '(^|\.)(__proto__|prototype|constructor)(\.|$)'
      or item_key=any(keys)
      or exists(select 1 from unnest(string_to_array(item->>'text',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023) then
      raise exception using errcode='22023',message='Invalid Site Copy key or English text';
    end if;
    keys := array_append(keys,item_key);
  end loop;
end;
$$;

create function premium_translation_private.assert_site_copy_current(identity text,
  snapshot jsonb, source_revision jsonb, target_revision jsonb)
returns void language plpgsql security invoker set search_path='' as $$
declare block public.homepage_blocks%rowtype; singleton_count bigint; copy jsonb;
  premium jsonb; machine jsonb; source_item jsonb; item_key text; marker jsonb;
begin
  if (source_revision->>'blockId')::uuid is distinct from identity::uuid
    or jsonb_build_object('id',source_revision->'blockId','updatedAt',source_revision->'blockUpdatedAt') is distinct from target_revision then
    raise exception using errcode='40001',message='Site Copy source and target identities differ';
  end if;
  -- Same singleton boundary as save_site_copy_block. All candidate writers take
  -- their per-entity lock before this singleton lock and then the canonical row.
  perform pg_advisory_xact_lock(188654771, 2);
  select count(*) into singleton_count from public.homepage_blocks
    where settings @> '{"systemKey":"site-copy-overrides"}'::jsonb;
  if singleton_count<>1 then
    raise exception using errcode='40001',message='Site Copy master is missing or ambiguous';
  end if;
  select * into block from public.homepage_blocks where id=identity::uuid for update;
  if not found or block.settings#>>'{systemKey}' is distinct from 'site-copy-overrides'
    or block.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
    or block.settings is distinct from snapshot->'settings' then
    raise exception using errcode='40001',message='Site Copy settings or revision changed';
  end if;
  copy := block.settings->'siteCopy'; premium := block.settings->'premiumTranslation';
  if jsonb_typeof(copy) is distinct from 'object'
    or jsonb_typeof(copy->'ru') is distinct from 'object'
    or (copy ? 'en' and copy->'en'<>'null'::jsonb and jsonb_typeof(copy->'en') is distinct from 'object')
    or (premium is not null and premium<>'null'::jsonb and jsonb_typeof(premium) is distinct from 'object') then
    raise exception using errcode='40001',message='Site Copy locale or metadata ownership is ambiguous';
  end if;
  machine := premium->'siteCopyEn';
  if machine is not null and machine<>'null'::jsonb and jsonb_typeof(machine) is distinct from 'object' then
    raise exception using errcode='40001',message='Site Copy machine metadata is malformed';
  end if;
  for source_item in select jsonb_array_elements(snapshot->'items') loop
    item_key := source_item->>'key'; marker := machine->item_key;
    if not (copy->'ru' ? item_key) or jsonb_typeof(copy->'ru'->item_key) is distinct from 'string'
      or char_length(premium_translation_private.trim_text(copy->'ru'->>item_key))=0 then
      raise exception using errcode='40001',message='Site Copy Russian key changed';
    end if;
    if (machine ? item_key) and jsonb_typeof(marker) is distinct from 'object' then
      raise exception using errcode='40001',message='Site Copy selected machine metadata is malformed';
    end if;
    if copy->'en' ? item_key and (jsonb_typeof(copy->'en'->item_key) is distinct from 'string'
      or jsonb_typeof(marker) is distinct from 'object'
      or jsonb_typeof(marker->'sourceHash') is distinct from 'string'
      or marker->>'sourceHash' !~ '^[a-f0-9]{64}$') then
      raise exception using errcode='40001',message='Manual or ambiguous Site Copy English is protected';
    end if;
  end loop;
end;
$$;
`;
const currentStart=helpers.indexOf('create function premium_translation_private.assert_site_copy_current');
const ownershipStart=helpers.indexOf("  copy := block.settings->'siteCopy'",currentStart);
const ownershipEnd=helpers.indexOf('\nend;\n$$;',ownershipStart);
if(currentStart<0||ownershipStart<0||ownershipEnd<0)throw Error('Missing Site Copy recorded ownership boundary');
const ownershipBody=helpers.slice(ownershipStart,ownershipEnd).replaceAll('block.settings',"snapshot->'settings'");
const recorded=`-- Durable private provider output survives a concurrent canonical edit or\n-- deletion. Validate the recorded source/ownership here; only promotion reloads\n-- and locks the current singleton and enforces its full settings/CAS binding.\ncreate function premium_translation_private.assert_site_copy_recorded(snapshot jsonb)\nreturns void language plpgsql immutable set search_path='' as $$\ndeclare copy jsonb; premium jsonb; machine jsonb; source_item jsonb; item_key text; marker jsonb;\nbegin\n${ownershipBody}\nend;\n$$;\n\n`;
const integratedHelpers=helpers.slice(0,currentStart)+recorded+helpers.slice(currentStart,ownershipStart)
  +'  perform premium_translation_private.assert_site_copy_recorded(snapshot);'+helpers.slice(ownershipEnd);
let identity=definition('premium_translation_private.assert_identity');
identity=replaceOnce(identity,"begin\n  if kind='writer_biography' then",String.raw`begin
  if kind='site_copy' then
    if identity is null or identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' then
      raise exception using errcode='22023',message='Invalid candidate identity';
    end if;
    return;
  end if;
  if kind='writer_biography' then`);
let shape=definition('premium_translation_private.assert_shape');
shape=replaceOnce(shape,"  if kind='writer_biography' then",String.raw`  if kind='site_copy' then
    perform premium_translation_private.assert_site_copy_shape(snapshot,source_revision,target_revision,payload);
    return;
  end if;
  if kind='writer_biography' then`);
let current=definition('premium_translation_private.assert_current');
current=replaceOnce(current,"  if kind='writer_biography' then",String.raw`  if kind='site_copy' then
    perform premium_translation_private.assert_site_copy_current(identity,snapshot,source_revision,target_revision);
    return;
  end if;
  if kind='writer_biography' then`);
let promote=definition('public.promote_premium_translation_working_draft');
promote=replaceOnce(promote,'protected_english jsonb; writer public.writer_profile_overrides%rowtype;',
  'protected_english jsonb; writer public.writer_profile_overrides%rowtype;\n  block public.homepage_blocks%rowtype; item jsonb; source_item jsonb; item_key text; machine jsonb; item_meta jsonb; idx integer;');
promote=replaceOnce(promote,"or (p_entity_type='literary_work' and p_catalog_source_fields is not null)","or (p_entity_type in ('literary_work','site_copy') and p_catalog_source_fields is not null)");
promote=replaceOnce(promote,"or (p_entity_type='literary_work' and p_catalog_source_hash is not null)","or (p_entity_type in ('literary_work','site_copy') and p_catalog_source_hash is not null)");
promote=replaceOnce(promote,"  if p_entity_type='writer_biography' then",String.raw`  if p_entity_type='site_copy' then
    select * into block from public.homepage_blocks where id=p_entity_id::uuid;
    translations := block.settings->'siteCopy';
    english := case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
    meta := case when jsonb_typeof(block.settings->'premiumTranslation')='object' then block.settings->'premiumTranslation' else '{}'::jsonb end;
    machine := case when jsonb_typeof(meta->'siteCopyEn')='object' then meta->'siteCopyEn' else '{}'::jsonb end;
    for idx in 0..jsonb_array_length(candidate.payload->'items')-1 loop
      item := candidate.payload->'items'->idx; source_item := candidate.source_snapshot->'items'->idx; item_key := item->>'key';
      item_meta := coalesce(machine->item_key,'{}'::jsonb)||jsonb_build_object('sourceHash',source_item->'sourceHash',
        'provider',candidate.provenance->'provider','model',candidate.provenance->'translatorModel',
        'reviewerModel',candidate.provenance->'reviewerModel','generatedAt',candidate.provenance->'generatedAt',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
      machine := machine||jsonb_build_object(item_key,item_meta);
      english := english||jsonb_build_object(item_key,item->'text');
    end loop;
    next_fields := block.settings||jsonb_build_object('siteCopy',translations||jsonb_build_object('en',english),
      'premiumTranslation',meta||jsonb_build_object('siteCopyEn',machine));
    update public.homepage_blocks set settings=next_fields,updated_by=actor where id=block.id
      returning id,updated_at into canonical_id,canonical_updated_at;
  elsif p_entity_type='writer_biography' then`);
const privateBase=fs.readFileSync(path.join(repo,'supabase/migrations/20261008160000_premium_translation_working_drafts.sql'),'utf8').replace(/\r\n?/g,'\n');
const stageStart=privateBase.indexOf('create function public.stage_premium_translation_working_draft(');
const stageEnd=privateBase.indexOf('\n$$;',stageStart);
if(stageStart<0||stageEnd<0)throw Error('Missing original stage RPC');
let stage=privateBase.slice(stageStart,stageEnd+4).replace('create function public.stage_','create or replace function public.stage_');
stage=replaceOnce(stage,'  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,p_source_snapshot,p_source_revision,p_target_revision,p_payload);',
`  if p_entity_type='site_copy' then\n    if p_source_revision->>'blockId' is distinct from p_entity_id or p_target_revision->>'id' is distinct from p_entity_id then\n      raise exception using errcode='22023',message='Site Copy recorded identity differs';\n    end if;\n    perform premium_translation_private.assert_site_copy_recorded(p_source_snapshot);\n  else\n    perform premium_translation_private.assert_current(p_entity_type,p_entity_id,p_source_snapshot,p_source_revision,p_target_revision,p_payload);\n  end if;`);
const list=String.raw`-- Read-only recovery discovery includes candidates whose canonical master was
-- deleted. Keyset paging exposes only identities, never private source/payload.
create function public.list_site_copy_premium_translation_working_drafts(
  p_after_id uuid default null, p_limit integer default 10)
returns jsonb language plpgsql security definer set search_path='' as $$
declare identities jsonb; last_id uuid; has_more boolean;
begin
  perform premium_translation_private.assert_actor();
  if p_limit is null or p_limit not between 1 and 10 then
    raise exception using errcode='22023',message='Invalid Site Copy candidate page size';
  end if;
  with requested as (
    select id,entity_id from public.premium_translation_working_drafts
    where entity_type='site_copy' and (p_after_id is null or id>p_after_id)
    order by id limit p_limit+1
  ), visible as (
    select id,entity_id from requested order by id limit p_limit
  )
  select coalesce(jsonb_agg(entity_id order by id),'[]'::jsonb),
    (select id from visible order by id desc limit 1),
    (select count(*)>p_limit from requested)
    into identities,last_id,has_more from visible;
  return jsonb_build_object('schemaVersion',1,'entityIds',identities,
    'nextCursor',case when has_more then last_id else null end);
end;
$$;
revoke all on function public.list_site_copy_premium_translation_working_drafts(uuid,integer) from public,anon,authenticated;
grant execute on function public.list_site_copy_premium_translation_working_drafts(uuid,integer) to authenticated;
`;
const sql=`-- Extend the existing private review protocol to Site Copy. Staging does not\n-- write canonical settings or request publication. Existing book/country/writer\n-- branches, RPC signatures, table/RPC grants and RLS remain unchanged.\nalter table public.premium_translation_working_drafts\n  drop constraint premium_translation_working_drafts_entity_type_check,\n  add constraint premium_translation_working_drafts_entity_type_check\n    check (entity_type in ('literary_work','country','writer_biography','site_copy'));\n\n${identity}\n${integratedHelpers}\n${shape}\n\n${current}\n\n${stage}\n\n${promote}\n\n${list}\n\nrevoke all on function premium_translation_private.site_copy_utf16_length(text) from public,anon,authenticated;\nrevoke all on function premium_translation_private.assert_site_copy_shape(jsonb,jsonb,jsonb,jsonb) from public,anon,authenticated;\nrevoke all on function premium_translation_private.assert_site_copy_recorded(jsonb) from public,anon,authenticated;\nrevoke all on function premium_translation_private.assert_site_copy_current(text,jsonb,jsonb,jsonb) from public,anon,authenticated;\n`;
fs.writeFileSync(target,sql);
console.log(JSON.stringify({target,bytes:Buffer.byteLength(sql),sha256:createHash('sha256').update(sql).digest('hex')}));
