param([Parameter(Mandatory=$true)][int]$Run)
$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$expectedData=Join-Path $nativeRoot 'data'
$pgBin='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\PORTAB~1\POSTGR~1.11-\pgsql\bin'
$psql=Join-Path $pgBin 'psql.exe'
$ownedPath=Join-Path $nativeRoot 'owned-cluster.json'
$oldOwned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($oldOwned.port -ne 55438 -or $oldOwned.dataDirectory -ne $expectedData){throw 'Unexpected owned cluster target'}
if(Get-Process -Id $oldOwned.pid -ErrorAction SilentlyContinue){throw 'Earlier owned PID still exists; do not start another postmaster'}
$exitCode=1
$started=$false
try {
 & (Join-Path $pgBin 'pg_ctl.exe') -D $expectedData -l (Join-Path $nativeRoot 'postgres.log') -o '-h 127.0.0.1 -p 55438' start
 if($LASTEXITCODE -ne 0){throw 'Cannot start owned cluster'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath (Join-Path $expectedData 'postmaster.pid') -TotalCount 1)
 $owned=[PSCustomObject]@{port=55438;listenAddress='127.0.0.1';dataDirectory=$expectedData;pgBin=$pgBin;pid=$ownedPid;service=$false}
 $owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding UTF8
 $env:PGCLIENTENCODING='UTF8'
 $probe=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $probe.Replace('/','\').ToLowerInvariant() -ne $expectedData.ToLowerInvariant()){throw 'Connection not to owned disposable cluster'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc --set=ON_ERROR_STOP=1 -c 'drop database if exists site_copy_private_fixture with (force);' -c 'drop role if exists anon,authenticated,service_role;' -c 'create database site_copy_private_fixture;'
 if($LASTEXITCODE -ne 0){throw 'Synthetic database reset failed'}
 $log=Join-Path $nativeRoot ('run-'+$Run+'.log')
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d site_copy_private_fixture --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'fixture.sql') *> $log
 $exitCode=$LASTEXITCODE
 Get-Content -LiteralPath $log|Where-Object{$_ -match '^M07_.*PASS|^M07_.*SUMMARY|ERROR:|CONTEXT:|LINE [0-9]+:'}
 Write-Output ('PSQL_EXIT='+$exitCode)
 if($exitCode -eq 0){
  & 'C:\Users\Костя\Documents\Codex\tools\node-v24.18.1\node.exe' 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\probe-site-copy-lock.mjs'
  if($LASTEXITCODE -ne 0){throw 'Actual singleton lock probe failed'}
  & $psql -h 127.0.0.1 -p 55438 -U postgres -d site_copy_private_fixture --no-psqlrc --set=ON_ERROR_STOP=1 -Atc "select jsonb_object_agg(name,value) from public.premium_fixture_saved where name like 'site-copy-%' or name in ('book-pending','country-pending','writer-pending');" > (Join-Path $nativeRoot ('native-envelopes-run-'+$Run+'.json'))
  if($LASTEXITCODE -ne 0){throw 'Native envelope export failed'}
 }
} finally {
 if($started){
  $actualPid=[int](Get-Content -LiteralPath (Join-Path $expectedData 'postmaster.pid') -TotalCount 1)
  if($actualPid -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $pgBin 'pg_ctl.exe') -D $expectedData -m fast stop *> (Join-Path $nativeRoot ('cleanup-run-'+$Run+'.log'))
  $stopExit=$LASTEXITCODE
  [PSCustomObject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPostmasterPid=$ownedPid;pgCtlExitCode=$stopExit;
   postmasterProcessRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);
   pidFileRemains=(Test-Path -LiteralPath (Join-Path $expectedData 'postmaster.pid'));port=55438;windowsServiceCreated=$false;dataDirectory=$expectedData
  }|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $nativeRoot ('cleanup-run-'+$Run+'.json')) -Encoding UTF8
  if($stopExit -ne 0){throw 'Owned cleanup failed'}
 }
}
exit $exitCode
