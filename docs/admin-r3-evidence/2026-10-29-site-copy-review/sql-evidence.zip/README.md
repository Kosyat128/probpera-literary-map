# Site Copy private review: isolated native SQL evidence

Final source-bound proof is Run 9: 28 actual SQL groups (10 book/country, 7 writer,
11 Site Copy), the real two-session singleton-lock probe, and 14 actual current
TypeScript DTO/transport parser checks over the native envelopes. Consult
native-report.json, fixture-manifest.json and sql-preservation-report.json.

Staging stores a pending private candidate and never writes canonical settings
or an outbox. Captured provider output survives concurrent RU/EN edits and
canonical deletion; strict live full-settings/CAS/singleton/ownership checks
remain required for explicit human promotion. Only selected EN keys and their
machine metadata change. Raw RU, CRLF, whitespace, long dashes, French/rights,
unknown metadata and block attributes are checked unchanged. UTF-16 boundaries
match the actual DTO. Staff-only discovery returns identities/cursor only and
finds candidates after canonical deletion, with exact 10+1 keyset pages.

These fixtures use synthetic Auth/staff and transactional publication capture.
They do not establish managed Auth/PostgREST, authenticated browser, real provider,
production schema/deployment or deployed public acceptance. Selected item text
and hashes remain trusted server/provider projections; SQL binds full raw settings,
raw-key existence/ownership, exact source/target revisions, item order and shape.

The final CLI security advisor run is FAILED: 11 warnings and 4 errors belong to
the synthetic predecessor setup. No finding names the new migration or the owned
new fixture functions. The raw failed log is preserved; it is not a clean global
advisor PASS or a production advisor result. CLI's generic “remote database”
message comes from --db-url pointing only to owned 127.0.0.1:55438.

Run 2 and 3 failures are retained as diagnostics: a timezone-rendered created_at
comparison and JSON operator precedence in the new fixture. They were corrected
without weakening contract checks. Runs 4 through 8 are superseded local passes;
only Run 9 binds the final source inventory. Initial limited-context bootstrap
socket failures produced no native run log. Early advisor probes reused a log
name before versioned logs were introduced; only the retained raw files are
packaged, with no reconstructed raw outputs or success claims.

The database was always stopped by its exact owned data-directory/PID manifest.
No Windows service was created and no unrelated process was stopped. Data files,
native binaries, dependency trees, credentials and personal sessions are excluded.

Verify ZIP/member hashes before extracting into an empty scratch directory.
fixture.sql may run only in an owned disposable empty PostgreSQL database.
The runners contain historical absolute workspace paths; adapt those deliberately
and use fresh output labels. Do not run them against a managed/production database.
The maintained new migration and fixture source captures are included unchanged.
DTO replay requires the matching current repository and its locked dependencies.
