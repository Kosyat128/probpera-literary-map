const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { createRequire } = require('node:module');
const repo = process.env.SITE_COPY_REPO;
const req = createRequire(path.join(repo, 'package.json'));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const read = relative => JSON.parse(fs.readFileSync(path.join(__dirname, relative), 'utf8'));
const before = read('before/report.json'), current = read('current/report.json');
assert.equal(before.fixture.sha256, current.fixture.sha256);
assert.equal(before.fixture.sha256, sha(fs.readFileSync(path.join(__dirname, 'site-copy-machine-review.cjs'))));
assert.equal(current.fixture.sha256, sha(fs.readFileSync(path.join(repo, 'apps/admin/lib/fixtures/site-copy-machine-review.cjs'))));
assert.equal(before.unchanged, true); assert.equal(current.unchanged, true);
assert.equal(before.summary.executionFail, 0); assert.equal(current.summary.fail, 0);
const common = before.checks.map(row => row.name);
const commonChecks = common.map(name => ({ name, before: before.checks.find(row => row.name === name), current: current.checks.find(row => row.name === name) }));
assert.ok(commonChecks.every(row => row.current?.pass === true));
const beforeGraph = new Map(before.sources.map(row => [row.file, row.sha256]));
const currentGraph = new Map(current.sources.map(row => [row.file, row.sha256]));
const graphDelta = [...new Set([...beforeGraph.keys(), ...currentGraph.keys()])].sort().map(file => ({ file,
  before: beforeGraph.get(file) || null, current: currentGraph.get(file) || null,
  change: !beforeGraph.has(file) ? 'newly executed' : !currentGraph.has(file) ? 'not executed in current'
    : beforeGraph.get(file) === currentGraph.get(file) ? 'same bytes' : 'changed bytes' }));
const packages = ['typescript', '@supabase/supabase-js', 'zod', 'next/navigation', 'next/dist/client/components/redirect',
  'next/dist/client/components/redirect-error', 'react', 'react-dom/server', 'cheerio'].map(name => {
  const entry = req.resolve(name);
  let folder = path.dirname(entry), manifest;
  while (!manifest) {
    const candidate = path.join(folder, 'package.json');
    if (fs.existsSync(candidate)) {
      const raw = fs.readFileSync(candidate), parsed = JSON.parse(raw);
      if (parsed.name && parsed.version) manifest = { file: candidate, name: parsed.name, version: parsed.version, sha256: sha(raw) };
    }
    const next = path.dirname(folder); if (next === folder) throw new Error(`Package metadata absent: ${name}`); folder = next;
  }
  return { requested: name, entry, entrySha256: sha(fs.readFileSync(entry)), package: manifest };
});
function batch(report) {
  const trace = report.traces.find(row => row.name === 'Actual batch');
  return { providerPasses: trace.providerCalls.map(row => row.pass), canonicalMutations: trace.mutations.length,
    publicBuildRequests: trace.builds.length, canonicalBefore: trace.originalRow.settings.siteCopy.en,
    canonicalAfter: trace.rowAfter.settings.siteCopy.en, actualPublicExport: trace.publicAfter.en,
    privatePending: trace.privateDraft?.humanReview || null };
}
const report = { checkedAt: new Date().toISOString(), fixtureSha256: current.fixture.sha256,
  wrapperSha256: sha(fs.readFileSync(path.join(__dirname, 'site-copy-machine-review.integration.test.ts'))),
  before: { sourceRoot: before.sourceRoot, summary: before.summary, batch: batch(before), unchanged: before.unchanged },
  current: { sourceRoot: current.sourceRoot, summary: current.summary, batch: batch(current), unchanged: current.unchanged },
  commonChecks, currentOnlyChecks: current.checks.filter(row => !common.includes(row.name)).map(row => ({ name: row.name, pass: row.pass })),
  graphDelta, installedPackageEntries: packages,
  limitations: current.limitations,
};
fs.writeFileSync(path.join(__dirname, 'pair-summary.json'), JSON.stringify(report, null, 2), { flag: 'wx' });
process.stdout.write(JSON.stringify({ fixtureSha256: report.fixtureSha256, before: report.before.summary,
  current: report.current.summary, commonChecks: commonChecks.length, graphFiles: { before: before.sources.length, current: current.sources.length } }));
