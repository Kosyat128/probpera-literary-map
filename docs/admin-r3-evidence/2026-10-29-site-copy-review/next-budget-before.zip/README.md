# M07 writer batch: retained BEFORE evidence

This archive records an unresolved budget defect. It is **not an acceptance PASS**
and contains no implementation change.

The current writer batch limits successful translations to three, but conflicts
do not consume that counter. With five eligible synthetic writers, the actual
batch/helper/premium pipeline starts five expensive attempts and ten provider
passes, records zero successes and five conflicts, and wraps `writerCursor` to
zero. Each synthetic override revision deliberately changes after its accepted
reviewer response. Canonical authored fields remain exact; there are no machine
canonical writes or publication requests.

## Evidence roles

- `writer-conflict-budget.cjs` is the frozen observation diagnostic. Its successful
  exit **0 means that the defect was reproduced**, not that the application meets
  the criterion. Its known-result assertions deliberately expect five attempts
  and ten passes; do not use this diagnostic's exit code as an acceptance gate.
- `writer-conflict-run/report.json` and `sources/` contain the original actual
  execution and all 15 byte-exact TypeScript source modules it loaded.
- `writer-conflict-frozen-replay/` is the same diagnostic replayed solely against
  that captured graph. It independently repeats the five-attempt/ten-pass result.
- `writer-conflict-budget-acceptance.cjs` is a separate contract fixture frozen
  before implementation, using the same five inputs and concurrency events. It
  expects three admitted attempts, six actual passes, three conflict items and
  cursor three. `writer-budget-contract-before/report.json` records **four target
  failures**, with execution and authored-preservation controls passing. The child
  process exits **1** for those target failures; unexpected execution failures
  exit **2**. A future correct implementation can run this exact same file and
  pass without replacing or fabricating the historical BEFORE capture.
- `command-receipt.json`, `acceptance-command-receipt.json`, source manifests,
  stdout captures and `package-manifest.json` identify commands, results, fixture
  hashes, runtime versions and installed dependency entry/metadata hashes.
- `sha256-manifest.json` hashes every packaged file except itself. The adjacent
  archive manifest supplies the ZIP hash and records successful readback checks.

The acceptance fixture is a focused next-step regression. Passing it alone will
not establish all M07-T10/T11, M07, M24 or R3 acceptance.

## Replay

Use the repository's installed Node 24/npm 11 dependencies. No credentials are
needed. Keep all output outside the repository, in the user's parent `work/`
directory. Each output directory must be new; scripts refuse to overwrite it.

In PowerShell, set the unpacked evidence path and the real repository path:

```powershell
$evidence = 'C:\path\to\work\unpacked-budget-evidence'
$repo = 'C:\path\to\probpera-literary-map'
Set-Location -LiteralPath $repo
$env:PROFILE_BUDGET_REPO = $repo
$env:PROFILE_BUDGET_SOURCE_ROOT = Join-Path $evidence 'writer-conflict-run/sources'
$env:PROFILE_BUDGET_OUTPUT_ROOT = Join-Path $evidence 'new-original-contract-replay'
node (Join-Path $evidence 'writer-conflict-budget-acceptance.cjs')
```

The original graph is expected to exit **1** with four budget/cursor target
failures. To compare the fixed implementation with the same fixture, set
`PROFILE_BUDGET_SOURCE_ROOT` to the current repository and choose another new
output directory. Do not change the captured source files, assertions, configured
limits or synthetic inputs merely to make a result green.

## Boundaries

Actual current batch, writer helper, premium two-pass translation algorithm,
runtime gate/probe, run DTO, installed Supabase SDK and native Next redirect run.
Staff, catalog, PostgREST transport and Cloudflare AI binding are controlled. The
provider algorithm, action and helper are not mocked. `global.fetch` denies
uncontrolled network access.

All authored text and rights in the fixture are synthetic. Timestamps change only
as explicit in-memory concurrency events. No real Auth, PostgREST, database, RLS,
provider, browser, deployment or production behavior is claimed. No paid calls or
repository edits were performed. No credentials, sessions, dependencies or native
binaries are packaged.

The measured case has five candidates. It does not measure the 120-scan worst
case, repair requests, retries, total elapsed deadline behavior or other translation domains.
`repositoryStatusUnchanged` compares Git status text, not every repository byte;
the stronger content-preservation claim applies to the 15 loaded modules, whose
original and captured hashes were checked before/after execution and readback.
