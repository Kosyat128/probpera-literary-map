# M07 library batch: retained BEFORE budget defect

This is evidence of an unresolved defect, **not an acceptance PASS**. No product
code was changed for this diagnostic.

With five eligible synthetic works, the actual library batch starts five expensive
attempts and ten premium provider passes, despite its successful-translation cap
of four. Each accepted reviewer response is followed by an intentional in-memory
RU revision change. The actual helper's final RU read detects that change and
returns a conflict. The durable run records zero successes, five conflicts and
`libraryCursor: 0`.

Actual safe-wrapper readiness, reviewed work/RU eligibility, ownership branch,
pre-verified English title, recorded matching bibliographic title and HTTPS source
guards execute. The trace contains six readiness RPCs, five distinct bibliographic
source reads and five post-provider RU revision reads. No helper, action, provider
algorithm or runtime probe is stubbed. Only staff, database transport and the
Cloudflare AI boundary are controlled.

All canonical EN, work fields, descriptions, metadata, source rows and rights
remain exact. The only intentional fixture mutation is each RU `updated_at`.
No canonical machine write or publication request occurs.

## Evidence and exit codes

- `library-conflict-budget.cjs`: frozen observation diagnostic. Exit **0 means the
  known five-attempt/ten-pass defect was reproduced**, not application acceptance.
- `library-conflict-run/`: original report, manifest and 15 captured source files.
- `library-conflict-frozen-replay/`: exact same diagnostic replayed against only
  that captured source graph, with the same observed result.
- `library-conflict-budget-acceptance.cjs`: separate contract fixture frozen
  before implementation. It keeps the same five eligible works and races, and
  expects four attempts, eight passes, four conflict items and cursor four.
- `library-budget-contract-before/report.json`: four target failures, with
  execution and authored-preservation controls passing. The acceptance child
  exits **1** for target failures; unexpected execution errors exit **2**.
- Receipts, stdout, dependency hashes and `sha256-manifest.json` identify the
  commands, results and original bytes. The adjacent ZIP manifest records archive
  hash and readback verification.

Do not relabel this archive as PASS. A future implementation can run the frozen
acceptance file unchanged against original and current graphs. Passing that
focused fixture alone does not establish full M07-T10/T11, M07 or R3 acceptance.

## Replay

Use installed repository Node 24/npm 11 dependencies; credentials are unnecessary.
Unpack under the parent `work/` directory. All output directories must be new.

```powershell
$evidence = 'C:\path\to\work\unpacked-library-evidence'
$repo = 'C:\path\to\probpera-literary-map'
Set-Location -LiteralPath $repo
$env:LIBRARY_BUDGET_REPO = $repo
$env:LIBRARY_BUDGET_SOURCE_ROOT = Join-Path $evidence 'library-conflict-run/sources'
$env:LIBRARY_BUDGET_OUTPUT_ROOT = Join-Path $evidence 'new-original-contract-replay'
node (Join-Path $evidence 'library-conflict-budget-acceptance.cjs')
```

The original graph should exit **1** with four target failures. For the fixed
implementation, point `LIBRARY_BUDGET_SOURCE_ROOT` at the repository, select
another new output directory and run the same file. Do not fabricate new BEFORE
sources, lower limits or alter the assertions to make a result green.

## Limits

The inputs, rights and text are synthetic. Real Auth, PostgREST, database/RLS,
provider, browser, deployment and production behavior are not tested. No paid or
uncontrolled network call was made; `global.fetch` rejects uncontrolled network.
No credentials, sessions, dependencies or native binaries are packaged.

This is a positive-provenance case with machine-owned canonical EN and review
explicitly enabled. A separate manual-English input, bad-source rejection,
repair requests, retries, elapsed deadlines, 60-candidate scan and ordering/resume
stability are not covered. The transport ignores ordering because the five-row
budget case starts with tied timestamps; it makes no ordering claim.

Git-status equality is not a whole-repository byte hash. The content hash claim
applies to the 15 executed source modules and captured originals. Their bytes were
verified before/after execution, during frozen replay and by archive readback.
