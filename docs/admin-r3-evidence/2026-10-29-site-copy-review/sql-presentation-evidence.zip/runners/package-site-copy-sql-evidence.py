import collections, datetime, hashlib, json, pathlib, subprocess, zipfile

repo=pathlib.Path(r'C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map')
work=repo.parent/'work'
out=work/'site-copy-sql-native'
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda name,value:(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
migration='supabase/migrations/20261029181630_site_copy_private_translation_review.sql'
fixture='scripts/database/fixtures/site-copy-private-translation-review.sql'
dto=json.loads((out/'dto-replay-report.json').read_text(encoding='utf-8-sig'))
assert sha((repo/dto['source']['file']).read_bytes())==dto['source']['sha256'],'DTO source drift; rerun actual receipt replay'
manifest=json.loads((out/'fixture-manifest.json').read_text())
for item in manifest['sources']:
 assert sha((repo/item['file']).read_bytes())==item['sha256'],item['file']+' source drift'
log=(out/'run-10.log').read_text(encoding='utf-8-sig')
groups=[line for line in log.splitlines() if line.startswith('M07_') and line.endswith('_PASS')]
assert len(groups)==28,groups
assert 'ERROR:' not in log
lock=json.loads((out/'singleton-lock-report.json').read_text())
assert lock['status']=='PASS'
advisors=json.loads(next(line for line in (out/'security-advisors-final-run-9.log').read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')))
findings=advisors['results']
new_names=['site_copy_utf16_length','assert_site_copy_shape','assert_site_copy_recorded','assert_site_copy_current','list_site_copy_premium_translation_working_drafts','site_copy_fixture_settings','site_copy_fixture_reject_update']
relevant=[item for item in findings if item.get('metadata',{}).get('name') in new_names]
assert not relevant
write('security-advisors-final-summary.json',{'status':'FAIL_INHERITED_SYNTHETIC_FIXTURE','exitCode':1,'levels':dict(collections.Counter(item['level'] for item in findings)),'newMigrationAndOwnedFixtureFindings':relevant,'findings':[{'level':item['level'],'name':item['name'],'object':item.get('metadata',{}).get('name'),'schema':item.get('metadata',{}).get('schema')} for item in findings],'boundary':'Only owned isolated 127.0.0.1:55438/site_copy_private_fixture was queried. CLI says remote database for an explicit --db-url, not a managed or production target. Synthetic predecessor setup warnings/errors are retained; this is not an overall clean advisor PASS.'})
owned=json.loads((out/'owned-cluster.json').read_text(encoding='utf-8-sig'))
cleanup=json.loads((out/'cleanup-run-10.json').read_text(encoding='utf-8-sig'))
assert cleanup['pgCtlExitCode']==0 and not cleanup['pidFileRemains'] and not cleanup['postmasterProcessRemains']
write('tool-versions.json',{'node':'24.18.1','nodePath':r'C:\Users\Костя\Documents\Codex\tools\node-v24.18.1\node.exe','npm':'11.16.0','declaredPackageManager':'npm@11.17.0','declaredEngines':{'node':'24.x','npm':'11.x'},'postgres':'17.11','postgresBin':str(work/'portable-db-tools/postgresql-17.11-5/pgsql/bin'),'supabaseCLI':'2.120.0','supabaseExecutable':str(work/'portable-db-tools/supabase-2.120.0/supabase.exe'),'typescript':dto['typescript'],'vitest':'4.1.10','next':'16.3.3','react':'18.3.1','playwright':'1.62.1','supabaseJs':'2.112.3','supabaseSsr':'0.12.4','scope':'Versions and paths only. No environment values, credentials, host installation or binary packaging.'})
write('documentation-and-cli-receipt.json',{'atUtc':now,'cliCreation':{'command':'supabase migration new site_copy_private_translation_review','version':'2.120.0','helpReadFirst':True,'createdMigration':migration,'observedStdout':'Migration created','receiptKind':'Summary of observed tool stdout; not a fabricated raw terminal transcript'},'telemetry':'Initial help/version probes attempted a user-home telemetry write and failed. Retried successfully with documented telemetry/update opt-outs and workspace-only SUPABASE_HOME. No secrets read or written.','sources':[{'url':'https://supabase.com/changelog.md','outcome':'Browser fetch rejected text/markdown; direct shell fetch could not resolve DNS. Current official HTML changelog read instead.'},{'url':'https://supabase.com/changelog','outcome':'Current breaking changes scanned.'},{'url':'https://supabase.com/changelog/45329-breaking-change-tables-not-exposed-to-data-and-graphql-api-automatically','outcome':'Read applicable Data API exposure change. This patch retains the existing unexposed private table/ACL and explicitly grants only the new staff read RPC.'},{'url':'https://supabase.com/docs/guides/database/functions','outcome':'Checked current definer/invoker, search_path, execute grants and fresh actor authorization guidance.'},{'url':'https://github.com/supabase/cli/blob/develop/apps/cli/docs/analytics.md','outcome':'Verified SUPABASE_TELEMETRY_DISABLED and DO_NOT_TRACK opt-outs.'}],'docsTool':'Supabase MCP search_docs used for current roles/function/migration guidance before implementation.'})
write('native-report.json',{'status':'PASS_WITH_EXPLICIT_BOUNDARIES','exitCode':0,'atUtc':now,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'finalRun':10,'postgresVersion':'17.11','sqlGroups':{'total':28,'bookCountry':10,'writer':7,'siteCopy':11},'groups':groups,'actualSharedSingletonLock':{'status':'PASS','lock':[188654771,2],'contenderExitCode':lock['contenderExitCode'],'durationMs':lock['durationMs'],'draftCanonicalAuditOutboxUnchanged':True},'dtoAssertions':len(dto['assertions']),'sourceManifest':'fixture-manifest.json','migration':{'file':migration,'sha256':sha((repo/migration).read_bytes())},'maintainedFixture':{'file':fixture,'sha256':sha((repo/fixture).read_bytes())},'dtoSource':dto['source'],'providerCalls':0,'managedAuthPostgrestVerified':False,'productionContacted':False,'advisors':'FAIL inherited synthetic fixture; zero new migration/owned fixture findings. Raw advisor Run9 is retained and not relabelled as a Run10 execution; migration/functions unchanged, with fixture data proven equivalent.','databaseStopped':True,'boundaries':manifest['boundaries']+['SQL validates captured settings/key ownership on private stage and retains paid output through concurrent live edits/deletion; only explicit human promotion applies strict current singleton/CAS/fullraw binding.','Discovery is a fresh staff checked, read-only keyset adapter over existing storage; only entity IDs and a draft UUID cursor are returned.','UTF-16 maxima agree with actual current DTO for 1200-unit keys and 4000-unit source/payload text; one more unit is rejected.','Two SQL source-literal Unicode escapes preserve actual full native stage arguments/candidate digest exactly; see presentation-literal-equivalence.json.','No authenticated browser, managed GoTrue/PostgREST, paid provider, production migration, deployment or deployed-public acceptance.']})
readme='''# Site Copy private review: isolated native SQL evidence

Final source-bound proof is Run 10: 28 actual SQL groups (10 book/country, 7 writer,
11 Site Copy), the real two-session singleton-lock probe, and 14 actual current
TypeScript DTO/transport parser checks over the native envelopes. Consult
native-report.json, fixture-manifest.json and sql-preservation-report.json.

Staging stores a pending private candidate and never writes canonical settings
or an outbox. Captured provider output survives concurrent RU/EN edits and
canonical deletion; strict live full-settings/CAS/singleton/ownership checks
remain required for explicit human promotion. Only selected EN keys and their
machine metadata change. Raw RU, CRLF, whitespace, long dashes, French/rights,
unknown metadata and block attributes are checked unchanged. UTF-16 boundaries
match the actual DTO. Staff-only discovery returns identities/cursor only and
finds candidates after canonical deletion, with exact 10+1 keyset pages.

These fixtures use synthetic Auth/staff and transactional publication capture.
They do not establish managed Auth/PostgREST, authenticated browser, real provider,
production schema/deployment or deployed public acceptance. Selected item text
and hashes remain trusted server/provider projections; SQL binds full raw settings,
raw-key existence/ownership, exact source/target revisions, item order and shape.

The final CLI security advisor run is FAILED: 11 warnings and 4 errors belong to
the synthetic predecessor setup. No finding names the new migration or the owned
new fixture functions. The raw failed log is preserved; it is not a clean global
advisor PASS or a production advisor result. CLI's generic “remote database”
message comes from --db-url pointing only to owned 127.0.0.1:55438.

Run 2 and 3 failures are retained as diagnostics: a timezone-rendered created_at
comparison and JSON operator precedence in the new fixture. They were corrected
without weakening contract checks. Runs 4 through 8 are superseded local passes;
only Run 10 binds the final source inventory. Run 9 is retained as the genuine
pre-presentation proof; two SQL E-string Unicode escapes preserve its full actual
stage arguments and candidate digest exactly. Initial limited-context bootstrap
socket failures produced no native run log. Early advisor probes reused a log
name before versioned logs were introduced; only the retained raw files are
packaged, with no reconstructed raw outputs or success claims.

The database was always stopped by its exact owned data-directory/PID manifest.
No Windows service was created and no unrelated process was stopped. Data files,
native binaries, dependency trees, credentials and personal sessions are excluded.

Verify ZIP/member hashes before extracting into an empty scratch directory.
fixture.sql may run only in an owned disposable empty PostgreSQL database.
The runners contain historical absolute workspace paths; adapt those deliberately
and use fresh output labels. Do not run them against a managed/production database.
The maintained new migration and fixture source captures are included unchanged.
DTO replay requires the matching current repository and its locked dependencies.
'''
(out/'README.md').write_text(readme,encoding='utf-8')
entries={}
for p in out.iterdir():
 if not p.is_file() or p.name in ['postgres.log','evidence-package-manifest.json']:continue
 if p.suffix in ['.json','.log','.sql','.md']:entries[p.name]=p.read_bytes()
for name in ['build-site-copy-native-fixture.mjs','build-site-copy-migration.mjs','compare-site-copy-sql.mjs','replay-site-copy-native-dto.mjs','probe-site-copy-lock.mjs','run-site-copy-native.ps1','check-site-copy-advisors.ps1','package-site-copy-sql-evidence.py']:
 entries['runners/'+name]=(work/name).read_bytes()
for name in [migration,fixture,dto['source']['file']]:entries['sources/'+name]=(repo/name).read_bytes()
package={'schemaVersion':1,'createdAtUtc':now,'classification':'LOCAL_VERIFIED_WITH_CONTROLLED_BOUNDARIES','finalNativeRun':10,'nativeGroups':28,'actualSingletonLockChecks':1,'dtoAssertions':len(dto['assertions']),'advisorsOverallPassed':False,'newMigrationAdvisorFindings':0,'entries':[{'name':name,'length':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]}
manifest_bytes=(json.dumps(package,ensure_ascii=False,indent=2)+'\n').encode();(out/'evidence-package-manifest.json').write_bytes(manifest_bytes);entries['evidence-package-manifest.json']=manifest_bytes
zip_path=work/'site-copy-private-sql-presentation-final-evidence.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(zip_path) as z:
 for item in package['entries']:
  data=z.read(item['name']);assert len(data)==item['length'] and sha(data)==item['sha256']
print(json.dumps({'archive':str(zip_path),'sha256':sha(zip_path.read_bytes()),'bytes':zip_path.stat().st_size,'members':len(entries),'manifestMembersVerified':len(package['entries']),'finalMigrationSha256':sha((repo/migration).read_bytes()),'finalFixtureSha256':sha((repo/fixture).read_bytes()),'dtoSource':dto['source']},ensure_ascii=True))
