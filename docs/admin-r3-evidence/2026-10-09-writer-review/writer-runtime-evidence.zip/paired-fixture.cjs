const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { createRequire } = require('node:module');
const { execFileSync } = require('node:child_process');

// Scratch-only SAME fixture. No maintained repository file or real service is changed.
const repo = process.env.WRITER_REPO || path.resolve(__dirname, '../../probpera-literary-map');
const sourceRoot = process.env.WRITER_SOURCE_ROOT || repo;
const outRoot = process.env.WRITER_OUTPUT_ROOT || path.join(__dirname, 'before-v1');
fs.mkdirSync(outRoot, { recursive: true });
assert.equal(fs.existsSync(path.join(outRoot, 'report.json')), false, 'Use a new output label');
const nativeRequire = createRequire(path.join(repo, 'package.json'));
const ts = nativeRequire('typescript');
const { createClient } = nativeRequire('@supabase/supabase-js');
const { isRedirectError } = nativeRequire('next/dist/client/components/redirect-error');
const { getURLFromRedirectError } = nativeRequire('next/dist/client/components/redirect');
const graph = new Map(), traces = [], checks = [];
const sha = value => createHash('sha256').update(value).digest('hex');
const digest = value => sha(JSON.stringify(value));
const noNetwork = () => { throw new Error('Forbidden uncontrolled network in writer fixture'); };
global.fetch = noNetwork;
const actorId = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const overrideId = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const runId = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc';
const countryId = 'russia', writerId = 'leo_tolstoy';
const stamp = '2026-10-09T10:00:00.123456+00:00';
const russianText = 'Лев Толстой (1828-1910) - русский писатель, автор романов «Война и мир» и «Анна Каренина». Его произведения входят в мировую литературную традицию и продолжают изучаться исследователями.';
const englishText = 'Leo Tolstoy (1828-1910) was a Russian writer who wrote the novels “War and Peace” and “Anna Karenina”. His works belong to the world literary tradition and continue to be studied by scholars.';
const source = { provider: 'Russian State Library', url: 'https://sources.fixture.invalid/tolstoy', fields: ['identity', 'life-dates', 'biography-facts', 'works'], usage: 'fact-check', retrievedAt: '2026-10-09', title: 'Verified writer reference', licenseName: 'Reference facts', licenseUrl: 'https://rights.fixture.invalid/reference' };
const russian = { locale: 'ru', text: russianText, sourceLanguage: 'Russian', status: 'reviewed', method: 'editorial-original', reviewedAt: '2026-10-09', reviewer: 'Human editorial fixture', sources: [source] };

function sourceBytes(file) {
  const actual = path.join(sourceRoot, file), bytes = fs.readFileSync(actual);
  const previous = graph.get(file), hash = sha(bytes);
  if (previous) assert.equal(previous.sha256, hash, `Executed source drift: ${file}`);
  else {
    const saved = path.join(outRoot, 'sources', file);
    fs.mkdirSync(path.dirname(saved), { recursive: true }); fs.writeFileSync(saved, bytes, { flag: 'wx' });
    graph.set(file, { module: file, sha256: hash, capture: path.relative(outRoot, saved).replaceAll('\\', '/') });
  }
  return bytes;
}
function modules(mocks) {
  const cache = new Map();
  const fixtureProcess = { env: { PREMIUM_TRANSLATION_PROVIDER: 'cloudflare', ADMIN_BASE_PATH: '', OPENAI_AUTO_TRANSLATE_PROFILES: 'true', OPENAI_PREMIUM_TRANSLATION_REVIEW: 'true' } };
  function load(file) {
    if (cache.has(file)) return cache.get(file);
    const bytes = sourceBytes(file), filename = path.join(sourceRoot, file);
    const output = ts.transpileModule(bytes.toString('utf8'), { fileName: filename.replace(/\.mjs$/u, '.js'), compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, esModuleInterop: true, allowJs: true } }).outputText;
    const module = { exports: {} }; cache.set(file, module.exports);
    function requireActual(name) {
      if (Object.hasOwn(mocks, name)) return mocks[name];
      const target = name.startsWith('@/') ? path.join(sourceRoot, 'apps/admin', name.slice(2)) : name.startsWith('.') ? path.resolve(path.dirname(filename), name) : null;
      if (!target) return nativeRequire(name);
      for (const extension of ['', '.ts', '.tsx', '.mjs', '/index.ts']) {
        const full = target + extension;
        if (fs.existsSync(full) && fs.statSync(full).isFile()) return load(path.relative(sourceRoot, full).replaceAll('\\', '/'));
      }
      throw new Error(`Actual dependency absent: ${name} from ${file}`);
    }
    new Function('require', 'module', 'exports', 'process', 'fetch', output)(requireActual, module, module.exports, fixtureProcess, noNetwork);
    cache.set(file, module.exports); return module.exports;
  }
  return { load };
}
function matches(row, params) {
  return [...params].every(([key, value]) => !value.startsWith('eq.') || String(row[key]) === value.slice(3));
}
function resultCheck(name, condition, expected, actual, category = 'target') {
  checks.push({ name, category, pass: !!condition, expected, actual });
}
function fixture(options = {}) {
  const fields = { name: 'Лев Толстой', fullName: 'Leo Tolstoy', biographyTranslations: { ru: structuredClone(russian) }, works: ['Война и мир'], custom: { rights: 'Keep author metadata', nested: [1, 'Ω'] } };
  const english = { locale: 'en', text: englishText, sourceLanguage: 'Russian', status: options.manualDraft ? 'draft' : 'reviewed', method: options.manual || options.manualDraft ? 'human-translation' : 'machine-translation', reviewedAt: options.manualDraft ? undefined : '2026-10-08', reviewer: 'Original admitted editor', translatedFromLocale: 'ru', sourceTextRights: 'project-original', sources: structuredClone(russian.sources), translationMeta: { provider: 'cloudflare', model: '@cf/original/translator', reviewerModel: '@cf/original/reviewer', sourceHash: digest({ writerName: 'Leo Tolstoy', text: russian.text, sourceLanguage: russian.sourceLanguage, sources: russian.sources }), generatedAt: '2026-10-08T09:00:00.000Z' } };
  if (options.manual || options.manualDraft || options.admitted) fields.biographyTranslations.en = english;
  if (options.malformedEnglish) fields.biographyTranslations.en = { locale: 'en', method: 'human-translation', text: englishText, authorRights: { holder: 'Human draft author', consent: 'Keep incomplete authored profile' }, sources: [{ ...source, customRights: 'Keep exact source rights' }] };
  fields.biographyTranslations.fr = { locale: 'fr', text: 'Unrelated authored locale stays exact.', rights: { holder: 'French human editor' } };
  const sourceFields = structuredClone(fields);
  let row = options.absentOverride ? null : { id: overrideId, country_id: countryId, writer_id: writerId, fields: { unrelated: { authorRights: 'Keep exact override rights', locales: ['fr', 'ru', 'en'] } }, updated_at: stamp, is_enabled: true };
  if (options.overrideEnglish) row.fields.biographyTranslations = structuredClone(fields.biographyTranslations);
  const before = structuredClone(row), providerCalls = [], wire = [], mutations = [], builds = [], enqueues = [], audits = [], revalidations = [];
  let tick = 0, loaded, privateDraft = null;
  const snapshot = () => structuredClone(row);
  function newStamp() { tick++; return `2026-10-09T10:00:${String(tick).padStart(2, '0')}.123456+00:00`; }
  const fetchBoundary = async (resource, init = {}) => {
    const url = new URL(typeof resource === 'string' ? resource : resource.url);
    assert.equal(url.origin, 'https://writer.fixture.invalid');
    const method = init.method || 'GET', table = url.pathname.split('/').at(-1), payload = init.body ? JSON.parse(init.body) : null;
    wire.push({ method, path: url.pathname, query: Object.fromEntries(url.searchParams), payload: structuredClone(payload) });
    let data = null;
    if (url.pathname.includes('/rpc/')) {
      if (table === 'record_translation_sync_run') data = runId;
      else if (table === 'enqueue_public_build_request') { enqueues.push(structuredClone(payload)); data = String(enqueues.length); }
      else if (table === 'mark_public_build_dispatched' || table === 'ensure_editorial_reference') data = null;
      else if (table === 'get_premium_translation_working_draft') data = { schemaVersion: 1, entityType: payload.p_entity_type, entityId: payload.p_entity_id, draft: structuredClone(privateDraft) };
      else if (table === 'stage_premium_translation_working_draft') {
        privateDraft = { id: 'dddddddd-dddd-4ddd-8ddd-dddddddddddd', version: 1, entityType: payload.p_entity_type, entityId: payload.p_entity_id, targetLocale: 'en', humanReview: 'pending', sourceHash: payload.p_source_hash, candidateHash: digest(payload), sourceRevision: structuredClone(payload.p_source_revision), targetRevision: structuredClone(payload.p_target_revision), sourceSnapshot: structuredClone(payload.p_source_snapshot), payload: structuredClone(payload.p_payload), provenance: structuredClone(payload.p_provenance), createdAt: '2026-10-09T10:10:00.000Z', createdBy: actorId };
        data = { schemaVersion: 1, entityType: privateDraft.entityType, entityId: privateDraft.entityId, draft: structuredClone(privateDraft) };
      } else throw new Error(`Unexpected controlled RPC: ${table}`);
    } else if (method === 'GET') {
      if (table === 'translation_provider_self_tests') {
        const identity = await loaded.load('apps/admin/lib/premium-translation-probe.ts').premiumTranslationConfigurationIdentity();
        data = [{ provider: 'cloudflare', configured: true, binding_found: true, test_passed: true, model: identity.configuration.model, latency_ms: 1, last_error_code: null, last_test_at: new Date().toISOString(), cooldown_until: null, test_in_progress: false, configuration_identity: identity }];
      } else if (table === 'writer_profile_overrides') data = row && matches(row, url.searchParams) ? [structuredClone(row)] : [];
      else throw new Error(`Unexpected controlled read: ${table}`);
    } else if (method === 'PATCH' || (method === 'POST' && table === 'writer_profile_overrides')) {
      assert.equal(table, 'writer_profile_overrides');
      mutations.push({ method, table, payload: structuredClone(payload), query: Object.fromEntries(url.searchParams) });
      if (method === 'POST' || (row && matches(row, url.searchParams))) { row = { ...(row || { id: overrideId }), ...structuredClone(payload), updated_at: newStamp() }; data = [structuredClone(row)]; } else data = [];
    } else if (method === 'POST' && table === 'admin_audit_log') { audits.push(structuredClone(payload)); data = null; }
    else throw new Error(`Unexpected controlled transport ${method} ${table}`);
    return new Response(JSON.stringify(data), { status: 200, headers: { 'Content-Type': 'application/json' } });
  };
  const sdk = createClient('https://writer.fixture.invalid', 'controlled-no-live-auth', { auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }, global: { fetch: fetchBoundary } });
  const ai = { async run(model, input) {
    const data = JSON.parse(input.messages[1].content), pass = Object.hasOwn(data, 'INVALID_DRAFT_TRANSLATION') ? 'repair' : Object.hasOwn(data, 'DRAFT_TRANSLATION') ? 'review' : 'translation';
    providerCalls.push({ model, pass, source: structuredClone(data.SOURCE_DATA) });
    return { id: `controlled-writer-${providerCalls.length}`, response: JSON.stringify({ text: englishText }), usage: { prompt_tokens: 17, completion_tokens: 29 } };
  } };
  const catalog = { version: 1, countries: [{ id: countryId, label: 'Россия', fields: { name: 'Россия' }, writers: [{ id: writerId, label: 'Лев Толстой', fields: sourceFields }] }] };
  loaded = modules({ '@opennextjs/cloudflare': { getCloudflareContext() { return { env: { AI: ai } }; } }, '@/lib/auth': { async requireStaff() { return { user: { id: actorId }, profile: { role: 'owner' } }; } }, '@/lib/supabase/server': { async createServerSupabaseClient() { return sdk; } }, '@/lib/editorial-catalog': { async loadEditorialCatalog() { return structuredClone(catalog); } }, '@/lib/public-build': { async triggerPublicBuild(reason) { builds.push({ reason }); return { configured: true, ok: true, provider: 'cloudflare' }; } }, 'next/cache': { revalidatePath(value) { revalidations.push(value); } } });
  function publicView() {
    const publicProfile = loaded.load('scripts/lib/writer-biography-public-profile.mjs');
    const publicOverride = loaded.load('scripts/lib/writer-biography-public-overrides.mjs');
    const overrides = publicOverride.applyPublishedWriterBiographyOverrides({ snapshotOverrides: {}, rows: row ? [row] : [], normalizeBiographyTranslations(value) { return publicProfile.normalizePublicWriterBiographyTranslations(value, { writerName: 'Leo Tolstoy' }); } });
    const countries = loaded.load('src/data/cms/editorialOverrides.ts').applyCmsWriterProfileOverrides([{ id: countryId, writers: [{ id: writerId, ...sourceFields }] }], overrides);
    const writer = countries[0].writers[0];
    return { override: overrides[`${countryId}:${writerId}`] || null, selected: loaded.load('src/data/writerBiography.ts').selectWriterBiography(writer, 'en'), display: loaded.load('src/data/writerBiographyDisplay.ts').selectWriterBiographyForDisplay(writer, 'en') };
  }
  const publicBefore = publicView();
  const invoke = () => loaded.load('apps/admin/lib/auto-translate-writer-biography.ts').ensureWriterEnglishBiography({ supabase: sdk, actorId, countryId, writerId, sourceFields: structuredClone(sourceFields) });
  async function action(file, name, form) {
    try { await loaded.load(file)[name](form); throw new Error('Action failed to redirect'); }
    catch (error) { assert.equal(isRedirectError(error), true); return new URL(getURLFromRedirectError(error), 'https://admin.fixture.invalid').href; }
  }
  async function batch() { return action('apps/admin/app/(dashboard)/translations/actions.ts', 'translatePremiumWriterBatchAction', new FormData()); }
  async function saveBiography() {
    const form = new FormData(); form.set('country_id', countryId); form.set('writer_id', writerId); form.set('expected_updated_at', row?.updated_at || '');
    for (const locale of ['ru', 'en']) {
      const profile = locale === 'ru' ? russian : sourceFields.biographyTranslations.en;
      if (profile) form.set(`${locale}_enabled`, '1');
      form.set(`${locale}_text`, locale === 'ru' && options.admitted ? russianText.replace('продолжают изучаться исследователями', 'изучаются исследователями литературы') : profile?.text || ''); form.set(`${locale}_source_language`, profile?.sourceLanguage || 'Russian'); form.set(`${locale}_status`, profile?.status || 'draft');
      form.set(`${locale}_method`, profile?.method || (locale === 'ru' ? 'editorial-original' : 'human-translation')); form.set(`${locale}_reviewed_at`, profile?.reviewedAt || ''); form.set(`${locale}_reviewer`, profile?.reviewer || '');
      form.set(`${locale}_translated_from_locale`, profile?.translatedFromLocale || ''); form.set(`${locale}_source_text_rights`, profile?.sourceTextRights || ''); form.set(`${locale}_sources_json`, JSON.stringify(profile?.sources || []));
    }
    return action('apps/admin/app/(dashboard)/editorial-database/actions.ts', 'saveWriterBiographyAction', form);
  }
  async function saveProfile() {
    const edit = loaded.load('apps/admin/lib/editorial-profile-edit.ts'); const form = new FormData();
    form.set('entity_type', 'writer'); form.set('country_id', countryId); form.set('writer_id', writerId); form.set('expected_updated_at', row?.updated_at || '');
    form.append('enabled_fields', 'fullName');
    for (const key of edit.writerProfileFields) { const value = sourceFields[key]; form.set(key, Array.isArray(value) ? value.join('\n') : typeof value === 'string' ? value : ''); }
    return action('apps/admin/app/(dashboard)/editorial-database/actions.ts', 'saveEditorialProfileAction', form);
  }
  return { invoke, batch, saveBiography, saveProfile, publicView, publicBefore, before, sourceFields, snapshot, providerCalls, mutations, wire, builds, enqueues, audits, revalidations, get privateDraft() { return privateDraft; } };
}
function record(name, view, result) {
  const after = view.snapshot(), publicAfter = view.publicView();
  traces.push({ name, result, originalRow: view.before, rowAfter: after, sourceFields: view.sourceFields, publicBefore: view.publicBefore, publicAfter, providerCalls: view.providerCalls, mutations: view.mutations, wire: view.wire, builds: view.builds, enqueues: view.enqueues, privateDraft: view.privateDraft });
  return { after, publicAfter };
}

async function main() {
  const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim();
  const status = execFileSync('git', ['status', '--porcelain'], { cwd: repo, encoding: 'utf8' }).trim();
  const newCase = fixture(); const result = await newCase.invoke(); const { after, publicAfter } = record('new machine helper', newCase, result);
  resultCheck('Helper correct machine output executes two actual premium passes', newCase.providerCalls.length === 2 && result.state === 'translated', { calls: 2, state: 'translated' }, { calls: newCase.providerCalls.length, state: result.state }, 'execution');
  resultCheck('Technical machine success leaves canonical writer row exact', digest(after) === digest(newCase.before), digest(newCase.before), digest(after));
  resultCheck('Technical machine success has explicit pending private outcome', result.humanReview === 'pending' && result.translationPersistence === 'working-draft' && result.publication === 'unchanged', { humanReview: 'pending', translationPersistence: 'working-draft', publication: 'unchanged' }, result);
  resultCheck('New machine EN is outside actual public writer admission', publicAfter.selected === null && publicAfter.display === null, null, publicAfter);
  const batchCase = fixture(); const batchRedirect = await batchCase.batch(); record('actual writer batch', batchCase, batchRedirect);
  resultCheck('Actual writer batch has no machine-triggered public enqueue or dispatch', batchCase.providerCalls.length === 2 && batchCase.enqueues.length === 0 && batchCase.builds.length === 0, { calls: 2, enqueues: 0, builds: 0 }, { calls: batchCase.providerCalls.length, enqueues: batchCase.enqueues.length, builds: batchCase.builds.length });
  const saveCase = fixture({ admitted: true }); const saveRedirect = await saveCase.saveBiography(); const saved = record('actual structured biography save', saveCase, saveRedirect);
  resultCheck('Actual biography save executes accepted RU save then helper', saveCase.providerCalls.length === 2 && saveCase.mutations.length >= 1 && saveRedirect.includes('biography-saved'), true, { calls: saveCase.providerCalls.length, mutations: saveCase.mutations.length, redirect: saveRedirect }, 'execution');
  resultCheck('Accepted RU biography save queues only its ordinary publication', saveCase.enqueues.length === 1 && !saveCase.enqueues.some(entry => entry.p_reason === 'writer_profile.biography.english_generated'), { enqueues: 1, englishGenerated: false }, saveCase.enqueues);
  resultCheck('Biography-save machine candidate stays outside actual public admission', saved.publicAfter.selected === null, null, saved.publicAfter);
  const profileCase = fixture(); const profileRedirect = await profileCase.saveProfile(); const profileSaved = record('actual generic profile save', profileCase, profileRedirect);
  resultCheck('Actual generic profile save invokes premium helper', profileCase.providerCalls.length === 2 && profileRedirect.includes('result=saved'), true, { calls: profileCase.providerCalls.length, redirect: profileRedirect }, 'execution');
  resultCheck('Generic-profile machine candidate stays outside actual public admission', profileSaved.publicAfter.selected === null, null, profileSaved.publicAfter);
  for (const [name, options, expected] of [['manual reviewed', { manual: true }, 'manual'], ['manual draft', { manualDraft: true }, 'manual'], ['admitted machine', { admitted: true }, 'current']]) {
    const control = fixture(options), outcome = await control.invoke(), final = record(name, control, outcome);
    resultCheck(`${name} stays exact and has zero provider/write/build expense`, outcome.state === expected && control.providerCalls.length === 0 && control.mutations.length === 0 && control.enqueues.length === 0 && digest(final.after) === digest(control.before), { state: expected, calls: 0, mutations: 0, enqueues: 0 }, { outcome, calls: control.providerCalls.length, mutations: control.mutations.length, enqueues: control.enqueues.length }, 'compatibility');
    if (name === 'admitted machine') resultCheck('Already admitted machine remains publicly selected', final.publicAfter.selected?.text === englishText && final.publicAfter.display?.kind === 'published', { text: englishText, kind: 'published' }, final.publicAfter, 'compatibility');
  }
  const malformed = fixture({ malformedEnglish: true, overrideEnglish: true }); const malformedResult = await malformed.invoke(), malformedAfter = record('separate malformed authored EN preservation', malformed, malformedResult);
  resultCheck('Malformed authored EN fails closed without provider expense or canonical writes', malformed.providerCalls.length === 0 && malformed.mutations.length === 0 && digest(malformedAfter.after) === digest(malformed.before), { calls: 0, writes: 0, rowUnchanged: true }, { calls: malformed.providerCalls.length, writes: malformed.mutations.length, outcome: malformedResult, rowUnchanged: digest(malformedAfter.after) === digest(malformed.before) }, 'preservation');
  const sources = [...graph.values()].sort((a, b) => a.module.localeCompare(b.module));
  const unchanged = sources.every(entry => sha(fs.readFileSync(path.join(sourceRoot, entry.module))) === entry.sha256);
  assert.equal(unchanged, true, 'Graph changed while executing');
  const report = { checkedAt: new Date().toISOString(), head, sourceRoot, repoStatus: status, fixture: { sha256: sha(fs.readFileSync(__filename)), path: __filename }, sourceFingerprint: digest(sources), sourceCount: sources.length, sources, unchanged, checks, traces, summary: { total: checks.length, pass: checks.filter(x => x.pass).length, fail: checks.filter(x => !x.pass).length, targetFail: checks.filter(x => !x.pass && x.category === 'target').length, preservationFail: checks.filter(x => !x.pass && x.category === 'preservation').length, executionFail: checks.filter(x => !x.pass && ['execution', 'compatibility'].includes(x.category)).length }, limitations: ['Actual writer helper, premium transport, runtime gate/probe, batch and save actions, native Next redirects, publication/run adapters and public biography projection/selector execute.', 'Installed Supabase SDK uses a controlled in-memory fetch boundary; Auth/catalog/Workers AI/outbound build are controlled. No real Auth/PostgREST/DB/RLS/provider/browser/production acceptance.', 'All machine source and model outputs are synthetic. No real network calls, paid calls, repository changes or live database writes.', 'Malformed authored EN is a separate preservation scenario; its failure is not counted as M07-T05 proof.'] };
  fs.writeFileSync(path.join(outRoot, 'report.json'), JSON.stringify(report, null, 2), { flag: 'wx' });
  fs.writeFileSync(path.join(outRoot, 'manifest.json'), JSON.stringify({ head, sourceRoot, fixtureSha256: report.fixture.sha256, sourceFingerprint: report.sourceFingerprint, sources }, null, 2), { flag: 'wx' });
  console.log(JSON.stringify({ head, output: outRoot, sourceCount: sources.length, sourceFingerprint: report.sourceFingerprint, summary: report.summary, failed: checks.filter(x => !x.pass).map(x => ({ name: x.name, category: x.category })) }, null, 2));
  process.exitCode = report.summary.executionFail ? 2 : report.summary.fail ? 1 : 0;
}
main().catch(error => { const failure = { error: error.stack || String(error), checkedAt: new Date().toISOString(), sources: [...graph.values()], traces }; fs.writeFileSync(path.join(outRoot, 'diagnostic.json'), JSON.stringify(failure, null, 2), { flag: 'wx' }); console.error(error.stack || error); process.exitCode = 2; });
