import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const repo=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map`;
const out=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\work\writer-sql-native`;
fs.mkdirSync(out,{recursive:true});
const sources=[];
const read=file=>{const b=fs.readFileSync(path.join(repo,file));sources.push({file,sha256:createHash('sha256').update(b).digest('hex')});return b.toString('utf8').replace(/\r\n?/g,'\n');};
const {adminEditorOperationsContractSql}=await import(pathToFileURL(path.join(repo,'scripts/database/admin-editor-operations-contract.mjs')));
for(const file of ['scripts/database/admin-editor-operations-contract.mjs','scripts/database/fixtures/atomic-article-bundle-contract.sql',
 'supabase/migrations/20260728_cms_foundation.sql','supabase/migrations/20260730_page_revision_history.sql',
 'supabase/migrations/20260901_zzz_admin_mutation_guards.sql','supabase/migrations/20260822_zz_atomic_article_bundle.sql',
 'supabase/migrations/20260902_article_working_drafts.sql','supabase/migrations/20260905_article_publication_permissions.sql'])read(file);
const foundation=adminEditorOperationsContractSql().split('create or replace function public.fixture_apply_migration()')[0];
const library=read('supabase/migrations/20260730_literary_archive.sql');
const books=read('supabase/migrations/20260808_book_translations_and_import_staging.sql');
const country=read('supabase/migrations/20260813_editorial_database_admin.sql');
const countries=country.slice(0,country.indexOf('create table if not exists public.book_edition_revisions'));
const writer=read('supabase/migrations/20260812_writer_and_work_revisions.sql');
const writers=writer.slice(0,writer.indexOf('alter table public.literary_works'));
const machine=read('supabase/migrations/20260823_premium_machine_translation.sql');
const shortDraft=read('supabase/migrations/20260914_literary_translation_draft_storage.sql');
const privateBase=read('supabase/migrations/20261008160000_premium_translation_working_drafts.sql');
const additive=read('supabase/migrations/20261009082816_writer_biography_private_translation_review.sql');
const compatibility=read('scripts/database/fixtures/premium-translation-working-drafts.sql');
const writerFixture=read('scripts/database/fixtures/writer-biography-private-translation-review.sql');
const sql=[foundation,library,books,countries,writers,machine,shortDraft,privateBase,additive,compatibility,writerFixture].join('\n');
fs.writeFileSync(path.join(out,'fixture.sql'),sql);
const manifest={atUtc:new Date().toISOString(),sources,sqlSha256:createHash('sha256').update(sql).digest('hex'),
 boundaries:['Isolated native PostgreSQL17; synthetic Auth/staff roles and local outbox capture; no GoTrue/PostgREST/provider/production',
 'Original book/country fixture executes unchanged against base plus new writer migration',
 'Actual canonical writer table/timestamp/revision definitions before first literary_works ALTER execute unchanged',
 'Real canonical writer FK registry/public API ACL and managed schema deployment are outside this fixture',
 'Static catalog authenticity remains trusted server responsibility; SQL checks exact hash/raw catalog binding and override CAS']};
fs.writeFileSync(path.join(out,'fixture-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({out,sqlSha256:manifest.sqlSha256,sources:sources.length}));
