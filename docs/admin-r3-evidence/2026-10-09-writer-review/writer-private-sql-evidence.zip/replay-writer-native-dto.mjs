import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
const repo=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map`;
const out=String.raw`C:\Users\Костя\Documents\Codex\2026-10-09\v\work\writer-sql-native`;
const sourceFile='apps/admin/lib/premium-translation-working-draft.ts';
const source=fs.readFileSync(path.join(repo,sourceFile),'utf8');
const sha=x=>createHash('sha256').update(x).digest('hex');
const sourceHash=sha(source);
const require=createRequire(pathToFileURL(path.join(repo,'apps/admin/package.json')));
const ts=require('typescript');
const compiled=ts.transpileModule(source,{fileName:sourceFile,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}});
const module={exports:{}};
new Function('require','module','exports',compiled.outputText)(require,module,module.exports);
const api=module.exports;
const receiptBytes=fs.readFileSync(path.join(out,'writer-native-dto.json'));
const receipts=JSON.parse(receiptBytes);
const compatibilityBytes=fs.readFileSync(path.join(out,'book-country-native-dto.json'));
const compatibility=JSON.parse(compatibilityBytes);
const d=receipts['writer-pending'];
const args=receipts['writer-args'];
const identity={entityType:d.entityType,entityId:d.entityId};
const input={...identity,sourceHash:args.sourceHash,sourceSnapshot:args.source,sourceRevision:args.sourceRevision,
 targetRevision:args.targetRevision,payload:args.payload,provenance:args.provenance};
const consumed={...identity,draftId:d.id,version:d.version,candidateHash:d.candidateHash};
const promotion={...consumed,sourceHash:d.sourceHash,catalogSourceHash:d.sourceRevision.catalogSourceHash,
 catalogSourceFields:d.sourceSnapshot.catalogFields,actorId:receipts['writer-promoted'].reviewedBy};
const outcomes=[];
const check=async(name,body)=>{await body();outcomes.push({name,status:'PASS'});console.log(`PASS ${name}`);};
const transport=(data,name,inspect=()=>{})=>({rpc:async(actual,args)=>{assert.equal(actual,name);inspect(args);return {data:structuredClone(data),error:null};}});
const fails=async body=>assert.rejects(body,error=>error instanceof api.PremiumTranslationDraftError&&error.code==='unconfirmed');
await check('actual writer schema accepts PostgreSQL UUIDs, timestamp offsets and JSONB ordering',()=>{
 assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(d).success,true);
 assert.match(d.createdAt,/\.\d{4,6}[+-]\d\d:\d\d$/);
 assert.equal(d.sourceRevision.overrideUpdatedAt,'2026-10-09T13:00:00.123456+03:00');
});
await check('actual read parser confirms exact native RPC envelope',async()=>{
 const actual=await api.readPremiumTranslationWorkingDraft(transport(receipts['writer-read'],'get_premium_translation_working_draft',a=>assert.deepEqual(a,{p_entity_type:identity.entityType,p_entity_id:identity.entityId})),identity);
 assert.deepEqual(actual,d);
});
await check('actual stage parser preserves complete raw RU source rights and metadata',async()=>{
 const actual=await api.stagePremiumTranslationWorkingDraft(transport(receipts['writer-stage'],'stage_premium_translation_working_draft',a=>{
  assert.equal(a.p_expected_draft_id,null);assert.equal(a.p_expected_draft_version,0);assert.deepEqual(a.p_source_snapshot,args.source);
 }),input);
 assert.deepEqual(actual,d);
 assert.equal(actual.sourceSnapshot.russianProfile.sources[0].customRights.permissionId,'RAW-SOURCE-RIGHTS');
 assert.equal(actual.sourceSnapshot.russianProfile.text.startsWith('  '),true);
});
await check('actual stage parser accepts semantically identical reordered JSON keys',async()=>{
 const reversed=Object.fromEntries(Object.entries(input).reverse());
 reversed.sourceSnapshot=Object.fromEntries(Object.entries(input.sourceSnapshot).reverse());
 assert.deepEqual(await api.stagePremiumTranslationWorkingDraft(transport(receipts['writer-stage'],'stage_premium_translation_working_draft'),reversed),d);
});
await check('actual promotion parser accepts SQL review actor and microsecond receipt',async()=>{
 const actual=await api.promotePremiumTranslationWorkingDraft(transport(receipts['writer-promoted'],'promote_premium_translation_working_draft',a=>{
  assert.equal(a.p_confirm_human_review,true);assert.deepEqual(a.p_catalog_source_fields,promotion.catalogSourceFields);
 }),promotion);
 assert.deepEqual(actual,receipts['writer-promoted']);
});
await check('actual discard parser confirms SQL receipt for maximum Unicode identity',async()=>{
 const long=receipts['writer-long-pending'];
 assert.equal(Array.from(long.entityId).length,301);assert.equal(long.entityId.length,481);
 assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(long).success,true);
 const actual=await api.discardPremiumTranslationWorkingDraft(transport(receipts['writer-discarded'],'discard_premium_translation_working_draft'),{
  entityType:long.entityType,entityId:long.entityId,draftId:long.id,version:long.version,candidateHash:long.candidateHash,
 });assert.deepEqual(actual,receipts['writer-discarded']);
});
await check('actual read parser accepts native consumed-candidate absence',async()=>{
 const absent=receipts['writer-absent'];
 assert.equal(await api.readPremiumTranslationWorkingDraft(transport(absent,'get_premium_translation_working_draft'),{entityType:absent.entityType,entityId:absent.entityId}),null);
});
await check('read parser rejects envelope/entity identity substitution',async()=>{
 const changed=structuredClone(receipts['writer-read']);changed.entityId='other-country:writer-one';
 await fails(()=>api.readPremiumTranslationWorkingDraft(transport(changed,'get_premium_translation_working_draft'),identity));
});
await check('stage parser rejects response with lost raw source rights',async()=>{
 const changed=structuredClone(receipts['writer-stage']);delete changed.draft.sourceSnapshot.russianProfile.sources[0].customRights;
 await fails(()=>api.stagePremiumTranslationWorkingDraft(transport(changed,'stage_premium_translation_working_draft'),input));
});
await check('stage parser rejects changed payload or source hash',async()=>{
 for(const key of ['payload','sourceHash']){
  const changed=structuredClone(receipts['writer-stage']);
  if(key==='payload')changed.draft.payload.text+=' Extra unsupported assertion.';else changed.draft.sourceHash='f'.repeat(64);
  await fails(()=>api.stagePremiumTranslationWorkingDraft(transport(changed,'stage_premium_translation_working_draft'),input));
 }
});
await check('writer schema rejects nullable reviewer and inconsistent exact timestamps',()=>{
 const changed=structuredClone(d);changed.provenance.reviewerModel=null;
 assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(changed).success,false);
 const drift=structuredClone(d);drift.targetRevision.updatedAt='2026-10-09T13:00:00.123457+03:00';
 assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(drift).success,false);
});
await check('promotion parser rejects forged actor, version, candidate hash or selected entity',async()=>{
 for(const [key,value] of [['reviewedBy',d.createdBy],['version',2],['candidateHash','f'.repeat(64)],['entityId','other-country:writer-one']]){
  const changed={...receipts['writer-promoted'],[key]:value};
  await fails(()=>api.promotePremiumTranslationWorkingDraft(transport(changed,'promote_premium_translation_working_draft'),promotion));
 }
});
await check('discard parser rejects receipt for a different draft UUID',async()=>{
 const long=receipts['writer-long-pending'];
 await fails(()=>api.discardPremiumTranslationWorkingDraft(transport({...receipts['writer-discarded'],draftId:d.id},'discard_premium_translation_working_draft'),{
 entityType:long.entityType,entityId:long.entityId,draftId:long.id,version:long.version,candidateHash:long.candidateHash}));
});
await check('actual schema preserves native book and country compatibility',()=>{
 for(const name of ['book-pending','country-pending'])assert.equal(api.premiumTranslationWorkingDraftSchema.safeParse(compatibility[name]).success,true);
});
assert.equal(sha(fs.readFileSync(path.join(repo,sourceFile),'utf8')),sourceHash,'Parser source changed during replay');
let head=null;try{head=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();}catch{}
const report={status:'PASS',exitCode:0,atUtc:new Date().toISOString(),head,source:{file:sourceFile,sha256:sourceHash},
 receipts:{file:'writer-native-dto.json',sha256:sha(receiptBytes)},compatibilityReceipts:{file:'book-country-native-dto.json',sha256:sha(compatibilityBytes)},
 compiler:{typescript:ts.version},assertions:outcomes,
 boundaries:['Actual current TypeScript module transpiled without source transformation; real installed Zod and next/navigation are loaded.',
 'Only Supabase RPC transport is replayed from native PostgreSQL receipts. No real PostgREST/Auth network exchange or provider call is claimed.']};
fs.writeFileSync(path.join(out,'dto-replay-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(`WRITER_NATIVE_DTO_REPLAY_PASS=${outcomes.length}`);
