import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
const work=path.dirname(fileURLToPath(import.meta.url)), root=path.resolve(work,'../probpera-literary-map');
const out=path.join(work,'writer-ui-validation');fs.mkdirSync(out,{recursive:true});
const hash=b=>createHash('sha256').update(b).digest('hex');
const write=(name,v)=>fs.writeFileSync(path.join(out,name),JSON.stringify(v,null,2)+'\n');
const sourceFiles=[
 'apps/admin/app/(dashboard)/translations/actions.ts',
 'apps/admin/app/(dashboard)/editorial-database/actions.ts',
 'apps/admin/app/(dashboard)/editorial-database/page.tsx',
 'apps/admin/app/(dashboard)/translations/premium-review-actions.ts',
 'apps/admin/components/PremiumTranslationReviewPanel.tsx',
 'apps/admin/app/(dashboard)/editorial-database/writer-biography-editor.source.test.ts',
 'apps/admin/app/(dashboard)/editorial-database/editorial-database-load-errors.integration.test.ts',
 'apps/admin/lib/premium-translation-working-draft.ts',
 'apps/admin/lib/premium-translation-review.ts',
 'apps/admin/lib/auto-translate-writer-biography.ts',
];
function snapshot(){return sourceFiles.map(p=>({path:p,sha256:hash(fs.readFileSync(path.join(root,p)))}));}
const env=Object.fromEntries(Object.entries(process.env).filter(([k])=>/^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i.test(k)));
Object.assign(env,{CI:'1',NEXT_TELEMETRY_DISABLED:'1',NO_COLOR:'1'});
async function run(id,args,cwd=root){
 const start=Date.now(),before=snapshot(),log=path.join(out,id+'.log');fs.writeFileSync(log,'');
 const receipt={id,head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),command:{executable:process.execPath,args,cwd},startedAt:new Date(start).toISOString(),sourceBefore:before,status:'RUNNING'};
 write(id+'-receipt.json',receipt);console.log('START '+id);
 const result=await new Promise(resolve=>{const child=spawn(process.execPath,args,{cwd,env,windowsHide:true,stdio:['ignore','pipe','pipe']});child.stdout.on('data',d=>fs.appendFileSync(log,d));child.stderr.on('data',d=>fs.appendFileSync(log,d));child.on('error',e=>{receipt.spawnError=String(e);});child.on('close',(code,signal)=>resolve({code,signal}));});
 const after=snapshot();Object.assign(receipt,{finishedAt:new Date().toISOString(),durationMs:Date.now()-start,exitCode:result.code,signal:result.signal,status:result.code===0?'PASS':'FAIL',logSha256:hash(fs.readFileSync(log)),sourceAfter:after,zeroSelectedSourceDrift:JSON.stringify(before)===JSON.stringify(after)});write(id+'-receipt.json',receipt);console.log('END '+id+' '+receipt.status+' exit='+result.code);return receipt;
}
const mode=process.argv[2],label=process.argv[3]||mode;
if(mode==='page-tests'){
 const result=await run(label,[path.join(root,'node_modules/vitest/vitest.mjs'),'run',sourceFiles[5],sourceFiles[6],'--maxWorkers=2','--reporter=json','--outputFile='+path.join(out,label+'.raw.json')]);process.exitCode=result.exitCode===0?0:1;
}else if(mode==='source-tests'){
 const result=await run(label,[path.join(root,'node_modules/vitest/vitest.mjs'),'run',sourceFiles[5],'--maxWorkers=2','--reporter=json','--outputFile='+path.join(out,label+'.raw.json')]);process.exitCode=result.exitCode===0?0:1;
}else if(mode==='typecheck'){
 const admin=path.join(root,'apps/admin'),req=createRequire(path.join(admin,'package.json')),tsc=path.join(path.dirname(req.resolve('typescript/package.json')),'bin/tsc');const result=await run(label,[tsc,'--noEmit','--incremental','false'],admin);process.exitCode=result.exitCode===0?0:1;
}else if(mode==='compatibility'){
 const result=await run(label,[path.join(root,'node_modules/vitest/vitest.mjs'),'run','apps/admin/lib/premium-translation-review.integration.test.ts','apps/admin/lib/country-profile-machine-review.integration.test.ts','apps/admin/lib/literary-work-machine-review.integration.test.ts','apps/admin/lib/country-translation-source-binding.integration.test.ts','--maxWorkers=2','--reporter=json','--outputFile='+path.join(out,label+'.raw.json')]);process.exitCode=result.exitCode===0?0:1;
}else throw new Error('Unknown validation mode');
