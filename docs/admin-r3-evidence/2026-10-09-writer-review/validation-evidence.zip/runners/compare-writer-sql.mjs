import fs from 'node:fs';
import crypto from 'node:crypto';
const root=new URL('../probpera-literary-map/',import.meta.url);
const old=fs.readFileSync(new URL('supabase/migrations/20261008160000_premium_translation_working_drafts.sql',root),'utf8').replace(/\r\n/g,'\n');
const file='supabase/migrations/20261009082816_writer_biography_private_translation_review.sql';
const bytes=fs.readFileSync(new URL(file,root)),fresh=bytes.toString('utf8').replace(/\r\n/g,'\n');
function body(source,name){const start=source.indexOf('function '+name+'(');const a=source.indexOf('$$',start)+2,b=source.indexOf('$$;',a);if(start<0||a<2||b<0)throw new Error(name);return source.slice(a,b);}
const shape=body(fresh,'premium_translation_private.assert_shape').replace("  if kind='writer_biography' then\n    perform premium_translation_private.assert_writer_shape(snapshot,source_revision,target_revision,payload,provenance);\n    return;\n  end if;\n",'');
const current=body(fresh,'premium_translation_private.assert_current').replace("  if kind='writer_biography' then\n    perform premium_translation_private.assert_writer_current(identity,snapshot,source_revision,target_revision);\n    return;\n  end if;\n",'');
const oldPromote=body(old,'public.promote_premium_translation_working_draft'),newPromote=body(fresh,'public.promote_premium_translation_working_draft');
const oldTail=oldPromote.slice(oldPromote.indexOf("  if p_entity_type='literary_work' then"));
const newTail=newPromote.slice(newPromote.indexOf("  elsif p_entity_type='literary_work' then")).replace("  elsif p_entity_type='literary_work' then","  if p_entity_type='literary_work' then");
const oldIdentity=body(old,'premium_translation_private.assert_identity'),newIdentity=body(fresh,'premium_translation_private.assert_identity');
const result={migration:file,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),checks:{
 existingIdentityBranchIdentical:oldIdentity.slice(oldIdentity.indexOf('  if kind is null'))===newIdentity.slice(newIdentity.indexOf('  if kind is null')),
 existingShapeBranchesAndProvenanceIdentical:shape===body(old,'premium_translation_private.assert_shape'),
 existingCurrentBranchesIdentical:current===body(old,'premium_translation_private.assert_current'),
 existingBookCountryPromotionAndCommonTailIdentical:oldTail===newTail,
 noReplacementOfActorReadStageDiscard:/function premium_translation_private\.assert_actor\(/.test(fresh)===false&&['get_','stage_','discard_'].every(prefix=>!fresh.includes('function public.'+prefix+'premium_translation_working_draft(')),
},reviewScope:'Source-only independent review plus exact branch comparison; does not claim managed DB deployment or additional native replay.'};
fs.writeFileSync(new URL('writer-ui-validation/sql-independent-comparison.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));process.exitCode=Object.values(result.checks).every(Boolean)?0:1;
