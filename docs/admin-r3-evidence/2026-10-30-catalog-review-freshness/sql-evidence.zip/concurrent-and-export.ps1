$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\catalog-freshness-sql-native'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory){throw 'Unexpected owned cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
$started=$false
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-export.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned start failed'}
 $started=$true
 $ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8'
 $psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not the owned isolated cluster'}
 $database='catalog_freshness_v3_20261030'
 $script:freshnessQuerySequence=0
 function Invoke-FreshnessQuery([string]$query){
  # psql Windows argv uses the active ANSI codepage for non-ASCII -c text.
  # Use exact UTF8 files instead of round-tripping authored fixture prose in argv.
  $script:freshnessQuerySequence++
  $queryFile=Join-Path $nativeRoot ('export-query-'+$script:freshnessQuerySequence+'.sql')
  [IO.File]::WriteAllText($queryFile,$query,[Text.UTF8Encoding]::new($false))
  $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f $queryFile 2> (Join-Path $nativeRoot ('export-query-'+$script:freshnessQuerySequence+'.stderr.log'))
  if($LASTEXITCODE -ne 0){throw 'Owned SQL query failed'}
  return ,@($raw|Where-Object{ $_.StartsWith('{') -or $_.StartsWith('[')})
 }
 function Start-FreshnessSession([string]$file,[string]$application){
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$psql;$info.UseShellExecute=$false;$info.CreateNoWindow=$true
  $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true;$info.Environment['PGAPPNAME']=$application
  foreach($argument in @('-h','127.0.0.1','-p','55438','-U','postgres','-d',$database,'--no-psqlrc','--set=ON_ERROR_STOP=1','-qAt','-f',$file)){$info.ArgumentList.Add($argument)}
  $process=[Diagnostics.Process]::new();$process.StartInfo=$info;$clock=[Diagnostics.Stopwatch]::StartNew()
  if(-not $process.Start()){throw 'Owned concurrent session failed'}
  return @{process=$process;stdout=$process.StandardOutput.ReadToEndAsync();stderr=$process.StandardError.ReadToEndAsync();clock=$clock;application=$application}
 }
 function Finish-FreshnessSession($entry,[string]$label){
  if(-not $entry.process.WaitForExit(15000)){$entry.process.Kill();throw 'Owned session timeout'}
  $entry.clock.Stop();$stdout=$entry.stdout.GetAwaiter().GetResult();$stderr=$entry.stderr.GetAwaiter().GetResult()
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($label+'.stdout.log')),$stdout)
  [IO.File]::WriteAllText((Join-Path $nativeRoot ($label+'.stderr.log')),$stderr)
  if($entry.process.ExitCode -ne 0){throw ($label+' SQL failed '+$stderr)}
  $json=@($stdout -split "`n"|Where-Object{$_.TrimStart().StartsWith('{')})
  if($json.Count -ne 1){throw ('Unexpected receipt '+$label)}
  return @{pid=$entry.process.Id;application=$entry.application;elapsedMs=$entry.clock.ElapsedMilliseconds;exitCode=$entry.process.ExitCode;receipt=($json[0]|ConvertFrom-Json)}
 }
 $concurrent=@()
 foreach($kind in @('literary_work','country')){
  $seedRaw=Invoke-FreshnessQuery ("select public.catalog_fixture_seed('"+$kind+"','freshness-concurrent',true)")
  if($seedRaw.Count -ne 1){throw 'Expected seed'}
  $seed=$seedRaw[0]|ConvertFrom-Json;$seedLiteral=$seedRaw[0].Replace("'","''")
  $completed=Invoke-FreshnessQuery ("select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);set role authenticated;select public.catalog_freshness_fixture_complete('"+$seedLiteral+"'::jsonb);select public.get_premium_translation_working_draft('"+$kind+"','"+$seed.entityId+"')->'draft';reset role;")
  if($completed.Count -ne 2){throw 'Expected actual admission completion and pending draft'}
  $operation=$completed[0]|ConvertFrom-Json;$draft=$completed[1]|ConvertFrom-Json;$draftLiteral=$completed[1].Replace("'","''")
  $fieldsLiteral='null';if($kind -eq 'country'){$fieldsLiteral="'"+(($seed.expectedState.catalogFields|ConvertTo-Json -Depth 40 -Compress).Replace("'","''"))+"'::jsonb"}
  $protectedSql="select jsonb_build_object('cache',(select probpera_translation_operations.retry_fingerprint(to_jsonb(a)) from premium_translation_private.catalog_operation_artifacts a where operation_id='"+$operation.operationId+"'),'job',(select probpera_translation_operations.retry_fingerprint(to_jsonb(j)) from public.translation_jobs j where id='"+$operation.jobId+"'),'item',(select probpera_translation_operations.retry_fingerprint(to_jsonb(i)) from public.translation_job_items i where id='"+$operation.itemId+"'),'attempts',(select probpera_translation_operations.retry_fingerprint(coalesce(jsonb_agg(to_jsonb(t) order by id),'[]'::jsonb)) from public.translation_job_attempts t where item_id='"+$operation.itemId+"'),'canonical',(select probpera_translation_operations.retry_fingerprint(jsonb_build_object('works',(select jsonb_agg(to_jsonb(t) order by id) from public.literary_works t),'translations',(select jsonb_agg(to_jsonb(t) order by id) from public.literary_work_translations t),'sources',(select jsonb_agg(to_jsonb(t) order by id) from public.literary_work_sources t),'countries',(select jsonb_agg(to_jsonb(t) order by id) from public.country_profile_overrides t)))))"
  $before=(Invoke-FreshnessQuery $protectedSql)[0]
  $readSql="begin;set local role authenticated;select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);select public.catalog_freshness_fixture_read('"+$draftLiteral+"'::jsonb,"+$fieldsLiteral+");select pg_sleep(0.9);commit;"
  $discardSql="begin;set local role authenticated;select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);select public.premium_fixture_discard('"+$draftLiteral+"'::jsonb);commit;"
  $readFile=Join-Path $nativeRoot ('read-'+$kind+'.sql');$discardFile=Join-Path $nativeRoot ('discard-'+$kind+'.sql')
  [IO.File]::WriteAllText($readFile,$readSql);[IO.File]::WriteAllText($discardFile,$discardSql)
  $reader=Start-FreshnessSession $readFile ('freshness-read-'+$kind)
  [Threading.Thread]::Sleep(140)
  $discarder=Start-FreshnessSession $discardFile ('freshness-discard-'+$kind)
  [Threading.Thread]::Sleep(140)
  $wait=(Invoke-FreshnessQuery ("select jsonb_build_object('blocked',exists(select 1 from pg_stat_activity where application_name='freshness-discard-"+$kind+"' and cardinality(pg_blocking_pids(pid))>0))"))[0]|ConvertFrom-Json
  $read=Finish-FreshnessSession $reader ('read-'+$kind);$discard=Finish-FreshnessSession $discarder ('discard-'+$kind)
  if(-not $wait.blocked -or -not $read.receipt.canPromote -or $discard.receipt.state -ne 'discarded'){throw 'Actual reader/discard lock proof failed'}
  $missing=(Invoke-FreshnessQuery ("select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);set role authenticated;select public.catalog_freshness_fixture_read('"+$draftLiteral+"'::jsonb,"+$fieldsLiteral+");reset role;"))[0]|ConvertFrom-Json
  if($missing.canPromote -or $missing.reason -ne 'candidate_missing'){throw 'Consumed candidate did not close freshness'}
  $after=(Invoke-FreshnessQuery $protectedSql)[0]
  if($before -ne $after){throw 'Read/discard changed canonical/provider journal/cache'}
  $concurrent+=@{entityType=$kind;readSession=$read;discardSession=$discard;actualBlockedOnDatabaseLock=$wait.blocked;consumedMetadata=$missing;canonicalJournalCacheExact=$true;newProviderCalls=0}
 }
 $concurrent|ConvertTo-Json -Depth 35|Set-Content -LiteralPath (Join-Path $nativeRoot 'concurrent-receipts.json') -Encoding utf8
 $queries=@{
  'native-case-results.json'='select jsonb_object_agg(label,value) from public.catalog_freshness_fixture_results';
  'native-metadata.json'="select jsonb_object_agg(label,case when value ? 'canPromote' then value else value->'freshness' end) from public.catalog_freshness_fixture_results where value ? 'canPromote' or value->'freshness' ? 'canPromote'";
  'native-functions.json'="select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'securityDefiner',p.prosecdef,'config',p.proconfig,'source',p.prosrc) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where (n.nspname='public' and (p.proname like '%catalog_translation_operation%' or p.proname like '%writer_translation_operation%' or p.proname in ('get_catalog_translation_candidate_freshness','promote_premium_translation_working_draft'))) or (n.nspname='premium_translation_private' and (p.proname like 'catalog_operation_%' or p.proname like 'writer_operation_%' or p.proname='assert_catalog_operation_promotion_current'))";
 }
 foreach($filename in $queries.Keys){
  $raw=Invoke-FreshnessQuery $queries[$filename];if($raw.Count -ne 1){throw ('Unexpected export '+$filename)}
  [IO.File]::WriteAllText((Join-Path $nativeRoot $filename),$raw[0],[Text.UTF8Encoding]::new($false))
 }
 $available=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc -Atc "select count(*) from pg_available_extensions where name='plpgsql_check'"
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1'
 $env:SUPABASE_HOME='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\catalog-freshness-sql-native\cli-home'
 $cli='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\portable-db-tools\supabase-2.120.0\supabase.exe'
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$database+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors.log')
 $advisorExit=$LASTEXITCODE
 [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');target=('owned loopback '+$database);advisorsExitCode=$advisorExit;lintStatus='NOT_RUN_PLPGSQL_CHECK_UNAVAILABLE_NO_INSTALL';plpgsqlCheckAvailable=[int]$available;installedAnything=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-receipt.json') -Encoding utf8
 Write-Output 'ACTUAL_TWO_KIND_FRESHNESS_CONCURRENT_DISCARD_PASS'
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'export-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'export-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
