const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../../probpera-literary-map');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const read=(name,root=__dirname)=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8').replace(/^\uFEFF/,''));
const manifest=read('source-manifest.json'),functions=read('native-functions.json'),metadata=read('native-metadata.json'),cases=read('native-case-results.json'),concurrent=read('concurrent-receipts.json');
const sources=new Map();function visit(m){for(const s of m.sources||[])sources.set(s.file,s);if(m.foundation)visit(m.foundation);}visit(manifest);
for(const s of sources.values())assert.equal(sha(fs.readFileSync(path.join(repo,s.file))),s.sha256,'Source drift '+s.file);
const oldCatalog=read('native-functions.json',path.resolve(__dirname,'../catalog-operation-sql-native'));
const oldWriter=read('native-functions.json',path.resolve(__dirname,'../writer-operation-sql-native'));
const oldBodies=new Map();for(const f of [...oldWriter,...oldCatalog])oldBodies.set(f.name,f);
const norm=v=>v.replace(/\r\n?/g,'\n');
const preserved=[];
for(const [name,old]of oldBodies){const now=functions.find(f=>f.name===name);assert.ok(now,'Missing old function '+name);assert.equal(norm(now.source),norm(old.source),'Old body drift '+name);assert.equal(now.securityDefiner,old.securityDefiner);assert.deepEqual(now.config,old.config);preserved.push({name,bodySha256:sha(old.source)});}
const migrationName='supabase/migrations/20261029230111_catalog_translation_candidate_freshness.sql';
const fixtureName='scripts/database/fixtures/catalog-translation-candidate-freshness.sql';
const migration=fs.readFileSync(path.join(repo,migrationName),'utf8');
const own=functions.find(f=>f.name.startsWith('get_catalog_translation_candidate_freshness('));assert.ok(own);
const start=migration.indexOf('as $$')+5,end=migration.indexOf('$$;',start);assert.equal(norm(migration.slice(start,end)),norm(own.source));
assert.equal(own.securityDefiner,true);assert.ok(own.config.includes('search_path=""')&&own.config.includes('TimeZone=UTC'));
const keys=['version','entityType','entityId','draftId','draftVersion','candidateHash','sourceHash','linked','canPromote','reason'].sort();
function check(v){assert.deepEqual(Object.keys(v).sort(),keys);assert.equal(v.version,1);assert.ok(['literary_work','country'].includes(v.entityType));assert.equal(v.canPromote,v.reason===null);assert.ok([null,'candidate_missing','candidate_changed','source_changed'].includes(v.reason));assert.equal(typeof v.linked,'boolean');assert.match(v.candidateHash,/^[a-f0-9]{64}$/);assert.match(v.sourceHash,/^[a-f0-9]{64}$/);}
Object.values(metadata).forEach(check);
for(const c of concurrent){check(c.readSession.receipt);check(c.consumedMetadata);assert.equal(c.actualBlockedOnDatabaseLock,true);assert.equal(c.canonicalJournalCacheExact,true);assert.equal(c.newProviderCalls,0);assert.equal(c.readSession.exitCode,0);assert.equal(c.discardSession.exitCode,0);}
const requests=read('native-requests.json'),allMetadata={...metadata};
for(const c of concurrent){allMetadata['concurrent-read-'+c.entityType]=c.readSession.receipt;allMetadata['concurrent-consumed-'+c.entityType]=c.consumedMetadata;}
assert.deepEqual(Object.keys(requests).sort(),Object.keys(allMetadata).sort());
for(const [label,v]of Object.entries(allMetadata)){
 const r=requests[label];assert.deepEqual(Object.keys(r).sort(),['p_entity_type','p_entity_id','p_draft_id','p_expected_version','p_candidate_hash','p_source_hash','p_catalog_source_hash','p_catalog_source_fields'].sort());
 assert.equal(r.p_entity_type,v.entityType);assert.equal(r.p_entity_id,v.entityId);assert.equal(r.p_draft_id,v.draftId);assert.equal(r.p_expected_version,v.draftVersion);assert.equal(r.p_candidate_hash,v.candidateHash);assert.equal(r.p_source_hash,v.sourceHash);
 if(v.entityType==='literary_work'){assert.equal(r.p_catalog_source_hash,null);assert.equal(r.p_catalog_source_fields,null);}
 else{assert.equal(r.p_catalog_source_hash,'b'.repeat(64));assert.equal(typeof r.p_catalog_source_fields,'object');assert.equal(r.p_catalog_source_fields.rights.catalog,label==='linked-country-catalog-timestamp-exact'?'NEW RAW CATALOG TERMS':'KEEP RAW CATALOG RIGHTS');}
}
const parseAdvisor=root=>JSON.parse(fs.readFileSync(path.join(root,'security-advisors.log'),'utf8').replace(/^\uFEFF/,'').split(/\r?\n/).find(v=>v.startsWith('{')));
const advisors=parseAdvisor(__dirname),oldAdvisors=parseAdvisor(path.resolve(__dirname,'../catalog-operation-sql-native'));
const oldAdvisorKeys=new Set(oldAdvisors.results.map(x=>x.cacheKey));const newFindings=advisors.results.filter(x=>!oldAdvisorKeys.has(x.cacheKey));assert.deepEqual(newFindings,[]);
const beforeNames=['next-catalog-review-full-seed-before.zip','next-catalog-country-review-full-seed-before.zip'];
const before=beforeNames.map(name=>({file:'docs/admin-r3-evidence/2026-10-30-catalog-admission/'+name,sha256:sha(fs.readFileSync(path.join(repo,'docs/admin-r3-evidence/2026-10-30-catalog-admission',name)))}));
assert.ok(before[0].sha256.startsWith('f45180'));assert.equal(before[1].sha256,'2c7588bdc02a5cec9c1e8c1088a1b2b50386d2882df209b4cd0436fca438871a');
const cleanup=[read('new-cleanup.json'),read('export-cleanup.json'),read('request-export-cleanup.json')];for(const c of cleanup){assert.equal(c.pgCtlExitCode,0);assert.equal(c.processRemains,false);assert.equal(c.pidFileRemains,false);assert.equal(c.serviceCreated,false);}
const summary={atUtc:new Date().toISOString(),mode:'Isolated actual native SQL CURRENT; synthetic data/Auth only; no provider/managed/production call',database:'catalog_freshness_v3_20261030',maintainedFixtureExitCode:0,
 migration:{file:migrationName,sha256:sha(migration),bytes:Buffer.byteLength(migration)},fixture:{file:fixtureName,sha256:sha(fs.readFileSync(path.join(repo,fixtureName)))},
 exactOldFunctionBodiesAndConfig:preserved,ownNativeFunction:{name:own.name,sourceSha256:sha(own.source),bodySourceBound:true,securityDefiner:own.securityDefiner,config:own.config},
 resultGroups:Object.keys(cases),resultGroupCount:Object.keys(cases).length,metadataGoldenCount:Object.keys(metadata).length,concurrentMetadataCount:concurrent.length*2,exactRequestGoldenCount:Object.keys(requests).length,
 concurrent,sourceInputCount:sources.size,sourceInputs:[...sources.values()],frozenBeforeArchivesUnchanged:before,
 advisors:{...read('advisors-lint-receipt.json'),findingCount:advisors.results.length,newFindingCount:newFindings.length,findings:advisors.results.map(v=>({name:v.name,level:v.level,object:v.metadata?.schema+'.'+v.metadata?.name}))},cleanup,
 boundaries:[
 'The response is a snapshot additional gate; existing human confirmation and atomic promotion remain mandatory. Source changes after preflight still fail atomic approval.',
 'Concrete unlinked legacy is passthrough for this additional gate only, with exact textual book identity/case preserved; it does not acquire full-seed validation.',
 'Only guard40001 becomes source_changed; 42501 and XX000 propagate. Fault replacements occur only in rolled-back synthetic subtransactions and old routine bytes are restored/exact.',
 'Native current/shared-staff reads preserve full journal/calls/cache/draft fingerprints, audit/outbox counts; real reader/discard sessions preserve canonical/journal/cache while explicit discard consumes the candidate.',
 'No raw body/source/provenance/provider information appears in strict RPC metadata. Other staff still cannot read actor-owned private response artifacts.',
 'Initial v1 timestamp fixture failed because inherited synthetic bootstrap used clock_timestamp; v2/v3 replay exact existing canonical now() function before freshness-only tests. All old source files unchanged.',
 'First export-only attempt hit Windows psql argv encoding with synthetic Russian JSON; corrected to exact UTF8 files. Server logs/cleanup/observed transcript retained; maintained source unchanged.',
 'Advisors exit1 is inherited synthetic-fixture findings, not PASS; no new finding. plpgsql_check unavailable, lint NOT RUN, nothing installed.',
 'This archive is native CURRENT proof only; root acceptance archive owns immutable BEFORE/SAME SSR+SDK proof and broad/gates. Full R3/partial-pass recovery/operator retry remain outside this increment.'
 ]};
fs.writeFileSync(path.join(__dirname,'native-summary.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify({groups:summary.resultGroupCount,metadata:Object.keys(metadata).length,concurrentMetadata:summary.concurrentMetadataCount,oldFunctionsExact:preserved.length,sources:sources.size,newAdvisorFindings:newFindings.length,migration:summary.migration,fixture:summary.fixture}));
