const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),prior=path.resolve(__dirname,'../catalog-operation-sql-native');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
if(fs.existsSync(path.join(__dirname,'new-run.log'))){
 const old=JSON.parse(fs.readFileSync(path.join(__dirname,'source-manifest.json'),'utf8'));
 const saved=path.join(__dirname,'history',old.fixtureSha256.slice(0,16));fs.mkdirSync(saved,{recursive:true});
 for(const name of ['fixture.sql','source-manifest.json','new-run.log','new-cleanup.json','new-cleanup.log','postgres-new.log'])
  if(fs.existsSync(path.join(__dirname,name))&&!fs.existsSync(path.join(saved,name)))fs.copyFileSync(path.join(__dirname,name),path.join(saved,name));
}
const foundationManifest=JSON.parse(fs.readFileSync(path.join(prior,'source-manifest.json'),'utf8'));
function validate(m){for(const s of m.sources||[])if(sha(fs.readFileSync(path.join(repo,s.file)))!==s.sha256)throw Error('Old source drift: '+s.file);if(m.foundation)validate(m.foundation);}
validate(foundationManifest);
const foundation=fs.readFileSync(path.join(prior,'fixture.sql'));if(sha(foundation)!==foundationManifest.fixtureSha256)throw Error('Catalog foundation fixture drift');
const sources=[];
const read=file=>{const b=fs.readFileSync(path.join(repo,file)),target=path.join(__dirname,'sources',file);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,b);sources.push({file,sha256:sha(b),bytes:b.length});return b.toString('utf8');};
// The old synthetic bootstrap used clock_timestamp(). Replay the EXACT real
// canonical function before freshness timestamp controls; do not disable any
// triggers or copy its behavior into a hand-written fixture replacement.
const cms=read('supabase/migrations/20260728_cms_foundation.sql');
const canonicalUpdatedAt=cms.match(/create or replace function public\.set_updated_at\(\)\r?\nreturns trigger[\s\S]*?\r?\n\$\$;/)?.[0];
if(!canonicalUpdatedAt)throw Error('Cannot extract actual canonical set_updated_at');
const sql=[foundation.toString('utf8'),canonicalUpdatedAt,read('supabase/migrations/20261029230111_catalog_translation_candidate_freshness.sql'),read('scripts/database/fixtures/catalog-translation-candidate-freshness.sql')].join('\n');
fs.writeFileSync(path.join(__dirname,'fixture.sql'),sql);
fs.writeFileSync(path.join(__dirname,'source-manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),sources,foundation:foundationManifest,foundationSha256:sha(foundation),fixtureSha256:sha(sql)},null,2));
const database=process.argv[2];if(!/^catalog_freshness_v\d+_20261030$/.test(database||''))throw Error('Explicit new isolated database required');
const runner=fs.readFileSync(path.join(prior,'run-probe.ps1'),'utf8').replaceAll('catalog-operation-sql-native','catalog-freshness-sql-native').replaceAll('catalog_operations_v8_20261030',database);
fs.writeFileSync(path.join(__dirname,'run-probe.ps1'),runner);
console.log(JSON.stringify({database,fixtureSha256:sha(sql),sources}));
