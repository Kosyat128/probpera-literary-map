\set ON_ERROR_STOP on
\pset tuples_only on
\pset format unaligned

create schema auth;
grant usage on schema auth to authenticated;

create table auth.users (id uuid primary key);

create or replace function auth.uid()
returns uuid
language sql
stable
set search_path = ''
as $$
  select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
$$;
grant execute on function auth.uid() to authenticated;

create type public.staff_role as enum ('owner', 'admin', 'editor');
create type public.article_status as enum (
  'draft', 'review', 'scheduled', 'published', 'hidden', 'archived'
);
create type public.article_translation_status as enum (
  'draft', 'review', 'approved', 'published', 'stale', 'archived'
);

create table public.staff_memberships (
  user_id uuid primary key references auth.users(id),
  role public.staff_role not null
);
create or replace function public.is_staff(
  allowed_roles public.staff_role[] default array[
    'owner'::public.staff_role,
    'admin'::public.staff_role,
    'editor'::public.staff_role
  ]
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.staff_memberships
    where user_id = (select auth.uid()) and role = any(allowed_roles)
  );
$$;
revoke all on function public.is_staff(public.staff_role[]) from public;
grant execute on function public.is_staff(public.staff_role[]) to authenticated;

create table public.categories (
  id uuid primary key,
  slug text not null unique
);

create table public.articles (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  title text not null check (char_length(title) between 3 and 240),
  subtitle text not null default '',
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  cover_external_url text,
  cover_alt text not null default '',
  category_id uuid references public.categories(id),
  status public.article_status not null default 'draft',
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,179}$'),
  legacy_path text unique,
  published_at timestamptz,
  scheduled_at timestamptz,
  featured boolean not null default false,
  show_on_homepage boolean not null default false,
  pinned boolean not null default false,
  sources jsonb not null default '[]'::jsonb,
  bibliography jsonb not null default '[]'::jsonb,
  seo_title text,
  seo_description text,
  seo_keywords text[] not null default '{}',
  canonical_url text,
  og_title text,
  og_description text,
  allow_indexing boolean not null default true,
  created_by uuid not null references auth.users(id),
  updated_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  check (status <> 'scheduled' or scheduled_at is not null),
  check (status <> 'published' or published_at is not null)
);

create table public.article_revisions (
  id bigint generated always as identity primary key,
  article_id uuid not null references public.articles(id) on delete cascade,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid,
  created_at timestamptz not null default now(),
  unique(article_id, revision_number)
);

create table public.article_translations (
  id uuid primary key default gen_random_uuid(),
  article_id uuid not null references public.articles(id) on delete cascade,
  locale text not null,
  title text not null check (char_length(title) between 3 and 240),
  subtitle text not null default '',
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  cover_alt text not null default '',
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{1,179}$'),
  sources jsonb not null default '[]'::jsonb,
  bibliography jsonb not null default '[]'::jsonb,
  seo_title text,
  seo_description text,
  seo_keywords text[] not null default '{}',
  canonical_url text,
  og_title text,
  og_description text,
  status public.article_translation_status not null default 'draft',
  source_content_hash text,
  source_article_updated_at timestamptz,
  reviewed_by uuid,
  reviewed_at timestamptz,
  approved_by uuid,
  approved_at timestamptz,
  published_at timestamptz,
  created_by uuid not null references auth.users(id),
  updated_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique(article_id, locale),
  unique(locale, slug),
  check (status not in ('approved', 'published') or approved_at is not null),
  check (status <> 'published' or published_at is not null)
);

create table public.article_translation_revisions (
  id bigint generated always as identity primary key,
  article_translation_id uuid not null references public.article_translations(id),
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid,
  created_at timestamptz not null default now(),
  unique(article_translation_id, revision_number)
);

create table public.redirects (
  id uuid primary key default gen_random_uuid(),
  source_path text not null unique,
  destination_path text not null,
  status_code smallint not null default 301,
  is_active boolean not null default true,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.admin_audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid,
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create table public.public_build_outbox (
  id bigint generated always as identity primary key,
  actor_id uuid,
  entity_type text not null,
  entity_id text not null,
  reason text not null,
  status text not null default 'requested',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = clock_timestamp(); return new; end;
$$;
create trigger articles_set_updated_at before update on public.articles
for each row execute function public.set_updated_at();
create trigger article_translations_set_updated_at before update on public.article_translations
for each row execute function public.set_updated_at();
create trigger redirects_set_updated_at before update on public.redirects
for each row execute function public.set_updated_at();

create or replace function public.capture_article_revision()
returns trigger language plpgsql security definer set search_path = '' as $$
declare n integer;
begin
  if old is not distinct from new then return new; end if;
  select coalesce(max(revision_number), 0) + 1 into n
  from public.article_revisions where article_id = old.id;
  insert into public.article_revisions(article_id, revision_number, snapshot, changed_by)
  values(old.id, n, to_jsonb(old), coalesce(new.updated_by, (select auth.uid())));
  return new;
end;
$$;
create trigger articles_capture_revision before update on public.articles
for each row execute function public.capture_article_revision();

create or replace function public.capture_article_translation_revision()
returns trigger language plpgsql security definer set search_path = '' as $$
declare n integer;
begin
  if old is not distinct from new then return new; end if;
  select coalesce(max(revision_number), 0) + 1 into n
  from public.article_translation_revisions
  where article_translation_id = old.id;
  insert into public.article_translation_revisions(
    article_translation_id, revision_number, snapshot, changed_by
  ) values(old.id, n, to_jsonb(old), coalesce(new.updated_by, (select auth.uid())));
  return new;
end;
$$;
create trigger article_translations_capture_revision
before update on public.article_translations
for each row execute function public.capture_article_translation_revision();

-- Mimic the important production behavior: changing the Russian source can
-- stale a released English translation before the explicit English save runs.
create or replace function public.fixture_sync_english_after_article()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'UPDATE' and old.title is distinct from new.title then
    update public.article_translations
    set status = 'stale', approved_by = null, approved_at = null,
        published_at = null, updated_by = new.updated_by
    where article_id = new.id and locale = 'en'
      and status in ('approved', 'published');
  end if;
  return new;
end;
$$;
create trigger articles_fixture_sync_english
after update on public.articles
for each row execute function public.fixture_sync_english_after_article();

create or replace function public.fixture_capture_outbox()
returns trigger language plpgsql security definer set search_path = '' as $$
declare row_data jsonb;
begin
  row_data := case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end;
  insert into public.public_build_outbox(actor_id, entity_type, entity_id, reason, metadata)
  values((select auth.uid()), tg_table_name,
    coalesce(row_data ->> 'id', row_data ->> 'article_id', tg_table_name),
    'database-' || lower(tg_op),
    jsonb_build_object('operation', lower(tg_op), 'table', tg_table_name));
  return case when tg_op = 'DELETE' then old else new end;
end;
$$;
create trigger articles_public_build_outbox after insert or update or delete on public.articles
for each row execute function public.fixture_capture_outbox();
create trigger article_translations_public_build_outbox after insert or update or delete on public.article_translations
for each row execute function public.fixture_capture_outbox();
create trigger redirects_public_build_outbox after insert or update or delete on public.redirects
for each row execute function public.fixture_capture_outbox();

alter table public.articles enable row level security;
alter table public.article_translations enable row level security;
alter table public.redirects enable row level security;
alter table public.admin_audit_log enable row level security;
grant usage on schema public to authenticated;
grant select, insert, update, delete on public.articles to authenticated;
grant select, insert, update, delete on public.article_translations to authenticated;
grant select, insert, update on public.redirects to authenticated;
grant select, insert on public.admin_audit_log to authenticated;
-- These are assertion-only reads in this isolated integration fixture. The
-- production privilege model remains unchanged.
grant select on public.article_revisions to authenticated;
grant select on public.article_translation_revisions to authenticated;
grant select on public.public_build_outbox to authenticated;
grant usage, select on all sequences in schema public to authenticated;

create policy "Staff read articles" on public.articles for select to authenticated
using (public.is_staff());
create policy "Staff create articles" on public.articles for insert to authenticated
with check (public.is_staff() and created_by = (select auth.uid()) and updated_by = (select auth.uid()));
create policy "Staff update articles" on public.articles for update to authenticated
using (public.is_staff()) with check (public.is_staff() and updated_by = (select auth.uid()));
create policy "Staff read article translations" on public.article_translations for select to authenticated
using (public.is_staff());
create policy "Staff create article translations" on public.article_translations for insert to authenticated
with check (public.is_staff() and created_by = (select auth.uid()) and updated_by = (select auth.uid()));
create policy "Staff update article translations" on public.article_translations for update to authenticated
using (public.is_staff()) with check (public.is_staff() and updated_by = (select auth.uid()));
create policy "Staff manage redirects" on public.redirects for all to authenticated
using (public.is_staff()) with check (public.is_staff() and created_by = (select auth.uid()));
create policy "Staff append audit log" on public.admin_audit_log for insert to authenticated
with check (public.is_staff() and actor_id = (select auth.uid()));

-- The migration's schema-health function expects these names to exist or be
-- safely probeable. Only public_build_outbox is referenced as a real relation.
create or replace function public.enqueue_public_build_request(text,text,text,jsonb)
returns bigint language sql as $$ select 1::bigint $$;
create or replace function public.move_homepage_block(uuid,text)
returns boolean language sql as $$ select true $$;


create type public.page_status as enum ('draft','published','hidden');
create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 2 and 180),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,119}$'),
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  status public.page_status not null default 'draft',
  seo_title text,
  seo_description text,
  canonical_url text,
  allow_indexing boolean not null default true,
  created_by uuid not null references auth.users(id) on delete restrict,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.page_revisions (
  id bigint generated always as identity primary key,
  page_id uuid not null references public.pages(id) on delete cascade,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (page_id, revision_number)
);

alter table public.pages enable row level security;
alter table public.page_revisions enable row level security;
create policy "Public read published pages"
on public.pages for select
to anon, authenticated
using (
  (status = 'published' and deleted_at is null)
);

create policy "Staff manage pages"
on public.pages for all
to authenticated
using (public.is_staff())
with check (
  public.is_staff()
  and created_by is not null
  and updated_by = (select auth.uid())
);

create policy "Staff read page revisions"
on public.page_revisions for select
to authenticated
using (public.is_staff());


grant select, insert, update, delete on public.pages to authenticated;
grant select on public.page_revisions to authenticated;
create or replace function public.fixture_page_set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
create trigger pages_set_updated_at before update on public.pages
for each row execute function public.fixture_page_set_updated_at();
-- Version history for permanent CMS pages.
-- Article revisions were part of the initial CMS migration; pages use the
-- same immutable-snapshot model so every editorial change is recoverable.

create or replace function public.capture_page_revision()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_revision integer;
begin
  if old is not distinct from new then
    return new;
  end if;

  select coalesce(max(revision_number), 0) + 1
  into next_revision
  from public.page_revisions
  where page_id = old.id;

  insert into public.page_revisions (
    page_id,
    revision_number,
    snapshot,
    changed_by
  )
  values (
    old.id,
    next_revision,
    to_jsonb(old),
    coalesce(new.updated_by, (select auth.uid()))
  );

  return new;
end;
$$;

drop trigger if exists pages_capture_revision on public.pages;
create trigger pages_capture_revision
  before update on public.pages
  for each row execute function public.capture_page_revision();

create index if not exists page_revisions_page_idx
  on public.page_revisions(page_id, revision_number desc);

create trigger pages_public_build_outbox after insert or update or delete on public.pages
for each row execute function public.fixture_capture_outbox();
create or replace function public.capture_public_build_outbox()
returns trigger language plpgsql security definer set search_path = '' as $$
begin return case when tg_op = 'DELETE' then old else new end; end;
$$;
-- Save the canonical Russian article row and its optional English translation in
-- one PostgreSQL transaction. Existing revision and public-build outbox triggers
-- remain authoritative and therefore commit or roll back with this function.
--
-- The function is deliberately SECURITY INVOKER: authenticated staff keep the
-- existing RLS checks and no privileged service-role path is introduced.

create or replace function public.save_article_bundle(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz,
  p_article_payload jsonb,
  p_english_mode text default 'none',
  p_english_payload jsonb default null,
  p_expected_english_updated_at timestamptz default null,
  p_redirect_source_path text default null,
  p_redirect_destination_path text default null,
  p_replace_homepage boolean default false,
  p_audit_action text default null,
  p_audit_metadata jsonb default '{}'::jsonb,
  p_social_publish_requested boolean default false,
  p_social_metadata jsonb default '{}'::jsonb
)
returns table (
  article_id uuid,
  article_updated_at timestamptz,
  english_updated_at timestamptz,
  homepage_replaced integer
)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  current_article public.articles%rowtype;
  current_english public.article_translations%rowtype;
  saved_article public.articles%rowtype;
  saved_english public.article_translations%rowtype;
  has_article boolean := false;
  has_english boolean := false;
  article_keywords text[];
  english_keywords text[];
  replaced_count integer := 0;
  effective_audit_action text;
begin
  if actor_id is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;

  if p_article_payload is null
    or jsonb_typeof(p_article_payload) <> 'object' then
    raise exception using errcode = '22023', message = 'ARTICLE_PAYLOAD_REQUIRED';
  end if;

  if p_english_mode not in ('none', 'save', 'stale') then
    raise exception using errcode = '22023', message = 'INVALID_ENGLISH_MODE';
  end if;

  if p_english_mode = 'save'
    and (p_english_payload is null or jsonb_typeof(p_english_payload) <> 'object') then
    raise exception using errcode = '22023', message = 'ENGLISH_PAYLOAD_REQUIRED';
  end if;

  article_keywords := coalesce(
    array(
      select jsonb_array_elements_text(
        coalesce(p_article_payload -> 'seo_keywords', '[]'::jsonb)
      )
    ),
    '{}'::text[]
  );

  if p_english_mode = 'save' then
    english_keywords := coalesce(
      array(
        select jsonb_array_elements_text(
          coalesce(p_english_payload -> 'seo_keywords', '[]'::jsonb)
        )
      ),
      '{}'::text[]
    );
  end if;

  -- Lock and validate both rows before the article UPDATE. Updating an article
  -- can legitimately mark a released English translation stale through the
  -- existing sync trigger, which also changes its updated_at. Checking the
  -- English timestamp after that trigger would create a false conflict.
  if p_article_id is not null then
    select *
    into current_article
    from public.articles
    where id = p_article_id
    for update;
    has_article := found;

    if not has_article then
      raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
    end if;

    if p_expected_article_updated_at is null
      or current_article.updated_at is distinct from p_expected_article_updated_at then
      raise exception using errcode = 'P0001', message = 'ARTICLE_CONFLICT';
    end if;

    if p_english_mode in ('save', 'stale') then
      select english_translation.*
      into current_english
      from public.article_translations as english_translation
      where english_translation.article_id = p_article_id
        and english_translation.locale = 'en'
      for update;
      has_english := found;

      if has_english then
        if p_expected_english_updated_at is null
          or current_english.updated_at is distinct from p_expected_english_updated_at then
          raise exception using errcode = 'P0001', message = 'ENGLISH_CONFLICT';
        end if;
      elsif p_expected_english_updated_at is not null then
        raise exception using errcode = 'P0001', message = 'ENGLISH_CONFLICT';
      end if;
    end if;

    update public.articles
    set
      title = p_article_payload ->> 'title',
      subtitle = coalesce(p_article_payload ->> 'subtitle', ''),
      excerpt = coalesce(p_article_payload ->> 'excerpt', ''),
      slug = p_article_payload ->> 'slug',
      content_html = coalesce(p_article_payload ->> 'content_html', ''),
      content_json = coalesce(
        p_article_payload -> 'content_json',
        '{"type":"doc","content":[]}'::jsonb
      ),
      category_id = nullif(p_article_payload ->> 'category_id', '')::uuid,
      status = (p_article_payload ->> 'status')::public.article_status,
      scheduled_at = nullif(p_article_payload ->> 'scheduled_at', '')::timestamptz,
      published_at = nullif(p_article_payload ->> 'published_at', '')::timestamptz,
      cover_external_url = nullif(p_article_payload ->> 'cover_external_url', ''),
      cover_alt = coalesce(p_article_payload ->> 'cover_alt', ''),
      legacy_path = nullif(p_article_payload ->> 'legacy_path', ''),
      seo_title = nullif(p_article_payload ->> 'seo_title', ''),
      seo_description = nullif(p_article_payload ->> 'seo_description', ''),
      seo_keywords = article_keywords,
      canonical_url = nullif(p_article_payload ->> 'canonical_url', ''),
      og_title = nullif(p_article_payload ->> 'og_title', ''),
      og_description = nullif(p_article_payload ->> 'og_description', ''),
      allow_indexing = coalesce((p_article_payload ->> 'allow_indexing')::boolean, true),
      sources = coalesce(p_article_payload -> 'sources', '[]'::jsonb),
      bibliography = coalesce(p_article_payload -> 'bibliography', '[]'::jsonb),
      featured = coalesce((p_article_payload ->> 'featured')::boolean, false),
      show_on_homepage = coalesce(
        (p_article_payload ->> 'show_on_homepage')::boolean,
        false
      ),
      pinned = coalesce((p_article_payload ->> 'pinned')::boolean, false),
      updated_by = actor_id
    where id = p_article_id
    returning * into saved_article;
  else
    if p_expected_article_updated_at is not null then
      raise exception using errcode = 'P0001', message = 'ARTICLE_CONFLICT';
    end if;

    insert into public.articles (
      title,
      subtitle,
      excerpt,
      slug,
      content_html,
      content_json,
      category_id,
      status,
      scheduled_at,
      published_at,
      cover_external_url,
      cover_alt,
      legacy_path,
      seo_title,
      seo_description,
      seo_keywords,
      canonical_url,
      og_title,
      og_description,
      allow_indexing,
      sources,
      bibliography,
      featured,
      show_on_homepage,
      pinned,
      created_by,
      updated_by
    ) values (
      p_article_payload ->> 'title',
      coalesce(p_article_payload ->> 'subtitle', ''),
      coalesce(p_article_payload ->> 'excerpt', ''),
      p_article_payload ->> 'slug',
      coalesce(p_article_payload ->> 'content_html', ''),
      coalesce(
        p_article_payload -> 'content_json',
        '{"type":"doc","content":[]}'::jsonb
      ),
      nullif(p_article_payload ->> 'category_id', '')::uuid,
      (p_article_payload ->> 'status')::public.article_status,
      nullif(p_article_payload ->> 'scheduled_at', '')::timestamptz,
      nullif(p_article_payload ->> 'published_at', '')::timestamptz,
      nullif(p_article_payload ->> 'cover_external_url', ''),
      coalesce(p_article_payload ->> 'cover_alt', ''),
      nullif(p_article_payload ->> 'legacy_path', ''),
      nullif(p_article_payload ->> 'seo_title', ''),
      nullif(p_article_payload ->> 'seo_description', ''),
      article_keywords,
      nullif(p_article_payload ->> 'canonical_url', ''),
      nullif(p_article_payload ->> 'og_title', ''),
      nullif(p_article_payload ->> 'og_description', ''),
      coalesce((p_article_payload ->> 'allow_indexing')::boolean, true),
      coalesce(p_article_payload -> 'sources', '[]'::jsonb),
      coalesce(p_article_payload -> 'bibliography', '[]'::jsonb),
      coalesce((p_article_payload ->> 'featured')::boolean, false),
      coalesce((p_article_payload ->> 'show_on_homepage')::boolean, false),
      coalesce((p_article_payload ->> 'pinned')::boolean, false),
      actor_id,
      actor_id
    )
    returning * into saved_article;
  end if;

  if p_english_mode = 'save' then
    if has_english then
      update public.article_translations
      set
        title = p_english_payload ->> 'title',
        subtitle = coalesce(p_english_payload ->> 'subtitle', ''),
        excerpt = coalesce(p_english_payload ->> 'excerpt', ''),
        content_json = coalesce(
          p_english_payload -> 'content_json',
          '{"type":"doc","content":[]}'::jsonb
        ),
        content_html = coalesce(p_english_payload ->> 'content_html', ''),
        cover_alt = coalesce(p_english_payload ->> 'cover_alt', ''),
        slug = p_english_payload ->> 'slug',
        sources = coalesce(p_english_payload -> 'sources', '[]'::jsonb),
        bibliography = coalesce(
          p_english_payload -> 'bibliography',
          '[]'::jsonb
        ),
        seo_title = nullif(p_english_payload ->> 'seo_title', ''),
        seo_description = nullif(p_english_payload ->> 'seo_description', ''),
        seo_keywords = english_keywords,
        canonical_url = nullif(p_english_payload ->> 'canonical_url', ''),
        og_title = nullif(p_english_payload ->> 'og_title', ''),
        og_description = nullif(p_english_payload ->> 'og_description', ''),
        status = (p_english_payload ->> 'status')::public.article_translation_status,
        source_content_hash = nullif(
          p_english_payload ->> 'source_content_hash',
          ''
        ),
        source_article_updated_at = saved_article.updated_at,
        reviewed_by = case
          when nullif(p_english_payload ->> 'reviewed_at', '') is null
            then null
          else actor_id
        end,
        reviewed_at = nullif(p_english_payload ->> 'reviewed_at', '')::timestamptz,
        approved_by = case
          when nullif(p_english_payload ->> 'approved_at', '') is null
            then null
          else actor_id
        end,
        approved_at = nullif(p_english_payload ->> 'approved_at', '')::timestamptz,
        published_at = nullif(p_english_payload ->> 'published_at', '')::timestamptz,
        updated_by = actor_id,
        deleted_at = nullif(p_english_payload ->> 'deleted_at', '')::timestamptz
      where id = current_english.id
      returning * into saved_english;
    else
      insert into public.article_translations (
        article_id,
        locale,
        title,
        subtitle,
        excerpt,
        content_json,
        content_html,
        cover_alt,
        slug,
        sources,
        bibliography,
        seo_title,
        seo_description,
        seo_keywords,
        canonical_url,
        og_title,
        og_description,
        status,
        source_content_hash,
        source_article_updated_at,
        reviewed_by,
        reviewed_at,
        approved_by,
        approved_at,
        published_at,
        created_by,
        updated_by,
        deleted_at
      ) values (
        saved_article.id,
        'en',
        p_english_payload ->> 'title',
        coalesce(p_english_payload ->> 'subtitle', ''),
        coalesce(p_english_payload ->> 'excerpt', ''),
        coalesce(
          p_english_payload -> 'content_json',
          '{"type":"doc","content":[]}'::jsonb
        ),
        coalesce(p_english_payload ->> 'content_html', ''),
        coalesce(p_english_payload ->> 'cover_alt', ''),
        p_english_payload ->> 'slug',
        coalesce(p_english_payload -> 'sources', '[]'::jsonb),
        coalesce(p_english_payload -> 'bibliography', '[]'::jsonb),
        nullif(p_english_payload ->> 'seo_title', ''),
        nullif(p_english_payload ->> 'seo_description', ''),
        english_keywords,
        nullif(p_english_payload ->> 'canonical_url', ''),
        nullif(p_english_payload ->> 'og_title', ''),
        nullif(p_english_payload ->> 'og_description', ''),
        (p_english_payload ->> 'status')::public.article_translation_status,
        nullif(p_english_payload ->> 'source_content_hash', ''),
        saved_article.updated_at,
        case
          when nullif(p_english_payload ->> 'reviewed_at', '') is null
            then null
          else actor_id
        end,
        nullif(p_english_payload ->> 'reviewed_at', '')::timestamptz,
        case
          when nullif(p_english_payload ->> 'approved_at', '') is null
            then null
          else actor_id
        end,
        nullif(p_english_payload ->> 'approved_at', '')::timestamptz,
        nullif(p_english_payload ->> 'published_at', '')::timestamptz,
        actor_id,
        actor_id,
        nullif(p_english_payload ->> 'deleted_at', '')::timestamptz
      )
      returning * into saved_english;
    end if;
  elsif p_english_mode = 'stale' and has_english then
    update public.article_translations
    set
      status = 'stale',
      approved_by = null,
      approved_at = null,
      published_at = null,
      updated_by = actor_id
    where id = current_english.id
    returning * into saved_english;
  end if;

  if nullif(trim(coalesce(p_redirect_source_path, '')), '') is not null
    and nullif(trim(coalesce(p_redirect_destination_path, '')), '') is not null
    and p_redirect_source_path is distinct from p_redirect_destination_path then
    insert into public.redirects (
      source_path,
      destination_path,
      status_code,
      is_active,
      created_by
    ) values (
      p_redirect_source_path,
      p_redirect_destination_path,
      301,
      true,
      actor_id
    )
    on conflict (source_path) do update set
      destination_path = excluded.destination_path,
      status_code = 301,
      is_active = true,
      created_by = actor_id;
  end if;

  if p_replace_homepage
    and saved_article.status = 'published'
    and saved_article.show_on_homepage
    and saved_article.category_id is not null then
    update public.articles
    set
      show_on_homepage = false,
      updated_by = actor_id
    where category_id = saved_article.category_id
      and status = 'published'
      and show_on_homepage
      and id <> saved_article.id;
    get diagnostics replaced_count = row_count;
  end if;

  effective_audit_action := coalesce(
    nullif(trim(coalesce(p_audit_action, '')), ''),
    case when p_article_id is null then 'article.created' else 'article.updated' end
  );

  insert into public.admin_audit_log (
    actor_id,
    action,
    entity_type,
    entity_id,
    metadata
  ) values (
    actor_id,
    effective_audit_action,
    'article',
    saved_article.id::text,
    coalesce(p_audit_metadata, '{}'::jsonb)
  );

  if p_social_publish_requested then
    insert into public.admin_audit_log (
      actor_id,
      action,
      entity_type,
      entity_id,
      metadata
    ) values (
      actor_id,
      'social_publish.requested',
      'article',
      saved_article.id::text,
      coalesce(p_social_metadata, '{}'::jsonb)
    );
  end if;

  return query
  select
    saved_article.id,
    saved_article.updated_at,
    case
      when p_english_mode in ('save', 'stale') and saved_english.id is not null
        then saved_english.updated_at
      else null
    end,
    replaced_count;
end;
$$;

revoke all on function public.save_article_bundle(
  uuid,
  timestamptz,
  jsonb,
  text,
  jsonb,
  timestamptz,
  text,
  text,
  boolean,
  text,
  jsonb,
  boolean,
  jsonb
) from public;
grant execute on function public.save_article_bundle(
  uuid,
  timestamptz,
  jsonb,
  text,
  jsonb,
  timestamptz,
  text,
  text,
  boolean,
  text,
  jsonb,
  boolean,
  jsonb
) to authenticated;

-- Keep the staff-only schema health probe synchronized with this canonical RPC.
create or replace function public.get_editorial_schema_health()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when public.is_staff() then jsonb_build_object(
      'version', '20260822_zz_atomic_article_bundle',
      'checkedAt', now(),
      'outbox', to_regclass('public.public_build_outbox') is not null,
      'outboxRpc',
        to_regprocedure(
          'public.enqueue_public_build_request(text,text,text,jsonb)'
        ) is not null,
      'articleBundleRpc',
        to_regprocedure(
          'public.save_article_bundle(uuid,timestamptz,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
        ) is not null,
      'migrationLedger',
        to_regclass('public.probpera_schema_migrations') is not null,
      'publicationTriggers', (
        select count(*) = 21
        from pg_catalog.pg_trigger outbox_trigger
        join pg_catalog.pg_class relation
          on relation.oid = outbox_trigger.tgrelid
        join pg_catalog.pg_namespace namespace
          on namespace.oid = relation.relnamespace
        where namespace.nspname = 'public'
          and not outbox_trigger.tgisinternal
          and outbox_trigger.tgfoid =
            'public.capture_public_build_outbox()'::regprocedure
          and outbox_trigger.tgname =
            (relation.relname::text || '_public_build_outbox')::name
          and relation.relname = any(array[
            'articles',
            'article_tags',
            'article_translations',
            'pages',
            'homepage_blocks',
            'banners',
            'navigation_menus',
            'navigation_items',
            'redirects',
            'categories',
            'tags',
            'media_assets',
            'media_usages',
            'literary_works',
            'literary_work_translations',
            'literary_work_sources',
            'literary_work_external_ids',
            'book_editions',
            'writer_profile_overrides',
            'country_profile_overrides',
            'literary_work_cover_artworks'
          ]::name[])
      ),
      'staffEditorialReadPolicies', (
        select count(*) = 3
        from pg_catalog.pg_policies
        where schemaname = 'public'
          and cmd = 'SELECT'
          and roles = array['authenticated'::name]
          and position('is_staff' in coalesce(qual, '')) > 0
          and (
            (tablename = 'articles' and policyname = 'Staff read articles')
            or (
              tablename = 'article_translations'
              and policyname = 'Staff read article translations'
            )
            or (
              tablename = 'media_assets'
              and policyname = 'Staff read media metadata'
            )
          )
      ),
      'pendingPublicBuilds', (
        select count(*)
        from public.public_build_outbox
        where status in ('requested', 'dispatched', 'failed')
      ),
      'revisionHistory',
        to_regclass('public.admin_revision_history') is not null,
      'workTranslations',
        to_regclass('public.literary_work_translations') is not null,
      'workCoverArtworks',
        to_regclass('public.literary_work_cover_artworks') is not null,
      'countryOverrides',
        to_regclass('public.country_profile_overrides') is not null,
      'writerOverrides',
        to_regclass('public.writer_profile_overrides') is not null,
      'homepageMove',
        to_regprocedure('public.move_homepage_block(uuid,text)') is not null,
      'tagsUpdatedAt', exists (
        select 1
        from information_schema.columns
        where table_schema = 'public'
          and table_name = 'tags'
          and column_name = 'updated_at'
      )
    )
    else null
  end;
$$;

revoke all on function public.get_editorial_schema_health() from public;
grant execute on function public.get_editorial_schema_health()
  to authenticated;

-- Private working copies for editing an already published article without
-- mutating its public row until the normal atomic publication flow succeeds.

create table if not exists public.article_working_drafts (
  article_id uuid primary key
    references public.articles(id) on update cascade on delete cascade,
  base_article_updated_at timestamptz not null,
  payload jsonb not null,
  english_payload jsonb not null,
  expected_english_updated_at timestamptz,
  version bigint not null default 1,
  actor_id uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint article_working_drafts_payload_object_check
    check (jsonb_typeof(payload) = 'object'),
  constraint article_working_drafts_payload_size_check
    check (octet_length(payload::text) <= 5242880),
  constraint article_working_drafts_english_payload_check
    check (
      jsonb_typeof(english_payload) = 'object'
      and octet_length(english_payload::text) <= 5242880
      and (
        english_payload = '{"mode":"disabled"}'::jsonb
        or (
          english_payload ->> 'mode' = 'save'
          and jsonb_typeof(english_payload -> 'payload') = 'object'
        )
      )
    ),
  constraint article_working_drafts_version_check check (version > 0),
  constraint article_working_drafts_timestamp_order_check
    check (updated_at >= created_at)
);

create index if not exists article_working_drafts_updated_idx
  on public.article_working_drafts(updated_at desc, article_id);
create index if not exists article_working_drafts_actor_idx
  on public.article_working_drafts(actor_id, updated_at desc);

alter table public.article_working_drafts enable row level security;
alter table public.article_working_drafts force row level security;
revoke all on table public.article_working_drafts from public, anon, authenticated;
grant select on table public.article_working_drafts to authenticated;
grant all on table public.article_working_drafts to service_role;

-- Editors may prepare drafts and send them to review, but only owners/admins
-- may mutate the public/scheduled article rows.  Keep this boundary in RLS so
-- a handcrafted PostgREST/RPC request cannot bypass the server action check.
drop policy if exists "Staff create articles" on public.articles;
create policy "Staff create articles"
  on public.articles for insert to authenticated
  with check (
    public.is_staff()
    and created_by = (select auth.uid())
    and updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or status in ('draft', 'review')
    )
  );

drop policy if exists "Staff update articles" on public.articles;
create policy "Staff update articles"
  on public.articles for update to authenticated
  using (
    public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
    or (
      public.is_staff(array['editor'::public.staff_role])
      and status in ('draft', 'review')
    )
  )
  with check (
    updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review')
      )
    )
  );

-- Apply the same release boundary to article translations.  Editors may work
-- only inside an unpublished parent and may never manufacture an approved,
-- published or archived translation through direct PostgREST writes.
drop policy if exists "Staff create article translations"
  on public.article_translations;
create policy "Staff create article translations"
  on public.article_translations for insert to authenticated
  with check (
    created_by = (select auth.uid())
    and updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review')
        and approved_by is null
        and approved_at is null
        and published_at is null
        and deleted_at is null
        and exists (
          select 1
          from public.articles parent_article
          where parent_article.id = article_id
            and parent_article.status in ('draft', 'review')
            and parent_article.deleted_at is null
        )
      )
    )
  );

drop policy if exists "Staff update article translations"
  on public.article_translations;
create policy "Staff update article translations"
  on public.article_translations for update to authenticated
  using (
    public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
    or (
      public.is_staff(array['editor'::public.staff_role])
      and deleted_at is null
      and exists (
        select 1
        from public.articles parent_article
        where parent_article.id = article_id
          and parent_article.status in ('draft', 'review')
          and parent_article.deleted_at is null
      )
    )
  )
  with check (
    updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review', 'stale')
        and approved_by is null
        and approved_at is null
        and published_at is null
        and deleted_at is null
        and exists (
          select 1
          from public.articles parent_article
          where parent_article.id = article_id
            and parent_article.status in ('draft', 'review')
            and parent_article.deleted_at is null
        )
      )
    )
  );

drop policy if exists "Staff read article working drafts"
  on public.article_working_drafts;
create policy "Staff read article working drafts"
  on public.article_working_drafts
  for select to authenticated
  using (public.is_staff());

create or replace function public.save_article_working_draft(
  p_article_id uuid,
  p_base_article_updated_at timestamptz,
  p_payload jsonb,
  p_english_payload jsonb,
  p_expected_english_updated_at timestamptz,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_article public.articles%rowtype;
  current_english_updated_at timestamptz;
  current_draft public.article_working_drafts%rowtype;
  saved public.article_working_drafts%rowtype;
begin
  if actor is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'staff-required';
  end if;
  if p_article_id is null
    or p_base_article_updated_at is null
    or p_expected_version is null
    or p_expected_version < 0
    or jsonb_typeof(p_payload) is distinct from 'object'
    or octet_length(p_payload::text) > 5242880
    or (
      jsonb_typeof(p_english_payload) is distinct from 'object'
      or octet_length(p_english_payload::text) > 5242880
      or not (
        p_english_payload = '{"mode":"disabled"}'::jsonb
        or (
          p_english_payload ->> 'mode' = 'save'
          and jsonb_typeof(p_english_payload -> 'payload') = 'object'
        )
      )
    ) then
    raise exception using errcode = '22023', message = 'working-draft-invalid';
  end if;

  select * into current_article
  from public.articles
  where id = p_article_id
  for update;
  if not found or current_article.deleted_at is not null
    or current_article.status is distinct from 'published'::public.article_status then
    raise exception using errcode = 'P0001', message = 'published-article-required';
  end if;
  if current_article.updated_at is distinct from p_base_article_updated_at then
    raise exception using errcode = '40001', message = 'article-version-conflict';
  end if;

  select translation.updated_at into current_english_updated_at
  from public.article_translations translation
  where translation.article_id = p_article_id
    and translation.locale = 'en'
    and translation.deleted_at is null
  for update;
  if current_english_updated_at is distinct from p_expected_english_updated_at then
    raise exception using errcode = '40001', message = 'english-version-conflict';
  end if;

  select * into current_draft
  from public.article_working_drafts
  where article_id = p_article_id
  for update;
  if found then
    if current_draft.version is distinct from p_expected_version then
      raise exception using errcode = '40001', message = 'working-draft-version-conflict';
    end if;
    update public.article_working_drafts
    set base_article_updated_at = p_base_article_updated_at,
        payload = p_payload,
        english_payload = p_english_payload,
        expected_english_updated_at = p_expected_english_updated_at,
        version = current_draft.version + 1,
        actor_id = actor,
        updated_at = now()
    where article_id = p_article_id and version = p_expected_version
    returning * into saved;
  else
    if p_expected_version <> 0 then
      raise exception using errcode = '40001', message = 'working-draft-version-conflict';
    end if;
    insert into public.article_working_drafts (
      article_id, base_article_updated_at, payload, english_payload,
      expected_english_updated_at, version, actor_id
    ) values (
      p_article_id, p_base_article_updated_at, p_payload, p_english_payload,
      p_expected_english_updated_at, 1, actor
    ) returning * into saved;
  end if;

  if saved.article_id is null then
    raise exception using errcode = '40001', message = 'working-draft-version-conflict';
  end if;
  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor,
    'article.working_draft.saved',
    'article',
    saved.article_id::text,
    jsonb_build_object(
      'version', saved.version,
      'baseArticleUpdatedAt', saved.base_article_updated_at,
      'hasEnglish', saved.english_payload ->> 'mode' = 'save'
    )
  );
  return jsonb_build_object(
    'articleId', saved.article_id,
    'version', saved.version,
    'updatedAt', saved.updated_at
  );
end;
$$;

create or replace function public.discard_article_working_draft(
  p_article_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_version bigint;
begin
  if actor is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'staff-required';
  end if;
  if p_article_id is null or p_expected_version is null or p_expected_version < 1 then
    raise exception using errcode = '22023', message = 'working-draft-invalid';
  end if;
  select version into current_version
  from public.article_working_drafts
  where article_id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'working-draft-not-found';
  end if;
  if current_version is distinct from p_expected_version then
    raise exception using errcode = '40001', message = 'working-draft-version-conflict';
  end if;
  delete from public.article_working_drafts
  where article_id = p_article_id and version = p_expected_version;
  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor,
    'article.working_draft.discarded',
    'article',
    p_article_id::text,
    jsonb_build_object('version', p_expected_version)
  );
  return jsonb_build_object('articleId', p_article_id, 'discarded', true);
end;
$$;

create or replace function public.clear_article_working_draft_after_promotion()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  delete from public.article_working_drafts where article_id = new.id;
  return new;
end;
$$;

-- An existing privileged release must not erase a newer working copy.  The
-- guard makes the legacy bundle RPC fail closed whenever a working draft is
-- present; only the promotion RPC below installs the transaction-local CAS
-- evidence after locking article -> draft in the canonical order.
create or replace function public.guard_article_working_draft_promotion()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_draft_version bigint;
  expected_promotion text;
begin
  if new.status not in ('published', 'scheduled', 'hidden', 'archived') then
    return new;
  end if;

  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = new.id
  for update;
  if not found then
    return new;
  end if;

  expected_promotion := nullif(
    current_setting('probpera.expected_working_draft_promotion', true),
    ''
  );
  if expected_promotion is distinct from
    (new.id::text || ':' || current_draft_version::text) then
    raise exception using
      errcode = '40001',
      message = 'WORKING_DRAFT_CONFLICT';
  end if;
  return new;
end;
$$;

create or replace function public.promote_article_working_draft(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz,
  p_expected_working_draft_version bigint,
  p_article_payload jsonb,
  p_english_mode text,
  p_english_payload jsonb,
  p_expected_english_updated_at timestamptz,
  p_redirect_source_path text,
  p_redirect_destination_path text,
  p_replace_homepage boolean,
  p_audit_action text,
  p_audit_metadata jsonb,
  p_social_publish_requested boolean,
  p_social_metadata jsonb
)
returns table (
  article_id uuid,
  article_updated_at timestamptz,
  english_updated_at timestamptz,
  homepage_replaced integer
)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  current_article_updated_at timestamptz;
  current_draft_version bigint;
  has_working_draft boolean := false;
  target_status text := p_article_payload ->> 'status';
begin
  if (select auth.uid()) is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  if p_article_id is null
    or p_expected_article_updated_at is null
    or p_expected_working_draft_version is null
    or p_expected_working_draft_version < 0 then
    raise exception using errcode = '22023', message = 'PROMOTION_INPUT_INVALID';
  end if;
  if target_status is null
    or target_status not in ('published', 'scheduled', 'hidden', 'archived') then
    raise exception using errcode = '22023', message = 'PROMOTION_STATUS_REQUIRED';
  end if;

  select article.updated_at
  into current_article_updated_at
  from public.articles article
  where article.id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
  end if;
  if current_article_updated_at is distinct from p_expected_article_updated_at then
    raise exception using errcode = '40001', message = 'ARTICLE_CONFLICT';
  end if;

  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  has_working_draft := found;
  if (
    p_expected_working_draft_version = 0
    and has_working_draft
  ) or (
    p_expected_working_draft_version > 0
    and (
      not has_working_draft
      or current_draft_version is distinct from p_expected_working_draft_version
    )
  ) then
    raise exception using errcode = '40001', message = 'WORKING_DRAFT_CONFLICT';
  end if;

  perform set_config(
    'probpera.expected_working_draft_promotion',
    p_article_id::text || ':' || p_expected_working_draft_version::text,
    true
  );

  return query
  select bundle.article_id,
         bundle.article_updated_at,
         bundle.english_updated_at,
         bundle.homepage_replaced
  from public.save_article_bundle(
    p_article_id,
    p_expected_article_updated_at,
    p_article_payload,
    p_english_mode,
    p_english_payload,
    p_expected_english_updated_at,
    p_redirect_source_path,
    p_redirect_destination_path,
    p_replace_homepage,
    p_audit_action,
    p_audit_metadata,
    p_social_publish_requested,
    p_social_metadata
  ) bundle;
end;
$$;

drop trigger if exists articles_guard_working_draft_promotion
  on public.articles;
create trigger articles_guard_working_draft_promotion
before update on public.articles
for each row
when (new.status in ('published', 'scheduled', 'hidden', 'archived'))
execute function public.guard_article_working_draft_promotion();

drop trigger if exists articles_clear_working_draft_after_promotion
  on public.articles;
create trigger articles_clear_working_draft_after_promotion
after update on public.articles
for each row
when (new.status in ('published', 'scheduled', 'hidden', 'archived'))
execute function public.clear_article_working_draft_after_promotion();

revoke all on function public.save_article_working_draft(
  uuid, timestamptz, jsonb, jsonb, timestamptz, bigint
) from public, anon, authenticated, service_role;
revoke all on function public.discard_article_working_draft(uuid, bigint)
  from public, anon, authenticated, service_role;
revoke all on function public.clear_article_working_draft_after_promotion()
  from public, anon, authenticated, service_role;
revoke all on function public.guard_article_working_draft_promotion()
  from public, anon, authenticated, service_role;
revoke all on function public.promote_article_working_draft(
  uuid, timestamptz, bigint, jsonb, text, jsonb, timestamptz, text, text,
  boolean, text, jsonb, boolean, jsonb
) from public, anon, authenticated, service_role;
grant execute on function public.save_article_working_draft(
  uuid, timestamptz, jsonb, jsonb, timestamptz, bigint
) to authenticated;
grant execute on function public.discard_article_working_draft(uuid, bigint)
  to authenticated;
grant execute on function public.promote_article_working_draft(
  uuid, timestamptz, bigint, jsonb, text, jsonb, timestamptz, text, text,
  boolean, text, jsonb, boolean, jsonb
) to authenticated;

create or replace function public.assert_redirect_candidate(
  p_id uuid,
  p_source_path text,
  p_destination_path text,
  p_is_active boolean
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  normalized_source text := regexp_replace(p_source_path, '/+$', '');
  normalized_destination text := case
    when p_destination_path like '/%' then regexp_replace(p_destination_path, '/+$', '')
    else p_destination_path
  end;
begin
  normalized_source := case when normalized_source = '' then '/' else normalized_source end;
  normalized_destination := case when normalized_destination = '' then '/' else normalized_destination end;
  if char_length(normalized_source) > 500
    or char_length(normalized_destination) > 500
    or normalized_source !~ '^/(?:$|[^/\\])'
    or normalized_source ~ '[[:cntrl:]\\]'
    or not (
      normalized_destination ~ '^/(?:$|[^/\\])'
      or normalized_destination ~ '^https://[^/[:space:]]+(?:/.*)?$'
    )
    or normalized_destination ~ '[[:cntrl:]\\]' then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_PATH';
  end if;
  if normalized_source = normalized_destination then
    raise exception using errcode = 'P0001', message = 'REDIRECT_SELF_REFERENCE';
  end if;

  if p_is_active and exists (
    select 1 from public.redirects r
    where r.id is distinct from p_id and r.is_active
      and (
        r.source_path = normalized_source
        or (normalized_destination like '/%' and r.source_path = normalized_destination)
        or r.destination_path = normalized_source
      )
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_COLLISION_OR_CHAIN';
  end if;

  if p_is_active and exists (
    select 1 from public.pages p
    where p.deleted_at is null and p.status = 'published'
      and (
        '/stranitsy/' || p.slug = normalized_source
        or regexp_replace(
          regexp_replace(coalesce(p.canonical_url, ''), '^https://[^/]+', ''),
          '/+$', ''
        ) = normalized_source
      )
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_LIVE_ROUTE_COLLISION';
  end if;

  if p_is_active and exists (
    select 1 from public.articles a
    where a.deleted_at is null and a.status = 'published'
      and regexp_replace(
        regexp_replace(coalesce(a.canonical_url, ''), '^https://[^/]+', ''),
        '/+$', ''
      ) = normalized_source
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_LIVE_ROUTE_COLLISION';
  end if;
end;
$$;
create or replace function public.create_seo_redirect_guarded(
  p_source_path text,
  p_destination_path text,
  p_status_code smallint,
  p_is_active boolean
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  redirect_id uuid;
begin
  perform pg_advisory_xact_lock(188654771, 3);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  if p_status_code not in (301, 302, 307, 308) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_STATUS';
  end if;
  perform public.assert_redirect_candidate(null, p_source_path, p_destination_path, p_is_active);
  insert into public.redirects (
    source_path, destination_path, status_code, is_active, created_by
  ) values (
    coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/'),
    case when p_destination_path like '/%' then coalesce(nullif(regexp_replace(p_destination_path, '/+$', ''), ''), '/') else p_destination_path end,
    p_status_code, p_is_active, actor_user_id
  ) returning id into redirect_id;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id, metadata)
  values (actor_user_id, 'redirect.created', 'redirect', redirect_id::text,
    jsonb_build_object('sourcePath', p_source_path, 'destinationPath', p_destination_path,
      'statusCode', p_status_code, 'isActive', p_is_active));
  return redirect_id;
exception when unique_violation then
  raise exception using errcode = 'P0001', message = 'REDIRECT_SOURCE_EXISTS';
end;
$$;
create or replace function public.update_seo_redirect_guarded(
  p_id uuid,
  p_expected_updated_at timestamptz,
  p_source_path text,
  p_destination_path text,
  p_status_code smallint,
  p_is_active boolean
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  current_updated_at timestamptz;
begin
  perform pg_advisory_xact_lock(188654771, 3);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  select updated_at into current_updated_at from public.redirects where id = p_id for update;
  if current_updated_at is null or current_updated_at <> p_expected_updated_at then
    raise exception using errcode = 'P0001', message = 'REDIRECT_WRITE_CONFLICT';
  end if;
  if p_status_code not in (301, 302, 307, 308) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_STATUS';
  end if;
  perform public.assert_redirect_candidate(p_id, p_source_path, p_destination_path, p_is_active);
  update public.redirects set
    source_path = coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/'),
    destination_path = case when p_destination_path like '/%' then coalesce(nullif(regexp_replace(p_destination_path, '/+$', ''), ''), '/') else p_destination_path end,
    status_code = p_status_code,
    is_active = p_is_active
  where id = p_id;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id, metadata)
  values (actor_user_id, 'redirect.updated', 'redirect', p_id::text,
    jsonb_build_object('sourcePath', p_source_path, 'destinationPath', p_destination_path,
      'statusCode', p_status_code, 'isActive', p_is_active));
  return p_id;
exception when unique_violation then
  raise exception using errcode = 'P0001', message = 'REDIRECT_SOURCE_EXISTS';
end;
$$;
revoke all on function public.assert_redirect_candidate(uuid, text, text, boolean) from public, anon, authenticated;
revoke all on function public.create_seo_redirect_guarded(text, text, smallint, boolean) from public, anon, authenticated;
revoke all on function public.update_seo_redirect_guarded(uuid, timestamptz, text, text, smallint, boolean) from public, anon, authenticated;
grant execute on function public.create_seo_redirect_guarded(text, text, smallint, boolean) to authenticated;
grant execute on function public.update_seo_redirect_guarded(uuid, timestamptz, text, text, smallint, boolean) to authenticated;
revoke insert, update, delete on public.redirects from authenticated;
-- Keep public save/promotion SECURITY INVOKER and both protected tables read-only
-- to authenticated clients. Only the existing guarded operations may write.

create or replace function public.lock_article_working_draft_for_publication(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_article_updated_at timestamptz;
  current_draft_version bigint;
begin
  if (select auth.uid()) is null
    or not public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role]) then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  if p_article_id is null or p_expected_article_updated_at is null then
    raise exception using errcode = '22023', message = 'PROMOTION_INPUT_INVALID';
  end if;

  -- Match the save/promotion lock order even when this helper is called directly.
  select article.updated_at into current_article_updated_at
  from public.articles article
  where article.id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
  end if;
  if current_article_updated_at is distinct from p_expected_article_updated_at then
    raise exception using errcode = '40001', message = 'ARTICLE_CONFLICT';
  end if;

  select draft.version into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  return current_draft_version;
end;
$$;

revoke all on function public.lock_article_working_draft_for_publication(uuid, timestamptz)
  from public, anon, authenticated, service_role;
grant execute on function public.lock_article_working_draft_for_publication(uuid, timestamptz)
  to authenticated;

create or replace function public.upsert_article_redirect_guarded(
  p_source_path text,
  p_destination_path text
)
returns uuid
language plpgsql
security invoker
set search_path = ''
as $$
declare
  existing_redirect_id uuid;
  existing_updated_at timestamptz;
  normalized_source text := coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/');
begin
  if (select auth.uid()) is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  -- Share the SEO RPC lock before reading its CAS token. Never use a direct
  -- INSERT/UPDATE or SELECT FOR UPDATE on the read-only redirects table.
  perform pg_advisory_xact_lock(188654771, 3);
  select redirect.id, redirect.updated_at
  into existing_redirect_id, existing_updated_at
  from public.redirects redirect
  where redirect.source_path = normalized_source;
  if found then
    return public.update_seo_redirect_guarded(
      existing_redirect_id, existing_updated_at,
      p_source_path, p_destination_path, 301::smallint, true
    );
  end if;
  return public.create_seo_redirect_guarded(
    p_source_path, p_destination_path, 301::smallint, true
  );
end;
$$;

revoke all on function public.upsert_article_redirect_guarded(text, text)
  from public, anon, authenticated, service_role;
grant execute on function public.upsert_article_redirect_guarded(text, text)
  to authenticated;

-- Replace only the two reviewed statements. Fail closed on an unexpected
-- predecessor; retain every original role, payload, CAS, RLS and atomicity gate.
do $publication_permissions$
declare
  promotion_oid regprocedure := to_regprocedure(
    'public.promote_article_working_draft(uuid,timestamptz,bigint,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
  );
  bundle_oid regprocedure := to_regprocedure(
    'public.save_article_bundle(uuid,timestamptz,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
  );
  definition text;
  old_lock text := $old_lock$  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  has_working_draft := found;$old_lock$;
  new_lock text := $new_lock$  current_draft_version := public.lock_article_working_draft_for_publication(
    p_article_id, p_expected_article_updated_at
  );
  has_working_draft := current_draft_version is not null;$new_lock$;
  old_redirect text := $old_redirect$    insert into public.redirects (
      source_path,
      destination_path,
      status_code,
      is_active,
      created_by
    ) values (
      p_redirect_source_path,
      p_redirect_destination_path,
      301,
      true,
      actor_id
    )
    on conflict (source_path) do update set
      destination_path = excluded.destination_path,
      status_code = 301,
      is_active = true,
      created_by = actor_id;$old_redirect$;
  new_redirect text := $new_redirect$    perform public.upsert_article_redirect_guarded(
      p_redirect_source_path, p_redirect_destination_path
    );$new_redirect$;
begin
  if promotion_oid is null or bundle_oid is null
    or exists (select 1 from pg_proc where oid in (promotion_oid, bundle_oid) and prosecdef) then
    raise exception 'Expected SECURITY INVOKER article publication functions are missing';
  end if;

  definition := pg_get_functiondef(promotion_oid);
  if strpos(definition, old_lock) > 0 and strpos(definition, new_lock) = 0
    and (length(definition) - length(replace(definition, old_lock, ''))) = length(old_lock) then
    execute replace(definition, old_lock, new_lock);
  elsif strpos(definition, old_lock) > 0 or strpos(definition, new_lock) = 0 then
    raise exception 'Unexpected article promotion lock predecessor';
  end if;

  definition := pg_get_functiondef(bundle_oid);
  if strpos(definition, old_redirect) > 0 and strpos(definition, new_redirect) = 0
    and (length(definition) - length(replace(definition, old_redirect, ''))) = length(old_redirect) then
    execute replace(definition, old_redirect, new_redirect);
  elsif strpos(definition, old_redirect) > 0 or strpos(definition, new_redirect) = 0 then
    raise exception 'Unexpected article redirect write predecessor';
  end if;

  if exists (
    select 1 from pg_proc where oid in (promotion_oid, bundle_oid) and prosecdef
  ) or not (
    select prosecdef from pg_proc
    where oid = 'public.lock_article_working_draft_for_publication(uuid,timestamptz)'::regprocedure
  ) or (
    select prosecdef from pg_proc
    where oid = 'public.upsert_article_redirect_guarded(text,text)'::regprocedure
  ) then
    raise exception 'Article publication privilege boundaries changed';
  end if;
  if has_table_privilege('authenticated', 'public.article_working_drafts', 'INSERT,UPDATE,DELETE')
    or has_any_column_privilege('authenticated', 'public.article_working_drafts', 'UPDATE')
    or has_table_privilege('authenticated', 'public.redirects', 'INSERT,UPDATE,DELETE')
    or has_any_column_privilege('authenticated', 'public.redirects', 'UPDATE') then
    raise exception 'Protected article tables must remain read-only to authenticated clients';
  end if;
  if not has_function_privilege('authenticated',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or not has_function_privilege('authenticated',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE')
    or has_function_privilege('anon',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or has_function_privilege('service_role',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or has_function_privilege('anon',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE')
    or has_function_privilege('service_role',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE') then
    raise exception 'Article publication helper ACLs are invalid';
  end if;
end;
$publication_permissions$;


create table if not exists public.media_assets (
  id uuid primary key default gen_random_uuid(),
  bucket text not null default 'editorial-media',
  object_path text not null unique,
  original_name text not null,
  mime_type text not null,
  byte_size bigint not null check (byte_size > 0 and byte_size <= 26214400),
  width integer check (width is null or width > 0),
  height integer check (height is null or height > 0),
  alt_text text not null default '' check (char_length(alt_text) <= 500),
  caption text not null default '' check (char_length(caption) <= 1000),
  creator text not null default '',
  source_url text,
  license_name text not null default '',
  license_url text,
  focus_x numeric(5,4) not null default 0.5 check (focus_x between 0 and 1),
  focus_y numeric(5,4) not null default 0.5 check (focus_y between 0 and 1),
  collection_name text not null default 'Общее',
  uploaded_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.homepage_blocks (
  id uuid primary key default gen_random_uuid(),
  block_type text not null check (
    block_type in (
      'hero',
      'article-grid',
      'carousel',
      'editors-choice',
      'popular',
      'latest',
      'categories',
      'book-vs-screen',
      'literary-map',
      'awards',
      'subscription',
      'text'
    )
  ),
  title text not null default '',
  settings jsonb not null default '{}'::jsonb,
  display_order integer not null default 0,
  is_enabled boolean not null default true,
  background_style text not null default 'light' check (
    background_style in ('light', 'violet', 'orange', 'paper', 'transparent')
  ),
  background_media_id uuid references public.media_assets(id) on delete set null,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.fixture_homepage_set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;
create trigger homepage_blocks_set_updated_at before update on public.homepage_blocks for each row execute function public.fixture_homepage_set_updated_at();
alter table public.homepage_blocks enable row level security;
create policy "Public read enabled homepage blocks"
on public.homepage_blocks for select
to anon, authenticated
using (is_enabled);

create policy "Staff manage homepage blocks"
on public.homepage_blocks for all
to authenticated
using (public.is_staff())
with check (public.is_staff() and updated_by = (select auth.uid()));


grant select on public.homepage_blocks to anon,authenticated; grant insert,update,delete on public.homepage_blocks to authenticated;
create or replace function public.save_site_copy_block(
  p_expected_updated_at timestamptz,
  p_payload jsonb,
  p_audit_metadata jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  block_id uuid;
  current_updated_at timestamptz;
begin
  perform pg_advisory_xact_lock(188654771, 2);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  if jsonb_typeof(p_payload) <> 'object'
    or p_payload #>> '{settings,systemKey}' <> 'site-copy-overrides'
    or p_payload ->> 'block_type' <> 'text' then
    raise exception using errcode = 'P0001', message = 'SITE_COPY_INVALID_PAYLOAD';
  end if;

  select id, updated_at into block_id, current_updated_at
  from public.homepage_blocks
  where settings @> '{"systemKey":"site-copy-overrides"}'::jsonb
  order by updated_at desc
  limit 1
  for update;

  if block_id is not null then
    if p_expected_updated_at is null
      or current_updated_at <> p_expected_updated_at then
      raise exception using errcode = 'P0001', message = 'SITE_COPY_WRITE_CONFLICT';
    end if;
    update public.homepage_blocks
    set block_type = p_payload ->> 'block_type',
        title = p_payload ->> 'title',
        settings = p_payload -> 'settings',
        display_order = (p_payload ->> 'display_order')::integer,
        is_enabled = (p_payload ->> 'is_enabled')::boolean,
        background_style = p_payload ->> 'background_style',
        background_media_id = nullif(p_payload ->> 'background_media_id', '')::uuid,
        updated_by = actor_user_id
    where id = block_id;
  else
    if p_expected_updated_at is not null then
      raise exception using errcode = 'P0001', message = 'SITE_COPY_WRITE_CONFLICT';
    end if;
    insert into public.homepage_blocks (
      block_type, title, settings, display_order, is_enabled,
      background_style, background_media_id, updated_by
    ) values (
      p_payload ->> 'block_type',
      p_payload ->> 'title',
      p_payload -> 'settings',
      (p_payload ->> 'display_order')::integer,
      (p_payload ->> 'is_enabled')::boolean,
      p_payload ->> 'background_style',
      nullif(p_payload ->> 'background_media_id', '')::uuid,
      actor_user_id
    ) returning id into block_id;
  end if;

  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor_user_id,
    case when coalesce((p_audit_metadata ->> 'inline_editor')::boolean, false)
      then 'site_copy.inline_updated' else 'site_copy.updated' end,
    'site_copy', block_id::text,
    coalesce(p_audit_metadata, '{}'::jsonb) || jsonb_build_object('storage', 'homepage_blocks')
  );
  return block_id;
exception
  when invalid_text_representation or numeric_value_out_of_range or not_null_violation
    or check_violation then
    raise exception using errcode = 'P0001', message = 'SITE_COPY_INVALID_PAYLOAD';
end;
$$;

-- Keep ordinary homepage blocks editable through their existing staff flows,
-- but make the singleton Site Copy row writable only by the security-definer
-- RPC above. Restrictive policies compose with the existing permissive staff
-- policy and protect both the old and proposed row on UPDATE.
drop policy if exists "Site Copy insert requires guarded RPC"
  on public.homepage_blocks;
create policy "Site Copy insert requires guarded RPC"
on public.homepage_blocks as restrictive for insert to authenticated
with check (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
);

drop policy if exists "Site Copy update requires guarded RPC"
  on public.homepage_blocks;
create policy "Site Copy update requires guarded RPC"
on public.homepage_blocks as restrictive for update to authenticated
using (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
)
with check (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
);

drop policy if exists "Site Copy delete requires guarded RPC"
  on public.homepage_blocks;
create policy "Site Copy delete requires guarded RPC"
on public.homepage_blocks as restrictive for delete to authenticated
using (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
);


revoke all on function public.save_site_copy_block(timestamptz, jsonb, jsonb) from public, anon, authenticated;
grant execute on function public.save_site_copy_block(timestamptz, jsonb, jsonb) to authenticated;
-- Нормализованный редакционный контур книжного архива.
-- Главным источником энциклопедических данных остаётся src/data/countries.
-- Эти таблицы дают CMS безопасный рабочий слой для проверки произведений,
-- конкретных изданий и ISBN без дублирования одной обложки на уровне произведения.

create table if not exists public.literary_works (
  id uuid primary key default gen_random_uuid(),
  legacy_id text not null unique check (char_length(legacy_id) between 2 and 180),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  title text not null check (char_length(title) between 1 and 300),
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{0,179}$'),
  original_title text not null default '' check (char_length(original_title) <= 300),
  first_published integer check (first_published between -3000 and 2100),
  original_language text not null default '' check (char_length(original_language) <= 120),
  genres text[] not null default '{}',
  tags text[] not null default '{}',
  description text not null default '' check (char_length(description) <= 5000),
  source_url text,
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (writer_id, slug)
);

create table if not exists public.book_editions (
  id uuid primary key default gen_random_uuid(),
  legacy_id text not null unique check (char_length(legacy_id) between 2 and 240),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  title text not null default '' check (char_length(title) <= 300),
  isbn_10 text check (
    isbn_10 is null
    or regexp_replace(isbn_10, '[^0-9Xx]', '', 'g') ~ '^[0-9]{9}[0-9Xx]$'
  ),
  isbn_13 text check (
    isbn_13 is null
    or regexp_replace(isbn_13, '[^0-9]', '', 'g') ~ '^[0-9]{13}$'
  ),
  publisher text not null default '' check (char_length(publisher) <= 240),
  publication_year integer check (publication_year between 1400 and 2100),
  language text not null default '' check (char_length(language) <= 120),
  format text not null default '' check (char_length(format) <= 120),
  page_count integer check (page_count is null or page_count > 0),
  cover_url text,
  cover_source_url text,
  cover_rights_status text not null default 'unverified'
    check (
      cover_rights_status in (
        'public-domain',
        'licensed',
        'permission',
        'editorial-original',
        'external-preview',
        'unverified'
      )
    ),
  license_name text not null default '' check (char_length(license_name) <= 240),
  license_url text,
  creator text not null default '' check (char_length(creator) <= 240),
  rights_holder text not null default '' check (char_length(rights_holder) <= 240),
  rights_checked_at date,
  source_url text,
  is_primary boolean not null default false,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (
    cover_url is null
    or (
      cover_source_url is not null
      and cover_rights_status <> 'unverified'
      and rights_checked_at is not null
    )
  )
);

create unique index if not exists literary_works_country_legacy_idx
  on public.literary_works(country_id, legacy_id);

create index if not exists literary_works_writer_idx
  on public.literary_works(country_id, writer_id, editorial_status);

create index if not exists literary_works_search_idx
  on public.literary_works
  using gin (
    to_tsvector(
      'simple',
      coalesce(title, '') || ' ' || coalesce(original_title, '') || ' ' ||
      coalesce(description, '')
    )
  );

create unique index if not exists book_editions_isbn_10_unique_idx
  on public.book_editions (
    regexp_replace(upper(isbn_10), '[^0-9X]', '', 'g')
  )
  where isbn_10 is not null;

create unique index if not exists book_editions_isbn_13_unique_idx
  on public.book_editions (
    regexp_replace(isbn_13, '[^0-9]', '', 'g')
  )
  where isbn_13 is not null;

create unique index if not exists book_editions_one_primary_idx
  on public.book_editions(work_id)
  where is_primary;

create index if not exists book_editions_work_idx
  on public.book_editions(work_id, publication_year desc);

drop trigger if exists literary_works_set_updated_at on public.literary_works;
create trigger literary_works_set_updated_at
  before update on public.literary_works
  for each row execute function public.set_updated_at();

drop trigger if exists book_editions_set_updated_at on public.book_editions;
create trigger book_editions_set_updated_at
  before update on public.book_editions
  for each row execute function public.set_updated_at();

alter table public.literary_works enable row level security;
alter table public.book_editions enable row level security;

create policy "Public read reviewed literary works"
on public.literary_works for select
to anon, authenticated
using (editorial_status in ('reviewed', 'verified'));

create policy "Staff manage literary works"
on public.literary_works for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Public read verified book editions"
on public.book_editions for select
to anon, authenticated
using (
  (
    cover_url is null
    or (
      cover_rights_status <> 'unverified'
      and cover_source_url is not null
      and rights_checked_at is not null
    )
  )
  and exists (
    select 1
    from public.literary_works
    where literary_works.id = book_editions.work_id
      and literary_works.editorial_status in ('reviewed', 'verified')
  )
);

create policy "Staff manage book editions"
on public.book_editions for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

-- Bilingual, source-aware publication workflow for literary works.
-- Discovery imports land in book_import_candidates. Only reviewed works with
-- complete RU/EN editorial text and provenance are visible through public RLS.

create table if not exists public.literary_work_translations (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  locale text not null check (locale in ('ru', 'en')),
  title text not null check (char_length(title) between 1 and 300),
  description text not null check (char_length(description) between 140 and 900),
  source_language text not null check (char_length(source_language) between 2 and 40),
  translation_method text not null
    check (
      translation_method in (
        'editorial-original',
        'human-translation',
        'licensed-source'
      )
    ),
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  source_urls text[] not null default '{}',
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, locale),
  check (
    editorial_status = 'draft'
    or (
      reviewed_at is not null
      and cardinality(source_urls) > 0
    )
  )
);

create table if not exists public.literary_work_sources (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  provider text not null check (char_length(provider) between 2 and 160),
  source_url text not null check (source_url ~ '^https://'),
  field_names text[] not null check (cardinality(field_names) > 0),
  license_name text,
  usage text not null
    check (usage in ('structured-data', 'reference-only', 'licensed-copy')),
  retrieved_at date not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, provider, source_url)
);

create table if not exists public.literary_work_external_ids (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  scheme text not null check (scheme ~ '^[a-z0-9][a-z0-9_-]{1,39}$'),
  external_id text not null check (char_length(external_id) between 1 and 180),
  source_url text not null check (source_url ~ '^https://'),
  created_at timestamptz not null default now(),
  unique (scheme, external_id),
  unique (work_id, scheme, external_id)
);

create table if not exists public.book_import_candidates (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider ~ '^[a-z0-9][a-z0-9_-]{1,39}$'),
  external_id text not null check (char_length(external_id) between 1 and 180),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  writer_key text not null check (char_length(writer_key) between 3 and 320),
  title text not null check (char_length(title) between 1 and 300),
  source_url text not null check (source_url ~ '^https://'),
  quality_score integer not null default 0 check (quality_score between 0 and 100),
  status text not null default 'candidate'
    check (status in ('candidate', 'rejected', 'reviewed', 'promoted')),
  rejection_reasons text[] not null default '{}',
  payload jsonb not null default '{}'::jsonb,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  promoted_work_id uuid references public.literary_works(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, external_id),
  check (
    status not in ('reviewed', 'promoted')
    or (reviewed_by is not null and reviewed_at is not null)
  ),
  check (status <> 'promoted' or promoted_work_id is not null)
);

create index if not exists literary_work_translations_public_idx
  on public.literary_work_translations(work_id, locale, editorial_status);
create index if not exists literary_work_sources_work_idx
  on public.literary_work_sources(work_id);
create index if not exists literary_work_external_ids_work_idx
  on public.literary_work_external_ids(work_id);
create index if not exists book_import_candidates_queue_idx
  on public.book_import_candidates(status, quality_score desc, created_at);
create index if not exists book_import_candidates_writer_idx
  on public.book_import_candidates(writer_key, status);

drop trigger if exists literary_work_translations_set_updated_at
  on public.literary_work_translations;
create trigger literary_work_translations_set_updated_at
  before update on public.literary_work_translations
  for each row execute function public.set_updated_at();

drop trigger if exists literary_work_sources_set_updated_at
  on public.literary_work_sources;
create trigger literary_work_sources_set_updated_at
  before update on public.literary_work_sources
  for each row execute function public.set_updated_at();

drop trigger if exists book_import_candidates_set_updated_at
  on public.book_import_candidates;
create trigger book_import_candidates_set_updated_at
  before update on public.book_import_candidates
  for each row execute function public.set_updated_at();

alter table public.literary_work_translations enable row level security;
alter table public.literary_work_sources enable row level security;
alter table public.literary_work_external_ids enable row level security;
alter table public.book_import_candidates enable row level security;

create or replace function public.is_publishable_literary_work(target_work_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1
    from public.literary_works as work
    where work.id = target_work_id
      and work.editorial_status in ('reviewed', 'verified')
      and exists (
        select 1
        from public.literary_work_sources as source
        where source.work_id = work.id
      )
      and not exists (
        select 1
        from public.literary_work_sources as source
        where source.work_id = work.id
          and (
            btrim(source.provider) = ''
            or source.source_url !~* '^https://'
            or cardinality(source.field_names) = 0
            or source.retrieved_at is null
          )
      )
      and 2 = (
        select count(distinct translation.locale)
        from public.literary_work_translations as translation
        where translation.work_id = work.id
          and translation.locale in ('ru', 'en')
          and translation.editorial_status in ('reviewed', 'verified')
          and translation.reviewed_at is not null
          and btrim(translation.title) <> ''
          and btrim(translation.source_language) <> ''
          and char_length(btrim(translation.description)) between 140 and 900
          and (
            select count(*)
            from regexp_matches(
              btrim(translation.description),
              '[.!?…]+([[:space:]]|$)',
              'g'
            )
          ) between 2 and 3
          and case
            when translation.locale = 'ru'
              then translation.description ~ '[А-Яа-яЁё]'
            when translation.locale = 'en'
              then translation.description ~ '[A-Za-z]'
                -- PostgreSQL ARE has no portable Unicode Script=Cyrillic class.
                -- Check every code point across the current Cyrillic blocks.
                and not exists (
                  select 1
                  from unnest(
                    string_to_array(
                      translation.title || translation.description,
                      null::text
                    )
                  ) as glyph(value)
                  where ascii(glyph.value) between 1024 and 1327
                    or ascii(glyph.value) between 7296 and 7311
                    or ascii(glyph.value) between 11744 and 11775
                    or ascii(glyph.value) between 42560 and 42655
                    or ascii(glyph.value) between 65070 and 65071
                    or ascii(glyph.value) between 122928 and 123023
                )
            else false
          end
          and position('Р°' in translation.description) = 0
          and position('Рµ' in translation.description) = 0
          and position('Рё' in translation.description) = 0
          and position('СЃ' in translation.description) = 0
          and position('С‚' in translation.description) = 0
          and position('вЂ' in translation.description) = 0
          and cardinality(translation.source_urls) > 0
          and not exists (
            select 1
            from unnest(translation.source_urls) as declared(source_url)
            where declared.source_url is null
              or btrim(declared.source_url) !~* '^https://'
              or not exists (
                select 1
                from public.literary_work_sources as source
                where source.work_id = translation.work_id
                  and source.source_url = btrim(declared.source_url)
              )
          )
          and (
            translation.translation_method <> 'licensed-source'
            or exists (
              select 1
              from unnest(translation.source_urls) as declared(source_url)
              join public.literary_work_sources as source
                on source.work_id = translation.work_id
               and source.source_url = btrim(declared.source_url)
              where source.usage = 'licensed-copy'
                and btrim(coalesce(source.license_name, '')) <> ''
            )
          )
      )
  );
$$;

revoke all on function public.is_publishable_literary_work(uuid) from public;
grant execute on function public.is_publishable_literary_work(uuid)
  to anon, authenticated;

drop policy if exists "Public read reviewed literary works"
  on public.literary_works;
drop policy if exists "Public read publishable literary works"
  on public.literary_works;
create policy "Public read publishable literary works"
on public.literary_works for select
to anon, authenticated
using (public.is_publishable_literary_work(id));

drop policy if exists "Public read publishable work translations"
  on public.literary_work_translations;
create policy "Public read publishable work translations"
on public.literary_work_translations for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work translations"
  on public.literary_work_translations;
create policy "Staff manage work translations"
on public.literary_work_translations for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Public read publishable work sources"
  on public.literary_work_sources;
create policy "Public read publishable work sources"
on public.literary_work_sources for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work sources"
  on public.literary_work_sources;
create policy "Staff manage work sources"
on public.literary_work_sources for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Public read publishable work external ids"
  on public.literary_work_external_ids;
create policy "Public read publishable work external ids"
on public.literary_work_external_ids for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work external ids"
  on public.literary_work_external_ids;
create policy "Staff manage work external ids"
on public.literary_work_external_ids for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Staff manage book import candidates"
  on public.book_import_candidates;
create policy "Staff manage book import candidates"
on public.book_import_candidates for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

-- Full editorial database overrides for countries plus missing history for
-- exact book editions. Static TypeScript records remain the audited fallback;
-- enabled CMS overrides are exported and applied last by the public build.

create table if not exists public.country_profile_overrides (
  id uuid primary key default gen_random_uuid(),
  country_id text not null unique
    check (char_length(country_id) between 2 and 120),
  fields jsonb not null default '{}'::jsonb,
  is_enabled boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (jsonb_typeof(fields) = 'object')
);

create index if not exists country_profile_overrides_public_idx
  on public.country_profile_overrides(country_id)
  where is_enabled;

drop trigger if exists country_profile_overrides_set_updated_at
  on public.country_profile_overrides;
create trigger country_profile_overrides_set_updated_at
  before update on public.country_profile_overrides
  for each row execute function public.set_updated_at();

create table if not exists public.country_profile_override_revisions (
  id bigint generated always as identity primary key,
  override_id uuid references public.country_profile_overrides(id)
    on delete set null,
  country_id text not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create index if not exists country_profile_override_revisions_country_idx
  on public.country_profile_override_revisions(country_id, revised_at desc);

create or replace function public.capture_country_profile_override_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  revision_actor uuid;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  if tg_op = 'UPDATE' then
    revision_actor := coalesce(new.updated_by, (select auth.uid()));
  else
    revision_actor := (select auth.uid());
  end if;
  insert into public.country_profile_override_revisions (
    override_id,
    country_id,
    snapshot,
    revised_by
  ) values (
    old.id,
    old.country_id,
    to_jsonb(old),
    revision_actor
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists country_profile_overrides_capture_revision
  on public.country_profile_overrides;
create trigger country_profile_overrides_capture_revision
  before update or delete on public.country_profile_overrides
  for each row execute function public.capture_country_profile_override_revision();


-- Durable editor-owned overrides for writer profiles and revision history for
-- both writers and literary works. The static country files remain the safe
-- fallback; published CMS values are applied last during the public build.

create table if not exists public.writer_profile_overrides (
  id uuid primary key default gen_random_uuid(),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  fields jsonb not null default '{}'::jsonb,
  is_enabled boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (country_id, writer_id),
  check (jsonb_typeof(fields) = 'object')
);

create index if not exists writer_profile_overrides_public_idx
  on public.writer_profile_overrides(country_id, writer_id)
  where is_enabled;

drop trigger if exists writer_profile_overrides_set_updated_at
  on public.writer_profile_overrides;
create trigger writer_profile_overrides_set_updated_at
  before update on public.writer_profile_overrides
  for each row execute function public.set_updated_at();

create table if not exists public.writer_profile_override_revisions (
  id bigint generated always as identity primary key,
  override_id uuid references public.writer_profile_overrides(id) on delete set null,
  country_id text not null,
  writer_id text not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create or replace function public.capture_writer_profile_override_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  revision_actor uuid;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  if tg_op = 'UPDATE' then
    revision_actor := coalesce(new.updated_by, (select auth.uid()));
  else
    revision_actor := (select auth.uid());
  end if;
  insert into public.writer_profile_override_revisions (
    override_id,
    country_id,
    writer_id,
    snapshot,
    revised_by
  ) values (
    old.id,
    old.country_id,
    old.writer_id,
    to_jsonb(old),
    revision_actor
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists writer_profile_overrides_capture_revision
  on public.writer_profile_overrides;
create trigger writer_profile_overrides_capture_revision
  before update or delete on public.writer_profile_overrides
  for each row execute function public.capture_writer_profile_override_revision();


-- Record AI-generated literary-work translations explicitly instead of
-- misclassifying them as human translations. Public publication rules remain
-- source-aware and still require reviewed/verified RU+EN records.

alter table public.literary_work_translations
  drop constraint if exists literary_work_translations_translation_method_check;

alter table public.literary_work_translations
  add constraint literary_work_translations_translation_method_check
  check (
    translation_method in (
      'editorial-original',
      'human-translation',
      'machine-translation',
      'licensed-source'
    )
  );

create or replace function public.premium_machine_translation_ready()
returns boolean
language sql
stable
security invoker
set search_path = ''
as $$
  select exists (
    select 1
    from pg_catalog.pg_constraint constraint_row
    join pg_catalog.pg_class relation
      on relation.oid = constraint_row.conrelid
    join pg_catalog.pg_namespace namespace
      on namespace.oid = relation.relnamespace
    where namespace.nspname = 'public'
      and relation.relname = 'literary_work_translations'
      and constraint_row.conname =
        'literary_work_translations_translation_method_check'
      and pg_catalog.pg_get_constraintdef(constraint_row.oid)
        like '%machine-translation%'
  );
$$;

revoke all on function public.premium_machine_translation_ready() from public;
grant execute on function public.premium_machine_translation_ready()
  to authenticated;

-- Preserve short, unreviewed draft text without changing publication rules.
-- Reviewed and verified descriptions retain the existing 140..900 limit.
do $literary_translation_draft_storage$
declare
  existing_constraint record;
  old_definition constant text :=
    'CHECK (((char_length(description) >= 140) AND (char_length(description) <= 900)))';
  target_definition constant text :=
    'CHECK ((((char_length(description) >= 140) AND (char_length(description) <= 900)) OR ((editorial_status = ''draft''::text) AND (reviewed_at IS NULL) AND ((char_length(description) >= 1) AND (char_length(description) <= 139)) AND (description ~ ''[^[:space:]]''::text))))';
begin
  lock table public.literary_work_translations
    in access exclusive mode nowait;

  select constraint_row.*,
    pg_catalog.pg_get_constraintdef(constraint_row.oid, false) as definition
  into existing_constraint
  from pg_catalog.pg_constraint constraint_row
  where constraint_row.conrelid =
      'public.literary_work_translations'::regclass
    and constraint_row.conname =
      'literary_work_translations_description_check';

  if not found
    or existing_constraint.contype <> 'c'
    or not existing_constraint.convalidated
    or not existing_constraint.conislocal
    or existing_constraint.coninhcount <> 0
    or existing_constraint.connoinherit
    or existing_constraint.condeferrable
    or existing_constraint.condeferred then
    raise exception 'Reviewed translation description constraint is missing or incompatible';
  end if;

  if existing_constraint.definition = target_definition then
    return;
  end if;
  if existing_constraint.definition <> old_definition then
    raise exception 'Translation description constraint differs from the reviewed predecessor';
  end if;

  alter table public.literary_work_translations
    drop constraint literary_work_translations_description_check;
  -- Adding a validated CHECK scans existing rows inside the same transaction.
  alter table public.literary_work_translations
    add constraint literary_work_translations_description_check check (
      char_length(description) between 140 and 900
      or (
        editorial_status = 'draft'
        and reviewed_at is null
        and char_length(description) between 1 and 139
        and description ~ '[^[:space:]]'
      )
    );
end;
$literary_translation_draft_storage$;

-- Private review candidates for books/countries. This is not a job queue.
-- Existing canonical rows, publication policies and public-build triggers are
-- unchanged. Only explicit human promotion writes canonical English.
create schema if not exists premium_translation_private;
revoke all on schema premium_translation_private from public, anon, authenticated;

create table public.premium_translation_working_drafts (
  id uuid primary key default gen_random_uuid(),
  version bigint not null default 1 check (version between 1 and 9007199254740991),
  entity_type text not null check (entity_type in ('literary_work', 'country')),
  entity_id text not null check (char_length(entity_id) between 1 and 120),
  target_locale text not null default 'en' check (target_locale = 'en'),
  human_review text not null default 'pending' check (human_review = 'pending'),
  source_hash text not null check (source_hash ~ '^[a-f0-9]{64}$'),
  candidate_hash text not null check (candidate_hash ~ '^[a-f0-9]{64}$'),
  source_revision jsonb not null check (jsonb_typeof(source_revision) = 'object'),
  target_revision jsonb not null check (jsonb_typeof(target_revision) = 'object'),
  source_snapshot jsonb not null check (jsonb_typeof(source_snapshot) = 'object'),
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  provenance jsonb not null check (jsonb_typeof(provenance) = 'object'),
  created_at timestamptz not null default clock_timestamp(),
  created_by uuid not null references auth.users(id) on delete restrict,
  unique (entity_type, entity_id, target_locale)
);
alter table public.premium_translation_working_drafts enable row level security;
alter table public.premium_translation_working_drafts force row level security;
-- No policies and no direct table grants: all access goes through the four
-- staff-checked RPCs. In particular no public content/outbox trigger exists.
revoke all on public.premium_translation_working_drafts from public, anon, authenticated;

create function premium_translation_private.assert_actor()
returns uuid language plpgsql security invoker set search_path = '' as $$
declare actor uuid := auth.uid();
begin
  if actor is null or not coalesce(public.is_staff(), false) then
    raise exception using errcode = '42501', message = 'Staff actor required';
  end if;
  return actor;
end;
$$;

create function premium_translation_private.assert_identity(kind text, identity text)
returns void language plpgsql immutable set search_path = '' as $$
begin
  if kind is null or kind not in ('literary_work','country') or identity is null
    or char_length(identity) not between 1 and 120
    or (kind = 'literary_work' and identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') then
    raise exception using errcode = '22023', message = 'Invalid candidate identity';
  end if;
end;
$$;

create function premium_translation_private.exact_object(value jsonb, keys text[])
returns boolean language sql immutable set search_path = '' as $$
  select coalesce(jsonb_typeof(value) = 'object' and value ?& keys
    and (value - keys) = '{}'::jsonb, false);
$$;

create function premium_translation_private.string_array(value jsonb, max_items integer, max_length integer)
returns boolean language plpgsql immutable set search_path = '' as $$
declare item jsonb;
begin
  if jsonb_typeof(value) is distinct from 'array' then return false; end if;
  if jsonb_array_length(value) > max_items then return false; end if;
  for item in select jsonb_array_elements(value) loop
    if jsonb_typeof(item) <> 'string' or char_length(item #>> '{}') > max_length then return false; end if;
  end loop;
  return true;
end;
$$;

create function premium_translation_private.valid_timestamp(value text)
returns boolean language plpgsql immutable set search_path = '' as $$
begin
  if value is null or value !~ '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})$' then return false; end if;
  perform value::timestamptz;
  return true;
exception when invalid_datetime_format or datetime_field_overflow then return false;
end;
$$;

create function premium_translation_private.valid_revision(value jsonb)
returns boolean language plpgsql immutable set search_path = '' as $$
begin
  if not premium_translation_private.exact_object(value, array['id','updatedAt']) then return false; end if;
  if value->'id' = 'null'::jsonb then return value->'updatedAt' = 'null'::jsonb; end if;
  return coalesce(jsonb_typeof(value->'id') = 'string'
    and value->>'id' ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
    and jsonb_typeof(value->'updatedAt') = 'string'
    and premium_translation_private.valid_timestamp(value->>'updatedAt'), false);
end;
$$;

-- ECMAScript String.trim whitespace, matching the existing Zod generators.
-- Used only for validation; candidate bytes and source snapshots stay intact.
create function premium_translation_private.trim_text(value text)
returns text language sql immutable set search_path = '' as $$
  select btrim(value, E' \t\n\r\f' || chr(11) || chr(160) || chr(5760)
    || chr(8192) || chr(8193) || chr(8194) || chr(8195) || chr(8196)
    || chr(8197) || chr(8198) || chr(8199) || chr(8200) || chr(8201)
    || chr(8202) || chr(8232) || chr(8233) || chr(8239) || chr(8287)
    || chr(12288) || chr(65279));
$$;

create function premium_translation_private.valid_country_fields(value jsonb, translated boolean)
returns boolean language plpgsql immutable set search_path = '' as $$
declare key text; max_length integer; item jsonb;
begin
  if not premium_translation_private.exact_object(value, array['name','region','continent','officialLanguage','capital',
      'description','history','historicalNote','literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology']) then return false; end if;
  foreach key in array array['name','region','continent','officialLanguage','capital','description','history','historicalNote'] loop
    max_length := case key when 'name' then 160 when 'region' then 160 when 'continent' then 160
      when 'officialLanguage' then 300 when 'capital' then 200 when 'history' then 8000 else 4000 end;
    if jsonb_typeof(value->key) <> 'string' or (translated and char_length(value->>key) > max_length) then return false; end if;
  end loop;
  if char_length(premium_translation_private.trim_text(value->>'name')) = 0 then return false; end if;
  foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces'] loop
    if not premium_translation_private.string_array(value->key,
      case when translated then case when key in ('facts','literaryPlaces') then 80 else 40 end else 10000 end,
      case when translated then case key when 'facts' then 1000 when 'literaryPlaces' then 500 else 300 end else 100000 end)
      then return false; end if;
  end loop;
  foreach key in array array['timeline','chronology'] loop
    if jsonb_typeof(value->key) <> 'array' then return false; end if;
    if jsonb_array_length(value->key) > (case when translated then 100 else 10000 end) then return false; end if;
    for item in select jsonb_array_elements(value->key) loop
      if not premium_translation_private.exact_object(item,array['year','title','description'])
        or jsonb_typeof(item->'year') <> 'string' or jsonb_typeof(item->'title') <> 'string'
        or jsonb_typeof(item->'description') <> 'string' then return false; end if;
      if translated and (char_length(item->>'year') > 80 or char_length(item->>'title') > 500
        or char_length(item->>'description') > 2000) then return false; end if;
    end loop;
  end loop;
  if translated and exists(select 1 from unnest(string_to_array(value::text,null::text)) glyph
    where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
      or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
      or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023) then return false; end if;
  return true;
end;
$$;

create function premium_translation_private.assert_shape(kind text, snapshot jsonb, source_revision jsonb,
  target_revision jsonb, payload jsonb, provenance jsonb)
returns void language plpgsql immutable set search_path = '' as $$
declare key text; item jsonb; source_item jsonb; idx integer;
begin
  if not premium_translation_private.valid_revision(target_revision)
    or not premium_translation_private.exact_object(provenance,array['provider','translatorModel','reviewerModel',
      'translatorRequestId','reviewerRequestId','generatedAt']) then
    raise exception using errcode='22023', message='Invalid candidate shape';
  end if;
  if provenance->>'provider' not in ('cloudflare','openai') or jsonb_typeof(provenance->'provider') <> 'string'
    or jsonb_typeof(provenance->'translatorModel') <> 'string' or char_length(provenance->>'translatorModel') not between 1 and 300
    or jsonb_typeof(provenance->'generatedAt') <> 'string' or not premium_translation_private.valid_timestamp(provenance->>'generatedAt') then
    raise exception using errcode='22023', message='Invalid candidate provenance';
  end if;
  foreach key in array array['reviewerModel','translatorRequestId','reviewerRequestId'] loop
    if jsonb_typeof(provenance->key) not in ('string','null') or
      (key='reviewerModel' and jsonb_typeof(provenance->key)='string' and char_length(provenance->>key) not between 1 and 300) then
      raise exception using errcode='22023', message='Invalid candidate provenance';
    end if;
  end loop;
  if kind = 'literary_work' then
    if not premium_translation_private.exact_object(source_revision,array['workId','workUpdatedAt','russianId','russianUpdatedAt'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'workId','updatedAt',source_revision->'workUpdatedAt'))
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'russianId','updatedAt',source_revision->'russianUpdatedAt'))
      or source_revision->>'workId' is null or source_revision->>'russianId' is null or target_revision->>'id' is null
      or not premium_translation_private.exact_object(snapshot,array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl',
        'description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls'])
      or not premium_translation_private.exact_object(payload,array['description','sourceLanguage','sourceUrls','bibliographicTitle'])
      or not premium_translation_private.exact_object(payload->'bibliographicTitle',array['value','provider','sourceUrl','retrievedAt']) then
      raise exception using errcode='22023', message='Invalid book candidate shape';
    end if;
    foreach key in array array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','originalLanguage','sourceLanguage'] loop
      if jsonb_typeof(snapshot->key) <> 'string' then raise exception using errcode='22023', message='Invalid book source shape'; end if;
    end loop;
    if jsonb_typeof(snapshot->'firstPublished') not in ('number','null')
      or not premium_translation_private.string_array(snapshot->'sourceUrls',10000,100000)
      or jsonb_typeof(payload->'description') <> 'string' or char_length(payload->>'description') not between 140 and 900
      or char_length(premium_translation_private.trim_text(payload->>'description')) not between 140 and 900
      or exists(select 1 from unnest(string_to_array(payload->>'description',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or (select count(*) from regexp_matches(payload->>'description','[.!?:]+(?=\s|$)','g')) not between 2 and 3
      or payload->>'sourceLanguage' is distinct from 'Russian'
      or not premium_translation_private.string_array(payload->'sourceUrls',10000,100000) then
      raise exception using errcode='22023', message='Invalid book candidate content';
    end if;
    foreach key in array array['value','provider','sourceUrl'] loop
      if jsonb_typeof(payload->'bibliographicTitle'->key) <> 'string' or char_length(payload->'bibliographicTitle'->>key)=0 then
        raise exception using errcode='22023', message='Invalid title provenance';
      end if;
    end loop;
    if jsonb_typeof(payload#>'{bibliographicTitle,retrievedAt}') not in ('string','null') then
      raise exception using errcode='22023', message='Invalid title provenance';
    end if;
    for item in select jsonb_array_elements(payload->'sourceUrls') loop
      if item #>> '{}' !~ '^https://' then raise exception using errcode='22023', message='Invalid candidate source URL'; end if;
    end loop;
  else
    if not premium_translation_private.exact_object(source_revision,array['overrideId','overrideUpdatedAt','catalogSourceHash'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt'))
      or jsonb_typeof(source_revision->'catalogSourceHash') <> 'string'
      or source_revision->>'catalogSourceHash' is null or source_revision->>'catalogSourceHash' !~ '^[a-f0-9]{64}$'
      or not premium_translation_private.valid_country_fields(snapshot,false)
      or not premium_translation_private.exact_object(payload,array['fields'])
      or not premium_translation_private.valid_country_fields(payload->'fields',true) then
      raise exception using errcode='22023', message='Invalid country candidate shape';
    end if;
    foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology'] loop
      if jsonb_array_length(snapshot->key) <> jsonb_array_length(payload->'fields'->key) then
        raise exception using errcode='22023', message='Country candidate changed item count';
      end if;
      if key in ('timeline','chronology') then
        for idx in 0..jsonb_array_length(snapshot->key)-1 loop
          if snapshot->key->idx->'year' is distinct from payload->'fields'->key->idx->'year' then
            raise exception using errcode='22023', message='Country candidate changed year';
          end if;
        end loop;
      end if;
    end loop;
  end if;
end;
$$;

-- Locks and verifies live SQL state on BOTH stage and promotion. Country static
-- catalog content is application-owned: catalogSourceHash is an additional
-- trusted-app binding, not a claim that SQL can independently read TS catalogs.
create function premium_translation_private.assert_current(kind text, identity text, snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql security invoker set search_path = '' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype;
  en public.literary_work_translations%rowtype; title_source public.literary_work_sources%rowtype;
  country public.country_profile_overrides%rowtype; current_source jsonb; urls jsonb;
begin
  if kind = 'literary_work' then
    select * into work from public.literary_works where id=identity::uuid for update;
    if not found or work.editorial_status not in ('reviewed','verified')
      or source_revision->>'workId' is distinct from identity
      or work.updated_at is distinct from (source_revision->>'workUpdatedAt')::timestamptz then
      raise exception using errcode='40001',message='Book source changed';
    end if;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru' for update;
    if not found or ru.id is distinct from (source_revision->>'russianId')::uuid
      or ru.updated_at is distinct from (source_revision->>'russianUpdatedAt')::timestamptz
      or ru.editorial_status not in ('reviewed','verified') or cardinality(ru.source_urls)=0 then
      raise exception using errcode='40001',message='Russian source changed';
    end if;
    select * into en from public.literary_work_translations where work_id=work.id and locale='en' for update;
    if not found or en.id is distinct from (target_revision->>'id')::uuid
      or en.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
      or en.translation_method <> 'machine-translation'
      or btrim(en.title)='' or exists(select 1 from unnest(string_to_array(en.title,null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,value}' is distinct from btrim(en.title)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,sourceUrl}' is distinct from snapshot->>'verifiedEnglishTitleSourceUrl'
      or not coalesce(snapshot->>'verifiedEnglishTitleSourceUrl'=any(en.source_urls),false) then
      raise exception using errcode='40001',message='English target or title ownership changed';
    end if;
    select * into title_source from public.literary_work_sources
      where work_id=work.id and source_url=snapshot->>'verifiedEnglishTitleSourceUrl'
        and provider=payload#>>'{bibliographicTitle,provider}' and 'title'=any(field_names)
      order by id limit 1 for share;
    if not found or jsonb_build_object('value',btrim(en.title),'provider',title_source.provider,
      'sourceUrl',title_source.source_url,'retrievedAt',title_source.retrieved_at) is distinct from payload->'bibliographicTitle' then
      raise exception using errcode='40001',message='Bibliographic title provenance changed';
    end if;
    current_source := jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),
      'verifiedEnglishTitleSourceUrl',title_source.source_url,'description',ru.description,
      'originalTitle',coalesce(work.original_title,''),'firstPublished',work.first_published,
      'originalLanguage',coalesce(work.original_language,''),'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    if current_source is distinct from snapshot then raise exception using errcode='40001',message='Book source snapshot changed'; end if;
    -- Ordered JS Set union used by the existing helper, preserving source rights.
    select coalesce(jsonb_agg(url order by position),'[]'::jsonb) into urls from (
      select url,min(position) position from (
        select url,position from unnest(en.source_urls) with ordinality as english(url,position) where url ~ '^https://'
        union all select url,position+cardinality(en.source_urls) from unnest(ru.source_urls) with ordinality as russian(url,position)
      ) combined group by url
    ) unique_urls;
    if urls is distinct from payload->'sourceUrls' then raise exception using errcode='40001',message='Candidate source provenance changed'; end if;
  else
    if jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt') is distinct from target_revision then
      raise exception using errcode='40001',message='Country source and target revisions differ';
    end if;
    select * into country from public.country_profile_overrides where country_id=identity for update;
    if found then
      if country.id is distinct from (target_revision->>'id')::uuid
        or country.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz then
        raise exception using errcode='40001',message='Country override changed';
      end if;
      if country.fields ? 'translations' and jsonb_typeof(country.fields->'translations') <> 'object' then
        raise exception using errcode='40001',message='Country translation ownership is ambiguous';
      end if;
      if country.fields->'translations' ? 'en' and (
        country.fields#>>'{translations,en,locale}' is distinct from 'en'
        or country.fields#>>'{translations,en,method}' is distinct from 'machine-translation') then
        raise exception using errcode='40001',message='Manual country English is protected';
      end if;
    elsif target_revision->>'id' is not null then
      raise exception using errcode='40001',message='Country override disappeared';
    end if;
  end if;
end;
$$;

create function premium_translation_private.dto(candidate public.premium_translation_working_drafts)
returns jsonb language sql stable set search_path = '' as $$
  select jsonb_build_object('id',candidate.id,'version',candidate.version,'entityType',candidate.entity_type,'entityId',candidate.entity_id,
    'targetLocale',candidate.target_locale,'humanReview',candidate.human_review,'sourceHash',candidate.source_hash,'candidateHash',candidate.candidate_hash,
    'sourceRevision',candidate.source_revision,'targetRevision',candidate.target_revision,'sourceSnapshot',candidate.source_snapshot,
    'payload',candidate.payload,'provenance',candidate.provenance,'createdAt',candidate.created_at,'createdBy',candidate.created_by);
$$;

create function public.get_premium_translation_working_draft(p_entity_type text, p_entity_id text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare candidate public.premium_translation_working_drafts%rowtype;
begin
  perform premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en';
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,
    'draft',case when candidate.id is null then null else premium_translation_private.dto(candidate) end);
end;
$$;

create function public.stage_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_source_hash text, p_source_snapshot jsonb, p_source_revision jsonb, p_target_revision jsonb,
  p_payload jsonb, p_provenance jsonb, p_expected_draft_id uuid, p_expected_draft_version bigint)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; digest text;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_expected_draft_id is not null or p_expected_draft_version is distinct from 0
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$' then
    raise exception using errcode='22023',message='Invalid initial candidate request';
  end if;
  perform premium_translation_private.assert_shape(p_entity_type,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance);
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  if exists(select 1 from public.premium_translation_working_drafts where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en') then
    raise exception using errcode='40001',message='Pending candidate must be explicitly discarded';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,p_source_snapshot,p_source_revision,p_target_revision,p_payload);
  digest := encode(sha256(convert_to(jsonb_build_object('entityType',p_entity_type,'entityId',p_entity_id,'targetLocale','en',
    'sourceHash',p_source_hash,'sourceSnapshot',p_source_snapshot,'sourceRevision',p_source_revision,
    'targetRevision',p_target_revision,'payload',p_payload,'provenance',p_provenance)::text,'UTF8')),'hex');
  insert into public.premium_translation_working_drafts(entity_type,entity_id,source_hash,candidate_hash,source_snapshot,
    source_revision,target_revision,payload,provenance,created_by)
    values(p_entity_type,p_entity_id,p_source_hash,digest,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance,actor)
    returning * into candidate;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.staged',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',digest,'sourceHash',p_source_hash,'outcome','pending'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'draft',premium_translation_private.dto(candidate));
exception when unique_violation then raise exception using errcode='40001',message='Candidate changed concurrently';
end;
$$;

create function public.promote_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text, p_source_hash text,
  p_catalog_source_hash text, p_catalog_source_fields jsonb, p_confirm_human_review boolean)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; review_time timestamptz;
  canonical_id uuid; canonical_updated_at timestamptz; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; human jsonb; meta jsonb; english jsonb; next_fields jsonb; translations jsonb;
  catalog_translations jsonb; protected_english jsonb;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_confirm_human_review is distinct from true then raise exception using errcode='22023',message='Explicit human review is required'; end if;
  if (p_entity_type='literary_work' and p_catalog_source_fields is not null)
    or (p_entity_type='country' and (jsonb_typeof(p_catalog_source_fields) is distinct from 'object'
      or (p_catalog_source_fields ? 'translations' and jsonb_typeof(p_catalog_source_fields->'translations') is distinct from 'object'))) then
    raise exception using errcode='22023',message='Invalid current catalog shape';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash or candidate.source_hash is distinct from p_source_hash
    or (p_entity_type='literary_work' and p_catalog_source_hash is not null)
    or (p_entity_type='country' and candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash) then
    raise exception using errcode='40001',message='Candidate or source changed';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,candidate.source_snapshot,
    candidate.source_revision,candidate.target_revision,candidate.payload);
  review_time := clock_timestamp();
  human := jsonb_build_object('status','approved','reviewedBy',actor,'reviewedAt',review_time);
  if p_entity_type='literary_work' then
    select * into en from public.literary_work_translations where id=(candidate.target_revision->>'id')::uuid;
    meta := case when jsonb_typeof(en.metadata)='object' then en.metadata else '{}'::jsonb end;
    meta := meta || jsonb_build_object('premiumTranslation',
      (case when jsonb_typeof(meta->'premiumTranslation')='object' then meta->'premiumTranslation' else '{}'::jsonb end)
      || jsonb_build_object('sourceHash',candidate.source_hash,'provider',candidate.provenance->'provider',
        'translatorModel',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'generatedAt',candidate.provenance->'generatedAt','bibliographicTitle',candidate.payload->'bibliographicTitle',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time));
    update public.literary_work_translations set description=candidate.payload->>'description',source_language='Russian',
      translation_method='machine-translation',editorial_status='reviewed',reviewed_at=review_time::date,
      source_urls=array(select jsonb_array_elements_text(candidate.payload->'sourceUrls')),metadata=meta
      where id=en.id returning id,updated_at into canonical_id,canonical_updated_at;
  else
    select * into country from public.country_profile_overrides where country_id=p_entity_id;
    next_fields := coalesce(country.fields,'{}'::jsonb);
    catalog_translations := case when jsonb_typeof(p_catalog_source_fields->'translations')='object'
      then p_catalog_source_fields->'translations' else '{}'::jsonb end;
    translations := case when next_fields ? 'translations' then next_fields->'translations' else catalog_translations end;
    if translations ? 'en' then protected_english := translations->'en';
    elsif catalog_translations ? 'en' then protected_english := catalog_translations->'en'; end if;
    if protected_english is not null and (protected_english->>'locale' is distinct from 'en'
      or protected_english->>'method' is distinct from 'machine-translation') then
      raise exception using errcode='40001',message='Manual catalog English is protected';
    end if;
    select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into meta from jsonb_each(candidate.payload->'fields')
      where value <> '""'::jsonb and value <> '[]'::jsonb;
    english := (case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end)
      || jsonb_build_object('locale','en','status','reviewed','method','machine-translation','sourceHash',candidate.source_hash,
        'generatedAt',candidate.provenance->'generatedAt','provider',candidate.provenance->'provider',
        'model',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'fields',meta,'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    next_fields := next_fields || jsonb_build_object('translations',translations || jsonb_build_object('en',english));
    if country.id is null then
      insert into public.country_profile_overrides(country_id,fields,updated_by)
        values(p_entity_id,next_fields,actor) returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.country_profile_overrides set fields=next_fields,updated_by=actor
        where id=country.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.promoted',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
        'sourceHash',candidate.source_hash,'canonicalId',canonical_id,'outcome','promoted'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','promoted',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
    'canonicalId',canonical_id,'canonicalUpdatedAt',canonical_updated_at,'reviewedBy',actor,'reviewedAt',review_time);
exception when unique_violation then raise exception using errcode='40001',message='Canonical target changed concurrently';
end;
$$;

create function public.discard_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash then
    raise exception using errcode='40001',message='Candidate changed';
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.discarded',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,'outcome','discarded'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','discarded',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash);
end;
$$;

revoke all on all functions in schema premium_translation_private from public, anon, authenticated;
revoke all on function public.get_premium_translation_working_draft(text,text) from public, anon, authenticated;
revoke all on function public.stage_premium_translation_working_draft(text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,uuid,bigint) from public, anon, authenticated;
revoke all on function public.promote_premium_translation_working_draft(text,text,uuid,bigint,text,text,text,jsonb,boolean) from public, anon, authenticated;
revoke all on function public.discard_premium_translation_working_draft(text,text,uuid,bigint,text) from public, anon, authenticated;
grant execute on function public.get_premium_translation_working_draft(text,text) to authenticated;
grant execute on function public.stage_premium_translation_working_draft(text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,uuid,bigint) to authenticated;
grant execute on function public.promote_premium_translation_working_draft(text,text,uuid,bigint,text,text,text,jsonb,boolean) to authenticated;
grant execute on function public.discard_premium_translation_working_draft(text,text,uuid,bigint,text) to authenticated;

-- Extend the existing private review contract to writer biographies. No queue,
-- publication trigger or canonical row is created/changed by staging a candidate.
-- Earlier migrations and the book/country contracts remain unchanged.
alter table public.premium_translation_working_drafts
  drop constraint premium_translation_working_drafts_entity_type_check,
  add constraint premium_translation_working_drafts_entity_type_check
    check (entity_type in ('literary_work','country','writer_biography')),
  drop constraint premium_translation_working_drafts_entity_id_check,
  add constraint premium_translation_working_drafts_entity_id_check
    check (char_length(entity_id) between 1 and
      case when entity_type='writer_biography' then 301 else 120 end);

create or replace function premium_translation_private.assert_identity(kind text, identity text)
returns void language plpgsql immutable set search_path = '' as $$
declare country_identity text; writer_identity text;
begin
  if kind='writer_biography' then
    country_identity := split_part(identity,':',1);
    writer_identity := split_part(identity,':',2);
    if identity is null or char_length(identity)>301
      or identity is distinct from country_identity||':'||writer_identity
      or char_length(country_identity) not between 2 and 120
      or country_identity !~ '^[a-z0-9][a-z0-9_-]*$'
      or char_length(writer_identity) not between 2 and 180
      or writer_identity ~ '[[:space:][:cntrl:]/:]' then
      raise exception using errcode='22023',message='Invalid candidate identity';
    end if;
    return;
  end if;
  if kind is null or kind not in ('literary_work','country') or identity is null
    or char_length(identity) not between 1 and 120
    or (kind = 'literary_work' and identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') then
    raise exception using errcode = '22023', message = 'Invalid candidate identity';
  end if;
end;
$$;

-- Provider projection only. The complete raw source remains in russianProfile
-- and is copied unchanged at promotion, including rights and unknown metadata.
create function premium_translation_private.writer_source_projection(raw_sources jsonb)
returns jsonb language plpgsql immutable set search_path='' as $$
declare source jsonb; field jsonb; fields jsonb; projected jsonb; result jsonb := '[]'::jsonb;
  provider text; url text; usage text; retrieved text; key text;
begin
  if jsonb_typeof(raw_sources) is distinct from 'array' then return result; end if;
  for source in select jsonb_array_elements(raw_sources) loop
    if jsonb_typeof(source) is distinct from 'object' then continue; end if;
    provider := case when jsonb_typeof(source->'provider')='string' then premium_translation_private.trim_text(source->>'provider') else '' end;
    url := case when jsonb_typeof(source->'url')='string' then premium_translation_private.trim_text(source->>'url') else '' end;
    usage := case when jsonb_typeof(source->'usage')='string' then premium_translation_private.trim_text(source->>'usage') else '' end;
    retrieved := case when jsonb_typeof(source->'retrievedAt')='string' then premium_translation_private.trim_text(source->>'retrievedAt') else '' end;
    fields := '[]'::jsonb;
    if jsonb_typeof(source->'fields')='array' then
      for field in select jsonb_array_elements(source->'fields') loop
        if jsonb_typeof(field)='string' and premium_translation_private.trim_text(field#>>'{}') in
          ('identity','life-dates','biography-facts','awards','works') then
          fields := fields || jsonb_build_array(premium_translation_private.trim_text(field#>>'{}'));
        end if;
      end loop;
    end if;
    if provider='' or url !~* '^https://' or jsonb_array_length(fields)=0
      or usage not in ('structured-data','fact-check','licensed-copy') or retrieved='' then continue; end if;
    projected := jsonb_build_object('provider',provider,'url',url,'fields',fields,'usage',usage,'retrievedAt',retrieved);
    foreach key in array array['author','title','licenseName','licenseUrl'] loop
      if jsonb_typeof(source->key)='string' then projected := projected||jsonb_build_object(key,source->key); end if;
    end loop;
    result := result||jsonb_build_array(projected);
  end loop;
  return result;
end;
$$;

create function premium_translation_private.assert_writer_shape(snapshot jsonb, source_revision jsonb,
  target_revision jsonb, payload jsonb, provenance jsonb)
returns void language plpgsql immutable set search_path='' as $$
declare russian jsonb;
begin
  if not premium_translation_private.exact_object(source_revision,
      array['countryId','writerId','overrideId','overrideUpdatedAt','catalogSourceHash','replaceEnglishTombstone'])
    or jsonb_typeof(source_revision->'countryId') is distinct from 'string'
    or jsonb_typeof(source_revision->'writerId') is distinct from 'string'
    or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt'))
    or jsonb_typeof(source_revision->'catalogSourceHash') is distinct from 'string'
    or source_revision->>'catalogSourceHash' !~ '^[a-f0-9]{64}$'
    or jsonb_typeof(source_revision->'replaceEnglishTombstone') is distinct from 'boolean'
    or not premium_translation_private.exact_object(snapshot,array['writerName','text','sourceLanguage','sources','russianProfile','catalogFields'])
    or jsonb_typeof(snapshot->'writerName') is distinct from 'string'
    or jsonb_typeof(snapshot->'text') is distinct from 'string'
    or jsonb_typeof(snapshot->'sourceLanguage') is distinct from 'string'
    or jsonb_typeof(snapshot->'sources') is distinct from 'array'
    or jsonb_typeof(snapshot->'russianProfile') is distinct from 'object'
    or jsonb_typeof(snapshot->'catalogFields') is distinct from 'object'
    or not premium_translation_private.exact_object(payload,array['text'])
    or jsonb_typeof(payload->'text') is distinct from 'string'
    or char_length(payload->>'text') not between 120 and 1600
    or char_length(premium_translation_private.trim_text(payload->>'text')) not between 120 and 1600
    or jsonb_typeof(provenance->'reviewerModel') is distinct from 'string'
    or char_length(premium_translation_private.trim_text(provenance->>'reviewerModel')) not between 1 and 300 then
    raise exception using errcode='22023',message='Invalid writer candidate shape';
  end if;
  perform premium_translation_private.assert_identity('writer_biography',(source_revision->>'countryId')||':'||(source_revision->>'writerId'));
  russian := snapshot->'russianProfile';
  if russian->>'locale' is distinct from 'ru'
    or russian->>'method' is distinct from 'editorial-original'
    or coalesce(russian->>'status','') not in ('reviewed','verified')
    or jsonb_typeof(russian->'reviewedAt') is distinct from 'string' or russian->>'reviewedAt'=''
    or jsonb_typeof(russian->'text') is distinct from 'string'
    or jsonb_typeof(russian->'sourceLanguage') is distinct from 'string'
    or jsonb_typeof(russian->'sources') is distinct from 'array'
    or snapshot->>'text' is distinct from premium_translation_private.trim_text(russian->>'text')
    or snapshot->>'sourceLanguage' is distinct from premium_translation_private.trim_text(russian->>'sourceLanguage')
    or snapshot->'sources' is distinct from premium_translation_private.writer_source_projection(russian->'sources')
    or jsonb_array_length(snapshot->'sources')=0 then
    raise exception using errcode='22023',message='Invalid writer source provenance';
  end if;
end;
$$;

-- Catalog fields/hash are a trusted server reload binding, not a claim that SQL
-- can read the checked-in TypeScript catalog. SQL independently binds the live
-- override, its exact timestamp, the raw RU profile, and parent-map ownership.
create function premium_translation_private.assert_writer_current(identity text, snapshot jsonb,
  source_revision jsonb, target_revision jsonb)
returns void language plpgsql security invoker set search_path='' as $$
declare writer public.writer_profile_overrides%rowtype; effective jsonb; translations jsonb;
  raw_english jsonb; writer_name text; override_owned boolean;
begin
  if identity is distinct from (source_revision->>'countryId')||':'||(source_revision->>'writerId')
    or jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt') is distinct from target_revision then
    raise exception using errcode='40001',message='Writer source and target identities differ';
  end if;
  select * into writer from public.writer_profile_overrides
    where country_id=source_revision->>'countryId' and writer_id=source_revision->>'writerId' for update;
  if found then
    if writer.id is distinct from (target_revision->>'id')::uuid
      or writer.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz then
      raise exception using errcode='40001',message='Writer override changed';
    end if;
  elsif target_revision->>'id' is not null then
    raise exception using errcode='40001',message='Writer override disappeared';
  end if;
  effective := snapshot->'catalogFields'||coalesce(writer.fields,'{}'::jsonb);
  translations := effective->'biographyTranslations';
  if jsonb_typeof(translations) is distinct from 'object'
    or translations->'ru' is distinct from snapshot->'russianProfile' then
    raise exception using errcode='40001',message='Writer Russian source changed';
  end if;
  writer_name := coalesce(nullif(case when jsonb_typeof(effective->'fullName')='string'
      then premium_translation_private.trim_text(effective->>'fullName') end,''),
    nullif(case when jsonb_typeof(effective->'name')='string'
      then premium_translation_private.trim_text(effective->>'name') end,''),source_revision->>'writerId');
  if writer_name is distinct from snapshot->>'writerName' then
    raise exception using errcode='40001',message='Writer source identity changed';
  end if;
  override_owned := coalesce(writer.fields ? 'biographyTranslations',false);
  if override_owned and (not (translations ? 'en') or translations->'en'='null'::jsonb)
    and source_revision->'replaceEnglishTombstone' is distinct from 'true'::jsonb then
    raise exception using errcode='40001',message='Writer English tombstone is protected';
  end if;
  raw_english := translations->'en';
  if not override_owned and translations ? 'en' and raw_english='null'::jsonb then
    raise exception using errcode='40001',message='Ambiguous catalog writer English is protected';
  end if;
  if raw_english is not null and raw_english<>'null'::jsonb and
    (jsonb_typeof(raw_english) is distinct from 'object'
      or raw_english->>'locale' is distinct from 'en'
      or raw_english->>'method' is distinct from 'machine-translation'
      or jsonb_typeof(raw_english->'text') is distinct from 'string'
      or jsonb_typeof(raw_english->'sourceLanguage') is distinct from 'string'
      or coalesce(raw_english->>'status','') not in ('draft','reviewed','verified')
      or (raw_english ? 'translationMeta' and jsonb_typeof(raw_english->'translationMeta') is distinct from 'object')) then
    raise exception using errcode='40001',message='Manual or ambiguous writer English is protected';
  end if;
end;
$$;

create or replace function premium_translation_private.assert_shape(kind text, snapshot jsonb, source_revision jsonb,
  target_revision jsonb, payload jsonb, provenance jsonb)
returns void language plpgsql immutable set search_path = '' as $$
declare key text; item jsonb; source_item jsonb; idx integer;
begin
  if not premium_translation_private.valid_revision(target_revision)
    or not premium_translation_private.exact_object(provenance,array['provider','translatorModel','reviewerModel',
      'translatorRequestId','reviewerRequestId','generatedAt']) then
    raise exception using errcode='22023', message='Invalid candidate shape';
  end if;
  if provenance->>'provider' not in ('cloudflare','openai') or jsonb_typeof(provenance->'provider') <> 'string'
    or jsonb_typeof(provenance->'translatorModel') <> 'string' or char_length(provenance->>'translatorModel') not between 1 and 300
    or jsonb_typeof(provenance->'generatedAt') <> 'string' or not premium_translation_private.valid_timestamp(provenance->>'generatedAt') then
    raise exception using errcode='22023', message='Invalid candidate provenance';
  end if;
  foreach key in array array['reviewerModel','translatorRequestId','reviewerRequestId'] loop
    if jsonb_typeof(provenance->key) not in ('string','null') or
      (key='reviewerModel' and jsonb_typeof(provenance->key)='string' and char_length(provenance->>key) not between 1 and 300) then
      raise exception using errcode='22023', message='Invalid candidate provenance';
    end if;
  end loop;
  if kind='writer_biography' then
    perform premium_translation_private.assert_writer_shape(snapshot,source_revision,target_revision,payload,provenance);
    return;
  end if;
  if kind = 'literary_work' then
    if not premium_translation_private.exact_object(source_revision,array['workId','workUpdatedAt','russianId','russianUpdatedAt'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'workId','updatedAt',source_revision->'workUpdatedAt'))
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'russianId','updatedAt',source_revision->'russianUpdatedAt'))
      or source_revision->>'workId' is null or source_revision->>'russianId' is null or target_revision->>'id' is null
      or not premium_translation_private.exact_object(snapshot,array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl',
        'description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls'])
      or not premium_translation_private.exact_object(payload,array['description','sourceLanguage','sourceUrls','bibliographicTitle'])
      or not premium_translation_private.exact_object(payload->'bibliographicTitle',array['value','provider','sourceUrl','retrievedAt']) then
      raise exception using errcode='22023', message='Invalid book candidate shape';
    end if;
    foreach key in array array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','originalLanguage','sourceLanguage'] loop
      if jsonb_typeof(snapshot->key) <> 'string' then raise exception using errcode='22023', message='Invalid book source shape'; end if;
    end loop;
    if jsonb_typeof(snapshot->'firstPublished') not in ('number','null')
      or not premium_translation_private.string_array(snapshot->'sourceUrls',10000,100000)
      or jsonb_typeof(payload->'description') <> 'string' or char_length(payload->>'description') not between 140 and 900
      or char_length(premium_translation_private.trim_text(payload->>'description')) not between 140 and 900
      or exists(select 1 from unnest(string_to_array(payload->>'description',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or (select count(*) from regexp_matches(payload->>'description','[.!?:]+(?=\s|$)','g')) not between 2 and 3
      or payload->>'sourceLanguage' is distinct from 'Russian'
      or not premium_translation_private.string_array(payload->'sourceUrls',10000,100000) then
      raise exception using errcode='22023', message='Invalid book candidate content';
    end if;
    foreach key in array array['value','provider','sourceUrl'] loop
      if jsonb_typeof(payload->'bibliographicTitle'->key) <> 'string' or char_length(payload->'bibliographicTitle'->>key)=0 then
        raise exception using errcode='22023', message='Invalid title provenance';
      end if;
    end loop;
    if jsonb_typeof(payload#>'{bibliographicTitle,retrievedAt}') not in ('string','null') then
      raise exception using errcode='22023', message='Invalid title provenance';
    end if;
    for item in select jsonb_array_elements(payload->'sourceUrls') loop
      if item #>> '{}' !~ '^https://' then raise exception using errcode='22023', message='Invalid candidate source URL'; end if;
    end loop;
  else
    if not premium_translation_private.exact_object(source_revision,array['overrideId','overrideUpdatedAt','catalogSourceHash'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt'))
      or jsonb_typeof(source_revision->'catalogSourceHash') <> 'string'
      or source_revision->>'catalogSourceHash' is null or source_revision->>'catalogSourceHash' !~ '^[a-f0-9]{64}$'
      or not premium_translation_private.valid_country_fields(snapshot,false)
      or not premium_translation_private.exact_object(payload,array['fields'])
      or not premium_translation_private.valid_country_fields(payload->'fields',true) then
      raise exception using errcode='22023', message='Invalid country candidate shape';
    end if;
    foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology'] loop
      if jsonb_array_length(snapshot->key) <> jsonb_array_length(payload->'fields'->key) then
        raise exception using errcode='22023', message='Country candidate changed item count';
      end if;
      if key in ('timeline','chronology') then
        for idx in 0..jsonb_array_length(snapshot->key)-1 loop
          if snapshot->key->idx->'year' is distinct from payload->'fields'->key->idx->'year' then
            raise exception using errcode='22023', message='Country candidate changed year';
          end if;
        end loop;
      end if;
    end loop;
  end if;
end;
$$;

create or replace function premium_translation_private.assert_current(kind text, identity text, snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql security invoker set search_path = '' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype;
  en public.literary_work_translations%rowtype; title_source public.literary_work_sources%rowtype;
  country public.country_profile_overrides%rowtype; current_source jsonb; urls jsonb;
begin
  if kind='writer_biography' then
    perform premium_translation_private.assert_writer_current(identity,snapshot,source_revision,target_revision);
    return;
  end if;
  if kind = 'literary_work' then
    select * into work from public.literary_works where id=identity::uuid for update;
    if not found or work.editorial_status not in ('reviewed','verified')
      or source_revision->>'workId' is distinct from identity
      or work.updated_at is distinct from (source_revision->>'workUpdatedAt')::timestamptz then
      raise exception using errcode='40001',message='Book source changed';
    end if;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru' for update;
    if not found or ru.id is distinct from (source_revision->>'russianId')::uuid
      or ru.updated_at is distinct from (source_revision->>'russianUpdatedAt')::timestamptz
      or ru.editorial_status not in ('reviewed','verified') or cardinality(ru.source_urls)=0 then
      raise exception using errcode='40001',message='Russian source changed';
    end if;
    select * into en from public.literary_work_translations where work_id=work.id and locale='en' for update;
    if not found or en.id is distinct from (target_revision->>'id')::uuid
      or en.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
      or en.translation_method <> 'machine-translation'
      or btrim(en.title)='' or exists(select 1 from unnest(string_to_array(en.title,null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,value}' is distinct from btrim(en.title)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,sourceUrl}' is distinct from snapshot->>'verifiedEnglishTitleSourceUrl'
      or not coalesce(snapshot->>'verifiedEnglishTitleSourceUrl'=any(en.source_urls),false) then
      raise exception using errcode='40001',message='English target or title ownership changed';
    end if;
    select * into title_source from public.literary_work_sources
      where work_id=work.id and source_url=snapshot->>'verifiedEnglishTitleSourceUrl'
        and provider=payload#>>'{bibliographicTitle,provider}' and 'title'=any(field_names)
      order by id limit 1 for share;
    if not found or jsonb_build_object('value',btrim(en.title),'provider',title_source.provider,
      'sourceUrl',title_source.source_url,'retrievedAt',title_source.retrieved_at) is distinct from payload->'bibliographicTitle' then
      raise exception using errcode='40001',message='Bibliographic title provenance changed';
    end if;
    current_source := jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),
      'verifiedEnglishTitleSourceUrl',title_source.source_url,'description',ru.description,
      'originalTitle',coalesce(work.original_title,''),'firstPublished',work.first_published,
      'originalLanguage',coalesce(work.original_language,''),'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    if current_source is distinct from snapshot then raise exception using errcode='40001',message='Book source snapshot changed'; end if;
    -- Ordered JS Set union used by the existing helper, preserving source rights.
    select coalesce(jsonb_agg(url order by position),'[]'::jsonb) into urls from (
      select url,min(position) position from (
        select url,position from unnest(en.source_urls) with ordinality as english(url,position) where url ~ '^https://'
        union all select url,position+cardinality(en.source_urls) from unnest(ru.source_urls) with ordinality as russian(url,position)
      ) combined group by url
    ) unique_urls;
    if urls is distinct from payload->'sourceUrls' then raise exception using errcode='40001',message='Candidate source provenance changed'; end if;
  else
    if jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt') is distinct from target_revision then
      raise exception using errcode='40001',message='Country source and target revisions differ';
    end if;
    select * into country from public.country_profile_overrides where country_id=identity for update;
    if found then
      if country.id is distinct from (target_revision->>'id')::uuid
        or country.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz then
        raise exception using errcode='40001',message='Country override changed';
      end if;
      if country.fields ? 'translations' and jsonb_typeof(country.fields->'translations') <> 'object' then
        raise exception using errcode='40001',message='Country translation ownership is ambiguous';
      end if;
      if country.fields->'translations' ? 'en' and (
        country.fields#>>'{translations,en,locale}' is distinct from 'en'
        or country.fields#>>'{translations,en,method}' is distinct from 'machine-translation') then
        raise exception using errcode='40001',message='Manual country English is protected';
      end if;
    elsif target_revision->>'id' is not null then
      raise exception using errcode='40001',message='Country override disappeared';
    end if;
  end if;
end;
$$;

create or replace function public.promote_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text, p_source_hash text,
  p_catalog_source_hash text, p_catalog_source_fields jsonb, p_confirm_human_review boolean)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; review_time timestamptz;
  canonical_id uuid; canonical_updated_at timestamptz; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; human jsonb; meta jsonb; english jsonb; next_fields jsonb; translations jsonb;
  catalog_translations jsonb; protected_english jsonb; writer public.writer_profile_overrides%rowtype;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_confirm_human_review is distinct from true then raise exception using errcode='22023',message='Explicit human review is required'; end if;
  if (p_entity_type='writer_biography' and jsonb_typeof(p_catalog_source_fields) is distinct from 'object')
    or (p_entity_type='literary_work' and p_catalog_source_fields is not null)
    or (p_entity_type='country' and (jsonb_typeof(p_catalog_source_fields) is distinct from 'object'
      or (p_catalog_source_fields ? 'translations' and jsonb_typeof(p_catalog_source_fields->'translations') is distinct from 'object'))) then
    raise exception using errcode='22023',message='Invalid current catalog shape';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash or candidate.source_hash is distinct from p_source_hash
    or (p_entity_type='writer_biography' and (
      candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash
      or candidate.source_snapshot->'catalogFields' is distinct from p_catalog_source_fields))
    or (p_entity_type='literary_work' and p_catalog_source_hash is not null)
    or (p_entity_type='country' and candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash) then
    raise exception using errcode='40001',message='Candidate or source changed';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,candidate.source_snapshot,
    candidate.source_revision,candidate.target_revision,candidate.payload);
  review_time := clock_timestamp();
  human := jsonb_build_object('status','approved','reviewedBy',actor,'reviewedAt',review_time);
  if p_entity_type='writer_biography' then
    select * into writer from public.writer_profile_overrides
      where country_id=candidate.source_revision->>'countryId' and writer_id=candidate.source_revision->>'writerId';
    next_fields := coalesce(writer.fields,'{}'::jsonb);
    translations := case when next_fields ? 'biographyTranslations' then next_fields->'biographyTranslations'
      else p_catalog_source_fields->'biographyTranslations' end;
    english := case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
    meta := case when jsonb_typeof(english->'translationMeta')='object' then english->'translationMeta' else '{}'::jsonb end;
    meta := meta||jsonb_build_object('provider',candidate.provenance->'provider','model',candidate.provenance->'translatorModel',
      'reviewerModel',candidate.provenance->'reviewerModel','sourceHash',candidate.source_hash,
      'generatedAt',candidate.provenance->'generatedAt','translatorRequestId',candidate.provenance->'translatorRequestId',
      'reviewerRequestId',candidate.provenance->'reviewerRequestId','humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    english := english||jsonb_build_object('locale','en','text',candidate.payload->'text','sourceLanguage','Russian',
      'status','reviewed','method','machine-translation','reviewedAt',to_char(review_time at time zone 'UTC','YYYY-MM-DD'),
      'reviewer',actor::text,'translatedFromLocale','ru','sourceTextRights','project-original',
      'sources',candidate.source_snapshot#>'{russianProfile,sources}','translationMeta',meta);
    next_fields := next_fields||jsonb_build_object('biographyTranslations',translations||jsonb_build_object('en',english));
    if writer.id is null then
      insert into public.writer_profile_overrides(country_id,writer_id,fields,updated_by)
        values(candidate.source_revision->>'countryId',candidate.source_revision->>'writerId',next_fields,actor)
        returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.writer_profile_overrides set fields=next_fields,updated_by=actor
        where id=writer.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  elsif p_entity_type='literary_work' then
    select * into en from public.literary_work_translations where id=(candidate.target_revision->>'id')::uuid;
    meta := case when jsonb_typeof(en.metadata)='object' then en.metadata else '{}'::jsonb end;
    meta := meta || jsonb_build_object('premiumTranslation',
      (case when jsonb_typeof(meta->'premiumTranslation')='object' then meta->'premiumTranslation' else '{}'::jsonb end)
      || jsonb_build_object('sourceHash',candidate.source_hash,'provider',candidate.provenance->'provider',
        'translatorModel',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'generatedAt',candidate.provenance->'generatedAt','bibliographicTitle',candidate.payload->'bibliographicTitle',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time));
    update public.literary_work_translations set description=candidate.payload->>'description',source_language='Russian',
      translation_method='machine-translation',editorial_status='reviewed',reviewed_at=review_time::date,
      source_urls=array(select jsonb_array_elements_text(candidate.payload->'sourceUrls')),metadata=meta
      where id=en.id returning id,updated_at into canonical_id,canonical_updated_at;
  else
    select * into country from public.country_profile_overrides where country_id=p_entity_id;
    next_fields := coalesce(country.fields,'{}'::jsonb);
    catalog_translations := case when jsonb_typeof(p_catalog_source_fields->'translations')='object'
      then p_catalog_source_fields->'translations' else '{}'::jsonb end;
    translations := case when next_fields ? 'translations' then next_fields->'translations' else catalog_translations end;
    if translations ? 'en' then protected_english := translations->'en';
    elsif catalog_translations ? 'en' then protected_english := catalog_translations->'en'; end if;
    if protected_english is not null and (protected_english->>'locale' is distinct from 'en'
      or protected_english->>'method' is distinct from 'machine-translation') then
      raise exception using errcode='40001',message='Manual catalog English is protected';
    end if;
    select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into meta from jsonb_each(candidate.payload->'fields')
      where value <> '""'::jsonb and value <> '[]'::jsonb;
    english := (case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end)
      || jsonb_build_object('locale','en','status','reviewed','method','machine-translation','sourceHash',candidate.source_hash,
        'generatedAt',candidate.provenance->'generatedAt','provider',candidate.provenance->'provider',
        'model',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'fields',meta,'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    next_fields := next_fields || jsonb_build_object('translations',translations || jsonb_build_object('en',english));
    if country.id is null then
      insert into public.country_profile_overrides(country_id,fields,updated_by)
        values(p_entity_id,next_fields,actor) returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.country_profile_overrides set fields=next_fields,updated_by=actor
        where id=country.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.promoted',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
        'sourceHash',candidate.source_hash,'canonicalId',canonical_id,'outcome','promoted'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','promoted',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
    'canonicalId',canonical_id,'canonicalUpdatedAt',canonical_updated_at,'reviewedBy',actor,'reviewedAt',review_time);
exception when unique_violation then raise exception using errcode='40001',message='Canonical target changed concurrently';
end;
$$;

-- New helpers are implementation details. Existing public RPC grants remain
-- unchanged; CREATE OR REPLACE retains them, and no new public endpoint is added.
revoke all on function premium_translation_private.writer_source_projection(jsonb) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_writer_shape(jsonb,jsonb,jsonb,jsonb,jsonb) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_writer_current(text,jsonb,jsonb,jsonb) from public,anon,authenticated;

-- Extend the existing private review protocol to Site Copy. Staging does not
-- write canonical settings or request publication. Existing book/country/writer
-- branches, RPC signatures, table/RPC grants and RLS remain unchanged.
alter table public.premium_translation_working_drafts
  drop constraint premium_translation_working_drafts_entity_type_check,
  add constraint premium_translation_working_drafts_entity_type_check
    check (entity_type in ('literary_work','country','writer_biography','site_copy'));

create or replace function premium_translation_private.assert_identity(kind text, identity text)
returns void language plpgsql immutable set search_path = '' as $$
declare country_identity text; writer_identity text;
begin
  if kind='site_copy' then
    if identity is null or identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' then
      raise exception using errcode='22023',message='Invalid candidate identity';
    end if;
    return;
  end if;
  if kind='writer_biography' then
    country_identity := split_part(identity,':',1);
    writer_identity := split_part(identity,':',2);
    if identity is null or char_length(identity)>301
      or identity is distinct from country_identity||':'||writer_identity
      or char_length(country_identity) not between 2 and 120
      or country_identity !~ '^[a-z0-9][a-z0-9_-]*$'
      or char_length(writer_identity) not between 2 and 180
      or writer_identity ~ '[[:space:][:cntrl:]/:]' then
      raise exception using errcode='22023',message='Invalid candidate identity';
    end if;
    return;
  end if;
  if kind is null or kind not in ('literary_work','country') or identity is null
    or char_length(identity) not between 1 and 120
    or (kind = 'literary_work' and identity !~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') then
    raise exception using errcode = '22023', message = 'Invalid candidate identity';
  end if;
end;
$$;

-- Match JavaScript/Zod maxima without altering source text: astral Unicode
-- characters occupy two UTF-16 code units, all other characters occupy one.
create function premium_translation_private.site_copy_utf16_length(value text)
returns integer language sql immutable strict set search_path='' as $$
  select char_length(value)+(select count(*)::integer
    from unnest(string_to_array(value,null::text)) glyph where ascii(glyph)>65535);
$$;

-- Full raw settings are the canonical binding. Selected item text/hash is the
-- trusted server/provider projection, not a claim that SQL reads the UI catalog.
create function premium_translation_private.assert_site_copy_shape(snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql immutable set search_path='' as $$
declare item jsonb; source_item jsonb; idx integer; keys text[] := array[]::text[]; item_key text;
begin
  if not premium_translation_private.exact_object(source_revision,array['blockId','blockUpdatedAt'])
    or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'blockId','updatedAt',source_revision->'blockUpdatedAt'))
    or source_revision->>'blockId' is null
    or jsonb_build_object('id',source_revision->'blockId','updatedAt',source_revision->'blockUpdatedAt') is distinct from target_revision
    or not premium_translation_private.exact_object(snapshot,array['settings','items'])
    or jsonb_typeof(snapshot->'settings') is distinct from 'object'
    or snapshot#>>'{settings,systemKey}' is distinct from 'site-copy-overrides'
    or jsonb_typeof(snapshot->'items') is distinct from 'array'
    or not premium_translation_private.exact_object(payload,array['items'])
    or jsonb_typeof(payload->'items') is distinct from 'array' then
    raise exception using errcode='22023',message='Invalid Site Copy candidate shape';
  end if;
  if jsonb_array_length(snapshot->'items') not between 1 and 50
    or jsonb_array_length(payload->'items') is distinct from jsonb_array_length(snapshot->'items') then
    raise exception using errcode='22023',message='Invalid Site Copy item count';
  end if;
  for idx in 0..jsonb_array_length(snapshot->'items')-1 loop
    source_item := snapshot->'items'->idx; item := payload->'items'->idx;
    if not premium_translation_private.exact_object(source_item,array['key','text','sourceHash'])
      or not premium_translation_private.exact_object(item,array['key','text'])
      or jsonb_typeof(source_item->'key') is distinct from 'string'
      or jsonb_typeof(source_item->'text') is distinct from 'string'
      or jsonb_typeof(source_item->'sourceHash') is distinct from 'string'
      or source_item->>'sourceHash' !~ '^[a-f0-9]{64}$'
      or jsonb_typeof(item->'key') is distinct from 'string'
      or jsonb_typeof(item->'text') is distinct from 'string'
      or item->'key' is distinct from source_item->'key'
      or premium_translation_private.site_copy_utf16_length(source_item->>'text') not between 1 and 4000
      or char_length(premium_translation_private.trim_text(source_item->>'text'))=0
      or premium_translation_private.site_copy_utf16_length(item->>'text') not between 1 and 4000
      or char_length(premium_translation_private.trim_text(item->>'text'))=0 then
      raise exception using errcode='22023',message='Invalid Site Copy item shape';
    end if;
    item_key := source_item->>'key';
    if premium_translation_private.site_copy_utf16_length(item_key) not between 1 and 1200
      or item_key is distinct from premium_translation_private.trim_text(item_key)
      or item_key ~ '[[:cntrl:]]'
      or item_key ~* '(^|\.)(__proto__|prototype|constructor)(\.|$)'
      or item_key=any(keys)
      or exists(select 1 from unnest(string_to_array(item->>'text',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023) then
      raise exception using errcode='22023',message='Invalid Site Copy key or English text';
    end if;
    keys := array_append(keys,item_key);
  end loop;
end;
$$;

-- Durable private provider output survives a concurrent canonical edit or
-- deletion. Validate the recorded source/ownership here; only promotion reloads
-- and locks the current singleton and enforces its full settings/CAS binding.
create function premium_translation_private.assert_site_copy_recorded(snapshot jsonb)
returns void language plpgsql immutable set search_path='' as $$
declare copy jsonb; premium jsonb; machine jsonb; source_item jsonb; item_key text; marker jsonb;
begin
  copy := snapshot->'settings'->'siteCopy'; premium := snapshot->'settings'->'premiumTranslation';
  if jsonb_typeof(copy) is distinct from 'object'
    or jsonb_typeof(copy->'ru') is distinct from 'object'
    or (copy ? 'en' and copy->'en'<>'null'::jsonb and jsonb_typeof(copy->'en') is distinct from 'object')
    or (premium is not null and premium<>'null'::jsonb and jsonb_typeof(premium) is distinct from 'object') then
    raise exception using errcode='40001',message='Site Copy locale or metadata ownership is ambiguous';
  end if;
  machine := premium->'siteCopyEn';
  if machine is not null and machine<>'null'::jsonb and jsonb_typeof(machine) is distinct from 'object' then
    raise exception using errcode='40001',message='Site Copy machine metadata is malformed';
  end if;
  for source_item in select jsonb_array_elements(snapshot->'items') loop
    item_key := source_item->>'key'; marker := machine->item_key;
    if not (copy->'ru' ? item_key) or jsonb_typeof(copy->'ru'->item_key) is distinct from 'string'
      or char_length(premium_translation_private.trim_text(copy->'ru'->>item_key))=0 then
      raise exception using errcode='40001',message='Site Copy Russian key changed';
    end if;
    if (machine ? item_key) and jsonb_typeof(marker) is distinct from 'object' then
      raise exception using errcode='40001',message='Site Copy selected machine metadata is malformed';
    end if;
    if copy->'en' ? item_key and (jsonb_typeof(copy->'en'->item_key) is distinct from 'string'
      or jsonb_typeof(marker) is distinct from 'object'
      or jsonb_typeof(marker->'sourceHash') is distinct from 'string'
      or marker->>'sourceHash' !~ '^[a-f0-9]{64}$') then
      raise exception using errcode='40001',message='Manual or ambiguous Site Copy English is protected';
    end if;
  end loop;
end;
$$;

create function premium_translation_private.assert_site_copy_current(identity text,
  snapshot jsonb, source_revision jsonb, target_revision jsonb)
returns void language plpgsql security invoker set search_path='' as $$
declare block public.homepage_blocks%rowtype; singleton_count bigint; copy jsonb;
  premium jsonb; machine jsonb; source_item jsonb; item_key text; marker jsonb;
begin
  if (source_revision->>'blockId')::uuid is distinct from identity::uuid
    or jsonb_build_object('id',source_revision->'blockId','updatedAt',source_revision->'blockUpdatedAt') is distinct from target_revision then
    raise exception using errcode='40001',message='Site Copy source and target identities differ';
  end if;
  -- Same singleton boundary as save_site_copy_block. All candidate writers take
  -- their per-entity lock before this singleton lock and then the canonical row.
  perform pg_advisory_xact_lock(188654771, 2);
  select count(*) into singleton_count from public.homepage_blocks
    where settings @> '{"systemKey":"site-copy-overrides"}'::jsonb;
  if singleton_count<>1 then
    raise exception using errcode='40001',message='Site Copy master is missing or ambiguous';
  end if;
  select * into block from public.homepage_blocks where id=identity::uuid for update;
  if not found or block.settings#>>'{systemKey}' is distinct from 'site-copy-overrides'
    or block.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
    or block.settings is distinct from snapshot->'settings' then
    raise exception using errcode='40001',message='Site Copy settings or revision changed';
  end if;
  perform premium_translation_private.assert_site_copy_recorded(snapshot);
end;
$$;

create or replace function premium_translation_private.assert_shape(kind text, snapshot jsonb, source_revision jsonb,
  target_revision jsonb, payload jsonb, provenance jsonb)
returns void language plpgsql immutable set search_path = '' as $$
declare key text; item jsonb; source_item jsonb; idx integer;
begin
  if not premium_translation_private.valid_revision(target_revision)
    or not premium_translation_private.exact_object(provenance,array['provider','translatorModel','reviewerModel',
      'translatorRequestId','reviewerRequestId','generatedAt']) then
    raise exception using errcode='22023', message='Invalid candidate shape';
  end if;
  if provenance->>'provider' not in ('cloudflare','openai') or jsonb_typeof(provenance->'provider') <> 'string'
    or jsonb_typeof(provenance->'translatorModel') <> 'string' or char_length(provenance->>'translatorModel') not between 1 and 300
    or jsonb_typeof(provenance->'generatedAt') <> 'string' or not premium_translation_private.valid_timestamp(provenance->>'generatedAt') then
    raise exception using errcode='22023', message='Invalid candidate provenance';
  end if;
  foreach key in array array['reviewerModel','translatorRequestId','reviewerRequestId'] loop
    if jsonb_typeof(provenance->key) not in ('string','null') or
      (key='reviewerModel' and jsonb_typeof(provenance->key)='string' and char_length(provenance->>key) not between 1 and 300) then
      raise exception using errcode='22023', message='Invalid candidate provenance';
    end if;
  end loop;
  if kind='site_copy' then
    perform premium_translation_private.assert_site_copy_shape(snapshot,source_revision,target_revision,payload);
    return;
  end if;
  if kind='writer_biography' then
    perform premium_translation_private.assert_writer_shape(snapshot,source_revision,target_revision,payload,provenance);
    return;
  end if;
  if kind = 'literary_work' then
    if not premium_translation_private.exact_object(source_revision,array['workId','workUpdatedAt','russianId','russianUpdatedAt'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'workId','updatedAt',source_revision->'workUpdatedAt'))
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'russianId','updatedAt',source_revision->'russianUpdatedAt'))
      or source_revision->>'workId' is null or source_revision->>'russianId' is null or target_revision->>'id' is null
      or not premium_translation_private.exact_object(snapshot,array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl',
        'description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls'])
      or not premium_translation_private.exact_object(payload,array['description','sourceLanguage','sourceUrls','bibliographicTitle'])
      or not premium_translation_private.exact_object(payload->'bibliographicTitle',array['value','provider','sourceUrl','retrievedAt']) then
      raise exception using errcode='22023', message='Invalid book candidate shape';
    end if;
    foreach key in array array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','originalLanguage','sourceLanguage'] loop
      if jsonb_typeof(snapshot->key) <> 'string' then raise exception using errcode='22023', message='Invalid book source shape'; end if;
    end loop;
    if jsonb_typeof(snapshot->'firstPublished') not in ('number','null')
      or not premium_translation_private.string_array(snapshot->'sourceUrls',10000,100000)
      or jsonb_typeof(payload->'description') <> 'string' or char_length(payload->>'description') not between 140 and 900
      or char_length(premium_translation_private.trim_text(payload->>'description')) not between 140 and 900
      or exists(select 1 from unnest(string_to_array(payload->>'description',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or (select count(*) from regexp_matches(payload->>'description','[.!?:]+(?=\s|$)','g')) not between 2 and 3
      or payload->>'sourceLanguage' is distinct from 'Russian'
      or not premium_translation_private.string_array(payload->'sourceUrls',10000,100000) then
      raise exception using errcode='22023', message='Invalid book candidate content';
    end if;
    foreach key in array array['value','provider','sourceUrl'] loop
      if jsonb_typeof(payload->'bibliographicTitle'->key) <> 'string' or char_length(payload->'bibliographicTitle'->>key)=0 then
        raise exception using errcode='22023', message='Invalid title provenance';
      end if;
    end loop;
    if jsonb_typeof(payload#>'{bibliographicTitle,retrievedAt}') not in ('string','null') then
      raise exception using errcode='22023', message='Invalid title provenance';
    end if;
    for item in select jsonb_array_elements(payload->'sourceUrls') loop
      if item #>> '{}' !~ '^https://' then raise exception using errcode='22023', message='Invalid candidate source URL'; end if;
    end loop;
  else
    if not premium_translation_private.exact_object(source_revision,array['overrideId','overrideUpdatedAt','catalogSourceHash'])
      or not premium_translation_private.valid_revision(jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt'))
      or jsonb_typeof(source_revision->'catalogSourceHash') <> 'string'
      or source_revision->>'catalogSourceHash' is null or source_revision->>'catalogSourceHash' !~ '^[a-f0-9]{64}$'
      or not premium_translation_private.valid_country_fields(snapshot,false)
      or not premium_translation_private.exact_object(payload,array['fields'])
      or not premium_translation_private.valid_country_fields(payload->'fields',true) then
      raise exception using errcode='22023', message='Invalid country candidate shape';
    end if;
    foreach key in array array['literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology'] loop
      if jsonb_array_length(snapshot->key) <> jsonb_array_length(payload->'fields'->key) then
        raise exception using errcode='22023', message='Country candidate changed item count';
      end if;
      if key in ('timeline','chronology') then
        for idx in 0..jsonb_array_length(snapshot->key)-1 loop
          if snapshot->key->idx->'year' is distinct from payload->'fields'->key->idx->'year' then
            raise exception using errcode='22023', message='Country candidate changed year';
          end if;
        end loop;
      end if;
    end loop;
  end if;
end;
$$;

create or replace function premium_translation_private.assert_current(kind text, identity text, snapshot jsonb,
  source_revision jsonb, target_revision jsonb, payload jsonb)
returns void language plpgsql security invoker set search_path = '' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype;
  en public.literary_work_translations%rowtype; title_source public.literary_work_sources%rowtype;
  country public.country_profile_overrides%rowtype; current_source jsonb; urls jsonb;
begin
  if kind='site_copy' then
    perform premium_translation_private.assert_site_copy_current(identity,snapshot,source_revision,target_revision);
    return;
  end if;
  if kind='writer_biography' then
    perform premium_translation_private.assert_writer_current(identity,snapshot,source_revision,target_revision);
    return;
  end if;
  if kind = 'literary_work' then
    select * into work from public.literary_works where id=identity::uuid for update;
    if not found or work.editorial_status not in ('reviewed','verified')
      or source_revision->>'workId' is distinct from identity
      or work.updated_at is distinct from (source_revision->>'workUpdatedAt')::timestamptz then
      raise exception using errcode='40001',message='Book source changed';
    end if;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru' for update;
    if not found or ru.id is distinct from (source_revision->>'russianId')::uuid
      or ru.updated_at is distinct from (source_revision->>'russianUpdatedAt')::timestamptz
      or ru.editorial_status not in ('reviewed','verified') or cardinality(ru.source_urls)=0 then
      raise exception using errcode='40001',message='Russian source changed';
    end if;
    select * into en from public.literary_work_translations where work_id=work.id and locale='en' for update;
    if not found or en.id is distinct from (target_revision->>'id')::uuid
      or en.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz
      or en.translation_method <> 'machine-translation'
      or btrim(en.title)='' or exists(select 1 from unnest(string_to_array(en.title,null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311
          or ascii(glyph) between 11744 and 11775 or ascii(glyph) between 42560 and 42655
          or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,value}' is distinct from btrim(en.title)
      or en.metadata#>>'{premiumTranslation,bibliographicTitle,sourceUrl}' is distinct from snapshot->>'verifiedEnglishTitleSourceUrl'
      or not coalesce(snapshot->>'verifiedEnglishTitleSourceUrl'=any(en.source_urls),false) then
      raise exception using errcode='40001',message='English target or title ownership changed';
    end if;
    select * into title_source from public.literary_work_sources
      where work_id=work.id and source_url=snapshot->>'verifiedEnglishTitleSourceUrl'
        and provider=payload#>>'{bibliographicTitle,provider}' and 'title'=any(field_names)
      order by id limit 1 for share;
    if not found or jsonb_build_object('value',btrim(en.title),'provider',title_source.provider,
      'sourceUrl',title_source.source_url,'retrievedAt',title_source.retrieved_at) is distinct from payload->'bibliographicTitle' then
      raise exception using errcode='40001',message='Bibliographic title provenance changed';
    end if;
    current_source := jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),
      'verifiedEnglishTitleSourceUrl',title_source.source_url,'description',ru.description,
      'originalTitle',coalesce(work.original_title,''),'firstPublished',work.first_published,
      'originalLanguage',coalesce(work.original_language,''),'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    if current_source is distinct from snapshot then raise exception using errcode='40001',message='Book source snapshot changed'; end if;
    -- Ordered JS Set union used by the existing helper, preserving source rights.
    select coalesce(jsonb_agg(url order by position),'[]'::jsonb) into urls from (
      select url,min(position) position from (
        select url,position from unnest(en.source_urls) with ordinality as english(url,position) where url ~ '^https://'
        union all select url,position+cardinality(en.source_urls) from unnest(ru.source_urls) with ordinality as russian(url,position)
      ) combined group by url
    ) unique_urls;
    if urls is distinct from payload->'sourceUrls' then raise exception using errcode='40001',message='Candidate source provenance changed'; end if;
  else
    if jsonb_build_object('id',source_revision->'overrideId','updatedAt',source_revision->'overrideUpdatedAt') is distinct from target_revision then
      raise exception using errcode='40001',message='Country source and target revisions differ';
    end if;
    select * into country from public.country_profile_overrides where country_id=identity for update;
    if found then
      if country.id is distinct from (target_revision->>'id')::uuid
        or country.updated_at is distinct from (target_revision->>'updatedAt')::timestamptz then
        raise exception using errcode='40001',message='Country override changed';
      end if;
      if country.fields ? 'translations' and jsonb_typeof(country.fields->'translations') <> 'object' then
        raise exception using errcode='40001',message='Country translation ownership is ambiguous';
      end if;
      if country.fields->'translations' ? 'en' and (
        country.fields#>>'{translations,en,locale}' is distinct from 'en'
        or country.fields#>>'{translations,en,method}' is distinct from 'machine-translation') then
        raise exception using errcode='40001',message='Manual country English is protected';
      end if;
    elsif target_revision->>'id' is not null then
      raise exception using errcode='40001',message='Country override disappeared';
    end if;
  end if;
end;
$$;

create or replace function public.stage_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_source_hash text, p_source_snapshot jsonb, p_source_revision jsonb, p_target_revision jsonb,
  p_payload jsonb, p_provenance jsonb, p_expected_draft_id uuid, p_expected_draft_version bigint)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; digest text;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_expected_draft_id is not null or p_expected_draft_version is distinct from 0
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$' then
    raise exception using errcode='22023',message='Invalid initial candidate request';
  end if;
  perform premium_translation_private.assert_shape(p_entity_type,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance);
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  if exists(select 1 from public.premium_translation_working_drafts where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en') then
    raise exception using errcode='40001',message='Pending candidate must be explicitly discarded';
  end if;
  if p_entity_type='site_copy' then
    if p_source_revision->>'blockId' is distinct from p_entity_id or p_target_revision->>'id' is distinct from p_entity_id then
      raise exception using errcode='22023',message='Site Copy recorded identity differs';
    end if;
    perform premium_translation_private.assert_site_copy_recorded(p_source_snapshot);
  else
    perform premium_translation_private.assert_current(p_entity_type,p_entity_id,p_source_snapshot,p_source_revision,p_target_revision,p_payload);
  end if;
  digest := encode(sha256(convert_to(jsonb_build_object('entityType',p_entity_type,'entityId',p_entity_id,'targetLocale','en',
    'sourceHash',p_source_hash,'sourceSnapshot',p_source_snapshot,'sourceRevision',p_source_revision,
    'targetRevision',p_target_revision,'payload',p_payload,'provenance',p_provenance)::text,'UTF8')),'hex');
  insert into public.premium_translation_working_drafts(entity_type,entity_id,source_hash,candidate_hash,source_snapshot,
    source_revision,target_revision,payload,provenance,created_by)
    values(p_entity_type,p_entity_id,p_source_hash,digest,p_source_snapshot,p_source_revision,p_target_revision,p_payload,p_provenance,actor)
    returning * into candidate;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.staged',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',digest,'sourceHash',p_source_hash,'outcome','pending'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'draft',premium_translation_private.dto(candidate));
exception when unique_violation then raise exception using errcode='40001',message='Candidate changed concurrently';
end;
$$;

create or replace function public.promote_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text, p_source_hash text,
  p_catalog_source_hash text, p_catalog_source_fields jsonb, p_confirm_human_review boolean)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; review_time timestamptz;
  canonical_id uuid; canonical_updated_at timestamptz; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; human jsonb; meta jsonb; english jsonb; next_fields jsonb; translations jsonb;
  catalog_translations jsonb; protected_english jsonb; writer public.writer_profile_overrides%rowtype;
  block public.homepage_blocks%rowtype; item jsonb; source_item jsonb; item_key text; machine jsonb; item_meta jsonb; idx integer;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_confirm_human_review is distinct from true then raise exception using errcode='22023',message='Explicit human review is required'; end if;
  if (p_entity_type='writer_biography' and jsonb_typeof(p_catalog_source_fields) is distinct from 'object')
    or (p_entity_type in ('literary_work','site_copy') and p_catalog_source_fields is not null)
    or (p_entity_type='country' and (jsonb_typeof(p_catalog_source_fields) is distinct from 'object'
      or (p_catalog_source_fields ? 'translations' and jsonb_typeof(p_catalog_source_fields->'translations') is distinct from 'object'))) then
    raise exception using errcode='22023',message='Invalid current catalog shape';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash or candidate.source_hash is distinct from p_source_hash
    or (p_entity_type='writer_biography' and (
      candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash
      or candidate.source_snapshot->'catalogFields' is distinct from p_catalog_source_fields))
    or (p_entity_type in ('literary_work','site_copy') and p_catalog_source_hash is not null)
    or (p_entity_type='country' and candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash) then
    raise exception using errcode='40001',message='Candidate or source changed';
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,candidate.source_snapshot,
    candidate.source_revision,candidate.target_revision,candidate.payload);
  review_time := clock_timestamp();
  human := jsonb_build_object('status','approved','reviewedBy',actor,'reviewedAt',review_time);
  if p_entity_type='site_copy' then
    select * into block from public.homepage_blocks where id=p_entity_id::uuid;
    translations := block.settings->'siteCopy';
    english := case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
    meta := case when jsonb_typeof(block.settings->'premiumTranslation')='object' then block.settings->'premiumTranslation' else '{}'::jsonb end;
    machine := case when jsonb_typeof(meta->'siteCopyEn')='object' then meta->'siteCopyEn' else '{}'::jsonb end;
    for idx in 0..jsonb_array_length(candidate.payload->'items')-1 loop
      item := candidate.payload->'items'->idx; source_item := candidate.source_snapshot->'items'->idx; item_key := item->>'key';
      item_meta := coalesce(machine->item_key,'{}'::jsonb)||jsonb_build_object('sourceHash',source_item->'sourceHash',
        'provider',candidate.provenance->'provider','model',candidate.provenance->'translatorModel',
        'reviewerModel',candidate.provenance->'reviewerModel','generatedAt',candidate.provenance->'generatedAt',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
      machine := machine||jsonb_build_object(item_key,item_meta);
      english := english||jsonb_build_object(item_key,item->'text');
    end loop;
    next_fields := block.settings||jsonb_build_object('siteCopy',translations||jsonb_build_object('en',english),
      'premiumTranslation',meta||jsonb_build_object('siteCopyEn',machine));
    update public.homepage_blocks set settings=next_fields,updated_by=actor where id=block.id
      returning id,updated_at into canonical_id,canonical_updated_at;
  elsif p_entity_type='writer_biography' then
    select * into writer from public.writer_profile_overrides
      where country_id=candidate.source_revision->>'countryId' and writer_id=candidate.source_revision->>'writerId';
    next_fields := coalesce(writer.fields,'{}'::jsonb);
    translations := case when next_fields ? 'biographyTranslations' then next_fields->'biographyTranslations'
      else p_catalog_source_fields->'biographyTranslations' end;
    english := case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
    meta := case when jsonb_typeof(english->'translationMeta')='object' then english->'translationMeta' else '{}'::jsonb end;
    meta := meta||jsonb_build_object('provider',candidate.provenance->'provider','model',candidate.provenance->'translatorModel',
      'reviewerModel',candidate.provenance->'reviewerModel','sourceHash',candidate.source_hash,
      'generatedAt',candidate.provenance->'generatedAt','translatorRequestId',candidate.provenance->'translatorRequestId',
      'reviewerRequestId',candidate.provenance->'reviewerRequestId','humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    english := english||jsonb_build_object('locale','en','text',candidate.payload->'text','sourceLanguage','Russian',
      'status','reviewed','method','machine-translation','reviewedAt',to_char(review_time at time zone 'UTC','YYYY-MM-DD'),
      'reviewer',actor::text,'translatedFromLocale','ru','sourceTextRights','project-original',
      'sources',candidate.source_snapshot#>'{russianProfile,sources}','translationMeta',meta);
    next_fields := next_fields||jsonb_build_object('biographyTranslations',translations||jsonb_build_object('en',english));
    if writer.id is null then
      insert into public.writer_profile_overrides(country_id,writer_id,fields,updated_by)
        values(candidate.source_revision->>'countryId',candidate.source_revision->>'writerId',next_fields,actor)
        returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.writer_profile_overrides set fields=next_fields,updated_by=actor
        where id=writer.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  elsif p_entity_type='literary_work' then
    select * into en from public.literary_work_translations where id=(candidate.target_revision->>'id')::uuid;
    meta := case when jsonb_typeof(en.metadata)='object' then en.metadata else '{}'::jsonb end;
    meta := meta || jsonb_build_object('premiumTranslation',
      (case when jsonb_typeof(meta->'premiumTranslation')='object' then meta->'premiumTranslation' else '{}'::jsonb end)
      || jsonb_build_object('sourceHash',candidate.source_hash,'provider',candidate.provenance->'provider',
        'translatorModel',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'generatedAt',candidate.provenance->'generatedAt','bibliographicTitle',candidate.payload->'bibliographicTitle',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time));
    update public.literary_work_translations set description=candidate.payload->>'description',source_language='Russian',
      translation_method='machine-translation',editorial_status='reviewed',reviewed_at=review_time::date,
      source_urls=array(select jsonb_array_elements_text(candidate.payload->'sourceUrls')),metadata=meta
      where id=en.id returning id,updated_at into canonical_id,canonical_updated_at;
  else
    select * into country from public.country_profile_overrides where country_id=p_entity_id;
    next_fields := coalesce(country.fields,'{}'::jsonb);
    catalog_translations := case when jsonb_typeof(p_catalog_source_fields->'translations')='object'
      then p_catalog_source_fields->'translations' else '{}'::jsonb end;
    translations := case when next_fields ? 'translations' then next_fields->'translations' else catalog_translations end;
    if translations ? 'en' then protected_english := translations->'en';
    elsif catalog_translations ? 'en' then protected_english := catalog_translations->'en'; end if;
    if protected_english is not null and (protected_english->>'locale' is distinct from 'en'
      or protected_english->>'method' is distinct from 'machine-translation') then
      raise exception using errcode='40001',message='Manual catalog English is protected';
    end if;
    select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into meta from jsonb_each(candidate.payload->'fields')
      where value <> '""'::jsonb and value <> '[]'::jsonb;
    english := (case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end)
      || jsonb_build_object('locale','en','status','reviewed','method','machine-translation','sourceHash',candidate.source_hash,
        'generatedAt',candidate.provenance->'generatedAt','provider',candidate.provenance->'provider',
        'model',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'fields',meta,'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    next_fields := next_fields || jsonb_build_object('translations',translations || jsonb_build_object('en',english));
    if country.id is null then
      insert into public.country_profile_overrides(country_id,fields,updated_by)
        values(p_entity_id,next_fields,actor) returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.country_profile_overrides set fields=next_fields,updated_by=actor
        where id=country.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.promoted',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
        'sourceHash',candidate.source_hash,'canonicalId',canonical_id,'outcome','promoted'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','promoted',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
    'canonicalId',canonical_id,'canonicalUpdatedAt',canonical_updated_at,'reviewedBy',actor,'reviewedAt',review_time);
exception when unique_violation then raise exception using errcode='40001',message='Canonical target changed concurrently';
end;
$$;

-- Read-only recovery discovery includes candidates whose canonical master was
-- deleted. Keyset paging exposes only identities, never private source/payload.
create function public.list_site_copy_premium_translation_working_drafts(
  p_after_id uuid default null, p_limit integer default 10)
returns jsonb language plpgsql security definer set search_path='' as $$
declare identities jsonb; last_id uuid; has_more boolean;
begin
  perform premium_translation_private.assert_actor();
  if p_limit is null or p_limit not between 1 and 10 then
    raise exception using errcode='22023',message='Invalid Site Copy candidate page size';
  end if;
  with requested as (
    select id,entity_id from public.premium_translation_working_drafts
    where entity_type='site_copy' and (p_after_id is null or id>p_after_id)
    order by id limit p_limit+1
  ), visible as (
    select id,entity_id from requested order by id limit p_limit
  )
  select coalesce(jsonb_agg(entity_id order by id),'[]'::jsonb),
    (select id from visible order by id desc limit 1),
    (select count(*)>p_limit from requested)
    into identities,last_id,has_more from visible;
  return jsonb_build_object('schemaVersion',1,'entityIds',identities,
    'nextCursor',case when has_more then last_id else null end);
end;
$$;
revoke all on function public.list_site_copy_premium_translation_working_drafts(uuid,integer) from public,anon,authenticated;
grant execute on function public.list_site_copy_premium_translation_working_drafts(uuid,integer) to authenticated;


revoke all on function premium_translation_private.site_copy_utf16_length(text) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_site_copy_shape(jsonb,jsonb,jsonb,jsonb) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_site_copy_recorded(jsonb) from public,anon,authenticated;
revoke all on function premium_translation_private.assert_site_copy_current(text,jsonb,jsonb,jsonb) from public,anon,authenticated;

-- Isolated native PG contract. The builder prepends unchanged canonical SQL and
-- the actual new migration. Auth/staff and public-build capture are local only.
create function public.premium_fixture_assert(ok boolean, label text)
returns void language plpgsql as $$ begin
  if ok is distinct from true then raise exception 'PREMIUM ASSERT: %',label; end if;
end; $$;
create function public.premium_fixture_error(statement text, expected text)
returns void language plpgsql as $$ declare seen text; begin
  begin execute statement; exception when others then get stacked diagnostics seen=returned_sqlstate; end;
  if seen is distinct from expected then raise exception 'Expected SQLSTATE %, got %',expected,coalesce(seen,'success'); end if;
end; $$;

create table public.premium_fixture_outbox(kind text, identity text);
create function public.premium_fixture_capture() returns trigger language plpgsql security definer as $$
begin insert into public.premium_fixture_outbox values(tg_table_name,new.id::text); return new; end; $$;
create trigger premium_fixture_book_outbox after update on public.literary_work_translations
  for each row execute function public.premium_fixture_capture();
create trigger premium_fixture_country_outbox after insert or update on public.country_profile_overrides
  for each row execute function public.premium_fixture_capture();

insert into auth.users(id) values('11111111-1111-4111-8111-111111111111'),('22222222-2222-4222-8222-222222222222'),('33333333-3333-4333-8333-333333333333');
insert into public.staff_memberships(user_id,role) values('11111111-1111-4111-8111-111111111111','editor'),('22222222-2222-4222-8222-222222222222','admin');
insert into public.literary_works(id,legacy_id,country_id,writer_id,title,slug,original_title,first_published,original_language,editorial_status,metadata,updated_at)
values('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','premium-fixture-work','fixture-country','fixture-author','Исходное название','premium-fixture-work','Original identity',1920,'Russian','reviewed',
 '{"authorPreserve":{"id":"authored"},"rights":{"owner":"author"}}','2026-10-08T10:00:00.123456Z');
insert into public.literary_work_sources(work_id,provider,source_url,field_names,usage,retrieved_at,metadata)
values('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','verified-bibliography','https://fixture.test/title',array['title'],'reference-only','2026-10-08','{"rights":"title-only"}'),
 ('aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','editorial-source','https://fixture.test/ru',array['description'],'reference-only','2026-10-08','{"rights":"reference"}');
insert into public.literary_work_translations(id,work_id,locale,title,description,source_language,translation_method,editorial_status,source_urls,reviewed_at,metadata,updated_at)
values('bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','ru','Исходное название',
 'Русский литературный текст описывает вымышленное произведение и его литературное значение для проверки сохранности редакторских данных. Второе предложение сохраняет исходное авторское содержание и подтверждённые сведения.',
 'Russian','editorial-original','reviewed',array['https://fixture.test/ru'],'2026-10-08','{"authored":"RU immutable"}','2026-10-08T10:00:00.123457Z'),
 ('cccccccc-cccc-4ccc-8ccc-cccccccccccc','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa','en','Exact Verified English Title',
 'This previously admitted English description remains available to public readers while a separate candidate awaits a human decision. Its second sentence preserves the existing reviewed editorial account and all bibliographic identifiers.',
 'Russian','machine-translation','reviewed',array['https://fixture.test/title','https://fixture.test/ru'],'2026-10-07',
 '{"authored":{"owner":"editor"},"rights":{"license":"unchanged"},"premiumTranslation":{"custom":"retained","bibliographicTitle":{"value":"Exact Verified English Title","sourceUrl":"https://fixture.test/title"}}}',
 '2026-10-08T10:00:00.123458Z');
grant select on public.literary_works,public.literary_work_translations,public.literary_work_sources to anon,authenticated;
alter table public.country_profile_overrides enable row level security;
create policy premium_fixture_country_public on public.country_profile_overrides for select to anon,authenticated using(is_enabled);
grant select on public.country_profile_overrides to anon,authenticated;

create table public.premium_fixture_saved(name text primary key, value jsonb not null);
create function public.premium_fixture_args(kind text, identity text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare work public.literary_works%rowtype; ru public.literary_work_translations%rowtype; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; source jsonb; source_revision jsonb; target_revision jsonb; payload jsonb;
begin
  if kind='literary_work' then
    select * into work from public.literary_works where id=identity::uuid;
    select * into ru from public.literary_work_translations where work_id=work.id and locale='ru';
    select * into en from public.literary_work_translations where work_id=work.id and locale='en';
    source:=jsonb_build_object('russianTitle',ru.title,'verifiedEnglishTitle',btrim(en.title),'verifiedEnglishTitleSourceUrl','https://fixture.test/title',
      'description',ru.description,'originalTitle',work.original_title,'firstPublished',work.first_published,'originalLanguage',work.original_language,
      'sourceLanguage',ru.source_language,'sourceUrls',ru.source_urls);
    source_revision:=jsonb_build_object('workId',work.id,'workUpdatedAt',work.updated_at,'russianId',ru.id,'russianUpdatedAt',ru.updated_at);
    target_revision:=jsonb_build_object('id',en.id,'updatedAt',en.updated_at);
    payload:=jsonb_build_object('description',
      'This structurally valid candidate incorrectly states that the fictional book was written on the Moon by a committee of astronomers. A human editor must check the facts and sources before this deliberately wrong account can replace the reviewed text.',
      'sourceLanguage','Russian','sourceUrls',jsonb_build_array('https://fixture.test/title','https://fixture.test/ru'),
      'bibliographicTitle',jsonb_build_object('value',en.title,'provider','verified-bibliography','sourceUrl','https://fixture.test/title','retrievedAt','2026-10-08'));
  else
    select * into country from public.country_profile_overrides where country_id=identity;
    source:=jsonb_build_object('name','Страна','region','Регион','continent','Континент','officialLanguage','Язык','capital','Столица',
      'description','Редакторский текст страны','history','','historicalNote','','literaryPeriods',jsonb_build_array('Период'),
      'literaryMovements','[]'::jsonb,'periods','[]'::jsonb,'facts',jsonb_build_array('Факт'),'literaryPlaces','[]'::jsonb,
      'timeline',jsonb_build_array(jsonb_build_object('year','1900','title','Событие','description','Описание')),'chronology','[]'::jsonb);
    source_revision:=jsonb_build_object('overrideId',country.id,'overrideUpdatedAt',country.updated_at,'catalogSourceHash',repeat('b',64));
    target_revision:=jsonb_build_object('id',country.id,'updatedAt',country.updated_at);
    payload:=jsonb_build_object('fields',jsonb_build_object('name','Country','region','Region','continent','Continent','officialLanguage','Language','capital','Capital',
      'description','A separate English candidate.','history','','historicalNote','','literaryPeriods',jsonb_build_array('Period'),
      'literaryMovements','[]'::jsonb,'periods','[]'::jsonb,'facts',jsonb_build_array('Fact'),'literaryPlaces','[]'::jsonb,
      'timeline',jsonb_build_array(jsonb_build_object('year','1900','title','Event','description','Description')),'chronology','[]'::jsonb));
  end if;
  return jsonb_build_object('kind',kind,'identity',identity,'sourceHash',repeat('a',64),'source',source,'sourceRevision',source_revision,
    'targetRevision',target_revision,'payload',payload,'provenance',jsonb_build_object('provider','cloudflare','translatorModel','fixture-translator',
      'reviewerModel','fixture-reviewer','translatorRequestId','req-1','reviewerRequestId',null,'generatedAt','2026-10-08T10:10:00.123456Z'));
end; $$;
create function public.premium_fixture_stage(args jsonb)
returns jsonb language sql security invoker as $$
 select public.stage_premium_translation_working_draft(args->>'kind',args->>'identity',args->>'sourceHash',args->'source',args->'sourceRevision',
   args->'targetRevision',args->'payload',args->'provenance',null,0);
$$;
create function public.premium_fixture_promote(draft jsonb, catalog jsonb default null, confirm boolean default true)
returns jsonb language sql security invoker as $$
 select public.promote_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash',draft->>'sourceHash',
   case when draft->>'entityType'='country' then draft#>>'{sourceRevision,catalogSourceHash}' else null end,catalog,confirm);
$$;
create function public.premium_fixture_discard(draft jsonb)
returns jsonb language sql security invoker as $$
 select public.discard_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash');
$$;
grant select,insert,update,delete on public.premium_fixture_saved to authenticated;

-- Actual role ACL, including no actor and nonstaff actor, applies to every RPC.
do $$ declare fn regprocedure; begin
 perform public.premium_fixture_assert((select relrowsecurity and relforcerowsecurity from pg_class where oid='public.premium_translation_working_drafts'::regclass),'private force RLS');
 perform public.premium_fixture_assert(not exists(select 1 from pg_trigger where tgrelid='public.premium_translation_working_drafts'::regclass and not tgisinternal),'no private triggers');
 perform public.premium_fixture_assert(not has_schema_privilege('authenticated','premium_translation_private','USAGE'),'private helper schema');
 for fn in select oid::regprocedure from pg_proc where proname in ('get_premium_translation_working_draft','stage_premium_translation_working_draft','promote_premium_translation_working_draft','discard_premium_translation_working_draft') loop
   perform public.premium_fixture_assert(not has_function_privilege('anon',fn,'EXECUTE') and has_function_privilege('authenticated',fn,'EXECUTE'),'RPC grants');
 end loop;
 set local role anon;
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country','fixture-country')$q$,'42501');
 reset role;
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','','true');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country','fixture-country')$q$,'42501');
 perform set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country','fixture-country')$q$,'42501');
 perform public.premium_fixture_error($q$select public.stage_premium_translation_working_draft('country','fixture-country',null,null,null,null,null,null,null,0)$q$,'42501');
 perform public.premium_fixture_error($q$select public.promote_premium_translation_working_draft('country','fixture-country',null,1,null,null,null,null,true)$q$,'42501');
 perform public.premium_fixture_error($q$select public.discard_premium_translation_working_draft('country','fixture-country',null,1,null)$q$,'42501');
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error('insert into public.premium_translation_working_drafts(entity_id) values(''forbidden'')','42501');
 perform public.premium_fixture_error('update public.premium_translation_working_drafts set version=2','42501');
 perform public.premium_fixture_error('delete from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('country','fixture-country')=
   '{"schemaVersion":1,"entityType":"country","entityId":"fixture-country","draft":null}'::jsonb,'explicit absent envelope');
end; $$;
select 'M07_T05_NATIVE_ACL_ACTOR_PASS';

-- Server refuses malformed JSON, forged snapshots and changed bibliography.
do $$ declare a jsonb; bad jsonb; begin
 a:=public.premium_fixture_args('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 for bad in select value from jsonb_array_elements(jsonb_build_array(
   jsonb_set(a,'{payload,extra}','true'),jsonb_set(a,'{source,extra}','true'),jsonb_set(a,'{sourceRevision,extra}','true'),
   jsonb_set(a,'{targetRevision,updatedAt}','null'),jsonb_set(a,'{provenance,reviewedBy}','"forged"'),
   jsonb_set(a,'{provenance,provider}','null'),jsonb_set(a,'{provenance,generatedAt}','"2026-10-08"'),
   jsonb_set(a,'{payload,description}','"Too short."'),jsonb_set(a,'{payload,sourceUrls}','[1]'),
   jsonb_set(a,'{payload,description}',to_jsonb(rpad('A. B.',140,' '))),
   jsonb_set(a,'{payload,description}',to_jsonb(rpad('A. B.',140,chr(160)))),
   jsonb_set(a,'{sourceRevision,workUpdatedAt}','"2026-10-08T10:00:00"')
 )) loop perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023'); end loop;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',jsonb_set(a,'{source,russianTitle}','"forged"')),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',jsonb_set(a,'{payload,bibliographicTitle,provider}','"forged"')),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',jsonb_set(a,'{payload,sourceUrls}','["https://fixture.test/title"]')),'40001');
 a:=public.premium_fixture_args('country','fixture-country');
 for bad in select value from jsonb_array_elements(jsonb_build_array(
   jsonb_set(a,'{payload,fields,extra}','true'),jsonb_set(a,'{payload,fields,facts}','[]'),
   jsonb_set(a,'{payload,fields,timeline,0,year}','"1901"'),jsonb_set(a,'{payload,fields,name}','"Страна"'),
   jsonb_set(a,'{payload,fields,name}',to_jsonb(E' \t\r\n'||chr(160)||chr(65279))),
   jsonb_set(a,'{payload,fields,timeline,0,extra}','true'),jsonb_set(a,'{sourceRevision,catalogSourceHash}','"bad"')
 )) loop perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023'); end loop;
end; $$;
select 'M07_T05_NATIVE_SHAPE_SOURCE_PASS';

do $$ declare a jsonb; bad jsonb; kind text; key text; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach kind in array array['literary_work','country'] loop
   a:=public.premium_fixture_args(kind,case when kind='country' then 'null-shape' else 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa' end);
   foreach key in array array['source','sourceRevision','targetRevision','payload','provenance'] loop
     bad:=jsonb_set(a,array[key],'null'::jsonb);
     perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
     bad:=a-key;
     perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
   end loop;
 end loop;
end; $$;
select 'M07_T05_NATIVE_NULL_BOUNDARY_PASS';

insert into public.premium_fixture_saved values('before-work',(select to_jsonb(w) from public.literary_works w)),
 ('before-ru',(select to_jsonb(t) from public.literary_work_translations t where locale='ru')),
 ('before-en',(select to_jsonb(t) from public.literary_work_translations t where locale='en')),
 ('before-sources',(select jsonb_agg(to_jsonb(s) order by id) from public.literary_work_sources s));
truncate public.premium_fixture_outbox;
do $$ declare a jsonb; d jsonb; actual_hash text; begin
 a:=public.premium_fixture_args('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(a)->'draft';
 insert into public.premium_fixture_saved values('book-pending',d),('book-args',a);
 perform public.premium_fixture_assert(d->>'humanReview'='pending' and d->>'createdBy'='11111111-1111-4111-8111-111111111111','server actor pending');
 perform public.premium_fixture_assert(d->'sourceRevision'=a->'sourceRevision' and d->'targetRevision'=a->'targetRevision' and d->'payload'=a->'payload'
   and d->'provenance'=a->'provenance' and d->'sourceSnapshot'=a->'source','exact ACK full precision');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa')->'draft'=d,'exact saved read');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,null,false)',d),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,null,null)',d),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',jsonb_set(d,'{candidateHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',jsonb_set(d,'{sourceHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{version}','2')),'40001');
 reset role;
 select encode(sha256(convert_to(jsonb_build_object('entityType',d->'entityType','entityId',d->'entityId','targetLocale','en',
   'sourceHash',d->'sourceHash','sourceSnapshot',d->'sourceSnapshot','sourceRevision',d->'sourceRevision','targetRevision',d->'targetRevision',
   'payload',d->'payload','provenance',d->'provenance')::text,'UTF8')),'hex') into actual_hash;
 perform public.premium_fixture_assert(d->>'candidateHash'=actual_hash,'entire immutable candidate hash');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stage no canonical outbox');
 perform public.premium_fixture_assert((select to_jsonb(w)=(select value from public.premium_fixture_saved where name='before-work') from public.literary_works w),'stage complete work');
 perform public.premium_fixture_assert((select to_jsonb(t)=(select value from public.premium_fixture_saved where name='before-ru') from public.literary_work_translations t where locale='ru'),'stage complete RU');
 perform public.premium_fixture_assert((select to_jsonb(t)=(select value from public.premium_fixture_saved where name='before-en') from public.literary_work_translations t where locale='en'),'stage complete EN');
 set local role anon;
 perform public.premium_fixture_assert((select count(*)=1 from public.literary_work_translations where locale='en'),'existing admitted machine remains public');
end; $$;
select 'M07_T05_NATIVE_PRIVATE_PENDING_PASS';

-- Each stale-source/target test rolls the canonical mutation back in a nested
-- subtransaction after observing the actual RPC conflict, retaining one receipt.
do $$ declare d jsonb; field text; begin
 select value into d from public.premium_fixture_saved where name='book-pending';
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 foreach field in array array['work','ru','en','manual','title','title-source'] loop
   begin
     if field='work' then update public.literary_works set original_title='changed';
     elsif field='ru' then update public.literary_work_translations set description=description||' ' where locale='ru';
     elsif field='en' then update public.literary_work_translations set description=description||' ' where locale='en';
     elsif field='manual' then update public.literary_work_translations set translation_method='human-translation' where locale='en';
     elsif field='title' then update public.literary_work_translations set title='New verified title' where locale='en';
     else delete from public.literary_work_sources where provider='verified-bibliography'; end if;
     set local role authenticated;
     perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',d),'40001');
     reset role;
     raise exception using errcode='P0002',message='rollback test drift';
   exception when no_data_found then null; end;
 end loop;
 -- Manual target also prevents initial staging, independent of pending check.
 begin
   delete from public.premium_translation_working_drafts;
   update public.literary_work_translations set translation_method='human-translation' where locale='en';
   set local role authenticated;
   perform public.premium_fixture_error($q$select public.premium_fixture_stage(public.premium_fixture_args('literary_work','aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'))$q$,'40001');
   reset role;
   raise exception using errcode='P0002',message='rollback manual control';
 exception when no_data_found then null; end;
end; $$;
select 'M07_T05_NATIVE_BOOK_CAS_MANUAL_PASS';

do $$ declare d jsonb; receipt jsonb; before_en jsonb; begin
 select value into d from public.premium_fixture_saved where name='book-pending';
 select value into before_en from public.premium_fixture_saved where name='before-en';
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 receipt:=public.premium_fixture_promote(d);
 insert into public.premium_fixture_saved values('book-promoted',receipt);
 perform public.premium_fixture_assert(receipt->>'state'='promoted' and receipt->>'reviewedBy'='22222222-2222-4222-8222-222222222222','human actor receipt');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('literary_work',d->>'entityId')->'draft'='null'::jsonb,'consumed exact book');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb)',d),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',d),'40001');
 reset role;
 perform public.premium_fixture_assert((select description=d#>>'{payload,description}' and title=before_en->>'title'
   and metadata->'authored'=before_en#>'{metadata,authored}' and metadata->'rights'=before_en#>'{metadata,rights}'
   and metadata#>>'{premiumTranslation,custom}'='retained' and editorial_status='reviewed'
   and metadata#>>'{premiumTranslation,humanReview,reviewedBy}'=receipt->>'reviewedBy'
   and metadata#>>'{premiumTranslation,humanReview,reviewedAt}'=receipt->>'reviewedAt'
   and metadata#>>'{premiumTranslation,translatorModel}'='fixture-translator'
   from public.literary_work_translations where locale='en'),'stored payload + preserved metadata + real human provenance');
 perform public.premium_fixture_assert((select to_jsonb(w)=(select value from public.premium_fixture_saved where name='before-work') from public.literary_works w),'promote work preserved');
 perform public.premium_fixture_assert((select to_jsonb(t)=(select value from public.premium_fixture_saved where name='before-ru') from public.literary_work_translations t where locale='ru'),'promote RU preserved');
 perform public.premium_fixture_assert((select jsonb_agg(to_jsonb(s) order by id)=(select value from public.premium_fixture_saved where name='before-sources') from public.literary_work_sources s),'sources rights preserved');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one canonical promotion');
end; $$;
select 'M07_T05_NATIVE_BOOK_PROMOTION_PASS';

-- Country absent override: no canonical insertion before approval. The trusted
-- current catalog includes other locales which must survive the new EN override.
truncate public.premium_fixture_outbox;
do $$ declare d jsonb; receipt jsonb; catalog jsonb := '{"name":"Страна","translations":{"ru":{"authored":"RU"},"fr":{"authored":"FR"}}}'; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','fixture-country'))->'draft';
 insert into public.premium_fixture_saved values('country-pending',d);
 reset role;
 perform public.premium_fixture_assert((select count(*)=0 from public.country_profile_overrides),'pending country absent unchanged');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'country pending no outbox');
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,'[]'),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,'{"translations":"opaque authored data"}'),'22023');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',jsonb_set(d,'{sourceRevision,catalogSourceHash}',to_jsonb(repeat('c',64))),catalog),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,'{"translations":{"en":null}}'),'40001');
 receipt:=public.premium_fixture_promote(d,catalog);
 insert into public.premium_fixture_saved values('country-promoted',receipt);
 reset role;
 perform public.premium_fixture_assert((select fields#>'{translations,ru}'=catalog#>'{translations,ru}' and fields#>'{translations,fr}'=catalog#>'{translations,fr}'
   and fields#>>'{translations,en,status}'='reviewed' and fields#>>'{translations,en,method}'='machine-translation'
   and fields#>>'{translations,en,humanReview,reviewedBy}'=receipt->>'reviewedBy'
   and not (fields#>'{translations,en,fields}')?'history' and not (fields#>'{translations,en,fields}')?'chronology'
   from public.country_profile_overrides where country_id='fixture-country'),'catalog locales + compact fields + human review');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one new country approval');
end; $$;
select 'M07_T05_NATIVE_COUNTRY_CATALOG_PASS';

insert into public.country_profile_overrides(country_id,fields,is_enabled,updated_by) values
 ('own-machine','{"name":"Авторская страна","coordinates":[10,20],"rights":{"source":"retain"},"translations":{"fr":{"human":"FR"},"en":{"locale":"en","method":"machine-translation","status":"reviewed","custom":"retain"}}}',false,'11111111-1111-4111-8111-111111111111'),
 ('hidden-human','{"translations":{"fr":{"human":"FR"}}}',true,'11111111-1111-4111-8111-111111111111'),
 ('own-human','{"translations":{"en":{"locale":"en","method":"human-translation","fields":{"name":"Human country"}}}}',true,'11111111-1111-4111-8111-111111111111');
insert into public.premium_fixture_saved values('country-before',(select to_jsonb(c) from public.country_profile_overrides c where country_id='own-machine'));
truncate public.premium_fixture_outbox;
do $$ declare d jsonb; receipt jsonb; before_country jsonb; field text; catalog jsonb := '{"translations":{"en":{"locale":"en","method":"human-translation"},"de":{"keep":"base"}}}'; begin
 select value into before_country from public.premium_fixture_saved where name='country-before';
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 perform public.premium_fixture_error($q$select public.premium_fixture_stage(public.premium_fixture_args('country','own-human'))$q$,'40001');
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','hidden-human'))->'draft';
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,catalog),'40001');
 perform public.premium_fixture_discard(d);
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','own-machine'))->'draft';
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(c)=before_country from public.country_profile_overrides c where country_id='own-machine'),'whole override unchanged while pending');
 foreach field in array array['source','manual','delete'] loop
   begin
     if field='source' then update public.country_profile_overrides set fields=fields||'{"name":"changed"}' where country_id='own-machine';
     elsif field='manual' then update public.country_profile_overrides set fields=jsonb_set(fields,'{translations,en,method}','"human-translation"') where country_id='own-machine';
     else delete from public.country_profile_overrides where country_id='own-machine'; end if;
     set local role authenticated;
     perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,catalog),'40001');
     reset role;
     raise exception using errcode='P0002',message='rollback country drift';
   exception when no_data_found then null; end;
 end loop;
 set local role authenticated;
 receipt:=public.premium_fixture_promote(d,catalog);
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,%L::jsonb)',d,catalog),'40001');
 reset role;
 perform public.premium_fixture_assert((select not is_enabled and fields-'translations'=(before_country->'fields')-'translations'
   and fields#>'{translations,fr}'=before_country#>'{fields,translations,fr}' and not (fields->'translations')?'de'
   and fields#>>'{translations,en,custom}'='retain' and fields#>>'{translations,en,reviewedBy}'=receipt->>'reviewedBy'
   from public.country_profile_overrides where country_id='own-machine'),'own machine precedence preserves override map flags rights');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'country canonical writes only approval');
end; $$;
select 'M07_T05_NATIVE_COUNTRY_CAS_MANUAL_PASS';

-- Lost stage ACK is recoverable through exact get; stale candidate can be
-- discarded even after a manual winner, but wrong version/hash cannot consume.
truncate public.premium_fixture_outbox;
do $$ declare d jsonb; later jsonb; before_country jsonb; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_stage(public.premium_fixture_args('country','late-override'));
 d:=public.get_premium_translation_working_draft('country','late-override')->'draft';
 reset role;
 insert into public.country_profile_overrides(country_id,fields) values('late-override','{"translations":{"en":{"locale":"en","method":"human-translation","fields":{"name":"Manual winner"}}}}');
 select to_jsonb(c) into before_country from public.country_profile_overrides c where country_id='late-override';
 truncate public.premium_fixture_outbox;
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_promote(%L::jsonb,''{}''::jsonb)',d),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{candidateHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('country','late-override')->'draft'=d,'stale still inspectable');
 perform public.premium_fixture_assert(public.premium_fixture_discard(d)->>'state'='discarded','exact stale discard');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',d),'40001');
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(c)=before_country from public.country_profile_overrides c where country_id='late-override'),'discard preserves manual winner');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'discard no canonical outbox');
 set local role authenticated;
 d:=public.premium_fixture_stage(public.premium_fixture_args('country','restage'))->'draft';
 perform public.premium_fixture_discard(d);
 later:=public.premium_fixture_stage(public.premium_fixture_args('country','restage'))->'draft';
 perform public.premium_fixture_assert(later->>'id'<>d->>'id','restage fresh identity');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',d),'40001');
 perform public.premium_fixture_discard(later);
end; $$;
select 'M07_T05_NATIVE_DISCARD_REPLAY_PASS';

do $$ begin
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_translation_working_drafts),'all candidates consumed explicitly');
 perform public.premium_fixture_assert(not exists(select 1 from public.admin_audit_log where action like 'premium_translation.candidate.%'
   and (metadata-array['draftId','version','candidateHash','sourceHash','canonicalId','outcome'])<>'{}'::jsonb),'audit only IDs hashes outcomes');
 perform public.premium_fixture_assert((select count(*)>5 from public.admin_audit_log where action like 'premium_translation.candidate.%'),'durable audit outcomes');
 perform public.premium_fixture_assert(not exists(select 1 from public.admin_audit_log where action like 'premium_translation.candidate.%' and
   metadata::text like '%astronomers%'),'no candidate prose in audit');
end; $$;
select 'M07_T05_NATIVE_AUDIT_FINAL_PASS';
select 'M07_T05_DTO='||jsonb_object_agg(name,value)::text from public.premium_fixture_saved
 where name in ('book-pending','country-pending','book-promoted','country-promoted','book-args');
select 'M07_T05_SUMMARY='||jsonb_build_object('groups',10,'providerCalls',0,'canonicalStagingWrites',0,
 'pendingNeverOverwritten',true,'explicitReviewActor',true,'protectedManualAndAdmittedMachine',true,
 'countryCatalogBoundary','trusted application reload; SQL override CAS and ownership','allCandidatesConsumed',true)::text;

-- Additive native PostgreSQL fixture. Run after the unchanged book/country
-- fixture, actual writer table/revision prefix, and both private migrations.
-- Auth/staff and outbox capture are synthetic local boundaries, not managed E2E.
reset role;
create trigger premium_fixture_writer_outbox after insert or update on public.writer_profile_overrides
  for each row execute function public.premium_fixture_capture();

create function public.writer_private_fixture_catalog()
returns jsonb language sql immutable as $$
select '{"fullName":"  Иван Автор  ","name":"Автор","rights":{"owner":"author","permission":"unchanged"},
 "biographyTranslations":{"ru":{"locale":"ru","text":"  Иван Автор родился в 1900 году и работал в Архиве. Он создал роман в 1930 году, преподавал литературу и подготовил исследование сохранившихся рукописей.  ",
 "sourceLanguage":" Russian ","status":"reviewed","method":"editorial-original","reviewedAt":"2026-10-01","reviewer":"Human RU editor",
 "sourceTextRights":"project-original","rights":{"license":"RAW RU RIGHTS"},"custom":{"nested":[null,true,"RAW RU VALUE"]},
 "sources":[{"provider":" Archive ","url":"https://fixture.test/writer","fields":["biography-facts"],"usage":"fact-check","retrievedAt":"2026-10-01",
   "author":"Original researcher","title":"Raw archive title","licenseName":"Permission","licenseUrl":"https://fixture.test/permission",
   "customRights":{"permissionId":"RAW-SOURCE-RIGHTS","conditions":["full-credit"]}}]},
 "en":{"locale":"en","text":"Previously admitted machine English remains visible while a private candidate awaits explicit human review. This existing biography and its metadata must remain untouched during staging.",
 "sourceLanguage":"Russian","status":"reviewed","method":"machine-translation","reviewedAt":"2026-10-02","sourceTextRights":"project-original",
 "customEnglish":{"editor":"EN AUTHOR METADATA"},"rights":{"credit":"KEEP EN RIGHTS"},
 "sources":[{"url":"https://fixture.test/previous-source","custom":"previous provenance"}],
 "translationMeta":{"customMachine":{"preserve":"EN META"},"generatedAt":"2026-10-01T01:00:00Z"}},
 "fr":{"locale":"fr","text":"Texte original conservé","rights":"OTHER LOCALE RIGHTS"}}}'::jsonb;
$$;

create function public.writer_private_fixture_args(identity text, catalog jsonb default public.writer_private_fixture_catalog(), replacement boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
declare writer public.writer_profile_overrides%rowtype; effective jsonb; russian jsonb; source jsonb;
begin
 select * into writer from public.writer_profile_overrides where country_id=split_part(identity,':',1) and writer_id=split_part(identity,':',2);
 effective:=catalog||coalesce(writer.fields,'{}'::jsonb); russian:=effective#>'{biographyTranslations,ru}';
 source:=jsonb_build_object('writerName',coalesce(nullif(btrim(effective->>'fullName'),''),nullif(btrim(effective->>'name'),''),split_part(identity,':',2)),
   'text',btrim(russian->>'text'),'sourceLanguage',btrim(russian->>'sourceLanguage'),
   'sources','[{"provider":"Archive","url":"https://fixture.test/writer","fields":["biography-facts"],"usage":"fact-check","retrievedAt":"2026-10-01","author":"Original researcher","title":"Raw archive title","licenseName":"Permission","licenseUrl":"https://fixture.test/permission"}]'::jsonb,
   'russianProfile',russian,'catalogFields',catalog);
 return jsonb_build_object('kind','writer_biography','identity',identity,'sourceHash',repeat('a',64),'source',source,
   'sourceRevision',jsonb_build_object('countryId',split_part(identity,':',1),'writerId',split_part(identity,':',2),
     'overrideId',writer.id,'overrideUpdatedAt',writer.updated_at,'catalogSourceHash',repeat('b',64),'replaceEnglishTombstone',replacement),
   'targetRevision',jsonb_build_object('id',writer.id,'updatedAt',writer.updated_at),
   'payload',jsonb_build_object('text','Ivan Author was born in 1900 and worked at the Archive, where he studied surviving manuscripts. He wrote a novel in 1930 and also taught literature during his scholarly career.'),
   'provenance',jsonb_build_object('provider','cloudflare','translatorModel','fixture-translator','reviewerModel','fixture-reviewer',
     'translatorRequestId','writer-request','reviewerRequestId',null,'generatedAt','2026-10-01T01:00:00.123456Z'));
end;
$$;
create function public.writer_private_fixture_promote(draft jsonb, catalog jsonb default public.writer_private_fixture_catalog(), confirm boolean default true)
returns jsonb language sql security invoker as $$
 select public.promote_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash',draft->>'sourceHash',draft#>>'{sourceRevision,catalogSourceHash}',catalog,confirm);
$$;

-- No new public API/grants, helper schema access, direct DML, or trigger leak.
do $$ declare fn regprocedure; begin
 perform public.premium_fixture_assert((select relrowsecurity and relforcerowsecurity from pg_class where oid='public.premium_translation_working_drafts'::regclass),'writer private force RLS');
 perform public.premium_fixture_assert(not exists(select 1 from pg_trigger where tgrelid='public.premium_translation_working_drafts'::regclass and not tgisinternal),'writer stage has no publication trigger');
 for fn in select oid::regprocedure from pg_proc where pronamespace='premium_translation_private'::regnamespace loop
   perform public.premium_fixture_assert(not has_function_privilege('anon',fn,'EXECUTE') and not has_function_privilege('authenticated',fn,'EXECUTE'),'writer helpers private');
 end loop;
 set local role anon;
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one')$q$,'42501');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','','true');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one')$q$,'42501');
 perform set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one')$q$,'42501');
 perform public.premium_fixture_error($q$select public.premium_fixture_stage(public.writer_private_fixture_args('fixture-country:writer-one'))$q$,'42501');
 perform public.premium_fixture_error($q$select public.promote_premium_translation_working_draft('writer_biography','fixture-country:writer-one',null,1,null,null,null,'{}',true)$q$,'42501');
 perform public.premium_fixture_error($q$select public.discard_premium_translation_working_draft('writer_biography','fixture-country:writer-one',null,1,null)$q$,'42501');
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error($q$insert into public.premium_translation_working_drafts(entity_id) values('writer-direct')$q$,'42501');
 perform public.premium_fixture_error('update public.premium_translation_working_drafts set version=2','42501');
 perform public.premium_fixture_error('delete from public.premium_translation_working_drafts','42501');
end; $$;
select 'M07_WRITER_NATIVE_ACL_PASS';

-- The public/canonical row and revision/outbox graph do not change on stage.
insert into public.writer_profile_overrides(id,country_id,writer_id,fields,is_enabled,updated_at)
 values('dddddddd-dddd-4ddd-8ddd-dddddddddddd','fixture-country','writer-one',public.writer_private_fixture_catalog()||'{"authoredOverride":{"keep":"ALL FIELDS"}}',false,'2026-10-09T10:00:00.123456Z');
do $$ declare a jsonb; d jsonb; staged jsonb; read_receipt jsonb; before_row jsonb; revision_count bigint; receipt jsonb; after_row jsonb; begin
 select to_jsonb(w) into before_row from public.writer_profile_overrides w where writer_id='writer-one';
 select count(*) into revision_count from public.writer_profile_override_revisions;
 truncate public.premium_fixture_outbox;
 a:=public.writer_private_fixture_args('fixture-country:writer-one');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 staged:=public.premium_fixture_stage(a); d:=staged->'draft';
 read_receipt:=public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one');
 perform public.premium_fixture_assert(d->>'humanReview'='pending','writer pending review');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('writer_biography','fixture-country:writer-one')->'draft'=d,'writer retained exact draft');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb,public.writer_private_fixture_catalog(),false)',d),'22023');
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(w)=before_row from public.writer_profile_overrides w where writer_id='writer-one'),'stage preserves full disabled canonical row');
 perform public.premium_fixture_assert((select count(*)=revision_count from public.writer_profile_override_revisions),'stage no canonical revision');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stage no publication outbox');
 insert into public.premium_fixture_saved values('writer-pending',d),('writer-args',a),('writer-stage',staged),('writer-read',read_receipt);
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 set local timezone='Pacific/Kiritimati';
 receipt:=public.writer_private_fixture_promote(d);
 reset role;
 select to_jsonb(w) into after_row from public.writer_profile_overrides w where writer_id='writer-one';
 perform public.premium_fixture_assert(after_row->'is_enabled'='false'::jsonb,'promotion retains disabled flag');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,ru}'=before_row#>'{fields,biographyTranslations,ru}','raw RU including spaces and rights retained');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,fr}'=before_row#>'{fields,biographyTranslations,fr}','other locale retained');
 perform public.premium_fixture_assert(((after_row->'fields')-'biographyTranslations')=((before_row->'fields')-'biographyTranslations'),'unrelated override fields retained');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,en,sources}'=before_row#>'{fields,biographyTranslations,ru,sources}','raw source rights inherited without projection');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,en,rights}'=before_row#>'{fields,biographyTranslations,en,rights}','EN rights retained');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,en,customEnglish}'=before_row#>'{fields,biographyTranslations,en,customEnglish}','EN unknown metadata retained');
 perform public.premium_fixture_assert(after_row#>'{fields,biographyTranslations,en,translationMeta,customMachine}'=before_row#>'{fields,biographyTranslations,en,translationMeta,customMachine}','machine unknown metadata retained');
 perform public.premium_fixture_assert(after_row#>>'{fields,biographyTranslations,en,text}'=a#>>'{payload,text}','exact candidate text promoted');
 perform public.premium_fixture_assert(after_row#>>'{fields,biographyTranslations,en,reviewedAt}'=to_char((receipt->>'reviewedAt')::timestamptz at time zone 'UTC','YYYY-MM-DD'),'human review date UTC');
 perform public.premium_fixture_assert(after_row#>>'{fields,biographyTranslations,en,translationMeta,humanReview,reviewedBy}'='22222222-2222-4222-8222-222222222222','reviewer is current human actor');
 perform public.premium_fixture_assert((select count(*)=revision_count+1 from public.writer_profile_override_revisions),'one promotion revision');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one promotion outbox');
 perform public.premium_fixture_assert(not exists(select 1 from public.premium_translation_working_drafts where id=(d->>'id')::uuid),'promotion consumes private candidate');
 insert into public.premium_fixture_saved values('writer-promoted',receipt),('writer-after',after_row);
end; $$;
select 'M07_WRITER_NATIVE_STAGE_PROMOTE_PRESERVATION_PASS';

-- Malformed source/payload/reviewer and mismatched writer/source/target identity.
do $$ declare a jsonb; bad jsonb; begin
 a:=public.writer_private_fixture_args('fixture-country:writer-one');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 bad:=jsonb_set(a,'{provenance,reviewerModel}','null');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
 bad:=jsonb_set(a,'{payload,text}','"Too short"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
 bad:=jsonb_set(a,'{source,sources,0,licenseName}','"Forged permission"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
 bad:=jsonb_set(a,'{source,russianProfile,rights,license}','"Forged raw rights"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'40001');
 bad:=jsonb_set(a,'{sourceRevision,writerId}','"writer-other"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'40001');
 bad:=jsonb_set(a,'{targetRevision,id}','"eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'40001');
 bad:=jsonb_set(a,'{sourceRevision,replaceEnglishTombstone}','"true"');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',bad),'22023');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer:other')$q$,'22023');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer/other')$q$,'22023');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('writer_biography','fixture-country:writer other')$q$,'22023');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('country',repeat('a',121))$q$,'22023');
end; $$;
select 'M07_WRITER_NATIVE_SHAPE_IDENTITY_PASS';

-- Authored/ambiguous EN and parent-map tombstones must not be overwritten.
do $$ declare catalog jsonb; a jsonb; d jsonb; value jsonb; before_row jsonb; begin
 catalog:=public.writer_private_fixture_catalog();
 foreach value in array array['"human-translation"'::jsonb,'"editorial-original"'::jsonb,'"licensed-source"'::jsonb,'null'::jsonb] loop
   a:=public.writer_private_fixture_args('fixture-country:manual-catalog',jsonb_set(catalog,'{biographyTranslations,en,method}',value));
   set local role authenticated;
   perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
   perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
   reset role;
 end loop;
 a:=public.writer_private_fixture_args('fixture-country:null-catalog',jsonb_set(catalog,'{biographyTranslations,en}','null'));
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 reset role;
 foreach value in array array['null'::jsonb,'"legacy metadata"'::jsonb,'[]'::jsonb] loop
   a:=public.writer_private_fixture_args('fixture-country:ambiguous-metadata',jsonb_set(catalog,'{biographyTranslations,en,translationMeta}',value));
   set local role authenticated;
   perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
   reset role;
 end loop;
 insert into public.writer_profile_overrides(country_id,writer_id,fields)
   values('fixture-country','tombstone',jsonb_build_object('biographyTranslations',jsonb_build_object('ru',catalog#>'{biographyTranslations,ru}')));
 a:=public.writer_private_fixture_args('fixture-country:tombstone');
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 reset role;
 update public.writer_profile_overrides set fields=jsonb_set(fields,'{biographyTranslations,en}','null') where writer_id='tombstone';
 a:=public.writer_private_fixture_args('fixture-country:tombstone');
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 reset role;
 select to_jsonb(w) into before_row from public.writer_profile_overrides w where writer_id='tombstone';
 a:=public.writer_private_fixture_args('fixture-country:tombstone',catalog,true);
 set local role authenticated;
 d:=public.premium_fixture_stage(a)->'draft';
 perform public.premium_fixture_discard(d);
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(w)=before_row from public.writer_profile_overrides w where writer_id='tombstone'),'explicit replacement staging/discard retains tombstone');
 set local role authenticated;
 d:=public.premium_fixture_stage(a)->'draft';
 perform public.writer_private_fixture_promote(d);
 reset role;
 perform public.premium_fixture_assert((select fields#>'{biographyTranslations,ru}'=before_row#>'{fields,biographyTranslations,ru}' from public.writer_profile_overrides where writer_id='tombstone'),'replacement retains raw authored RU');
 update public.writer_profile_overrides set fields=jsonb_set(fields,'{biographyTranslations,en,method}','"human-translation"') where writer_id='tombstone';
 a:=public.writer_private_fixture_args('fixture-country:tombstone',catalog,true);
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 reset role;
 foreach value in array array['{}'::jsonb,'null'::jsonb] loop
   update public.writer_profile_overrides set fields=jsonb_build_object('biographyTranslations',value) where writer_id='tombstone';
   a:=public.writer_private_fixture_args('fixture-country:tombstone',catalog,true);
   set local role authenticated;
   perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'22023');
   reset role;
 end loop;
end; $$;
select 'M07_WRITER_NATIVE_OWNERSHIP_TOMBSTONES_PASS';

-- Exact microsecond CAS, takeover, disappearance, raw source change, catalog
-- change and absent-to-present target all refuse promotion; discard still works.
do $$ declare a jsonb; d jsonb; changed jsonb; case_name text; before_row jsonb; begin
 foreach case_name in array array['microsecond','manual','source','deleted','catalog','absent'] loop
   if case_name<>'absent' then
     insert into public.writer_profile_overrides(country_id,writer_id,fields,updated_at)
       values('fixture-country','stale-'||case_name,public.writer_private_fixture_catalog(),'2026-10-09T10:00:00.123456Z');
   end if;
   a:=public.writer_private_fixture_args('fixture-country:stale-'||case_name);
   set local role authenticated;
   perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
   d:=public.premium_fixture_stage(a)->'draft';
   reset role;
   if case_name='microsecond' then
     alter table public.writer_profile_overrides disable trigger writer_profile_overrides_set_updated_at;
     update public.writer_profile_overrides set updated_at=updated_at+interval '1 microsecond' where writer_id='stale-'||case_name;
     alter table public.writer_profile_overrides enable trigger writer_profile_overrides_set_updated_at;
   elsif case_name='manual' then
     update public.writer_profile_overrides set fields=jsonb_set(fields,'{biographyTranslations,en,method}','"human-translation"') where writer_id='stale-'||case_name;
   elsif case_name='source' then
     -- Keep the timestamp fixed to prove full raw source equality is independent.
     alter table public.writer_profile_overrides disable trigger writer_profile_overrides_set_updated_at;
     update public.writer_profile_overrides set fields=jsonb_set(fields,'{biographyTranslations,ru,rights,license}','"changed raw source rights"') where writer_id='stale-'||case_name;
     alter table public.writer_profile_overrides enable trigger writer_profile_overrides_set_updated_at;
   elsif case_name='deleted' then
     delete from public.writer_profile_overrides where writer_id='stale-'||case_name;
   elsif case_name='absent' then
     insert into public.writer_profile_overrides(country_id,writer_id,fields) values('fixture-country','stale-absent',public.writer_private_fixture_catalog());
   end if;
   select to_jsonb(w) into before_row from public.writer_profile_overrides w where writer_id='stale-'||case_name;
   truncate public.premium_fixture_outbox;
   changed:=case when case_name='catalog' then jsonb_set(public.writer_private_fixture_catalog(),'{rights,permission}','"changed catalog rights"') else public.writer_private_fixture_catalog() end;
   set local role authenticated;
   perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb,%L::jsonb)',d,changed),'40001');
   perform public.premium_fixture_assert(public.get_premium_translation_working_draft('writer_biography','fixture-country:stale-'||case_name)->'draft'=d,'stale candidate retained');
   perform public.premium_fixture_assert(public.premium_fixture_discard(d)->>'state'='discarded','stale candidate discard');
   reset role;
   perform public.premium_fixture_assert((select to_jsonb(w) from public.writer_profile_overrides w where writer_id='stale-'||case_name) is not distinct from before_row,'stale discard preserves source winner');
   perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stale failure/discard no outbox');
 end loop;
end; $$;
select 'M07_WRITER_NATIVE_STALE_DISCARD_PASS';

-- Long Unicode identifiers, cross-country selection and new override creation.
do $$ declare identity text; a jsonb; d jsonb; wrong jsonb; receipt jsonb; begin
 identity:=repeat('a',120)||':'||repeat(chr(128512),180);
 a:=public.writer_private_fixture_args(identity);
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(a)->'draft';
 perform public.premium_fixture_assert(d->>'entityId'=identity,'301-codepoint writer identity accepted');
 receipt:=public.premium_fixture_discard(d);
 reset role;
 insert into public.premium_fixture_saved values('writer-long-pending',d),('writer-long-args',a),('writer-discarded',receipt);
 set local role authenticated;
 a:=public.writer_private_fixture_args('fixture-country:new-writer');
 d:=public.premium_fixture_stage(a)->'draft';
 wrong:=jsonb_set(d,'{entityId}','"other-country:new-writer"');
 perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb)',wrong),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',wrong),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{candidateHash}',to_jsonb(repeat('f',64)))),'40001');
 perform public.premium_fixture_error(format('select public.premium_fixture_discard(%L::jsonb)',jsonb_set(d,'{version}','2')),'40001');
 receipt:=public.writer_private_fixture_promote(d);
 perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb)',d),'40001');
 receipt:=public.get_premium_translation_working_draft('writer_biography','fixture-country:new-writer');
 reset role;
 perform public.premium_fixture_assert((select fields#>'{biographyTranslations,ru}'=public.writer_private_fixture_catalog()#>'{biographyTranslations,ru}' from public.writer_profile_overrides where writer_id='new-writer'),'new override retains raw catalog RU');
 perform public.premium_fixture_assert((select fields#>'{biographyTranslations,fr}'=public.writer_private_fixture_catalog()#>'{biographyTranslations,fr}' from public.writer_profile_overrides where writer_id='new-writer'),'new override retains other catalog locales');
 insert into public.premium_fixture_saved values('writer-absent',receipt);
end; $$;
select 'M07_WRITER_NATIVE_IDENTITY_NEW_OVERRIDE_PASS';

create function public.writer_private_fixture_fail_update() returns trigger language plpgsql as $$
begin raise exception using errcode='23514',message='Synthetic canonical writer failure'; end; $$;
create trigger writer_fixture_failure before update on public.writer_profile_overrides
  for each row when (old.writer_id='rollback-writer') execute function public.writer_private_fixture_fail_update();
insert into public.writer_profile_overrides(country_id,writer_id,fields) values('fixture-country','rollback-writer',public.writer_private_fixture_catalog());
do $$ declare d jsonb; before_row jsonb; audit_count bigint; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(public.writer_private_fixture_args('fixture-country:rollback-writer'))->'draft';
 reset role;
 select to_jsonb(w) into before_row from public.writer_profile_overrides w where writer_id='rollback-writer';
 select count(*) into audit_count from public.admin_audit_log;
 truncate public.premium_fixture_outbox;
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb)',d),'23514');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('writer_biography','fixture-country:rollback-writer')->'draft'=d,'failed promotion retains candidate');
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(w)=before_row from public.writer_profile_overrides w where writer_id='rollback-writer'),'failed promotion retains canonical bytes');
 perform public.premium_fixture_assert((select count(*)=audit_count from public.admin_audit_log),'failed promotion no audit receipt');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'failed promotion no outbox');
 set local role authenticated;
 perform public.premium_fixture_discard(d);
end; $$;
select 'M07_WRITER_NATIVE_ROLLBACK_PASS';

do $$ begin
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_translation_working_drafts),'all writer candidates consumed explicitly');
 perform public.premium_fixture_assert(not exists(select 1 from public.admin_audit_log where action like 'premium_translation.candidate.%'
   and (metadata-array['draftId','version','candidateHash','sourceHash','canonicalId','outcome'])<>'{}'::jsonb),'writer audit only identities hashes outcomes');
end; $$;
select 'M07_WRITER_DTO='||jsonb_object_agg(name,value)::text from public.premium_fixture_saved where name like 'writer-%';
select 'M07_WRITER_SUMMARY='||jsonb_build_object('groups',7,'providerCalls',0,'canonicalStagingWrites',0,'rawSourceRightsPreserved',true,
 'catalogBoundary','trusted application reload, exact hash and raw fields comparison','managedAuthPostgrestVerified',false)::text;

-- Synthetic data only. Run after the unchanged book/country/writer fixtures,
-- actual homepage definitions/guards and the additive Site Copy migration.
create trigger premium_fixture_site_copy_outbox after update on public.homepage_blocks
  for each row execute function public.premium_fixture_capture();

insert into public.media_assets(id,object_path,original_name,mime_type,byte_size,uploaded_by)
values('99999999-9999-4999-8999-999999999999','fixture/site-copy.png','site-copy.png','image/png',1,'11111111-1111-4111-8111-111111111111');

create function public.site_copy_fixture_settings()
returns jsonb language sql immutable set search_path='' as $$
 select jsonb_build_object('systemKey','site-copy-overrides','siteCopy',jsonb_build_object(
   'ru',jsonb_build_object('intro',E'  Исходный \u2014 текст\r\nс новой строкой  ','cta','Открыть карту','manual','Ручной русский'),
   'en',jsonb_build_object('intro','Existing machine copy','manual','Keep authored English','unrelated',jsonb_build_object('raw',true)),
   'fr',jsonb_build_object('intro','  Français intact  ','rights',jsonb_build_array('éditeur',null)),
   'localeExtension',jsonb_build_object('preserve',true)),
   'premiumTranslation',jsonb_build_object('siteCopyEn',jsonb_build_object(
     'intro',jsonb_build_object('sourceHash',repeat('a',64),'customMachine',jsonb_build_object('rights','keep')),
     'unselected',jsonb_build_object('raw','preserved')),'customPremium',jsonb_build_array('keep',null)),
   'unknownSettings',jsonb_build_object('empty',jsonb_build_array(),'rights',jsonb_build_object('owner','editor')))
$$;

insert into public.homepage_blocks(id,block_type,title,settings,display_order,is_enabled,background_style,background_media_id,updated_by,updated_at)
values('dddddddd-dddd-4ddd-8ddd-dddddddddddd','text','Authored title',public.site_copy_fixture_settings(),-17,false,'paper',
 '99999999-9999-4999-8999-999999999999','11111111-1111-4111-8111-111111111111','2026-10-29T10:00:00.123456Z');

create function public.site_copy_fixture_args()
returns jsonb language plpgsql security definer set search_path='' as $$
declare block public.homepage_blocks%rowtype;
begin
 select * into block from public.homepage_blocks where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 return jsonb_build_object('kind','site_copy','identity',block.id,'sourceHash',repeat('b',64),
   'source',jsonb_build_object('settings',block.settings,'items',jsonb_build_array(
     jsonb_build_object('key','intro','text',E'Исходный \u2014 текст\nс новой строкой','sourceHash',repeat('c',64)),
     jsonb_build_object('key','cta','text','Открыть карту','sourceHash',repeat('d',64)))),
   'sourceRevision',jsonb_build_object('blockId',block.id,'blockUpdatedAt',block.updated_at),
   'targetRevision',jsonb_build_object('id',block.id,'updatedAt',block.updated_at),
   'payload',jsonb_build_object('items',jsonb_build_array(
     jsonb_build_object('key','intro','text','Separate English copy awaiting explicit human review.'),
     jsonb_build_object('key','cta','text','Open the map'))),
   'provenance',jsonb_build_object('provider','openai','translatorModel','controlled-translator','reviewerModel',null,
     'translatorRequestId','controlled-translation','reviewerRequestId',null,'generatedAt','2026-10-29T10:00:01.123456Z'));
end;
$$;
create function public.site_copy_fixture_promote(draft jsonb, confirm_review boolean default true)
returns jsonb language sql security invoker set search_path='' as $$
 select public.promote_premium_translation_working_draft(draft->>'entityType',draft->>'entityId',(draft->>'id')::uuid,
   (draft->>'version')::bigint,draft->>'candidateHash',draft->>'sourceHash',null,null,confirm_review);
$$;

do $$ declare fn record; begin
 perform public.premium_fixture_assert((select relrowsecurity and relforcerowsecurity from pg_class where oid='public.premium_translation_working_drafts'::regclass),'Site Copy private force RLS');
 for fn in select oid::regprocedure as signature from pg_proc where proname in
   ('get_premium_translation_working_draft','stage_premium_translation_working_draft','promote_premium_translation_working_draft','discard_premium_translation_working_draft') loop
   perform public.premium_fixture_assert(not has_function_privilege('anon',fn.signature,'execute'),'anon RPC denied');
   perform public.premium_fixture_assert(has_function_privilege('authenticated',fn.signature,'execute'),'authenticated RPC retained');
 end loop;
 set local role anon;
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts()','42501');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('site_copy','dddddddd-dddd-4ddd-8ddd-dddddddddddd')$q$,'42501');
 reset role;
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts()','42501');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('site_copy','dddddddd-dddd-4ddd-8ddd-dddddddddddd')$q$,'42501');
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select * from public.premium_translation_working_drafts','42501');
 perform public.premium_fixture_error($q$select public.get_premium_translation_working_draft('site_copy','not-a-block-uuid')$q$,'22023');
 reset role;
end; $$;
select 'M07_SITE_COPY_NATIVE_ACL_PASS';

do $$ declare a jsonb; staged jsonb; d jsonb; receipt jsonb; before_row jsonb; after_row jsonb; begin
 select to_jsonb(b) into before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 a:=public.site_copy_fixture_args(); truncate public.premium_fixture_outbox;
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 staged:=public.premium_fixture_stage(a); d:=staged->'draft';
 perform public.premium_fixture_assert(d->>'humanReview'='pending','Site Copy stage pending');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('site_copy',d->>'entityId')->'draft'=d,'Site Copy exact private read');
 perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001');
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb,false)',d),'22023');
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(b)=before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'stage preserves entire canonical block');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stage emits no canonical outbox');
 insert into public.premium_fixture_saved values('site-copy-args',a),('site-copy-stage',staged),
   ('site-copy-read',public.get_premium_translation_working_draft('site_copy',d->>'entityId'));
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
 set local timezone='Pacific/Kiritimati';
 receipt:=public.site_copy_fixture_promote(d);
 reset role;
 select to_jsonb(b) into after_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 perform public.premium_fixture_assert((after_row-array['settings','updated_at','updated_by','created_at'])=(before_row-array['settings','updated_at','updated_by','created_at'])
   and (after_row->>'created_at')::timestamptz=(before_row->>'created_at')::timestamptz,'all block attrs retained across timezone rendering');
 perform public.premium_fixture_assert(after_row#>'{settings,siteCopy,ru}'=before_row#>'{settings,siteCopy,ru}','raw RU spaces CRLF and long dash preserved');
 perform public.premium_fixture_assert(after_row#>'{settings,siteCopy,fr}'=before_row#>'{settings,siteCopy,fr}','raw French and rights preserved');
 perform public.premium_fixture_assert(((after_row#>'{settings,siteCopy}')-array['en'])=((before_row#>'{settings,siteCopy}')-array['en']),'other locale maps preserved');
 perform public.premium_fixture_assert(after_row#>'{settings,siteCopy,en,manual}'=before_row#>'{settings,siteCopy,en,manual}','unselected manual English retained');
 perform public.premium_fixture_assert(after_row#>'{settings,siteCopy,en,unrelated}'=before_row#>'{settings,siteCopy,en,unrelated}','unselected malformed raw English retained');
 perform public.premium_fixture_assert(after_row#>>'{settings,siteCopy,en,intro}'=a#>>'{payload,items,0,text}' and after_row#>>'{settings,siteCopy,en,cta}'='Open the map','selected candidate text exact');
 perform public.premium_fixture_assert(after_row#>'{settings,premiumTranslation,siteCopyEn,intro,customMachine}'=before_row#>'{settings,premiumTranslation,siteCopyEn,intro,customMachine}','selected unknown machine metadata retained');
 perform public.premium_fixture_assert(after_row#>'{settings,premiumTranslation,siteCopyEn,unselected}'=before_row#>'{settings,premiumTranslation,siteCopyEn,unselected}','unselected machine metadata retained');
 perform public.premium_fixture_assert(((after_row#>'{settings,premiumTranslation}')-'siteCopyEn')=((before_row#>'{settings,premiumTranslation}')-'siteCopyEn'),'other premium metadata retained');
 perform public.premium_fixture_assert(((after_row->'settings')-array['siteCopy','premiumTranslation'])=((before_row->'settings')-array['siteCopy','premiumTranslation']),'other raw settings retained');
 perform public.premium_fixture_assert(after_row#>>'{settings,premiumTranslation,siteCopyEn,intro,humanReview,reviewedBy}'='22222222-2222-4222-8222-222222222222','reviewer is actual current actor');
 perform public.premium_fixture_assert(after_row#>'{settings,premiumTranslation,siteCopyEn,intro,reviewerModel}'='null'::jsonb,'configured no model reviewer accepted without claiming review');
 perform public.premium_fixture_assert((select count(*)=1 from public.premium_fixture_outbox),'one canonical promotion outbox');
 perform public.premium_fixture_assert(not exists(select 1 from public.premium_translation_working_drafts where id=(d->>'id')::uuid),'explicit promotion consumes private draft');
 insert into public.premium_fixture_saved values('site-copy-promoted',receipt),('site-copy-after',after_row);
end; $$;
select 'M07_SITE_COPY_NATIVE_PRESERVATION_PASS';

do $$ declare a jsonb; modified jsonb; case_name text; begin
 a:=public.site_copy_fixture_args();
 foreach case_name in array array['empty','too-many','reorder','duplicate','extra-item-key','bad-hash','null-source-id','mismatched-revision','wrong-request-identity','bad-timestamp','unsafe-key','cyrillic-output'] loop
  modified:=a;
  case case_name
   when 'empty' then modified:=jsonb_set(modified,'{source,items}','[]');
   when 'too-many' then modified:=jsonb_set(modified,'{source,items}',(select jsonb_agg(a#>'{source,items,0}') from generate_series(1,51)));
   when 'reorder' then modified:=jsonb_set(modified,'{payload,items}',jsonb_build_array(a#>'{payload,items,1}',a#>'{payload,items,0}'));
   when 'duplicate' then modified:=jsonb_set(jsonb_set(modified,'{payload,items,1,key}','"intro"'),'{source,items,1,key}','"intro"');
   when 'extra-item-key' then modified:=jsonb_set(modified,'{payload,items,0}',(a#>'{payload,items,0}')||'{"extra":true}');
   when 'bad-hash' then modified:=jsonb_set(modified,'{source,items,0,sourceHash}','"bad"');
   when 'null-source-id' then modified:=jsonb_set(modified,'{sourceRevision,blockId}','null');
   when 'mismatched-revision' then modified:=jsonb_set(modified,'{targetRevision,updatedAt}','"2026-10-28T01:00:00Z"');
   when 'wrong-request-identity' then modified:=jsonb_set(modified,'{identity}','"eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee"');
   when 'bad-timestamp' then modified:=jsonb_set(modified,'{sourceRevision,blockUpdatedAt}','"not-a-time"');
   when 'unsafe-key' then modified:=jsonb_set(jsonb_set(modified,'{payload,items,0,key}','"__proto__.polluted"'),'{source,items,0,key}','"__proto__.polluted"');
   when 'cyrillic-output' then modified:=jsonb_set(modified,'{payload,items,0,text}','"Русский вместо перевода"');
  end case;
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',modified),'22023');
  reset role;
 end loop;
end; $$;
select 'M07_SITE_COPY_NATIVE_SHAPE_PASS';

do $$ declare a jsonb; d jsonb; invalid jsonb; item_key text; case_name text; begin
 foreach case_name in array array['key','source','payload'] loop
  a:=public.site_copy_fixture_args();
  a:=jsonb_set(a,'{source,items}',jsonb_build_array(a#>'{source,items,0}'));
  a:=jsonb_set(a,'{payload,items}',jsonb_build_array(a#>'{payload,items,0}'));
  if case_name='key' then
   item_key:='k'||repeat('😀',599)||'a';
   a:=jsonb_set(jsonb_set(a,'{source,items,0,key}',to_jsonb(item_key)),'{payload,items,0,key}',to_jsonb(item_key));
   a:=jsonb_set(a,'{source,settings,siteCopy,ru}',(a#>'{source,settings,siteCopy,ru}')||jsonb_build_object(item_key,'Новый исходный текст'));
   invalid:=jsonb_set(jsonb_set(a,'{source,items,0,key}',to_jsonb(item_key||'a')),'{payload,items,0,key}',to_jsonb(item_key||'a'));
   invalid:=jsonb_set(invalid,'{source,settings,siteCopy,ru}',(a#>'{source,settings,siteCopy,ru}')||jsonb_build_object(item_key||'a','Новый исходный текст'));
  elsif case_name='source' then
   a:=jsonb_set(a,'{source,items,0,text}',to_jsonb(repeat('😀',2000)));
   invalid:=jsonb_set(a,'{source,items,0,text}',to_jsonb(repeat('😀',2000)||'a'));
  else
   a:=jsonb_set(a,'{payload,items,0,text}',to_jsonb(repeat('😀',2000)));
   invalid:=jsonb_set(a,'{payload,items,0,text}',to_jsonb(repeat('😀',2000)||'a'));
  end if;
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',invalid),'22023');
  d:=public.premium_fixture_stage(a)->'draft';
  insert into public.premium_fixture_saved values('site-copy-boundary-'||case_name,d);
  perform public.premium_fixture_discard(d); reset role;
 end loop;
end; $$;
select 'M07_SITE_COPY_NATIVE_UTF16_LIMITS_PASS';

do $$ declare a jsonb; base jsonb; modified jsonb; raw_en jsonb; case_name text; begin
 base:=public.site_copy_fixture_settings();
 foreach raw_en in array array['null'::jsonb,'""'::jsonb,'{}'::jsonb,'[]'::jsonb,'42'::jsonb,'"Manual English"'::jsonb] loop
  modified:=jsonb_set(base#-'{premiumTranslation,siteCopyEn,intro}','{siteCopy,en,intro}',raw_en);
  update public.homepage_blocks set settings=modified where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'; a:=public.site_copy_fixture_args();
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001'); reset role;
 end loop;
 foreach case_name in array array['locale-array','en-array','premium-array','machine-array','selected-null','selected-array','invalid-marker','missing-russian','non-string-russian'] loop
  modified:=base;
  case case_name
   when 'locale-array' then modified:=jsonb_set(base,'{siteCopy}','[]');
   when 'en-array' then modified:=jsonb_set(base,'{siteCopy,en}','[]');
   when 'premium-array' then modified:=jsonb_set(base,'{premiumTranslation}','[]');
   when 'machine-array' then modified:=jsonb_set(base,'{premiumTranslation,siteCopyEn}','[]');
   when 'selected-null' then modified:=jsonb_set(base,'{premiumTranslation,siteCopyEn,intro}','null');
   when 'selected-array' then modified:=jsonb_set(base,'{premiumTranslation,siteCopyEn,intro}','[]');
   when 'invalid-marker' then modified:=jsonb_set(base,'{premiumTranslation,siteCopyEn,intro,sourceHash}','"bad"');
   when 'missing-russian' then modified:=base#-'{siteCopy,ru,intro}';
   when 'non-string-russian' then modified:=jsonb_set(base,'{siteCopy,ru,intro}','{}');
  end case;
  update public.homepage_blocks set settings=modified where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'; a:=public.site_copy_fixture_args();
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.premium_fixture_stage(%L::jsonb)',a),'40001'); reset role;
 end loop;
 update public.homepage_blocks set settings=base where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
end; $$;
select 'M07_SITE_COPY_NATIVE_OWNERSHIP_PASS';

do $$ declare a jsonb; d jsonb; old_row jsonb; case_name text; begin
 foreach case_name in array array['raw-source','raw-fr','unknown-metadata'] loop
  update public.homepage_blocks set settings=public.site_copy_fixture_settings() where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  a:=public.site_copy_fixture_args(); set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  d:=public.premium_fixture_stage(a)->'draft'; reset role;
  case case_name
   when 'raw-source' then update public.homepage_blocks set settings=jsonb_set(settings,'{siteCopy,ru,intro}','"Изменённый исходник"') where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
   when 'raw-fr' then update public.homepage_blocks set settings=jsonb_set(settings,'{siteCopy,fr,intro}','"French changed"') where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
   when 'unknown-metadata' then update public.homepage_blocks set settings=settings||'{"extraRaw":true}' where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  end case;
  truncate public.premium_fixture_outbox; select to_jsonb(b) into old_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
  perform public.premium_fixture_assert(public.get_premium_translation_working_draft('site_copy',d->>'entityId')->'draft'=d,'stale pending remains readable');
  perform public.premium_fixture_discard(d); reset role;
  perform public.premium_fixture_assert((select to_jsonb(b)=old_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'stale promote/discard canonical unchanged');
  perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stale discard emits no outbox');
 end loop;
 update public.homepage_blocks set settings=public.site_copy_fixture_settings() where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
end; $$;
select 'M07_SITE_COPY_NATIVE_STALE_DISCARD_PASS';

do $$ declare a jsonb; d jsonb; begin
 a:=public.site_copy_fixture_args(); set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(a)->'draft'; reset role;
 insert into public.homepage_blocks(id,block_type,title,settings,updated_by) values
  ('eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee','text','Duplicate master',public.site_copy_fixture_settings(),'11111111-1111-4111-8111-111111111111');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
 perform public.premium_fixture_discard(d);
 d:=public.premium_fixture_stage(a)->'draft';
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
 perform public.premium_fixture_discard(d); reset role;
 delete from public.homepage_blocks where id='eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';
end; $$;
select 'M07_SITE_COPY_NATIVE_DUPLICATE_MASTER_PASS';

do $$ declare a jsonb; d jsonb; before_row jsonb; changed_row jsonb; case_name text; recovery_page jsonb; begin
 foreach case_name in array array['russian-takeover','english-takeover','deleted-master'] loop
  update public.homepage_blocks set settings=public.site_copy_fixture_settings() where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  a:=public.site_copy_fixture_args();
  select to_jsonb(b) into before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  case case_name
   when 'russian-takeover' then update public.homepage_blocks set settings=jsonb_set(settings,'{siteCopy,ru,intro}','"Новый ручной русский"') where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
   when 'english-takeover' then update public.homepage_blocks set settings=jsonb_set(settings#-'{premiumTranslation,siteCopyEn,intro}','{siteCopy,en,intro}','"New authored English"') where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
   when 'deleted-master' then delete from public.homepage_blocks where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  end case;
  select to_jsonb(b) into changed_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
  truncate public.premium_fixture_outbox;
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  d:=public.premium_fixture_stage(a)->'draft';
  perform public.premium_fixture_assert(d->'sourceSnapshot'=a->'source','provider output survives concurrent source/target takeover');
  perform public.premium_fixture_assert(public.get_premium_translation_working_draft('site_copy',d->>'entityId')->'draft'=d,'concurrent stale output remains inspectable');
  if case_name='deleted-master' then
   recovery_page:=public.list_site_copy_premium_translation_working_drafts();
   perform public.premium_fixture_assert(recovery_page=jsonb_build_object('schemaVersion',1,'entityIds',jsonb_build_array(d->>'entityId'),'nextCursor',null),'deleted master candidate remains discoverable after reload');
   insert into public.premium_fixture_saved values('site-copy-list-deleted-master',recovery_page);
  end if;
  perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
  perform public.premium_fixture_discard(d); reset role;
  perform public.premium_fixture_assert((select to_jsonb(b) from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd') is not distinct from changed_row,'stale stage and failed promotion preserve concurrent canonical state');
  perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'stale provider output never emits canonical outbox');
  if case_name='deleted-master' then
   insert into public.homepage_blocks select * from jsonb_populate_record(null::public.homepage_blocks,before_row);
  end if;
 end loop;
 update public.homepage_blocks set settings=public.site_copy_fixture_settings() where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
end; $$;
select 'M07_SITE_COPY_NATIVE_DURABLE_STALE_OUTPUT_PASS';

-- Separate real transactions ensure the actual now()-based foundation trigger
-- creates a new revision, without replacing it with a fixture timestamp rule.
do $$ declare d jsonb; begin
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(public.site_copy_fixture_args())->'draft';
 insert into public.premium_fixture_saved values('site-copy-cas-candidate',d);
end; $$;
update public.homepage_blocks set settings=settings where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
do $$ declare d jsonb; begin
 select value into d from public.premium_fixture_saved where name='site-copy-cas-candidate';
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');
 perform public.premium_fixture_discard(d);
end; $$;
select 'M07_SITE_COPY_NATIVE_EXACT_CAS_PASS';

do $$ declare a jsonb; d jsonb; n integer; identity text; page jsonb; seen jsonb:='[]'; expected jsonb; cursor_id uuid;
  before_canonical jsonb; audit_count bigint; last_expected uuid;
begin
 a:=public.site_copy_fixture_args();
 for n in 1..11 loop
  identity:='90000000-0000-4000-8000-'||lpad(n::text,12,'0');
  a:=jsonb_set(jsonb_set(jsonb_set(a,'{identity}',to_jsonb(identity)),'{sourceRevision,blockId}',to_jsonb(identity)),'{targetRevision,id}',to_jsonb(identity));
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_stage(a); reset role;
 end loop;
 select jsonb_agg(entity_id order by id) into expected from public.premium_translation_working_drafts where entity_type='site_copy';
 select to_jsonb(b) into before_canonical from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 select count(*) into audit_count from public.admin_audit_log;
 truncate public.premium_fixture_outbox;
 cursor_id:=null; n:=0;
 loop
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  page:=public.list_site_copy_premium_translation_working_drafts(cursor_id,3); reset role;
  perform public.premium_fixture_assert(premium_translation_private.exact_object(page,array['schemaVersion','entityIds','nextCursor']),'list exact response exposes no source/payload');
  perform public.premium_fixture_assert(jsonb_array_length(page->'entityIds') between 1 and 3,'list requested bounded page size');
  seen:=seen||(page->'entityIds'); n:=n+1;
  if n=1 then
   select id into last_expected from public.premium_translation_working_drafts where entity_type='site_copy' order by id offset 2 limit 1;
   perform public.premium_fixture_assert(page->>'nextCursor'=last_expected::text,'list cursor is last visible draft UUID');
   insert into public.premium_fixture_saved values('site-copy-list-page-1',page);
  end if;
  exit when page->'nextCursor'='null'::jsonb;
  cursor_id:=(page->>'nextCursor')::uuid;
  if n>4 then raise exception 'Unexpected pagination loop'; end if;
 end loop;
 perform public.premium_fixture_assert(n=4 and seen=expected,'keyset list visits all eleven candidate identities once in draft order');
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts(null,0)','22023');
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts(null,11)','22023');
 perform public.premium_fixture_error('select public.list_site_copy_premium_translation_working_drafts(null,null)','22023');
 page:=public.list_site_copy_premium_translation_working_drafts(null,10);
 perform public.premium_fixture_assert(jsonb_array_length(page->'entityIds')=10 and page->>'nextCursor' is not null,'list max ten page has continuation');
 insert into public.premium_fixture_saved values('site-copy-list-max-page',page);
 page:=public.list_site_copy_premium_translation_working_drafts((page->>'nextCursor')::uuid,10);
 perform public.premium_fixture_assert(jsonb_array_length(page->'entityIds')=1 and page->'nextCursor'='null'::jsonb,'list final page has exact null cursor');
 insert into public.premium_fixture_saved values('site-copy-list-max-last-page',page);
 reset role;
 perform public.premium_fixture_assert((select to_jsonb(b)=before_canonical from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'read-only list canonical unchanged');
 perform public.premium_fixture_assert((select count(*)=audit_count from public.admin_audit_log),'read-only list audit unchanged');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'read-only list outbox unchanged');
 for d in select premium_translation_private.dto(c) from public.premium_translation_working_drafts c where entity_type='site_copy' loop
  set local role authenticated;
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.premium_fixture_discard(d); reset role;
 end loop;
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 page:=public.list_site_copy_premium_translation_working_drafts();
 perform public.premium_fixture_assert(page='{"schemaVersion":1,"entityIds":[],"nextCursor":null}'::jsonb,'empty list exact null cursor');
 insert into public.premium_fixture_saved values('site-copy-list-empty',page);
 a:=public.site_copy_fixture_args(); identity:='ABCDEFAB-CDEF-4ABC-8DEF-ABCDEFABCDEF';
 a:=jsonb_set(jsonb_set(jsonb_set(a,'{identity}',to_jsonb(identity)),'{sourceRevision,blockId}',to_jsonb(identity)),'{targetRevision,id}',to_jsonb(identity));
 d:=public.premium_fixture_stage(a)->'draft';
 page:=public.list_site_copy_premium_translation_working_drafts();
 perform public.premium_fixture_assert(page->'entityIds'=jsonb_build_array(identity),'list retains stored UUID identity case for exact get');
 perform public.premium_fixture_assert(public.get_premium_translation_working_draft('site_copy',identity)->'draft'=d,'listed uppercase identity remains exactly readable');
 insert into public.premium_fixture_saved values('site-copy-list-uppercase',page);
 perform public.premium_fixture_discard(d);
end; $$;
select 'M07_SITE_COPY_NATIVE_READONLY_DISCOVERY_PAGING_PASS';

create function public.site_copy_fixture_reject_update() returns trigger language plpgsql set search_path='' as $$
begin raise exception using errcode='P0099',message='controlled canonical failure'; end; $$;
do $$ declare a jsonb; d jsonb; before_row jsonb; audit_count bigint; begin
 a:=public.site_copy_fixture_args(); set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 d:=public.premium_fixture_stage(a)->'draft'; reset role;
 select to_jsonb(b) into before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd';
 select count(*) into audit_count from public.admin_audit_log;
 truncate public.premium_fixture_outbox;
 create trigger site_copy_fixture_reject_update before update on public.homepage_blocks for each row execute function public.site_copy_fixture_reject_update();
 set local role authenticated;
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'P0099'); reset role;
 drop trigger site_copy_fixture_reject_update on public.homepage_blocks;
 perform public.premium_fixture_assert((select to_jsonb(b)=before_row from public.homepage_blocks b where id='dddddddd-dddd-4ddd-8ddd-dddddddddddd'),'failed promotion rolls back canonical');
 perform public.premium_fixture_assert((select count(*)=audit_count from public.admin_audit_log),'failed promotion rolls back audit');
 perform public.premium_fixture_assert((select count(*)=0 from public.premium_fixture_outbox),'failed promotion rolls back outbox');
 perform public.premium_fixture_assert((select premium_translation_private.dto(c)=d from public.premium_translation_working_drafts c where id=(d->>'id')::uuid),'failed promotion retains exact private candidate');
 insert into public.premium_fixture_saved values('site-copy-lock-candidate',d);
end; $$;
select 'M07_SITE_COPY_NATIVE_ROLLBACK_PASS';

select 'M07_SITE_COPY_NATIVE_SUMMARY',jsonb_build_object('groups',11,'providerCalls',0,'managedAuthPostgrest',false);

-- Durable, private Translation Operations control plane.
-- Source prose and provider payloads are deliberately not persisted here:
-- jobs contain stable entity references and hashes, attempts contain only
-- allow-listed error codes and bounded operational metadata.

create table if not exists public.translation_jobs (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (
    kind in ('article', 'literary_work', 'writer', 'country', 'site_copy')
  ),
  source_locale text not null default 'ru' check (source_locale = 'ru'),
  target_locale text not null default 'en' check (target_locale = 'en'),
  provider text not null check (provider in ('cloudflare', 'openai')),
  status text not null default 'queued' check (
    status in ('queued', 'running', 'cancelling', 'completed', 'partial', 'failed', 'cancelled')
  ),
  total_items integer not null default 0 check (total_items between 0 and 500),
  succeeded_items integer not null default 0 check (succeeded_items between 0 and total_items),
  failed_items integer not null default 0 check (failed_items between 0 and total_items),
  requested_by uuid not null references auth.users(id) on delete restrict,
  started_at timestamptz,
  completed_at timestamptz,
  cancel_requested_at timestamptz,
  version bigint not null default 1 check (version > 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (succeeded_items + failed_items <= total_items)
);

create table if not exists public.translation_job_items (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.translation_jobs(id) on delete cascade,
  position integer not null check (position between 0 and 499),
  entity_type text not null check (
    entity_type in ('article', 'literary_work', 'writer', 'country', 'site_copy')
  ),
  entity_id text not null check (
    char_length(btrim(entity_id)) between 1 and 1_200
    and entity_id !~ '[[:cntrl:]]'
  ),
  source_hash text check (source_hash is null or source_hash ~ '^[a-f0-9]{64}$'),
  status text not null default 'queued' check (
    status in ('queued', 'leased', 'retry_wait', 'succeeded', 'dead_letter', 'cancelled')
  ),
  attempt_count integer not null default 0 check (attempt_count between 0 and 10),
  max_attempts integer not null default 3 check (max_attempts between 1 and 5),
  next_attempt_at timestamptz not null default now(),
  lease_owner text check (
    lease_owner is null or (
      char_length(btrim(lease_owner)) between 1 and 120
      and lease_owner !~ '[[:cntrl:]]'
    )
  ),
  lease_expires_at timestamptz,
  last_error_code text check (
    last_error_code is null or last_error_code in (
      'provider_unavailable',
      'provider_request_failed',
      'provider_invalid_response',
      'source_changed',
      'write_conflict',
      'database_read_failed',
      'database_write_failed',
      'unexpected'
    )
  ),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (job_id, position),
  unique (job_id, entity_type, entity_id),
  check (
    (status = 'leased' and lease_owner is not null and lease_expires_at is not null)
    or (status <> 'leased' and lease_owner is null and lease_expires_at is null)
  )
);

create table if not exists public.translation_job_attempts (
  id bigint generated always as identity primary key,
  item_id uuid not null references public.translation_job_items(id) on delete cascade,
  attempt_number integer not null check (attempt_number between 1 and 10),
  outcome text not null check (outcome in ('succeeded', 'retry', 'dead_letter')),
  provider text not null check (provider in ('cloudflare', 'openai')),
  model text check (model is null or char_length(model) between 1 and 200),
  provider_request_id text check (
    provider_request_id is null or char_length(provider_request_id) between 1 and 200
  ),
  error_code text check (
    error_code is null or error_code in (
      'provider_unavailable',
      'provider_request_failed',
      'provider_invalid_response',
      'source_changed',
      'write_conflict',
      'database_read_failed',
      'database_write_failed',
      'unexpected'
    )
  ),
  input_tokens integer check (input_tokens is null or input_tokens between 0 and 10000000),
  output_tokens integer check (output_tokens is null or output_tokens between 0 and 10000000),
  duration_ms integer check (duration_ms is null or duration_ms between 0 and 3600000),
  created_at timestamptz not null default now(),
  unique (item_id, attempt_number),
  check (
    (outcome = 'succeeded' and error_code is null)
    or (outcome <> 'succeeded' and error_code is not null)
  )
);

create index if not exists translation_job_items_claim_idx
  on public.translation_job_items(status, next_attempt_at, lease_expires_at, job_id, position);
create index if not exists translation_jobs_status_idx
  on public.translation_jobs(status, created_at desc);
create index if not exists translation_job_attempts_item_idx
  on public.translation_job_attempts(item_id, attempt_number desc);

alter table public.translation_jobs enable row level security;
alter table public.translation_jobs force row level security;
alter table public.translation_job_items enable row level security;
alter table public.translation_job_items force row level security;
alter table public.translation_job_attempts enable row level security;
alter table public.translation_job_attempts force row level security;

drop policy if exists "Staff read translation jobs" on public.translation_jobs;
create policy "Staff read translation jobs"
on public.translation_jobs for select to authenticated
using (public.is_staff());

drop policy if exists "Staff read translation job items" on public.translation_job_items;
create policy "Staff read translation job items"
on public.translation_job_items for select to authenticated
using (public.is_staff());

drop policy if exists "Staff read translation job attempts" on public.translation_job_attempts;
create policy "Staff read translation job attempts"
on public.translation_job_attempts for select to authenticated
using (public.is_staff());

revoke all on table public.translation_jobs from public, anon, authenticated;
revoke all on table public.translation_job_items from public, anon, authenticated;
revoke all on table public.translation_job_attempts from public, anon, authenticated;
grant select on table public.translation_jobs to authenticated;
grant select on table public.translation_job_items to authenticated;
grant select on table public.translation_job_attempts to authenticated;
grant all on table public.translation_jobs to service_role;
grant all on table public.translation_job_items to service_role;
grant all on table public.translation_job_attempts to service_role;
grant usage, select on sequence public.translation_job_attempts_id_seq to service_role;

create or replace function public.create_translation_job(
  p_kind text,
  p_provider text,
  p_items jsonb,
  p_max_attempts integer default 3
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  created_job_id uuid;
  item_count integer;
begin
  if actor_id is null or not public.is_staff() then
    raise exception 'translation job requires staff access' using errcode = '42501';
  end if;
  if p_kind not in ('article', 'literary_work', 'writer', 'country', 'site_copy') then
    raise exception 'invalid translation job kind' using errcode = '22023';
  end if;
  if p_provider not in ('cloudflare', 'openai') then
    raise exception 'invalid translation provider' using errcode = '22023';
  end if;
  if p_max_attempts not between 1 and 5 then
    raise exception 'invalid translation attempt limit' using errcode = '22023';
  end if;
  if jsonb_typeof(p_items) <> 'array' then
    raise exception 'translation items must be an array' using errcode = '22023';
  end if;

  item_count := jsonb_array_length(p_items);
  if item_count < 1 or item_count > 500 then
    raise exception 'translation job item count is out of range' using errcode = '22023';
  end if;
  if exists (
    select 1
    from jsonb_array_elements(p_items) with ordinality as item(value, position)
    where jsonb_typeof(item.value) <> 'object'
      or coalesce(item.value->>'entityType', '') <> p_kind
      or char_length(btrim(coalesce(item.value->>'entityId', ''))) not between 1 and 1200
      or coalesce(item.value->>'entityId', '') ~ '[[:cntrl:]]'
      or (
        item.value ? 'sourceHash'
        and coalesce(item.value->>'sourceHash', '') !~ '^[a-f0-9]{64}$'
      )
  ) then
    raise exception 'invalid translation job item' using errcode = '22023';
  end if;
  if exists (
    select 1
    from jsonb_array_elements(p_items) as item(value)
    group by item.value->>'entityType', item.value->>'entityId'
    having count(*) > 1
  ) then
    raise exception 'duplicate translation job item' using errcode = '23505';
  end if;

  insert into public.translation_jobs (
    kind, provider, total_items, requested_by
  ) values (
    p_kind, p_provider, item_count, actor_id
  ) returning id into created_job_id;

  insert into public.translation_job_items (
    job_id, position, entity_type, entity_id, source_hash, max_attempts
  )
  select
    created_job_id,
    (item.position - 1)::integer,
    item.value->>'entityType',
    btrim(item.value->>'entityId'),
    nullif(item.value->>'sourceHash', ''),
    p_max_attempts
  from jsonb_array_elements(p_items) with ordinality as item(value, position);

  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor_id,
    'translation.job.created',
    'translation_job',
    created_job_id::text,
    jsonb_build_object(
      'kind', p_kind,
      'provider', p_provider,
      'itemCount', item_count,
      'maxAttempts', p_max_attempts
    )
  );

  return created_job_id;
end;
$$;

create or replace function public.request_translation_job_cancel(
  p_job_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  current_job public.translation_jobs%rowtype;
  next_status text;
begin
  if actor_id is null or not public.is_staff() then
    raise exception 'translation job cancellation requires staff access'
      using errcode = '42501';
  end if;

  select job.* into current_job
  from public.translation_jobs job
  where job.id = p_job_id
  for update;
  if not found then
    raise exception 'translation job not found' using errcode = 'P0002';
  end if;
  if current_job.version <> p_expected_version then
    raise exception 'translation job version conflict' using errcode = '40001';
  end if;
  if current_job.status in ('completed', 'partial', 'failed', 'cancelled') then
    return jsonb_build_object(
      'id', current_job.id,
      'status', current_job.status,
      'version', current_job.version
    );
  end if;

  update public.translation_job_items
  set status = 'cancelled',
      lease_owner = null,
      lease_expires_at = null,
      updated_at = now()
  where job_id = current_job.id
    and status in ('queued', 'retry_wait');

  next_status := case
    when exists (
      select 1 from public.translation_job_items item
      where item.job_id = current_job.id and item.status = 'leased'
    ) then 'cancelling'
    else 'cancelled'
  end;

  update public.translation_jobs
  set status = next_status,
      cancel_requested_at = coalesce(cancel_requested_at, now()),
      completed_at = case when next_status = 'cancelled' then now() else null end,
      version = version + 1,
      updated_at = now()
  where id = current_job.id
  returning * into current_job;

  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor_id,
    'translation.job.cancel_requested',
    'translation_job',
    current_job.id::text,
    jsonb_build_object('status', current_job.status, 'version', current_job.version)
  );

  return jsonb_build_object(
    'id', current_job.id,
    'status', current_job.status,
    'version', current_job.version
  );
end;
$$;

create or replace function public.claim_translation_job_items(
  p_worker_id text,
  p_limit integer default 10,
  p_lease_seconds integer default 300
)
returns table (
  item_id uuid,
  job_id uuid,
  kind text,
  provider text,
  entity_type text,
  entity_id text,
  source_hash text,
  attempt_number integer,
  lease_expires_at timestamptz
)
language sql
security definer
set search_path = ''
as $$
  with candidates as (
    select item.id
    from public.translation_job_items item
    join public.translation_jobs job on job.id = item.job_id
    where job.status in ('queued', 'running')
      and job.cancel_requested_at is null
      and (
        (item.status in ('queued', 'retry_wait') and item.next_attempt_at <= now())
        or (item.status = 'leased' and item.lease_expires_at <= now())
      )
    order by job.created_at, item.position
    for update of item skip locked
    limit greatest(1, least(coalesce(p_limit, 10), 50))
  ), claimed as (
    update public.translation_job_items item
    set status = 'leased',
        lease_owner = btrim(p_worker_id),
        lease_expires_at = now() + make_interval(
          secs => greatest(30, least(coalesce(p_lease_seconds, 300), 900))
        ),
        updated_at = now()
    from candidates
    where item.id = candidates.id
      and char_length(btrim(coalesce(p_worker_id, ''))) between 1 and 120
      and coalesce(p_worker_id, '') !~ '[[:cntrl:]]'
    returning item.*
  ), started_jobs as (
    update public.translation_jobs job
    set status = 'running',
        started_at = coalesce(job.started_at, now()),
        version = job.version + 1,
        updated_at = now()
    where job.id in (select distinct claimed.job_id from claimed)
      and job.status = 'queued'
    returning job.id
  )
  select
    claimed.id,
    claimed.job_id,
    job.kind,
    job.provider,
    claimed.entity_type,
    claimed.entity_id,
    claimed.source_hash,
    claimed.attempt_count + 1,
    claimed.lease_expires_at
  from claimed
  join public.translation_jobs job on job.id = claimed.job_id;
$$;

create or replace function public.complete_translation_job_item(
  p_item_id uuid,
  p_worker_id text,
  p_succeeded boolean,
  p_error_code text default null,
  p_model text default null,
  p_provider_request_id text default null,
  p_input_tokens integer default null,
  p_output_tokens integer default null,
  p_duration_ms integer default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_item public.translation_job_items%rowtype;
  current_job public.translation_jobs%rowtype;
  new_attempt integer;
  next_item_status text;
  attempt_outcome text;
  succeeded_count integer;
  failed_count integer;
  active_count integer;
  cancelled_count integer;
  next_job_status text;
begin
  select item.* into current_item
  from public.translation_job_items item
  where item.id = p_item_id
  for update;
  if not found then
    raise exception 'translation job item not found' using errcode = 'P0002';
  end if;
  if current_item.status <> 'leased'
    or current_item.lease_owner <> btrim(coalesce(p_worker_id, ''))
    or current_item.lease_expires_at <= now() then
    raise exception 'translation job lease is not valid' using errcode = '42501';
  end if;

  select job.* into current_job
  from public.translation_jobs job
  where job.id = current_item.job_id
  for update;

  new_attempt := current_item.attempt_count + 1;
  if p_succeeded then
    if p_error_code is not null then
      raise exception 'successful translation attempt cannot have an error code'
        using errcode = '22023';
    end if;
    next_item_status := 'succeeded';
    attempt_outcome := 'succeeded';
  else
    if p_error_code not in (
      'provider_unavailable', 'provider_request_failed',
      'provider_invalid_response', 'source_changed', 'write_conflict',
      'database_read_failed', 'database_write_failed', 'unexpected'
    ) then
      raise exception 'invalid translation error code' using errcode = '22023';
    end if;
    if new_attempt >= current_item.max_attempts then
      next_item_status := 'dead_letter';
      attempt_outcome := 'dead_letter';
    else
      next_item_status := 'retry_wait';
      attempt_outcome := 'retry';
    end if;
  end if;

  insert into public.translation_job_attempts (
    item_id, attempt_number, outcome, provider, model,
    provider_request_id, error_code, input_tokens, output_tokens, duration_ms
  ) values (
    current_item.id,
    new_attempt,
    attempt_outcome,
    current_job.provider,
    nullif(btrim(coalesce(p_model, '')), ''),
    nullif(btrim(coalesce(p_provider_request_id, '')), ''),
    p_error_code,
    p_input_tokens,
    p_output_tokens,
    p_duration_ms
  );

  update public.translation_job_items
  set status = next_item_status,
      attempt_count = new_attempt,
      next_attempt_at = case
        when next_item_status = 'retry_wait'
          then now() + make_interval(secs => least(900, 30 * (2 ^ (new_attempt - 1))::integer))
        else next_attempt_at
      end,
      lease_owner = null,
      lease_expires_at = null,
      last_error_code = p_error_code,
      updated_at = now()
  where id = current_item.id;

  if current_job.cancel_requested_at is not null then
    update public.translation_job_items
    set status = 'cancelled', updated_at = now()
    where job_id = current_job.id and status in ('queued', 'retry_wait');
  end if;

  select
    count(*) filter (where status = 'succeeded'),
    count(*) filter (where status = 'dead_letter'),
    count(*) filter (where status in ('queued', 'leased', 'retry_wait')),
    count(*) filter (where status = 'cancelled')
  into succeeded_count, failed_count, active_count, cancelled_count
  from public.translation_job_items
  where job_id = current_job.id;

  next_job_status := case
    when active_count > 0 and current_job.cancel_requested_at is not null then 'cancelling'
    when active_count > 0 then 'running'
    when current_job.cancel_requested_at is not null then 'cancelled'
    when succeeded_count = current_job.total_items then 'completed'
    when succeeded_count > 0 then 'partial'
    else 'failed'
  end;

  update public.translation_jobs
  set status = next_job_status,
      succeeded_items = succeeded_count,
      failed_items = failed_count,
      completed_at = case
        when next_job_status in ('completed', 'partial', 'failed', 'cancelled') then now()
        else null
      end,
      version = version + 1,
      updated_at = now()
  where id = current_job.id
  returning * into current_job;

  return jsonb_build_object(
    'jobId', current_job.id,
    'jobStatus', current_job.status,
    'itemId', current_item.id,
    'itemStatus', next_item_status,
    'attemptNumber', new_attempt
  );
end;
$$;

create or replace function public.translation_operations_ready()
returns boolean
language sql
stable
security invoker
set search_path = ''
as $$
  select public.is_staff()
    and to_regclass('public.translation_jobs') is not null
    and to_regclass('public.translation_job_items') is not null
    and to_regclass('public.translation_job_attempts') is not null
    and to_regprocedure('public.create_translation_job(text,text,jsonb,integer)') is not null
    and to_regprocedure('public.claim_translation_job_items(text,integer,integer)') is not null
    and to_regprocedure(
      'public.complete_translation_job_item(uuid,text,boolean,text,text,text,integer,integer,integer)'
    ) is not null;
$$;

create or replace function public.get_translation_operations_status()
returns jsonb
language sql
stable
security invoker
set search_path = ''
as $$
  with totals as (
    select
      count(*) filter (where job.status = 'queued') as queued,
      count(*) filter (where job.status in ('running', 'cancelling')) as running,
      count(*) filter (where job.status = 'completed') as completed,
      count(*) filter (where job.status in ('partial', 'failed')) as attention
    from public.translation_jobs job
  ), recent as (
    select coalesce(jsonb_agg(jsonb_build_object(
      'id', job.id,
      'kind', job.kind,
      'status', job.status,
      'totalItems', job.total_items,
      'succeededItems', job.succeeded_items,
      'failedItems', job.failed_items,
      'createdAt', job.created_at,
      'updatedAt', job.updated_at
    ) order by job.created_at desc), '[]'::jsonb) as items
    from (
      select * from public.translation_jobs order by created_at desc limit 12
    ) job
  )
  select case when public.is_staff() then jsonb_build_object(
    'queued', totals.queued,
    'running', totals.running,
    'completed', totals.completed,
    'attention', totals.attention,
    'deadLetterItems', (
      select count(*) from public.translation_job_items item
      where item.status = 'dead_letter'
    ),
    'recent', recent.items
  ) else null end
  from totals cross join recent;
$$;

revoke all on function public.create_translation_job(text,text,jsonb,integer)
  from public, anon, authenticated, service_role;
revoke all on function public.request_translation_job_cancel(uuid,bigint)
  from public, anon, authenticated, service_role;
revoke all on function public.claim_translation_job_items(text,integer,integer)
  from public, anon, authenticated, service_role;
revoke all on function public.complete_translation_job_item(
  uuid,text,boolean,text,text,text,integer,integer,integer
) from public, anon, authenticated, service_role;
revoke all on function public.translation_operations_ready()
  from public, anon, authenticated, service_role;
revoke all on function public.get_translation_operations_status()
  from public, anon, authenticated, service_role;

grant execute on function public.create_translation_job(text,text,jsonb,integer)
  to authenticated;
grant execute on function public.request_translation_job_cancel(uuid,bigint)
  to authenticated;
grant execute on function public.translation_operations_ready()
  to authenticated;
grant execute on function public.get_translation_operations_status()
  to authenticated;
grant execute on function public.claim_translation_job_items(text,integer,integer)
  to service_role;
grant execute on function public.complete_translation_job_item(
  uuid,text,boolean,text,text,text,integer,integer,integer
) to service_role;

-- Forward-only runtime closure for Translation Operations.
-- It persists real provider probes, rate-limits them before the provider call,
-- records bounded synchronous batches for durable resume, and fail-closes the
-- unused service-role lease API until a dedicated worker is deployed.

alter table public.translation_jobs
  drop constraint if exists translation_jobs_status_check;
alter table public.translation_jobs
  add constraint translation_jobs_status_check check (
    status in (
      'queued', 'running', 'reviewing', 'cancelling', 'completed', 'partial',
      'failed', 'conflict', 'stale', 'skipped', 'not-configured', 'cancelled'
    )
  );

alter table public.translation_jobs
  add column if not exists resume_cursor jsonb not null default '{}'::jsonb
  check (jsonb_typeof(resume_cursor) = 'object');

alter table public.translation_job_items
  drop constraint if exists translation_job_items_status_check;
alter table public.translation_job_items
  add constraint translation_job_items_status_check check (
    status in (
      'queued', 'leased', 'reviewing', 'retry_wait', 'succeeded', 'conflict',
      'stale', 'skipped', 'not-configured', 'dead_letter', 'cancelled'
    )
  );

alter table public.translation_job_items
  drop constraint if exists translation_job_items_last_error_code_check;
alter table public.translation_job_items
  add constraint translation_job_items_last_error_code_check check (
    last_error_code is null or last_error_code in (
      'translation_not_configured', 'provider_unavailable',
      'provider_request_failed', 'provider_invalid_response', 'source_changed',
      'write_conflict', 'database_read_failed', 'database_write_failed', 'unexpected'
    )
  );

alter table public.translation_job_attempts
  drop constraint if exists translation_job_attempts_outcome_check;
alter table public.translation_job_attempts
  add constraint translation_job_attempts_outcome_check check (
    outcome in (
      'succeeded', 'retry', 'dead_letter', 'conflict', 'stale',
      'skipped', 'not-configured'
    )
  );
alter table public.translation_job_attempts
  drop constraint if exists translation_job_attempts_error_code_check;
alter table public.translation_job_attempts
  add constraint translation_job_attempts_error_code_check check (
    error_code is null or error_code in (
      'translation_not_configured', 'provider_unavailable',
      'provider_request_failed', 'provider_invalid_response', 'source_changed',
      'write_conflict', 'database_read_failed', 'database_write_failed', 'unexpected'
    )
  );
alter table public.translation_job_attempts
  drop constraint if exists translation_job_attempts_check;
alter table public.translation_job_attempts
  drop constraint if exists translation_job_attempts_error_boundary_check;
alter table public.translation_job_attempts
  add constraint translation_job_attempts_error_boundary_check check (
    (outcome in ('succeeded', 'skipped') and error_code is null)
    or (outcome not in ('succeeded', 'skipped') and error_code is not null)
  );

create table if not exists public.translation_provider_self_tests (
  provider text primary key check (provider in ('cloudflare', 'openai')),
  configured boolean not null default false,
  binding_found boolean not null default false,
  test_passed boolean,
  model text check (model is null or char_length(model) between 1 and 200),
  latency_ms integer check (latency_ms is null or latency_ms between 0 and 3600000),
  last_error_code text check (
    last_error_code is null or last_error_code in (
      'translation_not_configured', 'provider_unavailable',
      'provider_request_failed', 'provider_invalid_response', 'unexpected'
    )
  ),
  last_test_at timestamptz,
  cooldown_until timestamptz,
  test_in_progress boolean not null default false,
  lease_token uuid,
  lease_expires_at timestamptz,
  tested_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now(),
  check (
    (test_in_progress and lease_token is not null and lease_expires_at is not null)
    or (not test_in_progress and lease_token is null and lease_expires_at is null)
  ),
  check (
    (test_passed is true and last_error_code is null)
    or test_passed is distinct from true
  )
);

alter table public.translation_provider_self_tests enable row level security;
alter table public.translation_provider_self_tests force row level security;
drop policy if exists "Staff read translation provider self tests"
  on public.translation_provider_self_tests;
create policy "Staff read translation provider self tests"
on public.translation_provider_self_tests for select to authenticated
using (public.is_staff());
revoke all on table public.translation_provider_self_tests
  from public, anon, authenticated;
grant select on table public.translation_provider_self_tests to authenticated;
grant all on table public.translation_provider_self_tests to service_role;

create or replace function public.begin_translation_provider_self_test(
  p_provider text,
  p_configured boolean,
  p_binding_found boolean,
  p_model text,
  p_cooldown_seconds integer default 300
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  current_probe public.translation_provider_self_tests%rowtype;
  token uuid := gen_random_uuid();
  cooldown integer := greatest(60, least(coalesce(p_cooldown_seconds, 300), 1800));
begin
  if actor_id is null or not public.is_staff() then
    raise exception 'translation self-test requires staff access' using errcode = '42501';
  end if;
  if p_provider not in ('cloudflare', 'openai') then
    raise exception 'invalid translation provider' using errcode = '22023';
  end if;
  if char_length(btrim(coalesce(p_model, ''))) not between 1 and 200 then
    raise exception 'invalid translation model' using errcode = '22023';
  end if;

  insert into public.translation_provider_self_tests (
    provider, configured, binding_found, model, tested_by
  ) values (
    p_provider, p_configured, p_binding_found, btrim(p_model), actor_id
  ) on conflict (provider) do nothing;

  select probe.* into current_probe
  from public.translation_provider_self_tests probe
  where probe.provider = p_provider
  for update;

  if current_probe.cooldown_until is not null and current_probe.cooldown_until > now() then
    raise exception 'translation self-test cooldown is active' using errcode = '55000';
  end if;
  if current_probe.test_in_progress
    and current_probe.lease_expires_at is not null
    and current_probe.lease_expires_at > now() then
    raise exception 'translation self-test is already running' using errcode = '55000';
  end if;

  update public.translation_provider_self_tests
  set configured = p_configured,
      binding_found = p_binding_found,
      model = btrim(p_model),
      test_in_progress = true,
      lease_token = token,
      lease_expires_at = now() + interval '5 minutes',
      cooldown_until = now() + make_interval(secs => cooldown),
      tested_by = actor_id,
      updated_at = now()
  where provider = p_provider;

  return token;
end;
$$;

create or replace function public.finish_translation_provider_self_test(
  p_provider text,
  p_lease_token uuid,
  p_configured boolean,
  p_binding_found boolean,
  p_test_passed boolean,
  p_model text,
  p_latency_ms integer,
  p_error_code text default null
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  saved public.translation_provider_self_tests%rowtype;
begin
  if actor_id is null or not public.is_staff() then
    raise exception 'translation self-test completion requires staff access'
      using errcode = '42501';
  end if;
  if p_test_passed and p_error_code is not null then
    raise exception 'successful translation self-test cannot have an error code'
      using errcode = '22023';
  end if;
  if not p_test_passed and p_error_code not in (
    'translation_not_configured', 'provider_unavailable',
    'provider_request_failed', 'provider_invalid_response', 'unexpected'
  ) then
    raise exception 'invalid translation self-test error code' using errcode = '22023';
  end if;
  if p_latency_ms not between 0 and 3600000 then
    raise exception 'invalid translation self-test latency' using errcode = '22023';
  end if;

  update public.translation_provider_self_tests
  set configured = p_configured,
      binding_found = p_binding_found,
      test_passed = p_test_passed,
      model = nullif(btrim(coalesce(p_model, '')), ''),
      latency_ms = p_latency_ms,
      last_error_code = p_error_code,
      last_test_at = now(),
      test_in_progress = false,
      lease_token = null,
      lease_expires_at = null,
      tested_by = actor_id,
      updated_at = now()
  where provider = p_provider
    and lease_token = p_lease_token
    and test_in_progress
    and lease_expires_at > now()
  returning * into saved;
  if not found then
    raise exception 'translation self-test lease is not valid' using errcode = '42501';
  end if;

  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor_id,
    'translation.provider.self_tested',
    'translation_provider',
    p_provider,
    jsonb_build_object(
      'configured', saved.configured,
      'bindingFound', saved.binding_found,
      'testPassed', saved.test_passed,
      'model', saved.model,
      'latencyMs', saved.latency_ms,
      'errorCode', saved.last_error_code
    )
  );

  return jsonb_build_object(
    'provider', saved.provider,
    'configured', saved.configured,
    'bindingFound', saved.binding_found,
    'testPassed', saved.test_passed,
    'lastTestAt', saved.last_test_at,
    'lastErrorCode', saved.last_error_code,
    'latencyMs', saved.latency_ms
  );
end;
$$;

create or replace function public.record_translation_sync_run(
  p_kind text,
  p_provider text,
  p_items jsonb,
  p_outcomes jsonb,
  p_resume_cursor jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  created_job_id uuid;
  item_count integer;
  succeeded_count integer;
  failed_count integer;
  derived_status text;
begin
  if actor_id is null or not public.is_staff() then
    raise exception 'translation run recording requires staff access' using errcode = '42501';
  end if;
  if p_kind not in ('article', 'literary_work', 'writer', 'country', 'site_copy')
    or p_provider not in ('cloudflare', 'openai') then
    raise exception 'invalid translation run identity' using errcode = '22023';
  end if;
  if jsonb_typeof(p_items) <> 'array'
    or jsonb_typeof(p_outcomes) <> 'array'
    or jsonb_typeof(p_resume_cursor) <> 'object' then
    raise exception 'invalid translation run payload' using errcode = '22023';
  end if;
  item_count := jsonb_array_length(p_items);
  if item_count < 1 or item_count > 500 or jsonb_array_length(p_outcomes) <> item_count then
    raise exception 'invalid translation run item count' using errcode = '22023';
  end if;
  if exists (
    select 1
    from jsonb_array_elements(p_items) item(value)
    where jsonb_typeof(item.value) <> 'object'
      or coalesce(item.value->>'entityType', '') <> p_kind
      or char_length(btrim(coalesce(item.value->>'entityId', ''))) not between 1 and 1200
      or coalesce(item.value->>'entityId', '') ~ '[[:cntrl:]]'
      or (
        item.value ? 'sourceHash'
        and coalesce(item.value->>'sourceHash', '') !~ '^[a-f0-9]{64}$'
      )
  ) then
    raise exception 'invalid translation run item' using errcode = '22023';
  end if;
  if exists (
    select 1
    from jsonb_array_elements(p_items) item(value)
    group by item.value->>'entityType', item.value->>'entityId'
    having count(*) > 1
  ) then
    raise exception 'duplicate translation run item' using errcode = '23505';
  end if;
  if exists (
    select 1
    from jsonb_array_elements(p_outcomes) outcome(value)
    where coalesce(outcome.value->>'status', '') not in (
      'succeeded', 'conflict', 'stale', 'skipped', 'not-configured', 'dead_letter'
    )
      or (
        coalesce(outcome.value->>'status', '') in ('succeeded', 'skipped')
        and outcome.value ? 'errorCode'
        and nullif(outcome.value->>'errorCode', '') is not null
      )
  ) then
    raise exception 'invalid translation run outcome' using errcode = '22023';
  end if;

  select
    count(*) filter (where value->>'status' = 'succeeded'),
    count(*) filter (where value->>'status' = 'dead_letter')
  into succeeded_count, failed_count
  from jsonb_array_elements(p_outcomes) outcome(value);

  select case
    when exists (select 1 from jsonb_array_elements(p_outcomes) o(value) where value->>'status' = 'dead_letter')
      then case when succeeded_count > 0 then 'partial' else 'failed' end
    when exists (select 1 from jsonb_array_elements(p_outcomes) o(value) where value->>'status' = 'conflict') then 'conflict'
    when exists (select 1 from jsonb_array_elements(p_outcomes) o(value) where value->>'status' = 'stale') then 'stale'
    when exists (select 1 from jsonb_array_elements(p_outcomes) o(value) where value->>'status' = 'not-configured') then 'not-configured'
    when succeeded_count = 0 then 'skipped'
    else 'completed'
  end into derived_status;

  insert into public.translation_jobs (
    kind, provider, status, total_items, succeeded_items, failed_items,
    requested_by, started_at, completed_at, resume_cursor
  ) values (
    p_kind, p_provider, derived_status, item_count, succeeded_count, failed_count,
    actor_id, now(), now(), p_resume_cursor
  ) returning id into created_job_id;

  insert into public.translation_job_items (
    job_id, position, entity_type, entity_id, source_hash, status,
    attempt_count, max_attempts, last_error_code
  )
  select
    created_job_id,
    (item.position - 1)::integer,
    item.value->>'entityType',
    btrim(item.value->>'entityId'),
    nullif(item.value->>'sourceHash', ''),
    outcome.value->>'status',
    1,
    1,
    nullif(outcome.value->>'errorCode', '')
  from jsonb_array_elements(p_items) with ordinality item(value, position)
  join jsonb_array_elements(p_outcomes) with ordinality outcome(value, position)
    using (position);

  insert into public.translation_job_attempts (
    item_id, attempt_number, outcome, provider, model,
    provider_request_id, error_code, input_tokens, output_tokens, duration_ms
  )
  select
    item.id,
    1,
    outcome.value->>'status',
    p_provider,
    nullif(outcome.value->>'model', ''),
    nullif(outcome.value->>'requestId', ''),
    nullif(outcome.value->>'errorCode', ''),
    nullif(outcome.value->>'inputTokens', '')::integer,
    nullif(outcome.value->>'outputTokens', '')::integer,
    nullif(outcome.value->>'durationMs', '')::integer
  from public.translation_job_items item
  join jsonb_array_elements(p_outcomes) with ordinality outcome(value, position)
    on item.position = outcome.position - 1
  where item.job_id = created_job_id;

  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor_id,
    'translation.sync_run.recorded',
    'translation_job',
    created_job_id::text,
    jsonb_build_object(
      'kind', p_kind,
      'status', derived_status,
      'itemCount', item_count,
      'resumeCursor', p_resume_cursor
    )
  );

  return created_job_id;
end;
$$;

create or replace function public.get_translation_job_resume(p_job_id uuid)
returns jsonb
language sql
stable
security invoker
set search_path = ''
as $$
  select case when public.is_staff() then jsonb_build_object(
    'id', job.id,
    'kind', job.kind,
    'resumeCursor', job.resume_cursor,
    'status', job.status
  ) else null end
  from public.translation_jobs job
  where job.id = p_job_id;
$$;

-- The bounded staff runner below is the active resume path. The base lease
-- worker remains service-role-only so a scheduled worker can use the same
-- durable rows without widening browser or authenticated-user privileges.
revoke all on function public.claim_translation_job_items(text,integer,integer)
  from public, anon, authenticated, service_role;
revoke all on function public.complete_translation_job_item(
  uuid,text,boolean,text,text,text,integer,integer,integer
) from public, anon, authenticated, service_role;
grant execute on function public.claim_translation_job_items(text,integer,integer)
  to service_role;
grant execute on function public.complete_translation_job_item(
  uuid,text,boolean,text,text,text,integer,integer,integer
) to service_role;

create or replace function public.get_translation_operations_status()
returns jsonb
language sql
stable
security invoker
set search_path = ''
as $$
  with totals as (
    select
      count(*) filter (where job.status = 'queued') as queued,
      count(*) filter (where job.status in ('running', 'reviewing', 'cancelling')) as running,
      count(*) filter (where job.status = 'completed') as completed,
      count(*) filter (
        where job.status in (
          'partial', 'failed', 'conflict', 'stale', 'not-configured'
        )
      ) as attention
    from public.translation_jobs job
  ), recent as (
    select coalesce(jsonb_agg(jsonb_build_object(
      'id', job.id,
      'kind', job.kind,
      'status', job.status,
      'totalItems', job.total_items,
      'succeededItems', job.succeeded_items,
      'failedItems', job.failed_items,
      'resumeCursor', job.resume_cursor,
      'createdAt', job.created_at,
      'updatedAt', job.updated_at
    ) order by job.created_at desc), '[]'::jsonb) as items
    from (
      select * from public.translation_jobs order by created_at desc limit 12
    ) job
  )
  select case when public.is_staff() then jsonb_build_object(
    'queued', totals.queued,
    'running', totals.running,
    'completed', totals.completed,
    'attention', totals.attention,
    'deadLetterItems', (
      select count(*) from public.translation_job_items item
      where item.status = 'dead_letter'
    ),
    'recent', recent.items,
    'runnerMode', 'staff-bounded-sync-resume'
  ) else null end
  from totals cross join recent;
$$;

create or replace function public.translation_operations_ready()
returns boolean
language sql
stable
security invoker
set search_path = ''
as $$
  select public.is_staff()
    and to_regclass('public.translation_jobs') is not null
    and to_regclass('public.translation_job_items') is not null
    and to_regclass('public.translation_job_attempts') is not null
    and to_regclass('public.translation_provider_self_tests') is not null
    and to_regprocedure(
      'public.create_translation_job(text,text,jsonb,integer)'
    ) is not null
    and to_regprocedure(
      'public.claim_translation_job_items(text,integer,integer)'
    ) is not null
    and to_regprocedure(
      'public.complete_translation_job_item(uuid,text,boolean,text,text,text,integer,integer,integer)'
    ) is not null
    and to_regprocedure(
      'public.begin_translation_provider_self_test(text,boolean,boolean,text,integer)'
    ) is not null
    and to_regprocedure(
      'public.record_translation_sync_run(text,text,jsonb,jsonb,jsonb)'
    ) is not null
    and to_regprocedure('public.get_translation_job_resume(uuid)') is not null
    and has_function_privilege(
      'authenticated',
      'public.create_translation_job(text,text,jsonb,integer)',
      'EXECUTE'
    )
    and has_function_privilege(
      'service_role',
      'public.claim_translation_job_items(text,integer,integer)',
      'EXECUTE'
    )
    and has_function_privilege(
      'service_role',
      'public.complete_translation_job_item(uuid,text,boolean,text,text,text,integer,integer,integer)',
      'EXECUTE'
    )
    and has_function_privilege(
      'authenticated',
      'public.begin_translation_provider_self_test(text,boolean,boolean,text,integer)',
      'EXECUTE'
    )
    and has_function_privilege(
      'authenticated',
      'public.finish_translation_provider_self_test(text,uuid,boolean,boolean,boolean,text,integer,text)',
      'EXECUTE'
    )
    and has_function_privilege(
      'authenticated',
      'public.record_translation_sync_run(text,text,jsonb,jsonb,jsonb)',
      'EXECUTE'
    )
    and has_function_privilege(
      'authenticated',
      'public.get_translation_job_resume(uuid)',
      'EXECUTE'
    );
$$;

revoke all on function public.begin_translation_provider_self_test(
  text,boolean,boolean,text,integer
) from public, anon, authenticated, service_role;
revoke all on function public.finish_translation_provider_self_test(
  text,uuid,boolean,boolean,boolean,text,integer,text
) from public, anon, authenticated, service_role;
revoke all on function public.record_translation_sync_run(
  text,text,jsonb,jsonb,jsonb
) from public, anon, authenticated, service_role;
revoke all on function public.get_translation_job_resume(uuid)
  from public, anon, authenticated, service_role;

grant execute on function public.begin_translation_provider_self_test(
  text,boolean,boolean,text,integer
) to authenticated;
grant execute on function public.finish_translation_provider_self_test(
  text,uuid,boolean,boolean,boolean,text,integer,text
) to authenticated;
grant execute on function public.record_translation_sync_run(
  text,text,jsonb,jsonb,jsonb
) to authenticated;
grant execute on function public.get_translation_job_resume(uuid)
  to authenticated;

-- Finish an existing staff synchronous article scan without fabricating an
-- item or changing the result of its already recorded batch. No content,
-- worker leases, direct table privileges or existing private schema changes.
create schema if not exists probpera_translation_operations;
revoke all on schema probpera_translation_operations
  from public, anon, authenticated, service_role;

create or replace function probpera_translation_operations.complete_article_scan(
  p_job_id uuid,
  p_expected_cursor jsonb
)
returns jsonb
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  uuid_pattern constant text := '^([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$';
  expected_scan jsonb;
  desired_cursor jsonb;
  upper_id uuid;
  after_id uuid;
  locked_job public.translation_jobs%rowtype;
begin
  if actor_id is null or not public.is_staff() then
    raise exception 'article scan completion requires staff access' using errcode = '42501';
  end if;
  if p_job_id is null or p_job_id::text !~* uuid_pattern
    or jsonb_typeof(p_expected_cursor) is distinct from 'object'
    or octet_length(p_expected_cursor::text) > 65536 then
    raise exception 'invalid article scan completion identity' using errcode = '22023';
  end if;
  expected_scan := p_expected_cursor -> 'articleScan';
  if jsonb_typeof(expected_scan) is distinct from 'object' then
    raise exception 'invalid article scan completion cursor' using errcode = '22023';
  end if;
  if not (expected_scan ?& array[
      'version', 'order', 'upperId', 'afterId', 'pendingIds',
      'nextIndex', 'lastWindow', 'exhausted'
    ]) or expected_scan - array[
      'version', 'order', 'upperId', 'afterId', 'pendingIds',
      'nextIndex', 'lastWindow', 'exhausted'
    ] <> '{}'::jsonb
    or expected_scan -> 'version' <> '1'::jsonb
    or expected_scan -> 'order' <> '"id"'::jsonb
    or expected_scan -> 'pendingIds' <> '[]'::jsonb
    or expected_scan -> 'nextIndex' <> '0'::jsonb
    or expected_scan -> 'lastWindow' <> 'false'::jsonb
    or expected_scan -> 'exhausted' <> 'false'::jsonb
    or jsonb_typeof(expected_scan -> 'upperId') <> 'string'
    or jsonb_typeof(expected_scan -> 'afterId') <> 'string'
    or (expected_scan ->> 'upperId') !~* uuid_pattern
    or (expected_scan ->> 'afterId') !~* uuid_pattern then
    raise exception 'invalid article scan completion boundary' using errcode = '22023';
  end if;
  upper_id := (expected_scan ->> 'upperId')::uuid;
  after_id := (expected_scan ->> 'afterId')::uuid;
  if after_id > upper_id then
    raise exception 'invalid article scan completion order' using errcode = '22023';
  end if;

  select * into locked_job from public.translation_jobs
    where id = p_job_id for update;
  if not found then
    raise exception 'article scan job not found' using errcode = 'P0002';
  end if;
  if locked_job.kind <> 'article' then
    raise exception 'invalid article scan job kind' using errcode = '22023';
  end if;
  if locked_job.status not in (
    'completed', 'partial', 'failed', 'conflict', 'stale', 'skipped', 'not-configured'
  ) then
    raise exception 'article scan job cannot continue' using errcode = '42501';
  end if;
  desired_cursor := jsonb_set(
    jsonb_set(p_expected_cursor, '{articleScan,lastWindow}', 'true'::jsonb, false),
    '{articleScan,exhausted}', 'true'::jsonb, false
  );
  -- A replay of the same accepted intent has no second audit or version bump.
  if locked_job.resume_cursor = desired_cursor then
    return jsonb_build_object('id', locked_job.id, 'kind', locked_job.kind,
      'status', locked_job.status, 'resumeCursor', locked_job.resume_cursor);
  end if;
  if locked_job.resume_cursor is distinct from p_expected_cursor then
    raise exception 'article scan cursor changed' using errcode = '40001';
  end if;
  -- Recheck in the database after the empty client-side selection. This is
  -- completion at this read snapshot, not immutable membership of the archive.
  if exists (
    select 1 from public.articles article
    where article.status = 'published' and article.deleted_at is null
      and article.id > after_id and article.id <= upper_id
  ) then
    raise exception 'article scan still has candidates' using errcode = '40001';
  end if;
  update public.translation_jobs
    set resume_cursor = desired_cursor, version = version + 1,
      updated_at = clock_timestamp()
    where id = locked_job.id
    returning * into locked_job;
  insert into public.admin_audit_log(actor_id, action, entity_type, entity_id, metadata)
    values (actor_id, 'translation.article_scan.completed', 'translation_job',
      locked_job.id::text, jsonb_build_object('upperId', upper_id,
        'afterId', after_id, 'jobVersion', locked_job.version::text));
  return jsonb_build_object('id', locked_job.id, 'kind', locked_job.kind,
    'status', locked_job.status, 'resumeCursor', locked_job.resume_cursor);
end;
$$;

revoke all on function probpera_translation_operations.complete_article_scan(uuid,jsonb)
  from public, anon, authenticated, service_role;
grant execute on function probpera_translation_operations.complete_article_scan(uuid,jsonb)
  to authenticated;

-- The SQL-standard body binds the helper at definition time. The invoker
-- needs only its EXECUTE grant, never USAGE on the private namespace.
create or replace function public.complete_article_translation_scan(
  p_job_id uuid,
  p_expected_cursor jsonb
)
returns jsonb
language sql
volatile
security invoker
set search_path = ''
return probpera_translation_operations.complete_article_scan(p_job_id, p_expected_cursor);

revoke all on function public.complete_article_translation_scan(uuid,jsonb)
  from public, anon, authenticated, service_role;
grant execute on function public.complete_article_translation_scan(uuid,jsonb)
  to authenticated;

-- An explicit, bounded staff retry of one existing article item. Provider
-- calls happen outside SQL; an admitted operation never expires into a new
-- admission. Only a private English working copy can be persisted here.
alter table public.translation_job_items add column staff_retry jsonb;
alter table public.translation_job_items add constraint translation_item_staff_retry_shape
  check (staff_retry is null or (jsonb_typeof(staff_retry) = 'object'
    and octet_length(staff_retry::text) <= 16384));
alter table public.translation_job_attempts add column staff_retry_operation_id uuid;
alter table public.translation_job_attempts add column staff_retry_receipt jsonb;
alter table public.translation_job_attempts add constraint translation_attempt_staff_retry_shape
  check ((staff_retry_operation_id is null and staff_retry_receipt is null)
    or (staff_retry_operation_id is not null and jsonb_typeof(staff_retry_receipt) is not distinct from 'object'
      and octet_length(staff_retry_receipt::text) <= 32768));
create unique index translation_item_staff_retry_operation_unique
  on public.translation_job_items ((staff_retry ->> 'operationId')) where staff_retry is not null;
create unique index translation_attempt_staff_retry_operation_unique
  on public.translation_job_attempts (staff_retry_operation_id) where staff_retry_operation_id is not null;

create or replace function probpera_translation_operations.retry_access()
returns void language plpgsql stable security invoker set search_path = '' as $$
begin
  if (select auth.uid()) is null or not public.is_staff() then
    raise exception 'article item retry requires staff access' using errcode = '42501';
  end if;
end; $$;

create or replace function probpera_translation_operations.retry_uuid(p_value uuid)
returns boolean language sql immutable security invoker set search_path = ''
return p_value is not null and p_value::text ~* '^([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$';

create or replace function probpera_translation_operations.retry_fingerprint(p_value jsonb)
returns text language sql immutable security invoker set search_path = ''
return encode(sha256(convert_to(p_value::text, 'UTF8')), 'hex');

-- Match the existing JavaScript/Zod string bounds, including astral symbols.
create or replace function probpera_translation_operations.retry_text_length(p_value text)
returns integer language sql immutable security invoker set search_path=''
return char_length(p_value)+regexp_count(p_value,U&'[\+010000-\+10FFFF]');

-- A conservative HTTP(S) subset of the existing URL parser. Unsupported
-- legacy URLs block admission instead of creating an unreadable copy.
create or replace function probpera_translation_operations.retry_url(p_value text)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare parts text[]; address inet;
begin
  if p_value is null or p_value ~ '[[:space:][:cntrl:]]' then return false; end if;
  parts:=regexp_match(p_value,'^https?://([A-Za-z0-9][A-Za-z0-9.-]*|\[[0-9A-Fa-f:]+\])(:[0-9]{1,5})?([/?#].*)?$','i');
  if parts is null or (parts[2] is not null and substr(parts[2],2)::integer>65535) then return false; end if;
  if left(parts[1],1)='[' then
    address:=substr(parts[1],2,char_length(parts[1])-2)::inet;
    if family(address)<>6 then return false; end if;
  elsif parts[1] ~ '^[0-9.]+$' then
    if parts[1] !~ '^(0|[1-9][0-9]{0,2})([.](0|[1-9][0-9]{0,2})){3}$' then return false; end if;
    address:=parts[1]::inet;
    if family(address)<>4 then return false; end if;
  elsif parts[1] ~* '(^|[.])([0-9]+|0x[0-9a-f]+)[.]?$' then
    return false;
  end if;
  return true;
exception when invalid_text_representation then return false;
end; $$;

create or replace function probpera_translation_operations.retry_payload_valid(p_value jsonb,p_english boolean)
returns boolean language plpgsql immutable security invoker set search_path = '' as $$
declare keys text[]; rule record; value jsonb; document jsonb;
begin
  keys := case when p_english then array[
    'title','subtitle','excerpt','content_json','content_html','cover_alt','slug','sources','bibliography',
    'seo_title','seo_description','seo_keywords','canonical_url','og_title','og_description','status',
    'source_content_hash','reviewed_at','approved_at','published_at','deleted_at'
  ] else array[
    'title','subtitle','excerpt','slug','content_html','content_json','category_id','status','scheduled_at',
    'published_at','cover_external_url','cover_alt','legacy_path','seo_title','seo_description','seo_keywords',
    'canonical_url','og_title','og_description','allow_indexing','sources','bibliography','featured','show_on_homepage','pinned'
  ] end;
  if p_value is null or jsonb_typeof(p_value) is distinct from 'object'
    or octet_length(p_value::text) > 5242880 or not(p_value ?& keys)
    or p_value - keys <> '{}'::jsonb or p_value -> 'status' <> '"draft"'::jsonb
    or jsonb_typeof(p_value -> 'content_json') is distinct from 'object' then return false; end if;
  for rule in select * from (values
    ('title',3,240),('subtitle',0,360),('excerpt',0,700),('slug',case when p_english then 2 else 1 end,180),
    ('content_html',0,2000000),('cover_alt',0,500),('seo_title',0,180),('seo_description',0,400),
    ('og_title',0,180),('og_description',0,400)
  ) as fields(name,minimum,maximum) loop
    if jsonb_typeof(p_value -> rule.name) is distinct from 'string'
      or probpera_translation_operations.retry_text_length(p_value ->> rule.name) not between rule.minimum and rule.maximum then return false; end if;
  end loop;
  if p_value -> 'canonical_url' = 'null'::jsonb then
    if not p_english then return false; end if;
  elsif jsonb_typeof(p_value -> 'canonical_url') is distinct from 'string'
    or not probpera_translation_operations.retry_url(p_value ->> 'canonical_url') then return false; end if;
  for rule in select * from (values ('sources',100),('bibliography',100),('seo_keywords',30)) as fields(name,maximum) loop
    if jsonb_typeof(p_value -> rule.name) is distinct from 'array'
      or jsonb_array_length(p_value -> rule.name) > rule.maximum then return false; end if;
    for value in select item.value from jsonb_array_elements(p_value -> rule.name) item(value) loop
      if rule.name = 'seo_keywords' then
        if jsonb_typeof(value) is distinct from 'string' or probpera_translation_operations.retry_text_length(value #>> '{}') > 80 then return false; end if;
      elsif jsonb_typeof(value) is distinct from 'object' or not(value ? 'text')
        or value - 'text' <> '{}'::jsonb or jsonb_typeof(value -> 'text') is distinct from 'string'
        or probpera_translation_operations.retry_text_length(value ->> 'text') > 1000 then return false; end if;
    end loop;
  end loop;
  if p_english then
    if jsonb_typeof(p_value -> 'source_content_hash') is distinct from 'string'
      or (p_value ->> 'source_content_hash') !~ '^[a-f0-9]{64}$'
      or p_value -> 'reviewed_at' <> 'null'::jsonb or p_value -> 'approved_at' <> 'null'::jsonb
      or p_value -> 'published_at' <> 'null'::jsonb or p_value -> 'deleted_at' <> 'null'::jsonb then return false; end if;
    document := p_value -> 'content_json' -> '__probperaPremiumTranslation';
    if jsonb_typeof(document) is distinct from 'object'
      or document -> 'version' is distinct from '1'::jsonb or document -> 'method' is distinct from '"machine-translation"'::jsonb
      or document -> 'sourceHash' is distinct from p_value -> 'source_content_hash' then return false; end if;
  else
    if p_value -> 'scheduled_at' <> 'null'::jsonb or p_value -> 'published_at' <> 'null'::jsonb
      or (p_value -> 'category_id' <> 'null'::jsonb and
        (jsonb_typeof(p_value -> 'category_id') is distinct from 'string'
          or (p_value ->> 'category_id') !~* '^([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$'))
      or (p_value -> 'legacy_path' <> 'null'::jsonb and jsonb_typeof(p_value -> 'legacy_path') is distinct from 'string')
      or (p_value -> 'cover_external_url' <> 'null'::jsonb and
        (jsonb_typeof(p_value -> 'cover_external_url') is distinct from 'string'
          or not probpera_translation_operations.retry_url(p_value ->> 'cover_external_url'))) then return false; end if;
    for rule in select name from (values('allow_indexing'),('featured'),('show_on_homepage'),('pinned')) fields(name) loop
      if jsonb_typeof(p_value -> rule.name) is distinct from 'boolean' then return false; end if;
    end loop;
  end if;
  return true;
exception when others then return false;
end; $$;

create or replace function probpera_translation_operations.begin_article_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_expected_job_version bigint,
  p_expected_attempt_count integer,p_expected_source_hash text,p_expected_article_updated_at timestamptz,
  p_expected_english_updated_at timestamptz,p_provider text
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  actor uuid:=(select auth.uid()); intent jsonb; prior jsonb; view jsonb; active jsonb; snapshot jsonb;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id)
    or p_expected_job_version is null or p_expected_job_version<1 or p_expected_job_version>9223372036854775805
    or p_expected_attempt_count is null or p_expected_attempt_count not between 0 and 4
    or p_expected_source_hash is null or p_expected_source_hash !~ '^[a-f0-9]{64}$'
    or p_expected_article_updated_at is null or p_provider is null or p_provider not in ('cloudflare','openai') then
    raise exception 'invalid article retry intent' using errcode='22023'; end if;
  intent:=jsonb_build_array(p_job_id,p_item_id,p_operation_id,actor,p_expected_job_version::text,
    p_expected_attempt_count,p_expected_source_hash,p_expected_article_updated_at,p_expected_english_updated_at,p_provider);
  -- Bind the UUID globally across active items and completed attempts before
  -- admitting any provider work. This lock lasts only for the SQL request.
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior is not null then
    if prior ->> 'actorId' is distinct from actor::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if prior -> 'beginIntent' is distinct from intent then
      raise exception 'article retry intent changed' using errcode='40001'; end if;
    return prior -> 'receipt' || jsonb_build_object('replayed',true,'canExecute',false);
  end if;
  if exists(select 1 from public.translation_job_items other where other.staff_retry ->> 'operationId'=p_operation_id::text
    and (other.id<>p_item_id or other.job_id<>p_job_id)) then
    raise exception 'article retry UUID already belongs to another item' using errcode='40001'; end if;
  -- Existing worker completion locks item before job. Cancellation locks job
  -- before queued/retry_wait items; this path admits only finished failed
  -- items and excludes every worker-active item before changing state.
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  if item.id is null or job.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  if item.staff_retry is not null then
    if item.staff_retry ->> 'actorId' is distinct from actor::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if item.staff_retry -> 'beginIntent' is distinct from intent then
      raise exception 'article retry already active or intent changed' using errcode='40001'; end if;
    return probpera_translation_operations.retry_view(job,item,'running',null,item.staff_retry,
      (item.staff_retry ->> 'sourceUpdatedAt')::timestamptz,
      (item.staff_retry ->> 'englishUpdatedAt')::timestamptz,false,true);
  end if;
  if job.version is distinct from p_expected_job_version or item.attempt_count is distinct from p_expected_attempt_count
    or item.source_hash is distinct from p_expected_source_hash or job.provider is distinct from p_provider then
    raise exception 'article retry item or job changed' using errcode='40001'; end if;
  view:=probpera_translation_operations.get_article_item_retry(p_job_id,p_item_id,null);
  if view ->> 'phase'<>'ready' then
    if view ->> 'blockReason'='operation_stopped' then
      raise exception 'article retry was stopped' using errcode='42501'; end if;
    raise exception 'article retry is not eligible' using errcode='40001';
  end if;
  select * into article from public.articles where id=item.entity_id::uuid for update;
  select * into english from public.article_translations where article_id=article.id and locale='en' for update;
  if article.updated_at is distinct from p_expected_article_updated_at
    or english.updated_at is distinct from p_expected_english_updated_at then
    raise exception 'article retry source or English changed' using errcode='40001'; end if;
  if article.id is null or article.deleted_at is not null or article.status<>'published'
    or exists(select 1 from public.article_working_drafts where article_id=article.id) then
    raise exception 'article retry source or draft changed' using errcode='40001'; end if;
  if english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
    or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash) then
    raise exception 'article retry English ownership changed' using errcode='40001'; end if;
  snapshot:=probpera_translation_operations.retry_ru_snapshot(article);
  active:=jsonb_build_object('version',1,'operationId',p_operation_id,'actorId',actor,'articleId',article.id,
    'beginIntent',intent,'sourceUpdatedAt',p_expected_article_updated_at,'englishUpdatedAt',p_expected_english_updated_at,
    'attemptNumber',item.attempt_count+1,'startedAt',clock_timestamp(),
    'sourceSnapshotHash',probpera_translation_operations.retry_fingerprint(snapshot));
  update public.translation_job_items set staff_retry=active,status='reviewing',
    max_attempts=attempt_count+1,lease_owner=null,lease_expires_at=null,updated_at=clock_timestamp()
    where id=item.id returning * into item;
  update public.translation_jobs set status='reviewing',failed_items=(select count(*) from public.translation_job_items
    where job_id=job.id and status='dead_letter'),completed_at=null,version=version+1,updated_at=clock_timestamp()
    where id=job.id returning * into job;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'translation.article_item_retry.began','translation_job',job.id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',item.id,'attemptNumber',item.attempt_count+1,
        'sourceHash',item.source_hash,'jobVersion',job.version::text));
  return probpera_translation_operations.retry_view(job,item,'running',null,active,
    p_expected_article_updated_at,p_expected_english_updated_at,true,false);
end; $$;

create or replace function probpera_translation_operations.retry_ru_snapshot(p_article public.articles)
returns jsonb language plpgsql stable security invoker set search_path = '' as $$
declare payload jsonb;
begin
  payload := jsonb_build_object(
    'title',p_article.title,'subtitle',coalesce(p_article.subtitle,''),'excerpt',coalesce(p_article.excerpt,''),
    'slug',p_article.slug,'content_html',p_article.content_html,'content_json',p_article.content_json,
    'category_id',p_article.category_id,'status','draft','scheduled_at',null,'published_at',null,
    'cover_external_url',p_article.cover_external_url,'cover_alt',coalesce(p_article.cover_alt,''),
    'legacy_path',p_article.legacy_path,'seo_title',coalesce(p_article.seo_title,''),
    'seo_description',coalesce(p_article.seo_description,''),'seo_keywords',coalesce(to_jsonb(p_article.seo_keywords),'[]'::jsonb),
    'canonical_url',p_article.canonical_url,'og_title',coalesce(p_article.og_title,''),
    'og_description',coalesce(p_article.og_description,''),'allow_indexing',p_article.allow_indexing,
    'sources',coalesce(p_article.sources,'[]'::jsonb),'bibliography',coalesce(p_article.bibliography,'[]'::jsonb),
    'featured',p_article.featured,'show_on_homepage',p_article.show_on_homepage,'pinned',p_article.pinned);
  if not probpera_translation_operations.retry_payload_valid(payload,false) then
    raise exception 'article source cannot form a compatible private copy' using errcode='22023';
  end if;
  return payload;
end; $$;

create or replace function probpera_translation_operations.retry_view(
  p_job public.translation_jobs,p_item public.translation_job_items,p_phase text,
  p_reason text,p_active jsonb,p_source_updated_at timestamptz,p_english_updated_at timestamptz,
  p_can_execute boolean default false,p_replayed boolean default false,p_result jsonb default null
)
returns jsonb language sql stable security invoker set search_path='' set timezone='UTC'
return jsonb_build_object('version',1,'jobId',p_job.id,'itemId',p_item.id,'articleId',coalesce(p_active -> 'articleId',to_jsonb(p_item.entity_id::uuid)),
  'provider',p_job.provider,'sourceHash',p_item.source_hash,'sourceUpdatedAt',p_source_updated_at,
  'englishUpdatedAt',p_english_updated_at,'jobVersion',p_job.version::text,
  'attemptCount',p_item.attempt_count,'maxAttempts',p_item.max_attempts,'jobStatus',p_job.status,
  'itemStatus',p_item.status,'operationId',p_active -> 'operationId','phase',p_phase,
  'canExecute',p_can_execute,'replayed',p_replayed,'retryable',p_phase='ready',
  'blockReason',p_reason,'result',p_result);

create or replace function probpera_translation_operations.get_article_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid default null
)
returns jsonb language plpgsql stable security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  prior jsonb; reason text; active jsonb;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or (p_operation_id is not null and not probpera_translation_operations.retry_uuid(p_operation_id)) then
    raise exception 'invalid article item retry identity' using errcode='22023'; end if;
  select * into job from public.translation_jobs where id=p_job_id;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id;
  if job.id is null or item.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  if job.kind<>'article' or item.entity_type<>'article' or job.source_locale<>'ru' or job.target_locale<>'en'
    or item.entity_id !~* '^([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$' then
    raise exception 'invalid article retry domain' using errcode='22023'; end if;
  if p_operation_id is not null then
    select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
    if prior is not null then
      if prior ->> 'actorId' is distinct from (select auth.uid())::text then
        raise exception 'article retry actor changed' using errcode='42501'; end if;
      if prior -> 'receipt' ->> 'jobId' is distinct from p_job_id::text
        or prior -> 'receipt' ->> 'itemId' is distinct from p_item_id::text then
        raise exception 'article retry identity changed' using errcode='40001'; end if;
      return prior -> 'receipt' || jsonb_build_object('replayed',true);
    end if;
    if item.staff_retry ->> 'operationId' is distinct from p_operation_id::text then
      raise exception 'article retry operation not found' using errcode='P0002'; end if;
    if item.staff_retry ->> 'actorId' is distinct from (select auth.uid())::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
  end if;
  if item.staff_retry is not null then
    if item.staff_retry ->> 'actorId' is distinct from (select auth.uid())::text then
      return probpera_translation_operations.retry_view(job,item,'blocked','retry_busy',null,null,null);
    end if;
    active:=item.staff_retry;
    return probpera_translation_operations.retry_view(job,item,'running',null,active,
      (active ->> 'sourceUpdatedAt')::timestamptz,(active ->> 'englishUpdatedAt')::timestamptz,false,true);
  end if;
  if job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then reason:='operation_stopped';
  elsif not exists(select 1 from public.admin_audit_log a where a.action='translation.sync_run.recorded'
    and a.entity_type='translation_job' and a.entity_id=job.id::text) then reason:='job_not_sync';
  elsif job.status not in ('completed','partial','failed','conflict','stale','skipped','not-configured') then reason:='job_not_finished';
  elsif item.source_hash is null then reason:='source_hash_missing';
  elsif item.status not in ('dead_letter','conflict','stale','not-configured') then reason:='item_not_failed';
  elsif item.attempt_count>=5 or item.max_attempts>5 then reason:='attempt_limit';
  elsif exists(select 1 from public.translation_job_items other where other.job_id=job.id
    and (other.status in ('queued','leased','reviewing','retry_wait') or other.staff_retry is not null)) then reason:='retry_busy'; end if;
  select * into article from public.articles where id=item.entity_id::uuid;
  select * into english from public.article_translations where article_id=item.entity_id::uuid and locale='en';
  if reason is null then
    if article.id is null or article.deleted_at is not null or article.status<>'published' then reason:='source_unavailable';
    elsif exists(select 1 from public.article_working_drafts where article_id=article.id) then reason:='author_draft_exists';
    elsif english.id is not null and (english.deleted_at is not null
      or english.source_content_hash is null or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
      or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
      or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash) then reason:='manual_english';
    else
      begin perform probpera_translation_operations.retry_ru_snapshot(article);
      exception when invalid_parameter_value then reason:='source_shape_unsupported'; end;
    end if;
  end if;
  return probpera_translation_operations.retry_view(job,item,case when reason is null then 'ready' else 'blocked' end,
    reason,null,article.updated_at,english.updated_at);
end; $$;

create or replace function probpera_translation_operations.finish_article_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_english_payload jsonb default null
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  actor uuid:=(select auth.uid()); active jsonb; prior jsonb; request_hash text;
  outcome text; code text; attempt_outcome text; snapshot jsonb; saved jsonb; result jsonb; receipt jsonb;
  source_stamp timestamptz; english_stamp timestamptz; attempt_number integer;
  succeeded integer; failed integer; conflicts integer; stale integer; not_configured integer;
  field text; field_value jsonb; draft_stamp timestamptz;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id)
    or jsonb_typeof(p_outcome) is distinct from 'object' or octet_length(p_outcome::text)>16384
    or not(p_outcome ?& array['status','providerCalls'])
    or p_outcome - array['status','providerCalls','errorCode','model','requestId','inputTokens','outputTokens','durationMs'] <> '{}'::jsonb
    or jsonb_typeof(p_outcome -> 'status') is distinct from 'string'
    or p_outcome ->> 'status' not in ('succeeded','dead_letter','conflict','stale','skipped','not-configured')
    or jsonb_typeof(p_outcome -> 'providerCalls') is distinct from 'number'
    or (p_outcome ->> 'providerCalls') !~ '^[0-4]$' then
    raise exception 'invalid article retry outcome' using errcode='22023'; end if;
  outcome:=p_outcome ->> 'status'; code:=p_outcome ->> 'errorCode';
  if (p_outcome ? 'errorCode' and p_outcome -> 'errorCode'<>'null'::jsonb
      and jsonb_typeof(p_outcome -> 'errorCode') is distinct from 'string')
    or (outcome in ('succeeded','skipped') and code is not null)
    or (outcome not in ('succeeded','skipped') and (code is null or code not in (
      'translation_not_configured','provider_unavailable','provider_request_failed','provider_invalid_response',
      'source_changed','write_conflict','database_read_failed','database_write_failed','unexpected'))) then
    raise exception 'invalid article retry error' using errcode='22023'; end if;
  foreach field in array array['model','requestId'] loop
    field_value:=p_outcome -> field;
    if field_value is not null and field_value<>'null'::jsonb and
      (jsonb_typeof(field_value) is distinct from 'string' or probpera_translation_operations.retry_text_length(p_outcome ->> field) not between 1 and 200) then
      raise exception 'invalid article retry provider metadata' using errcode='22023'; end if;
  end loop;
  foreach field in array array['inputTokens','outputTokens','durationMs'] loop
    field_value:=p_outcome -> field;
    if field_value is not null and field_value<>'null'::jsonb and
      (jsonb_typeof(field_value) is distinct from 'number' or (p_outcome ->> field) !~ '^[0-9]{1,8}$'
        or (p_outcome ->> field)::numeric > case when field='durationMs' then 3600000 else 10000000 end) then
      raise exception 'invalid article retry usage metadata' using errcode='22023'; end if;
  end loop;
  if outcome='succeeded' then
    if jsonb_typeof(p_english_payload) is distinct from 'object'
      or not(p_english_payload ?& array['mode','payload']) or p_english_payload - array['mode','payload']<>'{}'::jsonb
      or p_english_payload -> 'mode' is distinct from '"save"'::jsonb
      or not probpera_translation_operations.retry_payload_valid(p_english_payload -> 'payload',true) then
      raise exception 'invalid article retry private English' using errcode='22023'; end if;
  elsif p_english_payload is not null then
    raise exception 'non-successful article retry cannot persist English' using errcode='22023';
  end if;
  request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_outcome,p_english_payload));
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior is not null then
    if prior ->> 'actorId' is distinct from actor::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if prior -> 'receipt' ->> 'jobId' is distinct from p_job_id::text
      or prior -> 'receipt' ->> 'itemId' is distinct from p_item_id::text
      or prior ->> 'finishFingerprint' is distinct from request_hash then
      raise exception 'article retry finish intent changed' using errcode='40001'; end if;
    return prior -> 'receipt' || jsonb_build_object('replayed',true,'canExecute',false);
  end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  if item.id is null or job.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  active:=item.staff_retry;
  if active ->> 'operationId' is distinct from p_operation_id::text then
    raise exception 'article retry operation not found' using errcode='P0002'; end if;
  if active ->> 'actorId' is distinct from actor::text then
    raise exception 'article retry actor changed' using errcode='42501'; end if;
  source_stamp:=(active ->> 'sourceUpdatedAt')::timestamptz;
  english_stamp:=(active ->> 'englishUpdatedAt')::timestamptz;
  attempt_number:=(active ->> 'attemptNumber')::integer;
  if item.status<>'reviewing' or item.lease_owner is not null or item.lease_expires_at is not null
    or attempt_number is distinct from item.attempt_count+1 or attempt_number not between 1 and 5
    or job.kind<>'article' or item.entity_type<>'article' or job.source_locale<>'ru' or job.target_locale<>'en'
    or active -> 'version' is distinct from '1'::jsonb
    or (active ->> 'articleId')::uuid is distinct from item.entity_id::uuid
    or active -> 'beginIntent' ->> 0 is distinct from job.id::text
    or active -> 'beginIntent' ->> 1 is distinct from item.id::text
    or active -> 'beginIntent' ->> 2 is distinct from p_operation_id::text
    or active -> 'beginIntent' ->> 3 is distinct from actor::text
    or active -> 'beginIntent' ->> 6 is distinct from item.source_hash
    or active -> 'beginIntent' ->> 9 is distinct from job.provider then
    raise exception 'article retry active item changed' using errcode='40001'; end if;
  if outcome='succeeded' and p_english_payload -> 'payload' ->> 'source_content_hash' is distinct from item.source_hash then
    raise exception 'article retry English source changed' using errcode='22023'; end if;
  select * into article from public.articles where id=item.entity_id::uuid for update;
  select * into english from public.article_translations where article_id=item.entity_id::uuid and locale='en' for update;
  -- A known provider outcome is always journaled. A cancelled or changed
  -- source has no draft write, and does not turn generated text into review.
  if job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then
    outcome:='cancelled'; code:=null;
  elsif outcome='succeeded' then
    if article.id is null or article.deleted_at is not null or article.status<>'published'
      or article.updated_at is distinct from source_stamp then outcome:='stale'; code:='source_changed';
    elsif english.updated_at is distinct from english_stamp
      or exists(select 1 from public.article_working_drafts where article_id=article.id)
      or (english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
        or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
        or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
        or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash)) then
      outcome:='conflict'; code:='write_conflict';
    else
      begin snapshot:=probpera_translation_operations.retry_ru_snapshot(article);
      exception when invalid_parameter_value then snapshot:=null; end;
      if snapshot is null or probpera_translation_operations.retry_fingerprint(snapshot) is distinct from active ->> 'sourceSnapshotHash' then
        outcome:='stale'; code:='source_changed';
      else
        saved:=public.save_article_working_draft(article.id,source_stamp,snapshot,p_english_payload,english_stamp,0);
        if saved ->> 'articleId' is distinct from article.id::text or saved -> 'version' is distinct from '1'::jsonb
          or jsonb_typeof(saved -> 'updatedAt') is distinct from 'string' then
          raise exception 'invalid article retry private draft receipt' using errcode='22023'; end if;
        draft_stamp:=(saved ->> 'updatedAt')::timestamptz;
        update public.article_working_drafts set draft_scope='english-only',draft_english_enabled=true
          where article_id=article.id and version=1;
        if not found then raise exception 'article retry private draft changed' using errcode='40001'; end if;
      end if;
    end if;
  end if;
  update public.translation_job_items set status=case when outcome='cancelled' then 'cancelled' else outcome end,
    attempt_count=attempt_number,staff_retry=null,lease_owner=null,lease_expires_at=null,last_error_code=code,
    updated_at=clock_timestamp() where id=item.id returning * into item;
  select count(*) filter(where status='succeeded'),count(*) filter(where status='dead_letter'),
    count(*) filter(where status='conflict'),count(*) filter(where status='stale'),count(*) filter(where status='not-configured')
    into succeeded,failed,conflicts,stale,not_configured from public.translation_job_items where job_id=job.id;
  update public.translation_jobs set succeeded_items=succeeded,failed_items=failed,
    status=case when outcome='cancelled' then 'cancelled'
      when failed>0 then case when succeeded>0 then 'partial' else 'failed' end
      when conflicts>0 then 'conflict' when stale>0 then 'stale' when not_configured>0 then 'not-configured'
      when succeeded=0 then 'skipped' else 'completed' end,
    completed_at=clock_timestamp(),version=version+1,updated_at=clock_timestamp()
    where id=job.id returning * into job;
  result:=jsonb_build_object('outcome',outcome,'errorCode',code,
    'persistence',case when saved is not null then 'working-draft' else 'none' end,
    'workingDraftVersion',case when saved is not null then 1 else null end,'workingDraftUpdatedAt',draft_stamp,
    'publication','unchanged','humanReview',case when saved is not null then 'pending' else 'unchanged' end,
    'providerCalls',(p_outcome ->> 'providerCalls')::integer);
  receipt:=probpera_translation_operations.retry_view(job,item,'finished',null,active,source_stamp,english_stamp,false,false,result);
  attempt_outcome:=case when outcome='cancelled' then 'skipped' else outcome end;
  insert into public.translation_job_attempts(item_id,attempt_number,outcome,provider,model,provider_request_id,
    error_code,input_tokens,output_tokens,duration_ms,staff_retry_operation_id,staff_retry_receipt)
    values(item.id,attempt_number,attempt_outcome,job.provider,p_outcome ->> 'model',p_outcome ->> 'requestId',code,
      (p_outcome ->> 'inputTokens')::integer,(p_outcome ->> 'outputTokens')::integer,(p_outcome ->> 'durationMs')::integer,
      p_operation_id,jsonb_build_object('actorId',actor,'beginIntent',active -> 'beginIntent',
        'finishFingerprint',request_hash,'receipt',receipt));
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'translation.article_item_retry.finished','translation_job',job.id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',item.id,'attemptNumber',attempt_number,
        'outcome',outcome,'persistence',result -> 'persistence','jobVersion',job.version::text));
  return receipt;
end; $$;

create or replace function public.get_article_translation_item_retry(p_job_id uuid,p_item_id uuid,p_operation_id uuid default null)
returns jsonb language sql stable security invoker set search_path=''
return probpera_translation_operations.get_article_item_retry(p_job_id,p_item_id,p_operation_id);
create or replace function public.begin_article_translation_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_expected_job_version bigint,p_expected_attempt_count integer,
  p_expected_source_hash text,p_expected_article_updated_at timestamptz,p_expected_english_updated_at timestamptz,p_provider text)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.begin_article_item_retry(p_job_id,p_item_id,p_operation_id,p_expected_job_version,
  p_expected_attempt_count,p_expected_source_hash,p_expected_article_updated_at,p_expected_english_updated_at,p_provider);
create or replace function public.finish_article_translation_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_english_payload jsonb default null)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.finish_article_item_retry(p_job_id,p_item_id,p_operation_id,p_outcome,p_english_payload);

do $retry_acl$
declare signature text;
begin
  foreach signature in array array[
    'probpera_translation_operations.retry_access()',
    'probpera_translation_operations.retry_uuid(uuid)',
    'probpera_translation_operations.retry_fingerprint(jsonb)',
    'probpera_translation_operations.retry_text_length(text)',
    'probpera_translation_operations.retry_url(text)',
    'probpera_translation_operations.retry_payload_valid(jsonb,boolean)',
    'probpera_translation_operations.retry_ru_snapshot(public.articles)',
    'probpera_translation_operations.retry_view(public.translation_jobs,public.translation_job_items,text,text,jsonb,timestamp with time zone,timestamp with time zone,boolean,boolean,jsonb)',
    'probpera_translation_operations.get_article_item_retry(uuid,uuid,uuid)',
    'probpera_translation_operations.begin_article_item_retry(uuid,uuid,uuid,bigint,integer,text,timestamp with time zone,timestamp with time zone,text)',
    'probpera_translation_operations.finish_article_item_retry(uuid,uuid,uuid,jsonb,jsonb)',
    'public.get_article_translation_item_retry(uuid,uuid,uuid)',
    'public.begin_article_translation_item_retry(uuid,uuid,uuid,bigint,integer,text,timestamp with time zone,timestamp with time zone,text)',
    'public.finish_article_translation_item_retry(uuid,uuid,uuid,jsonb,jsonb)'
  ] loop
    execute format('revoke all on function %s from public,anon,authenticated,service_role',signature::regprocedure);
  end loop;
end; $retry_acl$;
grant execute on function probpera_translation_operations.get_article_item_retry(uuid,uuid,uuid) to authenticated;
grant execute on function probpera_translation_operations.begin_article_item_retry(uuid,uuid,uuid,bigint,integer,text,timestamptz,timestamptz,text) to authenticated;
grant execute on function probpera_translation_operations.finish_article_item_retry(uuid,uuid,uuid,jsonb,jsonb) to authenticated;
grant execute on function public.get_article_translation_item_retry(uuid,uuid,uuid) to authenticated;
grant execute on function public.begin_article_translation_item_retry(uuid,uuid,uuid,bigint,integer,text,timestamptz,timestamptz,text) to authenticated;
grant execute on function public.finish_article_translation_item_retry(uuid,uuid,uuid,jsonb,jsonb) to authenticated;

-- Bounded metadata for an explicit staff item retry. A dispatch record is an
-- admission, not evidence that a provider accepted or completed a request.
-- Unknown admission/transport results never expire into another admission.
create or replace function probpera_translation_operations.retry_journal_valid(p_value jsonb,p_provider text)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare call jsonb; previous jsonb; seen text[]:='{}'; n integer:=0; field text; stamp timestamptz;
begin
  if p_provider is null or p_provider not in ('openai','cloudflare')
    or p_value is null or jsonb_typeof(p_value) is distinct from 'object'
    or p_value - array['version','updatedAt','calls'] <> '{}'::jsonb
    or not(p_value ?& array['version','updatedAt','calls']) or p_value -> 'version' is distinct from '1'::jsonb
    or jsonb_typeof(p_value -> 'updatedAt') is distinct from 'string'
    or jsonb_typeof(p_value -> 'calls') is distinct from 'array' or jsonb_array_length(p_value -> 'calls')>4 then return false; end if;
  stamp:=(p_value ->> 'updatedAt')::timestamptz;
  if not isfinite(stamp) then return false; end if;
  for call in select value from jsonb_array_elements(p_value -> 'calls') loop
    n:=n+1;
    if jsonb_typeof(call) is distinct from 'object'
      or not(call ?& array['callId','provider','model','pass','dispatchRecordedAt','responseReceivedAt','httpStatus','requestId','responseId','inputTokens','outputTokens'])
      or call - array['callId','provider','model','pass','dispatchRecordedAt','responseReceivedAt','httpStatus','requestId','responseId','inputTokens','outputTokens'] <> '{}'::jsonb
      or jsonb_typeof(call -> 'callId') is distinct from 'string'
      or not probpera_translation_operations.retry_uuid((call ->> 'callId')::uuid)
      or call ->> 'callId' <> ((call ->> 'callId')::uuid)::text or call ->> 'callId'=any(seen)
      or jsonb_typeof(call -> 'provider') is distinct from 'string' or call ->> 'provider' is distinct from p_provider
      or jsonb_typeof(call -> 'model') is distinct from 'string'
      or probpera_translation_operations.retry_text_length(call ->> 'model') not between 1 and 200
      or jsonb_typeof(call -> 'pass') is distinct from 'string' or call ->> 'pass' not in ('translation','repair','review')
      or jsonb_typeof(call -> 'dispatchRecordedAt') is distinct from 'string' then return false; end if;
    stamp:=(call ->> 'dispatchRecordedAt')::timestamptz;
    if not isfinite(stamp) then return false; end if;
    if (n=1 and call ->> 'pass'<>'translation')
      or (n>1 and (previous -> 'responseReceivedAt'='null'::jsonb or not(
        (n=2 and call ->> 'pass' in ('repair','review'))
        or (n=3 and previous ->> 'pass'='repair' and call ->> 'pass'='review')
        or (n=3 and previous ->> 'pass'='review' and call ->> 'pass'='repair')
        or (n=4 and previous ->> 'pass'='review' and call ->> 'pass'='repair')))) then return false; end if;
    if call -> 'responseReceivedAt'='null'::jsonb then
      foreach field in array array['httpStatus','requestId','responseId','inputTokens','outputTokens'] loop
        if call -> field <> 'null'::jsonb then return false; end if;
      end loop;
    elsif jsonb_typeof(call -> 'responseReceivedAt')='string' then
      stamp:=(call ->> 'responseReceivedAt')::timestamptz;
      if not isfinite(stamp) then return false; end if;
      if call -> 'httpStatus'<>'null'::jsonb and (jsonb_typeof(call -> 'httpStatus')<>'number'
        or (call ->> 'httpStatus') !~ '^[1-5][0-9]{2}$') then return false; end if;
      foreach field in array array['requestId','responseId'] loop
        if call -> field<>'null'::jsonb and (jsonb_typeof(call -> field)<>'string'
          or probpera_translation_operations.retry_text_length(call ->> field) not between 1 and 200) then return false; end if;
      end loop;
      foreach field in array array['inputTokens','outputTokens'] loop
        if call -> field<>'null'::jsonb and (jsonb_typeof(call -> field)<>'number'
          or (call ->> field) !~ '^[0-9]{1,8}$' or (call ->> field)::numeric>10000000) then return false; end if;
      end loop;
    else return false; end if;
    seen:=array_append(seen,call ->> 'callId'); previous:=call;
  end loop;
  return true;
exception when others then return false;
end; $$;

create or replace function probpera_translation_operations.retry_journal_active(
  p_job public.translation_jobs,p_item public.translation_job_items,p_operation_id uuid
)
returns void language plpgsql stable security invoker set search_path='' as $$
declare active jsonb:=p_item.staff_retry; actor uuid:=(select auth.uid());
begin
  if active ->> 'operationId' is distinct from p_operation_id::text then
    raise exception 'article retry operation not found' using errcode='P0002'; end if;
  if active ->> 'actorId' is distinct from actor::text then
    raise exception 'article retry actor changed' using errcode='42501'; end if;
  if p_item.status<>'reviewing' or p_item.lease_owner is not null or p_item.lease_expires_at is not null
    or p_job.kind<>'article' or p_item.entity_type<>'article' or p_job.source_locale<>'ru' or p_job.target_locale<>'en'
    or p_job.provider not in ('openai','cloudflare') or p_item.source_hash is null or p_item.source_hash !~ '^[a-f0-9]{64}$'
    or active -> 'version' is distinct from '1'::jsonb
    or not probpera_translation_operations.retry_uuid(p_item.entity_id::uuid)
    or (active ->> 'articleId')::uuid is distinct from p_item.entity_id::uuid
    or (active ->> 'attemptNumber')::integer is distinct from p_item.attempt_count+1
    or p_item.attempt_count not between 0 and 4 or p_item.max_attempts<>p_item.attempt_count+1
    or active -> 'beginIntent' ->> 0 is distinct from p_job.id::text
    or active -> 'beginIntent' ->> 1 is distinct from p_item.id::text
    or active -> 'beginIntent' ->> 2 is distinct from p_operation_id::text
    or active -> 'beginIntent' ->> 3 is distinct from actor::text
    or active -> 'beginIntent' ->> 6 is distinct from p_item.source_hash
    or active -> 'beginIntent' ->> 9 is distinct from p_job.provider
    or active -> 'sourceUpdatedAt' is distinct from active -> 'beginIntent' -> 7
    or active -> 'englishUpdatedAt' is distinct from active -> 'beginIntent' -> 8
    or (active -> 'progress' is not null and active -> 'progress'<>'null'::jsonb
      and not probpera_translation_operations.retry_journal_valid(active -> 'progress',p_job.provider)) then
    raise exception 'article retry active item changed' using errcode='40001'; end if;
end; $$;

create or replace function probpera_translation_operations.retry_journal_view(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_receipt jsonb,p_progress jsonb,
  p_started_at jsonb,p_updated_at timestamptz,p_phase text,p_can_dispatch boolean,p_replayed boolean
)
returns jsonb language sql stable security invoker set search_path='' set timezone='UTC'
return jsonb_build_object('version',1,'jobId',p_job_id,'itemId',p_item_id,
  'articleId',p_receipt -> 'articleId','operationId',p_operation_id,'provider',p_receipt -> 'provider',
  'phase',p_phase,'startedAt',p_started_at,'updatedAt',coalesce(p_progress -> 'updatedAt',to_jsonb(p_updated_at)),
  'providerCalls',jsonb_array_length(coalesce(p_progress -> 'calls','[]'::jsonb)),
  'canDispatch',p_can_dispatch,'replayed',p_replayed,'calls',coalesce(p_progress -> 'calls','[]'::jsonb));

create or replace function probpera_translation_operations.get_article_item_retry_progress(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  prior public.translation_job_attempts%rowtype; receipt jsonb; progress jsonb; active jsonb;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id) then
    raise exception 'invalid article retry progress identity' using errcode='22023'; end if;
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  select * into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior.id is not null then
    if prior.staff_retry_receipt ->> 'actorId' is distinct from (select auth.uid())::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    receipt:=prior.staff_retry_receipt -> 'receipt'; progress:=nullif(prior.staff_retry_receipt -> 'progress','null'::jsonb);
    if receipt ->> 'jobId' is distinct from p_job_id::text or receipt ->> 'itemId' is distinct from p_item_id::text
      or (progress is not null and not probpera_translation_operations.retry_journal_valid(progress,receipt ->> 'provider')) then
      raise exception 'article retry progress identity changed' using errcode='40001'; end if;
    return probpera_translation_operations.retry_journal_view(p_job_id,p_item_id,p_operation_id,receipt,progress,
      prior.staff_retry_receipt -> 'startedAt',prior.created_at,'finished',false,true);
  end if;
  select other.staff_retry into active from public.translation_job_items other
    where other.staff_retry ->> 'operationId'=p_operation_id::text;
  if active is not null then
    if active ->> 'actorId' is distinct from (select auth.uid())::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if active -> 'beginIntent' ->> 0 is distinct from p_job_id::text
      or active -> 'beginIntent' ->> 1 is distinct from p_item_id::text then
      raise exception 'article retry progress identity changed' using errcode='40001'; end if;
  end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id;
  select * into job from public.translation_jobs where id=p_job_id;
  if item.id is null or job.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  perform probpera_translation_operations.retry_journal_active(job,item,p_operation_id);
  active:=item.staff_retry; progress:=nullif(active -> 'progress','null'::jsonb);
  receipt:=jsonb_build_object('articleId',item.entity_id::uuid,'provider',job.provider);
  return probpera_translation_operations.retry_journal_view(p_job_id,p_item_id,p_operation_id,receipt,progress,
    active -> 'startedAt',item.updated_at,'running',false,false);
end; $$;

create or replace function probpera_translation_operations.record_article_item_retry_dispatch(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_call_id uuid,p_provider text,p_model text,p_pass text
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  view jsonb; active jsonb; progress jsonb; calls jsonb; call jsonb; last_call jsonb; now_at timestamptz;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_call_id) or p_provider is null or p_provider not in ('openai','cloudflare')
    or p_model is null or probpera_translation_operations.retry_text_length(p_model) not between 1 and 200
    or p_pass is null or p_pass not in ('translation','repair','review') then
    raise exception 'invalid article retry dispatch metadata' using errcode='22023'; end if;
  -- GET holds the same operation advisory lock. Mutations preserve item -> job
  -- order used by retry FINISH and worker completion; no lease is granted.
  view:=probpera_translation_operations.get_article_item_retry_progress(p_job_id,p_item_id,p_operation_id);
  for call in select value from jsonb_array_elements(view -> 'calls') loop
    if call ->> 'callId'=p_call_id::text then
      if call ->> 'provider' is distinct from p_provider or call ->> 'model' is distinct from p_model
        or call ->> 'pass' is distinct from p_pass then
        raise exception 'article retry dispatch intent changed' using errcode='40001'; end if;
      return view || jsonb_build_object('canDispatch',false,'replayed',true);
    end if;
  end loop;
  if view ->> 'phase'='finished' then return view || jsonb_build_object('canDispatch',false,'replayed',true); end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  perform probpera_translation_operations.retry_journal_active(job,item,p_operation_id);
  if p_provider is distinct from job.provider or job.status<>'reviewing' or job.cancel_requested_at is not null then
    raise exception 'article retry dispatch was stopped' using errcode='40001'; end if;
  active:=item.staff_retry; calls:=coalesce(active -> 'progress' -> 'calls','[]'::jsonb);
  if jsonb_array_length(calls)>=4 then raise exception 'article retry dispatch budget exhausted' using errcode='40001'; end if;
  if jsonb_array_length(calls)>0 then
    last_call:=calls -> (jsonb_array_length(calls)-1);
    if last_call -> 'responseReceivedAt'='null'::jsonb then
      raise exception 'article retry previous response is unknown' using errcode='40001'; end if;
  end if;
  select * into article from public.articles where id=item.entity_id::uuid for update;
  select * into english from public.article_translations where article_id=item.entity_id::uuid and locale='en' for update;
  if article.id is null or article.status<>'published' or article.deleted_at is not null
    or article.updated_at is distinct from (active ->> 'sourceUpdatedAt')::timestamptz
    or english.updated_at is distinct from (active ->> 'englishUpdatedAt')::timestamptz
    or exists(select 1 from public.article_working_drafts where article_id=article.id)
    or probpera_translation_operations.retry_fingerprint(probpera_translation_operations.retry_ru_snapshot(article))
      is distinct from active ->> 'sourceSnapshotHash' then
    raise exception 'article retry source or draft changed before dispatch' using errcode='40001'; end if;
  if english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
    or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash) then
    raise exception 'article retry English ownership changed before dispatch' using errcode='40001'; end if;
  now_at:=clock_timestamp();
  call:=jsonb_build_object('callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,
    'dispatchRecordedAt',now_at,'responseReceivedAt',null,'httpStatus',null,'requestId',null,'responseId',null,
    'inputTokens',null,'outputTokens',null);
  progress:=jsonb_build_object('version',1,'updatedAt',now_at,'calls',calls||jsonb_build_array(call));
  if not probpera_translation_operations.retry_journal_valid(progress,job.provider) then
    raise exception 'article retry pass sequence changed' using errcode='40001'; end if;
  active:=active||jsonb_build_object('progress',progress);
  update public.translation_job_items set staff_retry=active,updated_at=now_at where id=item.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values((select auth.uid()),'translation.article_item_retry.dispatch_recorded','translation_job',job.id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',item.id,'callId',p_call_id,
        'provider',p_provider,'model',p_model,'pass',p_pass,'recordedAdmissions',jsonb_array_length(progress -> 'calls')));
  return probpera_translation_operations.retry_journal_view(p_job_id,p_item_id,p_operation_id,view,progress,
    active -> 'startedAt',now_at,'running',true,false);
end; $$;

create or replace function probpera_translation_operations.record_article_item_retry_response(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_metadata jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  view jsonb; progress jsonb; call jsonb; fields text[]:=array['callId','provider','model','pass','httpStatus','requestId','responseId','inputTokens','outputTokens'];
  position integer; idx integer:=0; now_at timestamptz; candidate jsonb;
begin
  perform probpera_translation_operations.retry_access();
  if jsonb_typeof(p_metadata) is distinct from 'object' or not(p_metadata ?& fields)
    or p_metadata-fields<>'{}'::jsonb or octet_length(p_metadata::text)>4096
    or jsonb_typeof(p_metadata -> 'pass') is distinct from 'string'
    or jsonb_typeof(p_metadata -> 'callId') is distinct from 'string'
    or (p_metadata ->> 'callId') !~* '^([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$' then
    raise exception 'invalid article retry response metadata' using errcode='22023'; end if;
  p_metadata:=p_metadata||jsonb_build_object('callId',(p_metadata ->> 'callId')::uuid);
  candidate:=p_metadata||jsonb_build_object('dispatchRecordedAt',clock_timestamp(),'responseReceivedAt',clock_timestamp());
  -- Validate each metadata field without admitting a new call or trusting prose.
  if not probpera_translation_operations.retry_journal_valid(jsonb_build_object('version',1,'updatedAt',clock_timestamp(),
      'calls',jsonb_build_array(candidate||jsonb_build_object('pass','translation'))),p_metadata ->> 'provider')
    or p_metadata ->> 'provider' not in ('openai','cloudflare') or p_metadata ->> 'pass' not in ('translation','repair','review') then
    raise exception 'invalid article retry response fields' using errcode='22023'; end if;
  view:=probpera_translation_operations.get_article_item_retry_progress(p_job_id,p_item_id,p_operation_id);
  for call in select value from jsonb_array_elements(view -> 'calls') loop
    if call ->> 'callId'=p_metadata ->> 'callId' then position:=idx; exit; end if;
    idx:=idx+1;
  end loop;
  if position is null then raise exception 'article retry response dispatch not found' using errcode='40001'; end if;
  if call ->> 'provider' is distinct from p_metadata ->> 'provider' or call ->> 'model' is distinct from p_metadata ->> 'model'
    or call ->> 'pass' is distinct from p_metadata ->> 'pass' then
    raise exception 'article retry response identity changed' using errcode='40001'; end if;
  if call -> 'responseReceivedAt'<>'null'::jsonb then
    if call-array['dispatchRecordedAt','responseReceivedAt'] is distinct from p_metadata then
      raise exception 'article retry response evidence changed' using errcode='40001'; end if;
    return view||jsonb_build_object('canDispatch',false,'replayed',true);
  end if;
  if view ->> 'phase'='finished' then raise exception 'article retry finished without this response' using errcode='40001'; end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  perform probpera_translation_operations.retry_journal_active(job,item,p_operation_id);
  now_at:=clock_timestamp(); progress:=item.staff_retry -> 'progress';
  progress:=jsonb_set(progress,array['calls',position::text],call||p_metadata||jsonb_build_object('responseReceivedAt',now_at));
  progress:=progress||jsonb_build_object('updatedAt',now_at);
  if not probpera_translation_operations.retry_journal_valid(progress,job.provider) then
    raise exception 'article retry response journal changed' using errcode='40001'; end if;
  update public.translation_job_items set staff_retry=staff_retry||jsonb_build_object('progress',progress),updated_at=now_at where id=item.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values((select auth.uid()),'translation.article_item_retry.response_received','translation_job',job.id::text,
      p_metadata||jsonb_build_object('operationId',p_operation_id,'itemId',item.id));
  return probpera_translation_operations.retry_journal_view(p_job_id,p_item_id,p_operation_id,view,progress,
    item.staff_retry -> 'startedAt',now_at,'running',false,false);
end; $$;

-- Preserve the existing private-draft/attempt/audit transaction and freeze
-- the bounded journal in that same attempt. The original migration is intact.
create or replace function probpera_translation_operations.finish_article_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_english_payload jsonb default null
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  actor uuid:=(select auth.uid()); active jsonb; prior jsonb; request_hash text;
  outcome text; code text; attempt_outcome text; snapshot jsonb; saved jsonb; result jsonb; receipt jsonb;
  source_stamp timestamptz; english_stamp timestamptz; attempt_number integer;
  succeeded integer; failed integer; conflicts integer; stale integer; not_configured integer;
  field text; field_value jsonb; draft_stamp timestamptz;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id)
    or jsonb_typeof(p_outcome) is distinct from 'object' or octet_length(p_outcome::text)>16384
    or not(p_outcome ?& array['status','providerCalls'])
    or p_outcome - array['status','providerCalls','errorCode','model','requestId','inputTokens','outputTokens','durationMs'] <> '{}'::jsonb
    or jsonb_typeof(p_outcome -> 'status') is distinct from 'string'
    or p_outcome ->> 'status' not in ('succeeded','dead_letter','conflict','stale','skipped','not-configured')
    or jsonb_typeof(p_outcome -> 'providerCalls') is distinct from 'number'
    or (p_outcome ->> 'providerCalls') !~ '^[0-4]$' then
    raise exception 'invalid article retry outcome' using errcode='22023'; end if;
  outcome:=p_outcome ->> 'status'; code:=p_outcome ->> 'errorCode';
  if (p_outcome ? 'errorCode' and p_outcome -> 'errorCode'<>'null'::jsonb
      and jsonb_typeof(p_outcome -> 'errorCode') is distinct from 'string')
    or (outcome in ('succeeded','skipped') and code is not null)
    or (outcome not in ('succeeded','skipped') and (code is null or code not in (
      'translation_not_configured','provider_unavailable','provider_request_failed','provider_invalid_response',
      'source_changed','write_conflict','database_read_failed','database_write_failed','unexpected'))) then
    raise exception 'invalid article retry error' using errcode='22023'; end if;
  foreach field in array array['model','requestId'] loop
    field_value:=p_outcome -> field;
    if field_value is not null and field_value<>'null'::jsonb and
      (jsonb_typeof(field_value) is distinct from 'string' or probpera_translation_operations.retry_text_length(p_outcome ->> field) not between 1 and 200) then
      raise exception 'invalid article retry provider metadata' using errcode='22023'; end if;
  end loop;
  foreach field in array array['inputTokens','outputTokens','durationMs'] loop
    field_value:=p_outcome -> field;
    if field_value is not null and field_value<>'null'::jsonb and
      (jsonb_typeof(field_value) is distinct from 'number' or (p_outcome ->> field) !~ '^[0-9]{1,8}$'
        or (p_outcome ->> field)::numeric > case when field='durationMs' then 3600000 else 10000000 end) then
      raise exception 'invalid article retry usage metadata' using errcode='22023'; end if;
  end loop;
  if outcome='succeeded' then
    if jsonb_typeof(p_english_payload) is distinct from 'object'
      or not(p_english_payload ?& array['mode','payload']) or p_english_payload - array['mode','payload']<>'{}'::jsonb
      or p_english_payload -> 'mode' is distinct from '"save"'::jsonb
      or not probpera_translation_operations.retry_payload_valid(p_english_payload -> 'payload',true) then
      raise exception 'invalid article retry private English' using errcode='22023'; end if;
  elsif p_english_payload is not null then
    raise exception 'non-successful article retry cannot persist English' using errcode='22023';
  end if;
  request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_outcome,p_english_payload));
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior is not null then
    if prior ->> 'actorId' is distinct from actor::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if prior -> 'receipt' ->> 'jobId' is distinct from p_job_id::text
      or prior -> 'receipt' ->> 'itemId' is distinct from p_item_id::text
      or prior ->> 'finishFingerprint' is distinct from request_hash then
      raise exception 'article retry finish intent changed' using errcode='40001'; end if;
    return prior -> 'receipt' || jsonb_build_object('replayed',true,'canExecute',false);
  end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  if item.id is null or job.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  active:=item.staff_retry;
  if active ->> 'operationId' is distinct from p_operation_id::text then
    raise exception 'article retry operation not found' using errcode='P0002'; end if;
  if active ->> 'actorId' is distinct from actor::text then
    raise exception 'article retry actor changed' using errcode='42501'; end if;
  source_stamp:=(active ->> 'sourceUpdatedAt')::timestamptz;
  english_stamp:=(active ->> 'englishUpdatedAt')::timestamptz;
  attempt_number:=(active ->> 'attemptNumber')::integer;
  if item.status<>'reviewing' or item.lease_owner is not null or item.lease_expires_at is not null
    or attempt_number is distinct from item.attempt_count+1 or attempt_number not between 1 and 5
    or job.kind<>'article' or item.entity_type<>'article' or job.source_locale<>'ru' or job.target_locale<>'en'
    or active -> 'version' is distinct from '1'::jsonb
    or (active ->> 'articleId')::uuid is distinct from item.entity_id::uuid
    or active -> 'beginIntent' ->> 0 is distinct from job.id::text
    or active -> 'beginIntent' ->> 1 is distinct from item.id::text
    or active -> 'beginIntent' ->> 2 is distinct from p_operation_id::text
    or active -> 'beginIntent' ->> 3 is distinct from actor::text
    or active -> 'beginIntent' ->> 6 is distinct from item.source_hash
    or active -> 'beginIntent' ->> 9 is distinct from job.provider then
    raise exception 'article retry active item changed' using errcode='40001'; end if;
  if outcome='succeeded' and p_english_payload -> 'payload' ->> 'source_content_hash' is distinct from item.source_hash then
    raise exception 'article retry English source changed' using errcode='22023'; end if;
  -- A durable dispatch remains unknown until its received-response record is
  -- acknowledged. Neither a timer nor a caller-supplied failure closes it.
  if active -> 'progress' is not null and active -> 'progress'<>'null'::jsonb then
    if not probpera_translation_operations.retry_journal_valid(active -> 'progress',job.provider)
      or jsonb_array_length(active -> 'progress' -> 'calls') is distinct from (p_outcome ->> 'providerCalls')::integer
      or exists(select 1 from jsonb_array_elements(active -> 'progress' -> 'calls') recorded
        where recorded -> 'responseReceivedAt'='null'::jsonb) then
      raise exception 'article retry provider outcome is unconfirmed' using errcode='40001'; end if;
  end if;
  select * into article from public.articles where id=item.entity_id::uuid for update;
  select * into english from public.article_translations where article_id=item.entity_id::uuid and locale='en' for update;
  -- A known provider outcome is always journaled. A cancelled or changed
  -- source has no draft write, and does not turn generated text into review.
  if job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then
    outcome:='cancelled'; code:=null;
  elsif outcome='succeeded' then
    if article.id is null or article.deleted_at is not null or article.status<>'published'
      or article.updated_at is distinct from source_stamp then outcome:='stale'; code:='source_changed';
    elsif english.updated_at is distinct from english_stamp
      or exists(select 1 from public.article_working_drafts where article_id=article.id)
      or (english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
        or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
        or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
        or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash)) then
      outcome:='conflict'; code:='write_conflict';
    else
      begin snapshot:=probpera_translation_operations.retry_ru_snapshot(article);
      exception when invalid_parameter_value then snapshot:=null; end;
      if snapshot is null or probpera_translation_operations.retry_fingerprint(snapshot) is distinct from active ->> 'sourceSnapshotHash' then
        outcome:='stale'; code:='source_changed';
      else
        saved:=public.save_article_working_draft(article.id,source_stamp,snapshot,p_english_payload,english_stamp,0);
        if saved ->> 'articleId' is distinct from article.id::text or saved -> 'version' is distinct from '1'::jsonb
          or jsonb_typeof(saved -> 'updatedAt') is distinct from 'string' then
          raise exception 'invalid article retry private draft receipt' using errcode='22023'; end if;
        draft_stamp:=(saved ->> 'updatedAt')::timestamptz;
        update public.article_working_drafts set draft_scope='english-only',draft_english_enabled=true
          where article_id=article.id and version=1;
        if not found then raise exception 'article retry private draft changed' using errcode='40001'; end if;
      end if;
    end if;
  end if;
  update public.translation_job_items set status=case when outcome='cancelled' then 'cancelled' else outcome end,
    attempt_count=attempt_number,staff_retry=null,lease_owner=null,lease_expires_at=null,last_error_code=code,
    updated_at=clock_timestamp() where id=item.id returning * into item;
  select count(*) filter(where status='succeeded'),count(*) filter(where status='dead_letter'),
    count(*) filter(where status='conflict'),count(*) filter(where status='stale'),count(*) filter(where status='not-configured')
    into succeeded,failed,conflicts,stale,not_configured from public.translation_job_items where job_id=job.id;
  update public.translation_jobs set succeeded_items=succeeded,failed_items=failed,
    status=case when outcome='cancelled' then 'cancelled'
      when failed>0 then case when succeeded>0 then 'partial' else 'failed' end
      when conflicts>0 then 'conflict' when stale>0 then 'stale' when not_configured>0 then 'not-configured'
      when succeeded=0 then 'skipped' else 'completed' end,
    completed_at=clock_timestamp(),version=version+1,updated_at=clock_timestamp()
    where id=job.id returning * into job;
  result:=jsonb_build_object('outcome',outcome,'errorCode',code,
    'persistence',case when saved is not null then 'working-draft' else 'none' end,
    'workingDraftVersion',case when saved is not null then 1 else null end,'workingDraftUpdatedAt',draft_stamp,
    'publication','unchanged','humanReview',case when saved is not null then 'pending' else 'unchanged' end,
    'providerCalls',(p_outcome ->> 'providerCalls')::integer);
  receipt:=probpera_translation_operations.retry_view(job,item,'finished',null,active,source_stamp,english_stamp,false,false,result);
  attempt_outcome:=case when outcome='cancelled' then 'skipped' else outcome end;
  insert into public.translation_job_attempts(item_id,attempt_number,outcome,provider,model,provider_request_id,
    error_code,input_tokens,output_tokens,duration_ms,staff_retry_operation_id,staff_retry_receipt)
    values(item.id,attempt_number,attempt_outcome,job.provider,p_outcome ->> 'model',p_outcome ->> 'requestId',code,
      (p_outcome ->> 'inputTokens')::integer,(p_outcome ->> 'outputTokens')::integer,(p_outcome ->> 'durationMs')::integer,
      p_operation_id,jsonb_build_object('actorId',actor,'beginIntent',active -> 'beginIntent',
        'finishFingerprint',request_hash,'receipt',receipt,
        'progress',active -> 'progress','startedAt',active -> 'startedAt'));
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'translation.article_item_retry.finished','translation_job',job.id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',item.id,'attemptNumber',attempt_number,
        'outcome',outcome,'persistence',result -> 'persistence','jobVersion',job.version::text));
  return receipt;
end; $$;


create or replace function public.record_article_translation_item_retry_dispatch(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_call_id uuid,p_provider text,p_model text,p_pass text
)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.record_article_item_retry_dispatch(p_job_id,p_item_id,p_operation_id,p_call_id,p_provider,p_model,p_pass);
create or replace function public.record_article_translation_item_retry_response(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_metadata jsonb
)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.record_article_item_retry_response(p_job_id,p_item_id,p_operation_id,p_metadata);
create or replace function public.get_article_translation_item_retry_progress(p_job_id uuid,p_item_id uuid,p_operation_id uuid)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.get_article_item_retry_progress(p_job_id,p_item_id,p_operation_id);

-- No private schema USAGE or service admission privilege is added. Public
-- invoker wrappers call only the staff-guarded definer entry points.
revoke all on function probpera_translation_operations.retry_journal_valid(jsonb,text) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.retry_journal_active(public.translation_jobs,public.translation_job_items,uuid) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.retry_journal_view(uuid,uuid,uuid,jsonb,jsonb,jsonb,timestamptz,text,boolean,boolean) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.get_article_item_retry_progress(uuid,uuid,uuid) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.record_article_item_retry_dispatch(uuid,uuid,uuid,uuid,text,text,text) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.record_article_item_retry_response(uuid,uuid,uuid,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.get_article_translation_item_retry_progress(uuid,uuid,uuid) from public,anon,authenticated,service_role;
revoke all on function public.record_article_translation_item_retry_dispatch(uuid,uuid,uuid,uuid,text,text,text) from public,anon,authenticated,service_role;
revoke all on function public.record_article_translation_item_retry_response(uuid,uuid,uuid,jsonb) from public,anon,authenticated,service_role;
grant execute on function probpera_translation_operations.get_article_item_retry_progress(uuid,uuid,uuid) to authenticated;
grant execute on function probpera_translation_operations.record_article_item_retry_dispatch(uuid,uuid,uuid,uuid,text,text,text) to authenticated;
grant execute on function probpera_translation_operations.record_article_item_retry_response(uuid,uuid,uuid,jsonb) to authenticated;
grant execute on function public.get_article_translation_item_retry_progress(uuid,uuid,uuid) to authenticated;
grant execute on function public.record_article_translation_item_retry_dispatch(uuid,uuid,uuid,uuid,text,text,text) to authenticated;
grant execute on function public.record_article_translation_item_retry_response(uuid,uuid,uuid,jsonb) to authenticated;

-- A validated full English candidate lives only in the existing private
-- working draft. Operation, audit and progress records contain bounded
-- metadata. A stored candidate is never authority for another model call.
create or replace function probpera_translation_operations.retry_candidate_outcome_valid(p_value jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare field text; value jsonb;
begin
  if jsonb_typeof(p_value) is distinct from 'object' or octet_length(p_value::text)>16384
    or not(p_value ?& array['status','providerCalls'])
    or p_value - array['status','providerCalls','errorCode','model','requestId','inputTokens','outputTokens','durationMs']<>'{}'::jsonb
    or p_value -> 'status' is distinct from '"succeeded"'::jsonb
    or jsonb_typeof(p_value -> 'providerCalls') is distinct from 'number'
    or (p_value ->> 'providerCalls') !~ '^[1-4]$'
    or (p_value ? 'errorCode' and p_value -> 'errorCode'<>'null'::jsonb) then return false; end if;
  foreach field in array array['model','requestId'] loop
    value:=p_value -> field;
    if value is not null and value<>'null'::jsonb and
      (jsonb_typeof(value) is distinct from 'string'
       or probpera_translation_operations.retry_text_length(p_value ->> field) not between 1 and 200) then return false; end if;
  end loop;
  foreach field in array array['inputTokens','outputTokens','durationMs'] loop
    value:=p_value -> field;
    if value is not null and value<>'null'::jsonb and
      (jsonb_typeof(value) is distinct from 'number' or (p_value ->> field) !~ '^[0-9]{1,8}$'
       or (p_value ->> field)::numeric>case when field='durationMs' then 3600000 else 10000000 end) then return false; end if;
  end loop;
  return true;
exception when others then return false;
end; $$;

create or replace function probpera_translation_operations.retry_candidate_meta_valid(p_value jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare stamp timestamptz;
begin
  if jsonb_typeof(p_value) is distinct from 'object'
    or not(p_value ?& array['version','preparedAt','candidateHash','finishFingerprint','outcome','workingDraftVersion','workingDraftUpdatedAt'])
    or p_value - array['version','preparedAt','candidateHash','finishFingerprint','outcome','workingDraftVersion','workingDraftUpdatedAt']<>'{}'::jsonb
    or p_value -> 'version' is distinct from '1'::jsonb
    or jsonb_typeof(p_value -> 'preparedAt') is distinct from 'string'
    or jsonb_typeof(p_value -> 'workingDraftUpdatedAt') is distinct from 'string'
    or jsonb_typeof(p_value -> 'candidateHash') is distinct from 'string'
    or (p_value ->> 'candidateHash') !~ '^[a-f0-9]{64}$'
    or jsonb_typeof(p_value -> 'finishFingerprint') is distinct from 'string'
    or (p_value ->> 'finishFingerprint') !~ '^[a-f0-9]{64}$'
    or p_value -> 'workingDraftVersion' is distinct from '1'::jsonb
    or not probpera_translation_operations.retry_candidate_outcome_valid(p_value -> 'outcome') then return false; end if;
  stamp:=(p_value ->> 'preparedAt')::timestamptz;
  if not isfinite(stamp) then return false; end if;
  stamp:=(p_value ->> 'workingDraftUpdatedAt')::timestamptz;
  return isfinite(stamp);
exception when others then return false;
end; $$;

-- The caller holds operation -> item -> job -> article -> English -> draft.
-- This check never writes a canonical article, translation or private draft.
create or replace function probpera_translation_operations.retry_candidate_block_reason(
  p_active jsonb,p_meta jsonb,p_article public.articles,p_english public.article_translations,
  p_draft public.article_working_drafts,p_provider text
)
returns text language plpgsql stable security invoker set search_path='' as $$
declare snapshot jsonb; progress jsonb:=p_active -> 'progress';
begin
  if not probpera_translation_operations.retry_candidate_meta_valid(p_meta) then
    raise exception 'article retry candidate metadata changed' using errcode='40001'; end if;
  if not probpera_translation_operations.retry_journal_valid(progress,p_provider)
    or jsonb_array_length(progress -> 'calls') is distinct from (p_meta -> 'outcome' ->> 'providerCalls')::integer
    or exists(select 1 from jsonb_array_elements(progress -> 'calls') call where call -> 'responseReceivedAt'='null'::jsonb) then
    return 'provider_outcome_unconfirmed'; end if;
  if p_article.id is null or p_article.status<>'published' or p_article.deleted_at is not null
    or p_article.updated_at is distinct from (p_active ->> 'sourceUpdatedAt')::timestamptz then return 'source_changed'; end if;
  begin snapshot:=probpera_translation_operations.retry_ru_snapshot(p_article);
  exception when invalid_parameter_value then return 'source_changed'; end;
  if probpera_translation_operations.retry_fingerprint(snapshot) is distinct from p_active ->> 'sourceSnapshotHash' then return 'source_changed'; end if;
  if p_english.updated_at is distinct from (p_active ->> 'englishUpdatedAt')::timestamptz
    or (p_english.id is not null and (p_english.deleted_at is not null or p_english.source_content_hash is null
      or p_english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
      or p_english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
      or p_english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from p_english.source_content_hash)) then return 'english_changed'; end if;
  if p_draft.article_id is null then return 'draft_missing'; end if;
  if p_draft.actor_id::text is distinct from p_active ->> 'actorId'
    or p_draft.version is distinct from (p_meta ->> 'workingDraftVersion')::bigint
    or p_draft.updated_at is distinct from (p_meta ->> 'workingDraftUpdatedAt')::timestamptz
    or p_draft.base_article_updated_at is distinct from (p_active ->> 'sourceUpdatedAt')::timestamptz
    or p_draft.expected_english_updated_at is distinct from (p_active ->> 'englishUpdatedAt')::timestamptz
    or p_draft.draft_scope is distinct from 'english-only' or p_draft.draft_english_enabled is distinct from true
    or p_draft.payload is distinct from snapshot
    or not probpera_translation_operations.retry_payload_valid(p_draft.english_payload -> 'payload',true)
    or p_draft.english_payload -> 'mode' is distinct from '"save"'::jsonb
    or p_draft.english_payload - array['mode','payload']<>'{}'::jsonb
    or p_draft.english_payload -> 'payload' ->> 'source_content_hash' is distinct from p_active -> 'beginIntent' ->> 6
    or probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_draft.payload,p_draft.english_payload,p_meta -> 'outcome'))
      is distinct from p_meta ->> 'candidateHash'
    or probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_meta -> 'outcome',p_draft.english_payload))
      is distinct from p_meta ->> 'finishFingerprint' then return 'draft_changed'; end if;
  return null;
end; $$;

create or replace function probpera_translation_operations.retry_candidate_view(
  p_receipt jsonb,p_meta jsonb,p_provider_calls integer,p_phase text,p_reason text,p_replayed boolean
)
returns jsonb language sql stable security invoker set search_path='' set timezone='UTC'
return jsonb_build_object('version',1,'jobId',p_receipt -> 'jobId','itemId',p_receipt -> 'itemId',
  'articleId',p_receipt -> 'articleId','operationId',p_receipt -> 'operationId','provider',p_receipt -> 'provider',
  'sourceHash',p_receipt -> 'sourceHash','sourceUpdatedAt',p_receipt -> 'sourceUpdatedAt',
  'englishUpdatedAt',p_receipt -> 'englishUpdatedAt','phase',p_phase,
  'candidateState',case when p_meta is null then 'missing' when p_phase='finished' then 'finished' else 'staged' end,
  'candidateHash',p_meta -> 'candidateHash','preparedAt',p_meta -> 'preparedAt',
  'workingDraftVersion',p_meta -> 'workingDraftVersion','workingDraftUpdatedAt',p_meta -> 'workingDraftUpdatedAt',
  'providerCalls',p_provider_calls,'canRecover',p_phase='running' and p_meta is not null and p_reason is null,
  'replayed',p_replayed,'blockReason',p_reason);

create or replace function probpera_translation_operations.get_article_item_retry_candidate(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  prior public.translation_job_attempts%rowtype; article public.articles%rowtype;
  english public.article_translations%rowtype; draft public.article_working_drafts%rowtype;
  receipt jsonb; active jsonb; meta jsonb; reason text; phase text; calls integer;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id) then
    raise exception 'invalid article retry candidate identity' using errcode='22023'; end if;
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  select * into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior.id is not null then
    if prior.staff_retry_receipt ->> 'actorId' is distinct from (select auth.uid())::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    receipt:=prior.staff_retry_receipt -> 'receipt';
    if receipt ->> 'jobId' is distinct from p_job_id::text or receipt ->> 'itemId' is distinct from p_item_id::text then
      raise exception 'article retry candidate identity changed' using errcode='40001'; end if;
    meta:=nullif(prior.staff_retry_receipt -> 'candidate','null'::jsonb);
    if prior.staff_retry_receipt ? 'candidate' and meta is null then
      raise exception 'article retry candidate metadata changed' using errcode='40001'; end if;
    active:=jsonb_build_object('actorId',prior.staff_retry_receipt -> 'actorId','beginIntent',prior.staff_retry_receipt -> 'beginIntent',
      'sourceUpdatedAt',receipt -> 'sourceUpdatedAt','englishUpdatedAt',receipt -> 'englishUpdatedAt',
      'sourceSnapshotHash',prior.staff_retry_receipt -> 'sourceSnapshotHash','progress',prior.staff_retry_receipt -> 'progress');
    phase:='finished'; calls:=(receipt -> 'result' ->> 'providerCalls')::integer;
  else
    select other.staff_retry into active from public.translation_job_items other where other.staff_retry ->> 'operationId'=p_operation_id::text;
    if active is not null then
      if active ->> 'actorId' is distinct from (select auth.uid())::text then
        raise exception 'article retry actor changed' using errcode='42501'; end if;
      if active -> 'beginIntent' ->> 0 is distinct from p_job_id::text or active -> 'beginIntent' ->> 1 is distinct from p_item_id::text then
        raise exception 'article retry candidate identity changed' using errcode='40001'; end if;
    end if;
    select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
    select * into job from public.translation_jobs where id=p_job_id for update;
    if item.id is null or job.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
    perform probpera_translation_operations.retry_journal_active(job,item,p_operation_id);
    active:=item.staff_retry; meta:=nullif(active -> 'candidate','null'::jsonb);
    if active ? 'candidate' and meta is null then
      raise exception 'article retry candidate metadata changed' using errcode='40001'; end if;
    receipt:=probpera_translation_operations.retry_view(job,item,'running',null,active,
      (active ->> 'sourceUpdatedAt')::timestamptz,(active ->> 'englishUpdatedAt')::timestamptz,false,false);
    phase:='running'; calls:=jsonb_array_length(coalesce(active -> 'progress' -> 'calls','[]'::jsonb));
  end if;
  if meta is null then reason:='candidate_missing';
  else
    select * into article from public.articles where id=(receipt ->> 'articleId')::uuid for update;
    select * into english from public.article_translations where article_id=article.id and locale='en' for update;
    select * into draft from public.article_working_drafts where article_id=article.id for update;
    reason:=probpera_translation_operations.retry_candidate_block_reason(active,meta,article,english,draft,receipt ->> 'provider');
  end if;
  return probpera_translation_operations.retry_candidate_view(receipt,meta,calls,phase,reason,phase='finished');
end; $$;

create or replace function probpera_translation_operations.stage_article_item_retry_candidate(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_english_payload jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  prior public.translation_job_attempts%rowtype; article public.articles%rowtype;
  english public.article_translations%rowtype; draft public.article_working_drafts%rowtype;
  active jsonb; meta jsonb; snapshot jsonb; saved jsonb; receipt jsonb; candidate_hash text; finish_hash text;
  reason text; now_at timestamptz;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id)
    or not probpera_translation_operations.retry_candidate_outcome_valid(p_outcome)
    or jsonb_typeof(p_english_payload) is distinct from 'object'
    or not(p_english_payload ?& array['mode','payload']) or p_english_payload - array['mode','payload']<>'{}'::jsonb
    or p_english_payload -> 'mode' is distinct from '"save"'::jsonb
    or not probpera_translation_operations.retry_payload_valid(p_english_payload -> 'payload',true) then
    raise exception 'invalid article retry candidate' using errcode='22023'; end if;
  finish_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_outcome,p_english_payload));
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  -- Reuse the global operation/actor binding before admitting a new body.
  perform probpera_translation_operations.get_article_item_retry_progress(p_job_id,p_item_id,p_operation_id);
  select * into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior.id is not null then
    if prior.staff_retry_receipt ->> 'actorId' is distinct from (select auth.uid())::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if prior.staff_retry_receipt -> 'receipt' ->> 'jobId' is distinct from p_job_id::text
      or prior.staff_retry_receipt -> 'receipt' ->> 'itemId' is distinct from p_item_id::text
      or prior.staff_retry_receipt -> 'candidate' ->> 'finishFingerprint' is distinct from finish_hash then
      raise exception 'article retry candidate intent changed' using errcode='40001'; end if;
    return probpera_translation_operations.get_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id)||jsonb_build_object('replayed',true);
  end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  if item.id is null or job.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  perform probpera_translation_operations.retry_journal_active(job,item,p_operation_id);
  active:=item.staff_retry; meta:=nullif(active -> 'candidate','null'::jsonb);
  if active ? 'candidate' and meta is null then
    raise exception 'article retry candidate metadata changed' using errcode='40001'; end if;
  if p_english_payload -> 'payload' ->> 'source_content_hash' is distinct from item.source_hash then
    raise exception 'article retry candidate source changed' using errcode='22023'; end if;
  if meta is not null then
    if not probpera_translation_operations.retry_candidate_meta_valid(meta) or meta ->> 'finishFingerprint' is distinct from finish_hash then
      raise exception 'article retry candidate intent changed' using errcode='40001'; end if;
    return probpera_translation_operations.get_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id)||jsonb_build_object('replayed',true);
  end if;
  if job.status<>'reviewing' or job.cancel_requested_at is not null then
    raise exception 'article retry candidate was stopped' using errcode='40001'; end if;
  if not probpera_translation_operations.retry_journal_valid(active -> 'progress',job.provider)
    or jsonb_array_length(active -> 'progress' -> 'calls') is distinct from (p_outcome ->> 'providerCalls')::integer
    or exists(select 1 from jsonb_array_elements(active -> 'progress' -> 'calls') call where call -> 'responseReceivedAt'='null'::jsonb) then
    raise exception 'article retry provider outcome is unconfirmed' using errcode='40001'; end if;
  select * into article from public.articles where id=item.entity_id::uuid for update;
  select * into english from public.article_translations where article_id=item.entity_id::uuid and locale='en' for update;
  select * into draft from public.article_working_drafts where article_id=item.entity_id::uuid for update;
  if article.id is null or article.status<>'published' or article.deleted_at is not null
    or article.updated_at is distinct from (active ->> 'sourceUpdatedAt')::timestamptz then
    raise exception 'article retry candidate source changed' using errcode='40001'; end if;
  snapshot:=probpera_translation_operations.retry_ru_snapshot(article);
  if probpera_translation_operations.retry_fingerprint(snapshot) is distinct from active ->> 'sourceSnapshotHash' then
    raise exception 'article retry candidate source changed' using errcode='40001'; end if;
  if english.updated_at is distinct from (active ->> 'englishUpdatedAt')::timestamptz or draft.article_id is not null
    or (english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
      or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
      or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
      or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash)) then
    raise exception 'article retry candidate English or draft changed' using errcode='40001'; end if;
  candidate_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(snapshot,p_english_payload,p_outcome));
  saved:=public.save_article_working_draft(article.id,(active ->> 'sourceUpdatedAt')::timestamptz,snapshot,
    p_english_payload,(active ->> 'englishUpdatedAt')::timestamptz,0);
  if saved ->> 'articleId' is distinct from article.id::text or saved -> 'version' is distinct from '1'::jsonb
    or jsonb_typeof(saved -> 'updatedAt') is distinct from 'string' then
    raise exception 'invalid article retry candidate draft receipt' using errcode='22023'; end if;
  update public.article_working_drafts set draft_scope='english-only',draft_english_enabled=true where article_id=article.id and version=1;
  if not found then raise exception 'article retry candidate draft changed' using errcode='40001'; end if;
  now_at:=clock_timestamp();
  meta:=jsonb_build_object('version',1,'preparedAt',now_at,'candidateHash',candidate_hash,'finishFingerprint',finish_hash,
    'outcome',p_outcome,'workingDraftVersion',1,'workingDraftUpdatedAt',(saved ->> 'updatedAt')::timestamptz);
  active:=active||jsonb_build_object('candidate',meta);
  if octet_length(active::text)>16384 then raise exception 'article retry candidate metadata exceeds bound' using errcode='22023'; end if;
  update public.translation_job_items set staff_retry=active,updated_at=now_at where id=item.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values((select auth.uid()),'translation.article_item_retry.candidate_staged','translation_job',job.id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',item.id,'candidateHash',candidate_hash,'workingDraftVersion',1,
        'workingDraftUpdatedAt',meta -> 'workingDraftUpdatedAt','recordedAdmissions',(p_outcome ->> 'providerCalls')::integer));
  return probpera_translation_operations.get_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id)||jsonb_build_object('replayed',false);
end; $$;

create or replace function probpera_translation_operations.recover_article_item_retry_candidate(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_expected_candidate_hash text
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare view jsonb; prior jsonb; meta jsonb; item public.translation_job_items%rowtype;
  job public.translation_jobs%rowtype; draft public.article_working_drafts%rowtype;
begin
  perform probpera_translation_operations.retry_access();
  if p_expected_candidate_hash is null or p_expected_candidate_hash !~ '^[a-f0-9]{64}$' then
    raise exception 'invalid article retry candidate hash' using errcode='22023'; end if;
  view:=probpera_translation_operations.get_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id);
  if view ->> 'candidateHash' is distinct from p_expected_candidate_hash then
    raise exception 'article retry candidate hash changed' using errcode='40001'; end if;
  if view ->> 'phase'='finished' then
    select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
    return prior -> 'receipt'||jsonb_build_object('replayed',true,'canExecute',false);
  end if;
  if view -> 'canRecover' is distinct from 'true'::jsonb then
    raise exception 'article retry candidate cannot be recovered: %',view ->> 'blockReason' using errcode='40001'; end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  perform probpera_translation_operations.retry_journal_active(job,item,p_operation_id);
  meta:=item.staff_retry -> 'candidate';
  select * into draft from public.article_working_drafts where article_id=item.entity_id::uuid for update;
  return probpera_translation_operations.finish_article_item_retry(p_job_id,p_item_id,p_operation_id,meta -> 'outcome',draft.english_payload);
end; $$;

create or replace function public.stage_article_translation_item_retry_candidate(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_english_payload jsonb
)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.stage_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id,p_outcome,p_english_payload);
create or replace function public.get_article_translation_item_retry_candidate(p_job_id uuid,p_item_id uuid,p_operation_id uuid)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.get_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id);
create or replace function public.recover_article_translation_item_retry_candidate(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_expected_candidate_hash text
)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.recover_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id,p_expected_candidate_hash);

revoke all on function probpera_translation_operations.retry_candidate_outcome_valid(jsonb) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.retry_candidate_meta_valid(jsonb) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.retry_candidate_block_reason(jsonb,jsonb,public.articles,public.article_translations,public.article_working_drafts,text) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.retry_candidate_view(jsonb,jsonb,integer,text,text,boolean) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.get_article_item_retry_candidate(uuid,uuid,uuid) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.stage_article_item_retry_candidate(uuid,uuid,uuid,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.recover_article_item_retry_candidate(uuid,uuid,uuid,text) from public,anon,authenticated,service_role;
revoke all on function public.get_article_translation_item_retry_candidate(uuid,uuid,uuid) from public,anon,authenticated,service_role;
revoke all on function public.stage_article_translation_item_retry_candidate(uuid,uuid,uuid,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.recover_article_translation_item_retry_candidate(uuid,uuid,uuid,text) from public,anon,authenticated,service_role;
grant execute on function probpera_translation_operations.get_article_item_retry_candidate(uuid,uuid,uuid) to authenticated;
grant execute on function probpera_translation_operations.stage_article_item_retry_candidate(uuid,uuid,uuid,jsonb,jsonb) to authenticated;
grant execute on function probpera_translation_operations.recover_article_item_retry_candidate(uuid,uuid,uuid,text) to authenticated;
grant execute on function public.get_article_translation_item_retry_candidate(uuid,uuid,uuid) to authenticated;
grant execute on function public.stage_article_translation_item_retry_candidate(uuid,uuid,uuid,jsonb,jsonb) to authenticated;
grant execute on function public.recover_article_translation_item_retry_candidate(uuid,uuid,uuid,text) to authenticated;

-- Additive prepared-aware replacements; previous SQL files remain unchanged.
create or replace function probpera_translation_operations.record_article_item_retry_dispatch(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_call_id uuid,p_provider text,p_model text,p_pass text
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  view jsonb; active jsonb; progress jsonb; calls jsonb; call jsonb; last_call jsonb; now_at timestamptz;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_call_id) or p_provider is null or p_provider not in ('openai','cloudflare')
    or p_model is null or probpera_translation_operations.retry_text_length(p_model) not between 1 and 200
    or p_pass is null or p_pass not in ('translation','repair','review') then
    raise exception 'invalid article retry dispatch metadata' using errcode='22023'; end if;
  -- GET holds the same operation advisory lock. Mutations preserve item -> job
  -- order used by retry FINISH and worker completion; no lease is granted.
  view:=probpera_translation_operations.get_article_item_retry_progress(p_job_id,p_item_id,p_operation_id);
  for call in select value from jsonb_array_elements(view -> 'calls') loop
    if call ->> 'callId'=p_call_id::text then
      if call ->> 'provider' is distinct from p_provider or call ->> 'model' is distinct from p_model
        or call ->> 'pass' is distinct from p_pass then
        raise exception 'article retry dispatch intent changed' using errcode='40001'; end if;
      return view || jsonb_build_object('canDispatch',false,'replayed',true);
    end if;
  end loop;
  if view ->> 'phase'='finished' then return view || jsonb_build_object('canDispatch',false,'replayed',true); end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  perform probpera_translation_operations.retry_journal_active(job,item,p_operation_id);
  if p_provider is distinct from job.provider or job.status<>'reviewing' or job.cancel_requested_at is not null then
    raise exception 'article retry dispatch was stopped' using errcode='40001'; end if;
  active:=item.staff_retry;
  -- The immutable marker survives a caller's explicit working-draft discard.
  -- A staged body never grants another paid pass, even if its row is absent.
  if active ? 'candidate' then
    raise exception 'article retry candidate is already staged' using errcode='40001'; end if;
  calls:=coalesce(active -> 'progress' -> 'calls','[]'::jsonb);
  if jsonb_array_length(calls)>=4 then raise exception 'article retry dispatch budget exhausted' using errcode='40001'; end if;
  if jsonb_array_length(calls)>0 then
    last_call:=calls -> (jsonb_array_length(calls)-1);
    if last_call -> 'responseReceivedAt'='null'::jsonb then
      raise exception 'article retry previous response is unknown' using errcode='40001'; end if;
  end if;
  select * into article from public.articles where id=item.entity_id::uuid for update;
  select * into english from public.article_translations where article_id=item.entity_id::uuid and locale='en' for update;
  if article.id is null or article.status<>'published' or article.deleted_at is not null
    or article.updated_at is distinct from (active ->> 'sourceUpdatedAt')::timestamptz
    or english.updated_at is distinct from (active ->> 'englishUpdatedAt')::timestamptz
    or exists(select 1 from public.article_working_drafts where article_id=article.id)
    or probpera_translation_operations.retry_fingerprint(probpera_translation_operations.retry_ru_snapshot(article))
      is distinct from active ->> 'sourceSnapshotHash' then
    raise exception 'article retry source or draft changed before dispatch' using errcode='40001'; end if;
  if english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
    or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash) then
    raise exception 'article retry English ownership changed before dispatch' using errcode='40001'; end if;
  now_at:=clock_timestamp();
  call:=jsonb_build_object('callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,
    'dispatchRecordedAt',now_at,'responseReceivedAt',null,'httpStatus',null,'requestId',null,'responseId',null,
    'inputTokens',null,'outputTokens',null);
  progress:=jsonb_build_object('version',1,'updatedAt',now_at,'calls',calls||jsonb_build_array(call));
  if not probpera_translation_operations.retry_journal_valid(progress,job.provider) then
    raise exception 'article retry pass sequence changed' using errcode='40001'; end if;
  active:=active||jsonb_build_object('progress',progress);
  update public.translation_job_items set staff_retry=active,updated_at=now_at where id=item.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values((select auth.uid()),'translation.article_item_retry.dispatch_recorded','translation_job',job.id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',item.id,'callId',p_call_id,
        'provider',p_provider,'model',p_model,'pass',p_pass,'recordedAdmissions',jsonb_array_length(progress -> 'calls')));
  return probpera_translation_operations.retry_journal_view(p_job_id,p_item_id,p_operation_id,view,progress,
    active -> 'startedAt',now_at,'running',true,false);
end; $$;

create or replace function probpera_translation_operations.finish_article_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_english_payload jsonb default null
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  actor uuid:=(select auth.uid()); active jsonb; prior jsonb; request_hash text;
  outcome text; code text; attempt_outcome text; snapshot jsonb; saved jsonb; result jsonb; receipt jsonb;
  source_stamp timestamptz; english_stamp timestamptz; attempt_number integer;
  succeeded integer; failed integer; conflicts integer; stale integer; not_configured integer;
  field text; field_value jsonb; draft_stamp timestamptz;
  candidate jsonb; candidate_reason text; draft public.article_working_drafts%rowtype;
begin
  perform probpera_translation_operations.retry_access();
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id)
    or jsonb_typeof(p_outcome) is distinct from 'object' or octet_length(p_outcome::text)>16384
    or not(p_outcome ?& array['status','providerCalls'])
    or p_outcome - array['status','providerCalls','errorCode','model','requestId','inputTokens','outputTokens','durationMs'] <> '{}'::jsonb
    or jsonb_typeof(p_outcome -> 'status') is distinct from 'string'
    or p_outcome ->> 'status' not in ('succeeded','dead_letter','conflict','stale','skipped','not-configured')
    or jsonb_typeof(p_outcome -> 'providerCalls') is distinct from 'number'
    or (p_outcome ->> 'providerCalls') !~ '^[0-4]$' then
    raise exception 'invalid article retry outcome' using errcode='22023'; end if;
  outcome:=p_outcome ->> 'status'; code:=p_outcome ->> 'errorCode';
  if (p_outcome ? 'errorCode' and p_outcome -> 'errorCode'<>'null'::jsonb
      and jsonb_typeof(p_outcome -> 'errorCode') is distinct from 'string')
    or (outcome in ('succeeded','skipped') and code is not null)
    or (outcome not in ('succeeded','skipped') and (code is null or code not in (
      'translation_not_configured','provider_unavailable','provider_request_failed','provider_invalid_response',
      'source_changed','write_conflict','database_read_failed','database_write_failed','unexpected'))) then
    raise exception 'invalid article retry error' using errcode='22023'; end if;
  foreach field in array array['model','requestId'] loop
    field_value:=p_outcome -> field;
    if field_value is not null and field_value<>'null'::jsonb and
      (jsonb_typeof(field_value) is distinct from 'string' or probpera_translation_operations.retry_text_length(p_outcome ->> field) not between 1 and 200) then
      raise exception 'invalid article retry provider metadata' using errcode='22023'; end if;
  end loop;
  foreach field in array array['inputTokens','outputTokens','durationMs'] loop
    field_value:=p_outcome -> field;
    if field_value is not null and field_value<>'null'::jsonb and
      (jsonb_typeof(field_value) is distinct from 'number' or (p_outcome ->> field) !~ '^[0-9]{1,8}$'
        or (p_outcome ->> field)::numeric > case when field='durationMs' then 3600000 else 10000000 end) then
      raise exception 'invalid article retry usage metadata' using errcode='22023'; end if;
  end loop;
  if outcome='succeeded' then
    if jsonb_typeof(p_english_payload) is distinct from 'object'
      or not(p_english_payload ?& array['mode','payload']) or p_english_payload - array['mode','payload']<>'{}'::jsonb
      or p_english_payload -> 'mode' is distinct from '"save"'::jsonb
      or not probpera_translation_operations.retry_payload_valid(p_english_payload -> 'payload',true) then
      raise exception 'invalid article retry private English' using errcode='22023'; end if;
  elsif p_english_payload is not null then
    raise exception 'non-successful article retry cannot persist English' using errcode='22023';
  end if;
  request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_outcome,p_english_payload));
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior is not null then
    if prior ->> 'actorId' is distinct from actor::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if prior -> 'receipt' ->> 'jobId' is distinct from p_job_id::text
      or prior -> 'receipt' ->> 'itemId' is distinct from p_item_id::text
      or prior ->> 'finishFingerprint' is distinct from request_hash then
      raise exception 'article retry finish intent changed' using errcode='40001'; end if;
    return prior -> 'receipt' || jsonb_build_object('replayed',true,'canExecute',false);
  end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  if item.id is null or job.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  active:=item.staff_retry;
  if active ->> 'operationId' is distinct from p_operation_id::text then
    raise exception 'article retry operation not found' using errcode='P0002'; end if;
  if active ->> 'actorId' is distinct from actor::text then
    raise exception 'article retry actor changed' using errcode='42501'; end if;
  source_stamp:=(active ->> 'sourceUpdatedAt')::timestamptz;
  english_stamp:=(active ->> 'englishUpdatedAt')::timestamptz;
  attempt_number:=(active ->> 'attemptNumber')::integer;
  if item.status<>'reviewing' or item.lease_owner is not null or item.lease_expires_at is not null
    or attempt_number is distinct from item.attempt_count+1 or attempt_number not between 1 and 5
    or job.kind<>'article' or item.entity_type<>'article' or job.source_locale<>'ru' or job.target_locale<>'en'
    or active -> 'version' is distinct from '1'::jsonb
    or (active ->> 'articleId')::uuid is distinct from item.entity_id::uuid
    or active -> 'beginIntent' ->> 0 is distinct from job.id::text
    or active -> 'beginIntent' ->> 1 is distinct from item.id::text
    or active -> 'beginIntent' ->> 2 is distinct from p_operation_id::text
    or active -> 'beginIntent' ->> 3 is distinct from actor::text
    or active -> 'beginIntent' ->> 6 is distinct from item.source_hash
    or active -> 'beginIntent' ->> 9 is distinct from job.provider then
    raise exception 'article retry active item changed' using errcode='40001'; end if;
  if outcome='succeeded' and p_english_payload -> 'payload' ->> 'source_content_hash' is distinct from item.source_hash then
    raise exception 'article retry English source changed' using errcode='22023'; end if;
  -- A durable dispatch remains unknown until its received-response record is
  -- acknowledged. Neither a timer nor a caller-supplied failure closes it.
  if active -> 'progress' is not null and active -> 'progress'<>'null'::jsonb then
    if not probpera_translation_operations.retry_journal_valid(active -> 'progress',job.provider)
      or jsonb_array_length(active -> 'progress' -> 'calls') is distinct from (p_outcome ->> 'providerCalls')::integer
      or exists(select 1 from jsonb_array_elements(active -> 'progress' -> 'calls') recorded
        where recorded -> 'responseReceivedAt'='null'::jsonb) then
      raise exception 'article retry provider outcome is unconfirmed' using errcode='40001'; end if;
  end if;
  candidate:=nullif(active -> 'candidate','null'::jsonb);
  if active ? 'candidate' and (candidate is null or not probpera_translation_operations.retry_candidate_meta_valid(candidate)
    or candidate ->> 'finishFingerprint' is distinct from request_hash) then
    raise exception 'article retry prepared finish intent changed' using errcode='40001'; end if;
  select * into article from public.articles where id=item.entity_id::uuid for update;
  select * into english from public.article_translations where article_id=item.entity_id::uuid and locale='en' for update;
  -- A known provider outcome is always journaled. A cancelled or changed
  -- source has no draft write, and does not turn generated text into review.
  if candidate is not null then
    select * into draft from public.article_working_drafts where article_id=item.entity_id::uuid for update;
    candidate_reason:=probpera_translation_operations.retry_candidate_block_reason(active,candidate,article,english,draft,job.provider);
    if candidate_reason is not null then
      raise exception 'article retry prepared candidate changed: %',candidate_reason using errcode='40001'; end if;
    if job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then
      outcome:='cancelled'; code:=null;
      -- The private body was already saved at STAGE and remains available.
      -- This cancelled FINISH performs no draft write.
    else
      saved:=jsonb_build_object('articleId',draft.article_id,'version',draft.version,'updatedAt',draft.updated_at);
      draft_stamp:=draft.updated_at;
      -- Consume the protected SAME row: no second save or version increment.
    end if;
  elsif job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then
    outcome:='cancelled'; code:=null;
  elsif outcome='succeeded' then
    if article.id is null or article.deleted_at is not null or article.status<>'published'
      or article.updated_at is distinct from source_stamp then outcome:='stale'; code:='source_changed';
    elsif english.updated_at is distinct from english_stamp
      or exists(select 1 from public.article_working_drafts where article_id=article.id)
      or (english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
        or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
        or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
        or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash)) then
      outcome:='conflict'; code:='write_conflict';
    else
      begin snapshot:=probpera_translation_operations.retry_ru_snapshot(article);
      exception when invalid_parameter_value then snapshot:=null; end;
      if snapshot is null or probpera_translation_operations.retry_fingerprint(snapshot) is distinct from active ->> 'sourceSnapshotHash' then
        outcome:='stale'; code:='source_changed';
      else
        saved:=public.save_article_working_draft(article.id,source_stamp,snapshot,p_english_payload,english_stamp,0);
        if saved ->> 'articleId' is distinct from article.id::text or saved -> 'version' is distinct from '1'::jsonb
          or jsonb_typeof(saved -> 'updatedAt') is distinct from 'string' then
          raise exception 'invalid article retry private draft receipt' using errcode='22023'; end if;
        draft_stamp:=(saved ->> 'updatedAt')::timestamptz;
        update public.article_working_drafts set draft_scope='english-only',draft_english_enabled=true
          where article_id=article.id and version=1;
        if not found then raise exception 'article retry private draft changed' using errcode='40001'; end if;
      end if;
    end if;
  end if;
  update public.translation_job_items set status=case when outcome='cancelled' then 'cancelled' else outcome end,
    attempt_count=attempt_number,staff_retry=null,lease_owner=null,lease_expires_at=null,last_error_code=code,
    updated_at=clock_timestamp() where id=item.id returning * into item;
  select count(*) filter(where status='succeeded'),count(*) filter(where status='dead_letter'),
    count(*) filter(where status='conflict'),count(*) filter(where status='stale'),count(*) filter(where status='not-configured')
    into succeeded,failed,conflicts,stale,not_configured from public.translation_job_items where job_id=job.id;
  update public.translation_jobs set succeeded_items=succeeded,failed_items=failed,
    status=case when outcome='cancelled' then 'cancelled'
      when failed>0 then case when succeeded>0 then 'partial' else 'failed' end
      when conflicts>0 then 'conflict' when stale>0 then 'stale' when not_configured>0 then 'not-configured'
      when succeeded=0 then 'skipped' else 'completed' end,
    completed_at=clock_timestamp(),version=version+1,updated_at=clock_timestamp()
    where id=job.id returning * into job;
  result:=jsonb_build_object('outcome',outcome,'errorCode',code,
    'persistence',case when saved is not null then 'working-draft' else 'none' end,
    'workingDraftVersion',case when saved is not null then 1 else null end,'workingDraftUpdatedAt',draft_stamp,
    'publication','unchanged','humanReview',case when saved is not null then 'pending' else 'unchanged' end,
    'providerCalls',(p_outcome ->> 'providerCalls')::integer);
  receipt:=probpera_translation_operations.retry_view(job,item,'finished',null,active,source_stamp,english_stamp,false,false,result);
  attempt_outcome:=case when outcome='cancelled' then 'skipped' else outcome end;
  insert into public.translation_job_attempts(item_id,attempt_number,outcome,provider,model,provider_request_id,
    error_code,input_tokens,output_tokens,duration_ms,staff_retry_operation_id,staff_retry_receipt)
    values(item.id,attempt_number,attempt_outcome,job.provider,p_outcome ->> 'model',p_outcome ->> 'requestId',code,
      (p_outcome ->> 'inputTokens')::integer,(p_outcome ->> 'outputTokens')::integer,(p_outcome ->> 'durationMs')::integer,
      p_operation_id,jsonb_build_object('actorId',actor,'beginIntent',active -> 'beginIntent',
        'finishFingerprint',request_hash,'receipt',receipt,
        'progress',active -> 'progress','startedAt',active -> 'startedAt')
        ||case when candidate is null then '{}'::jsonb else jsonb_build_object(
          'candidate',candidate,'sourceSnapshotHash',active -> 'sourceSnapshotHash') end);
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'translation.article_item_retry.finished','translation_job',job.id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',item.id,'attemptNumber',attempt_number,
        'outcome',outcome,'persistence',result -> 'persistence','jobVersion',job.version::text));
  return receipt;
end; $$;

-- Ordinary machine completion saves only a private English working copy.
-- Existing canonical RU/EN, editorial approvals and public-build triggers are
-- untouched. The private writer delegates the existing draft/CAS/audit API.
create function probpera_translation_operations.machine_english_draft_access()
returns void language plpgsql stable security invoker set search_path='' as $$
begin
  if (select auth.uid()) is null or not public.is_staff(array['owner'::public.staff_role,'admin'::public.staff_role]) then
    raise exception 'article machine English draft requires owner or admin' using errcode='42501';
  end if;
end; $$;

-- Match the complete author snapshot, independently of the TS content hash.
-- SQL jsonb::text fingerprints are not the JavaScript content-hash format.
create function probpera_translation_operations.machine_english_source_matches(
  p_article public.articles,p_source_updated_at timestamptz,p_source_snapshot jsonb
)
returns boolean language plpgsql stable security invoker set search_path='' as $$
begin
  if p_article.id is null or p_article.status<>'published' or p_article.deleted_at is not null
    or p_article.updated_at is distinct from p_source_updated_at then return false; end if;
  return probpera_translation_operations.retry_ru_snapshot(p_article) is not distinct from p_source_snapshot;
exception when invalid_parameter_value then return false;
end; $$;

create function probpera_translation_operations.get_article_machine_english_draft_context(
  p_article_id uuid,p_source_hash text,p_source_updated_at timestamptz,p_source_snapshot jsonb,
  p_expected_english_updated_at timestamptz
)
returns jsonb language plpgsql stable security definer set search_path='' set timezone='UTC' as $$
declare article public.articles%rowtype; english public.article_translations%rowtype;
  draft public.article_working_drafts%rowtype; reason text;
begin
  perform probpera_translation_operations.machine_english_draft_access();
  if not probpera_translation_operations.retry_uuid(p_article_id)
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$'
    or p_source_updated_at is null or not isfinite(p_source_updated_at)
    or (p_expected_english_updated_at is not null and not isfinite(p_expected_english_updated_at))
    or not probpera_translation_operations.retry_payload_valid(p_source_snapshot,false) then
    raise exception 'invalid article machine English context' using errcode='22023'; end if;
  select * into article from public.articles where id=p_article_id;
  select * into english from public.article_translations where article_id=p_article_id and locale='en';
  select * into draft from public.article_working_drafts where article_id=p_article_id;
  if not probpera_translation_operations.machine_english_source_matches(article,p_source_updated_at,p_source_snapshot) then
    reason:='source_changed';
  elsif english.updated_at is distinct from p_expected_english_updated_at then reason:='english_changed';
  elsif english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
    or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash) then
    reason:='manual_english';
  elsif draft.article_id is not null then reason:='draft_exists'; end if;
  return jsonb_build_object('version',1,'articleId',p_article_id,'sourceHash',p_source_hash,
    'sourceUpdatedAt',p_source_updated_at,'englishUpdatedAt',p_expected_english_updated_at,
    'canGenerate',reason is null,'blockReason',reason);
end; $$;

create function probpera_translation_operations.save_article_machine_english_draft(
  p_article_id uuid,p_source_hash text,p_source_updated_at timestamptz,p_source_snapshot jsonb,
  p_expected_english_updated_at timestamptz,p_english_payload jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare actor uuid:=(select auth.uid()); article public.articles%rowtype;
  english public.article_translations%rowtype; draft public.article_working_drafts%rowtype;
  saved jsonb; metadata jsonb; affected integer;
begin
  perform probpera_translation_operations.machine_english_draft_access();
  -- Reject malformed requests before acquiring row locks. The locked canonical
  -- records, not a client role or previous context response, decide admission.
  if not probpera_translation_operations.retry_uuid(p_article_id)
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$'
    or p_source_updated_at is null or not isfinite(p_source_updated_at)
    or (p_expected_english_updated_at is not null and not isfinite(p_expected_english_updated_at))
    or not probpera_translation_operations.retry_payload_valid(p_source_snapshot,false)
    or jsonb_typeof(p_english_payload) is distinct from 'object'
    or p_english_payload - array['mode','payload']<>'{}'::jsonb
    or not(p_english_payload ?& array['mode','payload'])
    or p_english_payload -> 'mode' is distinct from '"save"'::jsonb
    or not probpera_translation_operations.retry_payload_valid(p_english_payload -> 'payload',true)
    or p_english_payload -> 'payload' ->> 'source_content_hash' is distinct from p_source_hash then
    raise exception 'invalid article machine English draft' using errcode='22023'; end if;
  -- Keep the established article -> English -> working-draft lock order.
  select * into article from public.articles where id=p_article_id for update;
  select * into english from public.article_translations where article_id=p_article_id and locale='en' for update;
  select * into draft from public.article_working_drafts where article_id=p_article_id for update;
  if not probpera_translation_operations.machine_english_source_matches(article,p_source_updated_at,p_source_snapshot) then
    raise exception 'article machine English source changed' using errcode='40001'; end if;
  if english.updated_at is distinct from p_expected_english_updated_at then
    raise exception 'article machine English translation changed' using errcode='40001'; end if;
  if english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
    or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash) then
    raise exception 'article machine English translation is manual or deleted' using errcode='40001'; end if;
  if draft.article_id is not null then
    raise exception 'article machine English author draft exists' using errcode='40001'; end if;
  saved:=public.save_article_working_draft(p_article_id,p_source_updated_at,p_source_snapshot,
    p_english_payload,p_expected_english_updated_at,0);
  if saved ->> 'articleId' is distinct from p_article_id::text or saved -> 'version' is distinct from '1'::jsonb then
    raise exception 'article machine English draft save unconfirmed' using errcode='40001'; end if;
  update public.article_working_drafts set draft_scope='english-only',draft_english_enabled=true
    where article_id=p_article_id and version=1 and actor_id=actor;
  get diagnostics affected=ROW_COUNT;
  select * into draft from public.article_working_drafts where article_id=p_article_id;
  if affected<>1 or draft.payload is distinct from p_source_snapshot or draft.english_payload is distinct from p_english_payload
    or draft.draft_scope is distinct from 'english-only' or draft.draft_english_enabled is distinct from true
    or draft.base_article_updated_at is distinct from p_source_updated_at
    or draft.expected_english_updated_at is distinct from p_expected_english_updated_at
    or draft.updated_at is distinct from (saved ->> 'updatedAt')::timestamptz then
    raise exception 'article machine English draft save unconfirmed' using errcode='40001'; end if;
  metadata:=p_english_payload -> 'payload' -> 'content_json' -> '__probperaPremiumTranslation';
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata) values(actor,
    'article.premium_translation.backfill.succeeded','article',p_article_id::text,
    jsonb_build_object('locale','en','source_hash',p_source_hash,'source_updated_at',p_source_updated_at,
      'ownership','machine-translation','workingDraftVersion',1,'workingDraftUpdatedAt',draft.updated_at,
      'scope','english-only','publication','unchanged','humanReview','pending',
      'model',case when jsonb_typeof(metadata -> 'model')='string' and probpera_translation_operations.retry_text_length(metadata ->> 'model') between 1 and 200 then metadata -> 'model' else 'null'::jsonb end,
      'reviewer_model',case when jsonb_typeof(metadata -> 'reviewerModel')='string' and probpera_translation_operations.retry_text_length(metadata ->> 'reviewerModel') between 1 and 200 then metadata -> 'reviewerModel' else 'null'::jsonb end));
  return jsonb_build_object('version',1,'articleId',p_article_id,'sourceHash',p_source_hash,
    'sourceUpdatedAt',p_source_updated_at,'englishUpdatedAt',p_expected_english_updated_at,
    'workingDraftVersion',1,'workingDraftUpdatedAt',draft.updated_at,'scope','english-only',
    'publication','unchanged','humanReview','pending','persistence','working-draft');
end; $$;

create function public.get_article_machine_english_draft_context(
  p_article_id uuid,p_source_hash text,p_source_updated_at timestamptz,p_source_snapshot jsonb,
  p_expected_english_updated_at timestamptz
)
returns jsonb language sql stable security invoker set search_path=''
return probpera_translation_operations.get_article_machine_english_draft_context(p_article_id,p_source_hash,
  p_source_updated_at,p_source_snapshot,p_expected_english_updated_at);
create function public.save_article_machine_english_draft(
  p_article_id uuid,p_source_hash text,p_source_updated_at timestamptz,p_source_snapshot jsonb,
  p_expected_english_updated_at timestamptz,p_english_payload jsonb
)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.save_article_machine_english_draft(p_article_id,p_source_hash,
  p_source_updated_at,p_source_snapshot,p_expected_english_updated_at,p_english_payload);

revoke all on function probpera_translation_operations.machine_english_draft_access() from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.machine_english_source_matches(public.articles,timestamptz,jsonb) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.get_article_machine_english_draft_context(uuid,text,timestamptz,jsonb,timestamptz) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.save_article_machine_english_draft(uuid,text,timestamptz,jsonb,timestamptz,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.get_article_machine_english_draft_context(uuid,text,timestamptz,jsonb,timestamptz) from public,anon,authenticated,service_role;
revoke all on function public.save_article_machine_english_draft(uuid,text,timestamptz,jsonb,timestamptz,jsonb) from public,anon,authenticated,service_role;
grant execute on function probpera_translation_operations.get_article_machine_english_draft_context(uuid,text,timestamptz,jsonb,timestamptz) to authenticated;
grant execute on function probpera_translation_operations.save_article_machine_english_draft(uuid,text,timestamptz,jsonb,timestamptz,jsonb) to authenticated;
grant execute on function public.get_article_machine_english_draft_context(uuid,text,timestamptz,jsonb,timestamptz) to authenticated;
grant execute on function public.save_article_machine_english_draft(uuid,text,timestamptz,jsonb,timestamptz,jsonb) to authenticated;

-- Ordinary article translation uses the existing jobs, items, attempt journal
-- and private English candidate. Admission is committed before provider work.
-- Historical migrations and the unused service-role lease API stay intact.
begin;

create or replace function probpera_translation_operations.ordinary_marker(p_job public.translation_jobs)
returns boolean language sql immutable security invoker set search_path=''
return p_job.kind='article' and p_job.resume_cursor ? 'articleOrdinary';

create or replace function probpera_translation_operations.ordinary_access(p_job_id uuid)
returns boolean language plpgsql stable security definer set search_path='' as $$
declare job public.translation_jobs%rowtype;
begin
  select * into job from public.translation_jobs where id=p_job_id;
  if job.id is not null and probpera_translation_operations.ordinary_marker(job) then
    if (select auth.uid()) is null
      or not public.is_staff(array['owner','admin']::public.staff_role[])
      or job.requested_by is distinct from (select auth.uid()) then
      raise exception 'ordinary article translation requires its owner or admin actor' using errcode='42501';
    end if;
  end if;
  return true;
end; $$;

create or replace function probpera_translation_operations.ordinary_cursor_valid(p_cursor jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare scan jsonb; value jsonb; ids uuid[]; upper_id uuid; after_id uuid; next_index integer;
begin
  if p_cursor is null or jsonb_typeof(p_cursor) is distinct from 'object'
    or octet_length(p_cursor::text)>65536
    or p_cursor-array['articleScan','articleCursor','libraryCursor','writerCursor','countryCursor']<>'{}'::jsonb then return false; end if;
  for value in select entry.value from jsonb_each(p_cursor-'articleScan') entry loop
    if jsonb_typeof(value) is distinct from 'number' or value::text !~ '^[0-9]{1,9}$' then return false; end if;
  end loop;
  if not(p_cursor ? 'articleScan') then return true; end if;
  scan:=p_cursor -> 'articleScan';
  if jsonb_typeof(scan) is distinct from 'object'
    or not(scan ?& array['version','order','upperId','afterId','pendingIds','nextIndex','lastWindow','exhausted'])
    or scan-array['version','order','upperId','afterId','pendingIds','nextIndex','lastWindow','exhausted']<>'{}'::jsonb
    or scan -> 'version' is distinct from '1'::jsonb or scan -> 'order' is distinct from '"id"'::jsonb
    or jsonb_typeof(scan -> 'upperId') is distinct from 'string'
    or not probpera_translation_operations.retry_uuid((scan ->> 'upperId')::uuid)
    or (scan -> 'afterId'<>'null'::jsonb and (jsonb_typeof(scan -> 'afterId') is distinct from 'string'
      or not probpera_translation_operations.retry_uuid((scan ->> 'afterId')::uuid)))
    or jsonb_typeof(scan -> 'pendingIds') is distinct from 'array' or jsonb_array_length(scan -> 'pendingIds')>500
    or jsonb_typeof(scan -> 'nextIndex') is distinct from 'number' or (scan ->> 'nextIndex') !~ '^[0-9]{1,3}$'
    or jsonb_typeof(scan -> 'lastWindow') is distinct from 'boolean'
    or jsonb_typeof(scan -> 'exhausted') is distinct from 'boolean' then return false; end if;
  upper_id:=(scan ->> 'upperId')::uuid; after_id:=(scan ->> 'afterId')::uuid;
  next_index:=(scan ->> 'nextIndex')::integer;
  if after_id>upper_id or next_index>jsonb_array_length(scan -> 'pendingIds') then return false; end if;
  if exists(select 1 from jsonb_array_elements(scan -> 'pendingIds') element
    where jsonb_typeof(element) is distinct from 'string'
      or not probpera_translation_operations.retry_uuid((element #>> '{}')::uuid)) then return false; end if;
  select coalesce(array_agg((element #>> '{}')::uuid order by position),'{}'::uuid[]) into ids
    from jsonb_array_elements(scan -> 'pendingIds') with ordinality entries(element,position);
  if exists(select 1 from unnest(ids) with ordinality entries(id,position)
    where id>upper_id or id<=after_id or (position>1 and id<=ids[position-1])) then return false; end if;
  if scan -> 'exhausted'='true'::jsonb and (scan -> 'lastWindow'<>'true'::jsonb
    or cardinality(ids)<>0 or next_index<>0) then return false; end if;
  return true;
exception when others then return false;
end; $$;

create or replace function probpera_translation_operations.ordinary_run_view(p_job public.translation_jobs,p_replayed boolean default false)
returns jsonb language sql stable security invoker set search_path=''
return jsonb_build_object('version',1,'jobId',p_job.id,'provider',p_job.provider,'actorId',p_job.requested_by,
  'jobVersion',p_job.version::text,'status',p_job.status,'totalItems',p_job.total_items,
  'succeededItems',p_job.succeeded_items,'failedItems',p_job.failed_items,
  'activeItems',(select count(*) from public.translation_job_items where job_id=p_job.id and staff_retry is not null),
  'pendingItems',(select count(*) from public.translation_job_items where job_id=p_job.id and status in ('queued','leased','retry_wait')),
  'resumeCursor',p_job.resume_cursor-'articleOrdinary','replayed',p_replayed);

create or replace function probpera_translation_operations.ordinary_refresh_job(p_job_id uuid)
returns public.translation_jobs language plpgsql volatile security invoker set search_path='' as $$
declare job public.translation_jobs%rowtype; succeeded integer; failed integer; conflicts integer;
  stale integer; unavailable integer; active integer; pending integer;
begin
  select * into job from public.translation_jobs where id=p_job_id for update;
  select count(*) filter(where status='succeeded'),count(*) filter(where status='dead_letter'),
    count(*) filter(where status='conflict'),count(*) filter(where status='stale'),
    count(*) filter(where status='not-configured'),count(*) filter(where staff_retry is not null or status='reviewing'),
    count(*) filter(where status in ('queued','leased','retry_wait'))
    into succeeded,failed,conflicts,stale,unavailable,active,pending
    from public.translation_job_items where job_id=p_job_id;
  update public.translation_jobs set succeeded_items=succeeded,failed_items=failed,
    status=case when cancel_requested_at is not null or job.status in ('cancelled','cancelling')
      then case when active+pending>0 then 'cancelling' else 'cancelled' end
      when active>0 then 'reviewing' when pending>0 then 'running'
      when failed>0 then case when succeeded>0 then 'partial' else 'failed' end
      when conflicts>0 then 'conflict' when stale>0 then 'stale' when unavailable>0 then 'not-configured'
      when succeeded=0 then 'skipped' else 'completed' end,
    completed_at=case when active+pending>0 then null else coalesce(completed_at,clock_timestamp()) end,
    updated_at=clock_timestamp() where id=p_job_id returning * into job;
  return job;
end; $$;

-- Pre-existing duplicate active operations need reconciliation. Never delete
-- their state, expire an unknown provider admission, or silently choose one.
do $$
begin
  if exists(select 1 from public.translation_job_items where entity_type='article' and staff_retry is not null
    group by entity_type,entity_id::uuid having count(*)>1) then
    raise exception 'active article translation operations require reconciliation before admission upgrade' using errcode='40001';
  end if;
end; $$;
create unique index translation_article_active_operation_unique
  on public.translation_job_items(entity_type,(entity_id::uuid))
  where entity_type='article' and staff_retry is not null;

create or replace function probpera_translation_operations.ordinary_write_guard()
returns trigger language plpgsql security definer set search_path='' as $$
declare job public.translation_jobs%rowtype; old_job public.translation_jobs%rowtype; job_id uuid;
  marked boolean:=false; actor uuid:=(select auth.uid());
begin
  if tg_table_name='translation_jobs' then
    job:=case when tg_op='DELETE' then old else new end;
    marked:=probpera_translation_operations.ordinary_marker(job)
      or (tg_op='UPDATE' and probpera_translation_operations.ordinary_marker(old));
    if tg_op='UPDATE' and probpera_translation_operations.ordinary_marker(old)
      and ((new.resume_cursor -> 'articleOrdinary')-'lastCheckpointHash') is distinct from
        ((old.resume_cursor -> 'articleOrdinary')-'lastCheckpointHash') then
      raise exception 'ordinary article run identity changed' using errcode='40001'; end if;
  elsif tg_table_name='translation_job_items' then
    job_id:=case when tg_op='DELETE' then old.job_id else new.job_id end;
    select * into job from public.translation_jobs where id=job_id;
    marked:=probpera_translation_operations.ordinary_marker(job);
    if tg_op='UPDATE' then
      select * into old_job from public.translation_jobs where id=old.job_id;
      if probpera_translation_operations.ordinary_marker(old_job) then
        perform probpera_translation_operations.ordinary_access(old_job.id);
        if new.job_id is distinct from old.job_id or new.id is distinct from old.id
          or new.entity_type is distinct from old.entity_type or new.entity_id is distinct from old.entity_id then
          raise exception 'ordinary article item identity changed' using errcode='40001'; end if;
      end if;
    end if;
  else
    select item.job_id into job_id from public.translation_job_items item
      where item.id=case when tg_op='DELETE' then old.item_id else new.item_id end;
    select * into job from public.translation_jobs where id=job_id;
    marked:=probpera_translation_operations.ordinary_marker(job);
    if tg_op='UPDATE' then
      select jobs.* into old_job from public.translation_job_items items
        join public.translation_jobs jobs on jobs.id=items.job_id where items.id=old.item_id;
      if probpera_translation_operations.ordinary_marker(old_job) then
        perform probpera_translation_operations.ordinary_access(old_job.id);
        if new.item_id is distinct from old.item_id or new.id is distinct from old.id
          or new.attempt_number is distinct from old.attempt_number then
          raise exception 'ordinary article attempt identity changed' using errcode='40001'; end if;
      end if;
    end if;
  end if;
  if marked and (actor is null or not public.is_staff(array['owner','admin']::public.staff_role[])
    or job.requested_by is distinct from actor) then
    raise exception 'ordinary article translation mutation requires its owner or admin actor' using errcode='42501'; end if;
  if marked and tg_table_name='translation_jobs' and (jsonb_typeof(job.resume_cursor -> 'articleOrdinary') is distinct from 'object'
    or job.resume_cursor -> 'articleOrdinary' -> 'version' is distinct from '1'::jsonb
    or job.resume_cursor -> 'articleOrdinary' ->> 'actorId' is distinct from job.requested_by::text
    or job.resume_cursor -> 'articleOrdinary' ->> 'provider' is distinct from job.provider) then
    raise exception 'invalid ordinary article run marker' using errcode='22023'; end if;
  return case when tg_op='DELETE' then old else new end;
end; $$;

create trigger translation_jobs_ordinary_access before insert or update or delete on public.translation_jobs
  for each row execute function probpera_translation_operations.ordinary_write_guard();
create trigger translation_job_items_ordinary_access before insert or update or delete on public.translation_job_items
  for each row execute function probpera_translation_operations.ordinary_write_guard();
create trigger translation_job_attempts_ordinary_access before insert or update or delete on public.translation_job_attempts
  for each row execute function probpera_translation_operations.ordinary_write_guard();

create or replace function probpera_translation_operations.get_article_sync_run(p_job_id uuid)
returns jsonb language plpgsql stable security definer set search_path='' as $$
declare job public.translation_jobs%rowtype;
begin
  perform probpera_translation_operations.retry_access();
  perform probpera_translation_operations.ordinary_access(p_job_id);
  if not probpera_translation_operations.retry_uuid(p_job_id) then raise exception 'invalid ordinary article job identity' using errcode='22023'; end if;
  select * into job from public.translation_jobs where id=p_job_id;
  if job.id is null then raise exception 'ordinary article job not found' using errcode='P0002'; end if;
  if not probpera_translation_operations.ordinary_marker(job) then raise exception 'ordinary article job not found' using errcode='P0002'; end if;
  return probpera_translation_operations.ordinary_run_view(job);
end; $$;

create or replace function probpera_translation_operations.begin_article_sync_item(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_article_id uuid,p_expected_job_version bigint,
  p_expected_source_hash text,p_expected_article_updated_at timestamptz,p_expected_english_updated_at timestamptz,
  p_provider text,p_expected_cursor jsonb,p_resume_cursor jsonb,p_expected_source_snapshot jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare actor uuid:=(select auth.uid()); job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype; prior jsonb; active jsonb;
  snapshot jsonb; snapshot_hash text; intent jsonb; marker jsonb; created boolean:=false; violated_constraint text;
begin
  if actor is null or not public.is_staff(array['owner','admin']::public.staff_role[]) then
    raise exception 'ordinary article translation requires owner or admin access' using errcode='42501'; end if;
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id) or not probpera_translation_operations.retry_uuid(p_article_id)
    or p_expected_job_version is null or p_expected_job_version not between 0 and 9223372036854775805
    or p_expected_source_hash is null or p_expected_source_hash !~ '^[a-f0-9]{64}$'
    or p_expected_article_updated_at is null or not isfinite(p_expected_article_updated_at)
    or (p_expected_english_updated_at is not null and not isfinite(p_expected_english_updated_at))
    or p_provider is null or p_provider not in ('openai','cloudflare')
    or not probpera_translation_operations.ordinary_cursor_valid(p_expected_cursor)
    or not probpera_translation_operations.ordinary_cursor_valid(p_resume_cursor)
    or not probpera_translation_operations.retry_payload_valid(p_expected_source_snapshot,false) then
    raise exception 'invalid ordinary article translation intent' using errcode='22023'; end if;
  snapshot_hash:=probpera_translation_operations.retry_fingerprint(p_expected_source_snapshot);
  intent:=jsonb_build_array(p_job_id,p_item_id,p_operation_id,actor,p_expected_job_version::text,0,
    p_expected_source_hash,p_expected_article_updated_at,p_expected_english_updated_at,p_provider,
    snapshot_hash,probpera_translation_operations.retry_fingerprint(p_expected_cursor),
    probpera_translation_operations.retry_fingerprint(p_resume_cursor),'ordinary');
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  perform pg_advisory_xact_lock(hashtextextended(p_job_id::text,7048));
  select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior is not null then
    perform probpera_translation_operations.ordinary_access(p_job_id);
    if prior ->> 'actorId' is distinct from actor::text then raise exception 'ordinary article actor changed' using errcode='42501'; end if;
    if prior -> 'beginIntent' is distinct from intent then raise exception 'ordinary article intent changed' using errcode='40001'; end if;
    return prior -> 'receipt'||jsonb_build_object('replayed',true,'canExecute',false);
  end if;
  select * into item from public.translation_job_items where id=p_item_id for update;
  if item.id is not null then
    perform probpera_translation_operations.ordinary_access(item.job_id);
    if item.job_id is distinct from p_job_id or item.staff_retry is null or item.staff_retry -> 'beginIntent' is distinct from intent then
      raise exception 'ordinary article item or intent changed' using errcode='40001'; end if;
    select * into job from public.translation_jobs where id=p_job_id;
    return probpera_translation_operations.retry_view(job,item,'running',null,item.staff_retry,
      p_expected_article_updated_at,p_expected_english_updated_at,false,true);
  end if;
  if exists(select 1 from public.translation_job_items where staff_retry ->> 'operationId'=p_operation_id::text) then
    raise exception 'ordinary article operation belongs to another item' using errcode='40001'; end if;
  if probpera_translation_operations.article_sync_ready() is distinct from true then
    raise exception 'ordinary article admission capability is unavailable' using errcode='42883'; end if;
  select * into job from public.translation_jobs where id=p_job_id for update;
  if job.id is null then
    if p_expected_job_version<>0 then raise exception 'ordinary article job not found' using errcode='P0002'; end if;
    marker:=jsonb_build_object('version',1,'actorId',actor,'provider',p_provider,
      'initialCursorHash',probpera_translation_operations.retry_fingerprint(p_expected_cursor),'lastCheckpointHash',null);
    insert into public.translation_jobs(id,kind,provider,status,total_items,requested_by,started_at,resume_cursor)
      values(p_job_id,'article',p_provider,'running',0,actor,clock_timestamp(),
        p_expected_cursor||jsonb_build_object('articleOrdinary',marker)) returning * into job;
    created:=true;
  else
    perform probpera_translation_operations.ordinary_access(p_job_id);
    if not probpera_translation_operations.ordinary_marker(job) or job.provider is distinct from p_provider
      or job.version is distinct from p_expected_job_version
      or (job.resume_cursor-'articleOrdinary') is distinct from p_expected_cursor then
      raise exception 'ordinary article job or cursor changed' using errcode='40001'; end if;
  end if;
  if job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then
    raise exception 'ordinary article run was stopped' using errcode='42501'; end if;
  if job.total_items>=500 or exists(select 1 from public.translation_job_items where job_id=job.id and entity_type='article' and entity_id=p_article_id::text) then
    raise exception 'ordinary article is already recorded or run is full' using errcode='40001'; end if;
  if exists(select 1 from public.translation_job_items where entity_type='article' and staff_retry is not null and entity_id::uuid=p_article_id) then
    raise exception 'article translation operation is already active' using errcode='40001'; end if;
  if p_expected_cursor ? 'articleScan' and p_resume_cursor -> 'articleScan' -> 'upperId' is distinct from p_expected_cursor -> 'articleScan' -> 'upperId' then
    raise exception 'ordinary article scan boundary changed' using errcode='40001'; end if;
  select * into article from public.articles where id=p_article_id for update;
  select * into english from public.article_translations where article_id=p_article_id and locale='en' for update;
  if article.id is null or article.status<>'published' or article.deleted_at is not null
    or article.updated_at is distinct from p_expected_article_updated_at
    or english.updated_at is distinct from p_expected_english_updated_at
    or exists(select 1 from public.article_working_drafts where article_id=p_article_id) then
    raise exception 'ordinary article source, English or draft changed' using errcode='40001'; end if;
  if english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
    or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash) then
    raise exception 'ordinary article English is manual or unavailable' using errcode='40001'; end if;
  snapshot:=probpera_translation_operations.retry_ru_snapshot(article);
  if snapshot is distinct from p_expected_source_snapshot then
    raise exception 'ordinary article full source snapshot changed' using errcode='40001'; end if;
  active:=jsonb_build_object('version',1,'operationId',p_operation_id,'actorId',actor,'articleId',p_article_id,
    'beginIntent',intent,'sourceUpdatedAt',p_expected_article_updated_at,'englishUpdatedAt',p_expected_english_updated_at,
    'attemptNumber',1,'startedAt',clock_timestamp(),'sourceSnapshotHash',snapshot_hash,
    'progress',jsonb_build_object('version',1,'updatedAt',clock_timestamp(),'calls','[]'::jsonb));
  insert into public.translation_job_items(id,job_id,position,entity_type,entity_id,source_hash,status,max_attempts,staff_retry)
    values(p_item_id,p_job_id,job.total_items,'article',p_article_id::text,p_expected_source_hash,'reviewing',3,active)
    returning * into item;
  update public.translation_jobs set total_items=total_items+1,status='reviewing',completed_at=null,
    resume_cursor=p_resume_cursor||jsonb_build_object('articleOrdinary',resume_cursor -> 'articleOrdinary'),
    version=case when created then version else version+1 end,updated_at=clock_timestamp()
    where id=p_job_id returning * into job;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'translation.article_sync.admitted','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'articleId',p_article_id,
        'sourceHash',p_expected_source_hash,'sourceSnapshotHash',snapshot_hash,'jobVersion',job.version::text));
  return probpera_translation_operations.retry_view(job,item,'running',null,active,
    p_expected_article_updated_at,p_expected_english_updated_at,true,false);
exception when unique_violation then
  get stacked diagnostics violated_constraint=constraint_name;
  if violated_constraint='translation_article_active_operation_unique' then
    raise exception 'article translation operation is already active' using errcode='40001';
  end if;
  raise;
end; $$;

create or replace function probpera_translation_operations.checkpoint_article_sync_run(
  p_job_id uuid,p_expected_job_version bigint,p_expected_cursor jsonb,p_resume_cursor jsonb,p_observed_items jsonb,p_provider text
)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare actor uuid:=(select auth.uid()); job public.translation_jobs%rowtype; observation jsonb;
  item public.translation_job_items%rowtype; marker jsonb; request_hash text; created boolean:=false;
begin
  if actor is null or not public.is_staff(array['owner','admin']::public.staff_role[]) then
    raise exception 'ordinary article checkpoint requires owner or admin access' using errcode='42501'; end if;
  if not probpera_translation_operations.retry_uuid(p_job_id) or p_expected_job_version is null
    or p_expected_job_version not between 0 and 9223372036854775805
    or p_provider is null or p_provider not in ('openai','cloudflare')
    or not probpera_translation_operations.ordinary_cursor_valid(p_expected_cursor)
    or not probpera_translation_operations.ordinary_cursor_valid(p_resume_cursor)
    or jsonb_typeof(p_observed_items) is distinct from 'array' or jsonb_array_length(p_observed_items)>500
    or octet_length(p_observed_items::text)>262144 then
    raise exception 'invalid ordinary article checkpoint' using errcode='22023'; end if;
  if exists(select 1 from jsonb_array_elements(p_observed_items) value where
    jsonb_typeof(value) is distinct from 'object' or not(value ?& array['entityId','state'])
    or value-array['entityId','state','sourceHash']<>'{}'::jsonb
    or jsonb_typeof(value -> 'entityId') is distinct from 'string'
    or not probpera_translation_operations.retry_uuid((value ->> 'entityId')::uuid)
    or jsonb_typeof(value -> 'state') is distinct from 'string' or value ->> 'state' not in ('current','manual','skipped')
    or (value ? 'sourceHash' and (jsonb_typeof(value -> 'sourceHash') is distinct from 'string'
      or value ->> 'sourceHash' !~ '^[a-f0-9]{64}$'))) then
    raise exception 'invalid ordinary article observation' using errcode='22023'; end if;
  if exists(select 1 from jsonb_array_elements(p_observed_items) value group by (value ->> 'entityId')::uuid having count(*)>1) then
    raise exception 'duplicate ordinary article observation' using errcode='22023'; end if;
  request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_job_id,actor,
    p_expected_job_version::text,p_expected_cursor,p_resume_cursor,p_observed_items,p_provider));
  perform pg_advisory_xact_lock(hashtextextended(p_job_id::text,7048));
  select * into job from public.translation_jobs where id=p_job_id for update;
  if job.id is null then
    if p_expected_job_version<>0 or jsonb_array_length(p_observed_items)=0 then
      raise exception 'ordinary article checkpoint job not found' using errcode='P0002'; end if;
    marker:=jsonb_build_object('version',1,'actorId',actor,'provider',p_provider,
      'initialCursorHash',probpera_translation_operations.retry_fingerprint(p_expected_cursor),'lastCheckpointHash',null);
    insert into public.translation_jobs(id,kind,provider,status,total_items,requested_by,started_at,resume_cursor)
      values(p_job_id,'article',p_provider,'running',0,actor,clock_timestamp(),
        p_expected_cursor||jsonb_build_object('articleOrdinary',marker)) returning * into job;
    created:=true;
  else
    perform probpera_translation_operations.ordinary_access(p_job_id);
    if not probpera_translation_operations.ordinary_marker(job) or job.provider is distinct from p_provider then
      raise exception 'ordinary article checkpoint domain changed' using errcode='40001'; end if;
    if job.resume_cursor -> 'articleOrdinary' ->> 'lastCheckpointHash'=request_hash then
      return probpera_translation_operations.ordinary_run_view(job,true); end if;
    if job.version is distinct from p_expected_job_version or (job.resume_cursor-'articleOrdinary') is distinct from p_expected_cursor then
      raise exception 'ordinary article checkpoint cursor changed' using errcode='40001'; end if;
  end if;
  if job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then
    raise exception 'ordinary article checkpoint was stopped' using errcode='42501'; end if;
  if exists(select 1 from public.translation_job_items where job_id=p_job_id and (staff_retry is not null or status in ('queued','leased','reviewing','retry_wait'))) then
    raise exception 'ordinary article checkpoint has unresolved items' using errcode='40001'; end if;
  if p_expected_cursor ? 'articleScan' and p_resume_cursor -> 'articleScan' -> 'upperId' is distinct from p_expected_cursor -> 'articleScan' -> 'upperId' then
    raise exception 'ordinary article scan boundary changed' using errcode='40001'; end if;
  for observation in select value from jsonb_array_elements(p_observed_items) loop
    if exists(select 1 from public.translation_job_items where job_id=p_job_id and entity_id=((observation ->> 'entityId')::uuid)::text) then
      raise exception 'ordinary article observation already recorded' using errcode='40001'; end if;
    if job.total_items>=500 then raise exception 'ordinary article run is full' using errcode='40001'; end if;
    insert into public.translation_job_items(job_id,position,entity_type,entity_id,source_hash,status,max_attempts)
      values(p_job_id,job.total_items,'article',((observation ->> 'entityId')::uuid)::text,
        observation ->> 'sourceHash','skipped',3);
    update public.translation_jobs set total_items=total_items+1 where id=p_job_id returning * into job;
  end loop;
  marker:=(job.resume_cursor -> 'articleOrdinary')||jsonb_build_object('lastCheckpointHash',request_hash);
  update public.translation_jobs set resume_cursor=p_resume_cursor||jsonb_build_object('articleOrdinary',marker),
    version=case when created then version else version+1 end,updated_at=clock_timestamp()
    where id=p_job_id returning * into job;
  job:=probpera_translation_operations.ordinary_refresh_job(p_job_id);
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'translation.article_sync.checkpointed','translation_job',p_job_id::text,
      jsonb_build_object('observedItems',p_observed_items,'jobVersion',job.version::text,'requestHash',request_hash));
  return probpera_translation_operations.ordinary_run_view(job);
end; $$;

create or replace function public.get_article_translation_sync_run(p_job_id uuid)
returns jsonb language sql stable security invoker set search_path=''
return probpera_translation_operations.get_article_sync_run(p_job_id);
create or replace function public.begin_article_translation_sync_item(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_article_id uuid,p_expected_job_version bigint,
  p_expected_source_hash text,p_expected_article_updated_at timestamptz,p_expected_english_updated_at timestamptz,
  p_provider text,p_expected_cursor jsonb,p_resume_cursor jsonb,p_expected_source_snapshot jsonb
)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.begin_article_sync_item(p_job_id,p_item_id,p_operation_id,p_article_id,
  p_expected_job_version,p_expected_source_hash,p_expected_article_updated_at,p_expected_english_updated_at,
  p_provider,p_expected_cursor,p_resume_cursor,p_expected_source_snapshot);
create or replace function public.checkpoint_article_translation_sync_run(
  p_job_id uuid,p_expected_job_version bigint,p_expected_cursor jsonb,p_resume_cursor jsonb,p_observed_items jsonb,p_provider text
)
returns jsonb language sql volatile security invoker set search_path=''
return probpera_translation_operations.checkpoint_article_sync_run(p_job_id,p_expected_job_version,p_expected_cursor,
  p_resume_cursor,p_observed_items,p_provider);

create or replace function probpera_translation_operations.article_sync_ready()
returns boolean language sql stable security definer set search_path=''
return (select auth.uid()) is not null
  and public.is_staff(array['owner','admin']::public.staff_role[])
  and public.translation_operations_ready()
  and to_regprocedure('public.begin_article_translation_sync_item(uuid,uuid,uuid,uuid,bigint,text,timestamp with time zone,timestamp with time zone,text,jsonb,jsonb,jsonb)') is not null
  and to_regprocedure('public.get_article_translation_sync_run(uuid)') is not null
  and to_regprocedure('public.checkpoint_article_translation_sync_run(uuid,bigint,jsonb,jsonb,jsonb,text)') is not null
  and to_regprocedure('public.get_article_translation_item_retry(uuid,uuid,uuid)') is not null
  and to_regprocedure('public.begin_article_translation_item_retry(uuid,uuid,uuid,bigint,integer,text,timestamp with time zone,timestamp with time zone,text)') is not null
  and to_regprocedure('public.finish_article_translation_item_retry(uuid,uuid,uuid,jsonb,jsonb)') is not null
  and to_regprocedure('public.get_article_translation_item_retry_progress(uuid,uuid,uuid)') is not null
  and to_regprocedure('public.record_article_translation_item_retry_dispatch(uuid,uuid,uuid,uuid,text,text,text)') is not null
  and to_regprocedure('public.record_article_translation_item_retry_response(uuid,uuid,uuid,jsonb)') is not null
  and to_regprocedure('public.stage_article_translation_item_retry_candidate(uuid,uuid,uuid,jsonb,jsonb)') is not null
  and to_regprocedure('public.get_article_translation_item_retry_candidate(uuid,uuid,uuid)') is not null
  and to_regprocedure('public.recover_article_translation_item_retry_candidate(uuid,uuid,uuid,text)') is not null
  and to_regprocedure('probpera_translation_operations.ordinary_candidate_intact(jsonb,jsonb,public.article_working_drafts,text)') is not null
  and exists(select 1 from pg_index where indexrelid=to_regclass('public.translation_article_active_operation_unique')
    and indisunique and indisvalid and indpred is not null)
  and (select count(*)=3 from pg_trigger where tgfoid=to_regprocedure('probpera_translation_operations.ordinary_write_guard()')
    and tgrelid=any(array['public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass])
    and not tgisinternal and tgenabled in ('O','A'));
create or replace function public.article_translation_sync_ready()
returns boolean language sql stable security invoker set search_path=''
return probpera_translation_operations.article_sync_ready();

-- Additive replacements retain the existing private retry contracts.
create or replace function probpera_translation_operations.get_article_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid default null
)
returns jsonb language plpgsql stable security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  prior jsonb; reason text; active jsonb;
begin
  perform probpera_translation_operations.retry_access();
  perform probpera_translation_operations.ordinary_access(p_job_id);
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or (p_operation_id is not null and not probpera_translation_operations.retry_uuid(p_operation_id)) then
    raise exception 'invalid article item retry identity' using errcode='22023'; end if;
  select * into job from public.translation_jobs where id=p_job_id;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id;
  if job.id is null or item.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  if job.kind<>'article' or item.entity_type<>'article' or job.source_locale<>'ru' or job.target_locale<>'en'
    or item.entity_id !~* '^([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$' then
    raise exception 'invalid article retry domain' using errcode='22023'; end if;
  if p_operation_id is not null then
    select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
    if prior is not null then
      if prior ->> 'actorId' is distinct from (select auth.uid())::text then
        raise exception 'article retry actor changed' using errcode='42501'; end if;
      if prior -> 'receipt' ->> 'jobId' is distinct from p_job_id::text
        or prior -> 'receipt' ->> 'itemId' is distinct from p_item_id::text then
        raise exception 'article retry identity changed' using errcode='40001'; end if;
      return prior -> 'receipt' || jsonb_build_object('replayed',true);
    end if;
    if item.staff_retry ->> 'operationId' is distinct from p_operation_id::text then
      raise exception 'article retry operation not found' using errcode='P0002'; end if;
    if item.staff_retry ->> 'actorId' is distinct from (select auth.uid())::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
  end if;
  if item.staff_retry is not null then
    if item.staff_retry ->> 'actorId' is distinct from (select auth.uid())::text then
      return probpera_translation_operations.retry_view(job,item,'blocked','retry_busy',null,null,null);
    end if;
    active:=item.staff_retry;
    return probpera_translation_operations.retry_view(job,item,'running',null,active,
      (active ->> 'sourceUpdatedAt')::timestamptz,(active ->> 'englishUpdatedAt')::timestamptz,false,true);
  end if;
  if job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then reason:='operation_stopped';
  elsif not probpera_translation_operations.ordinary_marker(job) and not exists(select 1 from public.admin_audit_log a where a.action='translation.sync_run.recorded'
    and a.entity_type='translation_job' and a.entity_id=job.id::text) then reason:='job_not_sync';
  elsif job.status not in ('completed','partial','failed','conflict','stale','skipped','not-configured') then reason:='job_not_finished';
  elsif item.source_hash is null then reason:='source_hash_missing';
  elsif item.status not in ('dead_letter','conflict','stale','not-configured') then reason:='item_not_failed';
  elsif item.attempt_count>=5 or item.max_attempts>5
    or (probpera_translation_operations.ordinary_marker(job) and item.attempt_count>=item.max_attempts) then reason:='attempt_limit';
  elsif exists(select 1 from public.translation_job_items other where other.job_id=job.id
    and (other.status in ('queued','leased','reviewing','retry_wait') or other.staff_retry is not null)) then reason:='retry_busy'; end if;
  select * into article from public.articles where id=item.entity_id::uuid;
  select * into english from public.article_translations where article_id=item.entity_id::uuid and locale='en';
  if reason is null then
    if article.id is null or article.deleted_at is not null or article.status<>'published' then reason:='source_unavailable';
    elsif exists(select 1 from public.article_working_drafts where article_id=article.id) then reason:='author_draft_exists';
    elsif english.id is not null and (english.deleted_at is not null
      or english.source_content_hash is null or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
      or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
      or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash) then reason:='manual_english';
    else
      begin perform probpera_translation_operations.retry_ru_snapshot(article);
      exception when invalid_parameter_value then reason:='source_shape_unsupported'; end;
    end if;
  end if;
  return probpera_translation_operations.retry_view(job,item,case when reason is null then 'ready' else 'blocked' end,
    reason,null,article.updated_at,english.updated_at);
end; $$;

create or replace function probpera_translation_operations.begin_article_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_expected_job_version bigint,
  p_expected_attempt_count integer,p_expected_source_hash text,p_expected_article_updated_at timestamptz,
  p_expected_english_updated_at timestamptz,p_provider text
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  actor uuid:=(select auth.uid()); intent jsonb; prior jsonb; view jsonb; active jsonb; snapshot jsonb; violated_constraint text;
begin
  perform probpera_translation_operations.retry_access();
  perform probpera_translation_operations.ordinary_access(p_job_id);
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id)
    or p_expected_job_version is null or p_expected_job_version<1 or p_expected_job_version>9223372036854775805
    or p_expected_attempt_count is null or p_expected_attempt_count not between 0 and 4
    or p_expected_source_hash is null or p_expected_source_hash !~ '^[a-f0-9]{64}$'
    or p_expected_article_updated_at is null or p_provider is null or p_provider not in ('cloudflare','openai') then
    raise exception 'invalid article retry intent' using errcode='22023'; end if;
  intent:=jsonb_build_array(p_job_id,p_item_id,p_operation_id,actor,p_expected_job_version::text,
    p_expected_attempt_count,p_expected_source_hash,p_expected_article_updated_at,p_expected_english_updated_at,p_provider);
  -- Bind the UUID globally across active items and completed attempts before
  -- admitting any provider work. This lock lasts only for the SQL request.
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior is not null then
    if prior ->> 'actorId' is distinct from actor::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if prior -> 'beginIntent' is distinct from intent then
      raise exception 'article retry intent changed' using errcode='40001'; end if;
    return prior -> 'receipt' || jsonb_build_object('replayed',true,'canExecute',false);
  end if;
  if exists(select 1 from public.translation_job_items other where other.staff_retry ->> 'operationId'=p_operation_id::text
    and (other.id<>p_item_id or other.job_id<>p_job_id)) then
    raise exception 'article retry UUID already belongs to another item' using errcode='40001'; end if;
  -- Existing worker completion locks item before job. Cancellation locks job
  -- before queued/retry_wait items; this path admits only finished failed
  -- items and excludes every worker-active item before changing state.
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  if item.id is null or job.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  if item.staff_retry is not null then
    if item.staff_retry ->> 'actorId' is distinct from actor::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if item.staff_retry -> 'beginIntent' is distinct from intent then
      raise exception 'article retry already active or intent changed' using errcode='40001'; end if;
    return probpera_translation_operations.retry_view(job,item,'running',null,item.staff_retry,
      (item.staff_retry ->> 'sourceUpdatedAt')::timestamptz,
      (item.staff_retry ->> 'englishUpdatedAt')::timestamptz,false,true);
  end if;
  if job.version is distinct from p_expected_job_version or item.attempt_count is distinct from p_expected_attempt_count
    or item.source_hash is distinct from p_expected_source_hash or job.provider is distinct from p_provider then
    raise exception 'article retry item or job changed' using errcode='40001'; end if;
  if probpera_translation_operations.ordinary_marker(job)
    and probpera_translation_operations.article_sync_ready() is distinct from true then
    raise exception 'ordinary article admission capability is unavailable' using errcode='42883'; end if;
  view:=probpera_translation_operations.get_article_item_retry(p_job_id,p_item_id,null);
  if view ->> 'phase'<>'ready' then
    if view ->> 'blockReason'='operation_stopped' then
      raise exception 'article retry was stopped' using errcode='42501'; end if;
    raise exception 'article retry is not eligible' using errcode='40001';
  end if;
  select * into article from public.articles where id=item.entity_id::uuid for update;
  select * into english from public.article_translations where article_id=article.id and locale='en' for update;
  if article.updated_at is distinct from p_expected_article_updated_at
    or english.updated_at is distinct from p_expected_english_updated_at then
    raise exception 'article retry source or English changed' using errcode='40001'; end if;
  if article.id is null or article.deleted_at is not null or article.status<>'published'
    or exists(select 1 from public.article_working_drafts where article_id=article.id) then
    raise exception 'article retry source or draft changed' using errcode='40001'; end if;
  if english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
    or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
    or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash) then
    raise exception 'article retry English ownership changed' using errcode='40001'; end if;
  snapshot:=probpera_translation_operations.retry_ru_snapshot(article);
  active:=jsonb_build_object('version',1,'operationId',p_operation_id,'actorId',actor,'articleId',article.id,
    'beginIntent',intent,'sourceUpdatedAt',p_expected_article_updated_at,'englishUpdatedAt',p_expected_english_updated_at,
    'attemptNumber',item.attempt_count+1,'startedAt',clock_timestamp(),
    'sourceSnapshotHash',probpera_translation_operations.retry_fingerprint(snapshot));
  if probpera_translation_operations.ordinary_marker(job) then
    active:=active||jsonb_build_object('progress',jsonb_build_object('version',1,'updatedAt',active -> 'startedAt','calls','[]'::jsonb));
  end if;
  update public.translation_job_items set staff_retry=active,status='reviewing',
    max_attempts=case when probpera_translation_operations.ordinary_marker(job) then max_attempts else attempt_count+1 end,lease_owner=null,lease_expires_at=null,updated_at=clock_timestamp()
    where id=item.id returning * into item;
  update public.translation_jobs set status='reviewing',failed_items=(select count(*) from public.translation_job_items
    where job_id=job.id and status='dead_letter'),completed_at=null,version=version+1,updated_at=clock_timestamp()
    where id=job.id returning * into job;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'translation.article_item_retry.began','translation_job',job.id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',item.id,'attemptNumber',item.attempt_count+1,
        'sourceHash',item.source_hash,'jobVersion',job.version::text));
  return probpera_translation_operations.retry_view(job,item,'running',null,active,
    p_expected_article_updated_at,p_expected_english_updated_at,true,false);
exception when unique_violation then
  get stacked diagnostics violated_constraint=constraint_name;
  if violated_constraint='translation_article_active_operation_unique' then
    raise exception 'article translation operation is already active' using errcode='40001';
  end if;
  raise;
end; $$;

create or replace function probpera_translation_operations.retry_journal_active(
  p_job public.translation_jobs,p_item public.translation_job_items,p_operation_id uuid
)
returns void language plpgsql stable security invoker set search_path='' as $$
declare active jsonb:=p_item.staff_retry; actor uuid:=(select auth.uid());
begin
  perform probpera_translation_operations.ordinary_access(p_job.id);
  if active ->> 'operationId' is distinct from p_operation_id::text then
    raise exception 'article retry operation not found' using errcode='P0002'; end if;
  if active ->> 'actorId' is distinct from actor::text then
    raise exception 'article retry actor changed' using errcode='42501'; end if;
  if p_item.status<>'reviewing' or p_item.lease_owner is not null or p_item.lease_expires_at is not null
    or p_job.kind<>'article' or p_item.entity_type<>'article' or p_job.source_locale<>'ru' or p_job.target_locale<>'en'
    or p_job.provider not in ('openai','cloudflare') or p_item.source_hash is null or p_item.source_hash !~ '^[a-f0-9]{64}$'
    or active -> 'version' is distinct from '1'::jsonb
    or not probpera_translation_operations.retry_uuid(p_item.entity_id::uuid)
    or (active ->> 'articleId')::uuid is distinct from p_item.entity_id::uuid
    or (active ->> 'attemptNumber')::integer is distinct from p_item.attempt_count+1
    or p_item.attempt_count not between 0 and 4
    or (not probpera_translation_operations.ordinary_marker(p_job) and p_item.max_attempts<>p_item.attempt_count+1)
    or (probpera_translation_operations.ordinary_marker(p_job) and p_item.max_attempts<p_item.attempt_count+1)
    or active -> 'beginIntent' ->> 0 is distinct from p_job.id::text
    or active -> 'beginIntent' ->> 1 is distinct from p_item.id::text
    or active -> 'beginIntent' ->> 2 is distinct from p_operation_id::text
    or active -> 'beginIntent' ->> 3 is distinct from actor::text
    or active -> 'beginIntent' ->> 6 is distinct from p_item.source_hash
    or active -> 'beginIntent' ->> 9 is distinct from p_job.provider
    or active -> 'sourceUpdatedAt' is distinct from active -> 'beginIntent' -> 7
    or active -> 'englishUpdatedAt' is distinct from active -> 'beginIntent' -> 8
    or (active -> 'progress' is not null and active -> 'progress'<>'null'::jsonb
      and not probpera_translation_operations.retry_journal_valid(active -> 'progress',p_job.provider)) then
    raise exception 'article retry active item changed' using errcode='40001'; end if;
end; $$;

-- A canonical CAS refusal does not invalidate the already staged private
-- body. Validate that body against its ORIGINAL snapshot/metadata, without
-- comparing it to the newly authored canonical RU or English.
create or replace function probpera_translation_operations.ordinary_candidate_intact(
  p_active jsonb,p_meta jsonb,p_draft public.article_working_drafts,p_provider text
)
returns boolean language plpgsql stable security invoker set search_path='' as $$
begin
  return probpera_translation_operations.retry_candidate_meta_valid(p_meta)
    and probpera_translation_operations.retry_journal_valid(p_active -> 'progress',p_provider)
    and jsonb_array_length(p_active -> 'progress' -> 'calls')=(p_meta -> 'outcome' ->> 'providerCalls')::integer
    and not exists(select 1 from jsonb_array_elements(p_active -> 'progress' -> 'calls') call
      where call -> 'responseReceivedAt'='null'::jsonb)
    and p_draft.article_id::text=p_active ->> 'articleId'
    and p_draft.actor_id::text=p_active ->> 'actorId'
    and p_draft.version=(p_meta ->> 'workingDraftVersion')::bigint
    and p_draft.updated_at=(p_meta ->> 'workingDraftUpdatedAt')::timestamptz
    and p_draft.base_article_updated_at=(p_active ->> 'sourceUpdatedAt')::timestamptz
    and p_draft.expected_english_updated_at is not distinct from (p_active ->> 'englishUpdatedAt')::timestamptz
    and p_draft.draft_scope='english-only' and p_draft.draft_english_enabled=true
    and probpera_translation_operations.retry_payload_valid(p_draft.payload,false)
    and probpera_translation_operations.retry_fingerprint(p_draft.payload)=p_active ->> 'sourceSnapshotHash'
    and probpera_translation_operations.retry_payload_valid(p_draft.english_payload -> 'payload',true)
    and p_draft.english_payload -> 'mode'='"save"'::jsonb
    and p_draft.english_payload-array['mode','payload']='{}'::jsonb
    and p_draft.english_payload -> 'payload' ->> 'source_content_hash'=p_active -> 'beginIntent' ->> 6
    and probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_draft.payload,p_draft.english_payload,p_meta -> 'outcome'))
      =p_meta ->> 'candidateHash'
    and probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_meta -> 'outcome',p_draft.english_payload))
      =p_meta ->> 'finishFingerprint';
exception when others then return false;
end; $$;

create or replace function probpera_translation_operations.finish_article_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_english_payload jsonb default null
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare job public.translation_jobs%rowtype; item public.translation_job_items%rowtype;
  article public.articles%rowtype; english public.article_translations%rowtype;
  actor uuid:=(select auth.uid()); active jsonb; prior jsonb; request_hash text;
  outcome text; code text; attempt_outcome text; snapshot jsonb; saved jsonb; result jsonb; receipt jsonb;
  source_stamp timestamptz; english_stamp timestamptz; attempt_number integer;
  succeeded integer; failed integer; conflicts integer; stale integer; not_configured integer;
  field text; field_value jsonb; draft_stamp timestamptz;
  candidate jsonb; candidate_reason text; draft public.article_working_drafts%rowtype;
begin
  perform probpera_translation_operations.retry_access();
  perform probpera_translation_operations.ordinary_access(p_job_id);
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id)
    or jsonb_typeof(p_outcome) is distinct from 'object' or octet_length(p_outcome::text)>16384
    or not(p_outcome ?& array['status','providerCalls'])
    or p_outcome - array['status','providerCalls','errorCode','model','requestId','inputTokens','outputTokens','durationMs'] <> '{}'::jsonb
    or jsonb_typeof(p_outcome -> 'status') is distinct from 'string'
    or p_outcome ->> 'status' not in ('succeeded','dead_letter','conflict','stale','skipped','not-configured')
    or jsonb_typeof(p_outcome -> 'providerCalls') is distinct from 'number'
    or (p_outcome ->> 'providerCalls') !~ '^[0-4]$' then
    raise exception 'invalid article retry outcome' using errcode='22023'; end if;
  outcome:=p_outcome ->> 'status'; code:=p_outcome ->> 'errorCode';
  if (p_outcome ? 'errorCode' and p_outcome -> 'errorCode'<>'null'::jsonb
      and jsonb_typeof(p_outcome -> 'errorCode') is distinct from 'string')
    or (outcome in ('succeeded','skipped') and code is not null)
    or (outcome not in ('succeeded','skipped') and (code is null or code not in (
      'translation_not_configured','provider_unavailable','provider_request_failed','provider_invalid_response',
      'source_changed','write_conflict','database_read_failed','database_write_failed','unexpected'))) then
    raise exception 'invalid article retry error' using errcode='22023'; end if;
  foreach field in array array['model','requestId'] loop
    field_value:=p_outcome -> field;
    if field_value is not null and field_value<>'null'::jsonb and
      (jsonb_typeof(field_value) is distinct from 'string' or probpera_translation_operations.retry_text_length(p_outcome ->> field) not between 1 and 200) then
      raise exception 'invalid article retry provider metadata' using errcode='22023'; end if;
  end loop;
  foreach field in array array['inputTokens','outputTokens','durationMs'] loop
    field_value:=p_outcome -> field;
    if field_value is not null and field_value<>'null'::jsonb and
      (jsonb_typeof(field_value) is distinct from 'number' or (p_outcome ->> field) !~ '^[0-9]{1,8}$'
        or (p_outcome ->> field)::numeric > case when field='durationMs' then 3600000 else 10000000 end) then
      raise exception 'invalid article retry usage metadata' using errcode='22023'; end if;
  end loop;
  if outcome='succeeded' then
    if jsonb_typeof(p_english_payload) is distinct from 'object'
      or not(p_english_payload ?& array['mode','payload']) or p_english_payload - array['mode','payload']<>'{}'::jsonb
      or p_english_payload -> 'mode' is distinct from '"save"'::jsonb
      or not probpera_translation_operations.retry_payload_valid(p_english_payload -> 'payload',true) then
      raise exception 'invalid article retry private English' using errcode='22023'; end if;
  elsif p_english_payload is not null then
    raise exception 'non-successful article retry cannot persist English' using errcode='22023';
  end if;
  request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_outcome,p_english_payload));
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7047));
  select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
  if prior is not null then
    if prior ->> 'actorId' is distinct from actor::text then
      raise exception 'article retry actor changed' using errcode='42501'; end if;
    if prior -> 'receipt' ->> 'jobId' is distinct from p_job_id::text
      or prior -> 'receipt' ->> 'itemId' is distinct from p_item_id::text
      or prior ->> 'finishFingerprint' is distinct from request_hash then
      raise exception 'article retry finish intent changed' using errcode='40001'; end if;
    return prior -> 'receipt' || jsonb_build_object('replayed',true,'canExecute',false);
  end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  if item.id is null or job.id is null then raise exception 'article retry item not found' using errcode='P0002'; end if;
  active:=item.staff_retry;
  if active ->> 'operationId' is distinct from p_operation_id::text then
    raise exception 'article retry operation not found' using errcode='P0002'; end if;
  if active ->> 'actorId' is distinct from actor::text then
    raise exception 'article retry actor changed' using errcode='42501'; end if;
  source_stamp:=(active ->> 'sourceUpdatedAt')::timestamptz;
  english_stamp:=(active ->> 'englishUpdatedAt')::timestamptz;
  attempt_number:=(active ->> 'attemptNumber')::integer;
  if item.status<>'reviewing' or item.lease_owner is not null or item.lease_expires_at is not null
    or attempt_number is distinct from item.attempt_count+1 or attempt_number not between 1 and 5
    or job.kind<>'article' or item.entity_type<>'article' or job.source_locale<>'ru' or job.target_locale<>'en'
    or active -> 'version' is distinct from '1'::jsonb
    or (active ->> 'articleId')::uuid is distinct from item.entity_id::uuid
    or active -> 'beginIntent' ->> 0 is distinct from job.id::text
    or active -> 'beginIntent' ->> 1 is distinct from item.id::text
    or active -> 'beginIntent' ->> 2 is distinct from p_operation_id::text
    or active -> 'beginIntent' ->> 3 is distinct from actor::text
    or active -> 'beginIntent' ->> 6 is distinct from item.source_hash
    or active -> 'beginIntent' ->> 9 is distinct from job.provider then
    raise exception 'article retry active item changed' using errcode='40001'; end if;
  if outcome='succeeded' and p_english_payload -> 'payload' ->> 'source_content_hash' is distinct from item.source_hash then
    raise exception 'article retry English source changed' using errcode='22023'; end if;
  -- A durable dispatch remains unknown until its received-response record is
  -- acknowledged. Neither a timer nor a caller-supplied failure closes it.
  if active -> 'progress' is not null and active -> 'progress'<>'null'::jsonb then
    if not probpera_translation_operations.retry_journal_valid(active -> 'progress',job.provider)
      or jsonb_array_length(active -> 'progress' -> 'calls') is distinct from (p_outcome ->> 'providerCalls')::integer
      or exists(select 1 from jsonb_array_elements(active -> 'progress' -> 'calls') recorded
        where recorded -> 'responseReceivedAt'='null'::jsonb) then
      raise exception 'article retry provider outcome is unconfirmed' using errcode='40001'; end if;
  end if;
  candidate:=nullif(active -> 'candidate','null'::jsonb);
  if active ? 'candidate' and (candidate is null or not probpera_translation_operations.retry_candidate_meta_valid(candidate)
    or candidate ->> 'finishFingerprint' is distinct from request_hash) then
    raise exception 'article retry prepared finish intent changed' using errcode='40001'; end if;
  select * into article from public.articles where id=item.entity_id::uuid for update;
  select * into english from public.article_translations where article_id=item.entity_id::uuid and locale='en' for update;
  -- A known provider outcome is always journaled. A cancelled or changed
  -- source has no draft write, and does not turn generated text into review.
  if candidate is not null then
    select * into draft from public.article_working_drafts where article_id=item.entity_id::uuid for update;
    candidate_reason:=probpera_translation_operations.retry_candidate_block_reason(active,candidate,article,english,draft,job.provider);
    if candidate_reason is not null then
      if probpera_translation_operations.ordinary_marker(job)
        and candidate_reason in ('source_changed','english_changed')
        and probpera_translation_operations.ordinary_candidate_intact(active,candidate,draft,job.provider) is true then
        outcome:=case when candidate_reason='source_changed' then 'stale' else 'conflict' end;
        code:=case when candidate_reason='source_changed' then 'source_changed' else 'write_conflict' end;
        -- Journal the known outcome, preserve both the original private body
        -- and the new canonical author content, and release this admission.
      else
        raise exception 'article retry prepared candidate changed: %',candidate_reason using errcode='40001';
      end if;
    end if;
    if job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then
      outcome:='cancelled'; code:=null;
      -- The private body was already saved at STAGE and remains available.
      -- This cancelled FINISH performs no draft write.
    elsif candidate_reason is null then
      saved:=jsonb_build_object('articleId',draft.article_id,'version',draft.version,'updatedAt',draft.updated_at);
      draft_stamp:=draft.updated_at;
      -- Consume the protected SAME row: no second save or version increment.
    end if;
  elsif job.cancel_requested_at is not null or job.status in ('cancelled','cancelling') then
    outcome:='cancelled'; code:=null;
  elsif outcome='succeeded' then
    if article.id is null or article.deleted_at is not null or article.status<>'published'
      or article.updated_at is distinct from source_stamp then outcome:='stale'; code:='source_changed';
    elsif english.updated_at is distinct from english_stamp
      or exists(select 1 from public.article_working_drafts where article_id=article.id)
      or (english.id is not null and (english.deleted_at is not null or english.source_content_hash is null
        or english.content_json -> '__probperaPremiumTranslation' -> 'version' is distinct from '1'::jsonb
        or english.content_json -> '__probperaPremiumTranslation' -> 'method' is distinct from '"machine-translation"'::jsonb
        or english.content_json -> '__probperaPremiumTranslation' ->> 'sourceHash' is distinct from english.source_content_hash)) then
      outcome:='conflict'; code:='write_conflict';
    else
      begin snapshot:=probpera_translation_operations.retry_ru_snapshot(article);
      exception when invalid_parameter_value then snapshot:=null; end;
      if snapshot is null or probpera_translation_operations.retry_fingerprint(snapshot) is distinct from active ->> 'sourceSnapshotHash' then
        outcome:='stale'; code:='source_changed';
      else
        saved:=public.save_article_working_draft(article.id,source_stamp,snapshot,p_english_payload,english_stamp,0);
        if saved ->> 'articleId' is distinct from article.id::text or saved -> 'version' is distinct from '1'::jsonb
          or jsonb_typeof(saved -> 'updatedAt') is distinct from 'string' then
          raise exception 'invalid article retry private draft receipt' using errcode='22023'; end if;
        draft_stamp:=(saved ->> 'updatedAt')::timestamptz;
        update public.article_working_drafts set draft_scope='english-only',draft_english_enabled=true
          where article_id=article.id and version=1;
        if not found then raise exception 'article retry private draft changed' using errcode='40001'; end if;
      end if;
    end if;
  end if;
  update public.translation_job_items set status=case when outcome='cancelled' then 'cancelled' else outcome end,
    attempt_count=attempt_number,staff_retry=null,lease_owner=null,lease_expires_at=null,last_error_code=code,
    updated_at=clock_timestamp() where id=item.id returning * into item;
  select count(*) filter(where status='succeeded'),count(*) filter(where status='dead_letter'),
    count(*) filter(where status='conflict'),count(*) filter(where status='stale'),count(*) filter(where status='not-configured')
    into succeeded,failed,conflicts,stale,not_configured from public.translation_job_items where job_id=job.id;
  update public.translation_jobs set succeeded_items=succeeded,failed_items=failed,
    status=case when outcome='cancelled' then 'cancelled'
      when failed>0 then case when succeeded>0 then 'partial' else 'failed' end
      when conflicts>0 then 'conflict' when stale>0 then 'stale' when not_configured>0 then 'not-configured'
      when succeeded=0 then 'skipped' else 'completed' end,
    completed_at=clock_timestamp(),version=version+1,updated_at=clock_timestamp()
    where id=job.id returning * into job;
  if probpera_translation_operations.ordinary_marker(job) then
    job:=probpera_translation_operations.ordinary_refresh_job(job.id);
  end if;
  result:=jsonb_build_object('outcome',outcome,'errorCode',code,
    'persistence',case when saved is not null then 'working-draft' else 'none' end,
    'workingDraftVersion',case when saved is not null then 1 else null end,'workingDraftUpdatedAt',draft_stamp,
    'publication','unchanged','humanReview',case when saved is not null then 'pending' else 'unchanged' end,
    'providerCalls',(p_outcome ->> 'providerCalls')::integer);
  receipt:=probpera_translation_operations.retry_view(job,item,'finished',null,active,source_stamp,english_stamp,false,false,result);
  attempt_outcome:=case when outcome='cancelled' then 'skipped' else outcome end;
  insert into public.translation_job_attempts(item_id,attempt_number,outcome,provider,model,provider_request_id,
    error_code,input_tokens,output_tokens,duration_ms,staff_retry_operation_id,staff_retry_receipt)
    values(item.id,attempt_number,attempt_outcome,job.provider,p_outcome ->> 'model',p_outcome ->> 'requestId',code,
      (p_outcome ->> 'inputTokens')::integer,(p_outcome ->> 'outputTokens')::integer,(p_outcome ->> 'durationMs')::integer,
      p_operation_id,jsonb_build_object('actorId',actor,'beginIntent',active -> 'beginIntent',
        'finishFingerprint',request_hash,'receipt',receipt,
        'progress',active -> 'progress','startedAt',active -> 'startedAt')
        ||case when candidate is null then '{}'::jsonb else jsonb_build_object(
          'candidate',candidate,'sourceSnapshotHash',active -> 'sourceSnapshotHash') end);
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'translation.article_item_retry.finished','translation_job',job.id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',item.id,'attemptNumber',attempt_number,
        'outcome',outcome,'persistence',result -> 'persistence','jobVersion',job.version::text));
  return receipt;
end; $$;

-- GET remains truthful: a changed source/English has canRecover=false and its
-- original blockReason. Explicit ordinary finalization accepts only these
-- two known CAS refusals with an intact, fully acknowledged stored candidate.
create or replace function probpera_translation_operations.recover_article_item_retry_candidate(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_expected_candidate_hash text
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare view jsonb; prior jsonb; meta jsonb; item public.translation_job_items%rowtype;
  job public.translation_jobs%rowtype; draft public.article_working_drafts%rowtype;
begin
  perform probpera_translation_operations.retry_access();
  perform probpera_translation_operations.ordinary_access(p_job_id);
  if p_expected_candidate_hash is null or p_expected_candidate_hash !~ '^[a-f0-9]{64}$' then
    raise exception 'invalid article retry candidate hash' using errcode='22023'; end if;
  view:=probpera_translation_operations.get_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id);
  if view ->> 'candidateHash' is distinct from p_expected_candidate_hash then
    raise exception 'article retry candidate hash changed' using errcode='40001'; end if;
  if view ->> 'phase'='finished' then
    select staff_retry_receipt into prior from public.translation_job_attempts where staff_retry_operation_id=p_operation_id;
    return prior -> 'receipt'||jsonb_build_object('replayed',true,'canExecute',false);
  end if;
  if view -> 'canRecover' is distinct from 'true'::jsonb then
    select * into job from public.translation_jobs where id=p_job_id;
    if not probpera_translation_operations.ordinary_marker(job)
      or view ->> 'blockReason' not in ('source_changed','english_changed') then
      raise exception 'article retry candidate cannot be recovered: %',view ->> 'blockReason' using errcode='40001';
    end if;
  end if;
  select * into item from public.translation_job_items where id=p_item_id and job_id=p_job_id for update;
  select * into job from public.translation_jobs where id=p_job_id for update;
  perform probpera_translation_operations.retry_journal_active(job,item,p_operation_id);
  meta:=item.staff_retry -> 'candidate';
  select * into draft from public.article_working_drafts where article_id=item.entity_id::uuid for update;
  if view -> 'canRecover' is distinct from 'true'::jsonb
    and probpera_translation_operations.ordinary_candidate_intact(item.staff_retry,meta,draft,job.provider) is distinct from true then
    raise exception 'article retry prepared candidate changed' using errcode='40001'; end if;
  return probpera_translation_operations.finish_article_item_retry(p_job_id,p_item_id,p_operation_id,meta -> 'outcome',draft.english_payload);
end; $$;

create or replace function public.get_article_translation_item_retry(p_job_id uuid,p_item_id uuid,p_operation_id uuid default null)
returns jsonb language sql stable security invoker set search_path=''
return case when probpera_translation_operations.ordinary_access(p_job_id) then probpera_translation_operations.get_article_item_retry(p_job_id,p_item_id,p_operation_id) else null end;

create or replace function public.begin_article_translation_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_expected_job_version bigint,p_expected_attempt_count integer,
  p_expected_source_hash text,p_expected_article_updated_at timestamptz,p_expected_english_updated_at timestamptz,p_provider text)
returns jsonb language sql volatile security invoker set search_path=''
return case when probpera_translation_operations.ordinary_access(p_job_id) then probpera_translation_operations.begin_article_item_retry(p_job_id,p_item_id,p_operation_id,p_expected_job_version,
  p_expected_attempt_count,p_expected_source_hash,p_expected_article_updated_at,p_expected_english_updated_at,p_provider) else null end;

create or replace function public.finish_article_translation_item_retry(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_english_payload jsonb default null)
returns jsonb language sql volatile security invoker set search_path=''
return case when probpera_translation_operations.ordinary_access(p_job_id) then probpera_translation_operations.finish_article_item_retry(p_job_id,p_item_id,p_operation_id,p_outcome,p_english_payload) else null end;

create or replace function public.record_article_translation_item_retry_dispatch(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_call_id uuid,p_provider text,p_model text,p_pass text
)
returns jsonb language sql volatile security invoker set search_path=''
return case when probpera_translation_operations.ordinary_access(p_job_id) then probpera_translation_operations.record_article_item_retry_dispatch(p_job_id,p_item_id,p_operation_id,p_call_id,p_provider,p_model,p_pass) else null end;

create or replace function public.record_article_translation_item_retry_response(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_metadata jsonb
)
returns jsonb language sql volatile security invoker set search_path=''
return case when probpera_translation_operations.ordinary_access(p_job_id) then probpera_translation_operations.record_article_item_retry_response(p_job_id,p_item_id,p_operation_id,p_metadata) else null end;

create or replace function public.get_article_translation_item_retry_progress(p_job_id uuid,p_item_id uuid,p_operation_id uuid)
returns jsonb language sql volatile security invoker set search_path=''
return case when probpera_translation_operations.ordinary_access(p_job_id) then probpera_translation_operations.get_article_item_retry_progress(p_job_id,p_item_id,p_operation_id) else null end;

create or replace function public.stage_article_translation_item_retry_candidate(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_english_payload jsonb
)
returns jsonb language sql volatile security invoker set search_path=''
return case when probpera_translation_operations.ordinary_access(p_job_id) then probpera_translation_operations.stage_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id,p_outcome,p_english_payload) else null end;

create or replace function public.get_article_translation_item_retry_candidate(p_job_id uuid,p_item_id uuid,p_operation_id uuid)
returns jsonb language sql volatile security invoker set search_path=''
return case when probpera_translation_operations.ordinary_access(p_job_id) then probpera_translation_operations.get_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id) else null end;

create or replace function public.recover_article_translation_item_retry_candidate(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_expected_candidate_hash text
)
returns jsonb language sql volatile security invoker set search_path=''
return case when probpera_translation_operations.ordinary_access(p_job_id) then probpera_translation_operations.recover_article_item_retry_candidate(p_job_id,p_item_id,p_operation_id,p_expected_candidate_hash) else null end;

revoke all on function probpera_translation_operations.ordinary_marker(public.translation_jobs) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.ordinary_candidate_intact(jsonb,jsonb,public.article_working_drafts,text) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.ordinary_access(uuid) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.ordinary_cursor_valid(jsonb) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.ordinary_run_view(public.translation_jobs,boolean) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.ordinary_refresh_job(uuid) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.ordinary_write_guard() from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.article_sync_ready() from public,anon,authenticated,service_role;
revoke all on function public.article_translation_sync_ready() from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.get_article_sync_run(uuid) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.begin_article_sync_item(uuid,uuid,uuid,uuid,bigint,text,timestamptz,timestamptz,text,jsonb,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function probpera_translation_operations.checkpoint_article_sync_run(uuid,bigint,jsonb,jsonb,jsonb,text) from public,anon,authenticated,service_role;
revoke all on function public.get_article_translation_sync_run(uuid) from public,anon,authenticated,service_role;
revoke all on function public.begin_article_translation_sync_item(uuid,uuid,uuid,uuid,bigint,text,timestamptz,timestamptz,text,jsonb,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.checkpoint_article_translation_sync_run(uuid,bigint,jsonb,jsonb,jsonb,text) from public,anon,authenticated,service_role;
grant execute on function probpera_translation_operations.ordinary_access(uuid) to authenticated;
grant execute on function probpera_translation_operations.article_sync_ready() to authenticated;
grant execute on function public.article_translation_sync_ready() to authenticated;
grant execute on function probpera_translation_operations.get_article_sync_run(uuid) to authenticated;
grant execute on function probpera_translation_operations.begin_article_sync_item(uuid,uuid,uuid,uuid,bigint,text,timestamptz,timestamptz,text,jsonb,jsonb,jsonb) to authenticated;
grant execute on function probpera_translation_operations.checkpoint_article_sync_run(uuid,bigint,jsonb,jsonb,jsonb,text) to authenticated;
grant execute on function public.get_article_translation_sync_run(uuid) to authenticated;
grant execute on function public.begin_article_translation_sync_item(uuid,uuid,uuid,uuid,bigint,text,timestamptz,timestamptz,text,jsonb,jsonb,jsonb) to authenticated;
grant execute on function public.checkpoint_article_translation_sync_run(uuid,bigint,jsonb,jsonb,jsonb,text) to authenticated;
commit;

-- Preserve every existing operational error code and admit the explicit stop
-- outcome already understood by the application. Source/provider prose remains
-- outside the existing Translation Operations tables.
alter table public.translation_job_items
  drop constraint translation_job_items_last_error_code_check;
alter table public.translation_job_items
  add constraint translation_job_items_last_error_code_check check (
    last_error_code is null or last_error_code in (
      'translation_not_configured', 'provider_unavailable',
      'provider_request_failed', 'provider_invalid_response', 'source_changed',
      'write_conflict', 'database_read_failed', 'database_write_failed', 'unexpected',
      'translation_operation_stopped'
    )
  );

alter table public.translation_job_attempts
  drop constraint translation_job_attempts_error_code_check;
alter table public.translation_job_attempts
  add constraint translation_job_attempts_error_code_check check (
    error_code is null or error_code in (
      'translation_not_configured', 'provider_unavailable',
      'provider_request_failed', 'provider_invalid_response', 'source_changed',
      'write_conflict', 'database_read_failed', 'database_write_failed', 'unexpected',
      'translation_operation_stopped'
    )
  );

-- Read metadata only, using the current caller's permissions and a fresh staff
-- check. Fail closed on missing, unvalidated or altered error-code guards.
create function public.profile_translation_budget_ready()
returns boolean language plpgsql stable security invoker set search_path = '' as $$
declare
  expected_codes constant text[] := array[
    'translation_not_configured', 'provider_unavailable',
    'provider_request_failed', 'provider_invalid_response', 'source_changed',
    'write_conflict', 'database_read_failed', 'database_write_failed', 'unexpected',
    'translation_operation_stopped'
  ];
  codes_expression text;
  guard record;
  record_rpc oid := pg_catalog.to_regprocedure('public.record_translation_sync_run(text,text,jsonb,jsonb,jsonb)');
  resume_rpc oid := pg_catalog.to_regprocedure('public.get_translation_job_resume(uuid)');
begin
  if auth.uid() is null or not coalesce(public.is_staff(), false) then
    raise exception using errcode = '42501', message = 'Profile translation budget readiness requires staff access';
  end if;
  if record_rpc is null or resume_rpc is null then return false; end if;
  if not coalesce(pg_catalog.has_function_privilege('authenticated', record_rpc, 'EXECUTE'), false)
    or not coalesce(pg_catalog.has_function_privilege('authenticated', resume_rpc, 'EXECUTE'), false)
    or not exists (select 1 from pg_catalog.pg_proc where oid = record_rpc and prorettype = 'uuid'::regtype)
    or not exists (select 1 from pg_catalog.pg_proc where oid = resume_rpc and prorettype = 'jsonb'::regtype) then
    return false;
  end if;
  select pg_catalog.string_agg(pg_catalog.quote_literal(code) || '::text', ', ' order by position)
    into codes_expression from pg_catalog.unnest(expected_codes) with ordinality as code_list(code, position);
  for guard in select * from (values
    ('public.translation_job_items', 'translation_job_items_last_error_code_check', 'last_error_code'),
    ('public.translation_job_attempts', 'translation_job_attempts_error_code_check', 'error_code')
  ) as expected(table_name, constraint_name, column_name) loop
    if not exists (
      select 1 from pg_catalog.pg_constraint constraint_row
      join pg_catalog.pg_attribute attribute_row
        on attribute_row.attrelid = constraint_row.conrelid and attribute_row.attname = guard.column_name
      where constraint_row.conrelid = pg_catalog.to_regclass(guard.table_name)
        and constraint_row.conname = guard.constraint_name
        and constraint_row.contype = 'c' and constraint_row.convalidated
        and constraint_row.conkey = array[attribute_row.attnum]::smallint[]
        and pg_catalog.pg_get_expr(constraint_row.conbin, constraint_row.conrelid) =
          pg_catalog.format('((%1$I IS NULL) OR (%1$I = ANY (ARRAY[%2$s])))', guard.column_name, codes_expression)
    ) then return false; end if;
  end loop;
  return true;
end;
$$;

revoke all on function public.profile_translation_budget_ready()
  from public, anon, authenticated, service_role;
grant execute on function public.profile_translation_budget_ready() to authenticated;

-- Writer provider admission reuses Translation Operations. This private table
-- is an artifact cache, not a queue: scheduling/status/attempts stay in the
-- existing public journal. Unknown dispatches never expire into a new request.
begin;

create table premium_translation_private.writer_operation_artifacts (
  operation_id uuid primary key,
  job_id uuid not null unique references public.translation_jobs(id) on delete restrict deferrable initially deferred,
  item_id uuid not null unique references public.translation_job_items(id) on delete restrict deferrable initially deferred,
  actor_id uuid not null references auth.users(id) on delete restrict,
  entity_id text not null,
  provider text not null check(provider in ('openai','cloudflare')),
  source_hash text not null check(source_hash ~ '^[a-f0-9]{64}$'),
  intent_hash text not null check(intent_hash ~ '^[a-f0-9]{64}$'),
  configuration_hash text not null,
  configuration jsonb not null,
  source_snapshot jsonb not null check(jsonb_typeof(source_snapshot)='object' and octet_length(source_snapshot::text)<=1048576),
  source_revision jsonb not null,
  target_revision jsonb not null,
  expected_override_fields jsonb check(expected_override_fields is null or (jsonb_typeof(expected_override_fields)='object' and octet_length(expected_override_fields::text)<=1048576)),
  confirmed_cursor jsonb not null,
  calls jsonb not null default '[]'::jsonb check(jsonb_typeof(calls)='array' and jsonb_array_length(calls)<=4 and octet_length(calls::text)<=1048576),
  candidate jsonb,
  final_receipt jsonb,
  finish_fingerprint text,
  job_write_proof jsonb not null,
  item_write_proof jsonb not null,
  attempt_write_proof jsonb,
  created_at timestamptz not null default clock_timestamp()
);
alter table premium_translation_private.writer_operation_artifacts enable row level security;
alter table premium_translation_private.writer_operation_artifacts force row level security;
revoke all on premium_translation_private.writer_operation_artifacts from public,anon,authenticated,service_role;

create unique index translation_writer_active_operation_unique
  on public.translation_job_items(entity_type,entity_id)
  where entity_type='writer' and staff_retry is not null;

create function premium_translation_private.writer_operation_configuration_valid(v jsonb,p text)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare k text;
begin
  if not premium_translation_private.exact_object(v,array['version','provider','model','reviewerModel','promptFingerprint',
    'translatorReasoningEffort','translatorReasoningMode','reviewerReasoningEffort','reviewerReasoningMode',
    'schemaName','maxOutputTokens','twoPassReview']) or v->'version' is distinct from '1'::jsonb
    or v->>'provider' is distinct from p or v->>'schemaName' is distinct from 'probpera_writer_biography_translation'
    or v->'maxOutputTokens' is distinct from '4000'::jsonb or v->'twoPassReview' is distinct from 'true'::jsonb
    or jsonb_typeof(v->'promptFingerprint') is distinct from 'string' or v->>'promptFingerprint' !~ '^[a-f0-9]{64}$'
    or octet_length(v::text)>4096 then return false; end if;
  foreach k in array array['model','reviewerModel'] loop
    if jsonb_typeof(v->k) is distinct from 'string' or char_length(v->>k) not between 1 and 200
      or (v->>k) ~ '[[:cntrl:]]' then return false; end if;
  end loop;
  foreach k in array array['translatorReasoningEffort','reviewerReasoningEffort'] loop
    if jsonb_typeof(v->k) is distinct from 'string' or (v->>k) not in ('none','low','medium','high','xhigh','max') then return false; end if;
  end loop;
  foreach k in array array['translatorReasoningMode','reviewerReasoningMode'] loop
    if jsonb_typeof(v->k) is distinct from 'string' or (v->>k) not in ('standard','pro') then return false; end if;
  end loop;
  return true;
end; $$;

create function premium_translation_private.writer_operation_source_valid(s jsonb,r jsonb,t jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare ru jsonb;
begin
  if not premium_translation_private.exact_object(r,array['countryId','writerId','overrideId','overrideUpdatedAt','catalogSourceHash','replaceEnglishTombstone'])
    or not premium_translation_private.valid_revision(t)
    or t is distinct from jsonb_build_object('id',r->'overrideId','updatedAt',r->'overrideUpdatedAt')
    or jsonb_typeof(r->'countryId') is distinct from 'string' or jsonb_typeof(r->'writerId') is distinct from 'string'
    or jsonb_typeof(r->'replaceEnglishTombstone') is distinct from 'boolean'
    or coalesce(r->>'catalogSourceHash','') !~ '^[a-f0-9]{64}$'
    or not premium_translation_private.exact_object(s,array['writerName','text','sourceLanguage','sources','russianProfile','catalogFields'])
    or jsonb_typeof(s->'writerName') is distinct from 'string' or jsonb_typeof(s->'text') is distinct from 'string'
    or jsonb_typeof(s->'sourceLanguage') is distinct from 'string' or jsonb_typeof(s->'russianProfile') is distinct from 'object'
    or jsonb_typeof(s->'catalogFields') is distinct from 'object' or jsonb_typeof(s->'sources') is distinct from 'array'
    or octet_length(s::text)>1048576 then return false; end if;
  perform premium_translation_private.assert_identity('writer_biography',(r->>'countryId')||':'||(r->>'writerId'));
  ru:=s->'russianProfile';
  return coalesce(ru->>'locale'='ru' and ru->>'method'='editorial-original' and ru->>'status' in ('reviewed','verified')
    and jsonb_typeof(ru->'reviewedAt')='string' and ru->>'reviewedAt'<>''
    and jsonb_typeof(ru->'text')='string' and jsonb_typeof(ru->'sourceLanguage')='string'
    and jsonb_typeof(ru->'sources')='array'
    and s->>'text'=premium_translation_private.trim_text(ru->>'text')
    and s->>'sourceLanguage'=premium_translation_private.trim_text(ru->>'sourceLanguage')
    and s->'sources'=premium_translation_private.writer_source_projection(ru->'sources')
    and jsonb_array_length(s->'sources')>0,false);
exception when others then return false;
end; $$;

create function premium_translation_private.writer_operation_progress(c jsonb)
returns jsonb language sql immutable security invoker set search_path='' as $$
  select jsonb_build_object('version',1,'updatedAt',coalesce(nullif(c->(jsonb_array_length(c)-1)->'metadata'->'responseReceivedAt','null'::jsonb),
      c->(jsonb_array_length(c)-1)->'metadata'->'dispatchRecordedAt',to_jsonb('1970-01-01T00:00:00Z'::text)),
    'calls',coalesce(jsonb_agg(value->'metadata' order by n),'[]'::jsonb))
  from jsonb_array_elements(c) with ordinality x(value,n);
$$;

create function premium_translation_private.writer_operation_guard()
returns trigger language plpgsql security definer set search_path='' as $$
declare a premium_translation_private.writer_operation_artifacts%rowtype; identity uuid;
begin
  if tg_table_name='translation_jobs' then
    identity:=case when tg_op='INSERT' then new.id else old.id end;
    select * into a from premium_translation_private.writer_operation_artifacts where job_id=identity;
    if a.operation_id is null then return case when tg_op='DELETE' then old else new end; end if;
    if tg_op='DELETE' then raise exception 'Writer operation journal cannot be deleted' using errcode='42501'; end if;
    if to_jsonb(new)=a.job_write_proof then return new; end if;
    -- Existing cancellation is monotonic. It stops further dispatch, but cannot
    -- erase an admission, change a cursor or turn an unknown response into retry.
    if tg_op='UPDATE' and auth.uid()=a.actor_id and public.is_staff()
      and new.cancel_requested_at is not null and (old.cancel_requested_at is null or new.cancel_requested_at=old.cancel_requested_at)
      and new.status in ('cancelling','cancelled') and new.version=old.version+1
      and (to_jsonb(new)-array['cancel_requested_at','status','version','updated_at','completed_at'])=
          (to_jsonb(old)-array['cancel_requested_at','status','version','updated_at','completed_at']) then return new; end if;
  elsif tg_table_name='translation_job_items' then
    identity:=case when tg_op='INSERT' then new.id else old.id end;
    select * into a from premium_translation_private.writer_operation_artifacts where item_id=identity;
    if a.operation_id is null then
      if (tg_op<>'DELETE' and new.entity_type='writer' and new.staff_retry is not null)
        or (tg_op<>'INSERT' and old.entity_type='writer' and old.staff_retry is not null) then
        raise exception 'Writer operation requires private admission proof' using errcode='42501'; end if;
      return case when tg_op='DELETE' then old else new end;
    end if;
    if tg_op='DELETE' then raise exception 'Writer operation item cannot be deleted' using errcode='42501'; end if;
    if to_jsonb(new)=a.item_write_proof then return new; end if;
  else
    identity:=case when tg_op='INSERT' then new.item_id else old.item_id end;
    select * into a from premium_translation_private.writer_operation_artifacts where item_id=identity;
    if a.operation_id is null then return case when tg_op='DELETE' then old else new end; end if;
    if tg_op='INSERT' and to_jsonb(new)=a.attempt_write_proof then return new; end if;
  end if;
  raise exception 'Writer operation private journal proof differs' using errcode='42501';
end; $$;
create trigger translation_jobs_writer_integrity before insert or update or delete on public.translation_jobs
  for each row execute function premium_translation_private.writer_operation_guard();
create trigger translation_items_writer_integrity before insert or update or delete on public.translation_job_items
  for each row execute function premium_translation_private.writer_operation_guard();
create trigger translation_attempts_writer_integrity before insert or update or delete on public.translation_job_attempts
  for each row execute function premium_translation_private.writer_operation_guard();

create function premium_translation_private.writer_operation_view(a premium_translation_private.writer_operation_artifacts,
  replayed boolean default false, execute_allowed boolean default false, dispatch_allowed boolean default false)
returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare j public.translation_jobs%rowtype; pending text; reason text; phase text:='running';
begin
  select * into j from public.translation_jobs where id=a.job_id;
  select value->'metadata'->>'callId' into pending from jsonb_array_elements(a.calls)
    where value->'metadata'->'responseReceivedAt'='null'::jsonb limit 1;
  if a.final_receipt is not null then
    return a.final_receipt||jsonb_build_object('replayed',replayed,'canExecute',false,'canDispatch',false);
  elsif auth.uid() is distinct from a.actor_id then reason:='operation_owned_by_another_actor';phase:='blocked';
  elsif pending is not null and not dispatch_allowed then reason:='provider_outcome_unknown';phase:='blocked';
  elsif j.cancel_requested_at is not null then reason:='operation_stopped';phase:='blocked'; end if;
  return jsonb_build_object('version',1,'jobId',a.job_id,'itemId',a.item_id,'operationId',a.operation_id,
    'entityId',a.entity_id,'countryId',a.source_revision->'countryId','writerId',a.source_revision->'writerId',
    'actorId',a.actor_id,'provider',a.provider,'sourceHash',a.source_hash,'intentHash',a.intent_hash,
    'configurationHash',a.configuration_hash,'configuration',a.configuration,
    'sourceRevision',a.source_revision,'targetRevision',a.target_revision,'jobVersion',j.version::text,
    'phase',phase,'canExecute',execute_allowed and reason is null,'canDispatch',dispatch_allowed,
    'replayed',replayed,'providerCalls',jsonb_array_length(a.calls),'pendingCallId',pending,'blockReason',reason,
    'resumeCursor',j.resume_cursor-'writerOperation','result',null);
end; $$;

create function public.finish_writer_translation_operation(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_candidate jsonb default null
)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.writer_operation_artifacts%rowtype; j public.translation_jobs%rowtype;
  i public.translation_job_items%rowtype; attempt public.translation_job_attempts%rowtype;
  draft public.premium_translation_working_drafts%rowtype; w public.writer_profile_overrides%rowtype;
  fingerprint text; digest text; status text; code text; state text; persistence text:='none'; result jsonb; receipt jsonb;
  first_call jsonb; last_call jsonb; stamp timestamptz:=clock_timestamp(); current_bound boolean:=true;
begin
  a:=premium_translation_private.writer_operation_owned(p_job_id,p_item_id,p_operation_id);
  if p_outcome is null or jsonb_typeof(p_outcome)<>'object'
    or not(p_outcome ?& array['status','providerCalls'])
    or p_outcome-array['status','providerCalls','errorCode','model','requestId','inputTokens','outputTokens','durationMs']<>'{}'::jsonb
    or coalesce(p_outcome->>'status','') not in ('succeeded','dead_letter','conflict','stale','skipped','not-configured','cancelled')
    or jsonb_typeof(p_outcome->'providerCalls') is distinct from 'number'
    or p_outcome->>'providerCalls' !~ '^[0-4]$'
    or (p_outcome->>'providerCalls')::integer<>jsonb_array_length(a.calls)
    or (p_outcome->>'errorCode' is not null and p_outcome->>'errorCode' not in
      ('translation_not_configured','provider_unavailable','provider_request_failed','provider_invalid_response',
       'source_changed','write_conflict','database_read_failed','database_write_failed','unexpected','translation_operation_stopped')) then
    raise exception 'Invalid writer finish outcome' using errcode='22023'; end if;
  fingerprint:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_outcome,p_candidate));
  if a.final_receipt is not null then
    if a.finish_fingerprint is distinct from fingerprint then raise exception 'Writer finish intent differs' using errcode='40001'; end if;
    return premium_translation_private.writer_operation_view(a,true);
  end if;
  if exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->'responseReceivedAt'='null'::jsonb) then
    raise exception 'Writer provider outcome remains unknown' using errcode='40001'; end if;
  select * into j from public.translation_jobs where id=p_job_id for update;
  select * into i from public.translation_job_items where id=p_item_id for update;
  status:=p_outcome->>'status';code:=p_outcome->>'errorCode';
  if (status='succeeded') is distinct from (p_candidate is not null) then
    raise exception 'Writer completed candidate required only for success' using errcode='22023'; end if;
  if p_candidate is not null then
    if not premium_translation_private.exact_object(p_candidate,array['payload','provenance','translatorCallId','reviewerCallId'])
      or jsonb_array_length(a.calls)<2 or octet_length(p_candidate::text)>32768
      or not exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->>'pass'='review') then
      raise exception 'Writer independent review proof missing' using errcode='22023'; end if;
    first_call:=a.calls->0->'metadata';last_call:=a.calls->(jsonb_array_length(a.calls)-1)->'metadata';
    if p_candidate->>'translatorCallId' is distinct from first_call->>'callId'
      or p_candidate->>'reviewerCallId' is distinct from last_call->>'callId'
      or p_candidate->'provenance'->>'provider' is distinct from a.provider
      or p_candidate->'provenance'->>'translatorModel' is distinct from first_call->>'model'
      or p_candidate->'provenance'->>'reviewerModel' is distinct from last_call->>'model'
      or p_candidate->'provenance'->>'translatorRequestId' is distinct from coalesce(first_call->>'requestId',first_call->>'responseId')
      or p_candidate->'provenance'->>'reviewerRequestId' is distinct from coalesce(last_call->>'requestId',last_call->>'responseId') then
      raise exception 'Writer candidate provider evidence differs' using errcode='40001'; end if;
    perform premium_translation_private.assert_shape('writer_biography',a.source_snapshot,a.source_revision,a.target_revision,
      p_candidate->'payload',p_candidate->'provenance');
    -- Promotion takes draft -> canonical row locks; use the same order.
    perform pg_advisory_xact_lock(hashtextextended('premium-translation:writer_biography:'||a.entity_id,0));
    select * into draft from public.premium_translation_working_drafts where entity_type='writer_biography' and entity_id=a.entity_id for update;
    begin
      perform premium_translation_private.writer_operation_assert_current(a);
    exception when serialization_failure then current_bound:=false; end;
    if not current_bound then
      select * into w from public.writer_profile_overrides where country_id=a.source_revision->>'countryId' and writer_id=a.source_revision->>'writerId';
      if (a.source_snapshot->'catalogFields'||coalesce(w.fields,'{}'::jsonb))->'biographyTranslations'->'ru'
        is distinct from a.source_snapshot->'russianProfile' or (w.id is null and a.target_revision->>'id' is not null) then
        status:='stale';code:='source_changed';
      else status:='conflict';code:='write_conflict'; end if;
    end if;
    digest:=probpera_translation_operations.retry_fingerprint(jsonb_build_object('entityType','writer_biography','entityId',a.entity_id,
      'targetLocale','en','sourceHash',a.source_hash,'sourceSnapshot',a.source_snapshot,'sourceRevision',a.source_revision,
      'targetRevision',a.target_revision,'payload',p_candidate->'payload','provenance',p_candidate->'provenance'));
    -- A fully validated body is retained independently of live CAS/cancel.
    -- Existing pending author/review work is never replaced.
    if draft.id is null then
      insert into public.premium_translation_working_drafts(entity_type,entity_id,source_hash,candidate_hash,source_snapshot,
        source_revision,target_revision,payload,provenance,created_by)
        values('writer_biography',a.entity_id,a.source_hash,digest,a.source_snapshot,a.source_revision,a.target_revision,
          p_candidate->'payload',p_candidate->'provenance',a.actor_id) returning * into draft;
      persistence:='working-draft';
    elsif draft.candidate_hash=digest and draft.source_snapshot=a.source_snapshot and draft.source_revision=a.source_revision
      and draft.target_revision=a.target_revision and draft.payload=p_candidate->'payload' and draft.provenance=p_candidate->'provenance' then
      persistence:='working-draft';
    else
      persistence:='private-artifact';status:='conflict';code:='write_conflict';draft:=null;
    end if;
  end if;
  if j.cancel_requested_at is not null then status:='cancelled';code:=null; end if;
  if status in ('succeeded','skipped','cancelled') then code:=null;
  elsif code is null then code:=case status when 'stale' then 'source_changed' when 'conflict' then 'write_conflict'
    when 'not-configured' then 'translation_not_configured' else 'unexpected' end; end if;
  state:=case status when 'succeeded' then 'translated' when 'dead_letter' then 'failed' else status end;
  result:=jsonb_build_object('state',state,'errorCode',code,'persistence',persistence,
    'draftId',case when persistence='working-draft' then draft.id else null end,
    'draftVersion',case when persistence='working-draft' then draft.version else null end,
    'draftUpdatedAt',case when persistence='working-draft' then draft.created_at else null end,'candidateHash',digest,'publication','unchanged',
    'humanReview',case when p_candidate is null then 'unchanged' else 'pending' end);
  j.status:=case status when 'succeeded' then 'completed' when 'dead_letter' then 'failed' else status end;
  j.succeeded_items:=case when status='succeeded' then 1 else 0 end;j.failed_items:=case when status='dead_letter' then 1 else 0 end;
  j.version:=j.version+1;j.updated_at:=stamp;j.completed_at:=stamp;
  if not(status='skipped' and jsonb_array_length(a.calls)=0) then
    j.resume_cursor:=a.confirmed_cursor||jsonb_build_object('writerOperation',j.resume_cursor->'writerOperation');
  end if;
  receipt:=premium_translation_private.writer_operation_view(a)||jsonb_build_object('phase','finished','blockReason',null,'pendingCallId',null,
    'canExecute',false,'canDispatch',false,'jobVersion',j.version::text,'resumeCursor',j.resume_cursor-'writerOperation','result',result);
  i.status:=case status when 'succeeded' then 'succeeded' when 'cancelled' then 'cancelled' else status end;
  i.attempt_count:=1;i.staff_retry:=null;i.last_error_code:=code;i.updated_at:=stamp;
  attempt:=jsonb_populate_record(null::public.translation_job_attempts,jsonb_build_object(
    'id',nextval('public.translation_job_attempts_id_seq'),'item_id',p_item_id,'attempt_number',1,
    'outcome',case when status='cancelled' then 'skipped' else status end,'provider',a.provider,
    'model',p_outcome->'model','provider_request_id',p_outcome->'requestId','error_code',code,
    'input_tokens',p_outcome->'inputTokens','output_tokens',p_outcome->'outputTokens','duration_ms',p_outcome->'durationMs',
    'created_at',stamp,'staff_retry_operation_id',p_operation_id,'staff_retry_receipt',jsonb_build_object('version',1,
      'actorId',a.actor_id,'intentHash',a.intent_hash,'finishFingerprint',fingerprint,'receipt',receipt,
      'progress',premium_translation_private.writer_operation_progress(a.calls))));
  a.candidate:=p_candidate;a.final_receipt:=receipt;a.finish_fingerprint:=fingerprint;
  a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);a.attempt_write_proof:=to_jsonb(attempt);
  update premium_translation_private.writer_operation_artifacts set candidate=a.candidate,final_receipt=receipt,finish_fingerprint=fingerprint,
    job_write_proof=a.job_write_proof,item_write_proof=a.item_write_proof,attempt_write_proof=a.attempt_write_proof where operation_id=p_operation_id;
  insert into public.translation_job_attempts overriding system value select attempt.*;
  update public.translation_job_items set status=i.status,attempt_count=i.attempt_count,staff_retry=null,last_error_code=code,updated_at=stamp where id=p_item_id;
  update public.translation_jobs set status=j.status,succeeded_items=j.succeeded_items,failed_items=j.failed_items,version=j.version,
    updated_at=stamp,completed_at=stamp,resume_cursor=j.resume_cursor where id=p_job_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.writer_operation.finished','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'state',state,'persistence',persistence,'candidateHash',digest));
  return receipt;
end; $$;

create function public.reconcile_writer_translation_operation(p_country_id text,p_writer_id text,p_operation_id uuid default null)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.writer_operation_artifacts%rowtype; entity text:=p_country_id||':'||p_writer_id;
begin
  perform premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity('writer_biography',entity);
  perform pg_advisory_xact_lock(hashtextextended('writer-operation:'||entity,7191));
  select cache.* into a from premium_translation_private.writer_operation_artifacts cache
    join public.translation_job_items item on item.id=cache.item_id where cache.entity_id=entity
      and (p_operation_id is null or cache.operation_id=p_operation_id)
    order by (item.staff_retry is not null) desc,cache.created_at desc,cache.operation_id desc limit 1;
  if a.operation_id is null then return null; end if;
  return premium_translation_private.writer_operation_view(a,true);
end; $$;

create function public.get_writer_translation_operation_artifacts(p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_intent_hash text,p_source_hash text)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.writer_operation_artifacts%rowtype;
begin
  a:=premium_translation_private.writer_operation_owned(p_job_id,p_item_id,p_operation_id);
  if p_intent_hash is distinct from a.intent_hash or p_source_hash is distinct from a.source_hash then
    raise exception 'Writer private artifact binding differs' using errcode='40001'; end if;
  return jsonb_build_object('version',1,'receipt',premium_translation_private.writer_operation_view(a,true),
    'sourceSnapshot',a.source_snapshot,'sourceRevision',a.source_revision,'targetRevision',a.target_revision,
    'expectedOverrideFields',a.expected_override_fields,'configuration',a.configuration,'calls',a.calls,'candidate',a.candidate);
end; $$;



create function premium_translation_private.writer_operation_owned(p_job uuid,p_item uuid,p_operation uuid)
returns premium_translation_private.writer_operation_artifacts language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.writer_operation_artifacts%rowtype;
begin
  perform premium_translation_private.assert_actor();
  select * into a from premium_translation_private.writer_operation_artifacts where operation_id=p_operation for update;
  if a.operation_id is null then raise exception 'Writer operation not found' using errcode='P0002'; end if;
  if a.actor_id is distinct from auth.uid() then raise exception 'Writer operation actor differs' using errcode='42501'; end if;
  if a.job_id is distinct from p_job or a.item_id is distinct from p_item then
    raise exception 'Writer operation identity differs' using errcode='40001'; end if;
  return a;
end; $$;

create function premium_translation_private.writer_operation_assert_current(a premium_translation_private.writer_operation_artifacts)
returns void language plpgsql security invoker set search_path='' as $$
declare w public.writer_profile_overrides%rowtype;
begin
  select * into w from public.writer_profile_overrides where country_id=a.source_revision->>'countryId'
    and writer_id=a.source_revision->>'writerId';
  if (w.id is null) is distinct from (a.expected_override_fields is null)
    or (w.id is not null and w.fields is distinct from a.expected_override_fields) then
    raise exception 'Writer full override changed' using errcode='40001'; end if;
  perform premium_translation_private.assert_writer_current(a.entity_id,a.source_snapshot,a.source_revision,a.target_revision);
end; $$;

create function public.writer_translation_operation_ready()
returns boolean language plpgsql stable security definer set search_path='' as $$
declare signature text; routine regprocedure;
begin
  perform premium_translation_private.assert_actor();
  foreach signature in array array[
    'public.begin_writer_translation_operation(uuid,uuid,uuid,text,text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb)',
    'public.record_writer_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text)',
    'public.record_writer_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb)',
    'public.finish_writer_translation_operation(uuid,uuid,uuid,jsonb,jsonb)',
    'public.reconcile_writer_translation_operation(text,text,uuid)',
    'public.get_writer_translation_operation_artifacts(uuid,uuid,uuid,text,text)'] loop
    routine:=to_regprocedure(signature);
    if routine is null or not has_function_privilege('authenticated',routine,'EXECUTE') then return false; end if;
  end loop;
  return to_regclass('premium_translation_private.writer_operation_artifacts') is not null
    and exists(select 1 from pg_index where indexrelid=to_regclass('public.translation_writer_active_operation_unique')
      and indisunique and indisvalid and indpred is not null)
    and (select count(*)=3 from pg_trigger where not tgisinternal and tgenabled='O'
      and tgfoid=to_regprocedure('premium_translation_private.writer_operation_guard()') and tgname in
      ('translation_jobs_writer_integrity','translation_items_writer_integrity','translation_attempts_writer_integrity'));
end; $$;

create function public.begin_writer_translation_operation(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_country_id text,p_writer_id text,p_provider text,
  p_source_hash text,p_source_snapshot jsonb,p_source_revision jsonb,p_target_revision jsonb,
  p_expected_override_fields jsonb,p_configuration jsonb,p_current_cursor jsonb default '{}'::jsonb,p_resume_cursor jsonb default '{}'::jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare actor uuid:=premium_translation_private.assert_actor(); a premium_translation_private.writer_operation_artifacts%rowtype;
  j public.translation_jobs%rowtype; i public.translation_job_items%rowtype; entity text; intent text;
  stamp timestamptz:=clock_timestamp(); marker jsonb; view jsonb;
begin
  entity:=p_country_id||':'||p_writer_id;
  perform premium_translation_private.assert_identity('writer_biography',entity);
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id) or p_provider is null or p_provider not in ('openai','cloudflare')
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$'
    or not premium_translation_private.writer_operation_source_valid(p_source_snapshot,p_source_revision,p_target_revision)
    or p_source_revision->>'countryId' is distinct from p_country_id or p_source_revision->>'writerId' is distinct from p_writer_id
    or not premium_translation_private.writer_operation_configuration_valid(p_configuration,p_provider)
    or ((p_target_revision->>'id' is null) is distinct from (p_expected_override_fields is null))
    or (p_expected_override_fields is not null and (jsonb_typeof(p_expected_override_fields)<>'object' or octet_length(p_expected_override_fields::text)>1048576))
    or p_current_cursor is null or jsonb_typeof(p_current_cursor)<>'object' or p_current_cursor-'writerCursor'<>'{}'::jsonb
    or (p_current_cursor ? 'writerCursor' and (jsonb_typeof(p_current_cursor->'writerCursor')<>'number' or (p_current_cursor->>'writerCursor') !~ '^[0-9]{1,9}$'))
    or p_resume_cursor is null or jsonb_typeof(p_resume_cursor)<>'object' or p_resume_cursor-'writerCursor'<>'{}'::jsonb
    or (p_resume_cursor ? 'writerCursor' and (jsonb_typeof(p_resume_cursor->'writerCursor')<>'number' or (p_resume_cursor->>'writerCursor') !~ '^[0-9]{1,9}$')) then
    raise exception 'Invalid writer operation admission' using errcode='22023'; end if;
  intent:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_job_id,p_item_id,p_operation_id,actor,
    entity,p_provider,p_source_hash,p_source_snapshot,p_source_revision,p_target_revision,p_expected_override_fields,p_configuration,p_current_cursor,p_resume_cursor));
  perform pg_advisory_xact_lock(hashtextextended('writer-operation:'||entity,7191));
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7192));
  select * into a from premium_translation_private.writer_operation_artifacts where operation_id=p_operation_id for update;
  if a.operation_id is not null then
    if a.actor_id is distinct from actor then raise exception 'Writer operation actor differs' using errcode='42501'; end if;
    if a.intent_hash is distinct from intent then raise exception 'Writer operation intent differs' using errcode='40001'; end if;
    return premium_translation_private.writer_operation_view(a,true);
  end if;
  select cache.* into a from premium_translation_private.writer_operation_artifacts cache
    join public.translation_job_items item on item.id=cache.item_id
    where cache.entity_id=entity and item.entity_type='writer' and item.staff_retry is not null for update of cache;
  if a.operation_id is not null then
    view:=premium_translation_private.writer_operation_view(a,true);
    return view||jsonb_build_object('phase','blocked','blockReason',coalesce(view->>'blockReason','operation_in_progress'));
  end if;
  if exists(select 1 from public.translation_jobs where id=p_job_id)
    or exists(select 1 from public.translation_job_items where id=p_item_id)
    or exists(select 1 from public.premium_translation_working_drafts where entity_type='writer_biography' and entity_id=entity) then
    raise exception 'Writer job identity or private candidate already exists' using errcode='40001'; end if;
  a.operation_id:=p_operation_id;a.job_id:=p_job_id;a.item_id:=p_item_id;a.actor_id:=actor;a.entity_id:=entity;
  a.provider:=p_provider;a.source_hash:=p_source_hash;a.intent_hash:=intent;
  a.configuration:=p_configuration;a.configuration_hash:=probpera_translation_operations.retry_fingerprint(p_configuration);
  a.source_snapshot:=p_source_snapshot;a.source_revision:=p_source_revision;a.target_revision:=p_target_revision;
  a.expected_override_fields:=p_expected_override_fields;a.confirmed_cursor:=p_resume_cursor;a.calls:='[]';a.created_at:=stamp;
  perform premium_translation_private.writer_operation_assert_current(a);
  marker:=jsonb_build_object('version',1,'protocol','writer-biography','operationId',p_operation_id,'actorId',actor,
    'entityId',entity,'sourceHash',p_source_hash,'intentHash',intent,'configurationHash',a.configuration_hash,
    'startedAt',stamp,'attemptNumber',1,'progress',jsonb_build_object('version',1,'updatedAt',stamp,'calls','[]'::jsonb));
  j:=jsonb_populate_record(null::public.translation_jobs,jsonb_build_object('id',p_job_id,'kind','writer','source_locale','ru',
    'target_locale','en','provider',p_provider,'status','reviewing','total_items',1,'succeeded_items',0,'failed_items',0,
    'requested_by',actor,'started_at',stamp,'version',1,'created_at',stamp,'updated_at',stamp,
    'resume_cursor',p_current_cursor||jsonb_build_object('writerOperation',jsonb_build_object('version',1,'operationId',p_operation_id,'actorId',actor,'intentHash',intent))));
  i:=jsonb_populate_record(null::public.translation_job_items,jsonb_build_object('id',p_item_id,'job_id',p_job_id,'position',0,
    'entity_type','writer','entity_id',entity,'source_hash',p_source_hash,'status','reviewing','attempt_count',0,'max_attempts',3,
    'next_attempt_at',stamp,'created_at',stamp,'updated_at',stamp,'staff_retry',marker));
  a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);
  insert into premium_translation_private.writer_operation_artifacts select a.*;
  insert into public.translation_jobs select j.*;
  insert into public.translation_job_items select i.*;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'translation.writer_operation.admitted','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'entityId',entity,'sourceHash',p_source_hash,'configurationHash',a.configuration_hash));
  return premium_translation_private.writer_operation_view(a,false,true);
end; $$;

create function public.record_writer_translation_operation_dispatch(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_call_id uuid,p_provider text,p_model text,p_pass text,p_request_hash text
)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.writer_operation_artifacts%rowtype; j public.translation_jobs%rowtype;
  i public.translation_job_items%rowtype; call jsonb; metadata jsonb; progress jsonb; stamp timestamptz:=clock_timestamp();
begin
  a:=premium_translation_private.writer_operation_owned(p_job_id,p_item_id,p_operation_id);
  if not probpera_translation_operations.retry_uuid(p_call_id) or p_provider is distinct from a.provider
    or p_model is null or p_pass is null or p_pass not in ('translation','repair','review')
    or p_request_hash is null or p_request_hash !~ '^[a-f0-9]{64}$'
    or p_model is distinct from a.configuration->>(case when p_pass='translation' then 'model' else 'reviewerModel' end) then
    raise exception 'Invalid writer dispatch binding' using errcode='22023'; end if;
  for call in select value from jsonb_array_elements(a.calls) loop
    if call->'metadata'->>'callId'=p_call_id::text then
      if call->>'requestHash' is distinct from p_request_hash or call->'metadata'->>'pass' is distinct from p_pass
        or call->'metadata'->>'model' is distinct from p_model then raise exception 'Writer dispatch intent differs' using errcode='40001'; end if;
      return premium_translation_private.writer_operation_view(a,true);
    end if;
  end loop;
  select * into j from public.translation_jobs where id=p_job_id for update;
  if a.final_receipt is not null or j.cancel_requested_at is not null or j.status<>'reviewing'
    or jsonb_array_length(a.calls)>=4 or exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->'responseReceivedAt'='null'::jsonb) then
    raise exception 'Writer dispatch is blocked or outcome unknown' using errcode='40001'; end if;
  perform premium_translation_private.writer_operation_assert_current(a);
  metadata:=jsonb_build_object('callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,
    'dispatchRecordedAt',stamp,'responseReceivedAt',null,'httpStatus',null,'requestId',null,'responseId',null,'inputTokens',null,'outputTokens',null);
  a.calls:=a.calls||jsonb_build_array(jsonb_build_object('requestHash',p_request_hash,'metadata',metadata,'responseArtifact',null));
  progress:=premium_translation_private.writer_operation_progress(a.calls);
  if not probpera_translation_operations.retry_journal_valid(progress,a.provider) then
    raise exception 'Writer dispatch sequence differs' using errcode='40001'; end if;
  select * into i from public.translation_job_items where id=p_item_id for update;
  i.staff_retry:=i.staff_retry||jsonb_build_object('progress',progress);i.updated_at:=stamp;
  a.item_write_proof:=to_jsonb(i);
  update premium_translation_private.writer_operation_artifacts set calls=a.calls,item_write_proof=a.item_write_proof where operation_id=p_operation_id;
  update public.translation_job_items set staff_retry=i.staff_retry,updated_at=i.updated_at where id=p_item_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.writer_operation.dispatch_recorded','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,'requestHash',p_request_hash));
  return premium_translation_private.writer_operation_view(a,false,false,true);
end; $$;

create function public.record_writer_translation_operation_response(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_metadata jsonb,p_response_artifact jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.writer_operation_artifacts%rowtype; i public.translation_job_items%rowtype;
  call jsonb; position integer; progress jsonb; stamp timestamptz:=clock_timestamp();
begin
  a:=premium_translation_private.writer_operation_owned(p_job_id,p_item_id,p_operation_id);
  if not premium_translation_private.exact_object(p_metadata,array['callId','provider','model','pass','httpStatus','requestId','responseId','inputTokens','outputTokens'])
    or not premium_translation_private.exact_object(p_response_artifact,array['version','body'])
    or p_response_artifact->'version' is distinct from '1'::jsonb or octet_length(p_response_artifact::text)>262144 then
    raise exception 'Invalid writer response artifact' using errcode='22023'; end if;
  select value,(n-1)::integer into call,position from jsonb_array_elements(a.calls) with ordinality x(value,n)
    where value->'metadata'->>'callId'=p_metadata->>'callId';
  if position is null then raise exception 'Writer response dispatch not found' using errcode='40001'; end if;
  if call->'metadata'->>'provider' is distinct from p_metadata->>'provider'
    or call->'metadata'->>'model' is distinct from p_metadata->>'model' or call->'metadata'->>'pass' is distinct from p_metadata->>'pass' then
    raise exception 'Writer response identity differs' using errcode='40001'; end if;
  if call->'metadata'->'responseReceivedAt'<>'null'::jsonb then
    if (call->'metadata')-array['dispatchRecordedAt','responseReceivedAt'] is distinct from p_metadata
      or call->'responseArtifact' is distinct from p_response_artifact then raise exception 'Writer response evidence differs' using errcode='40001'; end if;
    return premium_translation_private.writer_operation_view(a,true);
  end if;
  if a.final_receipt is not null then raise exception 'Writer operation already finished' using errcode='40001'; end if;
  call:=call||jsonb_build_object('metadata',p_metadata||jsonb_build_object('dispatchRecordedAt',call->'metadata'->'dispatchRecordedAt','responseReceivedAt',stamp),
    'responseArtifact',p_response_artifact);
  a.calls:=jsonb_set(a.calls,array[position::text],call);
  progress:=premium_translation_private.writer_operation_progress(a.calls);
  if not probpera_translation_operations.retry_journal_valid(progress,a.provider) then
    raise exception 'Writer response metadata differs' using errcode='22023'; end if;
  select * into i from public.translation_job_items where id=p_item_id for update;
  i.staff_retry:=i.staff_retry||jsonb_build_object('progress',progress);i.updated_at:=stamp;a.item_write_proof:=to_jsonb(i);
  update premium_translation_private.writer_operation_artifacts set calls=a.calls,item_write_proof=a.item_write_proof where operation_id=p_operation_id;
  update public.translation_job_items set staff_retry=i.staff_retry,updated_at=i.updated_at where id=p_item_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.writer_operation.response_received','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'callId',p_metadata->'callId','responseHash',probpera_translation_operations.retry_fingerprint(p_response_artifact)));
  return premium_translation_private.writer_operation_view(a);
end; $$;

revoke all on function premium_translation_private.writer_operation_configuration_valid(jsonb,text) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.writer_operation_source_valid(jsonb,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.writer_operation_progress(jsonb) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.writer_operation_guard() from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.writer_operation_view(premium_translation_private.writer_operation_artifacts,boolean,boolean,boolean) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.writer_operation_owned(uuid,uuid,uuid) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.writer_operation_assert_current(premium_translation_private.writer_operation_artifacts) from public,anon,authenticated,service_role;
revoke all on function public.writer_translation_operation_ready() from public,anon,authenticated,service_role;
revoke all on function public.begin_writer_translation_operation(uuid,uuid,uuid,text,text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.record_writer_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text) from public,anon,authenticated,service_role;
revoke all on function public.record_writer_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.finish_writer_translation_operation(uuid,uuid,uuid,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.reconcile_writer_translation_operation(text,text,uuid) from public,anon,authenticated,service_role;
revoke all on function public.get_writer_translation_operation_artifacts(uuid,uuid,uuid,text,text) from public,anon,authenticated,service_role;
grant execute on function public.writer_translation_operation_ready() to authenticated;
grant execute on function public.begin_writer_translation_operation(uuid,uuid,uuid,text,text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb) to authenticated;
grant execute on function public.record_writer_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text) to authenticated;
grant execute on function public.record_writer_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb) to authenticated;
grant execute on function public.finish_writer_translation_operation(uuid,uuid,uuid,jsonb,jsonb) to authenticated;
grant execute on function public.reconcile_writer_translation_operation(text,text,uuid) to authenticated;
grant execute on function public.get_writer_translation_operation_artifacts(uuid,uuid,uuid,text,text) to authenticated;
commit;

-- Isolated PG17 fixture only. Synthetic Auth/canonical fixtures precede the
-- unchanged Translation Operations/article/private SQL and the new migration.
reset role;
create table public.writer_operation_fixture_results(label text primary key,value jsonb not null);
alter table public.writer_operation_fixture_results enable row level security;
create policy writer_operation_fixture_staff on public.writer_operation_fixture_results for all to authenticated
  using(public.is_staff()) with check(public.is_staff());
grant select,insert,update on public.writer_operation_fixture_results to authenticated;
create function public.writer_operation_fixture_config()
returns jsonb language sql immutable set search_path='' as $$ select jsonb_build_object('version',1,'provider','cloudflare','model','fixture-translator',
  'reviewerModel','fixture-reviewer','twoPassReview',true,'translatorReasoningEffort','none','translatorReasoningMode','standard',
  'reviewerReasoningEffort','none','reviewerReasoningMode','standard','promptFingerprint',repeat('d',64),
  'schemaName','probpera_writer_biography_translation','maxOutputTokens',4000); $$;
create function public.writer_operation_fixture_begin(writer text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare args jsonb:=public.writer_private_fixture_args('operation-country:'||writer); fields jsonb;
begin
 select w.fields into fields from public.writer_profile_overrides w where country_id='operation-country' and writer_id=writer;
 return public.begin_writer_translation_operation(gen_random_uuid(),gen_random_uuid(),gen_random_uuid(),'operation-country',writer,'cloudflare',
   args->>'sourceHash',args->'source',args->'sourceRevision',args->'targetRevision',fields,public.writer_operation_fixture_config(),'{"writerCursor":6}','{"writerCursor":7}');
end; $$;
create function public.writer_operation_fixture_dispatch(r jsonb,pass text)
returns jsonb language plpgsql set search_path='' as $$ begin
 return public.record_writer_translation_operation_dispatch((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,
  gen_random_uuid(),'cloudflare',case when pass='translation' then 'fixture-translator' else 'fixture-reviewer' end,pass,repeat('e',64));
end; $$;
create function public.writer_operation_fixture_response(r jsonb)
returns jsonb language sql set search_path='' as $$ select public.record_writer_translation_operation_response((r->>'jobId')::uuid,(r->>'itemId')::uuid,
 (r->>'operationId')::uuid,jsonb_build_object('callId',r->'pendingCallId','provider','cloudflare',
 'model',case when r->>'providerCalls'='1' then 'fixture-translator' else 'fixture-reviewer' end,
 'pass',case when r->>'providerCalls'='1' then 'translation' else 'review' end,
 'httpStatus',null,'requestId',null,'responseId',null,'inputTokens',5,'outputTokens',6),
 jsonb_build_object('version',1,'body',jsonb_build_object('response',jsonb_build_object('text','Ivan Author was born in 1900 and worked at the Archive, where he studied surviving manuscripts. He wrote a novel in 1930 and also taught literature during his scholarly career.')))); $$;
create function public.writer_operation_fixture_finish(r jsonb)
returns jsonb language plpgsql set search_path='' as $$ declare a jsonb; args jsonb; candidate jsonb; begin
 a:=public.get_writer_translation_operation_artifacts((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,r->>'intentHash',r->>'sourceHash');
 args:=public.writer_private_fixture_args(r->>'entityId');
 candidate:=jsonb_build_object('payload',args->'payload','provenance',(args->'provenance')||'{"translatorRequestId":null,"reviewerRequestId":null}'::jsonb,
   'translatorCallId',a->'calls'->0->'metadata'->'callId','reviewerCallId',a->'calls'->1->'metadata'->'callId');
 return public.finish_writer_translation_operation((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,
   '{"status":"succeeded","providerCalls":2,"model":"fixture-translator"}',candidate);
end; $$;
set role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);
do $$ declare r jsonb; d jsonb; replay jsonb; a jsonb; begin
 assert public.writer_translation_operation_ready() is true;
 r:=public.writer_operation_fixture_begin('unknown-writer');assert r->'canExecute'='true'::jsonb;
 d:=public.writer_operation_fixture_dispatch(r,'translation');assert d->'canDispatch'='true'::jsonb;
 replay:=public.writer_operation_fixture_begin('unknown-writer');
 assert replay->>'operationId'=r->>'operationId' and replay->'canExecute'='false'::jsonb and replay->>'blockReason'='provider_outcome_unknown';
 assert replay->'resumeCursor'='{"writerCursor":6}'::jsonb;
 perform public.premium_fixture_error(format('select public.finish_writer_translation_operation(%L,%L,%L,%L::jsonb)',
  r->>'jobId',r->>'itemId',r->>'operationId','{"status":"dead_letter","providerCalls":1,"errorCode":"provider_request_failed"}'),'40001');
 a:=public.get_writer_translation_operation_artifacts((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,r->>'intentHash',r->>'sourceHash');
 assert a->'candidate'='null'::jsonb and a->'calls'->0->'metadata'->'responseReceivedAt'='null'::jsonb;
 insert into public.writer_operation_fixture_results values('unknown-admission',replay);
 r:=public.writer_operation_fixture_begin('complete-writer');
 r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'translation'));
 a:=public.get_writer_translation_operation_artifacts((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,r->>'intentHash',r->>'sourceHash');
 assert a->'candidate'='null'::jsonb and a->'calls'->0->'metadata'->'responseReceivedAt'<>'null'::jsonb;
 r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'review'));
 d:=public.writer_operation_fixture_finish(r);
 assert d->>'phase'='finished' and d->'result'->>'state'='translated' and d->'result'->>'persistence'='working-draft';
 assert d->'resumeCursor'='{"writerCursor":7}'::jsonb;
 replay:=public.writer_operation_fixture_finish(r);assert replay->'replayed'='true'::jsonb and replay->'canDispatch'='false'::jsonb;
 assert replay->'result'=d->'result';
 assert public.reconcile_writer_translation_operation('operation-country','complete-writer',(d->>'operationId')::uuid)->'result'=d->'result';
 insert into public.writer_operation_fixture_results values('complete-receipt-recovery',d);
end; $$;
reset role;
select 'M07_WRITER_OPERATIONS_INITIAL_PASS';

-- Authenticated has read-only journal ACL; private artifacts have no direct
-- staff/service table grants. A different staff actor can discover the barrier
-- but cannot replay a paid operation or read its raw private cache.
set role anon;
select public.premium_fixture_error('select public.writer_translation_operation_ready()','42501');
reset role;
set role authenticated;
select set_config('request.jwt.claim.sub','',false);
select public.premium_fixture_error('select public.writer_translation_operation_ready()','42501');
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',false);
select public.premium_fixture_error('select public.writer_translation_operation_ready()','42501');
select set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',false);
do $$ declare r jsonb; newer jsonb; begin
 r:=public.reconcile_writer_translation_operation('operation-country','unknown-writer');
 assert r->>'blockReason'='operation_owned_by_another_actor';
 newer:=public.writer_operation_fixture_begin('unknown-writer');assert newer->>'operationId'=r->>'operationId' and newer->'canExecute'='false'::jsonb;
 perform public.premium_fixture_error(format('select public.get_writer_translation_operation_artifacts(%L,%L,%L,%L,%L)',
   r->>'jobId',r->>'itemId',r->>'operationId',r->>'intentHash',r->>'sourceHash'),'42501');
end; $$;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);
select public.premium_fixture_error('update public.translation_job_items set staff_retry=null','42501');
select public.premium_fixture_error('delete from public.translation_jobs','42501');
select public.premium_fixture_error('select * from premium_translation_private.writer_operation_artifacts','42501');
reset role;
set role service_role;
select public.premium_fixture_error($q$update public.translation_job_items set staff_retry=null where entity_id='operation-country:unknown-writer'$q$,'42501');
select public.premium_fixture_error($q$update public.translation_job_items set entity_id='operation-country:tampered' where entity_id='operation-country:unknown-writer'$q$,'42501');
select public.premium_fixture_error($q$update public.translation_job_items set id=gen_random_uuid() where entity_id='operation-country:unknown-writer'$q$,'42501');
select public.premium_fixture_error($q$update public.translation_job_items set staff_retry=jsonb_set(staff_retry,'{progress,calls,0,responseReceivedAt}','"2026-10-29T20:00:00Z"') where entity_id='operation-country:unknown-writer'$q$,'42501');
select public.premium_fixture_error($q$delete from public.translation_jobs where resume_cursor->'writerOperation'->>'operationId' is not null$q$,'42501');
select public.premium_fixture_error('select * from premium_translation_private.writer_operation_artifacts','42501');
reset role;
insert into public.writer_operation_fixture_results values('auth-and-direct-tamper','true');

-- Exact replay bindings, response retention, zero-dispatch reconciliation,
-- stopped unknown admissions, and no repeated call after acknowledged output.
set role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);
do $$ declare r jsonb; d jsonb; replay jsonb; call jsonb; a jsonb; begin
 r:=public.writer_operation_fixture_begin('ack-writer');d:=public.writer_operation_fixture_dispatch(r,'translation');
 replay:=public.record_writer_translation_operation_dispatch((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,
   (d->>'pendingCallId')::uuid,'cloudflare','fixture-translator','translation',repeat('e',64));
 assert replay->'replayed'='true'::jsonb and replay->'canDispatch'='false'::jsonb;
 replay:=public.writer_operation_fixture_response(d);assert replay->>'phase'='running';
 replay:=public.writer_operation_fixture_response(d);assert replay->'replayed'='true'::jsonb;
 a:=public.get_writer_translation_operation_artifacts((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,r->>'intentHash',r->>'sourceHash');
 assert jsonb_array_length(a->'calls')=1 and a->'candidate'='null'::jsonb;
 call:=a->'calls'->0;
 perform public.premium_fixture_error(format('select public.record_writer_translation_operation_response(%L,%L,%L,%L::jsonb,%L::jsonb)',
   r->>'jobId',r->>'itemId',r->>'operationId',((call->'metadata')-array['dispatchRecordedAt','responseReceivedAt'])::text,'{"version":1,"body":"changed"}'),'40001');
 perform public.premium_fixture_error(format('select public.get_writer_translation_operation_artifacts(%L,%L,%L,%L,%L)',
   r->>'jobId',r->>'itemId',r->>'operationId',repeat('f',64),r->>'sourceHash'),'40001');
 r:=public.writer_operation_fixture_begin('zero-writer');
 replay:=public.finish_writer_translation_operation((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,'{"status":"skipped","providerCalls":0}');
 assert replay->>'phase'='finished' and replay->'resumeCursor'='{"writerCursor":6}'::jsonb;
 perform public.premium_fixture_error(format('select public.writer_operation_fixture_dispatch(%L::jsonb,''translation'')',r::text),'40001');
 r:=public.reconcile_writer_translation_operation('operation-country','unknown-writer');
 perform public.request_translation_job_cancel((r->>'jobId')::uuid,(r->>'jobVersion')::bigint);
 replay:=public.writer_operation_fixture_begin('unknown-writer');assert replay->>'blockReason'='provider_outcome_unknown';
 assert replay->'resumeCursor'='{"writerCursor":6}'::jsonb and replay->'providerCalls'='1'::jsonb;
 insert into public.writer_operation_fixture_results values('ack-replay-and-cancel',replay);
end; $$;
reset role;

-- Completed paid bodies survive RU/source, manual-EN and rights drift without
-- overwriting any canonical byte. Stale candidates remain unpromotable under
-- the pre-existing explicit-review/current-CAS contract.
insert into public.writer_profile_overrides(country_id,writer_id,fields,updated_at)
 select 'operation-country',name,public.writer_private_fixture_catalog(),'2026-10-01T10:00:00Z' from unnest(array['stale-writer','manual-writer','rights-writer']) name;
do $$ declare name text; r jsonb; done jsonb; before_row jsonb; before_outbox bigint; before_revision bigint; draft jsonb; begin
 for name in select unnest(array['stale-writer','manual-writer','rights-writer']) loop
  set local role authenticated;perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  r:=public.writer_operation_fixture_begin(name);
  r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'translation'));
  r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'review'));
  reset role;
  update public.writer_profile_overrides set fields=case name
    when 'stale-writer' then jsonb_set(fields,'{biographyTranslations,ru,text}','"AUTHOR CHANGED RU source while provider was running"')
    when 'manual-writer' then jsonb_set(fields,'{biographyTranslations,en,method}','"human-translation"')
    else jsonb_set(fields,'{rights}','{"owner":"NEW AUTHOR RIGHTS"}') end where country_id='operation-country' and writer_id=name;
  select to_jsonb(w) into before_row from public.writer_profile_overrides w where country_id='operation-country' and writer_id=name;
  select count(*) into before_outbox from public.premium_fixture_outbox;
  select count(*) into before_revision from public.writer_profile_override_revisions;
  set local role authenticated;
  done:=public.writer_operation_fixture_finish(r);
  assert done->'result'->>'persistence'='working-draft' and done->'result'->>'humanReview'='pending';
  assert done->'result'->>'state'=case when name='stale-writer' then 'stale' else 'conflict' end;
  draft:=public.get_premium_translation_working_draft('writer_biography','operation-country:'||name)->'draft';
  perform public.premium_fixture_error(format('select public.writer_private_fixture_promote(%L::jsonb)',draft::text),'40001');
  reset role;
  assert (select to_jsonb(w)=before_row from public.writer_profile_overrides w where country_id='operation-country' and writer_id=name);
  assert (select count(*)=before_outbox from public.premium_fixture_outbox);
  assert (select count(*)=before_revision from public.writer_profile_override_revisions);
  insert into public.writer_operation_fixture_results values(name,done);
 end loop;
end; $$;

set role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);
do $$ declare r jsonb; done jsonb; prior jsonb; args jsonb; a jsonb; begin
 r:=public.writer_operation_fixture_begin('slot-writer');
 r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'translation'));
 r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'review'));
 args:=public.writer_private_fixture_args('operation-country:slot-writer');
 prior:=public.premium_fixture_stage(args)->'draft';
 done:=public.writer_operation_fixture_finish(r);
 assert done->'result'->>'state'='conflict' and done->'result'->>'persistence'='private-artifact';
 assert done->'result'->'draftId'='null'::jsonb and done->'result'->'draftVersion'='null'::jsonb and done->'result'->'draftUpdatedAt'='null'::jsonb;
 assert public.get_premium_translation_working_draft('writer_biography','operation-country:slot-writer')->'draft'=prior;
 a:=public.get_writer_translation_operation_artifacts((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,r->>'intentHash',r->>'sourceHash');
 assert jsonb_typeof(a->'candidate')='object' and jsonb_array_length(a->'calls')=2;
 insert into public.writer_operation_fixture_results values('pending-slot-takeover',done);
end; $$;
reset role;
do $$ declare r jsonb; begin
 assert (select count(*)=1 from public.translation_job_attempts where item_id=(select item_id from premium_translation_private.writer_operation_artifacts where entity_id='operation-country:complete-writer'));
 assert not exists(select 1 from public.translation_job_items where staff_retry::text like '%Ivan Author%' or staff_retry::text like '%RAW RU RIGHTS%');
 assert not exists(select 1 from public.translation_job_attempts where staff_retry_receipt::text like '%Ivan Author%' or staff_retry_receipt::text like '%RAW RU RIGHTS%');
 assert not exists(select 1 from public.admin_audit_log where action like 'translation.writer_operation.%' and (metadata::text like '%Ivan Author%' or metadata::text like '%RAW RU RIGHTS%'));
 assert not has_function_privilege('authenticated','public.claim_translation_job_items(text,integer,integer)','EXECUTE');
 assert not has_function_privilege('authenticated','public.complete_translation_job_item(uuid,text,boolean,text,text,text,integer,integer,integer)','EXECUTE');
 insert into public.writer_operation_fixture_results values('metadata-privacy-and-one-attempt','true');
end; $$;
select 'M07_WRITER_OPERATIONS_FULL_PASS';

-- Metadata readiness checks the actual RPC and enabled integrity guard, not
-- merely the existence of a table. These alterations are fixture-local only.
do $$ begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 alter table public.translation_job_items disable trigger translation_items_writer_integrity;
 assert public.writer_translation_operation_ready() is false;
 alter table public.translation_job_items enable trigger translation_items_writer_integrity;
 alter function public.reconcile_writer_translation_operation(text,text,uuid) rename to writer_fixture_missing_reconcile;
 assert public.writer_translation_operation_ready() is false;
 alter function public.writer_fixture_missing_reconcile(text,text,uuid) rename to reconcile_writer_translation_operation;
 revoke execute on function public.get_writer_translation_operation_artifacts(uuid,uuid,uuid,text,text) from authenticated;
 assert public.writer_translation_operation_ready() is false;
 grant execute on function public.get_writer_translation_operation_artifacts(uuid,uuid,uuid,text,text) to authenticated;
 assert public.writer_translation_operation_ready() is true;
 insert into public.writer_operation_fixture_results values('readiness-current-missing-disabled-acl','true');
end; $$;
set role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',false);
do $$ declare args jsonb; config jsonb; r jsonb; done jsonb; a jsonb; begin
 -- A different source/configuration/provider and a fresh UUID cannot bypass a
 -- prior unresolved request for the same canonical writer identity.
 args:=public.writer_private_fixture_args('operation-country:unknown-writer');
 config:=public.writer_operation_fixture_config()||'{"provider":"openai","model":"changed-translator"}';
 r:=public.begin_writer_translation_operation(gen_random_uuid(),gen_random_uuid(),gen_random_uuid(),'operation-country','unknown-writer','openai',
   repeat('f',64),args->'source',jsonb_set(args->'sourceRevision','{catalogSourceHash}',to_jsonb(repeat('f',64))),args->'targetRevision',null,config,'{"writerCursor":90}','{"writerCursor":91}');
 assert r->>'blockReason'='provider_outcome_unknown' and r->'canExecute'='false'::jsonb and r->'providerCalls'='1'::jsonb;
 insert into public.writer_operation_fixture_results values('changed-source-provider-no-bypass',r);
 -- Cancellation after both confirmed responses retains the complete candidate
 -- and its private review path, while leaving the cancellation intent visible.
 r:=public.writer_operation_fixture_begin('cancel-complete-writer');
 r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'translation'));
 r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'review'));
 perform public.request_translation_job_cancel((r->>'jobId')::uuid,(r->>'jobVersion')::bigint);
 done:=public.writer_operation_fixture_finish(r);
 assert done->'result'->>'state'='cancelled' and done->'result'->>'persistence'='working-draft' and done->'result'->>'humanReview'='pending';
 assert done->'result'->>'publication'='unchanged';
 a:=public.get_writer_translation_operation_artifacts((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,r->>'intentHash',r->>'sourceHash');
 assert jsonb_typeof(a->'candidate')='object';
 insert into public.writer_operation_fixture_results values('cancel-complete-retains-pending',done);
end; $$;
reset role;
select 'M07_WRITER_OPERATIONS_EXTRA_PASS';

-- Catalog provider admission reuses Translation Operations. This private table
-- is an artifact cache, not a queue: scheduling/status/attempts stay in the
-- existing public journal. Unknown dispatches never expire into a new request.
begin;

create table premium_translation_private.catalog_operation_artifacts (
  operation_id uuid primary key,
  job_id uuid not null unique references public.translation_jobs(id) on delete restrict deferrable initially deferred,
  item_id uuid not null unique references public.translation_job_items(id) on delete restrict deferrable initially deferred,
  actor_id uuid not null references auth.users(id) on delete restrict,
  entity_type text not null check(entity_type in ('literary_work','country')),
  entity_id text not null,
  begin_request_hash text not null,
  raw_seed_hash text not null,
  raw_seed jsonb not null check(jsonb_typeof(raw_seed)='object' and octet_length(raw_seed::text)<=4194304),
  linked_draft_id uuid unique,
  linked_draft_version bigint,
  candidate_hash text,
  provider text not null check(provider in ('openai','cloudflare')),
  source_hash text not null check(source_hash ~ '^[a-f0-9]{64}$'),
  intent_hash text not null check(intent_hash ~ '^[a-f0-9]{64}$'),
  configuration_hash text not null,
  configuration jsonb not null,
  source_snapshot jsonb not null check(jsonb_typeof(source_snapshot)='object' and octet_length(source_snapshot::text)<=4194304),
  source_revision jsonb not null,
  target_revision jsonb not null,
  expected_state jsonb not null check(jsonb_typeof(expected_state)='object' and octet_length(expected_state::text)<=4194304),
  confirmed_cursor jsonb not null,
  calls jsonb not null default '[]'::jsonb check(jsonb_typeof(calls)='array' and jsonb_array_length(calls)<=4 and octet_length(calls::text)<=4194304),
  candidate jsonb check(candidate is null or (jsonb_typeof(candidate)='object' and octet_length(candidate::text)<=1048576)),
  final_receipt jsonb,
  finish_fingerprint text,
  job_write_proof jsonb not null,
  item_write_proof jsonb not null,
  attempt_write_proof jsonb,
  created_at timestamptz not null default clock_timestamp()
);
alter table premium_translation_private.catalog_operation_artifacts enable row level security;
alter table premium_translation_private.catalog_operation_artifacts force row level security;
revoke all on premium_translation_private.catalog_operation_artifacts from public,anon,authenticated,service_role;

create unique index translation_catalog_active_operation_unique
  on public.translation_job_items(entity_type,entity_id)
  where entity_type in ('literary_work','country') and staff_retry is not null;

create function premium_translation_private.catalog_operation_identity(k text,v text)
returns text language plpgsql immutable security invoker set search_path='' as $$
begin
  if k is null or k not in ('literary_work','country') then raise exception 'Unsupported catalog operation kind' using errcode='22023'; end if;
  perform premium_translation_private.assert_identity(k,v);
  if k='literary_work' then return v::uuid::text; end if;
  if v<>btrim(v) or v ~ '[[:cntrl:]]' then raise exception 'Invalid country identity' using errcode='22023'; end if;
  return v;
end; $$;

create function premium_translation_private.catalog_operation_cursor_valid(k text,v jsonb)
returns boolean language sql immutable security invoker set search_path='' as $$
 select coalesce(jsonb_typeof(v)='object' and v-(case k when 'literary_work' then 'libraryCursor' else 'countryCursor' end)='{}'::jsonb
   and (v='{}'::jsonb or (jsonb_typeof(v->(case k when 'literary_work' then 'libraryCursor' else 'countryCursor' end))='number'
     and v->>(case k when 'literary_work' then 'libraryCursor' else 'countryCursor' end) ~ '^[0-9]{1,9}$')),false);
$$;

-- Client projections are deliberately distinguished from full server rows.
-- Timestamp offsets are equivalent instants; every authored value is exact.
create function premium_translation_private.catalog_operation_projection(actual jsonb,expected jsonb,keys text[])
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare projection jsonb;
begin
  if not premium_translation_private.exact_object(expected,keys) then return false; end if;
  select jsonb_object_agg(key,value) into projection from jsonb_each(actual) where key=any(keys);
  return (projection-'updated_at')=(expected-'updated_at')
    and (projection->>'updated_at')::timestamptz is not distinct from (expected->>'updated_at')::timestamptz;
exception when others then return false;
end; $$;

create function premium_translation_private.catalog_operation_capture(k text,identity text,expected jsonb)
returns jsonb language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare w public.literary_works%rowtype; ru public.literary_work_translations%rowtype; en public.literary_work_translations%rowtype;
  c public.country_profile_overrides%rowtype; sources jsonb; selected uuid;
begin
  if k='literary_work' then
    select * into w from public.literary_works where id=identity::uuid for update;
    select * into ru from public.literary_work_translations where work_id=identity::uuid and locale='ru' for update;
    select * into en from public.literary_work_translations where work_id=identity::uuid and locale='en' for update;
    if w.id is null or ru.id is null or en.id is null then raise exception 'Book source disappeared' using errcode='40001'; end if;
    -- Parent FOR UPDATE also excludes new FK source inserts until transaction
    -- completion. Deterministic source locks exclude licence/update/delete races.
    perform 1 from public.literary_work_sources where work_id=w.id order by id for share;
    select coalesce(jsonb_agg(to_jsonb(s) order by s.id),'[]'::jsonb) into sources from public.literary_work_sources s where work_id=w.id;
    select id into selected from public.literary_work_sources where work_id=w.id
      and provider=expected#>>'{titleSource,provider}' and source_url=expected#>>'{titleSource,source_url}'
      and retrieved_at=(expected#>>'{titleSource,retrieved_at}')::date and 'title'=any(field_names);
    if selected is null then raise exception 'Verified bibliographic source changed' using errcode='40001'; end if;
    return jsonb_build_object('version',1,'work',to_jsonb(w),'russian',to_jsonb(ru),'english',to_jsonb(en),'sources',sources,'selectedTitleSourceId',selected);
  end if;
  select * into c from public.country_profile_overrides where country_id=identity for update;
  return jsonb_build_object('version',1,'catalogFields',expected->'catalogFields','override',case when c.id is null then 'null'::jsonb else to_jsonb(c) end);
end; $$;

create function premium_translation_private.catalog_operation_expected_valid(k text,expected jsonb,seed jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare selected jsonb;
begin
  if expected->'version' is distinct from '1'::jsonb then return false; end if;
  if k='literary_work' then
    if not premium_translation_private.exact_object(expected,array['version','work','russian','english','titleSource'])
      or not premium_translation_private.exact_object(expected->'titleSource',array['provider','source_url','retrieved_at']) then return false; end if;
    select value into selected from jsonb_array_elements(seed->'sources') where value->>'id'=seed->>'selectedTitleSourceId';
    return premium_translation_private.catalog_operation_projection(seed->'work',expected->'work',array['id','title','original_title','first_published','original_language','editorial_status','updated_at'])
      and premium_translation_private.catalog_operation_projection(seed->'russian',expected->'russian',array['id','title','description','source_language','source_urls','editorial_status','updated_at','metadata'])
      and premium_translation_private.catalog_operation_projection(seed->'english',expected->'english',array['id','title','description','source_urls','translation_method','editorial_status','updated_at','metadata'])
      and jsonb_build_object('provider',selected->'provider','source_url',selected->'source_url','retrieved_at',selected->'retrieved_at')=expected->'titleSource';
  end if;
  if not premium_translation_private.exact_object(expected,array['version','catalogFields','override'])
    or jsonb_typeof(expected->'catalogFields') is distinct from 'object' or expected->'catalogFields' is distinct from seed->'catalogFields' then return false; end if;
  if seed->'override'='null'::jsonb then return expected->'override'='null'::jsonb; end if;
  return premium_translation_private.catalog_operation_projection(seed->'override',expected->'override',array['id','fields','updated_at']);
exception when others then return false;
end; $$;


create function premium_translation_private.catalog_operation_configuration_valid(k text,v jsonb,p text)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare key text;
begin
  if not premium_translation_private.exact_object(v,array['version','provider','model','reviewerModel','promptFingerprint',
    'translatorReasoningEffort','translatorReasoningMode','reviewerReasoningEffort','reviewerReasoningMode','schemaName','maxOutputTokens','twoPassReview'])
    or v->'version' is distinct from '1'::jsonb or v->>'provider' is distinct from p
    or v->>'schemaName' is distinct from (case k when 'literary_work' then 'probpera_literary_work_translation' else 'probpera_country_profile_translation' end)
    or v->'maxOutputTokens' is distinct from to_jsonb(case k when 'literary_work' then 4000 else 12000 end)
    or jsonb_typeof(v->'twoPassReview') is distinct from 'boolean'
    or jsonb_typeof(v->'promptFingerprint') is distinct from 'string' or v->>'promptFingerprint' !~ '^[a-f0-9]{64}$' or octet_length(v::text)>4096 then return false; end if;
  foreach key in array array['model','reviewerModel'] loop
    if jsonb_typeof(v->key) is distinct from 'string' or char_length(v->>key) not between 1 and 200 or v->>key ~ '[[:cntrl:]]' then return false; end if;
  end loop;
  foreach key in array array['translatorReasoningEffort','reviewerReasoningEffort'] loop
    if jsonb_typeof(v->key) is distinct from 'string' or v->>key not in ('none','low','medium','high','xhigh','max') then return false; end if;
  end loop;
  foreach key in array array['translatorReasoningMode','reviewerReasoningMode'] loop
    if jsonb_typeof(v->key) is distinct from 'string' or v->>key not in ('standard','pro') then return false; end if;
  end loop;
  return true;
end; $$;


create function premium_translation_private.catalog_operation_source_valid(k text,identity text,s jsonb,r jsonb,t jsonb,seed jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare w jsonb:=seed->'work'; ru jsonb:=seed->'russian'; en jsonb:=seed->'english'; selected jsonb;
  effective jsonb; translations jsonb; catalog_translations jsonb; protected jsonb; current_source jsonb;
begin
  if not premium_translation_private.valid_revision(t) or octet_length(s::text)>4194304 then return false; end if;
  if k='literary_work' then
    if not premium_translation_private.exact_object(r,array['workId','workUpdatedAt','russianId','russianUpdatedAt'])
      or not premium_translation_private.exact_object(s,array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls'])
      or r->>'workId' is distinct from identity or (w->>'id')::uuid is distinct from identity::uuid
      or (r->>'russianId')::uuid is distinct from (ru->>'id')::uuid or (t->>'id')::uuid is distinct from (en->>'id')::uuid
      or (r->>'workUpdatedAt')::timestamptz is distinct from (w->>'updated_at')::timestamptz
      or (r->>'russianUpdatedAt')::timestamptz is distinct from (ru->>'updated_at')::timestamptz
      or (t->>'updatedAt')::timestamptz is distinct from (en->>'updated_at')::timestamptz
      or w->>'editorial_status' not in ('reviewed','verified') or ru->>'editorial_status' not in ('reviewed','verified')
      or jsonb_array_length(ru->'source_urls')=0 or en->>'translation_method' is distinct from 'machine-translation' then return false; end if;
    select value into selected from jsonb_array_elements(seed->'sources') where value->>'id'=seed->>'selectedTitleSourceId';
    current_source:=jsonb_build_object('russianTitle',ru->'title','verifiedEnglishTitle',premium_translation_private.trim_text(en->>'title'),
      'verifiedEnglishTitleSourceUrl',selected->'source_url','description',ru->'description','originalTitle',coalesce(w->>'original_title',''),
      'firstPublished',w->'first_published','originalLanguage',coalesce(w->>'original_language',''),'sourceLanguage',ru->'source_language','sourceUrls',ru->'source_urls');
    return current_source=s and char_length(s->>'verifiedEnglishTitle')>0
      and not exists(select 1 from unnest(string_to_array(s->>'verifiedEnglishTitle',null::text)) glyph
        where ascii(glyph) between 1024 and 1327 or ascii(glyph) between 7296 and 7311 or ascii(glyph) between 11744 and 11775
          or ascii(glyph) between 42560 and 42655 or ascii(glyph) between 65070 and 65071 or ascii(glyph) between 122928 and 123023)
      and en#>>'{metadata,premiumTranslation,bibliographicTitle,value}'=s->>'verifiedEnglishTitle'
      and en#>>'{metadata,premiumTranslation,bibliographicTitle,sourceUrl}'=s->>'verifiedEnglishTitleSourceUrl'
      and en->'source_urls' ? (s->>'verifiedEnglishTitleSourceUrl') and selected->'field_names' ? 'title';
  end if;
  if not premium_translation_private.exact_object(r,array['overrideId','overrideUpdatedAt','catalogSourceHash'])
    or coalesce(r->>'catalogSourceHash','') !~ '^[a-f0-9]{64}$'
    or jsonb_build_object('id',r->'overrideId','updatedAt',r->'overrideUpdatedAt') is distinct from t
    or not premium_translation_private.valid_country_fields(s,false) or coalesce(s->>'name','')=''
    or (coalesce(s->>'description','')='' and coalesce(s->>'history','')='' and coalesce(s->>'historicalNote','')='') then return false; end if;
  if seed->'override'='null'::jsonb then
    if t->>'id' is not null then return false; end if;
  elsif (seed#>>'{override,id}')::uuid is distinct from (t->>'id')::uuid
    or (seed#>>'{override,updated_at}')::timestamptz is distinct from (t->>'updatedAt')::timestamptz then return false; end if;
  if (seed->'catalogFields' ? 'translations' and jsonb_typeof(seed#>'{catalogFields,translations}') is distinct from 'object')
    or (seed#>'{override,fields}' ? 'translations' and jsonb_typeof(seed#>'{override,fields,translations}') is distinct from 'object') then return false; end if;
  effective:=seed->'catalogFields'||coalesce(nullif(seed#>'{override,fields}','null'::jsonb),'{}'::jsonb);
  translations:=coalesce(effective->'translations','{}'::jsonb);catalog_translations:=coalesce(seed#>'{catalogFields,translations}','{}'::jsonb);
  protected:=case when translations ? 'en' then translations->'en' when catalog_translations ? 'en' then catalog_translations->'en' else null end;
  return protected is null or (protected->>'locale'='en' and protected->>'method'='machine-translation');
exception when others then return false;
end; $$;


create function premium_translation_private.catalog_operation_progress(c jsonb)
returns jsonb language sql immutable security invoker set search_path='' as $$
  select jsonb_build_object('version',1,'updatedAt',coalesce(nullif(c->(jsonb_array_length(c)-1)->'metadata'->'responseReceivedAt','null'::jsonb),
      c->(jsonb_array_length(c)-1)->'metadata'->'dispatchRecordedAt',to_jsonb('1970-01-01T00:00:00Z'::text)),
    'calls',coalesce(jsonb_agg(value->'metadata' order by n),'[]'::jsonb))
  from jsonb_array_elements(c) with ordinality x(value,n);
$$;

create function premium_translation_private.catalog_operation_guard()
returns trigger language plpgsql security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; identity uuid;
begin
  if tg_table_name='translation_jobs' then
    identity:=case when tg_op='INSERT' then new.id else old.id end;
    select * into a from premium_translation_private.catalog_operation_artifacts where job_id=identity;
    if a.operation_id is null then return case when tg_op='DELETE' then old else new end; end if;
    if tg_op='DELETE' then raise exception 'Catalog operation journal cannot be deleted' using errcode='42501'; end if;
    if to_jsonb(new)=a.job_write_proof then return new; end if;
    -- Existing cancellation is monotonic. It stops further dispatch, but cannot
    -- erase an admission, change a cursor or turn an unknown response into retry.
    if tg_op='UPDATE' and auth.uid()=a.actor_id and public.is_staff()
      and new.cancel_requested_at is not null and (old.cancel_requested_at is null or new.cancel_requested_at=old.cancel_requested_at)
      and new.status in ('cancelling','cancelled') and new.version=old.version+1
      and (to_jsonb(new)-array['cancel_requested_at','status','version','updated_at','completed_at'])=
          (to_jsonb(old)-array['cancel_requested_at','status','version','updated_at','completed_at']) then return new; end if;
  elsif tg_table_name='translation_job_items' then
    identity:=case when tg_op='INSERT' then new.id else old.id end;
    select * into a from premium_translation_private.catalog_operation_artifacts where item_id=identity;
    if a.operation_id is null then
      if (tg_op<>'DELETE' and new.entity_type in ('literary_work','country') and new.staff_retry is not null)
        or (tg_op<>'INSERT' and old.entity_type in ('literary_work','country') and old.staff_retry is not null) then
        raise exception 'Catalog operation requires private admission proof' using errcode='42501'; end if;
      return case when tg_op='DELETE' then old else new end;
    end if;
    if tg_op='DELETE' then raise exception 'Catalog operation item cannot be deleted' using errcode='42501'; end if;
    if to_jsonb(new)=a.item_write_proof then return new; end if;
  else
    identity:=case when tg_op='INSERT' then new.item_id else old.item_id end;
    select * into a from premium_translation_private.catalog_operation_artifacts where item_id=identity;
    if a.operation_id is null then return case when tg_op='DELETE' then old else new end; end if;
    if tg_op='INSERT' and to_jsonb(new)=a.attempt_write_proof then return new; end if;
  end if;
  raise exception 'Catalog operation private journal proof differs' using errcode='42501';
end; $$;
create trigger translation_jobs_catalog_integrity before insert or update or delete on public.translation_jobs
  for each row execute function premium_translation_private.catalog_operation_guard();
create trigger translation_items_catalog_integrity before insert or update or delete on public.translation_job_items
  for each row execute function premium_translation_private.catalog_operation_guard();
create trigger translation_attempts_catalog_integrity before insert or update or delete on public.translation_job_attempts
  for each row execute function premium_translation_private.catalog_operation_guard();

create function premium_translation_private.catalog_operation_view(a premium_translation_private.catalog_operation_artifacts,
  replayed boolean default false,execute_allowed boolean default false,dispatch_allowed boolean default false)
returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare j public.translation_jobs%rowtype; pending text; reason text; phase text:='running';
begin
  select * into j from public.translation_jobs where id=a.job_id;
  select value->'metadata'->>'callId' into pending from jsonb_array_elements(a.calls) where value->'metadata'->'responseReceivedAt'='null'::jsonb limit 1;
  if a.final_receipt is not null then return a.final_receipt||jsonb_build_object('replayed',replayed,'canExecute',false,'canDispatch',false);
  elsif auth.uid() is distinct from a.actor_id then reason:='operation_owned_by_another_actor';phase:='blocked';
  elsif pending is not null and not dispatch_allowed then reason:='provider_outcome_unknown';phase:='blocked';
  elsif j.cancel_requested_at is not null then reason:='operation_stopped';phase:='blocked'; end if;
  return jsonb_build_object('version',1,'jobId',a.job_id,'itemId',a.item_id,'operationId',a.operation_id,'entityType',a.entity_type,'entityId',a.entity_id,
    'actorId',a.actor_id,'provider',a.provider,'sourceHash',a.source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,
    'configurationHash',a.configuration_hash,'configuration',a.configuration,'sourceRevision',a.source_revision,'targetRevision',a.target_revision,
    'jobVersion',j.version::text,'phase',phase,'canExecute',execute_allowed and reason is null,'canDispatch',dispatch_allowed,
    'replayed',replayed,'providerCalls',jsonb_array_length(a.calls),'pendingCallId',pending,'blockReason',reason,'resumeCursor',j.resume_cursor-'catalogOperation','result',null);
end; $$;


create function public.finish_catalog_translation_operation(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_candidate jsonb default null
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; j public.translation_jobs%rowtype;
  i public.translation_job_items%rowtype; attempt public.translation_job_attempts%rowtype;
  draft public.premium_translation_working_drafts%rowtype; current_work jsonb; current_ru jsonb; current_sources jsonb; selected_source jsonb; urls jsonb; n integer;
  fingerprint text; digest text; status text; code text; state text; persistence text:='none'; result jsonb; receipt jsonb;
  first_call jsonb; last_call jsonb; stamp timestamptz:=clock_timestamp(); current_bound boolean:=true;
begin
  a:=premium_translation_private.catalog_operation_owned(p_job_id,p_item_id,p_operation_id);
  if p_outcome is null or jsonb_typeof(p_outcome)<>'object'
    or not(p_outcome ?& array['status','providerCalls'])
    or p_outcome-array['status','providerCalls','errorCode','model','requestId','inputTokens','outputTokens','durationMs']<>'{}'::jsonb
    or coalesce(p_outcome->>'status','') not in ('succeeded','dead_letter','conflict','stale','skipped','not-configured','cancelled')
    or jsonb_typeof(p_outcome->'providerCalls') is distinct from 'number'
    or p_outcome->>'providerCalls' !~ '^[0-4]$'
    or (p_outcome->>'providerCalls')::integer<>jsonb_array_length(a.calls)
    or (p_outcome->>'errorCode' is not null and p_outcome->>'errorCode' not in
      ('translation_not_configured','provider_unavailable','provider_request_failed','provider_invalid_response',
       'source_changed','write_conflict','database_read_failed','database_write_failed','unexpected','translation_operation_stopped')) then
    raise exception 'Invalid catalog finish outcome' using errcode='22023'; end if;
  fingerprint:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_outcome,p_candidate));
  if a.final_receipt is not null then
    if a.finish_fingerprint is distinct from fingerprint then raise exception 'Catalog finish intent differs' using errcode='40001'; end if;
    return premium_translation_private.catalog_operation_view(a,true);
  end if;
  if exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->'responseReceivedAt'='null'::jsonb) then
    raise exception 'Catalog provider outcome remains unknown' using errcode='40001'; end if;
  select * into j from public.translation_jobs where id=p_job_id for update;
  select * into i from public.translation_job_items where id=p_item_id for update;
  status:=p_outcome->>'status';code:=p_outcome->>'errorCode';
  if (status='succeeded') is distinct from (p_candidate is not null) then
    raise exception 'Catalog completed candidate required only for success' using errcode='22023'; end if;
  if p_candidate is not null then
    n:=jsonb_array_length(a.calls);
    if not premium_translation_private.exact_object(p_candidate,array['payload','provenance','translatorCallId','reviewerCallId'])
      or n<1 or octet_length(p_candidate::text)>1048576
      or (a.configuration->'twoPassReview'='true'::jsonb and not exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->>'pass'='review'))
      or (a.configuration->'twoPassReview'='false'::jsonb and (n>2 or exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->>'pass'='review'))) then
      raise exception 'Catalog independent review proof missing' using errcode='22023'; end if;
    first_call:=a.calls->0->'metadata';last_call:=a.calls->(jsonb_array_length(a.calls)-1)->'metadata';
    if p_candidate->>'translatorCallId' is distinct from first_call->>'callId'
      or p_candidate->>'reviewerCallId' is distinct from (case when n=1 then null else last_call->>'callId' end)
      or p_candidate->'provenance'->>'provider' is distinct from a.provider
      or p_candidate->'provenance'->>'translatorModel' is distinct from first_call->>'model'
      or p_candidate->'provenance'->>'reviewerModel' is distinct from (case when n=1 then null else last_call->>'model' end)
      or p_candidate->'provenance'->>'translatorRequestId' is distinct from coalesce(first_call->>'requestId',first_call->>'responseId')
      or p_candidate->'provenance'->>'reviewerRequestId' is distinct from (case when n=1 then null else coalesce(last_call->>'requestId',last_call->>'responseId') end) then
      raise exception 'Catalog candidate provider evidence differs' using errcode='40001'; end if;
    perform premium_translation_private.assert_shape(a.entity_type,a.source_snapshot,a.source_revision,a.target_revision,
      p_candidate->'payload',p_candidate->'provenance');
    if a.entity_type='literary_work' then
      select value into selected_source from jsonb_array_elements(a.raw_seed->'sources') where value->>'id'=a.raw_seed->>'selectedTitleSourceId';
      select coalesce(jsonb_agg(url order by position),'[]'::jsonb) into urls from (
        select url,min(position) position from (
          select value #>> '{}' url,position from jsonb_array_elements(a.raw_seed#>'{english,source_urls}') with ordinality e(value,position) where value #>> '{}' ~ '^https://'
          union all select value #>> '{}',position+jsonb_array_length(a.raw_seed#>'{english,source_urls}') from jsonb_array_elements(a.raw_seed#>'{russian,source_urls}') with ordinality r(value,position)
        ) combined group by url
      ) ordered_urls;
      if p_candidate->'payload'->'sourceUrls' is distinct from urls
        or p_candidate->'payload'->'bibliographicTitle' is distinct from jsonb_build_object('value',a.source_snapshot->'verifiedEnglishTitle',
          'provider',selected_source->'provider','sourceUrl',selected_source->'source_url','retrievedAt',selected_source->'retrieved_at') then
        raise exception 'Catalog recorded bibliography/source rights binding differs' using errcode='40001'; end if;
    end if;
    -- Promotion takes draft -> canonical row locks; use the same order.
    perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||a.entity_type||':'||a.entity_id,0));
    select * into draft from public.premium_translation_working_drafts where entity_type=a.entity_type and entity_id=a.entity_id for update;
    begin
      perform premium_translation_private.catalog_operation_assert_current(a);
    exception when serialization_failure then current_bound:=false; end;
    if not current_bound then
      status:='conflict';code:='write_conflict';
      if a.entity_type='literary_work' then
        select to_jsonb(w) into current_work from public.literary_works w where id=a.entity_id::uuid;
        select to_jsonb(r) into current_ru from public.literary_work_translations r where work_id=a.entity_id::uuid and locale='ru';
        select coalesce(jsonb_agg(to_jsonb(s) order by id),'[]'::jsonb) into current_sources from public.literary_work_sources s where work_id=a.entity_id::uuid;
        if current_work is distinct from a.raw_seed->'work' or current_ru is distinct from a.raw_seed->'russian'
          or current_sources is distinct from a.raw_seed->'sources' then status:='stale';code:='source_changed'; end if;
      end if;
    end if;
    digest:=probpera_translation_operations.retry_fingerprint(jsonb_build_object('entityType',a.entity_type,'entityId',a.entity_id,
      'targetLocale','en','sourceHash',a.source_hash,'sourceSnapshot',a.source_snapshot,'sourceRevision',a.source_revision,
      'targetRevision',a.target_revision,'payload',p_candidate->'payload','provenance',p_candidate->'provenance'));
    -- A fully validated body is retained independently of live CAS/cancel.
    -- Existing pending author/review work is never replaced.
    if draft.id is null then
      insert into public.premium_translation_working_drafts(entity_type,entity_id,source_hash,candidate_hash,source_snapshot,
        source_revision,target_revision,payload,provenance,created_by)
        values(a.entity_type,a.entity_id,a.source_hash,digest,a.source_snapshot,a.source_revision,a.target_revision,
          p_candidate->'payload',p_candidate->'provenance',a.actor_id) returning * into draft;
      persistence:='working-draft';
    elsif draft.candidate_hash=digest and draft.source_snapshot=a.source_snapshot and draft.source_revision=a.source_revision
      and draft.target_revision=a.target_revision and draft.payload=p_candidate->'payload' and draft.provenance=p_candidate->'provenance' then
      persistence:='working-draft';
    else
      persistence:='private-artifact';status:='conflict';code:='write_conflict';draft:=null;
    end if;
  end if;
  if j.cancel_requested_at is not null then status:='cancelled';code:=null; end if;
  if status in ('succeeded','skipped','cancelled') then code:=null;
  elsif code is null then code:=case status when 'stale' then 'source_changed' when 'conflict' then 'write_conflict'
    when 'not-configured' then 'translation_not_configured' else 'unexpected' end; end if;
  state:=case status when 'succeeded' then 'translated' when 'dead_letter' then 'failed' else status end;
  result:=jsonb_build_object('state',state,'errorCode',code,'persistence',persistence,
    'draftId',case when persistence='working-draft' then draft.id else null end,
    'draftVersion',case when persistence='working-draft' then draft.version else null end,
    'draftUpdatedAt',case when persistence='working-draft' then draft.created_at else null end,'candidateHash',digest,'publication','unchanged',
    'humanReview',case when p_candidate is null then 'unchanged' else 'pending' end);
  j.status:=case status when 'succeeded' then 'completed' when 'dead_letter' then 'failed' else status end;
  j.succeeded_items:=case when status='succeeded' then 1 else 0 end;j.failed_items:=case when status='dead_letter' then 1 else 0 end;
  j.version:=j.version+1;j.updated_at:=stamp;j.completed_at:=stamp;
  if not(status='skipped' and jsonb_array_length(a.calls)=0) then
    j.resume_cursor:=a.confirmed_cursor||jsonb_build_object('catalogOperation',j.resume_cursor->'catalogOperation');
  end if;
  receipt:=premium_translation_private.catalog_operation_view(a)||jsonb_build_object('phase','finished','blockReason',null,'pendingCallId',null,
    'canExecute',false,'canDispatch',false,'jobVersion',j.version::text,'resumeCursor',j.resume_cursor-'catalogOperation','result',result);
  i.status:=case status when 'succeeded' then 'succeeded' when 'cancelled' then 'cancelled' else status end;
  i.attempt_count:=1;i.staff_retry:=null;i.last_error_code:=code;i.updated_at:=stamp;
  attempt:=jsonb_populate_record(null::public.translation_job_attempts,jsonb_build_object(
    'id',nextval('public.translation_job_attempts_id_seq'),'item_id',p_item_id,'attempt_number',1,
    'outcome',case when status='cancelled' then 'skipped' else status end,'provider',a.provider,
    'model',p_outcome->'model','provider_request_id',p_outcome->'requestId','error_code',code,
    'input_tokens',p_outcome->'inputTokens','output_tokens',p_outcome->'outputTokens','duration_ms',p_outcome->'durationMs',
    'created_at',stamp,'staff_retry_operation_id',p_operation_id,'staff_retry_receipt',jsonb_build_object('version',1,
      'actorId',a.actor_id,'intentHash',a.intent_hash,'finishFingerprint',fingerprint,'receipt',receipt,
      'progress',premium_translation_private.catalog_operation_progress(a.calls))));
  if persistence='working-draft' then a.linked_draft_id:=draft.id;a.linked_draft_version:=draft.version; end if;
  a.candidate_hash:=digest;
  a.candidate:=p_candidate;a.final_receipt:=receipt;a.finish_fingerprint:=fingerprint;
  a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);a.attempt_write_proof:=to_jsonb(attempt);
  update premium_translation_private.catalog_operation_artifacts set candidate=a.candidate,final_receipt=receipt,finish_fingerprint=fingerprint,
    linked_draft_id=a.linked_draft_id,linked_draft_version=a.linked_draft_version,candidate_hash=digest,
    job_write_proof=a.job_write_proof,item_write_proof=a.item_write_proof,attempt_write_proof=a.attempt_write_proof where operation_id=p_operation_id;
  insert into public.translation_job_attempts overriding system value select attempt.*;
  update public.translation_job_items set status=i.status,attempt_count=i.attempt_count,staff_retry=null,last_error_code=code,updated_at=stamp where id=p_item_id;
  update public.translation_jobs set status=j.status,succeeded_items=j.succeeded_items,failed_items=j.failed_items,version=j.version,
    updated_at=stamp,completed_at=stamp,resume_cursor=j.resume_cursor where id=p_job_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.catalog_operation.finished','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'state',state,'persistence',persistence,'candidateHash',digest));
  return receipt;
end; $$;


create function public.reconcile_catalog_translation_operation(p_entity_type text,p_entity_id text,p_operation_id uuid default null)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; identity text;
begin
  perform premium_translation_private.assert_actor();identity:=premium_translation_private.catalog_operation_identity(p_entity_type,p_entity_id);
  perform pg_advisory_xact_lock(hashtextextended('catalog-operation:'||p_entity_type||':'||identity,7291));
  select cache.* into a from premium_translation_private.catalog_operation_artifacts cache join public.translation_job_items item on item.id=cache.item_id
    where cache.entity_type=p_entity_type and cache.entity_id=identity and (p_operation_id is null or cache.operation_id=p_operation_id)
    order by (item.staff_retry is not null) desc,cache.created_at desc,cache.operation_id desc limit 1;
  if a.operation_id is null then return null; end if;
  return premium_translation_private.catalog_operation_view(a,true);
end; $$;


create function public.get_catalog_translation_operation_artifacts(p_job_id uuid,p_item_id uuid,p_operation_id uuid,
  p_entity_type text,p_entity_id text,p_intent_hash text,p_source_hash text)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;
begin
  a:=premium_translation_private.catalog_operation_owned(p_job_id,p_item_id,p_operation_id);
  if a.entity_type is distinct from p_entity_type or a.entity_id is distinct from premium_translation_private.catalog_operation_identity(p_entity_type,p_entity_id)
    or a.intent_hash is distinct from p_intent_hash or a.source_hash is distinct from p_source_hash then
    raise exception 'Catalog private artifact binding differs' using errcode='40001'; end if;
  return jsonb_build_object('version',1,'receipt',premium_translation_private.catalog_operation_view(a,true),'expectedState',a.expected_state,'rawSeed',a.raw_seed,
    'sourceSnapshot',a.source_snapshot,'sourceRevision',a.source_revision,'targetRevision',a.target_revision,'configuration',a.configuration,'calls',a.calls,'candidate',a.candidate);
end; $$;




create function premium_translation_private.catalog_operation_owned(p_job uuid,p_item uuid,p_operation uuid)
returns premium_translation_private.catalog_operation_artifacts language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;
begin
  perform premium_translation_private.assert_actor();
  select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation for update;
  if a.operation_id is null then raise exception 'Catalog operation not found' using errcode='P0002'; end if;
  if a.actor_id is distinct from auth.uid() then raise exception 'Catalog operation actor differs' using errcode='42501'; end if;
  if a.job_id is distinct from p_job or a.item_id is distinct from p_item or a.entity_type not in ('literary_work','country') then
    raise exception 'Catalog operation identity differs' using errcode='40001'; end if;
  return a;
end; $$;


create function premium_translation_private.catalog_operation_assert_current(a premium_translation_private.catalog_operation_artifacts)
returns void language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare current_seed jsonb;
begin
  current_seed:=premium_translation_private.catalog_operation_capture(a.entity_type,a.entity_id,a.expected_state);
  if current_seed is distinct from a.raw_seed then raise exception 'Catalog full source/target seed changed' using errcode='40001'; end if;
  if premium_translation_private.catalog_operation_source_valid(a.entity_type,a.entity_id,a.source_snapshot,a.source_revision,a.target_revision,current_seed) is distinct from true then
    raise exception 'Catalog source eligibility or English ownership changed' using errcode='40001'; end if;
end; $$;


create function public.catalog_translation_operation_ready()
returns boolean language plpgsql stable security definer set search_path='' as $$
declare signature text; routine regprocedure;
begin
  perform premium_translation_private.assert_actor();
  foreach signature in array array[
    'public.begin_catalog_translation_operation(uuid,uuid,uuid,text,text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb)',
    'public.record_catalog_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text)',
    'public.record_catalog_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb)',
    'public.finish_catalog_translation_operation(uuid,uuid,uuid,jsonb,jsonb)',
    'public.reconcile_catalog_translation_operation(text,text,uuid)',
    'public.get_catalog_translation_operation_artifacts(uuid,uuid,uuid,text,text,text,text)'] loop
    routine:=to_regprocedure(signature);
    if routine is null or not has_function_privilege('authenticated',routine,'EXECUTE') then return false; end if;
  end loop;
  return to_regclass('premium_translation_private.catalog_operation_artifacts') is not null
    and to_regprocedure('premium_translation_private.assert_catalog_operation_promotion_current(public.premium_translation_working_drafts,text,jsonb)') is not null
    and exists(select 1 from pg_index where indexrelid=to_regclass('public.translation_catalog_active_operation_unique') and indisunique and indisvalid and indpred is not null)
    and (select count(*)=3 from pg_trigger where not tgisinternal and tgenabled='O'
      and tgfoid=to_regprocedure('premium_translation_private.catalog_operation_guard()')
      and tgname in ('translation_jobs_catalog_integrity','translation_items_catalog_integrity','translation_attempts_catalog_integrity'));
end; $$;


create function public.begin_catalog_translation_operation(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_entity_type text,p_entity_id text,p_provider text,p_source_hash text,
  p_source_snapshot jsonb,p_source_revision jsonb,p_target_revision jsonb,p_expected_state jsonb,p_configuration jsonb,
  p_current_cursor jsonb default '{}'::jsonb,p_resume_cursor jsonb default '{}'::jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare actor uuid:=premium_translation_private.assert_actor(); a premium_translation_private.catalog_operation_artifacts%rowtype;
  j public.translation_jobs%rowtype; i public.translation_job_items%rowtype; identity text; request_hash text; marker jsonb; view jsonb;
  stamp timestamptz:=clock_timestamp();
begin
  identity:=premium_translation_private.catalog_operation_identity(p_entity_type,p_entity_id);
  if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
    or not probpera_translation_operations.retry_uuid(p_operation_id) or p_provider is null or p_provider not in ('openai','cloudflare')
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$'
    or jsonb_typeof(p_expected_state) is distinct from 'object' or octet_length(p_expected_state::text)>4194304
    or premium_translation_private.catalog_operation_configuration_valid(p_entity_type,p_configuration,p_provider) is distinct from true
    or premium_translation_private.catalog_operation_cursor_valid(p_entity_type,p_current_cursor) is distinct from true
    or premium_translation_private.catalog_operation_cursor_valid(p_entity_type,p_resume_cursor) is distinct from true then
    raise exception 'Invalid catalog operation admission' using errcode='22023'; end if;
  request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_job_id,p_item_id,p_operation_id,actor,p_entity_type,identity,
    p_provider,p_source_hash,p_source_snapshot,p_source_revision,p_target_revision,p_expected_state,p_configuration,p_current_cursor,p_resume_cursor));
  perform pg_advisory_xact_lock(hashtextextended('catalog-operation:'||p_entity_type||':'||identity,7291));
  perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7292));
  select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation_id for update;
  if a.operation_id is not null then
    if a.actor_id is distinct from actor then raise exception 'Catalog operation actor differs' using errcode='42501'; end if;
    if a.begin_request_hash is distinct from request_hash then raise exception 'Catalog begin intent differs' using errcode='40001'; end if;
    return premium_translation_private.catalog_operation_view(a,true);
  end if;
  select cache.* into a from premium_translation_private.catalog_operation_artifacts cache
    join public.translation_job_items item on item.id=cache.item_id
    where cache.entity_type=p_entity_type and cache.entity_id=identity and item.staff_retry is not null for update of cache;
  if a.operation_id is not null then
    view:=premium_translation_private.catalog_operation_view(a,true);
    if a.final_receipt is not null then return view; end if;
    return view||jsonb_build_object('phase','blocked','blockReason',coalesce(view->>'blockReason','operation_in_progress'));
  end if;
  -- FINISH serializes private candidate creation on this same lock. Recheck
  -- after waiting: a completed prior admission cannot be paid for again.
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||identity,0));
  if exists(select 1 from public.translation_jobs where id=p_job_id)
    or exists(select 1 from public.translation_job_items where id=p_item_id)
    or exists(select 1 from public.premium_translation_working_drafts where entity_type=p_entity_type
      and (case when p_entity_type='literary_work' then lower(entity_id)=identity else entity_id=identity end)) then
    raise exception 'Catalog job identity or private candidate already exists' using errcode='40001'; end if;
  a.operation_id:=p_operation_id;a.job_id:=p_job_id;a.item_id:=p_item_id;a.actor_id:=actor;a.entity_type:=p_entity_type;a.entity_id:=identity;
  a.provider:=p_provider;a.source_hash:=p_source_hash;a.begin_request_hash:=request_hash;a.expected_state:=p_expected_state;
  a.raw_seed:=premium_translation_private.catalog_operation_capture(p_entity_type,identity,p_expected_state);
  if octet_length(a.raw_seed::text)>4194304 then raise exception 'Catalog raw source exceeds admission limit' using errcode='22023'; end if;
  if premium_translation_private.catalog_operation_expected_valid(p_entity_type,p_expected_state,a.raw_seed) is distinct from true then
    raise exception 'Catalog expected client projection changed' using errcode='40001'; end if;
  if premium_translation_private.catalog_operation_source_valid(p_entity_type,identity,p_source_snapshot,p_source_revision,p_target_revision,a.raw_seed) is distinct from true then
    raise exception 'Catalog source/target eligibility changed' using errcode='40001'; end if;
  a.raw_seed_hash:=probpera_translation_operations.retry_fingerprint(a.raw_seed);
  a.intent_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(request_hash,a.raw_seed_hash));
  a.configuration:=p_configuration;a.configuration_hash:=probpera_translation_operations.retry_fingerprint(p_configuration);
  a.source_snapshot:=p_source_snapshot;a.source_revision:=p_source_revision;a.target_revision:=p_target_revision;
  a.confirmed_cursor:=p_resume_cursor;a.calls:='[]'::jsonb;a.created_at:=stamp;
  marker:=jsonb_build_object('version',1,'protocol','catalog-translation','operationId',p_operation_id,'actorId',actor,'entityType',p_entity_type,
    'entityId',identity,'sourceHash',p_source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,
    'configurationHash',a.configuration_hash,'startedAt',stamp,'attemptNumber',1,'progress',jsonb_build_object('version',1,'updatedAt',stamp,'calls','[]'::jsonb));
  j:=jsonb_populate_record(null::public.translation_jobs,jsonb_build_object('id',p_job_id,'kind',p_entity_type,'source_locale','ru','target_locale','en',
    'provider',p_provider,'status','reviewing','total_items',1,'succeeded_items',0,'failed_items',0,'requested_by',actor,'started_at',stamp,'version',1,
    'created_at',stamp,'updated_at',stamp,'resume_cursor',p_current_cursor||jsonb_build_object('catalogOperation',
      jsonb_build_object('version',1,'entityType',p_entity_type,'operationId',p_operation_id,'actorId',actor,'intentHash',a.intent_hash))));
  i:=jsonb_populate_record(null::public.translation_job_items,jsonb_build_object('id',p_item_id,'job_id',p_job_id,'position',0,'entity_type',p_entity_type,
    'entity_id',identity,'source_hash',p_source_hash,'status','reviewing','attempt_count',0,'max_attempts',3,'next_attempt_at',stamp,'created_at',stamp,'updated_at',stamp,'staff_retry',marker));
  a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);
  insert into premium_translation_private.catalog_operation_artifacts select a.*;
  insert into public.translation_jobs select j.*;
  insert into public.translation_job_items select i.*;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata) values(actor,'translation.catalog_operation.admitted','translation_job',p_job_id::text,
    jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'entityType',p_entity_type,'entityId',identity,'sourceHash',p_source_hash,'rawSeedHash',a.raw_seed_hash));
  return premium_translation_private.catalog_operation_view(a,false,true);
end; $$;


create function public.record_catalog_translation_operation_dispatch(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_call_id uuid,p_provider text,p_model text,p_pass text,p_request_hash text
)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; j public.translation_jobs%rowtype;
  i public.translation_job_items%rowtype; call jsonb; metadata jsonb; progress jsonb; stamp timestamptz:=clock_timestamp();
begin
  a:=premium_translation_private.catalog_operation_owned(p_job_id,p_item_id,p_operation_id);
  if not probpera_translation_operations.retry_uuid(p_call_id) or p_provider is distinct from a.provider
    or p_model is null or p_pass is null or p_pass not in ('translation','repair','review')
    or p_request_hash is null or p_request_hash !~ '^[a-f0-9]{64}$'
    or p_model is distinct from a.configuration->>(case when p_pass='translation' then 'model' else 'reviewerModel' end) then
    raise exception 'Invalid catalog dispatch binding' using errcode='22023'; end if;
  for call in select value from jsonb_array_elements(a.calls) loop
    if call->'metadata'->>'callId'=p_call_id::text then
      if call->>'requestHash' is distinct from p_request_hash or call->'metadata'->>'pass' is distinct from p_pass
        or call->'metadata'->>'model' is distinct from p_model then raise exception 'Catalog dispatch intent differs' using errcode='40001'; end if;
      return premium_translation_private.catalog_operation_view(a,true);
    end if;
  end loop;
  select * into j from public.translation_jobs where id=p_job_id for update;
  if a.final_receipt is not null or j.cancel_requested_at is not null or j.status<>'reviewing'
    or jsonb_array_length(a.calls)>=4 or exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->'responseReceivedAt'='null'::jsonb) then
    raise exception 'Catalog dispatch is blocked or outcome unknown' using errcode='40001'; end if;
  if a.configuration->'twoPassReview'='false'::jsonb and (p_pass='review' or jsonb_array_length(a.calls)>=2) then
    raise exception 'Unconfigured catalog review pass' using errcode='22023'; end if;
  perform premium_translation_private.catalog_operation_assert_current(a);
  metadata:=jsonb_build_object('callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,
    'dispatchRecordedAt',stamp,'responseReceivedAt',null,'httpStatus',null,'requestId',null,'responseId',null,'inputTokens',null,'outputTokens',null);
  a.calls:=a.calls||jsonb_build_array(jsonb_build_object('requestHash',p_request_hash,'metadata',metadata,'responseArtifact',null));
  progress:=premium_translation_private.catalog_operation_progress(a.calls);
  if not probpera_translation_operations.retry_journal_valid(progress,a.provider) then
    raise exception 'Catalog dispatch sequence differs' using errcode='40001'; end if;
  select * into i from public.translation_job_items where id=p_item_id for update;
  i.staff_retry:=i.staff_retry||jsonb_build_object('progress',progress);i.updated_at:=stamp;
  a.item_write_proof:=to_jsonb(i);
  update premium_translation_private.catalog_operation_artifacts set calls=a.calls,item_write_proof=a.item_write_proof where operation_id=p_operation_id;
  update public.translation_job_items set staff_retry=i.staff_retry,updated_at=i.updated_at where id=p_item_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.catalog_operation.dispatch_recorded','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,'requestHash',p_request_hash));
  return premium_translation_private.catalog_operation_view(a,false,false,true);
end; $$;

create function public.record_catalog_translation_operation_response(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_metadata jsonb,p_response_artifact jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; i public.translation_job_items%rowtype;
  call jsonb; position integer; progress jsonb; stamp timestamptz:=clock_timestamp();
begin
  a:=premium_translation_private.catalog_operation_owned(p_job_id,p_item_id,p_operation_id);
  if not premium_translation_private.exact_object(p_metadata,array['callId','provider','model','pass','httpStatus','requestId','responseId','inputTokens','outputTokens'])
    or not premium_translation_private.exact_object(p_response_artifact,array['version','body'])
    or p_response_artifact->'version' is distinct from '1'::jsonb or octet_length(p_response_artifact::text)>1048576 then
    raise exception 'Invalid catalog response artifact' using errcode='22023'; end if;
  select value,(n-1)::integer into call,position from jsonb_array_elements(a.calls) with ordinality x(value,n)
    where value->'metadata'->>'callId'=p_metadata->>'callId';
  if position is null then raise exception 'Catalog response dispatch not found' using errcode='40001'; end if;
  if call->'metadata'->>'provider' is distinct from p_metadata->>'provider'
    or call->'metadata'->>'model' is distinct from p_metadata->>'model' or call->'metadata'->>'pass' is distinct from p_metadata->>'pass' then
    raise exception 'Catalog response identity differs' using errcode='40001'; end if;
  if call->'metadata'->'responseReceivedAt'<>'null'::jsonb then
    if (call->'metadata')-array['dispatchRecordedAt','responseReceivedAt'] is distinct from p_metadata
      or call->'responseArtifact' is distinct from p_response_artifact then raise exception 'Catalog response evidence differs' using errcode='40001'; end if;
    return premium_translation_private.catalog_operation_view(a,true);
  end if;
  if a.final_receipt is not null then raise exception 'Catalog operation already finished' using errcode='40001'; end if;
  call:=call||jsonb_build_object('metadata',p_metadata||jsonb_build_object('dispatchRecordedAt',call->'metadata'->'dispatchRecordedAt','responseReceivedAt',stamp),
    'responseArtifact',p_response_artifact);
  a.calls:=jsonb_set(a.calls,array[position::text],call);
  if octet_length(a.calls::text)>4194304 then raise exception 'Catalog aggregate response artifact limit exceeded' using errcode='22023'; end if;
  progress:=premium_translation_private.catalog_operation_progress(a.calls);
  if not probpera_translation_operations.retry_journal_valid(progress,a.provider) then
    raise exception 'Catalog response metadata differs' using errcode='22023'; end if;
  select * into i from public.translation_job_items where id=p_item_id for update;
  i.staff_retry:=i.staff_retry||jsonb_build_object('progress',progress);i.updated_at:=stamp;a.item_write_proof:=to_jsonb(i);
  update premium_translation_private.catalog_operation_artifacts set calls=a.calls,item_write_proof=a.item_write_proof where operation_id=p_operation_id;
  update public.translation_job_items set staff_retry=i.staff_retry,updated_at=i.updated_at where id=p_item_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.catalog_operation.response_received','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'callId',p_metadata->'callId','responseHash',probpera_translation_operations.retry_fingerprint(p_response_artifact)));
  return premium_translation_private.catalog_operation_view(a);
end; $$;

create function premium_translation_private.assert_catalog_operation_promotion_current(
  d public.premium_translation_working_drafts,catalog_hash text,catalog_fields jsonb)
returns void language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;
begin
  -- Link by the actual draft UUID first. Altering its hash/version/body cannot
  -- downgrade a newly bound candidate into an unbound legacy candidate.
  -- Plain read avoids cache -> draft / draft -> cache lock inversion at FINISH.
  select * into a from premium_translation_private.catalog_operation_artifacts where linked_draft_id=d.id;
  if a.operation_id is null then return; end if;
  if a.final_receipt is null or a.entity_type is distinct from d.entity_type or a.entity_id is distinct from d.entity_id
    or a.linked_draft_version is distinct from d.version or a.candidate_hash is distinct from d.candidate_hash
    or a.source_hash is distinct from d.source_hash or a.source_snapshot is distinct from d.source_snapshot
    or a.source_revision is distinct from d.source_revision or a.target_revision is distinct from d.target_revision
    or a.candidate->'payload' is distinct from d.payload or a.candidate->'provenance' is distinct from d.provenance then
    raise exception 'Catalog linked candidate binding changed' using errcode='40001'; end if;
  if d.entity_type='country' and (catalog_fields is distinct from a.raw_seed->'catalogFields'
    or catalog_hash is distinct from a.source_revision->>'catalogSourceHash') then
    raise exception 'Catalog country source changed' using errcode='40001'; end if;
  perform premium_translation_private.catalog_operation_assert_current(a);
end; $$;


create or replace function public.promote_premium_translation_working_draft(p_entity_type text, p_entity_id text,
  p_draft_id uuid, p_expected_version bigint, p_candidate_hash text, p_source_hash text,
  p_catalog_source_hash text, p_catalog_source_fields jsonb, p_confirm_human_review boolean)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare actor uuid; candidate public.premium_translation_working_drafts%rowtype; review_time timestamptz;
  canonical_id uuid; canonical_updated_at timestamptz; en public.literary_work_translations%rowtype;
  country public.country_profile_overrides%rowtype; human jsonb; meta jsonb; english jsonb; next_fields jsonb; translations jsonb;
  catalog_translations jsonb; protected_english jsonb; writer public.writer_profile_overrides%rowtype;
  block public.homepage_blocks%rowtype; item jsonb; source_item jsonb; item_key text; machine jsonb; item_meta jsonb; idx integer;
begin
  actor := premium_translation_private.assert_actor();
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if p_confirm_human_review is distinct from true then raise exception using errcode='22023',message='Explicit human review is required'; end if;
  if (p_entity_type='writer_biography' and jsonb_typeof(p_catalog_source_fields) is distinct from 'object')
    or (p_entity_type in ('literary_work','site_copy') and p_catalog_source_fields is not null)
    or (p_entity_type='country' and (jsonb_typeof(p_catalog_source_fields) is distinct from 'object'
      or (p_catalog_source_fields ? 'translations' and jsonb_typeof(p_catalog_source_fields->'translations') is distinct from 'object'))) then
    raise exception using errcode='22023',message='Invalid current catalog shape';
  end if;
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  select * into candidate from public.premium_translation_working_drafts
    where entity_type=p_entity_type and entity_id=p_entity_id and target_locale='en' for update;
  if not found or candidate.id is distinct from p_draft_id or candidate.version is distinct from p_expected_version
    or candidate.candidate_hash is distinct from p_candidate_hash or candidate.source_hash is distinct from p_source_hash
    or (p_entity_type='writer_biography' and (
      candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash
      or candidate.source_snapshot->'catalogFields' is distinct from p_catalog_source_fields))
    or (p_entity_type in ('literary_work','site_copy') and p_catalog_source_hash is not null)
    or (p_entity_type='country' and candidate.source_revision->>'catalogSourceHash' is distinct from p_catalog_source_hash) then
    raise exception using errcode='40001',message='Candidate or source changed';
  end if;
  if p_entity_type in ('literary_work','country') then
    perform premium_translation_private.assert_catalog_operation_promotion_current(candidate,p_catalog_source_hash,p_catalog_source_fields);
  end if;
  perform premium_translation_private.assert_current(p_entity_type,p_entity_id,candidate.source_snapshot,
    candidate.source_revision,candidate.target_revision,candidate.payload);
  review_time := clock_timestamp();
  human := jsonb_build_object('status','approved','reviewedBy',actor,'reviewedAt',review_time);
  if p_entity_type='site_copy' then
    select * into block from public.homepage_blocks where id=p_entity_id::uuid;
    translations := block.settings->'siteCopy';
    english := case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
    meta := case when jsonb_typeof(block.settings->'premiumTranslation')='object' then block.settings->'premiumTranslation' else '{}'::jsonb end;
    machine := case when jsonb_typeof(meta->'siteCopyEn')='object' then meta->'siteCopyEn' else '{}'::jsonb end;
    for idx in 0..jsonb_array_length(candidate.payload->'items')-1 loop
      item := candidate.payload->'items'->idx; source_item := candidate.source_snapshot->'items'->idx; item_key := item->>'key';
      item_meta := coalesce(machine->item_key,'{}'::jsonb)||jsonb_build_object('sourceHash',source_item->'sourceHash',
        'provider',candidate.provenance->'provider','model',candidate.provenance->'translatorModel',
        'reviewerModel',candidate.provenance->'reviewerModel','generatedAt',candidate.provenance->'generatedAt',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
      machine := machine||jsonb_build_object(item_key,item_meta);
      english := english||jsonb_build_object(item_key,item->'text');
    end loop;
    next_fields := block.settings||jsonb_build_object('siteCopy',translations||jsonb_build_object('en',english),
      'premiumTranslation',meta||jsonb_build_object('siteCopyEn',machine));
    update public.homepage_blocks set settings=next_fields,updated_by=actor where id=block.id
      returning id,updated_at into canonical_id,canonical_updated_at;
  elsif p_entity_type='writer_biography' then
    select * into writer from public.writer_profile_overrides
      where country_id=candidate.source_revision->>'countryId' and writer_id=candidate.source_revision->>'writerId';
    next_fields := coalesce(writer.fields,'{}'::jsonb);
    translations := case when next_fields ? 'biographyTranslations' then next_fields->'biographyTranslations'
      else p_catalog_source_fields->'biographyTranslations' end;
    english := case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
    meta := case when jsonb_typeof(english->'translationMeta')='object' then english->'translationMeta' else '{}'::jsonb end;
    meta := meta||jsonb_build_object('provider',candidate.provenance->'provider','model',candidate.provenance->'translatorModel',
      'reviewerModel',candidate.provenance->'reviewerModel','sourceHash',candidate.source_hash,
      'generatedAt',candidate.provenance->'generatedAt','translatorRequestId',candidate.provenance->'translatorRequestId',
      'reviewerRequestId',candidate.provenance->'reviewerRequestId','humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    english := english||jsonb_build_object('locale','en','text',candidate.payload->'text','sourceLanguage','Russian',
      'status','reviewed','method','machine-translation','reviewedAt',to_char(review_time at time zone 'UTC','YYYY-MM-DD'),
      'reviewer',actor::text,'translatedFromLocale','ru','sourceTextRights','project-original',
      'sources',candidate.source_snapshot#>'{russianProfile,sources}','translationMeta',meta);
    next_fields := next_fields||jsonb_build_object('biographyTranslations',translations||jsonb_build_object('en',english));
    if writer.id is null then
      insert into public.writer_profile_overrides(country_id,writer_id,fields,updated_by)
        values(candidate.source_revision->>'countryId',candidate.source_revision->>'writerId',next_fields,actor)
        returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.writer_profile_overrides set fields=next_fields,updated_by=actor
        where id=writer.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  elsif p_entity_type='literary_work' then
    select * into en from public.literary_work_translations where id=(candidate.target_revision->>'id')::uuid;
    meta := case when jsonb_typeof(en.metadata)='object' then en.metadata else '{}'::jsonb end;
    meta := meta || jsonb_build_object('premiumTranslation',
      (case when jsonb_typeof(meta->'premiumTranslation')='object' then meta->'premiumTranslation' else '{}'::jsonb end)
      || jsonb_build_object('sourceHash',candidate.source_hash,'provider',candidate.provenance->'provider',
        'translatorModel',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'translatorRequestId',candidate.provenance->'translatorRequestId','reviewerRequestId',candidate.provenance->'reviewerRequestId',
        'generatedAt',candidate.provenance->'generatedAt','bibliographicTitle',candidate.payload->'bibliographicTitle',
        'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time));
    update public.literary_work_translations set description=candidate.payload->>'description',source_language='Russian',
      translation_method='machine-translation',editorial_status='reviewed',reviewed_at=review_time::date,
      source_urls=array(select jsonb_array_elements_text(candidate.payload->'sourceUrls')),metadata=meta
      where id=en.id returning id,updated_at into canonical_id,canonical_updated_at;
  else
    select * into country from public.country_profile_overrides where country_id=p_entity_id;
    next_fields := coalesce(country.fields,'{}'::jsonb);
    catalog_translations := case when jsonb_typeof(p_catalog_source_fields->'translations')='object'
      then p_catalog_source_fields->'translations' else '{}'::jsonb end;
    translations := case when next_fields ? 'translations' then next_fields->'translations' else catalog_translations end;
    if translations ? 'en' then protected_english := translations->'en';
    elsif catalog_translations ? 'en' then protected_english := catalog_translations->'en'; end if;
    if protected_english is not null and (protected_english->>'locale' is distinct from 'en'
      or protected_english->>'method' is distinct from 'machine-translation') then
      raise exception using errcode='40001',message='Manual catalog English is protected';
    end if;
    select coalesce(jsonb_object_agg(key,value),'{}'::jsonb) into meta from jsonb_each(candidate.payload->'fields')
      where value <> '""'::jsonb and value <> '[]'::jsonb;
    english := (case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end)
      || jsonb_build_object('locale','en','status','reviewed','method','machine-translation','sourceHash',candidate.source_hash,
        'generatedAt',candidate.provenance->'generatedAt','provider',candidate.provenance->'provider',
        'model',candidate.provenance->'translatorModel','reviewerModel',candidate.provenance->'reviewerModel',
        'fields',meta,'humanReview',human,'reviewedBy',actor,'reviewedAt',review_time);
    next_fields := next_fields || jsonb_build_object('translations',translations || jsonb_build_object('en',english));
    if country.id is null then
      insert into public.country_profile_overrides(country_id,fields,updated_by)
        values(p_entity_id,next_fields,actor) returning id,updated_at into canonical_id,canonical_updated_at;
    else
      update public.country_profile_overrides set fields=next_fields,updated_by=actor
        where id=country.id returning id,updated_at into canonical_id,canonical_updated_at;
    end if;
  end if;
  delete from public.premium_translation_working_drafts where id=candidate.id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(actor,'premium_translation.candidate.promoted',p_entity_type,p_entity_id,
      jsonb_build_object('draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
        'sourceHash',candidate.source_hash,'canonicalId',canonical_id,'outcome','promoted'));
  return jsonb_build_object('schemaVersion',1,'entityType',p_entity_type,'entityId',p_entity_id,'state','promoted',
    'draftId',candidate.id,'version',candidate.version,'candidateHash',candidate.candidate_hash,
    'canonicalId',canonical_id,'canonicalUpdatedAt',canonical_updated_at,'reviewedBy',actor,'reviewedAt',review_time);
exception when unique_violation then raise exception using errcode='40001',message='Canonical target changed concurrently';
end;
$$;

revoke all on function premium_translation_private.catalog_operation_identity(text,text) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_cursor_valid(text,jsonb) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_projection(jsonb,jsonb,text[]) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_capture(text,text,jsonb) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_expected_valid(text,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_configuration_valid(text,jsonb,text) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_source_valid(text,text,jsonb,jsonb,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_progress(jsonb) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_guard() from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_view(premium_translation_private.catalog_operation_artifacts,boolean,boolean,boolean) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_owned(uuid,uuid,uuid) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.catalog_operation_assert_current(premium_translation_private.catalog_operation_artifacts) from public,anon,authenticated,service_role;
revoke all on function premium_translation_private.assert_catalog_operation_promotion_current(public.premium_translation_working_drafts,text,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.catalog_translation_operation_ready() from public,anon,authenticated,service_role;
revoke all on function public.begin_catalog_translation_operation(uuid,uuid,uuid,text,text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.record_catalog_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text) from public,anon,authenticated,service_role;
revoke all on function public.record_catalog_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.finish_catalog_translation_operation(uuid,uuid,uuid,jsonb,jsonb) from public,anon,authenticated,service_role;
revoke all on function public.reconcile_catalog_translation_operation(text,text,uuid) from public,anon,authenticated,service_role;
revoke all on function public.get_catalog_translation_operation_artifacts(uuid,uuid,uuid,text,text,text,text) from public,anon,authenticated,service_role;
grant execute on function public.catalog_translation_operation_ready() to authenticated;
grant execute on function public.begin_catalog_translation_operation(uuid,uuid,uuid,text,text,text,text,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb,jsonb) to authenticated;
grant execute on function public.record_catalog_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text) to authenticated;
grant execute on function public.record_catalog_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb) to authenticated;
grant execute on function public.finish_catalog_translation_operation(uuid,uuid,uuid,jsonb,jsonb) to authenticated;
grant execute on function public.reconcile_catalog_translation_operation(text,text,uuid) to authenticated;
grant execute on function public.get_catalog_translation_operation_artifacts(uuid,uuid,uuid,text,text,text,text) to authenticated;

commit;

-- Synthetic local-only PG17 contract; never a production/provider operation.
-- Original book/country/writer/site-copy SQL and writer admission tests precede
-- this fixture. No old migration or private-draft DTO is rewritten.
reset role;
create table public.catalog_operation_fixture_results(label text primary key,value jsonb not null);
alter table public.catalog_operation_fixture_results enable row level security;
create policy catalog_operation_fixture_staff on public.catalog_operation_fixture_results for all to authenticated using(public.is_staff()) with check(public.is_staff());
grant select,insert,update on public.catalog_operation_fixture_results to authenticated;
create function public.catalog_fixture_compact_json(v jsonb)
returns text language plpgsql immutable set search_path='' as $$
declare result text;
begin
 if jsonb_typeof(v)='array' then select '['||coalesce(string_agg(public.catalog_fixture_compact_json(value),',' order by n),'')||']' into result from jsonb_array_elements(v) with ordinality x(value,n);return result;
 elsif jsonb_typeof(v)='object' then select '{'||coalesce(string_agg(to_jsonb(key)::text||':'||public.catalog_fixture_compact_json(value),',' order by array_position(array['year','title','description'],key),key),'')||'}' into result from jsonb_each(v);return result;
 else return v::text;end if;
end; $$;
create function public.catalog_fixture_hash(k text,s jsonb)
returns text language plpgsql immutable set search_path='' as $$
declare keys text[]; result text;
begin
 keys:=case k when 'literary_work' then array['russianTitle','verifiedEnglishTitle','verifiedEnglishTitleSourceUrl','description','originalTitle','firstPublished','originalLanguage','sourceLanguage','sourceUrls']
 else array['name','region','continent','officialLanguage','capital','description','history','historicalNote','literaryPeriods','literaryMovements','periods','facts','literaryPlaces','timeline','chronology'] end;
 select '{'||string_agg(to_jsonb(key)::text||':'||public.catalog_fixture_compact_json(s->key),',' order by n)||'}' into result from unnest(keys) with ordinality x(key,n);
 return encode(sha256(convert_to(result,'UTF8')),'hex');
end; $$;
create function public.catalog_fixture_config(k text,review boolean)
returns jsonb language sql immutable set search_path='' as $$
 select public.writer_operation_fixture_config()||jsonb_build_object('schemaName',case k when 'literary_work' then 'probpera_literary_work_translation' else 'probpera_country_profile_translation' end,
  'maxOutputTokens',case k when 'literary_work' then 4000 else 12000 end,'twoPassReview',review);
$$;
create function public.catalog_fixture_seed(k text,tag text,review boolean default true)
returns jsonb language plpgsql security definer set search_path='' as $$
declare identity text; wid uuid; args jsonb; expected jsonb; raw_catalog jsonb; country_id text;
 w public.literary_works%rowtype; ru public.literary_work_translations%rowtype; en public.literary_work_translations%rowtype; c public.country_profile_overrides%rowtype;
begin
 if k='literary_work' then
  wid:=gen_random_uuid();identity:=wid::text;
  insert into public.literary_works(id,legacy_id,country_id,writer_id,title,slug,original_title,first_published,original_language,editorial_status,metadata,updated_at)
   values(wid,'native-'||wid,'fixture-country','fixture-writer','Исходное название','native-'||wid,'Original title',1900,'Russian','reviewed','{"rights":{"owner":"AUTHOR"},"exact":[null,"keep"]}','2026-10-01T10:00:00.123456Z');
  insert into public.literary_work_translations(work_id,locale,title,description,source_language,translation_method,editorial_status,source_urls,reviewed_at,metadata,updated_at)
   values(wid,'ru','Русское название','Русское авторское описание сохраняет все исходные литературные сведения и последовательность повествования. Права, лицензии источников и авторские уточнения должны сохраняться без изменений.','Russian','editorial-original','reviewed',array['https://fixture.test/ru'],'2026-10-01','{"rights":"RU AUTHOR EXACT"}','2026-10-01T10:00:00.123457Z'),
   (wid,'en','Exact Verified English Title','The retained English literary description preserves its documented setting and the original narrative sequence. Its sources, rights and editorial qualifications remain available for human review.','Russian','machine-translation','reviewed',array['https://fixture.test/title','https://fixture.test/ru'],'2026-10-01',
    '{"rights":"EN AUTHOR EXACT","premiumTranslation":{"bibliographicTitle":{"value":"Exact Verified English Title","sourceUrl":"https://fixture.test/title"}}}','2026-10-01T10:00:00.123458Z');
  insert into public.literary_work_sources(work_id,provider,source_url,field_names,license_name,usage,retrieved_at,metadata)
   values(wid,'verified-bibliography','https://fixture.test/title',array['title'],'ORIGINAL SOURCE LICENCE','reference-only','2026-10-08','{"rights":{"permission":"KEEP EXACT"}}');
  select * into w from public.literary_works where id=wid;
  select * into ru from public.literary_work_translations where work_id=wid and locale='ru';
  select * into en from public.literary_work_translations where work_id=wid and locale='en';
  args:=public.premium_fixture_args(k,identity);
  expected:=jsonb_build_object('version',1,'work',jsonb_build_object('id',w.id,'title',w.title,'original_title',w.original_title,'first_published',w.first_published,'original_language',w.original_language,'editorial_status',w.editorial_status,'updated_at',w.updated_at),
   'russian',jsonb_build_object('id',ru.id,'title',ru.title,'description',ru.description,'source_language',ru.source_language,'source_urls',ru.source_urls,'editorial_status',ru.editorial_status,'updated_at',ru.updated_at,'metadata',ru.metadata),
   'english',jsonb_build_object('id',en.id,'title',en.title,'description',en.description,'source_urls',en.source_urls,'translation_method',en.translation_method,'editorial_status',en.editorial_status,'updated_at',en.updated_at,'metadata',en.metadata),
   'titleSource',jsonb_build_object('provider','verified-bibliography','source_url','https://fixture.test/title','retrieved_at','2026-10-08'));
 else
  identity:='catalog-'||tag;
  args:=public.premium_fixture_args(k,'fixture-country');raw_catalog:=args->'source'||'{"rights":{"catalog":"KEEP RAW CATALOG RIGHTS"},"translations":{"fr":{"locale":"fr","text":"Texte exact"}}}';
  insert into public.country_profile_overrides(country_id,fields,updated_at) values(identity,raw_catalog||jsonb_build_object('rights','RAW OVERRIDE RIGHTS',
   'translations',jsonb_build_object('fr',jsonb_build_object('locale','fr','text','Exact private French'),
    'en',jsonb_build_object('locale','en','method','machine-translation','status','reviewed','sourceHash',repeat('0',64),'fields',args#>'{payload,fields}','rights','KEEP RAW EN RIGHTS'))),'2026-10-01T10:00:00.123456Z') returning * into c;
  args:=public.premium_fixture_args(k,identity);
  expected:=jsonb_build_object('version',1,'catalogFields',raw_catalog,'override',jsonb_build_object('id',c.id,'fields',c.fields,'updated_at',c.updated_at));
 end if;
 return args||jsonb_build_object('entityType',k,'entityId',identity,'sourceHash',public.catalog_fixture_hash(k,args->'source'),
  'expectedState',expected,'configuration',public.catalog_fixture_config(k,review),'currentCursor',jsonb_build_object(case k when 'literary_work' then 'libraryCursor' else 'countryCursor' end,6),
  'resumeCursor',jsonb_build_object(case k when 'literary_work' then 'libraryCursor' else 'countryCursor' end,7));
end; $$;
create function public.catalog_fixture_begin(a jsonb)
returns jsonb language sql set search_path='' as $$
 select public.begin_catalog_translation_operation(gen_random_uuid(),gen_random_uuid(),gen_random_uuid(),a->>'entityType',a->>'entityId','cloudflare',a->>'sourceHash',
  a->'source',a->'sourceRevision',a->'targetRevision',a->'expectedState',a->'configuration',a->'currentCursor',a->'resumeCursor');
$$;
create function public.catalog_fixture_artifact(r jsonb)
returns jsonb language sql set search_path='' as $$ select public.get_catalog_translation_operation_artifacts((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,
 r->>'entityType',r->>'entityId',r->>'intentHash',r->>'sourceHash'); $$;
create function public.catalog_fixture_pass(r jsonb,pass text,payload jsonb)
returns jsonb language plpgsql set search_path='' as $$ declare d jsonb; metadata jsonb;begin
 d:=public.record_catalog_translation_operation_dispatch((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,gen_random_uuid(),'cloudflare',
  case pass when 'translation' then 'fixture-translator' else 'fixture-reviewer' end,pass,repeat('c',64));
 metadata:=jsonb_build_object('callId',d->'pendingCallId','provider','cloudflare','model',case pass when 'translation' then 'fixture-translator' else 'fixture-reviewer' end,
  'pass',pass,'httpStatus',null,'requestId',null,'responseId',case pass when 'translation' then 'native-translation' else 'native-editorial' end,'inputTokens',5,'outputTokens',6);
 return public.record_catalog_translation_operation_response((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,metadata,
   jsonb_build_object('version',1,'body',jsonb_build_object('response',(case r->>'entityType' when 'literary_work' then jsonb_build_object('description',payload->'description') else payload->'fields' end)::text)));
end; $$;
create function public.catalog_fixture_finish(r jsonb,payload jsonb)
returns jsonb language plpgsql set search_path='' as $$ declare a jsonb; calls jsonb; first jsonb; last jsonb; candidate jsonb; n integer;begin
 a:=public.catalog_fixture_artifact(r);calls:=a->'calls';n:=jsonb_array_length(calls);first:=calls->0->'metadata';last:=calls->(n-1)->'metadata';
 candidate:=jsonb_build_object('payload',payload,'provenance',jsonb_build_object('provider','cloudflare','translatorModel',first->'model',
   'reviewerModel',case when n=1 then 'null'::jsonb else last->'model' end,'translatorRequestId',first->'responseId',
   'reviewerRequestId',case when n=1 then 'null'::jsonb else last->'responseId' end,
   'generatedAt',to_char((last->>'responseReceivedAt')::timestamptz at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')),
  'translatorCallId',first->'callId','reviewerCallId',case when n=1 then 'null'::jsonb else last->'callId' end);
 return public.finish_catalog_translation_operation((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,
   jsonb_build_object('status','succeeded','providerCalls',n,'model','fixture-translator'),candidate);
end; $$;
do $$ declare k text; args jsonb; r jsonb; done jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach k in array array['literary_work','country'] loop
  args:=public.catalog_fixture_seed(k,'normal-'||k,true);
  set local role authenticated;
  assert public.catalog_translation_operation_ready() is true;
  r:=public.catalog_fixture_begin(args);assert r->'canExecute'='true'::jsonb;
  r:=public.catalog_fixture_pass(r,'translation',args->'payload');r:=public.catalog_fixture_pass(r,'review',args->'payload');
  done:=public.catalog_fixture_finish(r,args->'payload');assert done#>>'{result,state}'='translated' and done#>>'{result,persistence}'='working-draft';
  assert done->'resumeCursor'=args->'resumeCursor';
  insert into public.catalog_operation_fixture_results values('normal-'||k,jsonb_build_object('args',args,'receipt',done,'artifact',public.catalog_fixture_artifact(done)));
  reset role;
 end loop;
end; $$;
select 'M07_CATALOG_INITIAL_PASS';

create function public.catalog_fixture_approve(r jsonb,p_catalog_fields jsonb default null)
returns jsonb language plpgsql set search_path='' as $$ declare d jsonb; catalog jsonb;begin
 d:=public.get_premium_translation_working_draft(r->>'entityType',r->>'entityId')->'draft';
 if r->>'entityType'='country' then catalog:=coalesce(p_catalog_fields,public.catalog_fixture_artifact(r)#>'{rawSeed,catalogFields}');end if;
 return public.promote_premium_translation_working_draft(r->>'entityType',r->>'entityId',(d->>'id')::uuid,(d->>'version')::bigint,
  d->>'candidateHash',d->>'sourceHash',case r->>'entityType' when 'country' then d#>>'{sourceRevision,catalogSourceHash}' else null end,catalog,true);
end; $$;
-- Optional review remains optional: one translation or translation+repair.
-- The configured repair model stays non-null; actual reviewer provenance does
-- not claim a pass that never ran. Old writer admission still requires review.
do $$ declare k text; repair boolean; args jsonb; r jsonb; done jsonb; artifact jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach k in array array['literary_work','country'] loop
  foreach repair in array array[false,true] loop
   args:=public.catalog_fixture_seed(k,'optional-'||k||'-'||repair,false);
   set local role authenticated;
   r:=public.catalog_fixture_begin(args);r:=public.catalog_fixture_pass(r,'translation',args->'payload');
   if repair then r:=public.catalog_fixture_pass(r,'repair',args->'payload');end if;
   done:=public.catalog_fixture_finish(r,args->'payload');artifact:=public.catalog_fixture_artifact(done);
   assert done#>>'{result,state}'='translated';
   if not repair then
    assert done->'providerCalls'='1'::jsonb and artifact#>'{candidate,reviewerCallId}'='null'::jsonb and artifact#>'{candidate,provenance,reviewerModel}'='null'::jsonb;
   else assert done->'providerCalls'='2'::jsonb and artifact#>>'{candidate,provenance,reviewerModel}'='fixture-reviewer';end if;
   insert into public.catalog_operation_fixture_results values('optional-'||k||'-'||repair,jsonb_build_object('receipt',done,'artifact',artifact));
   reset role;
  end loop;
 end loop;
end; $$;

-- The full raw title-source licence/metadata inventory is independent of all
-- master timestamps and old title projections. A NEW linked draft must refuse
-- approval both before FINISH and after it. Canonical rows/builds stay exact.
do $$ declare mode text; args jsonb; r jsonb; done jsonb; before_master jsonb; after_master jsonb; before_outbox bigint;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach mode in array array['before-finish','after-finish'] loop
  args:=public.catalog_fixture_seed('literary_work','licence-'||mode,true);
  set local role authenticated;
  r:=public.catalog_fixture_begin(args);r:=public.catalog_fixture_pass(r,'translation',args->'payload');r:=public.catalog_fixture_pass(r,'review',args->'payload');
  if mode='after-finish' then done:=public.catalog_fixture_finish(r,args->'payload');end if;
  reset role;
  select jsonb_build_object('work',to_jsonb(w),'ru',to_jsonb(ru),'en',to_jsonb(en)) into before_master
   from public.literary_works w join public.literary_work_translations ru on ru.work_id=w.id and ru.locale='ru'
   join public.literary_work_translations en on en.work_id=w.id and en.locale='en' where w.id=(r->>'entityId')::uuid;
  update public.literary_work_sources set license_name='CHANGED SOURCE LICENCE ONLY',metadata='{"rights":{"permission":"NEW SOURCE CONDITIONS"}}' where work_id=(r->>'entityId')::uuid;
  select jsonb_build_object('work',to_jsonb(w),'ru',to_jsonb(ru),'en',to_jsonb(en)) into after_master
   from public.literary_works w join public.literary_work_translations ru on ru.work_id=w.id and ru.locale='ru'
   join public.literary_work_translations en on en.work_id=w.id and en.locale='en' where w.id=(r->>'entityId')::uuid;
  assert before_master=after_master,'Licence-only change must leave work/RU/EN INCLUDING timestamps exact';
  select count(*) into before_outbox from public.premium_fixture_outbox;
  set local role authenticated;
  if mode='before-finish' then done:=public.catalog_fixture_finish(r,args->'payload');assert done#>>'{result,state}'='stale';end if;
  assert done#>>'{result,persistence}'='working-draft' and public.catalog_fixture_artifact(done)->'candidate'<>'null'::jsonb;
  perform public.premium_fixture_error(format('select public.catalog_fixture_approve(%L::jsonb)',done::text),'40001');
  reset role;
  assert (select jsonb_build_object('work',to_jsonb(w),'ru',to_jsonb(ru),'en',to_jsonb(en))=after_master from public.literary_works w
   join public.literary_work_translations ru on ru.work_id=w.id and ru.locale='ru' join public.literary_work_translations en on en.work_id=w.id and en.locale='en' where w.id=(r->>'entityId')::uuid);
  assert (select count(*)=before_outbox from public.premium_fixture_outbox);
  insert into public.catalog_operation_fixture_results values('linked-licence-'||mode,jsonb_build_object('receipt',done,'masterRowsAndTimestampsExact',before_master=after_master,'artifact',public.catalog_fixture_artifact(done)));
 end loop;
end; $$;

-- A different catalogue JSON must not slip through by supplying its old hash.
-- Full canonical override/map drift is retained privately and never approved.
do $$ declare mode text; args jsonb; r jsonb; done jsonb; fields jsonb; before_row jsonb; before_outbox bigint;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach mode in array array['catalog','override','manual'] loop
  args:=public.catalog_fixture_seed('country','drift-'||mode,true);
  set local role authenticated;
  r:=public.catalog_fixture_begin(args);r:=public.catalog_fixture_pass(r,'translation',args->'payload');r:=public.catalog_fixture_pass(r,'review',args->'payload');
  reset role;
  if mode='override' then update public.country_profile_overrides c set fields=jsonb_set(c.fields,'{rights}','"NEW OVERRIDE RIGHTS"') where country_id=r->>'entityId';
  elsif mode='manual' then update public.country_profile_overrides c set fields=jsonb_set(c.fields,'{translations,en,method}','"human-translation"') where country_id=r->>'entityId';end if;
  select to_jsonb(c) into before_row from public.country_profile_overrides c where country_id=r->>'entityId';
  select count(*) into before_outbox from public.premium_fixture_outbox;
  fields:=args#>'{expectedState,catalogFields}';if mode='catalog' then fields:=jsonb_set(fields,'{rights}','{"catalog":"NEW CATALOG RIGHTS"}');end if;
  set local role authenticated;
  done:=public.catalog_fixture_finish(r,args->'payload');assert done#>>'{result,persistence}'='working-draft';
  if mode<>'catalog' then assert done#>>'{result,state}'='conflict';end if;
  perform public.premium_fixture_error(format('select public.catalog_fixture_approve(%L::jsonb,%L::jsonb)',done::text,fields::text),'40001');
  reset role;
  assert (select to_jsonb(c)=before_row from public.country_profile_overrides c where country_id=r->>'entityId');
  assert (select count(*)=before_outbox from public.premium_fixture_outbox);
  insert into public.catalog_operation_fixture_results values('country-'||mode||'-drift',jsonb_build_object('receipt',done,'canonicalExact',true));
 end loop;
end; $$;

-- Link by UUID first: changed version/hash/payload/provenance must never turn a
-- new candidate into a weaker legacy candidate. Unlinked legacy drafts retain
-- the existing explicit-review path; all original branch bytes are preserved.
do $$ declare mode text; args jsonb; r jsonb; done jsonb; d public.premium_translation_working_drafts%rowtype; original public.premium_translation_working_drafts%rowtype;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 args:=public.catalog_fixture_seed('literary_work','tamper',true);
 set local role authenticated;
 r:=public.catalog_fixture_begin(args);r:=public.catalog_fixture_pass(r,'translation',args->'payload');r:=public.catalog_fixture_pass(r,'review',args->'payload');done:=public.catalog_fixture_finish(r,args->'payload');
 reset role;
 select * into original from public.premium_translation_working_drafts where id=(done#>>'{result,draftId}')::uuid;
 foreach mode in array array['version','hash','payload','provenance'] loop
  update public.premium_translation_working_drafts set version=case mode when 'version' then 2 else original.version end,
   candidate_hash=case mode when 'hash' then repeat('f',64) else original.candidate_hash end,
   payload=case mode when 'payload' then jsonb_set(original.payload,'{description}',to_jsonb('Tampered payload with a fresh public receipt. Source and licence approval must still fail for this linked private candidate.'::text)) else original.payload end,
   provenance=case mode when 'provenance' then jsonb_set(original.provenance,'{translatorModel}','"TAMPERED MODEL"') else original.provenance end where id=original.id;
  set local role authenticated;
  perform public.premium_fixture_error(format('select public.catalog_fixture_approve(%L::jsonb)',done::text),'40001');
  reset role;
 end loop;
 update public.premium_translation_working_drafts set version=original.version,candidate_hash=original.candidate_hash,payload=original.payload,provenance=original.provenance where id=original.id;
 args:=public.catalog_fixture_seed('literary_work','legacy',true);
 set local role authenticated;
 r:=public.premium_fixture_stage(args)->'draft';
 assert public.premium_fixture_promote(r)->>'state'='promoted';
 reset role;
 insert into public.catalog_operation_fixture_results values('linked-tamper-and-unlinked-legacy','true');
end; $$;
select 'M07_CATALOG_BINDING_PASS';

do $$ declare k text; args jsonb; r jsonb; done jsonb; artifact jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach k in array array['literary_work','country'] loop
  args:=public.catalog_fixture_seed(k,'positive-'||k,true);
  set local role authenticated;
  r:=public.catalog_fixture_begin(args);r:=public.catalog_fixture_pass(r,'translation',args->'payload');r:=public.catalog_fixture_pass(r,'review',args->'payload');done:=public.catalog_fixture_finish(r,args->'payload');
  assert public.catalog_fixture_approve(done)->>'state'='promoted';
  assert public.catalog_fixture_artifact(done)->'candidate'<>'null'::jsonb;
  insert into public.catalog_operation_fixture_results values('new-linked-positive-'||k,done);
  reset role;
 end loop;
 -- The existing writer protocol runs under the new triggers and promotion
 -- function with its original forced-review contract and cache untouched.
 set local role authenticated;
 r:=public.writer_operation_fixture_begin('catalog-compat-writer');
 r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'translation'));
 r:=public.writer_operation_fixture_response(public.writer_operation_fixture_dispatch(r,'review'));
 done:=public.writer_operation_fixture_finish(r);assert done#>>'{result,state}'='translated';
 reset role;
 insert into public.catalog_operation_fixture_results values('writer-api-compatibility',done);
end; $$;

-- Unknown dispatch survives new source/provider/actor/UUID, cancellation and
-- native direct mutation attempts. Raw received output is not a candidate.
do $$ declare k text; args jsonb; r jsonb; d jsonb; other jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach k in array array['literary_work','country'] loop
  args:=public.catalog_fixture_seed(k,'unknown-'||k,true);
  set local role authenticated;
  r:=public.catalog_fixture_begin(args);
  d:=public.record_catalog_translation_operation_dispatch((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,gen_random_uuid(),'cloudflare','fixture-translator','translation',repeat('c',64));
  assert public.catalog_fixture_begin(args)->>'operationId'=r->>'operationId';
  assert public.catalog_fixture_begin(args)->>'blockReason'='provider_outcome_unknown';
  other:=args||jsonb_build_object('sourceHash',repeat('f',64),'configuration',(args->'configuration')||'{"provider":"openai","model":"other-model"}');
  other:=public.begin_catalog_translation_operation(gen_random_uuid(),gen_random_uuid(),gen_random_uuid(),k,args->>'entityId','openai',repeat('f',64),
   args->'source',args->'sourceRevision',args->'targetRevision',args->'expectedState',other->'configuration',args->'currentCursor',args->'resumeCursor');
  assert other->>'operationId'=r->>'operationId' and other->'canExecute'='false'::jsonb;
  perform public.premium_fixture_error(format('select public.finish_catalog_translation_operation(%L,%L,%L,''{"status":"dead_letter","providerCalls":1,"errorCode":"provider_request_failed"}'')',r->>'jobId',r->>'itemId',r->>'operationId'),'40001');
  perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
  assert public.catalog_fixture_begin(args)->>'blockReason'='operation_owned_by_another_actor';
  perform public.premium_fixture_error(format('select public.catalog_fixture_artifact(%L::jsonb)',r::text),'42501');
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  perform public.request_translation_job_cancel((r->>'jobId')::uuid,(r->>'jobVersion')::bigint);
  other:=public.reconcile_catalog_translation_operation(k,args->>'entityId');
  assert other->>'blockReason'='provider_outcome_unknown' and other->'resumeCursor'=args->'currentCursor';
  insert into public.catalog_operation_fixture_results values('unknown-'||k,jsonb_build_object('receipt',other,'artifact',public.catalog_fixture_artifact(other)));
  reset role;
 end loop;
end; $$;
set role authenticated;
select public.premium_fixture_error('update public.translation_job_items set staff_retry=null','42501');
select public.premium_fixture_error('select * from premium_translation_private.catalog_operation_artifacts','42501');
reset role;
set role service_role;
select public.premium_fixture_error($q$update public.translation_job_items set staff_retry=null where staff_retry->>'protocol'='catalog-translation'$q$,'42501');
select public.premium_fixture_error($q$update public.translation_job_items set entity_id='tampered' where staff_retry->>'protocol'='catalog-translation'$q$,'42501');
select public.premium_fixture_error($q$delete from public.translation_jobs where resume_cursor ? 'catalogOperation'$q$,'42501');
select public.premium_fixture_error('select * from premium_translation_private.catalog_operation_artifacts','42501');
reset role;
insert into public.catalog_operation_fixture_results values('native-auth-service-tamper','true');

-- Confirmed zero-call cleanup preserves CURRENT cursor. Cancellation after
-- complete response retains valid pending output and cancellation semantics.
do $$ declare k text; args jsonb; r jsonb; done jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach k in array array['literary_work','country'] loop
  args:=public.catalog_fixture_seed(k,'zero-'||k,true);
  set local role authenticated;r:=public.catalog_fixture_begin(args);
  done:=public.finish_catalog_translation_operation((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,'{"status":"skipped","providerCalls":0}');
  assert done->'resumeCursor'=args->'currentCursor';
  insert into public.catalog_operation_fixture_results values('zero-current-'||k,done);reset role;
  args:=public.catalog_fixture_seed(k,'cancel-complete-'||k,true);
  set local role authenticated;r:=public.catalog_fixture_begin(args);r:=public.catalog_fixture_pass(r,'translation',args->'payload');r:=public.catalog_fixture_pass(r,'review',args->'payload');
  perform public.request_translation_job_cancel((r->>'jobId')::uuid,(r->>'jobVersion')::bigint);
  done:=public.catalog_fixture_finish(r,args->'payload');
  assert done#>>'{result,state}'='cancelled' and done#>>'{result,persistence}'='working-draft' and done#>>'{result,humanReview}'='pending';
  insert into public.catalog_operation_fixture_results values('cancel-complete-'||k,done);reset role;
 end loop;
end; $$;

do $$ declare k text; args jsonb; r jsonb; prior jsonb; done jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach k in array array['literary_work','country'] loop
  args:=public.catalog_fixture_seed(k,'slot-'||k,true);
  set local role authenticated;r:=public.catalog_fixture_begin(args);r:=public.catalog_fixture_pass(r,'translation',args->'payload');r:=public.catalog_fixture_pass(r,'review',args->'payload');
  prior:=public.premium_fixture_stage(args)->'draft';done:=public.catalog_fixture_finish(r,args->'payload');
  assert done#>>'{result,persistence}'='private-artifact' and done#>'{result,draftId}'='null'::jsonb and done#>'{result,draftVersion}'='null'::jsonb and done#>'{result,draftUpdatedAt}'='null'::jsonb;
  assert public.get_premium_translation_working_draft(k,args->>'entityId')->'draft'=prior;
  assert public.catalog_fixture_artifact(done)->'candidate'<>'null'::jsonb;
  insert into public.catalog_operation_fixture_results values('pending-slot-'||k,done);reset role;
 end loop;
end; $$;

-- Hard limits fail closed before mutation; the oversized server row is NOT in
-- the expected client projection. Received/oversized bodies never masquerade
-- as acknowledged successful output or grant another dispatch.
do $$ declare args jsonb; r jsonb; d jsonb; count_before bigint; metadata jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 args:=public.catalog_fixture_seed('literary_work','server-oversize',true);
 update public.literary_work_sources set metadata=jsonb_build_object('rights',repeat('x',4194304)) where work_id=(args->>'entityId')::uuid;
 select count(*) into count_before from public.translation_jobs;
 set local role authenticated;perform public.premium_fixture_error(format('select public.catalog_fixture_begin(%L::jsonb)',args::text),'22023');reset role;
 assert (select count(*)=count_before from public.translation_jobs);
 args:=public.catalog_fixture_seed('country','response-oversize',true);
 set local role authenticated;r:=public.catalog_fixture_begin(args);
 d:=public.record_catalog_translation_operation_dispatch((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,gen_random_uuid(),'cloudflare','fixture-translator','translation',repeat('c',64));
 metadata:=jsonb_build_object('callId',d->'pendingCallId','provider','cloudflare','model','fixture-translator','pass','translation','httpStatus',null,'requestId',null,'responseId',null,'inputTokens',null,'outputTokens',null);
 perform public.premium_fixture_error(format('select public.record_catalog_translation_operation_response(%L,%L,%L,%L::jsonb,%L::jsonb)',
  r->>'jobId',r->>'itemId',r->>'operationId',metadata::text,jsonb_build_object('version',1,'body',repeat('x',1048576))::text),'22023');
 assert public.catalog_fixture_artifact(r)#>'{calls,0,metadata,responseReceivedAt}'='null'::jsonb;
 insert into public.catalog_operation_fixture_results values('oversize-source-response',jsonb_build_object('sourceOrphanJobs',0,'responseStillUnknown',true));
 reset role;
end; $$;

set role anon;select public.premium_fixture_error('select public.catalog_translation_operation_ready()','42501');reset role;
set role authenticated;
select set_config('request.jwt.claim.sub','',false);select public.premium_fixture_error('select public.catalog_translation_operation_ready()','42501');
select set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',false);select public.premium_fixture_error('select public.catalog_translation_operation_ready()','42501');
reset role;
do $$ begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 alter table public.translation_job_items disable trigger translation_items_catalog_integrity;assert public.catalog_translation_operation_ready() is false;
 alter table public.translation_job_items enable trigger translation_items_catalog_integrity;
 alter function public.reconcile_catalog_translation_operation(text,text,uuid) rename to catalog_fixture_missing_reconcile;
 assert public.catalog_translation_operation_ready() is false;
 alter function public.catalog_fixture_missing_reconcile(text,text,uuid) rename to reconcile_catalog_translation_operation;
 assert public.catalog_translation_operation_ready() is true;
 assert not exists(select 1 from public.translation_job_items where staff_retry->>'protocol'='catalog-translation' and (staff_retry::text like '%RU AUTHOR EXACT%' or staff_retry::text like '%ORIGINAL SOURCE LICENCE%'));
 assert not exists(select 1 from public.translation_job_attempts where staff_retry_receipt::text like '%ORIGINAL SOURCE LICENCE%');
 assert not has_function_privilege('authenticated','public.claim_translation_job_items(text,integer,integer)','EXECUTE');
 assert not has_function_privilege('authenticated','public.complete_translation_job_item(uuid,text,boolean,text,text,text,integer,integer,integer)','EXECUTE');
 insert into public.catalog_operation_fixture_results values('ready-privacy-unchanged-lease-boundary','true');
end; $$;
select 'M07_CATALOG_FULL_PASS';

do $$ declare args jsonb; r jsonb; a jsonb; call jsonb; replay jsonb; bad jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 args:=public.catalog_fixture_seed('literary_work','replay',true);
 set local role authenticated;
 r:=public.catalog_fixture_begin(args);r:=public.catalog_fixture_pass(r,'translation',args->'payload');
 a:=public.catalog_fixture_artifact(r);call:=a->'calls'->0;
 replay:=public.record_catalog_translation_operation_dispatch((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,
  (call#>>'{metadata,callId}')::uuid,'cloudflare','fixture-translator','translation',call->>'requestHash');
 assert replay->'canDispatch'='false'::jsonb and replay->'replayed'='true'::jsonb;
 replay:=public.record_catalog_translation_operation_response((r->>'jobId')::uuid,(r->>'itemId')::uuid,(r->>'operationId')::uuid,
  (call->'metadata')-array['dispatchRecordedAt','responseReceivedAt'],call->'responseArtifact');
 assert replay->'replayed'='true'::jsonb and replay->'providerCalls'='1'::jsonb;
 r:=public.catalog_fixture_pass(r,'review',args->'payload');
 bad:=args->'payload'||jsonb_build_object('description',repeat('x',1048576));
 perform public.premium_fixture_error(format('select public.catalog_fixture_finish(%L::jsonb,%L::jsonb)',r::text,bad::text),'22023');
 assert public.catalog_fixture_artifact(r)->'candidate'='null'::jsonb;
 replay:=public.catalog_fixture_finish(r,args->'payload');
 assert public.catalog_fixture_finish(r,args->'payload')->'result'=replay->'result';
 assert (select count(*)=1 from public.translation_job_attempts where item_id=(r->>'itemId')::uuid);
 insert into public.catalog_operation_fixture_results values('ack-replay-candidate-limit-one-attempt',replay);
 reset role;
end; $$;
select 'M07_CATALOG_FINAL_PASS';

-- Staff metadata-only freshness for new linked book/country candidates.
-- Legacy drafts retain their existing review checks and exact text identity.
-- Existing atomic promotion, seven admission RPCs and writer/site-copy stay
-- byte-unchanged. This read returns only a snapshot freshness gate.
create function public.get_catalog_translation_candidate_freshness(
  p_entity_type text,p_entity_id text,p_draft_id uuid,p_expected_version bigint,
  p_candidate_hash text,p_source_hash text,p_catalog_source_hash text default null,
  p_catalog_source_fields jsonb default null
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare actor uuid; d public.premium_translation_working_drafts%rowtype; linked boolean:=false; envelope jsonb;
begin
  actor:=premium_translation_private.assert_actor();
  if p_entity_type is null or p_entity_type not in ('literary_work','country') then
    raise exception 'Unsupported catalog candidate freshness identity' using errcode='22023'; end if;
  -- Preserve legacy textual UUID case: the old private candidate/promote lookup
  -- uses exact entity_id text. No lower()/normalization of legacy identities.
  perform premium_translation_private.assert_identity(p_entity_type,p_entity_id);
  if not probpera_translation_operations.retry_uuid(p_draft_id) or p_expected_version is null
    or p_expected_version not between 1 and 9007199254740991
    or p_candidate_hash is null or p_candidate_hash !~ '^[a-f0-9]{64}$'
    or p_source_hash is null or p_source_hash !~ '^[a-f0-9]{64}$'
    or (p_entity_type='literary_work' and (p_catalog_source_hash is not null or p_catalog_source_fields is not null))
    or (p_entity_type='country' and (p_catalog_source_hash is null or p_catalog_source_hash !~ '^[a-f0-9]{64}$'
      or jsonb_typeof(p_catalog_source_fields) is distinct from 'object'
      or (p_catalog_source_fields ? 'translations' and jsonb_typeof(p_catalog_source_fields->'translations') is distinct from 'object'))) then
    raise exception 'Invalid catalog candidate freshness request' using errcode='22023'; end if;
  envelope:=jsonb_build_object('version',1,'entityType',p_entity_type,'entityId',p_entity_id,'draftId',p_draft_id,
    'draftVersion',p_expected_version,'candidateHash',p_candidate_hash,'sourceHash',p_source_hash);
  perform pg_advisory_xact_lock(hashtextextended('premium-translation:'||p_entity_type||':'||p_entity_id,0));
  -- Actual draft UUID first; no entity-history or hash-only fallback.
  select * into d from public.premium_translation_working_drafts where id=p_draft_id for share;
  if d.id is null then
    return envelope||jsonb_build_object('linked',false,'canPromote',false,'reason','candidate_missing'); end if;
  if d.entity_type is distinct from p_entity_type or d.entity_id is distinct from p_entity_id then
    return envelope||jsonb_build_object('linked',false,'canPromote',false,'reason','candidate_changed'); end if;
  select exists(select 1 from premium_translation_private.catalog_operation_artifacts where linked_draft_id=d.id) into linked;
  if d.version is distinct from p_expected_version or d.candidate_hash is distinct from p_candidate_hash or d.source_hash is distinct from p_source_hash then
    return envelope||jsonb_build_object('linked',linked,'canPromote',false,'reason','candidate_changed'); end if;
  if not linked then
    -- Only this complete triple is a confirmed legacy passthrough. Existing
    -- review-domain checks still apply; this is not an approval authorization.
    return envelope||jsonb_build_object('linked',false,'canPromote',true,'reason',null); end if;
  begin
    -- Existing guard compares complete stored server rows/licences and fresh
    -- country catalogue, with the same canonical lock order as atomic promote.
    -- It reads completed cache without a row lock, avoiding FINISH inversion.
    perform premium_translation_private.assert_catalog_operation_promotion_current(d,p_catalog_source_hash,p_catalog_source_fields);
  exception when serialization_failure then
    -- source_changed means recorded source/candidate context is no longer
    -- intact. Other DB errors are deliberately NOT mislabeled as stale.
    return envelope||jsonb_build_object('linked',true,'canPromote',false,'reason','source_changed');
  end;
  return envelope||jsonb_build_object('linked',true,'canPromote',true,'reason',null);
end; $$;
revoke all on function public.get_catalog_translation_candidate_freshness(text,text,uuid,bigint,text,text,text,jsonb)
  from public,anon,authenticated,service_role;
grant execute on function public.get_catalog_translation_candidate_freshness(text,text,uuid,bigint,text,text,text,jsonb) to authenticated;

-- Isolated native PG contract. Prepend the unchanged catalog-operation native
-- foundation and the CLI-generated freshness migration, then this fixture.
-- Existing catalog_fixture_* and premium_fixture_* are actual maintained
-- admission/review fixtures, not replacements for the production algorithms.
reset role;
create table public.catalog_freshness_fixture_results(label text primary key,value jsonb not null);
alter table public.catalog_freshness_fixture_results enable row level security;
create policy catalog_freshness_fixture_staff on public.catalog_freshness_fixture_results for all to authenticated
  using(public.is_staff()) with check(public.is_staff());
grant select,insert,update on public.catalog_freshness_fixture_results to authenticated;

create function public.catalog_freshness_fixture_read(d jsonb,catalog_fields jsonb default null)
returns jsonb language sql set search_path='' as $$
 select public.get_catalog_translation_candidate_freshness(d->>'entityType',d->>'entityId',(d->>'id')::uuid,
   (d->>'version')::bigint,d->>'candidateHash',d->>'sourceHash',
   case when d->>'entityType'='country' then d#>>'{sourceRevision,catalogSourceHash}' else null end,catalog_fields);
$$;
create function public.catalog_freshness_fixture_shape(v jsonb,d jsonb)
returns void language plpgsql set search_path='' as $$ begin
 assert jsonb_typeof(v)='object' and v ?& array['version','entityType','entityId','draftId','draftVersion','candidateHash','sourceHash','linked','canPromote','reason'];
 assert v-array['version','entityType','entityId','draftId','draftVersion','candidateHash','sourceHash','linked','canPromote','reason']='{}'::jsonb,
   'Metadata response must not expose any private body, source, provider or extra field';
 assert v->'version'='1'::jsonb and v->'entityType'=d->'entityType' and v->'entityId'=d->'entityId'
   and v->'draftId'=d->'id' and v->'draftVersion'=d->'version'
   and v->'candidateHash'=d->'candidateHash' and v->'sourceHash'=d->'sourceHash';
 assert jsonb_typeof(v->'linked')='boolean' and jsonb_typeof(v->'canPromote')='boolean';
 assert v->'reason'='null'::jsonb or v->>'reason' in ('candidate_missing','candidate_changed','source_changed');
 assert (v->'canPromote'='true'::jsonb)=(v->'reason'='null'::jsonb);
end; $$;
create function public.catalog_freshness_fixture_complete(a jsonb)
returns jsonb language plpgsql set search_path='' as $$ declare r jsonb;begin
 r:=public.catalog_fixture_begin(a);r:=public.catalog_fixture_pass(r,'translation',a->'payload');
 r:=public.catalog_fixture_pass(r,'review',a->'payload');return public.catalog_fixture_finish(r,a->'payload');
end; $$;

-- Entire journal/cache/candidate contents are fingerprinted internally so a
-- read cannot quietly record a call, consume a receipt, or mutate operations.
-- This helper is fixture-only and intentionally has no client execute grant.
create function public.catalog_freshness_fixture_journal_hash()
returns text language sql set search_path='' as $$
 select probpera_translation_operations.retry_fingerprint(jsonb_build_object(
  'jobs',(select coalesce(jsonb_agg(to_jsonb(t) order by id),'[]'::jsonb) from public.translation_jobs t),
  'items',(select coalesce(jsonb_agg(to_jsonb(t) order by id),'[]'::jsonb) from public.translation_job_items t),
  'attempts',(select coalesce(jsonb_agg(to_jsonb(t) order by id),'[]'::jsonb) from public.translation_job_attempts t),
  'cache',(select coalesce(jsonb_agg(to_jsonb(t) order by operation_id),'[]'::jsonb) from premium_translation_private.catalog_operation_artifacts t),
  'drafts',(select coalesce(jsonb_agg(to_jsonb(t) order by id),'[]'::jsonb) from public.premium_translation_working_drafts t)));
$$;
revoke all on function public.catalog_freshness_fixture_journal_hash() from public,anon,authenticated,service_role;

-- A real newly linked candidate is current. A different fresh staff actor may
-- inspect safe metadata, but cannot read the original actor's private cache.
do $$ declare k text;a jsonb;r jsonb;d jsonb;v jsonb;fields jsonb;before_audit bigint;before_outbox bigint;before_journal text;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach k in array array['literary_work','country'] loop
  a:=public.catalog_fixture_seed(k,'freshness-current-'||k,true);
  fields:=case when k='country' then a#>'{expectedState,catalogFields}' else null end;
  set local role authenticated;
  r:=public.catalog_freshness_fixture_complete(a);
  d:=public.get_premium_translation_working_draft(k,a->>'entityId')->'draft';
  reset role;
  select count(*) into before_audit from public.admin_audit_log;
  select count(*) into before_outbox from public.premium_fixture_outbox;
  before_journal:=public.catalog_freshness_fixture_journal_hash();
  set local role authenticated;
  v:=public.catalog_freshness_fixture_read(d,fields);perform public.catalog_freshness_fixture_shape(v,d);
  assert v->'linked'='true'::jsonb and v->'canPromote'='true'::jsonb and v->'reason'='null'::jsonb;
  perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
  assert public.catalog_freshness_fixture_read(d,fields)=v;
  perform public.premium_fixture_error(format('select public.catalog_fixture_artifact(%L::jsonb)',r::text),'42501');
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  insert into public.catalog_freshness_fixture_results values('linked-current-other-staff-'||k,v);
  reset role;
  assert (select count(*)=before_audit from public.admin_audit_log) and (select count(*)=before_outbox from public.premium_fixture_outbox),
    'Metadata inspection must not audit, publish, consume or mutate the candidate';
  assert before_journal=public.catalog_freshness_fixture_journal_hash(),'Exact journal/calls/cache/candidate contents unchanged';
 end loop;
end; $$;

-- Link lookup by actual draft UUID must survive tampered receipt or body. A
-- linked candidate never downgrades into the legacy passthrough on mismatch.
do $$ declare mode text;a jsonb;r jsonb;d jsonb;changed jsonb;v jsonb;
 original public.premium_translation_working_drafts%rowtype;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 a:=public.catalog_fixture_seed('literary_work','freshness-linked-tamper',true);
 set local role authenticated;r:=public.catalog_freshness_fixture_complete(a);
 d:=public.get_premium_translation_working_draft('literary_work',a->>'entityId')->'draft';reset role;
 select * into original from public.premium_translation_working_drafts where id=(d->>'id')::uuid;
 foreach mode in array array['version','hash','sourceHash','payload','provenance'] loop
  update public.premium_translation_working_drafts set
   version=case mode when 'version' then original.version+1 else original.version end,
   candidate_hash=case mode when 'hash' then repeat('f',64) else original.candidate_hash end,
   source_hash=case mode when 'sourceHash' then repeat('e',64) else original.source_hash end,
   payload=case mode when 'payload' then jsonb_set(original.payload,'{description}','"TAMPERED PRIVATE PAYLOAD"') else original.payload end,
   provenance=case mode when 'provenance' then jsonb_set(original.provenance,'{translatorModel}','"TAMPERED MODEL"') else original.provenance end where id=original.id;
  set local role authenticated;v:=public.catalog_freshness_fixture_read(d);perform public.catalog_freshness_fixture_shape(v,d);
  assert v->'linked'='true'::jsonb and v->'canPromote'='false'::jsonb;
  assert v->>'reason'=case when mode in ('version','hash','sourceHash') then 'candidate_changed' else 'source_changed' end;
  insert into public.catalog_freshness_fixture_results values('linked-tamper-'||mode,v);reset role;
 end loop;
 update public.premium_translation_working_drafts set version=original.version,candidate_hash=original.candidate_hash,source_hash=original.source_hash,
  payload=original.payload,provenance=original.provenance where id=original.id;
 set local role authenticated;
 assert public.catalog_freshness_fixture_read(d)->'canPromote'='true'::jsonb;
 v:=public.catalog_freshness_fixture_read(d||jsonb_build_object('entityId',gen_random_uuid()));
 assert v->'canPromote'='false'::jsonb and v->>'reason'='candidate_changed';
 perform public.premium_fixture_discard(d);
 v:=public.catalog_freshness_fixture_read(d);perform public.catalog_freshness_fixture_shape(v,d);
 assert v->'linked'='false'::jsonb and v->'canPromote'='false'::jsonb and v->>'reason'='candidate_missing';
 insert into public.catalog_freshness_fixture_results values('consumed-candidate-no-legacy',v);reset role;
end; $$;

-- Fault injection is isolated in rollback subtransactions. Only a40001 from
-- the linked guard becomes stale; permissions/other database errors propagate.
-- The original existing guard definition is restored before the next test.
do $$ declare a jsonb;r jsonb;d jsonb;v jsonb;code text;seen text;definition text;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 a:=public.catalog_fixture_seed('literary_work','freshness-error-mapping',true);
 set local role authenticated;r:=public.catalog_freshness_fixture_complete(a);
 d:=public.get_premium_translation_working_draft('literary_work',a->>'entityId')->'draft';reset role;
 select pg_get_functiondef('premium_translation_private.assert_catalog_operation_promotion_current(public.premium_translation_working_drafts,text,jsonb)'::regprocedure) into definition;
 foreach code in array array['40001','42501','XX000'] loop
  begin
   execute format('create or replace function premium_translation_private.assert_catalog_operation_promotion_current(d public.premium_translation_working_drafts,catalog_hash text,catalog_fields jsonb) returns void language plpgsql security invoker set search_path='''' set timezone=''UTC'' as $fault$begin raise exception ''Synthetic fixture fault'' using errcode=%L;end;$fault$',code);
   set local role authenticated;seen:=null;v:=null;
   begin v:=public.catalog_freshness_fixture_read(d);exception when others then get stacked diagnostics seen=returned_sqlstate;end;
   if code='40001' then assert seen is null and v->>'reason'='source_changed' and v->'canPromote'='false'::jsonb;
   else assert seen=code and v is null;end if;
   reset role;
   raise exception 'Rollback only synthetic replacement' using errcode='ZX001';
  exception when sqlstate 'ZX001' then null;end;
  assert (select pg_get_functiondef('premium_translation_private.assert_catalog_operation_promotion_current(public.premium_translation_working_drafts,text,jsonb)'::regprocedure))=definition;
  set local role authenticated;assert public.catalog_freshness_fixture_read(d)->'canPromote'='true'::jsonb;reset role;
  insert into public.catalog_freshness_fixture_results values('only40001-stale-'||code,jsonb_build_object('propagatedSqlstate',seen,'freshness',v));
 end loop;
end; $$;

-- Reproduce the actual book UI defect without touching any master timestamp.
-- The unchanged atomic promote guard must reject the same linked candidate.
do $$ declare a jsonb;r jsonb;d jsonb;v jsonb;before_master jsonb;after_master jsonb;before_outbox bigint;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 a:=public.catalog_fixture_seed('literary_work','freshness-source-licence',true);
 set local role authenticated;r:=public.catalog_freshness_fixture_complete(a);
 d:=public.get_premium_translation_working_draft('literary_work',a->>'entityId')->'draft';
 assert public.catalog_freshness_fixture_read(d)->'canPromote'='true'::jsonb;reset role;
 select jsonb_build_object('work',to_jsonb(w),'ru',to_jsonb(ru),'en',to_jsonb(en)) into before_master
  from public.literary_works w join public.literary_work_translations ru on ru.work_id=w.id and ru.locale='ru'
  join public.literary_work_translations en on en.work_id=w.id and en.locale='en' where w.id=(a->>'entityId')::uuid;
 update public.literary_work_sources set license_name='NEW LICENCE ONLY',metadata='{"rights":{"permission":"CHANGED ONLY SOURCE TERMS"}}'
  where work_id=(a->>'entityId')::uuid;
 select jsonb_build_object('work',to_jsonb(w),'ru',to_jsonb(ru),'en',to_jsonb(en)) into after_master
  from public.literary_works w join public.literary_work_translations ru on ru.work_id=w.id and ru.locale='ru'
  join public.literary_work_translations en on en.work_id=w.id and en.locale='en' where w.id=(a->>'entityId')::uuid;
 assert before_master=after_master,'Master work/RU/EN rows INCLUDING timestamps stay exact';
 select count(*) into before_outbox from public.premium_fixture_outbox;
 set local role authenticated;v:=public.catalog_freshness_fixture_read(d);perform public.catalog_freshness_fixture_shape(v,d);
 assert v->'linked'='true'::jsonb and v->'canPromote'='false'::jsonb and v->>'reason'='source_changed';
 perform public.premium_fixture_error(format('select public.catalog_fixture_approve(%L::jsonb)',r::text),'40001');
 insert into public.catalog_freshness_fixture_results values('linked-book-source-licence-master-exact',v);
 reset role;assert (select count(*)=before_outbox from public.premium_fixture_outbox);
 assert (select jsonb_build_object('work',to_jsonb(w),'ru',to_jsonb(ru),'en',to_jsonb(en))=after_master from public.literary_works w
  join public.literary_work_translations ru on ru.work_id=w.id and ru.locale='ru'
  join public.literary_work_translations en on en.work_id=w.id and en.locale='en' where w.id=(a->>'entityId')::uuid);
end; $$;

-- Full override opaque rights can drift with an unchanged timestamp. Normalize
-- at transaction now(), capture, then modify rights in this SAME transaction;
-- the unchanged real set_updated_at() trigger also uses transaction now().
do $$ declare mode text;a jsonb;r jsonb;d jsonb;v jsonb;fresh jsonb;fields jsonb;before_row jsonb;after_row jsonb;
 c public.country_profile_overrides%rowtype;before_outbox bigint;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach mode in array array['catalog','override-rights'] loop
  a:=public.catalog_fixture_seed('country','freshness-'||mode,true);
  update public.country_profile_overrides set updated_at=now() where country_id=a->>'entityId' returning * into c;
  fresh:=public.premium_fixture_args('country',a->>'entityId');
  a:=a||jsonb_build_object('sourceRevision',fresh->'sourceRevision','targetRevision',fresh->'targetRevision',
    'expectedState',jsonb_build_object('version',1,'catalogFields',a#>'{expectedState,catalogFields}',
       'override',jsonb_build_object('id',c.id,'fields',c.fields,'updated_at',c.updated_at)));
  fields:=a#>'{expectedState,catalogFields}';
  set local role authenticated;r:=public.catalog_freshness_fixture_complete(a);
  d:=public.get_premium_translation_working_draft('country',a->>'entityId')->'draft';
  assert public.catalog_freshness_fixture_read(d,fields)->'canPromote'='true'::jsonb;reset role;
  select to_jsonb(t) into before_row from public.country_profile_overrides t where country_id=a->>'entityId';
  if mode='catalog' then fields:=jsonb_set(fields,'{rights}','{"catalog":"NEW RAW CATALOG TERMS"}');
  else update public.country_profile_overrides set fields=jsonb_set(country_profile_overrides.fields,'{rights}','"NEW RAW OVERRIDE TERMS"') where country_id=a->>'entityId';end if;
  select to_jsonb(t) into after_row from public.country_profile_overrides t where country_id=a->>'entityId';
  assert before_row->'updated_at'=after_row->'updated_at';
  if mode='catalog' then assert before_row=after_row;
  else assert before_row-'fields'=after_row-'fields' and before_row#>'{fields,translations}'=after_row#>'{fields,translations}';end if;
  select count(*) into before_outbox from public.premium_fixture_outbox;
  set local role authenticated;v:=public.catalog_freshness_fixture_read(d,fields);perform public.catalog_freshness_fixture_shape(v,d);
  assert v->'linked'='true'::jsonb and v->'canPromote'='false'::jsonb and v->>'reason'='source_changed';
  perform public.premium_fixture_error(format('select public.catalog_fixture_approve(%L::jsonb,%L::jsonb)',r::text,fields::text),'40001');
  insert into public.catalog_freshness_fixture_results values('linked-country-'||mode||'-timestamp-exact',v);
  reset role;assert (select to_jsonb(t)=after_row from public.country_profile_overrides t where country_id=a->>'entityId');
  assert (select count(*)=before_outbox from public.premium_fixture_outbox);
 end loop;
end; $$;

-- A concrete unlinked legacy candidate passes only this extra predicate; the
-- existing review and explicit human/atomic guards still decide publication.
-- Uppercase textual UUID is deliberately retained, matching the old contract.
do $$ declare k text;a jsonb;d jsonb;v jsonb;fields jsonb;identity text;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach k in array array['literary_work','country'] loop
  a:=public.catalog_fixture_seed(k,'freshness-legacy-'||k,true);fields:=case when k='country' then a#>'{expectedState,catalogFields}' else null end;
  if k='literary_work' then identity:=upper(a->>'identity');a:=a||jsonb_build_object('identity',identity,'sourceRevision',jsonb_set(a->'sourceRevision','{workId}',to_jsonb(identity)));end if;
  set local role authenticated;d:=public.premium_fixture_stage(a)->'draft';
  v:=public.catalog_freshness_fixture_read(d,fields);perform public.catalog_freshness_fixture_shape(v,d);
  assert v->'linked'='false'::jsonb and v->'canPromote'='true'::jsonb and v->'reason'='null'::jsonb;
  assert public.catalog_freshness_fixture_read(d||jsonb_build_object('version',(d->>'version')::bigint+1),fields)->>'reason'='candidate_changed';
  assert public.catalog_freshness_fixture_read(d||jsonb_build_object('candidateHash',repeat('f',64)),fields)->>'reason'='candidate_changed';
  assert public.catalog_freshness_fixture_read(d||jsonb_build_object('id',gen_random_uuid()),fields)->>'reason'='candidate_missing';
  if k='literary_work' then assert public.catalog_freshness_fixture_read(d||jsonb_build_object('entityId',lower(d->>'entityId')),fields)->>'reason'='candidate_changed';end if;
  insert into public.catalog_freshness_fixture_results values('legacy-exact-text-and-bound-receipt-'||k,v);
  reset role;
 end loop;
end; $$;

-- Auth/ACL cannot turn denied reads into legacy/current claims. Null and
-- nonstaff fail fresh actor verification before domain validation.
do $$ declare fn regprocedure:='public.get_catalog_translation_candidate_freshness(text,text,uuid,bigint,text,text,text,jsonb)'::regprocedure;
 statement text:='select public.get_catalog_translation_candidate_freshness(''country'',''fixture-country'',gen_random_uuid(),1,repeat(''a'',64),repeat(''b'',64),repeat(''c'',64),''{}''::jsonb)';begin
 assert has_function_privilege('authenticated',fn,'EXECUTE') and not has_function_privilege('anon',fn,'EXECUTE')
   and not has_function_privilege('service_role',fn,'EXECUTE');
 set local role anon;perform public.premium_fixture_error(statement,'42501');reset role;
 set local role service_role;perform public.premium_fixture_error(statement,'42501');reset role;
 set local role authenticated;perform set_config('request.jwt.claim.sub','',true);perform public.premium_fixture_error(statement,'42501');
 perform set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);perform public.premium_fixture_error(statement,'42501');
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 perform public.premium_fixture_error('select public.get_catalog_translation_candidate_freshness(''writer_biography'',''fixture-country:writer'',gen_random_uuid(),1,repeat(''a'',64),repeat(''b'',64))','22023');
 perform public.premium_fixture_error('select public.get_catalog_translation_candidate_freshness(''site_copy'',gen_random_uuid()::text,gen_random_uuid(),1,repeat(''a'',64),repeat(''b'',64))','22023');
 reset role;
 insert into public.catalog_freshness_fixture_results values('staff-only-closed-kinds','true');
end; $$;
select 'M07_CATALOG_FRESHNESS_INITIAL_PASS';
