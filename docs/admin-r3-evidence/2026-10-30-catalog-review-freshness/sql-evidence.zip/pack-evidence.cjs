const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),out=path.resolve(__dirname,'../catalog-freshness-sql-evidence-20261030-sol');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const read=n=>JSON.parse(fs.readFileSync(path.join(__dirname,n),'utf8').replace(/^\uFEFF/,''));
const summary=read('native-summary.json');
assert.equal(summary.migration.sha256,'716027ea34885bc5a809e73506bb78a9f928890d592bbb2f613277acd30f20dd');
assert.equal(summary.fixture.sha256,'5c89f26b104f5eccad8ce0f2ef026ba07cc7ecb30f872e2fdc1dcccd8aa9522b');
const copy=(a,b)=>{fs.mkdirSync(path.dirname(b),{recursive:true});fs.copyFileSync(a,b);};
const tree=(a,b)=>{for(const e of fs.readdirSync(a,{withFileTypes:true})){const from=path.join(a,e.name),to=path.join(b,e.name);if(e.isDirectory())tree(from,to);else copy(from,to);}};
fs.mkdirSync(out,{recursive:true});
for(const name of ['build-probe.cjs','build-request-export.cjs','summarize.cjs','pack-evidence.cjs','run-probe.ps1','concurrent-and-export.ps1','export-requests.ps1','fixture.sql','source-manifest.json','native-summary.json','native-metadata.json','native-requests.json','native-requests.sql','native-requests.stderr.log','native-case-results.json','native-functions.json','concurrent-receipts.json','new-run.log','new-cleanup.json','new-cleanup.log','export-cleanup.json','export-cleanup.log','request-export-cleanup.json','request-export-cleanup.log','postgres-new.log','postgres-export.log','postgres-requests.log','security-advisors.log','advisors-lint-receipt.json'])copy(path.join(__dirname,name),path.join(out,name));
for(const name of fs.readdirSync(__dirname))if(/^(?:read-|discard-|export-query-)/.test(name))copy(path.join(__dirname,name),path.join(out,name));
tree(path.join(__dirname,'history'),path.join(out,'history'));
for(const s of summary.sourceInputs){const bytes=fs.readFileSync(path.join(repo,s.file));assert.equal(sha(bytes),s.sha256);fs.mkdirSync(path.dirname(path.join(out,'sources',s.file)),{recursive:true});fs.writeFileSync(path.join(out,'sources',s.file),bytes);}
const prior=path.resolve(__dirname,'../catalog-operation-sql-native');
for(const name of ['fixture.sql','source-manifest.json','native-functions.json','security-advisors.log'])copy(path.join(prior,name),path.join(out,'foundation',name));
let conformance=null;
if(process.argv[2]){const file=path.resolve(process.argv[2]),bytes=fs.readFileSync(file);conformance={originalPath:file,sha256:sha(bytes)};copy(file,path.join(out,'actual-ts-native-conformance-report.json'));}
fs.writeFileSync(path.join(out,'README.txt'),`Catalog candidate freshness native proof — GPT-6.1 Sol Ultra — 2026-10-30

CURRENT isolated native PG17 proof. Final fresh database v3 maintained fixture exit0,26 result groups.23 strict metadata goldens plus4 actual two-session metadata responses;27 exact8-argument request goldens. Existing atomic promotion remains authoritative. No provider/paid/managed/production operation.

The one new authenticated fresh-staff metadata RPC binds actual draft UUID first and exact book text/case; only a concretely bound unlinked legacy row passes the extra gate. A linked cache reuses the existing full-server-seed guard. Licence/source metadata drift or country catalogue/opaque override rights drift with all master timestamps exact disables approval. Only guard40001 maps to source_changed;42501/XX000 stay errors. Other staff can read safe metadata while actor-owned private artifacts remain denied. No source/body/prose/provider fields appear in metadata. Human confirmation and atomic POST checks are unchanged.

Both domains ran real separate psql sessions. A shared-staff read held its locks while explicit discard waited on actual database locks; it then completed without deadlock, and the consumed UUID reported candidate_missing. Exact canonical/journal/cache fingerprints remained unchanged. Current reads also preserve draft contents,audit/outbox counts and call journals. All35 old writer/catalog/promote native function bodies and config remain exact.

Read native-summary.json for source bindings,cleanup/advisors and scope. The new migration/fixture are the only maintained files owned by this proof.35 exact source inputs and final joined fixture.sql are included. The frozen bookf45180... and country2c758... BEFORE ZIPs remain unchanged; root acceptance artifacts separately own paired SSR/SDK BEFORE/CURRENT and broad/gates. This native archive makes no broadtest or wholeR3 acceptance claim.

Iteration history is honest: v1 failed a timestamp fixture assertion because the inherited synthetic foundation uses clock_timestamp();v2/v3 replay the EXACT pre-existing canonical now() function statement extracted from cms_foundation.sql before freshness-only tests. Triggers were never disabled and old source files remain exact. v1 full log/fixture/cleanup and v2 full passing logs/exports are retained in history. The first export-only runner hit Windows psql argv codepage conversion with synthetic Russian JSON; server error log,cleanup and explicit observed transcript are retained. It was corrected to exact UTF8 SQL files without maintained changes. Final exports and cleanup pass.

Advisors ran against owned127.0.0.1:55438 only (the CLI generic 'remote database' label does not mean production). Exit1 retains the same15 inherited synthetic-fixture findings;0new findings. Lint NOT RUN:plpgsql_check unavailable,nothing installed. Final fixturePID15808,metadata exportPID13564 and request exportPID13500 stopped with no PID file/process/service. No secrets,real Auth/database data,dependencies or binaries are included.

Replay: final fixture.sql can be applied with psql --no-psqlrc --set=ON_ERROR_STOP=1 to a NEW owned disposable PG17 database with the documented synthetic fixture roles. build-probe.cjs verifies frozen foundation/source hashes and generates the joined SQL. run-probe.ps1 refuses existing DBs and verifies owned data_directory/PID;concurrent-and-export.ps1 and export-requests.ps1 likewise start/query/stop the exact owned loopback cluster. Runtime/parent paths are this machine's documented aliases: rebase them to extracted sources/foundation and an owned local PG17 cluster, never a managed environment. Source timestamps and raw logs are not billing receipts.

native-requests.json is NOT the public metadata response. It reconstructs exact native call arguments from echoed bindings+native stored catalogue or the unchanged legacy fixture seed expression. Original native responses remain their original point-in-time tamper/consumed states; they were not falsely regenerated from later restored rows. The independent TypeScript+installedSDK replay validates wire conformance against these raw goldens.${conformance?' Its exact report is copied as actual-ts-native-conformance-report.json, SHA'+conformance.sha256+'.':' Its report is maintained separately by root acceptance and has not been claimed as run here.'}
`);
const files=[];function walk(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,e.name);if(e.isDirectory())walk(f);else if(path.relative(out,f)!=='manifest.json'){const b=fs.readFileSync(f);files.push({file:path.relative(out,f).replaceAll('\\','/'),bytes:b.length,sha256:sha(b)});}}}walk(out);files.sort((a,b)=>a.file.localeCompare(b.file));
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({atUtc:new Date().toISOString(),mode:'CURRENT_NATIVE_ONLY',sourceCount:summary.sourceInputCount,conformance,files},null,2));
console.log(JSON.stringify({out,files:files.length,sourceCount:summary.sourceInputCount,conformance}));
