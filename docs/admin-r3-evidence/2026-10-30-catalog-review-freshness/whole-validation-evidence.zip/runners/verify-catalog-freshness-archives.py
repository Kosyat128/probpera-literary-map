from pathlib import Path,PurePosixPath
import json,hashlib,zipfile
repo=Path(__file__).resolve().parents[1]/'probpera-literary-map'
destination=repo/'docs/admin-r3-evidence/2026-10-30-catalog-review-freshness'
sha=lambda b:hashlib.sha256(b).hexdigest()
specs=[('catalog-review-freshness-controlled-tests.zip','b6b63d0f6919dc4224fc7fde398cfd526f1d442560bff24ef39d4620917c8965','package-manifest.json',210),
 ('sql-evidence.zip','93c02052ee11250946780c36cfeb7fc16ae6512e9cd06723037c043a4a9d747b','manifest.json',136)]
results=[]
for name,expected,manifest_name,count in specs:
    archive=destination/name;data=archive.read_bytes();assert sha(data)==expected
    with zipfile.ZipFile(archive) as z:
        names=z.namelist();assert len(names)==len(set(names))==count+1
        manifest_bytes=z.read(manifest_name);manifest=json.loads(manifest_bytes)
        entries=manifest['files'];assert len(entries)==count
        for entry in entries:
            rel=entry['file'];p=PurePosixPath(rel)
            assert not p.is_absolute() and '..' not in p.parts and ':' not in rel and '\\' not in rel
            content=z.read(rel);assert len(content)==entry['bytes'] and sha(content)==entry['sha256']
        assert set(names)=={manifest_name}|{entry['file'] for entry in entries}
    results.append({'archive':name,'sha256':expected,'bytes':len(data),'verifiedPayloads':count,'manifestSha256':sha(manifest_bytes),'status':'PASS'})
snapshot=json.loads((repo.parent/'work/catalog-review-freshness-final-validation-v1/source-before.json').read_text(encoding='utf-8'))
frozen={entry['path']:entry for entry in snapshot['files']}
with zipfile.ZipFile(destination/'catalog-review-freshness-controlled-tests.zip') as z:
    bound=[name for name in z.namelist() if name.startswith('source-current/')]
    for name in bound:
        rel=name.removeprefix('source-current/');assert rel in frozen and sha(z.read(name))==frozen[rel]['sha256']
    assert len(bound)==136
receipt={'classification':'ROOT_INDEPENDENT_ARCHIVE_READBACK_PASS','archives':results,'safeRelativeUniquePaths':True,
 'currentSourceBindings':len(bound),'sourceFingerprint':snapshot['validationSourceSha256'],'allBindingsMatchFrozenSource':True}
(destination/'root-independent-archive-check.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
