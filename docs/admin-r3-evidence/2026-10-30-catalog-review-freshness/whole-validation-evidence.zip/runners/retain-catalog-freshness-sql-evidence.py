from pathlib import Path
import hashlib,json,zipfile
work=Path(__file__).resolve().parent;repo=work.parent/'probpera-literary-map'
source=work/'catalog-freshness-sql-evidence-20261030-sol.zip'
destination=repo/'docs/admin-r3-evidence/2026-10-30-catalog-review-freshness'
destination.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
data=source.read_bytes();assert sha(data)=='93c02052ee11250946780c36cfeb7fc16ae6512e9cd06723037c043a4a9d747b'
with zipfile.ZipFile(source) as z:
    manifest=json.loads(z.read('manifest.json'))
    assert len(z.namelist())==len(set(z.namelist()))==137
    for entry in manifest['files']:
        content=z.read(entry['file']);assert len(content)==entry['bytes'] and sha(content)==entry['sha256']
    assert len(manifest['files'])==136
native=json.loads((work/'catalog-freshness-sql-native/native-summary.json').read_text(encoding='utf-8'))
assert native['maintainedFixtureExitCode']==0 and native['resultGroupCount']==26
assert len(native['exactOldFunctionBodiesAndConfig'])==35
for entry in native['sourceInputs']:assert sha((repo/entry['file']).read_bytes())==entry['sha256']
dest=destination/'sql-evidence.zip';assert not dest.exists();dest.write_bytes(data)
assert sha(dest.read_bytes())==sha(data)
receipt={'archive':dest.name,'sha256':sha(data),'bytes':len(data),'verifiedPayloads':136,'sourceInputs':len(native['sourceInputs']),
 'sourceBindingsMatchCurrent':True,'nativeGroupsPassed':26,'oldRoutineBodiesAndConfigExact':35,'metadataGoldenCount':27,
 'actualTsSdkMetadataConformance':27,'cleanup':native['cleanup'],'advisors':native['advisors'],
 'historyScope':'Initial freshness fixture used inherited synthetic clock_timestamp; actual canonical now() statement appended for freshness tests only. Original failure and later passes retained. No trigger disabling or old-source edits.'}
(destination/'sql-evidence.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'archive':dest.name,'sha256':sha(data),'bytes':len(data),'verifiedPayloads':136,'sourceBindings':len(native['sourceInputs']),'nativeGroups':26,'oldRoutinesExact':35}))
