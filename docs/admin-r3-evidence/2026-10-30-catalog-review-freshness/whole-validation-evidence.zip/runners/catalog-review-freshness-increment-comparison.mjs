import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const work=path.dirname(fileURLToPath(import.meta.url));
const priorFile=path.join(work,'catalog-admission-final-validation-v2/source-before.json');
const currentFile=path.join(work,'catalog-review-freshness-final-validation-v1/source-before.json');
const prior=JSON.parse(fs.readFileSync(priorFile,'utf8')),current=JSON.parse(fs.readFileSync(currentFile,'utf8'));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const before=new Map(prior.files.filter(f=>!f.path.startsWith('docs/')).map(f=>[f.path,f]));
const after=new Map(current.files.filter(f=>!f.path.startsWith('docs/')).map(f=>[f.path,f]));
const changed=[...after.values()].filter(f=>before.has(f.path)&&JSON.stringify(before.get(f.path))!==JSON.stringify(f));
const added=[...after.values()].filter(f=>!before.has(f.path)),removed=[...before.values()].filter(f=>!after.has(f.path));
assert.equal(prior.validationSourceSha256,'91cd9cc89f2d3c2e9c62b630b97ce56269a9dce15009aed0d5d574e6641e6f79');
assert.equal(prior.head,current.head);assert.deepEqual(removed,[]);
assert.deepEqual(changed.map(f=>f.path).sort(),[
 'apps/admin/lib/premium-translation-review.ts',
 'apps/admin/lib/premium-translation-review.integration.test.ts',
 'apps/admin/lib/fixtures/catalog-admission-boundary.cjs',
].sort());
assert.deepEqual(added.map(f=>f.path).sort(),[
 'apps/admin/lib/catalog-translation-candidate-freshness-rpc.ts',
 'apps/admin/lib/catalog-translation-candidate-freshness-rpc.integration.test.ts',
 'apps/admin/lib/catalog-review-full-seed.integration.test.ts',
 'apps/admin/lib/fixtures/catalog-review-freshness-boundary.cjs',
 'apps/admin/lib/fixtures/catalog-review-full-seed-runtime.cjs',
 'apps/admin/lib/fixtures/catalog-review-full-seed-cases.cjs',
 'apps/admin/lib/fixtures/catalog-review-preflight.same-contract.cjs',
 'scripts/database/fixtures/catalog-translation-candidate-freshness.sql',
 'supabase/migrations/20261029230111_catalog_translation_candidate_freshness.sql',
].sort());
const result={status:'PASS',capturedAt:new Date().toISOString(),head:current.head,previousManifestSha256:hash(fs.readFileSync(priorFile)),currentManifestSha256:hash(fs.readFileSync(currentFile)),previousSourceCount:before.size,currentSourceCount:after.size,previousSourceFingerprint:prior.validationSourceSha256,currentSourceFingerprint:current.validationSourceSha256,changedExisting:changed.map(f=>({path:f.path,beforeSha256:before.get(f.path).sha256,afterSha256:f.sha256})),added,removed,unchangedOriginalSourceCount:before.size-changed.length,allChangesMatchDeclaredIncrement:true,comparisonExclusion:'docs/ only; all tracked/owned non-doc files compared.'};
fs.writeFileSync(path.join(work,'catalog-review-freshness-final-validation-v1/increment-source-comparison.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,changed:changed.length,added:added.length,unchangedPrevious:result.unchangedOriginalSourceCount,sourceCount:after.size,fingerprint:current.validationSourceSha256}));
