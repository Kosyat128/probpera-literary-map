import datetime, hashlib, json, pathlib, zipfile

repo=pathlib.Path(r'C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map')
work=repo.parent/'work'
out=work/'catalog-review-freshness-final-validation-v1'
destination=repo/'docs/admin-r3-evidence/2026-10-30-catalog-review-freshness'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda name:json.loads((out/name).read_text(encoding='utf-8-sig'))
write=lambda name,value:(out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
tests=read('selected-tests-summary.json'); receipt=read('selected-tests-receipt.json')
gates=read('gates-summary.json'); drift=read('source-drift.json')
preservation=read('baseline-preservation.json'); increment=read('increment-source-comparison.json')
before=read('source-before.json'); after=read('source-after-tests.json')
assert receipt.get('finishedAt') and before['head']==after['head']
assert drift['zeroValidationSourceDrift'] and before['validationSourceSha256']==after['validationSourceSha256']
assert preservation['pass'] and increment['status']=='PASS'
assert tests['testFileCount']==209 and tests['numPendingTests']==0 and tests['numTodoTests']==0
for gate in gates['receipts']:
    individual=read(gate['id']+'-receipt.json')
    assert individual.get('finishedAt') and individual['status']==gate['status']

baseline=repo/'docs/admin-r3-evidence/2026-10-30-catalog-admission/whole-validation-evidence.zip'
assert sha(baseline.read_bytes())=='9a6a7bc4f636b9fc58e16efe591d5cf42d3d873f7753d35f74d0a0b959242d6a'
with zipfile.ZipFile(baseline) as z:
    old_tests_bytes=z.read('final/selected-tests-summary.json'); old_tests=json.loads(old_tests_bytes)
    old_text=z.read('final/gate-readonly-hyphens.log')
def failures(report):
    return sorted([{'fullName':failure['fullName'],'firstErrors':[message.replace('\r\n','\n').split('\n')[0] for message in failure.get('failureMessages',[])]}
      for file in report.get('failedFiles',[]) for failure in file.get('assertionFailures',[])],key=lambda item:item['fullName'])
comparison={'sameFailureCasesAndFirstErrors':failures(tests)==failures(old_tests),'baseline':failures(old_tests),'current':failures(tests),
 'sourceArchiveSha256':sha(baseline.read_bytes()),'claim':'Exact case names and first diagnostic line; line-ending normalization only. No fabricated original fixture, ignored case or replacement BEFORE.'}
write('baseline-failure-comparison.json',comparison)
assert comparison['sameFailureCasesAndFirstErrors'] and tests['numFailedTests']==6
text=(out/'gate-readonly-hyphens.log').read_bytes()
text_comparison={'byteIdenticalToBaseline':text==old_text,'baselineSha256':sha(old_text),'currentSha256':sha(text),
 'findingCount':sum(line.startswith('- ') for line in text.decode('utf-8-sig').splitlines()),'normalizerWriteFlagUsed':False}
write('readonly-gate-baseline-comparison.json',text_comparison)
assert text_comparison['byteIdenticalToBaseline'] and text_comparison['findingCount']==41
assert gates['passed']==4 and all(g['status']=='PASS' or g['id']=='gate-readonly-hyphens' for g in gates['receipts'])
external=[]
for name in ['catalog-review-freshness-controlled-tests.zip','sql-evidence.zip']:
    file=destination/name; assert file.exists()
    external.append({'path':name,'bytes':file.stat().st_size,'sha256':sha(file.read_bytes())})
summary={'schemaVersion':1,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':before['head'],
 'classification':'LOCAL_CATALOG_REVIEW_FRESHNESS_INCREMENT_VERIFIED_WITH_KNOWN_INHERITED_FAILURES_NOT_FULL_R3_ACCEPTANCE',
 'tests':{'files':tests['testFileCount'],'total':tests['numTotalTests'],'passed':tests['numPassedTests'],'failed':tests['numFailedTests'],
 'pending':tests['numPendingTests'],'todo':tests['numTodoTests'],'exitCode':receipt['exitCode'],'sameSixHistoricalFailures':True},
 'gates':{**gates,'readonlyLogByteIdenticalToBaseline':True,'readonlyFindingCount':41},
 'source':{'nonDocFileCount':after['validationSourceCount'],'nonDocFingerprint':after['validationSourceSha256'],'fullFileCount':after['trackedFileCount'],
 'beforeFullAggregate':before['aggregateSha256'],'afterTestsFullAggregate':after['aggregateSha256'],'zeroValidationSourceDrift':True,
 'changedExistingVersusCatalog':len(increment['changedExisting']),'addedVersusCatalog':len(increment['added']),'unchangedPreviousFiles':increment['unchangedOriginalSourceCount'],
 'exclusion':'docs/ only; all tracked/owned non-doc files compared. Documentation changes are separately reported.'},
 'preservation':{'pass':True,'normalizers':len(preservation['normalizers']),'rulesAndTests':len(preservation['normalizerRulesAndTests']),
 'ASTScopes':len(preservation['normalizerImportAndCallScopes']),'oldMigrations':len(preservation['oldMigrations']),
 'telegramPaths':len(preservation['independentTelegram']),'packageFiles':len(preservation['packages']),'writeFlagUsed':False},
 'externalArchives':external,
 'limitations':['Six M02 cases require absent genuine original .tmp/m02-operation-wiring-before files; failures retained.',
 'Readonly text gate remains the exact previous41 findings; excluded normalizer subsystem preserved.',
 'Focused482 and native metadata DTO27 are distinct overlapping scopes, not additional acceptance criteria. Current209-file broad run binds final source; prior evidence retains its declared scope.',
 'Native PostgreSQL uses controlled Auth/staff boundaries; consult its original advisor/lint/history receipts. No live managed acceptance is claimed.',
 'Metadata freshness is an additional snapshot check; explicit human confirmation and unchanged atomic promotion remain final authority after any later source change.',
 'Partial-pass replay, global budgets/concurrency, stable T12 scanning and full operator retry remain pending.',
 'No keys/setup, paid provider, managed/browser E2E, production migration/deploy, push or PR ran. Full26-module/230-criterion goal remains active.']}
write('validation-summary.json',summary)
entries={}
for file in out.iterdir():
    if file.is_file() and file.suffix in ['.json','.log','.txt','.md'] and file.name!='evidence-package-manifest.json':entries['final/'+file.name]=file.read_bytes()
for name in ['catalog-review-freshness-final-validation-v1-runner.mjs','catalog-review-freshness-preservation.mjs','catalog-review-freshness-increment-comparison.mjs','package-catalog-review-freshness-final-validation.py','retain-catalog-freshness-sql-evidence.py','verify-catalog-freshness-archives.py']:
    entries['runners/'+name]=(work/name).read_bytes()
entries['baseline/selected-tests-summary.json']=old_tests_bytes
entries['baseline/gate-readonly-hyphens.log']=old_text
entries['external-archive-readback.json']=(destination/'root-independent-archive-check.json').read_bytes()
entries['README.md']=b'# Whole-admin catalog review freshness validation\n\nThe final209-file broad suite and all five gates bind the frozen source fingerprint\nin final/validation-summary.json. Six historical M02 missing-original-fixture cases\nremain FAIL. The readonly text gate is the exact previous41 findings, byte-identical\nto the preceding catalog proof; four other gates pass. No skip or substitute BEFORE.\n\nActual review/SSR and metadata checks close approval after full book source licence\nor country override rights drift while retaining preview/discard. The same3aa\ncontract gives genuine BEFORE two target failures and CURRENT zero failures; all\nsix controls pass. Fresh staff metadata, actual draft binding, explicit human\nconfirmation and unchanged atomic promotion are separately checked. No raw body\nor provider/dispatch capability is returned by metadata. Legacy unlinked candidates\nretain confirmed prior checks; missing/malformed data never grant legacy fallback.\n\nThe separate controlled archive contains482 focused checks,27 native metadata DTO\nreplays and portable32-group actual review replay. Native SQL has26 result groups,\nactual read/discard lock races,35 unchanged old routine bodies/configs, original\nfixture-bootstrap failure and corrected canonical now() evidence. Advisor/lint\nlimits remain explicit. These are overlapping local scopes, not230 R3 criteria.\n\nNo live provider, managed database/browser E2E, production deploy, push or PR ran.\nPartial-pass replay, global budgets, stable traversal, operator retry and full\nproject acceptance remain open. Pinned dependencies and deliberate path adaptation\nare needed for replay. Keep safe child environments and fresh output directories.\nNo credentials, database binaries/data, caches or generated apps are packaged.\n'
manifest={'schemaVersion':1,'head':before['head'],'classification':summary['classification'],'sourceFingerprint':after['validationSourceSha256'],
 'entries':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]}
entries['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
archive=destination/'whole-validation-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    for item in manifest['entries']:assert sha(z.read(item['path']))==item['sha256']
package_receipt={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
 'verifiedPayloads':len(manifest['entries']),'manifestSha256':sha(entries['manifest.json']),
 'sourceFingerprint':after['validationSourceSha256'],'testFiles':209,'testsPassed':tests['numPassedTests'],'testsFailed':6,
 'gatesPassed':4,'gatesTotal':5,'readonlyBaselineFindings':41,'sameSixHistoricalFailures':True,'zeroValidationSourceDrift':True}
(destination/'whole-validation-evidence.receipt.json').write_text(json.dumps(package_receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(package_receipt))
