const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{spawnSync}=require('node:child_process');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),native=require('node:module').createRequire(path.join(repo,'package.json')),ts=native('typescript');
const output=path.join(__dirname,'final-focused-'+new Date().toISOString().replaceAll(/[:.]/g,'-'));fs.mkdirSync(output);
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const owned=['catalog-translation-candidate-freshness-rpc.integration.test.ts','catalog-review-full-seed.integration.test.ts','fixtures/catalog-review-freshness-boundary.cjs',
 'fixtures/catalog-review-full-seed-runtime.cjs','fixtures/catalog-review-full-seed-cases.cjs','fixtures/catalog-review-preflight.same-contract.cjs',
 'fixtures/catalog-admission-boundary.cjs','premium-translation-review.integration.test.ts'].map(name=>'apps/admin/lib/'+name);
const snapshot=files=>files.map(file=>({file,bytes:fs.statSync(path.join(repo,file)).size,sha256:sha(fs.readFileSync(path.join(repo,file)))}));
const before=snapshot(owned),prior=JSON.parse(fs.readFileSync(path.join(__dirname,'../catalog-admission-v1/final-focused-2026-10-29T22-31-41-156Z/receipt.json')));
const tests=[...new Set([...prior.tests,'apps/admin/lib/premium-translation-review.integration.test.ts',...owned.filter(name=>name.endsWith('.test.ts'))])];
const protectedOld=JSON.parse(fs.readFileSync(path.join(__dirname,'../catalog-admission-v1/owned16-source-freeze.json'))).owned.filter(item=>!owned.includes(item.file));
for(const item of protectedOld)assert.equal(sha(fs.readFileSync(path.join(repo,item.file))),item.sha256);
function expectations(bytes){const ast=ts.createSourceFile('review.ts',bytes.toString(),ts.ScriptTarget.Latest,true),values=[];function visit(node){if(ts.isCallExpression(node)&&ts.isIdentifier(node.expression)&&node.expression.text==='expect')values.push(node.getText(ast));ts.forEachChild(node,visit);}visit(ast);return values;}
const original=fs.readFileSync(path.join(__dirname,'../catalog-admission-v1/legacy-originals/premium-translation-review.integration.test.ts'));
assert.deepEqual(expectations(original),expectations(fs.readFileSync(path.join(repo,'apps/admin/lib/premium-translation-review.integration.test.ts'))));
const temp=path.join(output,'temp');fs.mkdirSync(temp);
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>/^(?:PATH|SystemRoot|windir|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i.test(key)));
Object.assign(env,{TEMP:temp,TMP:temp});const runs=[];
for(const [name,args,timeout]of [['tests',['node_modules/vitest/vitest.mjs','run',...tests,'--reporter=json','--outputFile='+path.join(output,'tests.raw.json')],240000],
 ['types',['node_modules/typescript/bin/tsc','--noEmit','--project','apps/admin/tsconfig.json','--pretty','false'],90000]]){
 const run=spawnSync(process.execPath,args,{cwd:repo,env,encoding:'utf8',timeout,maxBuffer:32*1024*1024});fs.writeFileSync(path.join(output,name+'.stdout.log'),run.stdout||'');fs.writeFileSync(path.join(output,name+'.stderr.log'),run.stderr||'');
 runs.push({name,args,status:run.status,error:run.error?.message||null});}
const raw=JSON.parse(fs.readFileSync(path.join(output,'tests.raw.json'))),after=snapshot(owned);assert.deepEqual(after,before);
const result={atUtc:new Date().toISOString(),output,tests,ownedBefore:before,ownedAfter:after,ownedUnchanged:true,prior14OwnedFilesUnchanged:true,originalReviewExpectCalls:expectations(original).length,originalExpectCallsExactlyPreserved:true,
 runs,passed:raw.numPassedTests,total:raw.numTotalTests,failed:raw.numFailedTests,testFiles:tests.length,contractSha256:sha(fs.readFileSync(path.join(repo,'apps/admin/lib/fixtures/catalog-review-preflight.same-contract.cjs')))};
fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));process.exitCode=runs.some(run=>run.status!==0)?1:0;
