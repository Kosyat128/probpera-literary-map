const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const extracted=path.resolve(__dirname,'..'),repo=path.resolve(process.argv[2]||''),output=path.resolve(process.argv[3]||'');
assert.ok(process.argv[2]&&process.argv[3],'Usage: node replay/portable-replay.cjs <checkout-with-installed-dependencies> <new-output-directory>');assert.equal(fs.existsSync(output),false);fs.mkdirSync(output,{recursive:true});
const binding=JSON.parse(fs.readFileSync(path.join(extracted,'source-binding.json'))),mappings={};
for(const item of binding.sourceFiles)mappings[path.join(repo,item.file)]=path.join(extracted,'source-current',item.file);
for(const[file,target]of Object.entries({
 'docs/admin-r3-evidence/2026-10-30-catalog-admission/next-catalog-review-full-seed-before.zip':'next-catalog-review-full-seed-before.zip',
 'docs/admin-r3-evidence/2026-10-30-catalog-admission/next-catalog-country-review-full-seed-before.zip':'next-catalog-country-review-full-seed-before.zip',
 'docs/admin-r3-evidence/2026-10-30-writer-admission/next-library-country-admission-before.zip':'original-library-country-before.zip',
}))mappings[path.join(repo,file)]=path.join(extracted,'original-before',target);
const preload=path.join(output,'captured-file-locations.cjs');
fs.writeFileSync(preload,`const fs=require('node:fs'),path=require('node:path'),read=fs.readFileSync,exists=fs.existsSync,stat=fs.statSync;const map=${JSON.stringify(mappings)};const target=p=>typeof p==='string'?(map[path.resolve(p)]||p):p;fs.readFileSync=function(p,...a){return read.call(this,target(p),...a);};fs.existsSync=function(p){return exists.call(this,target(p));};fs.statSync=function(p,...a){return stat.call(this,target(p),...a);};\n`);
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>/^(?:PATH|SystemRoot|windir|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i.test(key)));
const temp=path.join(output,'temp');fs.mkdirSync(temp);Object.assign(env,{TEMP:temp,TMP:temp,CATALOG_PREFLIGHT_REPO:repo});
const runs=[];function run(name,args,extra={}){const result=spawnSync(process.execPath,['--require',preload,...args],{cwd:repo,env:{...env,...extra},encoding:'utf8',timeout:90000,maxBuffer:24*1024*1024});
 fs.writeFileSync(path.join(output,name+'.stdout.log'),result.stdout||'');fs.writeFileSync(path.join(output,name+'.stderr.log'),result.stderr||'');runs.push({name,status:result.status,error:result.error?.message||null});return result;}
const fixtures=path.join(extracted,'source-current/apps/admin/lib/fixtures'),contract=path.join(fixtures,'catalog-review-preflight.same-contract.cjs');
for(const mode of ['before','current']){const dir=path.join(output,mode);assert.equal(run(mode,[path.join(fixtures,'catalog-review-full-seed-runtime.cjs')],{CATALOG_PREFLIGHT_MODE:mode,CATALOG_PREFLIGHT_OUTPUT_ROOT:dir}).status,0);
 const result=path.join(output,mode+'-contract.json'),verified=run(mode+'-contract',[contract,path.join(dir,'paired-report.json'),result]);const proof=JSON.parse(fs.readFileSync(result));assert.equal(proof.controlFailures,0);assert.equal(proof.targetFailures,mode==='before'?2:0);assert.equal(verified.status,mode==='before'?1:0);}
assert.equal(run('review-cases',[path.join(fixtures,'catalog-review-full-seed-cases.cjs')],{CATALOG_PREFLIGHT_MODE:'current',CATALOG_PREFLIGHT_OUTPUT_ROOT:path.join(output,'cases')}).status,0);
const cases=JSON.parse(fs.readFileSync(path.join(output,'cases/review-cases-report.json')));assert.equal(cases.checks.length,32);assert.ok(cases.checks.every(item=>item.pass));
assert.equal(run('native-dto',[path.join(extracted,'replay/native-dto-conformance.cjs')],{FRESHNESS_NATIVE_REPO:repo,FRESHNESS_NATIVE_INPUT:path.join(extracted,'native-sql'),FRESHNESS_NATIVE_OUTPUT:path.join(output,'native-dto')}).status,0);
const dto=JSON.parse(fs.readFileSync(path.join(output,'native-dto/report.json')));assert.equal(dto.checks.length,27);assert.ok(dto.checks.every(item=>item.pass));
const receipt={atUtc:new Date().toISOString(),runs,sourceFiles:binding.sourceFiles.length,reviewGroups:32,nativeChecks:27,beforeTargetFailures:2,currentTargetFailures:0,controlFailures:0,
 hosting:'Byte-verified captured file locations and immutable input archives are mapped read-only into the normal loader; all app algorithms execute unchanged. Dependencies are reused from the supplied checkout. No symlink, installation, paid/live service or original parentwork path required.',
 scope:'Portable actual review/SSR/SDK/paired/native DTO replay; typed53 and full482 Vitest/typecheck assertions remain in separately captured focused logs.'};
fs.writeFileSync(path.join(output,'portable-replay-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));
