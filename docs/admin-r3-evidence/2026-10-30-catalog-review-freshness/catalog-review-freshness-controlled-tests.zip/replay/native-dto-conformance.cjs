const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),{createRequire}=require('node:module');
const repo=process.env.FRESHNESS_NATIVE_REPO||path.resolve(__dirname,'../../probpera-literary-map'),nativeDir=process.env.FRESHNESS_NATIVE_INPUT||path.resolve(__dirname,'../catalog-freshness-sql-native');
const output=process.env.FRESHNESS_NATIVE_OUTPUT||path.join(__dirname,'native-dto-'+new Date().toISOString().replaceAll(/[:.]/g,'-'));fs.mkdirSync(output);
Object.assign(process.env,{CATALOG_ADMISSION_REPO:repo,CATALOG_ADMISSION_SOURCE_ROOT:repo,CATALOG_ADMISSION_OUTPUT_ROOT:path.join(output,'runtime')});
const runtime=require(path.join(repo,'apps/admin/lib/fixtures/catalog-admission-runtime.cjs')).setup('library');
const api=runtime.load('apps/admin/lib/catalog-translation-candidate-freshness-rpc.ts'),{createClient}=createRequire(path.join(repo,'package.json'))('@supabase/supabase-js');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex'),inputs=[];
function read(file){const bytes=fs.readFileSync(path.join(nativeDir,file));inputs.push({file,bytes:bytes.length,sha256:sha(bytes)});return JSON.parse(bytes);}
const metadata=read('native-metadata.json'),requests=read('native-requests.json'),concurrency=read('concurrent-receipts.json');
for(const item of concurrency){metadata['concurrent-read-'+item.entityType]=item.readSession.receipt;metadata['concurrent-consumed-'+item.entityType]=item.consumedMetadata;}
async function main(){const checks=[];assert.equal(Object.keys(metadata).length,27);assert.equal(Object.keys(requests).length,27);
 for(const[label,value]of Object.entries(metadata)){try{const args=requests[label];assert.ok(args,label+' exact native args');
  const binding={entityType:args.p_entity_type,entityId:args.p_entity_id,draftId:args.p_draft_id,draftVersion:args.p_expected_version,candidateHash:args.p_candidate_hash,sourceHash:args.p_source_hash};
  assert.deepEqual(api.parseCatalogTranslationCandidateFreshnessReceipt(value,binding),value);let count=0;
  const client=createClient('https://native-freshness-dto.fixture.invalid','synthetic-no-auth-session',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},global:{fetch:async(resource,init={})=>{
    const url=new URL(typeof resource==='string'?resource:resource.url);assert.equal(url.origin,'https://native-freshness-dto.fixture.invalid');assert.equal(url.pathname,'/rest/v1/rpc/get_catalog_translation_candidate_freshness');
    assert.deepEqual(JSON.parse(init.body),args);count++;return new Response(JSON.stringify(value),{status:200,headers:{'Content-Type':'application/json'}});
  }}});
  const parsed=await api.readCatalogTranslationCandidateFreshness(client,{...binding,catalogSourceHash:args.p_catalog_source_hash,catalogSourceFields:args.p_catalog_source_fields});
  assert.deepEqual(parsed,value,'Unchanged native metadata must pass actual parser/SDK reader without response normalization');assert.equal(count,1);checks.push({label,pass:true});
 }catch(error){checks.push({label,pass:false,error:error.stack||String(error)});}}
 const sources=[...runtime.graph.values()];for(const item of sources)assert.equal(sha(fs.readFileSync(path.join(repo,item.module))),item.sha256);
 const report={atUtc:new Date().toISOString(),inputs,checks,sources,unchanged:true,providerCalls:runtime.providerCalls.length,
  scope:'27 unchanged actual PostgreSQL metadata results (23 native +4 concurrent read/consumed) through actual TypeScript parser and installed-SDK reader, with exact8native RPC args. Only SDK return transport is controlled.',
  limitations:'Native DB tests/locks/staff authorization ran independently; no live provider, managed service, production, normalizer or source edits during replay.'};
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({output,checks,sourceCount:sources.length}));process.exitCode=checks.some(x=>!x.pass)?1:0;
}
main().catch(error=>{console.error(error.stack||String(error));process.exitCode=2;});
