const fs=require('node:fs'),path=require('node:path');
const dir=__dirname,read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8').replace(/^\uFEFF/,''));
const concurrent=read('concurrent-receipts.json'),extra=[];
for(const c of concurrent){extra.push({label:'concurrent-read-'+c.entityType,value:c.readSession.receipt});extra.push({label:'concurrent-consumed-'+c.entityType,value:c.consumedMetadata});}
const sql=`-- Synthetic native fixture request export. Not a public metadata response.
-- Metadata golden responses keep their original point-in-time native states.
-- Reconstruct exact8args from each golden echo plus recorded country cache,
-- falling back only for fixture legacy rows to the exact seed expression.
with m as (
 select label,case when value ? 'canPromote' then value else value->'freshness' end v
 from public.catalog_freshness_fixture_results where value ? 'canPromote' or value->'freshness' ? 'canPromote'
 union all select x->>'label',x->'value' from jsonb_array_elements('${JSON.stringify(extra).replaceAll("'","''")}'::jsonb) x
),request as (select label,v,
 case when v->>'entityType'='country' then coalesce(
  (select a.raw_seed->'catalogFields' from premium_translation_private.catalog_operation_artifacts a where a.entity_type='country' and a.entity_id=v->>'entityId' order by a.created_at limit1),
  (public.premium_fixture_args('country',v->>'entityId')->'source')||'{"rights":{"catalog":"KEEP RAW CATALOG RIGHTS"},"translations":{"fr":{"locale":"fr","text":"Texte exact"}}}'::jsonb) else null end fields,
 case when v->>'entityType'='country' then coalesce(
  (select a.source_revision->>'catalogSourceHash' from premium_translation_private.catalog_operation_artifacts a where a.entity_type='country' and a.entity_id=v->>'entityId' order by a.created_at limit1),repeat('b',64)) else null end catalog_hash
 from m)
select jsonb_object_agg(label,jsonb_build_object('p_entity_type',v->'entityType','p_entity_id',v->'entityId','p_draft_id',v->'draftId',
 'p_expected_version',v->'draftVersion','p_candidate_hash',v->'candidateHash','p_source_hash',v->'sourceHash',
 'p_catalog_source_hash',catalog_hash,'p_catalog_source_fields',case when label='linked-country-catalog-timestamp-exact' then jsonb_set(fields,'{rights}','{"catalog":"NEW RAW CATALOG TERMS"}') else fields end)) from request;
`.replaceAll('limit1','limit 1');
fs.writeFileSync(path.join(dir,'native-requests.sql'),sql);
const original=fs.readFileSync(path.join(dir,'concurrent-and-export.ps1'),'utf8');
const prefix=original.slice(0,original.indexOf(" $database='"));
const tail=original.slice(original.indexOf('}finally{')).replaceAll('export-cleanup','request-export-cleanup');
const body=` $database='catalog_freshness_v3_20261030'
 $raw=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'native-requests.sql') 2> (Join-Path $nativeRoot 'native-requests.stderr.log')
 if($LASTEXITCODE -ne 0){throw 'Request-only native export failed'}
 $json=@($raw|Where-Object{$_.StartsWith('{')})
 if($json.Count -ne 1){throw 'Unexpected request export count'}
 [IO.File]::WriteAllText((Join-Path $nativeRoot 'native-requests.json'),$json[0],[Text.UTF8Encoding]::new($false))
 Write-Output 'NATIVE_SYNTHETIC_REQUEST_EXPORT_PASS'
`;
fs.writeFileSync(path.join(dir,'export-requests.ps1'),prefix.replaceAll('postgres-export.log','postgres-requests.log')+body+tail);
