-- Synthetic native fixture request export. Not a public metadata response.
-- Metadata golden responses keep their original point-in-time native states.
-- Reconstruct exact8args from each golden echo plus recorded country cache,
-- falling back only for fixture legacy rows to the exact seed expression.
with m as (
 select label,case when value ? 'canPromote' then value else value->'freshness' end v
 from public.catalog_freshness_fixture_results where value ? 'canPromote' or value->'freshness' ? 'canPromote'
 union all select x->>'label',x->'value' from jsonb_array_elements('[{"label":"concurrent-read-literary_work","value":{"linked":true,"reason":null,"draftId":"f4484ff3-16a3-4971-8d90-c686870f4bda","version":1,"entityId":"8e802640-4440-4c3a-b1e5-c9cd995de6cd","canPromote":true,"entityType":"literary_work","sourceHash":"a7322fa21bc586241cb56e1967550106f055263e799d1e14e9f07b17cd6a597f","draftVersion":1,"candidateHash":"47ad3233304a217e4e29ca7c4b43ffbe2fc7a72e0faca706215bb2b0b67ef499"}},{"label":"concurrent-consumed-literary_work","value":{"linked":false,"reason":"candidate_missing","draftId":"f4484ff3-16a3-4971-8d90-c686870f4bda","version":1,"entityId":"8e802640-4440-4c3a-b1e5-c9cd995de6cd","canPromote":false,"entityType":"literary_work","sourceHash":"a7322fa21bc586241cb56e1967550106f055263e799d1e14e9f07b17cd6a597f","draftVersion":1,"candidateHash":"47ad3233304a217e4e29ca7c4b43ffbe2fc7a72e0faca706215bb2b0b67ef499"}},{"label":"concurrent-read-country","value":{"linked":true,"reason":null,"draftId":"ef132c26-712f-46bf-8175-a3f298d945c5","version":1,"entityId":"catalog-freshness-concurrent","canPromote":true,"entityType":"country","sourceHash":"f47a8208c7866e671ecefb05a5e696bb22c83ac3af51d452ec7ac446e6f84543","draftVersion":1,"candidateHash":"fe9e31a60f573902d7055748cb2615e02843b6399599c702b5b676cd872d3cbc"}},{"label":"concurrent-consumed-country","value":{"linked":false,"reason":"candidate_missing","draftId":"ef132c26-712f-46bf-8175-a3f298d945c5","version":1,"entityId":"catalog-freshness-concurrent","canPromote":false,"entityType":"country","sourceHash":"f47a8208c7866e671ecefb05a5e696bb22c83ac3af51d452ec7ac446e6f84543","draftVersion":1,"candidateHash":"fe9e31a60f573902d7055748cb2615e02843b6399599c702b5b676cd872d3cbc"}}]'::jsonb) x
),request as (select label,v,
 case when v->>'entityType'='country' then coalesce(
  (select a.raw_seed->'catalogFields' from premium_translation_private.catalog_operation_artifacts a where a.entity_type='country' and a.entity_id=v->>'entityId' order by a.created_at limit 1),
  (public.premium_fixture_args('country',v->>'entityId')->'source')||'{"rights":{"catalog":"KEEP RAW CATALOG RIGHTS"},"translations":{"fr":{"locale":"fr","text":"Texte exact"}}}'::jsonb) else null end fields,
 case when v->>'entityType'='country' then coalesce(
  (select a.source_revision->>'catalogSourceHash' from premium_translation_private.catalog_operation_artifacts a where a.entity_type='country' and a.entity_id=v->>'entityId' order by a.created_at limit 1),repeat('b',64)) else null end catalog_hash
 from m)
select jsonb_object_agg(label,jsonb_build_object('p_entity_type',v->'entityType','p_entity_id',v->'entityId','p_draft_id',v->'draftId',
 'p_expected_version',v->'draftVersion','p_candidate_hash',v->'candidateHash','p_source_hash',v->'sourceHash',
 'p_catalog_source_hash',catalog_hash,'p_catalog_source_fields',case when label='linked-country-catalog-timestamp-exact' then jsonb_set(fields,'{rights}','{"catalog":"NEW RAW CATALOG TERMS"}') else fields end)) from request;
