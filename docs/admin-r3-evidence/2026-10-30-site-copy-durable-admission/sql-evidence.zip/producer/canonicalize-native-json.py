import hashlib
import json
import pathlib
import sys

source, target = map(pathlib.Path, sys.argv[1:3])
original = source.read_bytes()
value = json.loads(original.decode("utf-8-sig"))
rendered = (json.dumps(value, ensure_ascii=True, separators=(",", ":")) + "\n").encode("ascii")
target.write_bytes(rendered)
assert json.loads(rendered) == value
print(json.dumps({"classification": "NATIVE_JSON_SERIALIZATION_ONLY_DECODED_VALUES_UNCHANGED", "records": len(value),
                  "rawSha256": hashlib.sha256(original).hexdigest(), "exportSha256": hashlib.sha256(rendered).hexdigest(),
                  "decodedValuesEqual": True, "asciiOnly": True}))
