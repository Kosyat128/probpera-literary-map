// Parent text-draft metadata only. No compile, SDK, PostgreSQL or provider calls.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = __dirname;
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
const record = file => { const b = fs.readFileSync(path.join(root, file)); return { file, bytes: b.length, sha256: hash(b) }; };
const contractPath = path.join(root, 'rpc-contract.json');
const contract = JSON.parse(fs.readFileSync(contractPath, 'utf8'));
contract.staticReview = {
  status: 'TEXT_REVIEW_ONLY_NOT_EXECUTED_NOT_ACCEPTANCE',
  sqlChanges: [
    'Missing JSON proof members compare with IS DISTINCT FROM, not nullable <>.',
    'Initial private proof binds actor/provider/source/intent/raw/config hashes and actual full current singleton seed.',
    'A new private call append independently locks and checks the actual job cancellation/status boundary.',
    'One deferred site-copy cache INSERT event asserts actual current journal construction; BEGIN calls the same assertion explicitly after inserts and before returning its new capability. No GUC or blind ON CONFLICT adoption.',
  ],
  dtoChanges: [
    'Strict selected-key source items, unique keys, existing key validator, 1..50 and original text/hash formats.',
    'Strict expected projection and raw-seed envelope; preserve every actual server-row column.',
    'Raw and expected revisions bind the receipt revision with offset-normalized bigint fractions; PostgreSQL microseconds are preserved.',
    'Immutable deadline delta is exactly45 seconds including fractional timestamp precision.',
    'Raw/source/expected/call aggregate/candidate/individual response caps are enforced structurally.',
  ],
  semanticTrustBoundary: 'Original production JS builds/normalizes the selected RU projection and opaque SHA256(JSON.stringify(items)); no new SQL normalizer or JSONB rehash replaces that semantic contract. Actual helper must independently rebuild/check the original source and candidate before any new dispatch or recovered FINISH.',
  remainingProofObligations: [
    'PostgreSQL parse/runtime/roles/ACL/search_path/security/advisors/old routine and schema comparisons have not run.',
    'The parent draft deferred reverse-construction assertion is not native proof: test existing-row pointer forgery, missing job/item/attempt, SET CONSTRAINTS before/after completion, actual zero-call/cancel/completed-in-same-transaction commits and full rollback.',
    'Actual old promotion/discard/source-save/restore calls must prove unique actual pending draft recognition and immutable linked UUID/body/version, without a legacy-looking downgrade or false rejection.',
    'Promotion versus source/candidate/cache edits, cancellation and dispatch require actual two/three-session lock proofs.',
    'SQL NULL, JSON null, absent and wrong-type private proof members require negative native cases.',
    'Actual installed SDK plus strict DTO parser must bind native final receipts and exact RPC argument names; no generated mocks count as native.',
    'Actual helper/callers must prove feature/runtime checks precede each expense but follow metadata recovery; saved translation body and unknown first delivery must not duplicate expense.',
    'The same cf1/a63 two target cases and nine safety controls must be rerun with original inputs; no altered oracle or shortened path.',
  ],
  intentionallySeparate: 'Explicit trusted partial-pass continuation and nonarticle failed-item/version retry are not implemented by this admission/retention draft. An expired original operation deadline cannot be reset inside that operation.',
};
contract.constructionIntegrity = {
  classification: 'PARENT_TEXT_DRAFT_IMPLEMENTED_NOT_NATIVE_VERIFIED',
  constraint: 'catalog_artifacts_site_copy_admission_complete; AFTER INSERT WHEN NEW.entity_type=site_copy; DEFERRABLE INITIALLY DEFERRED; one cache construction event.',
  assertion: 'site_copy_operation_assert_constructed(operation UUID) reloads the current immutable-identity cache, actual job/item and optional completed attempt; verifies exact actual row proofs plus actor/kind/provider/config/intent/source/op bindings. The initial INSERT snapshot is not mistaken for current terminal state.',
  beforeBeginReturn: 'Same assertion after cache+job+item INSERT and before the fresh canExecute receipt. Existing unrelated job/item/cache IDs are refused before construction; operation replay requires exact original actor/domain/request fingerprint.',
  cancellation: 'Only the already permitted actual monotonic cancellation delta may differ from cached job proof; it preserves the exact item and never grants expense. All other actual job differences fail closed.',
  updateIdentity: 'Immediate private cache guard keeps operation/job/item/actor/kind/entity/full raw seed/config/source/request identity immutable. Existing private journal triggers still compare actual INSERT/UPDATE attempts and rows with exact write proofs.',
  protectedOldKinds: 'The new constraint WHEN and additive guards restrict new behavior to site_copy; old book/country RPC families and validators remain closed and unchanged.',
  nativeStatus: 'NOT_RUN_DURING_ROOT_GLOBAL_V4',
};
contract.actualSelectedItemsAlgorithm = 'See source-input-static-map.json: original Object.entries source order, existing protected projection, ownership/current filters, optional key Set membership, slice50, original JS hash before later provider CRLF/trim normalization.';
fs.writeFileSync(contractPath, JSON.stringify(contract, null, 2) + '\n');
const files = ['site-copy-admission.sql', 'site-copy-translation-operation-rpc.draft.ts', 'rpc-contract.json', 'guards.sql.part', 'prepare-draft.cjs', 'sql-draft-receipt.json', 'source-input-static-map.json', 'source-input-static-map.cjs', 'native-construction-cases.json', 'finalize-static-review.cjs'];
const retainedInitialDrafts = ['site-copy-admission.initial-unvalidated.sql', 'site-copy-translation-operation-rpc.initial-unvalidated.ts', 'guards.initial-unvalidated.sql.part'].map(record);
const manifest = {
  classification: 'PARENT_ONLY_STATIC_REVIEW_TEXT_DRAFT_NOT_TYPECHECKED_NOT_NATIVE_NOT_ACCEPTANCE',
  files: files.map(record), retainedInitialDrafts,
  closedRpcCount: contract.rpc.length,
  receiptFields: contract.receipt.closedFields.length,
  cacheChecksInspected: 9,
  maintainedWrites: 0, databaseStarts: 0, providerCalls: 0, heavyTests: 0,
  validation: 'DEFERRED_ROOT_GLOBAL_V4_LIVE',
};
fs.writeFileSync(path.join(root, 'prepared-draft-manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
process.stdout.write(JSON.stringify({ classification: manifest.classification, files: manifest.files.slice(0, 3), validationsRun: 0 }) + '\n');
