import collections, hashlib, json, pathlib, re, sys

run = pathlib.Path(sys.argv[1])
repo = pathlib.Path(__file__).resolve().parents[2] / 'probpera-literary-map'
def read(name):
    return json.loads((run / name).read_text(encoding='utf-8-sig'))
def digest(p):
    data=p.read_bytes()
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
comparisons={}
for kind,key in [('functions','name'),('tables','name'),('indexes','name'),('constraints','name'),('triggers','name'),('relations','name'),('roles','rolname')]:
    before=read('before-'+kind+'.json'); after=read('after-'+kind+'.json')
    def identity(x):
        return (x.get('schema',''), x.get('table',''), x[key])
    b={identity(x):x for x in before};a={identity(x):x for x in after}
    comparisons[kind]={'beforeCount':len(b),'afterCount':len(a),'added':[list(i) for i in a.keys()-b.keys()],
        'removed':[list(i) for i in b.keys()-a.keys()], 'changed':[{'identity':list(i),'before':b[i],'after':a[i]} for i in b.keys()&a.keys() if b[i]!=a[i]]}
    if kind != 'constraints':
        assert not comparisons[kind]['removed'],kind+' old objects removed'
    assert not comparisons[kind]['changed'],kind+' existing objects changed'
    if kind in ('tables','relations','roles'):
        assert not comparisons[kind]['added'],kind+' new objects added'
assert len(comparisons['indexes']['added'])==1
assert comparisons['constraints']['removed']==[['','premium_translation_private.catalog_operation_artifacts','catalog_operation_artifacts_entity_type_check']]
assert {x[-1] for x in comparisons['constraints']['added']}=={'catalog_artifacts_site_copy_admission_complete','catalog_operation_artifacts_catalog_site_copy_type_check'}
assert len(comparisons['triggers']['added'])==5
wire=read('native-goldens.json'); cases=read('native-cases.json')
assert len(wire)>123
assert read('concurrency/results.json')['pass']==12 and read('concurrency/results.json')['fail']==0
cleanup=read('completion-cleanup.json');assert cleanup['pgCtlExitCode']==0 and not cleanup['processRemains'] and not cleanup['pidFileRemains']
assert read('completion-receipt.json')['exitCode']==0
live=read('post-cleanup-liveness.json');assert not live['processRemains'] and not live['pidFileRemains'] and live['listenerCount']==0
clients=read('concurrency/session-cleanup.json')['sessions'];assert len(clients)==26 and all(x['closed'] and x['exitCode']==0 for x in clients)
actual=read('actual-retained-candidate.json'); artifact=read('native-real-js-final-artifact.json')
assert actual==artifact['candidate'] and artifact['receipt']['sourceHash']=='428450394708d92b258fe25a1360ef780c7899187952036ae000a13e8a851944'
assert [i['key'] for i in actual['payload']['items']]==['cta','intro']
beforemanual=[json.loads(s) for s in (run/'manual-restore-before.raw.log').read_text(encoding='utf-8-sig').splitlines() if s.startswith('{')]
assert len(beforemanual)==1
manual=next(x['value'] for x in cases if x['label']=='paid-fullrow-manual-restore-discard-legacy')
assert beforemanual[0]['payload']==manual['manualRestorePayload']
summary={'classification':'FINAL_NATIVE_SQL_PROOF_PENDING_INDEPENDENT_READBACK_AND_SDK_FINAL_CONFORMANCE',
 'database':read('run-receipt.json')['database'],'sameFoundationComparison':comparisons,
 'nativeWireRecords':len(wire),'nativeWireByRpc':dict(collections.Counter(x['rpc'] for x in wire)),
 'nativeCaseLabels':[x['label'] for x in cases], 'concurrency':read('concurrency/results.json'),
 'cleanup':cleanup,'postCleanupLiveness':live,'ownPsqlClientsTerminal':len(clients),'firstPhaseCleanup':read('cleanup.json'),'completion':read('completion-receipt.json'),'advisorsLint':read('advisors-lint-receipt.json'),
 'actualRetainedBridge':{'fullCandidateEquality':True,'selectedOrder':['cta','intro'],'sourceHash':artifact['receipt']['sourceHash'],'externalProviderCalls':0},
 'manualRestoreBeforeAfterActualPayloadEquality':True,
 'scope':['Owned loopback PostgreSQL17.11; exact selected old DDL and synthetic Auth stubs, not a managed Supabase Auth/browser stack.',
 'Installed SDK replay is separate test-agent proof. Native raw journal/SQL proofs include opaque source hash cases plus one real unchanged JS-source retained reconstruction.',
 'Admission preserves unknown and partial accepted responses; explicit trusted continuation and nonarticle addressed failed-item retry remain separate requirements.'],
 'bindings':[{ 'file':str(p),**digest(p)} for p in [repo/'supabase/migrations/20261030094705_site_copy_translation_operation_admission.sql',repo/'scripts/database/fixtures/site-copy-translation-operation-admission.sql',repo/'apps/admin/lib/site-copy-translation-operation-rpc.ts',repo/'apps/admin/lib/site-copy-translation-candidate-freshness-rpc.ts',run/'native-goldens.json',run/'fixture-cases.sql',run/'migration.sql',run/'foundation.sql',run/'run.ps1']]}
def advisor(name):
    text=(run/name).read_text(encoding='utf-8-sig')
    return json.loads(next(s for s in text.splitlines() if s.startswith('{')))
before_advisors=advisor('security-advisors-before.raw.log')
after_advisors=advisor('security-advisors-after-migration.raw.log')
assert before_advisors==after_advisors
summary['securityAdvisors']={'sameFoundationExactJsonEquality':True,'beforeCount':len(before_advisors['results']),
 'afterCount':len(after_advisors['results']),'levels':dict(collections.Counter(x['level'] for x in before_advisors['results'])),
 'newFindings':0,'scope':'Includes exact selected foundation and synthetic fixture warnings; not a production or managed-stack clean-advisor claim.'}
(run/'native-summary.json').write_text(json.dumps(summary,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:summary[k] for k in ['classification','nativeWireRecords','nativeWireByRpc','manualRestoreBeforeAfterActualPayloadEquality']}))
