const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const file=path.resolve(__dirname,'../../probpera-literary-map/scripts/database/fixtures/site-copy-translation-operation-admission.sql');
const input=path.resolve(__dirname,'../site-copy-durable-tests-sol/native-real-js-seed.json');
const bytes=fs.readFileSync(input),seed=JSON.parse(bytes);
assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),'f5e49f4925b44ce0d2fcc023d2c9c40a7557bf2173b722f7171959808ca7354d');
const data={sourceSnapshot:seed.sourceSnapshot,sourceHash:seed.sourceHash,configuration:seed.configuration,dispatch:seed.dispatchArgs,responseMetadata:seed.responseArgs.p_metadata,responseArtifact:seed.responseArgs.p_response_artifact,orderedPayload:seed.orderedPayload};
// ASCII escaping changes source representation only; JSONB decodes the exact
// original values and original production JS semantic hashes remain unchanged.
const encoded=JSON.stringify(data).replace(/[\u007f-\uffff]/gu,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));
assert(!encoded.includes('$native_real_js$'));
const sql=`
-- Actual unchanged JS builder/hash + actual production one-pass raw response,
-- then real native journal. The owner runner derives FINISH through the actual
-- installed SDK/retained helper from this native GET, never a copied test time.
create function public.site_copy_operation_fixture_real_js_input()
returns jsonb language sql immutable set search_path='' as $$ select $native_real_js$${encoded}$native_real_js$::jsonb; $$;
do $$ declare input jsonb;a jsonb;r jsonb;request jsonb;metadata jsonb;artifact jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 input:=public.site_copy_operation_fixture_real_js_input();a:=public.site_copy_operation_fixture_seed(false);
 assert a#>'{sourceSnapshot,settings}'=input#>'{sourceSnapshot,settings}','actual native canonical settings equal production builder input';
 a:=a||jsonb_build_object('sourceSnapshot',input->'sourceSnapshot','sourceHash',input->'sourceHash','configuration',input->'configuration','payload',input->'orderedPayload');
 set local role authenticated;r:=public.site_copy_operation_fixture_begin(a);
 request:=(input->'dispatch')||jsonb_build_object('p_job_id',r->'jobId','p_item_id',r->'itemId','p_operation_id',r->'operationId','p_call_id',gen_random_uuid());
 r:=public.site_copy_operation_fixture_call('record_site_copy_translation_operation_dispatch',request);
 metadata:=(input->'responseMetadata')||jsonb_build_object('callId',r->'pendingCallId');
 r:=public.site_copy_operation_fixture_call('record_site_copy_translation_operation_response',jsonb_build_object('p_job_id',r->'jobId','p_item_id',r->'itemId','p_operation_id',r->'operationId',
  'p_metadata',metadata,'p_response_artifact',input->'responseArtifact'));
 artifact:=public.site_copy_operation_fixture_artifact(r);reset role;
 assert artifact#>>'{receipt,sourceHash}'='428450394708d92b258fe25a1360ef780c7899187952036ae000a13e8a851944';
 insert into public.site_copy_operation_fixture_results values('real-js-native-input',jsonb_build_object('artifact',artifact,'expectedPayload',input->'orderedPayload',
  'actualBuilderSeedSha256','f5e49f4925b44ce0d2fcc023d2c9c40a7557bf2173b722f7171959808ca7354d','nativeReceiptBodyBeforeTrustedFinish',true));
end; $$;
select 'M07_SITE_COPY_NATIVE_REAL_JS_INPUT_RECORDED_PASS';
`;
let current=fs.readFileSync(file,'utf8');
const marker='-- Actual unchanged JS builder/hash + actual production one-pass raw response,';
const at=current.indexOf(marker);
if(at>=0){const endMarker="select 'M07_SITE_COPY_NATIVE_REAL_JS_INPUT_RECORDED_PASS';";const end=current.indexOf(endMarker,at);assert(end>at);current=current.slice(0,at)+current.slice(end+endMarker.length);}
current=current.replaceAll(String.fromCodePoint(0x2014),String.raw`\u2014`);
fs.writeFileSync(file,current.trimEnd()+'\n'+sql);
console.log(JSON.stringify({realSeedHash:seed.sourceHash,seedSha256:'f5e49f4925b44ce0d2fcc023d2c9c40a7557bf2173b722f7171959808ca7354d',externalProviderCalls:0}));
