const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const work=path.resolve(__dirname,'..'),repo=path.resolve(work,'../probpera-literary-map');
const run=process.argv[2]||'v1',dir=path.join(work,'site-copy-admission-sql-native',run),fast=process.argv[3]==='--owned-v2-baseline';
fs.mkdirSync(dir,{recursive:true});
const basePath=path.join(work,'profile-scan-sql-native/v5/fixture.sql');
const migration='supabase/migrations/20261030094705_site_copy_translation_operation_admission.sql';
const fixture='scripts/database/fixtures/site-copy-translation-operation-admission.sql';
const base=fs.readFileSync(basePath,'utf8');
const oldHistoryFile='supabase/migrations/20260812_homepage_block_revisions.sql';
const oldHistory=fs.readFileSync(path.join(repo,oldHistoryFile),'utf8');
const snapshot=`\nreset role;set timezone='UTC';
create table if not exists public.site_copy_operation_fixture_baseline(label text primary key,value jsonb not null);
truncate public.site_copy_operation_fixture_baseline;
insert into public.site_copy_operation_fixture_baseline values('functions',(select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'source',p.prosrc,'securityDefiner',p.prosecdef,'config',p.proconfig,'acl',p.proacl) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in ('premium_translation_private','probpera_translation_operations') or(n.nspname='public' and p.proname not like '%fixture%' and(p.proname like '%translation%' or p.proname like '%premium%'))));
insert into public.site_copy_operation_fixture_baseline values('tables',(select jsonb_agg(jsonb_build_object('name',c.oid::regclass::text,'acl',c.relacl,'forceRls',c.relforcerowsecurity,'rls',c.relrowsecurity,'columns',(select jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull) order by a.attnum) from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped)) order by c.oid::regclass::text) from pg_class c where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass,'public.premium_translation_working_drafts'::regclass,'public.homepage_blocks'::regclass)));
insert into public.site_copy_operation_fixture_baseline values('indexes',(select jsonb_agg(jsonb_build_object('schema',n.nspname,'name',ci.relname,'definition',pg_get_indexdef(ci.oid)) order by n.nspname,ci.relname) from pg_index i join pg_class c on c.oid=i.indrelid join pg_class ci on ci.oid=i.indexrelid join pg_namespace n on n.oid=ci.relnamespace where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass,'public.premium_translation_working_drafts'::regclass,'public.homepage_blocks'::regclass)));
insert into public.site_copy_operation_fixture_baseline values('constraints',(select jsonb_agg(jsonb_build_object('name',conname,'table',conrelid::regclass::text,'definition',pg_get_constraintdef(oid)) order by conrelid::regclass::text,conname) from pg_constraint where conrelid in('premium_translation_private.catalog_operation_artifacts'::regclass,'public.premium_translation_working_drafts'::regclass)));
`;
fs.writeFileSync(path.join(dir,'fixture.sql'),(fast?'':base)+'\n'+oldHistory+'\n'+snapshot+'\n'+fs.readFileSync(path.join(repo,migration),'utf8')+'\n'+fs.readFileSync(path.join(repo,fixture),'utf8'));
const oldRunner=fs.readFileSync(path.join(work,'profile-scan-sql-native/v5/run.ps1'),'utf8');
const nativeShort='C:\\Users\\685F~1\\DOCUME~1\\Codex\\2026-1~1\\v\\work\\site-copy-admission-sql-native\\'+run;
let runner=oldRunner.replace(/\$nativeRoot='[^']+'/,'$nativeRoot='+"'"+nativeShort+"'").replace("$database='profile_scan_v5_20261030'",`$database='site_copy_admission_${run}_20261030'`);
if(fast){
 runner=runner.replace(' & $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc --set=ON_ERROR_STOP=1 -c "create database $database"',
  ` $oldFamilyCount=& $psql -h 127.0.0.1 -p 55438 -U postgres -d site_copy_admission_v2_20261030 --no-psqlrc -Atc "select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='premium_translation_private' and p.proname like 'site_copy_operation_%'"
 if($LASTEXITCODE -ne 0 -or $oldFamilyCount -ne '0'){throw 'Owned v2 template is not the rolled-back pre-admission baseline'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc --set=ON_ERROR_STOP=1 -c "create database $database template site_copy_admission_v2_20261030"`);
}
const beforeInput=path.join(__dirname,'manual-restore-before.sql');
fs.copyFileSync(beforeInput,path.join(dir,'manual-restore-before.sql'));
runner=runner.replace(" $database='site_copy_admission_"+run+"_20261030'",` & $psql -h 127.0.0.1 -p 55438 -U postgres -d site_copy_admission_v2_20261030 --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'manual-restore-before.sql') *> (Join-Path $nativeRoot 'manual-restore-before.raw.log')
 if($LASTEXITCODE -ne 0){throw 'Old actual guarded-save BEFORE failed'}
 $database='site_copy_admission_${run}_20261030'`);
runner=runner.replace("if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}", "if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}\nif(@(Get-NetTCPConnection -LocalPort 55438 -State Listen -ErrorAction SilentlyContinue).Count -ne 0){throw 'Unexpected listener on owned loopback port'}");
runner=runner.replace(" Get-Content -LiteralPath(Join-Path $nativeRoot 'run.log')|Select-Object -Last 9",` if($exitCode -eq 0){
  $realInput=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select value->'artifact' from public.site_copy_operation_fixture_results where label='real-js-native-input'"
  if($LASTEXITCODE -ne 0 -or -not $realInput){throw 'Real JS native input missing'}
  $realInput|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-real-js-before.json') -Encoding utf8
  & node 'C:\\Users\\Костя\\Documents\\Codex\\2026-10-09\\v\\work\\site-copy-durable-tests-sol\\native-candidate-from-artifact.cjs' (Join-Path $nativeRoot 'native-real-js-before.json') (Join-Path $nativeRoot 'actual-retained-candidate.json') *> (Join-Path $nativeRoot 'actual-retained-candidate.log')
  if($LASTEXITCODE -ne 0){throw 'Actual SDK and retained builder could not reconstruct native GET'}
  & node 'C:\\Users\\Костя\\Documents\\Codex\\2026-10-09\\v\\work\\site-copy-durable-admission-next\\prepare-real-js-finish.cjs' (Join-Path $nativeRoot 'native-real-js-before.json') (Join-Path $nativeRoot 'actual-retained-candidate.json') (Join-Path $nativeRoot 'real-js-finish.sql') *> (Join-Path $nativeRoot 'real-js-finish-prepare.log')
  if($LASTEXITCODE -ne 0){throw 'Actual retained candidate FINISH preparation failed'}
  & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'real-js-finish.sql') *> (Join-Path $nativeRoot 'real-js-finish.raw.log')
  if($LASTEXITCODE -ne 0){throw 'Native FINISH of actual retained production candidate failed'}
  $realFinal=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select value->'artifact' from public.site_copy_operation_fixture_results where label='real-js-native-roundtrip'"
  if($LASTEXITCODE -ne 0 -or -not $realFinal){throw 'Real JS final native GET missing'}
  $realFinal|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-real-js-final-artifact.json') -Encoding utf8
  $wire=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select coalesce(jsonb_agg(jsonb_build_object('rpc',e.rpc,'args',e.args,'response',e.response) order by e.at_time,e.id),'[]'::jsonb) from (select rpc,args,response,at_time::text,id::text from public.site_copy_operation_fixture_wire union all select trace.entry->>'rpc',trace.entry->'args',trace.entry->'response',trace.entry->>'at_time',trace.entry->>'id' from public.site_copy_operation_fixture_results r cross join lateral jsonb_array_elements(coalesce(r.value->'observedWire','[]'::jsonb)) trace(entry)) e"
  if($LASTEXITCODE -ne 0){throw 'Native wire export failed'}
  $wire|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-goldens.raw-utf8.json') -Encoding utf8
  & python 'C:\\Users\\Костя\\Documents\\Codex\\2026-10-09\\v\\work\\site-copy-durable-admission-next\\canonicalize-native-json.py' (Join-Path $nativeRoot 'native-goldens.raw-utf8.json') (Join-Path $nativeRoot 'native-goldens.json') *> (Join-Path $nativeRoot 'native-json-canonicalization.json')
  if($LASTEXITCODE -ne 0){throw 'Native JSON equivalent ASCII export failed'}
  $cases=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select coalesce(jsonb_agg(jsonb_build_object('label',label,'value',value) order by label),'[]'::jsonb) from public.site_copy_operation_fixture_results"
  if($LASTEXITCODE -ne 0){throw 'Native case export failed'}
  $cases|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-cases.json') -Encoding utf8
 }
 Get-Content -LiteralPath(Join-Path $nativeRoot 'run.log')|Select-Object -Last 9`);
fs.writeFileSync(path.join(dir,'run.ps1'),runner);
const bindings=[{file:basePath},{file:beforeInput},...['supabase/migrations/20261030072209_profile_translation_stable_scan.sql',oldHistoryFile,migration,fixture,'apps/admin/lib/site-copy-translation-operation-rpc.ts','apps/admin/lib/site-copy-translation-candidate-freshness-rpc.ts'].map(file=>({file:path.join(repo,file)}))].map(({file})=>{const b=fs.readFileSync(file);return{file,bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')};});
fs.writeFileSync(path.join(dir,'source-manifest.json'),JSON.stringify({classification:'NATIVE_INPUTS_NOT_YET_EXECUTED',bindings,syntheticAuth:true,providers:0,loopback:'127.0.0.1:55438',existingOwnedCluster:true,foundation:fast?'Owned v2 complete old-native baseline; verify new private family0 after failed new migration rolled back, clone into unique new DB. Debug iteration only; final full-prefix proof remains required.':'Full exact inherited v5 fixture plus new baseline snapshot.'},null,2)+'\n');
console.log(JSON.stringify({dir,inputs:bindings.map(({file,sha256})=>({file,sha256}))}));
