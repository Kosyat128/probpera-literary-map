const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const repo = path.resolve(__dirname, '../../probpera-literary-map');
const migration = 'supabase/migrations/20261030094705_site_copy_translation_operation_admission.sql';
const adapter = 'apps/admin/lib/site-copy-translation-operation-rpc.ts';
const sql = fs.readFileSync(path.join(__dirname, 'site-copy-admission.sql'), 'utf8');
assert.equal(crypto.createHash('sha256').update(sql).digest('hex'), '30b49995fa2876b1b1fb224294d08239af75915990e963853470aa005893aa96');
assert.equal(fs.statSync(path.join(repo, migration)).size, 0, 'CLI-created migration must still be empty');
const prefix = '-- PARENT-ONLY UNEXECUTED SITE-COPY ADMISSION DRAFT. NOT A MIGRATION.';
assert(sql.startsWith(prefix));
fs.writeFileSync(path.join(repo, migration), sql.replace(prefix, '-- Site-copy durable provider admission and retained response artifacts.'));
const dto = fs.readFileSync(path.join(__dirname, 'site-copy-translation-operation-rpc.draft.ts'), 'utf8');
assert.equal(crypto.createHash('sha256').update(dto).digest('hex'), '796b79c09abcac97fa8eb9e1d36281b5451bf1b4296e673dd19a51c06762e639');
fs.writeFileSync(path.join(repo, adapter), dto.replace('// PARENT-ONLY UNVALIDATED DTO DRAFT. Imports target the future apps/admin/lib location.', '// Closed staff RPC adapter for durable site-copy translation operations.'), { flag: 'wx' });
const bindings = [migration, adapter].map(file => {
  const b = fs.readFileSync(path.join(repo, file));
  return { file, bytes: b.length, sha256: crypto.createHash('sha256').update(b).digest('hex') };
});
const receipt = { classification: 'FORMAL_NEW_FILES_UNVALIDATED_NATIVE_PENDING', cliVersion: '2.120.0', cliCommand: 'supabase migration new site_copy_translation_operation_admission', cliCreatedEmptyBeforeCopy: true, bindings,
  initialCliFailure: 'Telemetry write EPERM outside workspace; recovered using existing SUPABASE_TELEMETRY_DISABLED=1/DO_NOT_TRACK=1/SUPABASE_NO_UPDATE_NOTIFIER=1/SUPABASE_NO_KEYRING=1 environment, no additional filesystem permission.', databaseStarts: 0, providerCalls: 0 };
fs.writeFileSync(path.join(__dirname, 'formal-landing-receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
process.stdout.write(JSON.stringify(receipt) + '\n');
