// Parent-only preparation. No maintained source, migration or database mutation.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const file='supabase/migrations/20261029220832_catalog_translation_operation_admission.sql',base=fs.readFileSync(path.join(repo,file),'utf8');
function extract(name){const start=base.indexOf(`create function ${name}(`);assert(start>=0,name);const open=base.indexOf('$$',start),end=base.indexOf('$$;',open+2);assert(end>open,name);return base.slice(start,end+3);}
function rename(text){return text.replaceAll('catalog_operation_artifacts','__COMMON_ARTIFACT_TABLE__').replaceAll('catalog_operation_','site_copy_operation_').replaceAll('catalog_translation_operation','site_copy_translation_operation').replaceAll('catalogOperation','siteCopyOperation').replaceAll('translation.catalog_operation.','translation.site_copy_operation.').replaceAll('__COMMON_ARTIFACT_TABLE__','catalog_operation_artifacts');}
let config=rename(extract('premium_translation_private.catalog_operation_configuration_valid'))
 .replace('(k text,v jsonb,p text)','(v jsonb,p text)')
 .replace("(case k when 'literary_work' then 'probpera_literary_work_translation' else 'probpera_country_profile_translation' end)","'probpera_site_copy_translation'")
 .replace("to_jsonb(case k when 'literary_work' then 4000 else 12000 end)","'12000'::jsonb");
assert(!config.includes('case k'));
let dispatch=rename(extract('public.record_catalog_translation_operation_dispatch'));
dispatch=dispatch.replace("security definer set search_path='' as $$", () => "security definer set search_path='' set timezone='UTC' as $$");
dispatch=dispatch.replace("if a.final_receipt is not null or j.cancel_requested_at is not null or j.status<>'reviewing'", "if a.final_receipt is not null or j.cancel_requested_at is not null or j.status<>'reviewing' or stamp>=a.created_at+interval '45 seconds'");
assert(dispatch.includes("stamp>=a.created_at+interval '45 seconds'"));
const response=rename(extract('public.record_catalog_translation_operation_response'))
 .replace("security definer set search_path='' as $$", () => "security definer set search_path='' set timezone='UTC' as $$");
const progress=rename(extract('premium_translation_private.catalog_operation_progress'));
const sql=[];
sql.push(`-- PARENT-ONLY UNEXECUTED SITE-COPY ADMISSION DRAFT. NOT A MIGRATION.
-- Seven closed staff RPCs; no new queue/table/column/role/lease grant.
-- One additional staff metadata read proves paid candidate full-row freshness.
-- Existing book/country functions and old migration files are not replaced.
begin;
do $check$ declare name text;n integer;att smallint;begin
 select attnum into att from pg_attribute where attrelid='premium_translation_private.catalog_operation_artifacts'::regclass and attname='entity_type';
 select count(*),min(conname) into n,name from pg_constraint where conrelid='premium_translation_private.catalog_operation_artifacts'::regclass and contype='c' and conkey=array[att];
 if n<>1 then raise exception 'Unexpected catalog artifact identity CHECK layout' using errcode='42501';end if;
 execute format('alter table premium_translation_private.catalog_operation_artifacts drop constraint %I',name);
 alter table premium_translation_private.catalog_operation_artifacts add constraint catalog_operation_artifacts_catalog_site_copy_type_check check(entity_type in ('literary_work','country','site_copy'));
end;$check$;
create unique index translation_site_copy_active_operation_unique on public.translation_job_items(entity_type)
 where entity_type='site_copy' and staff_retry is not null;
`);
sql.push(config,progress);
sql.push(`create function premium_translation_private.site_copy_operation_scope_lock()
returns void language sql volatile security invoker set search_path='' as $$
 select pg_advisory_xact_lock(hashtextextended('site-copy-operation:site-copy-overrides',7391));
$$;
create function premium_translation_private.site_copy_operation_source_valid(identity text,s jsonb,r jsonb,t jsonb,seed jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare item jsonb;seen text[]:='{}';k text;begin
 perform premium_translation_private.assert_identity('site_copy',identity);
 if not premium_translation_private.exact_object(s,array['settings','items']) or jsonb_typeof(s->'settings') is distinct from 'object'
  or s#>>'{settings,systemKey}' is distinct from 'site-copy-overrides' or jsonb_typeof(s->'items') is distinct from 'array'
  or jsonb_array_length(s->'items') not between 1 and 50 or octet_length(s::text)>4194304
  or not premium_translation_private.exact_object(r,array['blockId','blockUpdatedAt'])
  or (r->>'blockId')::uuid is distinct from identity::uuid
  or not premium_translation_private.valid_revision(t)
  or jsonb_build_object('id',r->'blockId','updatedAt',r->'blockUpdatedAt') is distinct from t
  or not premium_translation_private.exact_object(seed,array['version','block']) or seed->'version'<>'1'::jsonb
  or seed#>'{block,settings}' is distinct from s->'settings'
  or (seed#>>'{block,id}')::uuid is distinct from identity::uuid
  or (seed#>>'{block,updated_at}')::timestamptz is distinct from (r->>'blockUpdatedAt')::timestamptz then return false;end if;
 for item in select value from jsonb_array_elements(s->'items') loop
  if not premium_translation_private.exact_object(item,array['key','text','sourceHash']) or jsonb_typeof(item->'key') is distinct from 'string'
   or jsonb_typeof(item->'text') is distinct from 'string' or jsonb_typeof(item->'sourceHash') is distinct from 'string'
   or coalesce(item->>'sourceHash','')!~'^[a-f0-9]{64}$'
   or premium_translation_private.site_copy_utf16_length(item->>'text') not between 1 and 4000
   or premium_translation_private.trim_text(item->>'text')='' then return false;end if;
  k:=item->>'key';if premium_translation_private.site_copy_utf16_length(k) not between 1 and 1200 or k<>premium_translation_private.trim_text(k)
   or k~'[[:cntrl:]]' or k~*'(^|\\.)(__proto__|prototype|constructor)(\\.|$)' or k=any(seen) then return false;end if;
  seen:=array_append(seen,k);
 end loop;
 -- Existing server JS projection/hash semantics stay opaque: no SQL hyphen
 -- normalizer or JSONB replacement for SHA256(JSON.stringify(items)).
 perform premium_translation_private.assert_site_copy_recorded(s);return true;
exception when others then return false;end; $$;
create function premium_translation_private.site_copy_operation_capture(identity text,expected jsonb)
returns jsonb language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare b public.homepage_blocks%rowtype;n integer;begin
 perform pg_advisory_xact_lock(188654771,2);
 select count(*) into n from public.homepage_blocks where settings @> '{"systemKey":"site-copy-overrides"}';
 if n<>1 then raise exception 'Site Copy master missing or ambiguous' using errcode='40001';end if;
 select * into b from public.homepage_blocks where id=identity::uuid for update;
 if b.id is null or b.settings->>'systemKey'<>'site-copy-overrides'
  or not premium_translation_private.exact_object(expected,array['version','block']) or expected->'version'<>'1'::jsonb
  or not premium_translation_private.exact_object(expected->'block',array['id','settings','updated_at'])
  or (expected#>>'{block,id}')::uuid is distinct from b.id or expected#>'{block,settings}' is distinct from b.settings
  or (expected#>>'{block,updated_at}')::timestamptz is distinct from b.updated_at then
  raise exception 'Site Copy expected projection changed' using errcode='40001';end if;
 return jsonb_build_object('version',1,'block',to_jsonb(b));
end; $$;
create function premium_translation_private.site_copy_operation_assert_current(a premium_translation_private.catalog_operation_artifacts)
returns void language plpgsql volatile security invoker set search_path='' as $$ declare seed jsonb;begin
 seed:=premium_translation_private.site_copy_operation_capture(a.entity_id,a.expected_state);
 if seed is distinct from a.raw_seed or premium_translation_private.site_copy_operation_source_valid(a.entity_id,a.source_snapshot,a.source_revision,a.target_revision,seed) is distinct from true then
  raise exception 'Site Copy full recorded source changed' using errcode='40001';end if;
end; $$;
create function premium_translation_private.site_copy_operation_owned(p_job uuid,p_item uuid,p_operation uuid)
returns premium_translation_private.catalog_operation_artifacts language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;begin
 perform premium_translation_private.assert_actor();perform premium_translation_private.site_copy_operation_scope_lock();
 select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation for update;
 if a.operation_id is null then raise exception 'Site Copy operation not found' using errcode='P0002';end if;
 if a.actor_id is distinct from auth.uid() then raise exception 'Site Copy operation actor differs' using errcode='42501';end if;
 if a.job_id is distinct from p_job or a.item_id is distinct from p_item or a.entity_type<>'site_copy' then
  raise exception 'Site Copy operation identity differs' using errcode='40001';end if;return a;
end; $$;
create function premium_translation_private.site_copy_operation_view(a premium_translation_private.catalog_operation_artifacts,
 replayed boolean default false,execute_allowed boolean default false,dispatch_allowed boolean default false)
returns jsonb language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare j public.translation_jobs%rowtype;pending uuid;reason text;phase text:='running';begin
 select * into j from public.translation_jobs where id=a.job_id;
 select (value#>>'{metadata,callId}')::uuid into pending from jsonb_array_elements(a.calls) where value#>'{metadata,responseReceivedAt}'='null'::jsonb limit 1;
 if a.final_receipt is not null then return a.final_receipt||jsonb_build_object('replayed',replayed,'canExecute',false,'canDispatch',false);end if;
 if auth.uid() is distinct from a.actor_id then reason:='operation_owned_by_another_actor';
 elsif pending is not null and not dispatch_allowed then reason:='provider_outcome_unknown';
 elsif j.cancel_requested_at is not null then reason:='operation_stopped';
 elsif clock_timestamp()>=a.created_at+interval '45 seconds' and not dispatch_allowed then reason:='operation_deadline';end if;
 if reason is not null then phase:='blocked';end if;
 return jsonb_build_object('version',1,'logicalScope','site-copy-overrides','jobId',a.job_id,'itemId',a.item_id,'operationId',a.operation_id,
  'entityType','site_copy','entityId',a.entity_id,'actorId',a.actor_id,'provider',a.provider,'sourceHash',a.source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,
  'configurationHash',a.configuration_hash,'configuration',a.configuration,'sourceRevision',a.source_revision,'targetRevision',a.target_revision,
  'startedAt',a.created_at,'deadlineAt',a.created_at+interval '45 seconds','jobVersion',j.version::text,'phase',phase,
  'canExecute',execute_allowed and reason is null,'canDispatch',dispatch_allowed,'replayed',replayed,'providerCalls',jsonb_array_length(a.calls),
  'pendingCallId',pending,'blockReason',reason,'resumeCursor','{}'::jsonb,'result',null);
end; $$;
create function public.reconcile_site_copy_translation_operation(p_operation_id uuid default null)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;begin
 perform premium_translation_private.assert_actor();perform premium_translation_private.site_copy_operation_scope_lock();
 if p_operation_id is not null and not probpera_translation_operations.retry_uuid(p_operation_id) then raise exception 'Invalid Site Copy operation' using errcode='22023';end if;
 -- Logical active scope first, before a recreated block ID/config/feature read.
 select c.* into a from premium_translation_private.catalog_operation_artifacts c join public.translation_job_items i on i.id=c.item_id
  where c.entity_type='site_copy' and i.entity_type='site_copy' and i.staff_retry is not null order by c.created_at desc,c.operation_id desc limit 1;
 if a.operation_id is null then
  select * into a from premium_translation_private.catalog_operation_artifacts where entity_type='site_copy' and(p_operation_id is null or operation_id=p_operation_id)
   order by created_at desc,operation_id desc limit 1;
 end if;
 if a.operation_id is null then return null;end if;return premium_translation_private.site_copy_operation_view(a,true);
end; $$;
create function public.get_site_copy_translation_operation_artifacts(p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_intent_hash text,p_source_hash text,p_raw_seed_hash text)
returns jsonb language plpgsql volatile security definer set search_path='' as $$ declare a premium_translation_private.catalog_operation_artifacts%rowtype;begin
 a:=premium_translation_private.site_copy_operation_owned(p_job_id,p_item_id,p_operation_id);
 if a.intent_hash is distinct from p_intent_hash or a.source_hash is distinct from p_source_hash or a.raw_seed_hash is distinct from p_raw_seed_hash then
  raise exception 'Site Copy private artifact binding differs' using errcode='40001';end if;
 return jsonb_build_object('version',1,'receipt',premium_translation_private.site_copy_operation_view(a,true),'expectedState',a.expected_state,'rawSeed',a.raw_seed,
  'sourceSnapshot',a.source_snapshot,'sourceRevision',a.source_revision,'targetRevision',a.target_revision,'configuration',a.configuration,'calls',a.calls,'candidate',a.candidate);
end; $$;`);
sql.push(`create function public.begin_site_copy_translation_operation(p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_block_id uuid,p_provider text,
 p_source_hash text,p_source_snapshot jsonb,p_source_revision jsonb,p_target_revision jsonb,p_expected_state jsonb,p_configuration jsonb)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare actor uuid:=premium_translation_private.assert_actor();a premium_translation_private.catalog_operation_artifacts%rowtype;
 j public.translation_jobs%rowtype;i public.translation_job_items%rowtype;request_hash text;marker jsonb;view jsonb;stamp timestamptz:=clock_timestamp();identity text;begin
 perform premium_translation_private.site_copy_operation_scope_lock();
 select c.* into a from premium_translation_private.catalog_operation_artifacts c join public.translation_job_items x on x.id=c.item_id where c.entity_type='site_copy' and x.entity_type='site_copy' and x.staff_retry is not null for update of c;
 if a.operation_id is not null then
  view:=premium_translation_private.site_copy_operation_view(a,true);
  return view||jsonb_build_object('phase','blocked','blockReason',coalesce(view->>'blockReason','operation_in_progress'),'canExecute',false,'canDispatch',false);
 end if;
 identity:=p_block_id::text;
 if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
  or not probpera_translation_operations.retry_uuid(p_operation_id) or not probpera_translation_operations.retry_uuid(p_block_id)
  or p_provider is null or p_provider not in('cloudflare','openai') or coalesce(p_source_hash,'')!~'^[a-f0-9]{64}$'
  or premium_translation_private.site_copy_operation_configuration_valid(p_configuration,p_provider) is distinct from true
  or jsonb_typeof(p_expected_state) is distinct from 'object' or octet_length(p_expected_state::text)>4194304 then
  raise exception 'Invalid Site Copy admission' using errcode='22023';end if;
 request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_job_id,p_item_id,p_operation_id,actor,identity,p_provider,p_source_hash,
  p_source_snapshot,p_source_revision,p_target_revision,p_expected_state,p_configuration));
 perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7292));
 select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation_id for update;
 if a.operation_id is not null then
  if a.entity_type<>'site_copy' or a.actor_id<>actor then raise exception 'Site Copy operation actor/domain differs' using errcode='42501';end if;
  if a.begin_request_hash<>request_hash then raise exception 'Site Copy begin intent differs' using errcode='40001';end if;
  return premium_translation_private.site_copy_operation_view(a,true);
 end if;
 perform pg_advisory_xact_lock(hashtextextended('premium-translation:site_copy:'||identity,0));
 if exists(select 1 from public.translation_jobs where id=p_job_id) or exists(select 1 from public.translation_job_items where id=p_item_id)
  or exists(select 1 from premium_translation_private.catalog_operation_artifacts where job_id=p_job_id or item_id=p_item_id)
  or exists(select 1 from premium_translation_private.writer_operation_artifacts where operation_id=p_operation_id)
  or exists(select 1 from public.translation_job_attempts where staff_retry_operation_id=p_operation_id)
  or exists(select 1 from public.translation_job_items where staff_retry is not null and staff_retry->>'operationId'=p_operation_id::text)
  or exists(select 1 from public.premium_translation_working_drafts where entity_type='site_copy' and lower(entity_id)=identity) then
  raise exception 'Site Copy identity or pending candidate already exists' using errcode='40001';end if;
 a.raw_seed:=premium_translation_private.site_copy_operation_capture(identity,p_expected_state);
 if octet_length(a.raw_seed::text)>4194304 or premium_translation_private.site_copy_operation_source_valid(identity,p_source_snapshot,p_source_revision,p_target_revision,a.raw_seed) is distinct from true then
  raise exception 'Site Copy source/target eligibility changed' using errcode='40001';end if;
 a.operation_id:=p_operation_id;a.job_id:=p_job_id;a.item_id:=p_item_id;a.actor_id:=actor;a.entity_type:='site_copy';a.entity_id:=identity;
 a.provider:=p_provider;a.source_hash:=p_source_hash;a.begin_request_hash:=request_hash;a.expected_state:=p_expected_state;
 a.raw_seed_hash:=probpera_translation_operations.retry_fingerprint(a.raw_seed);a.intent_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(request_hash,a.raw_seed_hash));
 a.configuration:=p_configuration;a.configuration_hash:=probpera_translation_operations.retry_fingerprint(p_configuration);
 a.source_snapshot:=p_source_snapshot;a.source_revision:=p_source_revision;a.target_revision:=p_target_revision;a.confirmed_cursor:='{}';a.calls:='[]';a.created_at:=stamp;
 marker:=jsonb_build_object('version',1,'protocol','site-copy-translation','logicalScope','site-copy-overrides','operationId',p_operation_id,'actorId',actor,
  'sourceHash',p_source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,'configurationHash',a.configuration_hash,'startedAt',stamp,'attemptNumber',1,
  'progress',jsonb_build_object('version',1,'updatedAt',stamp,'calls','[]'::jsonb));
 j:=jsonb_populate_record(null::public.translation_jobs,jsonb_build_object('id',p_job_id,'kind','site_copy','source_locale','ru','target_locale','en','provider',p_provider,
  'status','reviewing','total_items',1,'succeeded_items',0,'failed_items',0,'requested_by',actor,'started_at',stamp,'version',1,'created_at',stamp,'updated_at',stamp,
  'resume_cursor',jsonb_build_object('siteCopyOperation',jsonb_build_object('version',1,'logicalScope','site-copy-overrides','operationId',p_operation_id,'actorId',actor,'intentHash',a.intent_hash))));
 i:=jsonb_populate_record(null::public.translation_job_items,jsonb_build_object('id',p_item_id,'job_id',p_job_id,'position',0,'entity_type','site_copy','entity_id',identity,
  'source_hash',p_source_hash,'status','reviewing','attempt_count',0,'max_attempts',1,'next_attempt_at',stamp,'created_at',stamp,'updated_at',stamp,'staff_retry',marker));
 a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);
 insert into premium_translation_private.catalog_operation_artifacts select a.*;insert into public.translation_jobs select j.*;insert into public.translation_job_items select i.*;
 perform premium_translation_private.site_copy_operation_assert_constructed(p_operation_id);
 insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)values(actor,'translation.site_copy_operation.admitted','translation_job',p_job_id::text,
  jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'logicalScope','site-copy-overrides','blockId',identity,'sourceHash',p_source_hash,'rawSeedHash',a.raw_seed_hash));
 return premium_translation_private.site_copy_operation_view(a,false,true);
end; $$;`);
sql.push(dispatch,response);
let finish=rename(extract('public.finish_catalog_translation_operation'));
const specializedStart=finish.indexOf("    if a.entity_type='literary_work' then"),specializedEnd=finish.indexOf('    digest:=',specializedStart);
assert(specializedStart>0&&specializedEnd>specializedStart);
finish=finish.slice(0,specializedStart)+`    perform premium_translation_private.assert_site_copy_recorded(a.source_snapshot);
    perform pg_advisory_xact_lock(hashtextextended('premium-translation:site_copy:'||a.entity_id,0));
    select * into draft from public.premium_translation_working_drafts where entity_type='site_copy' and entity_id=a.entity_id for update;
    begin perform premium_translation_private.site_copy_operation_assert_current(a);
    exception when serialization_failure then current_bound:=false;status:='stale';code:='source_changed';end;
`+finish.slice(specializedEnd);
finish=finish.replace("  if (status='succeeded') is distinct from (p_candidate is not null) then",`  -- A paid unfinished pass is not a terminal failure/retry grant. Retain it.
  if jsonb_array_length(a.calls)>0 and p_candidate is null then raise exception 'Site Copy paid partial response must remain retained' using errcode='40001';end if;
  if (status='succeeded') is distinct from (p_candidate is not null) then`);
// Exact old candidate/provenance/call proofs and journal accounting are retained
// in this NEW function. The old public catalog family remains byte-unchanged.
sql.push(finish);
// Remaining additive guards and closed readiness are in an explicit source part.
const guardPath=path.join(__dirname,'guards.sql.part');assert(fs.existsSync(guardPath),'Write the reviewed additive guards part before preparing');sql.push(fs.readFileSync(guardPath,'utf8'));
sql.push(fs.readFileSync(path.join(__dirname,'candidate-freshness.sql.part'),'utf8'));
const joined=sql.join('\n\n');
const declarations=[...joined.matchAll(/create function ([a-z0-9_.]+)\(([^]*?)\)\s*\nreturns/g)].map(m=>({name:m[1],args:m[2].replace(/\s+/g,' ').trim()}));
const signatures=declarations.map(({name,args})=>name+'('+args.split(',').map(a=>a.trim().replace(/\s+default\s+[^]*$/i,'').split(/\s+/).slice(1).join(' ')).join(',')+')');
const internal=signatures.filter(s=>!s.startsWith('public.')),pub=signatures.filter(s=>s.startsWith('public.'));assert.equal(pub.length,8);
const tail=`\nrevoke all on function ${internal.join(',\n ')} from public,anon,authenticated,service_role;\nrevoke all on function ${pub.join(',\n ')} from public,anon,authenticated,service_role;\ngrant execute on function ${pub.join(',\n ')} to authenticated;\ncommit;\n`;
fs.writeFileSync(path.join(__dirname,'site-copy-admission.sql'),joined+tail);
const sources=[file,'supabase/migrations/20261029181630_site_copy_private_translation_review.sql','supabase/migrations/20261029230111_catalog_translation_candidate_freshness.sql','supabase/migrations/20261029235455_library_translation_stable_scan.sql','supabase/migrations/20261030072209_profile_translation_stable_scan.sql','apps/admin/lib/auto-translate-site-copy-private.ts','apps/admin/lib/auto-translate-site-copy.ts','apps/admin/lib/site-copy-translation-contract.ts'].map(file=>{const b=fs.readFileSync(path.join(repo,file));return{file,bytes:b.length,sha256:sha(b)};});
const table=base.slice(base.indexOf('create table premium_translation_private.catalog_operation_artifacts'),base.indexOf('alter table premium_translation_private.catalog_operation_artifacts'));
const checks=table.split('\n').filter(line=>line.includes('check(')).map(line=>line.trim());assert.equal(checks.length,9);
const receipt={classification:'PARENT_ONLY_PREPARED_UNEXECUTED_UNVALIDATED_NOT_MIGRATION',bytes:Buffer.byteLength(joined+tail),sha256:sha(Buffer.from(joined+tail)),sourceBindings:sources,
 existingCacheAllCheckClauses:checks,changedExistingChecks:['entity_type adds site_copy only'],unchangedOtherCacheCheckClauses:8,
 privateCacheShapeNoNewColumns:true,oldPaidRoutineReplacements:0,newPublicRpcs:pub,internalFunctions:internal,maintainedWrites:0,databaseExecutions:0,providerCalls:0,
 limitations:['No PostgreSQL parse/runtime/roles/constraints/trigger/lock/performance or SDK native conformance run.','Atomic CMS approval recognition and legacy/discard/pending-pointer races require genuine native proof before maintained landing.','Explicit trusted partial-pass continuation and addressed failed-item retry are deliberately separate; this admission draft only retains paid partial/unknown outcomes.']};
fs.writeFileSync(path.join(__dirname,'sql-draft-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({classification:receipt.classification,bytes:receipt.bytes,sha256:receipt.sha256,newPublicRpcs:pub.length,cacheCheckClauses:checks.length}));
