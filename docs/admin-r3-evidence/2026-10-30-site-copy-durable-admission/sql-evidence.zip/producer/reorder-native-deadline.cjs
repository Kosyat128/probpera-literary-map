const fs=require('node:fs'),path=require('node:path');
const file=path.resolve(__dirname,'../../probpera-literary-map/scripts/database/fixtures/site-copy-translation-operation-admission.sql');
let sql=fs.readFileSync(file,'utf8');
const blocks=[];
for(const [prefix,marker] of [
 ['-- Confirmed partial output before the real original deadline',"select 'M07_SITE_COPY_ADMISSION_PARTIAL_REAL_DEADLINE_PASS';"],
 ['-- A first body arriving after the actual original deadline',"select 'M07_SITE_COPY_ADMISSION_FIRST_BODY_AFTER_DEADLINE_PASS';"],
]){
 const start=sql.indexOf(prefix),found=sql.indexOf(marker,start),end=found<0?-1:found+marker.length;
 if(start>=0&&end>start){blocks.push(sql.slice(start,end));sql=sql.slice(0,start)+sql.slice(end);}
}
fs.writeFileSync(file,sql.trimEnd()+'\n\n'+blocks.join('\n\n')+'\n');
