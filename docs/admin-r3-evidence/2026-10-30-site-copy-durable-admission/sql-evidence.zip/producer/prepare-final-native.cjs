const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),assert=require('node:assert/strict');
const work=path.resolve(__dirname,'..'),repo=path.resolve(work,'../probpera-literary-map');
const run='final_v1',dir=path.join(work,'site-copy-admission-sql-native',run);
assert(!fs.existsSync(dir),'Final directory must be fresh');
cp.execFileSync(process.execPath,[path.join(__dirname,'prepare-native.cjs'),run],{stdio:'pipe'});
const migration=fs.readFileSync(path.join(repo,'supabase/migrations/20261030094705_site_copy_translation_operation_admission.sql'),'utf8');
const cases=fs.readFileSync(path.join(repo,'scripts/database/fixtures/site-copy-translation-operation-admission.sql'),'utf8');
const all=fs.readFileSync(path.join(dir,'fixture.sql'),'utf8'),at=all.indexOf(migration);assert(at>0&&all.indexOf(migration,at+1)<0);
const tables=[
 'public.translation_jobs','public.translation_job_items','public.translation_job_attempts','premium_translation_private.writer_operation_artifacts',
 'premium_translation_private.catalog_operation_artifacts','public.premium_translation_working_drafts','public.homepage_blocks','public.homepage_block_revisions',
].map(x=>"'"+x+"'::regclass").join(',');
const queries={
 functions:`select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'source',p.prosrc,'definition',pg_get_functiondef(p.oid),'owner',pg_get_userbyid(p.proowner),'securityDefiner',p.prosecdef,'volatility',p.provolatile,'config',p.proconfig,'acl',p.proacl) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in('auth','public','premium_translation_private','probpera_translation_operations') and p.prokind in('f','p') and p.proname not like '%fixture%'`,
 tables:`select jsonb_agg(jsonb_build_object('name',c.oid::regclass::text,'owner',pg_get_userbyid(c.relowner),'acl',c.relacl,'forceRls',c.relforcerowsecurity,'rls',c.relrowsecurity,'columns',(select jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull,'identity',a.attidentity,'generated',a.attgenerated,'default',(select pg_get_expr(d.adbin,d.adrelid) from pg_attrdef d where d.adrelid=c.oid and d.adnum=a.attnum)) order by a.attnum) from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped),'policies',(select jsonb_agg(to_jsonb(p) order by p.policyname) from pg_policies p where p.schemaname=n.nspname and p.tablename=c.relname)) order by c.oid::regclass::text) from pg_class c join pg_namespace n on n.oid=c.relnamespace where c.oid in(${tables})`,
 indexes:`select jsonb_agg(jsonb_build_object('schema',n.nspname,'name',ci.relname,'definition',pg_get_indexdef(ci.oid),'unique',i.indisunique,'primary',i.indisprimary,'valid',i.indisvalid,'ready',i.indisready) order by n.nspname,ci.relname) from pg_index i join pg_class c on c.oid=i.indrelid join pg_class ci on ci.oid=i.indexrelid join pg_namespace n on n.oid=ci.relnamespace where c.oid in(${tables})`,
 constraints:`select jsonb_agg(jsonb_build_object('name',conname,'table',conrelid::regclass::text,'type',contype,'deferrable',condeferrable,'initiallyDeferred',condeferred,'validated',convalidated,'definition',pg_get_constraintdef(oid)) order by conrelid::regclass::text,conname) from pg_constraint where conrelid in(${tables})`,
 triggers:`select jsonb_agg(jsonb_build_object('name',t.tgname,'table',t.tgrelid::regclass::text,'enabled',t.tgenabled,'definition',pg_get_triggerdef(t.oid),'function',t.tgfoid::regprocedure::text) order by t.tgrelid::regclass::text,t.tgname) from pg_trigger t where not t.tgisinternal and t.tgrelid in(${tables})`,
 relations:`select jsonb_agg(jsonb_build_object('schema',n.nspname,'name',c.relname,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner)) order by n.nspname,c.relname) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname in('auth','public','premium_translation_private','probpera_translation_operations') and c.relkind in('r','p','v','m','f','S')`,
 roles:`select jsonb_agg(to_jsonb(r) order by r.rolname) from pg_roles r`,
};
let snapshot="\nreset role;set timezone='UTC';set search_path=public,pg_catalog;truncate public.site_copy_operation_fixture_baseline;\n";
for(const [name,query] of Object.entries(queries)){
 snapshot+=`insert into public.site_copy_operation_fixture_baseline values('${name}',(${query}));\n`;
 fs.writeFileSync(path.join(dir,'after-'+name+'.sql'),"set search_path=public,pg_catalog;set timezone='UTC';\n"+query+';\n');
}
fs.writeFileSync(path.join(dir,'foundation.sql'),all.slice(0,at)+snapshot);
fs.writeFileSync(path.join(dir,'migration.sql'),migration);
fs.writeFileSync(path.join(dir,'fixture-cases.sql'),cases);
let runner=fs.readFileSync(path.join(dir,'run.ps1'),'utf8');
const oldManual=/ & \$psql -h 127\.0\.0\.1 -p 55438 -U postgres -d site_copy_admission_v2_20261030[^\n]*manual-restore-before[^\n]*\n if\(\$LASTEXITCODE -ne 0\)\{throw 'Old actual guarded-save BEFORE failed'\}\n/;
assert(oldManual.test(runner));runner=runner.replace(oldManual,'');
const sourceLine=" & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'fixture.sql') *> (Join-Path $nativeRoot 'run.log')";
assert(runner.includes(sourceLine));
const phase=` & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'foundation.sql') *> (Join-Path $nativeRoot 'foundation.log')
 if($LASTEXITCODE -ne 0){throw 'Final exact old foundation failed'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'manual-restore-before.sql') *> (Join-Path $nativeRoot 'manual-restore-before.raw.log')
 if($LASTEXITCODE -ne 0){throw 'Same-foundation actual OLD guarded-save BEFORE failed'}
 $baselineDatabase='site_copy_admission_final_v1_before_20261030'
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc --set=ON_ERROR_STOP=1 -c "create database $baselineDatabase template $database" *> (Join-Path $nativeRoot 'before-database-clone.log')
 if($LASTEXITCODE -ne 0){throw 'Final same-foundation BEFORE clone failed'}
 foreach($scope in @('functions','tables','indexes','constraints','triggers','relations','roles')){
  $before=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $baselineDatabase --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select value from public.site_copy_operation_fixture_baseline where label='$scope'"
  if($LASTEXITCODE -ne 0){throw 'Final BEFORE export failed'}
  $before|Set-Content -LiteralPath(Join-Path $nativeRoot ('before-'+$scope+'.json')) -Encoding utf8
 }
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1';$env:SUPABASE_HOME=Join-Path $nativeRoot 'cli-home'
 $cli='C:\\Users\\Костя\\Documents\\Codex\\2026-10-09\\v\\work\\portable-db-tools\\supabase-2.120.0\\supabase.exe'
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$baselineDatabase+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors-before.raw.log')
 $beforeAdvisorExit=$LASTEXITCODE
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'migration.sql') *> (Join-Path $nativeRoot 'migration.log')
 if($LASTEXITCODE -ne 0){throw 'Final new migration failed'}
 foreach($scope in @('functions','tables','indexes','constraints','triggers','relations','roles')){
  $after=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot ('after-'+$scope+'.sql'))
  if($LASTEXITCODE -ne 0){throw 'Final AFTER export failed'}
  $after|Set-Content -LiteralPath(Join-Path $nativeRoot ('after-'+$scope+'.json')) -Encoding utf8
 }
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$database+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors-after-migration.raw.log')
 $afterAdvisorExit=$LASTEXITCODE
 $available=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc -Atc "select count(*) from pg_available_extensions where name='plpgsql_check'"
 [pscustomobject]@{sameFoundationBeforeDatabase=$baselineDatabase;beforeAdvisorExit=$beforeAdvisorExit;afterAdvisorExit=$afterAdvisorExit;plpgsqlCheckAvailable=[int]$available;lint='NOT_RUN_EXTENSION_NOT_INSTALLED_NO_INSTALL';managedAuthOrProviderClaim=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-receipt.json') -Encoding utf8
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'fixture-cases.sql') *> (Join-Path $nativeRoot 'run.log')`;
runner=runner.replace(sourceLine,()=>phase);
const beforeWire="  $wire=& $psql";
assert(runner.includes(beforeWire));
runner=runner.replace(beforeWire,()=>`  & node 'C:\\Users\\Костя\\Documents\\Codex\\2026-10-09\\v\\work\\site-copy-admission-races-sol\\run-races.cjs' --execute-owned --owned $ownedPath --database $database --output (Join-Path $nativeRoot 'concurrency') *> (Join-Path $nativeRoot 'concurrency.raw.log')
  if($LASTEXITCODE -ne 0){throw 'Final native concurrency groups failed'}
  $wire=& $psql`);
fs.writeFileSync(path.join(dir,'run.ps1'),runner);
fs.writeFileSync(path.join(dir,'metadata-queries.json'),JSON.stringify(queries,null,2)+'\n');
console.log(JSON.stringify({dir,database:'site_copy_admission_final_v1_20261030',beforeDatabase:'site_copy_admission_final_v1_before_20261030',phases:['exact old foundation','same-foundation before clone/exports/advisors','new migration/after exports/advisors','all fixture cases','nativeGET actualSDK/retained parity nativeFINISH','12actual races','official ASCII wire export','finally cleanup'],queries:Object.keys(queries)}));
