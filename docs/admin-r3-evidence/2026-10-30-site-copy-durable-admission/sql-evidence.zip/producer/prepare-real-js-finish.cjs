const fs=require('node:fs'),assert=require('node:assert/strict');
const [artifactPath,candidatePath,sqlPath]=process.argv.slice(2);
const artifact=JSON.parse(fs.readFileSync(artifactPath,'utf8').replace(/^\uFEFF/u,''));
const candidate=JSON.parse(fs.readFileSync(candidatePath,'utf8'));
const r=artifact.receipt;
assert.equal(r.entityType,'site_copy');assert.equal(r.sourceHash,'428450394708d92b258fe25a1360ef780c7899187952036ae000a13e8a851944');
assert.equal(artifact.calls.length,1);assert.equal(artifact.candidate,null);
for(const id of[r.jobId,r.itemId,r.operationId,r.actorId])assert.match(id,/^[a-f0-9-]{36}$/u);
const metadata=artifact.calls[0].metadata;
const args={p_job_id:r.jobId,p_item_id:r.itemId,p_operation_id:r.operationId,p_outcome:{status:'succeeded',providerCalls:1,model:metadata.model,
 requestId:candidate.provenance.translatorRequestId,inputTokens:metadata.inputTokens,outputTokens:metadata.outputTokens},p_candidate:candidate};
const encoded=JSON.stringify(args).replace(/[\u007f-\uffff]/gu,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));
assert(!encoded.includes('$actual_retained_candidate$'));
assert(!encoded.includes('$real_finish$'));
const sql=`begin;
set local timezone='UTC';set local role authenticated;
select set_config('request.jwt.claim.sub','${r.actorId}',true);
do $real_finish$ declare input jsonb:=$actual_retained_candidate$${encoded}$actual_retained_candidate$::jsonb;r jsonb;a jsonb;expected jsonb;begin
 select value->'expectedPayload' into expected from public.site_copy_operation_fixture_results where label='real-js-native-input';
 r:=public.site_copy_operation_fixture_call('finish_site_copy_translation_operation',input);
 a:=public.site_copy_operation_fixture_artifact(r);
 assert a->'candidate'=input->'p_candidate' and a#>'{candidate,payload}'=expected,'native saved candidate equals actual retained production reconstruction';
 insert into public.site_copy_operation_fixture_results values('real-js-native-roundtrip',jsonb_build_object('finished',r,'artifact',a,'actualRetainedBuilderCandidate',input->'p_candidate',
  'actualSdkGetAndProductionRetainedBuilder',true,'nativeStoredCandidateParity',true,'externalProviderCalls',0));
end; $real_finish$;
commit;
select value->'artifact' from public.site_copy_operation_fixture_results where label='real-js-native-roundtrip';
`;
fs.writeFileSync(sqlPath,sql);console.log(JSON.stringify({sqlPath,actualNativeOperationId:r.operationId,externalProviderCalls:0}));
