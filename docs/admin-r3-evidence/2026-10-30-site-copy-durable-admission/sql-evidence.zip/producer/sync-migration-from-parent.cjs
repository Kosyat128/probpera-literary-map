const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../../probpera-literary-map');
const sql=fs.readFileSync(path.join(__dirname,'site-copy-admission.sql'),'utf8');
const file='supabase/migrations/20261030094705_site_copy_translation_operation_admission.sql';
fs.writeFileSync(path.join(repo,file),sql.replace('-- PARENT-ONLY UNEXECUTED SITE-COPY ADMISSION DRAFT. NOT A MIGRATION.','-- Site-copy durable provider admission and retained response artifacts.'));
const files=[file,'apps/admin/lib/site-copy-translation-operation-rpc.ts','apps/admin/lib/site-copy-translation-candidate-freshness-rpc.ts'].map(file=>{
 const b=fs.readFileSync(path.join(repo,file));return{file,bytes:b.length,sha256:crypto.createHash('sha256').update(b).digest('hex')};});
console.log(JSON.stringify(files));
