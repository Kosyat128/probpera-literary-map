const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const work=path.resolve(__dirname,'..'),dir=path.join(work,'site-copy-admission-sql-native/final_v1');
const old=fs.readFileSync(path.join(dir,'run.ps1'),'utf8'),start=old.slice(0,old.indexOf(" $database='site_copy_admission_final_v1_20261030'"));
const wire=old.slice(old.indexOf('  $wire=& $psql'),old.indexOf('\n }\n Get-Content'));
assert(start.length>200&&wire.includes("'native-goldens.json'"));
const stop=old.slice(old.indexOf('}finally{')).replace("(Join-Path $nativeRoot 'cleanup.log')","(Join-Path $nativeRoot 'completion-cleanup.log')").replace("(Join-Path $nativeRoot 'cleanup.json')","(Join-Path $nativeRoot 'completion-cleanup.json')");
const sql=fs.readFileSync(path.join(dir,'after-functions.sql'),'utf8');
const code=start+` $database='site_copy_admission_final_v1_20261030'
 $exists=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc "select count(*) from pg_database where datname='$database'"
 if($LASTEXITCODE -ne 0 -or $exists -ne '1'){throw 'Exact previously completed final database missing'}
 $stamp=[DateTime]::UtcNow
 $current=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f(Join-Path $nativeRoot 'after-functions.sql')
 if($LASTEXITCODE -ne 0 -or $current.Trim() -ne (Get-Content -LiteralPath(Join-Path $nativeRoot 'after-functions.json') -Raw).Trim()){throw 'Final functions drift since native fixture proof'}
 $active=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select count(*) from public.translation_job_items where entity_type='site_copy' and staff_retry is not null"
 if($LASTEXITCODE -ne 0 -or $active -ne '0'){throw 'Cannot start race completion with an unresolved operation'}
 & node '${path.join(work,'site-copy-admission-races-sol/run-races.cjs')}' --execute-owned --owned $ownedPath --database $database --output '${path.join(dir,'concurrency')}' *> (Join-Path $nativeRoot 'completion-concurrency.raw.log')
 if($LASTEXITCODE -ne 0){throw 'Final corrected-path actual native concurrency failed'}
${wire}
 $exitCode=0
 [pscustomobject]@{classification='COMPLETION_AFTER_PRECONNECTION_SHORT_PATH_PREFLIGHT_REFUSAL_NO_SQL_OR_SOURCE_CHANGE';database=$database;startedAt=$stamp.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');exitCode=0;elapsedMs=([DateTime]::UtcNow-$stamp).TotalMilliseconds;providerCalls=0}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'completion-receipt.json') -Encoding utf8
 Write-Output 'FINAL_COMPLETION_PASS'
`+stop;
fs.writeFileSync(path.join(dir,'complete-concurrency-export.ps1'),code);
console.log(JSON.stringify({file:path.join(dir,'complete-concurrency-export.ps1'),scope:'Existing final database only; actual function-definition drift check and active operation zero before 12 new owned native race groups, followed by ASCII export/finally stop; original failed preconnection wrapper unchanged.'}));
