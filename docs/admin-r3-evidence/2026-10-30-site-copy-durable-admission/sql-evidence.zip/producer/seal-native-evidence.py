import hashlib,json,pathlib,shutil,sys,zipfile
work=pathlib.Path(__file__).resolve().parents[1]
repo=work.parent/'probpera-literary-map'
native=work/'site-copy-admission-sql-native'
run=native/'final_v1'
out=work/'site-copy-native-evidence-final'
assert not out.exists(),'Archive staging directory must be fresh'
summary=json.loads((run/'native-summary.json').read_text(encoding='utf-8'))
assert summary['concurrency']['pass']==12 and summary['concurrency']['fail']==0
assert summary['completion']['exitCode']==0
out.mkdir()
def sha(b):return hashlib.sha256(b).hexdigest()
bindings={}
def capture(file,expected=None):
    p=repo/file
    assert p.is_file(),file
    b=p.read_bytes()
    if expected:assert sha(b)==expected,{'file':file,'expected':expected,'actual':sha(b)}
    q=out/'sources'/file;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
    bindings[file]={'file':file,'bytes':len(b),'sha256':sha(b)}
def nested(obj):
    if isinstance(obj,dict):
        if isinstance(obj.get('file'),str) and obj.get('sha256') and (repo/obj['file']).is_file():capture(obj['file'],obj['sha256'])
        for x in obj.values():nested(x)
    elif isinstance(obj,list):
        for x in obj:nested(x)
nested(json.loads((work/'profile-scan-sql-native/v5/source-manifest.json').read_text(encoding='utf-8')))
nested(json.loads((work/'site-copy-durable-tests-sol/native-real-js-seed-receipt.json').read_text(encoding='utf-8')))
for x in summary['bindings'][:4]:capture(str(pathlib.Path(x['file']).relative_to(repo)).replace('\\','/'),x['sha256'])
capture('supabase/migrations/20260812_homepage_block_revisions.sql')
for src,dest in [(native,'native-history'),(work/'site-copy-durable-admission-next','producer'),(work/'site-copy-admission-races-sol','races')]:
    for p in sorted(src.rglob('*')):
        if not p.is_file() or 'cli-home' in p.parts or 'node_modules' in p.parts:continue
        q=out/dest/p.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
bridge=out/'real-js-bridge';bridge.mkdir()
for name in ['native-real-js-seed.json','native-real-js-seed-receipt.json','native-candidate-from-artifact.cjs','generate-native-real-js-seed.cjs']:
    shutil.copyfile(work/'site-copy-durable-tests-sol'/name,bridge/name)
profile=out/'inherited-foundation';profile.mkdir()
for name in ['source-manifest.json','fixture.sql']:
    shutil.copyfile(work/'profile-scan-sql-native/v5'/name,profile/name)
manifest={'classification':'NATIVE_SQL_ONLY_FINAL_INPUTS_AND_ACTUAL_RECEIPTS_WITH_DECLARED_ORCHESTRATION_FAILURES',
 'currentHead':'acb910d89133396e8e9794e91bd5db74128dab3b',
 'nativeSummary':'native-history/final_v1/native-summary.json',
 'nativeFinalAscii':'native-history/final_v1/native-goldens.json',
 'physicalSources':list(bindings.values()),
 'externalSdkDependency':{'status':'NOT_EMBEDDED_IN_THIS_NATIVE_ONLY_ARCHIVE','requirement':'Separate final installed SDK + all eight actual typed wrappers + real retained-builder parity conformance must bind this exact final ASCII hash before overall acceptance.'},
 'history':['v1-v14 are original native parse/fixture/source or orchestration iterations with their own exact bytes; do not relabel as final source proof.',
 'actual-v14-debug had 11 race groups PASS plus a harness barrier coordination failure; corrected actual-v14-retry had12 PASS.',
 'final_v1 full exact foundation, all new SQL cases and realJS bridge passed; original wrapper then refused short output path before any race DB connection.',
 'Separate complete-concurrency-export.ps1 checked exact actual current function definitions and zero active operations, then performed12 race groups on that same unchanged final database and exported final wire; both actual own server sessions finally stopped.',
 'No original failure, SQL source, oracle or accepted-body deadline was rewritten.'],
 'scope':summary['scope']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
(out/'README.txt').write_text('Native SQL evidence only. Read manifest.json and native-history/final_v1/native-summary.json first.\n'
 'The final same-foundation comparison preserves all186 original nonfixture functions,8 target table definitions/policies/ACLs,53 schema relations and19 roles.\n'
 'Old indexes35 are preserved plus1 new active-scope index; old22 triggers are preserved plus5; constraints95 become96 solely through the documented type CHECK extension and deferred event.\n'
 'Advisors contain15 unchanged selected-foundation/fixture findings; this is not a production clean-advisor claim. plpgsql_check was unavailable and not installed.\n'
 'No real provider call, production database, managed Auth/browser stack or explicit trusted partial-pass continuation is claimed.\n'
 'Native inputs are portable SQL; actual execution requires an explicitly owned local PostgreSQL17 loopback cluster and the declared prerequisites. Producers contain original paths and lifecycle controls; adapt only local workspace/owned descriptor paths when reproducing. Never point these scripts at managed or production databases.\n'
 'All raw historical failures remain. Installed SDK final conformance is a separate dependency, deliberately not replaced by an intermediate123-row report.\n',encoding='utf-8')
payload=[]
for p in sorted(out.rglob('*')):
    if p.is_file():
        b=p.read_bytes();payload.append({'file':p.relative_to(out).as_posix(),'bytes':len(b),'sha256':sha(b)})
(out/'payload-manifest.json').write_text(json.dumps(payload,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
archive=work/'site-copy-admission-native-evidence.zip'
assert not archive.exists(),'Archive must be new and immutable'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(out.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(out).as_posix())
with zipfile.ZipFile(archive) as z:
    names=z.namelist();assert len(names)==len(set(names))
    assert all(not n.startswith(('/', '\\')) and '..' not in pathlib.PurePosixPath(n).parts for n in names)
    for row in payload:
        b=z.read(row['file']);assert len(b)==row['bytes'] and sha(b)==row['sha256']
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'payloadFiles':len(names),
 'hashedPayloads':len(payload),'physicalBindings':len(bindings),'allPayloadsReadBack':True,'nativeOnly':True,'sdkFinalConformanceExternal':True}
(work/'site-copy-admission-native-evidence-receipt.json').write_text(json.dumps(receipt,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
