// Source read/hash metadata only; deliberately does not import/execute helpers.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const repo = path.resolve(__dirname, '../../probpera-literary-map');
const sourceFiles = [
  'apps/admin/lib/auto-translate-site-copy-private.ts',
  'apps/admin/lib/auto-translate-site-copy.ts',
  'apps/admin/lib/site-copy-translation-contract.ts',
  'apps/admin/lib/site-copy-storage.ts',
  'supabase/migrations/20261008160000_premium_translation_working_drafts.sql',
  'supabase/migrations/20261029181630_site_copy_private_translation_review.sql',
];
const sources = sourceFiles.map(file => {
  const bytes = fs.readFileSync(path.join(repo, file));
  return { file, bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex') };
});
const report = {
  classification: 'STATIC_SOURCE_INSPECTION_ONLY_NOT_RUNTIME_OR_NATIVE_PROOF',
  sources,
  actualExistingSequence: [
    { location: 'auto-translate-site-copy-private.ts:37', behavior: 'Read actual singleton projection id/settings/updated_at with limit2 and exactly one row. Duplicate canonical blocks never choose a latest winner.' },
    { location: 'site-copy-translation-contract.ts:65', behavior: 'siteCopyTranslationSource validates raw settings and locale/metadata ownership, then calls the existing readSiteCopyValues projection. No replacement normalizer is introduced.' },
    { location: 'site-copy-storage.ts:46', behavior: 'storedLocale uses existing safeStorageKey and existing protected normalizer on candidate.trim(). JavaScript trim decides whether a string is blank. This draft preserves the old call sites and returned values byte-for-byte.' },
    { location: 'site-copy-translation-contract.ts:74', behavior: 'Every raw RU/EN key must pass the existing validSiteCopyTranslationKey; a nonblank raw text omitted by the projected map makes the source ambiguous and is rejected.' },
    { location: 'site-copy-translation-contract.ts:84', behavior: 'Walk Object.entries(raw RU) in existing ECMAScript property enumeration order, reject non-string RU, skip rawText.trim() blanks, take the existing projected RU text, require <=4000 UTF-16 units, skip manual EN, reject invalid ownership.' },
    { location: 'site-copy-translation-contract.ts:94', behavior: 'Per-item sourceHash is original translationSourceHash({key,text}). Skip a current machine-owned EN only when hash matches and projected EN is nonempty <=4000 and has no Cyrillic. Preserve all other selected item objects and their order.' },
    { location: 'auto-translate-site-copy-private.ts:101', behavior: 'Optional requested keys become a membership Set. Filtering preserves source.items order, not requested-key order. Then slice(0,50), never split into per-key tasks.' },
    { location: 'auto-translate-site-copy-private.ts:124', behavior: 'Operation semantic sourceHash is original translationSourceHash(items), including each selected object key/text/sourceHash and original array order.' },
    { location: 'auto-translate-site-copy.ts:80', behavior: 'Only the provider input map subsequently applies key.trim() and text.replace(/\\r\\n?/gu,"\\n").trim(), followed by empty and duplicate-key refusal. Do not rewrite retained semantic source items/hash using this later provider normalization.' },
  ],
  whitespace: {
    unchangedExistingSqlHelper: 'premium_translation_private.trim_text in 20261008160000:94-103 explicitly implements the existing ECMAScript String.trim validation character set. The new SQL calls it for validation only; it does not transform stored source items, payload or hashes.',
    existingTrimCodePoints: ['U+0009','U+000A','U+000B','U+000C','U+000D','U+0020','U+00A0','U+1680','U+2000','U+2001','U+2002','U+2003','U+2004','U+2005','U+2006','U+2007','U+2008','U+2009','U+200A','U+2028','U+2029','U+202F','U+205F','U+3000','U+FEFF'],
    notIntroduced: 'No new PG trim/regexp normalizer, SQL hyphen replacement or semantic JSONB rehash. Existing old SQL shape/ownership validation stays the existing contract.',
  },
  trustBoundaries: {
    sql: 'Capture and bind the entire actual server homepage row, exact client projection, singleton count1, original UUID/CAS, immutable source items/config/intent and private raw body. SQL validates source item structure and existing ownership; it does not claim to execute the JS site-copy projection.',
    actualServerHelper: 'Before a new paid call or recovered FINISH, use the actual existing builder and selected-key algorithm to prove the admitted source items and original opaque semantic sourceHash. Do not accept client-provided items merely because SQL shape validation succeeded.',
    hashes: 'sourceHash is the old JS semantic SHA256(JSON.stringify(selectedItems)); rawSeedHash is a distinct opaque native fingerprint of {version:1,block:fullActualRow}. They have different inputs/authority and must never substitute for each other.',
    recovery: 'Reconcile fixed logical scope site-copy-overrides before current block UUID/config/eligibility/runtime reads. Old admitted seed/config/body remain recoverable after deletion/recreate; unknown/partial calls remain held.',
  },
  validation: { helpersExecuted: 0, providerCalls: 0, databaseStarts: 0, maintainedWrites: 0, status: 'Await root release for actual helper/SDK/native cases.' },
};
fs.writeFileSync(path.join(__dirname, 'source-input-static-map.json'), JSON.stringify(report, null, 2) + '\n');
process.stdout.write(JSON.stringify({ classification: report.classification, sourceBindings: sources.length }) + '\n');
