begin;
set local timezone='UTC';
do $$ declare a premium_translation_private.catalog_operation_artifacts%rowtype;r jsonb;payload jsonb;done jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 select * into a from premium_translation_private.catalog_operation_artifacts where entity_type='site_copy' and final_receipt is null;
 if a.operation_id is not null then
  assert a.actor_id='11111111-1111-4111-8111-111111111111'::uuid;
  assert a.configuration->'twoPassReview'='false'::jsonb and jsonb_array_length(a.calls)=1;
  assert a.calls#>'{0,metadata,responseReceivedAt}'<>'null'::jsonb and a.calls#>'{0,responseArtifact}'<>'null'::jsonb;
  payload:=(a.calls#>>'{0,responseArtifact,body,response}')::jsonb;
  set local role authenticated;r:=public.reconcile_site_copy_translation_operation(a.operation_id);
  done:=public.site_copy_operation_fixture_finish(r,payload);reset role;
  assert done->>'phase'='finished' and done->'providerCalls'='1'::jsonb;
  raise notice 'HONEST_KNOWN_COMPLETE_RECOVERY_WITHOUT_NEW_DISPATCH %',done;
 end if;
end; $$;
commit;
