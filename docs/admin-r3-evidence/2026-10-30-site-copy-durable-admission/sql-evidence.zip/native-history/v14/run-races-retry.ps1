$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-admission-sql-native\v14'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json';$dataDirectory=Join-Path $clusterRoot 'data'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory -or $owned.service){throw 'Unexpected owned local cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous owned PID remains'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Previous owned PID file remains'}
if(@(Get-NetTCPConnection -LocalPort 55438 -State Listen -ErrorAction SilentlyContinue).Count -ne 0){throw 'Unexpected listener'}
$started=$false;$exitCode=1
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-races-retry.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned local start failed'}
 $started=$true;$ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $psql=Join-Path $owned.pgBin 'psql.exe'
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d site_copy_admission_v14_20261030 --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'honest-known-complete-cleanup.sql') *> (Join-Path $nativeRoot 'honest-known-complete-cleanup.log')
 if($LASTEXITCODE -ne 0){throw 'Cannot honestly recover known complete synthetic operation'}
 & node 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-admission-races-sol\run-races.cjs' --execute-owned --owned $ownedPath --database site_copy_admission_v14_20261030 --output 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-admission-races-sol\actual-v14-retry'
 $exitCode=$LASTEXITCODE
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'races-cleanup-retry.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'races-cleanup-retry.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
exit $exitCode
