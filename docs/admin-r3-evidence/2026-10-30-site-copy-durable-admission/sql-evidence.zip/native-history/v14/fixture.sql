
-- Immutable history for visual edits of homepage blocks. The public snapshot
-- still comes from homepage_blocks; this table is editorial recovery data only.

create table if not exists public.homepage_block_revisions (
  id bigint generated always as identity primary key,
  homepage_block_id uuid references public.homepage_blocks(id) on delete set null,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (homepage_block_id, revision_number)
);

create or replace function public.capture_homepage_block_revision()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_revision integer;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;

  select coalesce(max(revision_number), 0) + 1
  into next_revision
  from public.homepage_block_revisions
  where homepage_block_id = old.id;

  insert into public.homepage_block_revisions (
    homepage_block_id,
    revision_number,
    snapshot,
    changed_by
  )
  values (
    old.id,
    next_revision,
    to_jsonb(old),
    coalesce(
      case when tg_op = 'UPDATE' then new.updated_by else old.updated_by end,
      (select auth.uid())
    )
  );

  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists homepage_blocks_capture_revision on public.homepage_blocks;
create trigger homepage_blocks_capture_revision
  before update or delete on public.homepage_blocks
  for each row execute function public.capture_homepage_block_revision();

create index if not exists homepage_block_revisions_block_idx
  on public.homepage_block_revisions(homepage_block_id, revision_number desc);

-- System blocks are singletons. This also turns a simultaneous first save
-- from two admin tabs into a visible uniqueness conflict instead of two
-- divergent records whose last-updated row silently wins.
with ranked_system_blocks as (
  select
    id,
    row_number() over (
      partition by settings ->> 'systemKey'
      order by updated_at desc, id desc
    ) as position
  from public.homepage_blocks
  where settings ? 'systemKey'
)
delete from public.homepage_blocks as block
using ranked_system_blocks as ranked
where block.id = ranked.id
  and ranked.position > 1;

create unique index if not exists homepage_blocks_system_key_unique_idx
  on public.homepage_blocks ((settings ->> 'systemKey'))
  where settings ? 'systemKey';

-- Every built-in public section is also a singleton. Keep the newest row if
-- an older deployment already allowed a race, then reject future duplicates.
with ranked_core_blocks as (
  select
    id,
    row_number() over (
      partition by settings ->> 'coreSectionKey'
      order by updated_at desc, id desc
    ) as position
  from public.homepage_blocks
  where settings ? 'coreSectionKey'
)
delete from public.homepage_blocks as block
using ranked_core_blocks as ranked
where block.id = ranked.id
  and ranked.position > 1;

create unique index if not exists homepage_blocks_core_section_key_unique_idx
  on public.homepage_blocks ((settings ->> 'coreSectionKey'))
  where settings ? 'coreSectionKey';

alter table public.homepage_block_revisions enable row level security;

drop policy if exists "Staff read homepage block revisions"
  on public.homepage_block_revisions;
create policy "Staff read homepage block revisions"
on public.homepage_block_revisions for select
to authenticated
using (public.is_staff());


reset role;set timezone='UTC';
create table if not exists public.site_copy_operation_fixture_baseline(label text primary key,value jsonb not null);
truncate public.site_copy_operation_fixture_baseline;
insert into public.site_copy_operation_fixture_baseline values('functions',(select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'source',p.prosrc,'securityDefiner',p.prosecdef,'config',p.proconfig,'acl',p.proacl) order by p.oid::regprocedure::text) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in ('premium_translation_private','probpera_translation_operations') or(n.nspname='public' and p.proname not like '%fixture%' and(p.proname like '%translation%' or p.proname like '%premium%'))));
insert into public.site_copy_operation_fixture_baseline values('tables',(select jsonb_agg(jsonb_build_object('name',c.oid::regclass::text,'acl',c.relacl,'forceRls',c.relforcerowsecurity,'rls',c.relrowsecurity,'columns',(select jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notNull',a.attnotnull) order by a.attnum) from pg_attribute a where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped)) order by c.oid::regclass::text) from pg_class c where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass,'public.premium_translation_working_drafts'::regclass,'public.homepage_blocks'::regclass)));
insert into public.site_copy_operation_fixture_baseline values('indexes',(select jsonb_agg(jsonb_build_object('schema',n.nspname,'name',ci.relname,'definition',pg_get_indexdef(ci.oid)) order by n.nspname,ci.relname) from pg_index i join pg_class c on c.oid=i.indrelid join pg_class ci on ci.oid=i.indexrelid join pg_namespace n on n.oid=ci.relnamespace where c.oid in('public.translation_jobs'::regclass,'public.translation_job_items'::regclass,'public.translation_job_attempts'::regclass,'premium_translation_private.catalog_operation_artifacts'::regclass,'premium_translation_private.writer_operation_artifacts'::regclass,'public.premium_translation_working_drafts'::regclass,'public.homepage_blocks'::regclass)));
insert into public.site_copy_operation_fixture_baseline values('constraints',(select jsonb_agg(jsonb_build_object('name',conname,'table',conrelid::regclass::text,'definition',pg_get_constraintdef(oid)) order by conrelid::regclass::text,conname) from pg_constraint where conrelid in('premium_translation_private.catalog_operation_artifacts'::regclass,'public.premium_translation_working_drafts'::regclass)));

-- Site-copy durable provider admission and retained response artifacts.
-- Seven closed staff RPCs; no new queue/table/column/role/lease grant.
-- One additional staff metadata read proves paid candidate full-row freshness.
-- Existing book/country functions and old migration files are not replaced.
begin;
do $check$ declare name text;n integer;att smallint;begin
 select attnum into att from pg_attribute where attrelid='premium_translation_private.catalog_operation_artifacts'::regclass and attname='entity_type';
 select count(*),min(conname) into n,name from pg_constraint where conrelid='premium_translation_private.catalog_operation_artifacts'::regclass and contype='c' and conkey=array[att];
 if n<>1 then raise exception 'Unexpected catalog artifact identity CHECK layout' using errcode='42501';end if;
 execute format('alter table premium_translation_private.catalog_operation_artifacts drop constraint %I',name);
 alter table premium_translation_private.catalog_operation_artifacts add constraint catalog_operation_artifacts_catalog_site_copy_type_check check(entity_type in ('literary_work','country','site_copy'));
end;$check$;
create unique index translation_site_copy_active_operation_unique on public.translation_job_items(entity_type)
 where entity_type='site_copy' and staff_retry is not null;


create function premium_translation_private.site_copy_operation_configuration_valid(v jsonb,p text)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare key text;
begin
  if not premium_translation_private.exact_object(v,array['version','provider','model','reviewerModel','promptFingerprint',
    'translatorReasoningEffort','translatorReasoningMode','reviewerReasoningEffort','reviewerReasoningMode','schemaName','maxOutputTokens','twoPassReview'])
    or v->'version' is distinct from '1'::jsonb or v->>'provider' is distinct from p
    or v->>'schemaName' is distinct from 'probpera_site_copy_translation'
    or v->'maxOutputTokens' is distinct from '12000'::jsonb
    or jsonb_typeof(v->'twoPassReview') is distinct from 'boolean'
    or jsonb_typeof(v->'promptFingerprint') is distinct from 'string' or v->>'promptFingerprint' !~ '^[a-f0-9]{64}$' or octet_length(v::text)>4096 then return false; end if;
  foreach key in array array['model','reviewerModel'] loop
    if jsonb_typeof(v->key) is distinct from 'string' or char_length(v->>key) not between 1 and 200 or v->>key ~ '[[:cntrl:]]' then return false; end if;
  end loop;
  foreach key in array array['translatorReasoningEffort','reviewerReasoningEffort'] loop
    if jsonb_typeof(v->key) is distinct from 'string' or v->>key not in ('none','low','medium','high','xhigh','max') then return false; end if;
  end loop;
  foreach key in array array['translatorReasoningMode','reviewerReasoningMode'] loop
    if jsonb_typeof(v->key) is distinct from 'string' or v->>key not in ('standard','pro') then return false; end if;
  end loop;
  return true;
end; $$;

create function premium_translation_private.site_copy_operation_progress(c jsonb)
returns jsonb language sql immutable security invoker set search_path='' as $$
  select jsonb_build_object('version',1,'updatedAt',coalesce(nullif(c->(jsonb_array_length(c)-1)->'metadata'->'responseReceivedAt','null'::jsonb),
      c->(jsonb_array_length(c)-1)->'metadata'->'dispatchRecordedAt',to_jsonb('1970-01-01T00:00:00Z'::text)),
    'calls',coalesce(jsonb_agg(value->'metadata' order by n),'[]'::jsonb))
  from jsonb_array_elements(c) with ordinality x(value,n);
$$;

create function premium_translation_private.site_copy_operation_scope_lock()
returns void language sql volatile security invoker set search_path='' as $$
 select pg_advisory_xact_lock(hashtextextended('site-copy-operation:site-copy-overrides',7391));
$$;
create function premium_translation_private.site_copy_operation_source_valid(identity text,s jsonb,r jsonb,t jsonb,seed jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare item jsonb;seen text[]:='{}';k text;begin
 perform premium_translation_private.assert_identity('site_copy',identity);
 if not premium_translation_private.exact_object(s,array['settings','items']) or jsonb_typeof(s->'settings') is distinct from 'object'
  or s#>>'{settings,systemKey}' is distinct from 'site-copy-overrides' or jsonb_typeof(s->'items') is distinct from 'array'
  or jsonb_array_length(s->'items') not between 1 and 50 or octet_length(s::text)>4194304
  or not premium_translation_private.exact_object(r,array['blockId','blockUpdatedAt'])
  or (r->>'blockId')::uuid is distinct from identity::uuid
  or not premium_translation_private.valid_revision(t)
  or jsonb_build_object('id',r->'blockId','updatedAt',r->'blockUpdatedAt') is distinct from t
  or not premium_translation_private.exact_object(seed,array['version','block']) or seed->'version'<>'1'::jsonb
  or seed#>'{block,settings}' is distinct from s->'settings'
  or (seed#>>'{block,id}')::uuid is distinct from identity::uuid
  or (seed#>>'{block,updated_at}')::timestamptz is distinct from (r->>'blockUpdatedAt')::timestamptz then return false;end if;
 for item in select value from jsonb_array_elements(s->'items') loop
  if not premium_translation_private.exact_object(item,array['key','text','sourceHash']) or jsonb_typeof(item->'key') is distinct from 'string'
   or jsonb_typeof(item->'text') is distinct from 'string' or jsonb_typeof(item->'sourceHash') is distinct from 'string'
   or coalesce(item->>'sourceHash','')!~'^[a-f0-9]{64}$'
   or premium_translation_private.site_copy_utf16_length(item->>'text') not between 1 and 4000
   or premium_translation_private.trim_text(item->>'text')='' then return false;end if;
  k:=item->>'key';if premium_translation_private.site_copy_utf16_length(k) not between 1 and 1200 or k<>premium_translation_private.trim_text(k)
   or k~'[[:cntrl:]]' or k~*'(^|\.)(__proto__|prototype|constructor)(\.|$)' or k=any(seen) then return false;end if;
  seen:=array_append(seen,k);
 end loop;
 -- Existing server JS projection/hash semantics stay opaque: no SQL hyphen
 -- normalizer or JSONB replacement for SHA256(JSON.stringify(items)).
 perform premium_translation_private.assert_site_copy_recorded(s);return true;
exception when others then return false;end; $$;
create function premium_translation_private.site_copy_operation_capture(identity text,expected jsonb)
returns jsonb language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare b public.homepage_blocks%rowtype;n integer;begin
 perform pg_advisory_xact_lock(188654771,2);
 select count(*) into n from public.homepage_blocks where settings @> '{"systemKey":"site-copy-overrides"}';
 if n<>1 then raise exception 'Site Copy master missing or ambiguous' using errcode='40001';end if;
 select * into b from public.homepage_blocks where id=identity::uuid for update;
 if b.id is null or b.settings->>'systemKey'<>'site-copy-overrides'
  or not premium_translation_private.exact_object(expected,array['version','block']) or expected->'version'<>'1'::jsonb
  or not premium_translation_private.exact_object(expected->'block',array['id','settings','updated_at'])
  or (expected#>>'{block,id}')::uuid is distinct from b.id or expected#>'{block,settings}' is distinct from b.settings
  or (expected#>>'{block,updated_at}')::timestamptz is distinct from b.updated_at then
  raise exception 'Site Copy expected projection changed' using errcode='40001';end if;
 return jsonb_build_object('version',1,'block',to_jsonb(b));
end; $$;
create function premium_translation_private.site_copy_operation_assert_current(a premium_translation_private.catalog_operation_artifacts)
returns void language plpgsql volatile security invoker set search_path='' as $$ declare seed jsonb;begin
 seed:=premium_translation_private.site_copy_operation_capture(a.entity_id,a.expected_state);
 if seed is distinct from a.raw_seed or premium_translation_private.site_copy_operation_source_valid(a.entity_id,a.source_snapshot,a.source_revision,a.target_revision,seed) is distinct from true then
  raise exception 'Site Copy full recorded source changed' using errcode='40001';end if;
end; $$;
create function premium_translation_private.site_copy_operation_owned(p_job uuid,p_item uuid,p_operation uuid)
returns premium_translation_private.catalog_operation_artifacts language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;begin
 perform premium_translation_private.assert_actor();perform premium_translation_private.site_copy_operation_scope_lock();
 select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation for update;
 if a.operation_id is null then raise exception 'Site Copy operation not found' using errcode='P0002';end if;
 if a.actor_id is distinct from auth.uid() then raise exception 'Site Copy operation actor differs' using errcode='42501';end if;
 if a.job_id is distinct from p_job or a.item_id is distinct from p_item or a.entity_type<>'site_copy' then
  raise exception 'Site Copy operation identity differs' using errcode='40001';end if;return a;
end; $$;
create function premium_translation_private.site_copy_operation_view(a premium_translation_private.catalog_operation_artifacts,
 replayed boolean default false,execute_allowed boolean default false,dispatch_allowed boolean default false)
returns jsonb language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare j public.translation_jobs%rowtype;pending uuid;reason text;phase text:='running';begin
 select * into j from public.translation_jobs where id=a.job_id;
 select (value#>>'{metadata,callId}')::uuid into pending from jsonb_array_elements(a.calls) where value#>'{metadata,responseReceivedAt}'='null'::jsonb limit 1;
 if a.final_receipt is not null then return a.final_receipt||jsonb_build_object('replayed',replayed,'canExecute',false,'canDispatch',false);end if;
 if auth.uid() is distinct from a.actor_id then reason:='operation_owned_by_another_actor';
 elsif pending is not null and not dispatch_allowed then reason:='provider_outcome_unknown';
 elsif j.cancel_requested_at is not null then reason:='operation_stopped';
 elsif clock_timestamp()>=a.created_at+interval '45 seconds' and not dispatch_allowed then reason:='operation_deadline';end if;
 if reason is not null then phase:='blocked';end if;
 return jsonb_build_object('version',1,'logicalScope','site-copy-overrides','jobId',a.job_id,'itemId',a.item_id,'operationId',a.operation_id,
  'entityType','site_copy','entityId',a.entity_id,'actorId',a.actor_id,'provider',a.provider,'sourceHash',a.source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,
  'configurationHash',a.configuration_hash,'configuration',a.configuration,'sourceRevision',a.source_revision,'targetRevision',a.target_revision,
  'startedAt',a.created_at,'deadlineAt',a.created_at+interval '45 seconds','jobVersion',j.version::text,'phase',phase,
  'canExecute',execute_allowed and reason is null,'canDispatch',dispatch_allowed,'replayed',replayed,'providerCalls',jsonb_array_length(a.calls),
  'pendingCallId',pending,'blockReason',reason,'resumeCursor','{}'::jsonb,'result',null);
end; $$;
create function public.reconcile_site_copy_translation_operation(p_operation_id uuid default null)
returns jsonb language plpgsql volatile security definer set search_path='' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;begin
 perform premium_translation_private.assert_actor();perform premium_translation_private.site_copy_operation_scope_lock();
 if p_operation_id is not null and not probpera_translation_operations.retry_uuid(p_operation_id) then raise exception 'Invalid Site Copy operation' using errcode='22023';end if;
 -- Logical active scope first, before a recreated block ID/config/feature read.
 select c.* into a from premium_translation_private.catalog_operation_artifacts c join public.translation_job_items i on i.id=c.item_id
  where c.entity_type='site_copy' and i.entity_type='site_copy' and i.staff_retry is not null order by c.created_at desc,c.operation_id desc limit 1;
 if a.operation_id is null then
  select * into a from premium_translation_private.catalog_operation_artifacts where entity_type='site_copy' and(p_operation_id is null or operation_id=p_operation_id)
   order by created_at desc,operation_id desc limit 1;
 end if;
 if a.operation_id is null then return null;end if;return premium_translation_private.site_copy_operation_view(a,true);
end; $$;
create function public.get_site_copy_translation_operation_artifacts(p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_intent_hash text,p_source_hash text,p_raw_seed_hash text)
returns jsonb language plpgsql volatile security definer set search_path='' as $$ declare a premium_translation_private.catalog_operation_artifacts%rowtype;begin
 a:=premium_translation_private.site_copy_operation_owned(p_job_id,p_item_id,p_operation_id);
 if a.intent_hash is distinct from p_intent_hash or a.source_hash is distinct from p_source_hash or a.raw_seed_hash is distinct from p_raw_seed_hash then
  raise exception 'Site Copy private artifact binding differs' using errcode='40001';end if;
 return jsonb_build_object('version',1,'receipt',premium_translation_private.site_copy_operation_view(a,true),'expectedState',a.expected_state,'rawSeed',a.raw_seed,
  'sourceSnapshot',a.source_snapshot,'sourceRevision',a.source_revision,'targetRevision',a.target_revision,'configuration',a.configuration,'calls',a.calls,'candidate',a.candidate);
end; $$;

create function public.begin_site_copy_translation_operation(p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_block_id uuid,p_provider text,
 p_source_hash text,p_source_snapshot jsonb,p_source_revision jsonb,p_target_revision jsonb,p_expected_state jsonb,p_configuration jsonb)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare actor uuid:=premium_translation_private.assert_actor();a premium_translation_private.catalog_operation_artifacts%rowtype;
 j public.translation_jobs%rowtype;i public.translation_job_items%rowtype;request_hash text;marker jsonb;view jsonb;stamp timestamptz:=clock_timestamp();identity text;begin
 perform premium_translation_private.site_copy_operation_scope_lock();
 select c.* into a from premium_translation_private.catalog_operation_artifacts c join public.translation_job_items x on x.id=c.item_id where c.entity_type='site_copy' and x.entity_type='site_copy' and x.staff_retry is not null for update of c;
 if a.operation_id is not null then
  view:=premium_translation_private.site_copy_operation_view(a,true);
  return view||jsonb_build_object('phase','blocked','blockReason',coalesce(view->>'blockReason','operation_in_progress'),'canExecute',false,'canDispatch',false);
 end if;
 identity:=p_block_id::text;
 if not probpera_translation_operations.retry_uuid(p_job_id) or not probpera_translation_operations.retry_uuid(p_item_id)
  or not probpera_translation_operations.retry_uuid(p_operation_id) or not probpera_translation_operations.retry_uuid(p_block_id)
  or p_provider is null or p_provider not in('cloudflare','openai') or coalesce(p_source_hash,'')!~'^[a-f0-9]{64}$'
  or premium_translation_private.site_copy_operation_configuration_valid(p_configuration,p_provider) is distinct from true
  or jsonb_typeof(p_expected_state) is distinct from 'object' or octet_length(p_expected_state::text)>4194304 then
  raise exception 'Invalid Site Copy admission' using errcode='22023';end if;
 request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_job_id,p_item_id,p_operation_id,actor,identity,p_provider,p_source_hash,
  p_source_snapshot,p_source_revision,p_target_revision,p_expected_state,p_configuration));
 perform pg_advisory_xact_lock(hashtextextended(p_operation_id::text,7292));
 select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation_id for update;
 if a.operation_id is not null then
  if a.entity_type<>'site_copy' or a.actor_id<>actor then raise exception 'Site Copy operation actor/domain differs' using errcode='42501';end if;
  if a.begin_request_hash<>request_hash then raise exception 'Site Copy begin intent differs' using errcode='40001';end if;
  return premium_translation_private.site_copy_operation_view(a,true);
 end if;
 perform pg_advisory_xact_lock(hashtextextended('premium-translation:site_copy:'||identity,0));
 if exists(select 1 from public.translation_jobs where id=p_job_id) or exists(select 1 from public.translation_job_items where id=p_item_id)
  or exists(select 1 from premium_translation_private.catalog_operation_artifacts where job_id=p_job_id or item_id=p_item_id)
  or exists(select 1 from premium_translation_private.writer_operation_artifacts where operation_id=p_operation_id)
  or exists(select 1 from public.translation_job_attempts where staff_retry_operation_id=p_operation_id)
  or exists(select 1 from public.translation_job_items where staff_retry is not null and staff_retry->>'operationId'=p_operation_id::text)
  or exists(select 1 from public.premium_translation_working_drafts where entity_type='site_copy' and lower(entity_id)=identity) then
  raise exception 'Site Copy identity or pending candidate already exists' using errcode='40001';end if;
 a.raw_seed:=premium_translation_private.site_copy_operation_capture(identity,p_expected_state);
 if octet_length(a.raw_seed::text)>4194304 or premium_translation_private.site_copy_operation_source_valid(identity,p_source_snapshot,p_source_revision,p_target_revision,a.raw_seed) is distinct from true then
  raise exception 'Site Copy source/target eligibility changed' using errcode='40001';end if;
 a.operation_id:=p_operation_id;a.job_id:=p_job_id;a.item_id:=p_item_id;a.actor_id:=actor;a.entity_type:='site_copy';a.entity_id:=identity;
 a.provider:=p_provider;a.source_hash:=p_source_hash;a.begin_request_hash:=request_hash;a.expected_state:=p_expected_state;
 a.raw_seed_hash:=probpera_translation_operations.retry_fingerprint(a.raw_seed);a.intent_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(request_hash,a.raw_seed_hash));
 a.configuration:=p_configuration;a.configuration_hash:=probpera_translation_operations.retry_fingerprint(p_configuration);
 a.source_snapshot:=p_source_snapshot;a.source_revision:=p_source_revision;a.target_revision:=p_target_revision;a.confirmed_cursor:='{}';a.calls:='[]';a.created_at:=stamp;
 marker:=jsonb_build_object('version',1,'protocol','site-copy-translation','logicalScope','site-copy-overrides','operationId',p_operation_id,'actorId',actor,
  'sourceHash',p_source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,'configurationHash',a.configuration_hash,'startedAt',stamp,'attemptNumber',1,
  'progress',jsonb_build_object('version',1,'updatedAt',stamp,'calls','[]'::jsonb));
 j:=jsonb_populate_record(null::public.translation_jobs,jsonb_build_object('id',p_job_id,'kind','site_copy','source_locale','ru','target_locale','en','provider',p_provider,
  'status','reviewing','total_items',1,'succeeded_items',0,'failed_items',0,'requested_by',actor,'started_at',stamp,'version',1,'created_at',stamp,'updated_at',stamp,
  'resume_cursor',jsonb_build_object('siteCopyOperation',jsonb_build_object('version',1,'logicalScope','site-copy-overrides','operationId',p_operation_id,'actorId',actor,'intentHash',a.intent_hash))));
 i:=jsonb_populate_record(null::public.translation_job_items,jsonb_build_object('id',p_item_id,'job_id',p_job_id,'position',0,'entity_type','site_copy','entity_id',identity,
  'source_hash',p_source_hash,'status','reviewing','attempt_count',0,'max_attempts',1,'next_attempt_at',stamp,'created_at',stamp,'updated_at',stamp,'staff_retry',marker));
 a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);
 insert into premium_translation_private.catalog_operation_artifacts select a.*;insert into public.translation_jobs select j.*;insert into public.translation_job_items select i.*;
 perform premium_translation_private.site_copy_operation_assert_constructed(p_operation_id);
 insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)values(actor,'translation.site_copy_operation.admitted','translation_job',p_job_id::text,
  jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'logicalScope','site-copy-overrides','blockId',identity,'sourceHash',p_source_hash,'rawSeedHash',a.raw_seed_hash));
 return premium_translation_private.site_copy_operation_view(a,false,true);
end; $$;

create function public.record_site_copy_translation_operation_dispatch(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_call_id uuid,p_provider text,p_model text,p_pass text,p_request_hash text
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; j public.translation_jobs%rowtype;
  i public.translation_job_items%rowtype; call jsonb; metadata jsonb; progress jsonb; stamp timestamptz:=clock_timestamp();
begin
  a:=premium_translation_private.site_copy_operation_owned(p_job_id,p_item_id,p_operation_id);
  if not probpera_translation_operations.retry_uuid(p_call_id) or p_provider is distinct from a.provider
    or p_model is null or p_pass is null or p_pass not in ('translation','repair','review')
    or p_request_hash is null or p_request_hash !~ '^[a-f0-9]{64}$'
    or p_model is distinct from a.configuration->>(case when p_pass='translation' then 'model' else 'reviewerModel' end) then
    raise exception 'Invalid catalog dispatch binding' using errcode='22023'; end if;
  for call in select value from jsonb_array_elements(a.calls) loop
    if call->'metadata'->>'callId'=p_call_id::text then
      if call->>'requestHash' is distinct from p_request_hash or call->'metadata'->>'pass' is distinct from p_pass
        or call->'metadata'->>'model' is distinct from p_model then raise exception 'Catalog dispatch intent differs' using errcode='40001'; end if;
      return premium_translation_private.site_copy_operation_view(a,true);
    end if;
  end loop;
  select * into j from public.translation_jobs where id=p_job_id for update;
  if a.final_receipt is not null or j.cancel_requested_at is not null or j.status<>'reviewing' or stamp>=a.created_at+interval '45 seconds'
    or jsonb_array_length(a.calls)>=4 or exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->'responseReceivedAt'='null'::jsonb) then
    raise exception 'Catalog dispatch is blocked or outcome unknown' using errcode='40001'; end if;
  if a.configuration->'twoPassReview'='false'::jsonb and (p_pass='review' or jsonb_array_length(a.calls)>=2) then
    raise exception 'Unconfigured catalog review pass' using errcode='22023'; end if;
  perform premium_translation_private.site_copy_operation_assert_current(a);
  metadata:=jsonb_build_object('callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,
    'dispatchRecordedAt',stamp,'responseReceivedAt',null,'httpStatus',null,'requestId',null,'responseId',null,'inputTokens',null,'outputTokens',null);
  a.calls:=a.calls||jsonb_build_array(jsonb_build_object('requestHash',p_request_hash,'metadata',metadata,'responseArtifact',null));
  progress:=premium_translation_private.site_copy_operation_progress(a.calls);
  if not probpera_translation_operations.retry_journal_valid(progress,a.provider) then
    raise exception 'Catalog dispatch sequence differs' using errcode='40001'; end if;
  select * into i from public.translation_job_items where id=p_item_id for update;
  i.staff_retry:=i.staff_retry||jsonb_build_object('progress',progress);i.updated_at:=stamp;
  a.item_write_proof:=to_jsonb(i);
  update premium_translation_private.catalog_operation_artifacts set calls=a.calls,item_write_proof=a.item_write_proof where operation_id=p_operation_id;
  update public.translation_job_items set staff_retry=i.staff_retry,updated_at=i.updated_at where id=p_item_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.site_copy_operation.dispatch_recorded','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'callId',p_call_id,'provider',p_provider,'model',p_model,'pass',p_pass,'requestHash',p_request_hash));
  return premium_translation_private.site_copy_operation_view(a,false,false,true);
end; $$;

create function public.record_site_copy_translation_operation_response(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_metadata jsonb,p_response_artifact jsonb
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; i public.translation_job_items%rowtype;
  call jsonb; position integer; progress jsonb; stamp timestamptz:=clock_timestamp();
begin
  a:=premium_translation_private.site_copy_operation_owned(p_job_id,p_item_id,p_operation_id);
  if not premium_translation_private.exact_object(p_metadata,array['callId','provider','model','pass','httpStatus','requestId','responseId','inputTokens','outputTokens'])
    or not premium_translation_private.exact_object(p_response_artifact,array['version','body'])
    or p_response_artifact->'version' is distinct from '1'::jsonb or octet_length(p_response_artifact::text)>1048576 then
    raise exception 'Invalid catalog response artifact' using errcode='22023'; end if;
  select value,(n-1)::integer into call,position from jsonb_array_elements(a.calls) with ordinality x(value,n)
    where value->'metadata'->>'callId'=p_metadata->>'callId';
  if position is null then raise exception 'Catalog response dispatch not found' using errcode='40001'; end if;
  if call->'metadata'->>'provider' is distinct from p_metadata->>'provider'
    or call->'metadata'->>'model' is distinct from p_metadata->>'model' or call->'metadata'->>'pass' is distinct from p_metadata->>'pass' then
    raise exception 'Catalog response identity differs' using errcode='40001'; end if;
  if call->'metadata'->'responseReceivedAt'<>'null'::jsonb then
    if (call->'metadata')-array['dispatchRecordedAt','responseReceivedAt'] is distinct from p_metadata
      or call->'responseArtifact' is distinct from p_response_artifact then raise exception 'Catalog response evidence differs' using errcode='40001'; end if;
    return premium_translation_private.site_copy_operation_view(a,true);
  end if;
  if a.final_receipt is not null then raise exception 'Catalog operation already finished' using errcode='40001'; end if;
  call:=call||jsonb_build_object('metadata',p_metadata||jsonb_build_object('dispatchRecordedAt',call->'metadata'->'dispatchRecordedAt','responseReceivedAt',stamp),
    'responseArtifact',p_response_artifact);
  a.calls:=jsonb_set(a.calls,array[position::text],call);
  if octet_length(a.calls::text)>4194304 then raise exception 'Catalog aggregate response artifact limit exceeded' using errcode='22023'; end if;
  progress:=premium_translation_private.site_copy_operation_progress(a.calls);
  if not probpera_translation_operations.retry_journal_valid(progress,a.provider) then
    raise exception 'Catalog response metadata differs' using errcode='22023'; end if;
  select * into i from public.translation_job_items where id=p_item_id for update;
  i.staff_retry:=i.staff_retry||jsonb_build_object('progress',progress);i.updated_at:=stamp;a.item_write_proof:=to_jsonb(i);
  update premium_translation_private.catalog_operation_artifacts set calls=a.calls,item_write_proof=a.item_write_proof where operation_id=p_operation_id;
  update public.translation_job_items set staff_retry=i.staff_retry,updated_at=i.updated_at where id=p_item_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.site_copy_operation.response_received','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'callId',p_metadata->'callId','responseHash',probpera_translation_operations.retry_fingerprint(p_response_artifact)));
  return premium_translation_private.site_copy_operation_view(a);
end; $$;

create function public.finish_site_copy_translation_operation(
  p_job_id uuid,p_item_id uuid,p_operation_id uuid,p_outcome jsonb,p_candidate jsonb default null
)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype; j public.translation_jobs%rowtype;
  i public.translation_job_items%rowtype; attempt public.translation_job_attempts%rowtype;
  draft public.premium_translation_working_drafts%rowtype; current_work jsonb; current_ru jsonb; current_sources jsonb; selected_source jsonb; urls jsonb; n integer;
  fingerprint text; digest text; status text; code text; state text; persistence text:='none'; result jsonb; receipt jsonb;
  first_call jsonb; last_call jsonb; stamp timestamptz:=clock_timestamp(); current_bound boolean:=true;
begin
  a:=premium_translation_private.site_copy_operation_owned(p_job_id,p_item_id,p_operation_id);
  if p_outcome is null or jsonb_typeof(p_outcome)<>'object'
    or not(p_outcome ?& array['status','providerCalls'])
    or p_outcome-array['status','providerCalls','errorCode','model','requestId','inputTokens','outputTokens','durationMs']<>'{}'::jsonb
    or coalesce(p_outcome->>'status','') not in ('succeeded','dead_letter','conflict','stale','skipped','not-configured','cancelled')
    or jsonb_typeof(p_outcome->'providerCalls') is distinct from 'number'
    or p_outcome->>'providerCalls' !~ '^[0-4]$'
    or (p_outcome->>'providerCalls')::integer<>jsonb_array_length(a.calls)
    or (p_outcome->>'errorCode' is not null and p_outcome->>'errorCode' not in
      ('translation_not_configured','provider_unavailable','provider_request_failed','provider_invalid_response',
       'source_changed','write_conflict','database_read_failed','database_write_failed','unexpected','translation_operation_stopped')) then
    raise exception 'Invalid catalog finish outcome' using errcode='22023'; end if;
  fingerprint:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(p_outcome,p_candidate));
  if a.final_receipt is not null then
    if a.finish_fingerprint is distinct from fingerprint then raise exception 'Catalog finish intent differs' using errcode='40001'; end if;
    return premium_translation_private.site_copy_operation_view(a,true);
  end if;
  if exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->'responseReceivedAt'='null'::jsonb) then
    raise exception 'Catalog provider outcome remains unknown' using errcode='40001'; end if;
  select * into j from public.translation_jobs where id=p_job_id for update;
  select * into i from public.translation_job_items where id=p_item_id for update;
  status:=p_outcome->>'status';code:=p_outcome->>'errorCode';
  -- A paid unfinished pass is not a terminal failure/retry grant. Retain it.
  if jsonb_array_length(a.calls)>0 and p_candidate is null then raise exception 'Site Copy paid partial response must remain retained' using errcode='40001';end if;
  if (status='succeeded') is distinct from (p_candidate is not null) then
    raise exception 'Catalog completed candidate required only for success' using errcode='22023'; end if;
  if p_candidate is not null then
    n:=jsonb_array_length(a.calls);
    if not premium_translation_private.exact_object(p_candidate,array['payload','provenance','translatorCallId','reviewerCallId'])
      or n<1 or octet_length(p_candidate::text)>1048576
      or (a.configuration->'twoPassReview'='true'::jsonb and not exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->>'pass'='review'))
      or (a.configuration->'twoPassReview'='false'::jsonb and (n>2 or exists(select 1 from jsonb_array_elements(a.calls) value where value->'metadata'->>'pass'='review'))) then
      raise exception 'Catalog independent review proof missing' using errcode='22023'; end if;
    first_call:=a.calls->0->'metadata';last_call:=a.calls->(jsonb_array_length(a.calls)-1)->'metadata';
    if p_candidate->>'translatorCallId' is distinct from first_call->>'callId'
      or p_candidate->>'reviewerCallId' is distinct from (case when n=1 then null else last_call->>'callId' end)
      or p_candidate->'provenance'->>'provider' is distinct from a.provider
      or p_candidate->'provenance'->>'translatorModel' is distinct from first_call->>'model'
      or p_candidate->'provenance'->>'reviewerModel' is distinct from (case when n=1 then null else last_call->>'model' end)
      or p_candidate->'provenance'->>'translatorRequestId' is distinct from coalesce(first_call->>'requestId',first_call->>'responseId')
      or p_candidate->'provenance'->>'reviewerRequestId' is distinct from (case when n=1 then null else coalesce(last_call->>'requestId',last_call->>'responseId') end) then
      raise exception 'Catalog candidate provider evidence differs' using errcode='40001'; end if;
    perform premium_translation_private.assert_shape(a.entity_type,a.source_snapshot,a.source_revision,a.target_revision,
      p_candidate->'payload',p_candidate->'provenance');
    perform premium_translation_private.assert_site_copy_recorded(a.source_snapshot);
    perform pg_advisory_xact_lock(hashtextextended('premium-translation:site_copy:'||a.entity_id,0));
    select * into draft from public.premium_translation_working_drafts where entity_type='site_copy' and entity_id=a.entity_id for update;
    begin perform premium_translation_private.site_copy_operation_assert_current(a);
    exception when serialization_failure then current_bound:=false;status:='stale';code:='source_changed';end;
    digest:=probpera_translation_operations.retry_fingerprint(jsonb_build_object('entityType',a.entity_type,'entityId',a.entity_id,
      'targetLocale','en','sourceHash',a.source_hash,'sourceSnapshot',a.source_snapshot,'sourceRevision',a.source_revision,
      'targetRevision',a.target_revision,'payload',p_candidate->'payload','provenance',p_candidate->'provenance'));
    -- A fully validated body is retained independently of live CAS/cancel.
    -- Existing pending author/review work is never replaced.
    if draft.id is null then
      insert into public.premium_translation_working_drafts(entity_type,entity_id,source_hash,candidate_hash,source_snapshot,
        source_revision,target_revision,payload,provenance,created_by)
        values(a.entity_type,a.entity_id,a.source_hash,digest,a.source_snapshot,a.source_revision,a.target_revision,
          p_candidate->'payload',p_candidate->'provenance',a.actor_id) returning * into draft;
      persistence:='working-draft';
    elsif draft.candidate_hash=digest and draft.source_snapshot=a.source_snapshot and draft.source_revision=a.source_revision
      and draft.target_revision=a.target_revision and draft.payload=p_candidate->'payload' and draft.provenance=p_candidate->'provenance' then
      persistence:='working-draft';
    else
      persistence:='private-artifact';status:='conflict';code:='write_conflict';draft:=null;
    end if;
  end if;
  if j.cancel_requested_at is not null then status:='cancelled';code:=null; end if;
  if status in ('succeeded','skipped','cancelled') then code:=null;
  elsif code is null then code:=case status when 'stale' then 'source_changed' when 'conflict' then 'write_conflict'
    when 'not-configured' then 'translation_not_configured' else 'unexpected' end; end if;
  state:=case status when 'succeeded' then 'translated' when 'dead_letter' then 'failed' else status end;
  result:=jsonb_build_object('state',state,'errorCode',code,'persistence',persistence,
    'draftId',case when persistence='working-draft' then draft.id else null end,
    'draftVersion',case when persistence='working-draft' then draft.version else null end,
    'draftUpdatedAt',case when persistence='working-draft' then draft.created_at else null end,'candidateHash',digest,'publication','unchanged',
    'humanReview',case when p_candidate is null then 'unchanged' else 'pending' end);
  j.status:=case status when 'succeeded' then 'completed' when 'dead_letter' then 'failed' else status end;
  j.succeeded_items:=case when status='succeeded' then 1 else 0 end;j.failed_items:=case when status='dead_letter' then 1 else 0 end;
  j.version:=j.version+1;j.updated_at:=stamp;j.completed_at:=stamp;
  if not(status='skipped' and jsonb_array_length(a.calls)=0) then
    j.resume_cursor:=a.confirmed_cursor||jsonb_build_object('siteCopyOperation',j.resume_cursor->'siteCopyOperation');
  end if;
  receipt:=premium_translation_private.site_copy_operation_view(a)||jsonb_build_object('phase','finished','blockReason',null,'pendingCallId',null,
    'canExecute',false,'canDispatch',false,'jobVersion',j.version::text,'resumeCursor',j.resume_cursor-'siteCopyOperation','result',result);
  i.status:=case status when 'succeeded' then 'succeeded' when 'cancelled' then 'cancelled' else status end;
  i.attempt_count:=1;i.staff_retry:=null;i.last_error_code:=code;i.updated_at:=stamp;
  attempt:=jsonb_populate_record(null::public.translation_job_attempts,jsonb_build_object(
    'id',nextval('public.translation_job_attempts_id_seq'),'item_id',p_item_id,'attempt_number',1,
    'outcome',case when status='cancelled' then 'skipped' else status end,'provider',a.provider,
    'model',p_outcome->'model','provider_request_id',p_outcome->'requestId','error_code',code,
    'input_tokens',p_outcome->'inputTokens','output_tokens',p_outcome->'outputTokens','duration_ms',p_outcome->'durationMs',
    'created_at',stamp,'staff_retry_operation_id',p_operation_id,'staff_retry_receipt',jsonb_build_object('version',1,
      'actorId',a.actor_id,'intentHash',a.intent_hash,'finishFingerprint',fingerprint,'receipt',receipt,
      'progress',premium_translation_private.site_copy_operation_progress(a.calls))));
  if persistence='working-draft' then a.linked_draft_id:=draft.id;a.linked_draft_version:=draft.version; end if;
  a.candidate_hash:=digest;
  a.candidate:=p_candidate;a.final_receipt:=receipt;a.finish_fingerprint:=fingerprint;
  a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);a.attempt_write_proof:=to_jsonb(attempt);
  update premium_translation_private.catalog_operation_artifacts set candidate=a.candidate,final_receipt=receipt,finish_fingerprint=fingerprint,
    linked_draft_id=a.linked_draft_id,linked_draft_version=a.linked_draft_version,candidate_hash=digest,
    job_write_proof=a.job_write_proof,item_write_proof=a.item_write_proof,attempt_write_proof=a.attempt_write_proof where operation_id=p_operation_id;
  insert into public.translation_job_attempts overriding system value select attempt.*;
  update public.translation_job_items set status=i.status,attempt_count=i.attempt_count,staff_retry=null,last_error_code=code,updated_at=stamp where id=p_item_id;
  update public.translation_jobs set status=j.status,succeeded_items=j.succeeded_items,failed_items=j.failed_items,version=j.version,
    updated_at=stamp,completed_at=stamp,resume_cursor=j.resume_cursor where id=p_job_id;
  insert into public.admin_audit_log(actor_id,action,entity_type,entity_id,metadata)
    values(a.actor_id,'translation.site_copy_operation.finished','translation_job',p_job_id::text,
      jsonb_build_object('operationId',p_operation_id,'itemId',p_item_id,'state',state,'persistence',persistence,'candidateHash',digest));
  return receipt;
end; $$;

-- ADDITIVE guard part for parent-only unexecuted admission draft.
create function premium_translation_private.site_copy_operation_complete_valid(a premium_translation_private.catalog_operation_artifacts,candidate jsonb)
returns boolean language plpgsql immutable security invoker set search_path='' as $$
declare first jsonb;last jsonb;n integer;sequence text;begin
 n:=jsonb_array_length(a.calls);
 if n<1 or not premium_translation_private.exact_object(candidate,array['payload','provenance','translatorCallId','reviewerCallId'])
  or octet_length(candidate::text)>1048576 then return false;end if;
 select string_agg(value#>>'{metadata,pass}',',' order by pos) into sequence from jsonb_array_elements(a.calls) with ordinality x(value,pos);
 if a.configuration->'twoPassReview'='true'::jsonb then
  if sequence not in('translation,review','translation,repair,review','translation,review,repair','translation,repair,review,repair') then return false;end if;
 elsif sequence not in('translation','translation,repair') then return false;end if;
 if exists(select 1 from jsonb_array_elements(a.calls) c where c#>'{metadata,responseReceivedAt}'='null'::jsonb or c->'responseArtifact'='null'::jsonb
  or(c#>'{metadata,httpStatus}'<>'null'::jsonb and(c#>>'{metadata,httpStatus}')::integer not between 200 and 299)) then return false;end if;
 first:=a.calls->0->'metadata';last:=a.calls->(n-1)->'metadata';
 if candidate->>'translatorCallId' is distinct from first->>'callId'
  or candidate->>'reviewerCallId' is distinct from(case when n=1 then null else last->>'callId' end)
  or candidate#>>'{provenance,provider}' is distinct from a.provider
  or candidate#>>'{provenance,translatorModel}' is distinct from first->>'model'
  or candidate#>>'{provenance,reviewerModel}' is distinct from(case when n=1 then null else last->>'model' end)
  or candidate#>>'{provenance,translatorRequestId}' is distinct from coalesce(first->>'requestId',first->>'responseId')
  or candidate#>>'{provenance,reviewerRequestId}' is distinct from(case when n=1 then null else coalesce(last->>'requestId',last->>'responseId') end) then return false;end if;
 perform premium_translation_private.assert_shape('site_copy',a.source_snapshot,a.source_revision,a.target_revision,candidate->'payload',candidate->'provenance');
 perform premium_translation_private.assert_site_copy_recorded(a.source_snapshot);return true;
exception when others then return false;end; $$;

create function premium_translation_private.site_copy_operation_cache_guard()
returns trigger language plpgsql security definer set search_path='' as $$
declare n integer;previous integer;idx integer;c jsonb;old_call jsonb;d public.premium_translation_working_drafts%rowtype;digest text;j public.translation_jobs%rowtype;
begin
 if tg_op='DELETE' then
  if old.entity_type='site_copy' then raise exception 'Site Copy paid artifacts cannot be deleted' using errcode='42501';end if;return old;
 end if;
 if new.entity_type<>'site_copy' and(tg_op='INSERT' or old.entity_type<>'site_copy') then return new;end if;
 if new.entity_type<>'site_copy' or new.entity_id<>((new.entity_id)::uuid)::text
  or new.confirmed_cursor<>'{}'::jsonb or new.raw_seed_hash<>probpera_translation_operations.retry_fingerprint(new.raw_seed)
  or new.configuration_hash<>probpera_translation_operations.retry_fingerprint(new.configuration)
  or new.intent_hash<>probpera_translation_operations.retry_fingerprint(jsonb_build_array(new.begin_request_hash,new.raw_seed_hash))
  or premium_translation_private.site_copy_operation_configuration_valid(new.configuration,new.provider) is distinct from true
  or premium_translation_private.site_copy_operation_source_valid(new.entity_id,new.source_snapshot,new.source_revision,new.target_revision,new.raw_seed) is distinct from true
  or probpera_translation_operations.retry_journal_valid(premium_translation_private.site_copy_operation_progress(new.calls),new.provider) is distinct from true
  or new.job_write_proof->>'id' is distinct from new.job_id::text or new.job_write_proof->>'kind' is distinct from 'site_copy'
  or new.job_write_proof->>'requested_by' is distinct from new.actor_id::text
  or new.item_write_proof->>'id' is distinct from new.item_id::text or new.item_write_proof->>'job_id' is distinct from new.job_id::text
  or new.item_write_proof->>'entity_type' is distinct from 'site_copy' or new.item_write_proof->>'entity_id' is distinct from new.entity_id
  or new.item_write_proof->>'source_hash' is distinct from new.source_hash
  or new.item_write_proof->>'position' is distinct from '0' or new.item_write_proof->>'max_attempts' is distinct from '1'
  or new.begin_request_hash is distinct from probpera_translation_operations.retry_fingerprint(jsonb_build_array(new.job_id,new.item_id,new.operation_id,new.actor_id,
   new.entity_id,new.provider,new.source_hash,new.source_snapshot,new.source_revision,new.target_revision,new.expected_state,new.configuration)) then
  raise exception 'Invalid Site Copy private artifact proof' using errcode='42501';end if;
 n:=jsonb_array_length(new.calls);
 for c in select value from jsonb_array_elements(new.calls) loop
  if not premium_translation_private.exact_object(c,array['requestHash','metadata','responseArtifact']) or coalesce(c->>'requestHash','')!~'^[a-f0-9]{64}$'
   or(c#>'{metadata,responseReceivedAt}'='null'::jsonb) is distinct from(c->'responseArtifact'='null'::jsonb)
   or(c->'responseArtifact'<>'null'::jsonb and(not premium_translation_private.exact_object(c->'responseArtifact',array['version','body']) or c#>'{responseArtifact,version}' is distinct from '1'::jsonb))
   or c#>>'{metadata,provider}' is distinct from new.provider
   or c#>>'{metadata,model}' is distinct from new.configuration->>(case when c#>>'{metadata,pass}'='translation' then 'model' else 'reviewerModel' end) then
   raise exception 'Invalid Site Copy private call proof' using errcode='42501';end if;
 end loop;
 if new.configuration->'twoPassReview'='false'::jsonb and(n>2 or exists(select 1 from jsonb_array_elements(new.calls) entry(value) where entry.value#>>'{metadata,pass}'='review')) then
  raise exception 'Site Copy review not configured' using errcode='42501';end if;
 if tg_op='INSERT' then
  if n<>0 or new.candidate is not null or new.final_receipt is not null or new.finish_fingerprint is not null or new.linked_draft_id is not null
   or new.linked_draft_version is not null or new.candidate_hash is not null or new.attempt_write_proof is not null
   or new.job_write_proof->>'status' is distinct from 'reviewing' or new.job_write_proof->>'provider' is distinct from new.provider
   or new.item_write_proof->>'status' is distinct from 'reviewing' or new.item_write_proof->>'attempt_count' is distinct from '0'
   or new.item_write_proof#>>'{staff_retry,protocol}' is distinct from 'site-copy-translation'
   or new.item_write_proof#>>'{staff_retry,logicalScope}' is distinct from 'site-copy-overrides'
   or new.item_write_proof#>>'{staff_retry,operationId}' is distinct from new.operation_id::text
   or new.item_write_proof#>>'{staff_retry,actorId}' is distinct from new.actor_id::text
   or new.item_write_proof#>>'{staff_retry,sourceHash}' is distinct from new.source_hash
   or new.item_write_proof#>>'{staff_retry,intentHash}' is distinct from new.intent_hash
   or new.item_write_proof#>>'{staff_retry,rawSeedHash}' is distinct from new.raw_seed_hash
   or new.item_write_proof#>>'{staff_retry,configurationHash}' is distinct from new.configuration_hash
   or new.item_write_proof#>>'{staff_retry,attemptNumber}' is distinct from '1' then
   raise exception 'Invalid initial Site Copy admission proof' using errcode='42501';end if;
  perform premium_translation_private.site_copy_operation_assert_current(new);return new;
 end if;
 if old.entity_type<>'site_copy' or(to_jsonb(new)-array['calls','candidate','final_receipt','finish_fingerprint','linked_draft_id','linked_draft_version','candidate_hash','job_write_proof','item_write_proof','attempt_write_proof'])
  is distinct from(to_jsonb(old)-array['calls','candidate','final_receipt','finish_fingerprint','linked_draft_id','linked_draft_version','candidate_hash','job_write_proof','item_write_proof','attempt_write_proof']) then
  raise exception 'Site Copy admission identity/source is immutable' using errcode='42501';end if;
 if old.final_receipt is not null then
  if to_jsonb(new) is distinct from to_jsonb(old) then raise exception 'Site Copy completed artifacts are immutable' using errcode='42501';end if;return new;
 end if;
 previous:=jsonb_array_length(old.calls);
 if new.final_receipt is null then
  if(to_jsonb(new)-array['calls','item_write_proof']) is distinct from(to_jsonb(old)-array['calls','item_write_proof'])
   or(new.item_write_proof-array['staff_retry','updated_at']) is distinct from(old.item_write_proof-array['staff_retry','updated_at'])
   or((new.item_write_proof->'staff_retry')-'progress') is distinct from((old.item_write_proof->'staff_retry')-'progress')
   or new.item_write_proof#>'{staff_retry,progress}' is distinct from premium_translation_private.site_copy_operation_progress(new.calls) then
   raise exception 'Site Copy call transition cannot replace journal history' using errcode='42501';end if;
  if n=previous+1 then
   select * into j from public.translation_jobs where id=old.job_id for update;
   if previous>=4 or clock_timestamp()>=old.created_at+interval '45 seconds'
    or j.id is null or j.status is distinct from 'reviewing' or j.cancel_requested_at is not null
    or exists(select 1 from jsonb_array_elements(old.calls) entry(value) where entry.value#>'{metadata,responseReceivedAt}'='null'::jsonb)
    or new.calls->previous->'responseArtifact'<>'null'::jsonb then raise exception 'Site Copy call transition stopped or unknown' using errcode='42501';end if;
   if previous>0 then for idx in 0..previous-1 loop if new.calls->idx is distinct from old.calls->idx then raise exception 'Site Copy old call changed' using errcode='42501';end if;end loop;end if;
   -- The exact recorded full source/manual/CAS check holds canonical locks.
   perform premium_translation_private.site_copy_operation_assert_current(old);
  elsif n=previous and n>0 then
   if n>1 then for idx in 0..n-2 loop if new.calls->idx is distinct from old.calls->idx then raise exception 'Site Copy acknowledged call changed' using errcode='42501';end if;end loop;end if;
   c:=new.calls->(n-1);old_call:=old.calls->(n-1);
   if old_call#>'{metadata,responseReceivedAt}'<>'null'::jsonb or c#>'{metadata,responseReceivedAt}'='null'::jsonb
    or c->>'requestHash' is distinct from old_call->>'requestHash'
    or((c->'metadata')-array['responseReceivedAt','httpStatus','requestId','responseId','inputTokens','outputTokens'])
     is distinct from((old_call->'metadata')-array['responseReceivedAt','httpStatus','requestId','responseId','inputTokens','outputTokens']) then
    raise exception 'Site Copy response cannot replace acceptance evidence' using errcode='42501';end if;
  elsif new.calls is distinct from old.calls or new.item_write_proof is distinct from old.item_write_proof then
   raise exception 'Invalid Site Copy call update' using errcode='42501';end if;
  return new;
 end if;
 if new.calls is distinct from old.calls or new.finish_fingerprint is null
  or exists(select 1 from jsonb_array_elements(new.calls) entry(value) where entry.value#>'{metadata,responseReceivedAt}'='null'::jsonb)
  or(n>0 and premium_translation_private.site_copy_operation_complete_valid(new,new.candidate) is distinct from true)
  or(n=0 and(new.candidate is not null or new.candidate_hash is not null or new.linked_draft_id is not null))
  or new.final_receipt->>'phase' is distinct from 'finished' or new.final_receipt->'canExecute' is distinct from 'false'::jsonb or new.final_receipt->'canDispatch' is distinct from 'false'::jsonb
  or new.final_receipt->>'operationId' is distinct from new.operation_id::text or new.final_receipt->>'logicalScope' is distinct from 'site-copy-overrides'
  or new.item_write_proof->'staff_retry' is distinct from 'null'::jsonb or new.item_write_proof->>'attempt_count' is distinct from '1'
  or new.attempt_write_proof->>'staff_retry_operation_id' is distinct from new.operation_id::text then
  raise exception 'Site Copy unknown/partial result cannot become a fresh retry' using errcode='42501';end if;
 if n=0 and(new.attempt_write_proof->'model' is distinct from 'null'::jsonb or new.attempt_write_proof->'provider_request_id' is distinct from 'null'::jsonb
  or new.attempt_write_proof->'input_tokens' is distinct from 'null'::jsonb or new.attempt_write_proof->'output_tokens' is distinct from 'null'::jsonb or new.attempt_write_proof->'duration_ms' is distinct from 'null'::jsonb) then
  raise exception 'Zero-call Site Copy cleanup cannot carry expense fields' using errcode='42501';end if;
 if new.candidate is not null then
  digest:=probpera_translation_operations.retry_fingerprint(jsonb_build_object('entityType','site_copy','entityId',new.entity_id,'targetLocale','en',
   'sourceHash',new.source_hash,'sourceSnapshot',new.source_snapshot,'sourceRevision',new.source_revision,'targetRevision',new.target_revision,
   'payload',new.candidate->'payload','provenance',new.candidate->'provenance'));
  if new.candidate_hash is distinct from digest then raise exception 'Site Copy paid candidate hash differs' using errcode='42501';end if;
 end if;
 if new.linked_draft_id is not null then
  select * into d from public.premium_translation_working_drafts where id=new.linked_draft_id;
  if d.id is null or d.entity_type<>'site_copy' or d.entity_id<>new.entity_id or d.version is distinct from new.linked_draft_version
   or d.candidate_hash is distinct from new.candidate_hash or d.source_hash is distinct from new.source_hash
   or d.source_snapshot is distinct from new.source_snapshot or d.source_revision is distinct from new.source_revision or d.target_revision is distinct from new.target_revision
   or d.payload is distinct from new.candidate->'payload' or d.provenance is distinct from new.candidate->'provenance' then
   raise exception 'Site Copy paid candidate pointer differs' using errcode='42501';end if;
 end if;return new;
end; $$;
create trigger catalog_artifacts_site_copy_private_integrity before insert or update or delete on premium_translation_private.catalog_operation_artifacts
 for each row execute function premium_translation_private.site_copy_operation_cache_guard();

create function premium_translation_private.site_copy_operation_item_guard()
returns trigger language plpgsql security definer set search_path='' as $$ declare a premium_translation_private.catalog_operation_artifacts%rowtype;begin
 if tg_op='INSERT' then
  if new.entity_type<>'site_copy' or new.staff_retry is null then return new;end if;
  select * into a from premium_translation_private.catalog_operation_artifacts where item_id=new.id;
 else
  if old.entity_type<>'site_copy' and new.entity_type<>'site_copy' then return new;end if;
  select * into a from premium_translation_private.catalog_operation_artifacts where item_id=old.id;
 end if;
 if a.operation_id is null then
  if new.staff_retry is not null then raise exception 'Site Copy item requires private admission proof' using errcode='42501';end if;return new;
 end if;
 if a.entity_type<>'site_copy' or to_jsonb(new) is distinct from a.item_write_proof then
  raise exception 'Site Copy item private proof differs' using errcode='42501';end if;return new;
end; $$;
create trigger translation_items_site_copy_integrity before insert or update on public.translation_job_items
 for each row execute function premium_translation_private.site_copy_operation_item_guard();

-- One cache INSERT event checks the reverse cache-to-real-journal direction at
-- COMMIT. Cache-first deferred foreign keys remain valid during construction;
-- neither existing public journal rows nor absent rows can be blindly adopted.
-- The same assertion runs explicitly after the fresh BEGIN inserts, before it
-- returns the one new execution capability. No session flag authorizes a skip.
create function premium_translation_private.site_copy_operation_assert_constructed(p_operation uuid)
returns void language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;j public.translation_jobs%rowtype;
 i public.translation_job_items%rowtype;t public.translation_job_attempts%rowtype;marker jsonb;progress jsonb;job_matches boolean;
begin
 select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=p_operation;
 if a.operation_id is null or a.entity_type is distinct from 'site_copy' then
  raise exception 'Site Copy admission cache missing or changed' using errcode='42501';end if;
 select * into j from public.translation_jobs where id=a.job_id;
 select * into i from public.translation_job_items where id=a.item_id;
 marker:=jsonb_build_object('version',1,'logicalScope','site-copy-overrides','operationId',a.operation_id,'actorId',a.actor_id,'intentHash',a.intent_hash);
 if j.id is null or i.id is null or j.kind is distinct from 'site_copy' or j.provider is distinct from a.provider
  or j.requested_by is distinct from a.actor_id or j.source_locale is distinct from 'ru' or j.target_locale is distinct from 'en'
  or j.total_items is distinct from 1 or j.created_at is distinct from a.created_at or j.started_at is distinct from a.created_at
  or j.resume_cursor is distinct from jsonb_build_object('siteCopyOperation',marker)
  or i.job_id is distinct from a.job_id or i.entity_type is distinct from 'site_copy' or i.entity_id is distinct from a.entity_id
  or i.source_hash is distinct from a.source_hash or i.position is distinct from 0 or i.max_attempts is distinct from 1
  or i.created_at is distinct from a.created_at or to_jsonb(i) is distinct from a.item_write_proof
  or a.configuration_hash is distinct from probpera_translation_operations.retry_fingerprint(a.configuration)
  or a.raw_seed_hash is distinct from probpera_translation_operations.retry_fingerprint(a.raw_seed)
  or a.begin_request_hash is distinct from probpera_translation_operations.retry_fingerprint(jsonb_build_array(a.job_id,a.item_id,a.operation_id,a.actor_id,
   a.entity_id,a.provider,a.source_hash,a.source_snapshot,a.source_revision,a.target_revision,a.expected_state,a.configuration))
  or a.intent_hash is distinct from probpera_translation_operations.retry_fingerprint(jsonb_build_array(a.begin_request_hash,a.raw_seed_hash)) then
  raise exception 'Site Copy admission actual journal binding differs' using errcode='42501';end if;
 job_matches:=to_jsonb(j)=a.job_write_proof;
 -- Existing catalog journal cancellation is the sole monotonic exception: it
 -- changes only these fields and never grants another dispatch or clears item.
 if not job_matches then
  job_matches:=j.cancel_requested_at is not null and j.status in('cancelling','cancelled')
   and j.version=(a.job_write_proof->>'version')::bigint+1
   and a.job_write_proof->'cancel_requested_at'='null'::jsonb
   and(to_jsonb(j)-array['cancel_requested_at','status','version','updated_at','completed_at'])=
      (a.job_write_proof-array['cancel_requested_at','status','version','updated_at','completed_at']);
 end if;
 if job_matches is distinct from true then
  raise exception 'Site Copy admission actual job proof differs' using errcode='42501';end if;
 if a.final_receipt is null then
  progress:=case when jsonb_array_length(a.calls)=0 then jsonb_build_object('version',1,'updatedAt',a.created_at,'calls','[]'::jsonb)
   else premium_translation_private.site_copy_operation_progress(a.calls) end;
  marker:=jsonb_build_object('version',1,'protocol','site-copy-translation','logicalScope','site-copy-overrides','operationId',a.operation_id,'actorId',a.actor_id,
   'sourceHash',a.source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,'configurationHash',a.configuration_hash,'startedAt',a.created_at,
   'attemptNumber',1,'progress',progress);
  if i.staff_retry is distinct from marker or i.attempt_count is distinct from 0 or i.status is distinct from 'reviewing'
   or a.attempt_write_proof is not null or exists(select 1 from public.translation_job_attempts where item_id=a.item_id or staff_retry_operation_id=a.operation_id) then
   raise exception 'Site Copy unfinished admission attempt proof differs' using errcode='42501';end if;
 else
  if a.attempt_write_proof is null or i.staff_retry is not null or i.attempt_count is distinct from 1 then
   raise exception 'Site Copy completed admission lacks actual attempt proof' using errcode='42501';end if;
  select * into t from public.translation_job_attempts where id=(a.attempt_write_proof->>'id')::bigint;
  if t.id is null or t.item_id is distinct from a.item_id or t.attempt_number is distinct from 1 or t.provider is distinct from a.provider
   or t.staff_retry_operation_id is distinct from a.operation_id or to_jsonb(t) is distinct from a.attempt_write_proof
   or t.staff_retry_receipt->>'actorId' is distinct from a.actor_id::text
   or t.staff_retry_receipt->>'intentHash' is distinct from a.intent_hash
   or t.staff_retry_receipt->>'finishFingerprint' is distinct from a.finish_fingerprint
   or t.staff_retry_receipt->'receipt' is distinct from a.final_receipt
   or t.staff_retry_receipt->'progress' is distinct from premium_translation_private.site_copy_operation_progress(a.calls)
   or(select count(*) from public.translation_job_attempts where item_id=a.item_id or staff_retry_operation_id=a.operation_id)<>1 then
   raise exception 'Site Copy completed admission actual attempt differs' using errcode='42501';end if;
 end if;
end; $$;
create function premium_translation_private.site_copy_operation_cache_commit_guard()
returns trigger language plpgsql security definer set search_path='' as $$ begin
 perform premium_translation_private.site_copy_operation_assert_constructed(new.operation_id);return null;
end; $$;
create constraint trigger catalog_artifacts_site_copy_admission_complete
 after insert on premium_translation_private.catalog_operation_artifacts deferrable initially deferred
 for each row when(new.entity_type='site_copy') execute function premium_translation_private.site_copy_operation_cache_commit_guard();

-- Linked site-copy candidates are immutable; explicit DELETE/discard remains.
-- The completed private cache keeps the paid body after consumption/discard.
create function premium_translation_private.site_copy_linked_candidate_update_guard()
returns trigger language plpgsql security definer set search_path='' as $$ begin
 if tg_op='INSERT' then
  if exists(select 1 from premium_translation_private.catalog_operation_artifacts where entity_type='site_copy' and linked_draft_id=new.id) then
   raise exception 'Consumed Site Copy candidate UUID cannot be reused' using errcode='42501';end if;return new;
 end if;
 if new.id is distinct from old.id and exists(select 1 from premium_translation_private.catalog_operation_artifacts where entity_type='site_copy' and linked_draft_id=new.id) then
  raise exception 'Consumed Site Copy candidate UUID cannot be reused' using errcode='42501';end if;
 if exists(select 1 from premium_translation_private.catalog_operation_artifacts where entity_type='site_copy' and linked_draft_id=old.id)
  and to_jsonb(new) is distinct from to_jsonb(old) then
  raise exception 'Linked Site Copy candidate is immutable' using errcode='42501';end if;return new;
end; $$;
create trigger premium_site_copy_linked_candidate_immutable before insert or update on public.premium_translation_working_drafts
 for each row execute function premium_translation_private.site_copy_linked_candidate_update_guard();

create function premium_translation_private.site_copy_paid_approval_settings(d public.premium_translation_working_drafts,b public.homepage_blocks,human jsonb)
returns jsonb language plpgsql stable security invoker set search_path='' as $$
declare translations jsonb;english jsonb;meta jsonb;machine jsonb;item jsonb;source_item jsonb;k text;idx integer;begin
 if not premium_translation_private.exact_object(human,array['status','reviewedBy','reviewedAt']) or human->>'status'<>'approved'
  or (human->>'reviewedBy')::uuid is distinct from auth.uid() or not premium_translation_private.valid_timestamp(human->>'reviewedAt') then
  raise exception 'Invalid Site Copy human approval marker' using errcode='40001';end if;
 perform premium_translation_private.assert_shape('site_copy',d.source_snapshot,d.source_revision,d.target_revision,d.payload,d.provenance);
 translations:=b.settings->'siteCopy';english:=case when jsonb_typeof(translations->'en')='object' then translations->'en' else '{}'::jsonb end;
 meta:=case when jsonb_typeof(b.settings->'premiumTranslation')='object' then b.settings->'premiumTranslation' else '{}'::jsonb end;
 machine:=case when jsonb_typeof(meta->'siteCopyEn')='object' then meta->'siteCopyEn' else '{}'::jsonb end;
 for idx in 0..jsonb_array_length(d.payload->'items')-1 loop
  item:=d.payload->'items'->idx;source_item:=d.source_snapshot->'items'->idx;k:=item->>'key';
  machine:=machine||jsonb_build_object(k,coalesce(machine->k,'{}'::jsonb)||jsonb_build_object('sourceHash',source_item->'sourceHash',
   'provider',d.provenance->'provider','model',d.provenance->'translatorModel','reviewerModel',d.provenance->'reviewerModel','generatedAt',d.provenance->'generatedAt',
   'translatorRequestId',d.provenance->'translatorRequestId','reviewerRequestId',d.provenance->'reviewerRequestId',
   'humanReview',human,'reviewedBy',human->'reviewedBy','reviewedAt',human->'reviewedAt'));
  english:=english||jsonb_build_object(k,item->'text');
 end loop;
 return b.settings||jsonb_build_object('siteCopy',translations||jsonb_build_object('en',english),'premiumTranslation',meta||jsonb_build_object('siteCopyEn',machine));
end; $$;

create function premium_translation_private.site_copy_paid_promotion_guard()
returns trigger language plpgsql security definer set search_path='' set timezone='UTC' as $$
declare changed boolean;d public.premium_translation_working_drafts%rowtype;selected public.premium_translation_working_drafts%rowtype;
 a premium_translation_private.catalog_operation_artifacts%rowtype;human jsonb;expected jsonb;k text;matches integer:=0;begin
 if old.settings->>'systemKey' is distinct from 'site-copy-overrides' then return new;end if;
 select exists(select 1 from jsonb_each(case when jsonb_typeof(new.settings#>'{premiumTranslation,siteCopyEn}')='object' then new.settings#>'{premiumTranslation,siteCopyEn}' else '{}'::jsonb end)m
  where m.value#>>'{humanReview,status}'='approved' and(m.value->'humanReview' is distinct from old.settings#>array['premiumTranslation','siteCopyEn',m.key,'humanReview']
   or new.settings#>array['siteCopy','en',m.key] is distinct from old.settings#>array['siteCopy','en',m.key])) into changed;
 if not changed then return new;end if;
 -- Recognize the actual pending pointer by the exact old promotion layout,
 -- not a caller GUC, query text, cache-history guess or UI freshness decision.
 for d in select * from public.premium_translation_working_drafts where entity_type='site_copy' and lower(entity_id)=old.id::text loop
  begin
   k:=d.payload#>>'{items,0,key}';human:=new.settings#>array['premiumTranslation','siteCopyEn',k,'humanReview'];
   expected:=premium_translation_private.site_copy_paid_approval_settings(d,old,human);
   if expected=new.settings then selected:=d;matches:=matches+1;end if;
  exception when invalid_parameter_value or invalid_text_representation or serialization_failure then null;
  end;
 end loop;
 -- Ordinary authored saves/history-shaped restores may change approved text
 -- independently. The actual old promotion always produces its exact pending
 -- layout, so only an ambiguous match is refused before UUID-first linkage.
 if matches=0 then return new;end if;
 if matches>1 then raise exception 'Site Copy approval pending pointer is ambiguous' using errcode='40001';end if;
 -- Actual draft UUID first, with no identity/hash-only legacy downgrade.
 select * into a from premium_translation_private.catalog_operation_artifacts where linked_draft_id=selected.id;
 if a.operation_id is null then return new;end if;
 perform premium_translation_private.assert_actor();
 perform premium_translation_private.site_copy_operation_assert_paid_candidate(selected,old);
 if new.updated_by is distinct from auth.uid()
  or(to_jsonb(new)-array['settings','updated_at','updated_by']) is distinct from(to_jsonb(old)-array['settings','updated_at','updated_by'])
  then
  raise exception 'Site Copy paid approval source/candidate/cache changed' using errcode='40001';end if;
 return new;
end; $$;
create trigger homepage_blocks_site_copy_paid_approval before update of settings on public.homepage_blocks
 for each row execute function premium_translation_private.site_copy_paid_promotion_guard();

create function public.site_copy_translation_operation_ready()
returns boolean language plpgsql stable security definer set search_path='' as $$ declare signature text;begin
 perform premium_translation_private.assert_actor();
 foreach signature in array array[
  'public.begin_site_copy_translation_operation(uuid,uuid,uuid,uuid,text,text,jsonb,jsonb,jsonb,jsonb,jsonb)',
  'public.reconcile_site_copy_translation_operation(uuid)',
  'public.get_site_copy_translation_operation_artifacts(uuid,uuid,uuid,text,text,text)',
  'public.record_site_copy_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text)',
  'public.record_site_copy_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb)',
  'public.finish_site_copy_translation_operation(uuid,uuid,uuid,jsonb,jsonb)',
  'public.get_site_copy_translation_candidate_freshness(text,uuid,bigint,text,text)'] loop
  if to_regprocedure(signature) is null then return false;end if;
 end loop;
 return exists(select 1 from pg_index where indexrelid=to_regclass('public.translation_site_copy_active_operation_unique') and indisunique and indisvalid)
  and(select count(*)=4 from pg_trigger where tgenabled='O' and not tgisinternal and tgname in('catalog_artifacts_site_copy_private_integrity','translation_items_site_copy_integrity','premium_site_copy_linked_candidate_immutable','homepage_blocks_site_copy_paid_approval'))
  and exists(select 1 from pg_trigger where tgrelid='premium_translation_private.catalog_operation_artifacts'::regclass
   and tgname='catalog_artifacts_site_copy_admission_complete' and tgenabled='O' and tgdeferrable and tginitdeferred
   and tgfoid='premium_translation_private.site_copy_operation_cache_commit_guard()'::regprocedure);
end; $$;


-- Shared private proof for the actual CMS OLD row and staff metadata read.
-- Cache lookup starts with the actual pending draft UUID and takes no cache
-- row lock, preserving the existing per-entity/draft/singleton/row order.
create function premium_translation_private.site_copy_operation_assert_paid_candidate(d public.premium_translation_working_drafts,b public.homepage_blocks)
returns void language plpgsql volatile security invoker set search_path='' set timezone='UTC' as $$
declare a premium_translation_private.catalog_operation_artifacts%rowtype;count_blocks integer;begin
 select * into a from premium_translation_private.catalog_operation_artifacts where linked_draft_id=d.id;
 select count(*) into count_blocks from public.homepage_blocks where settings @> '{"systemKey":"site-copy-overrides"}';
 if a.operation_id is null or b.id is null or count_blocks<>1 or b.settings->>'systemKey' is distinct from 'site-copy-overrides'
  or a.entity_type is distinct from 'site_copy' or d.entity_type is distinct from 'site_copy' or a.entity_id is distinct from b.id::text
  or d.entity_id is distinct from a.entity_id or a.final_receipt is null or a.actor_id is distinct from d.created_by
  or a.linked_draft_version is distinct from d.version or a.candidate_hash is distinct from d.candidate_hash
  or a.source_hash is distinct from d.source_hash or a.source_snapshot is distinct from d.source_snapshot
  or a.source_revision is distinct from d.source_revision or a.target_revision is distinct from d.target_revision
  or a.candidate->'payload' is distinct from d.payload or a.candidate->'provenance' is distinct from d.provenance
  or a.final_receipt#>>'{result,persistence}' is distinct from 'working-draft'
  or a.final_receipt#>>'{result,draftId}' is distinct from d.id::text
  or a.final_receipt#>>'{result,draftVersion}' is distinct from d.version::text
  or a.final_receipt#>>'{result,candidateHash}' is distinct from d.candidate_hash
  or to_jsonb(b) is distinct from a.raw_seed->'block' or d.source_snapshot->'settings' is distinct from b.settings
  or (d.target_revision->>'id')::uuid is distinct from b.id or (d.target_revision->>'updatedAt')::timestamptz is distinct from b.updated_at
  or premium_translation_private.site_copy_operation_complete_valid(a,a.candidate) is distinct from true then
  raise exception 'Site Copy paid approval source/candidate/cache changed' using errcode='40001';end if;
end; $$;

-- Metadata only: a fresh staff reviewer may inspect linkage/full-row freshness
-- without obtaining the owner's private response artifacts or expense flags.
create function public.get_site_copy_translation_candidate_freshness(
 p_entity_id text,p_draft_id uuid,p_expected_version bigint,p_candidate_hash text,p_source_hash text)
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' as $$
declare d public.premium_translation_working_drafts%rowtype;b public.homepage_blocks%rowtype;linked boolean;envelope jsonb;begin
 perform premium_translation_private.assert_actor();perform premium_translation_private.assert_identity('site_copy',p_entity_id);
 if not probpera_translation_operations.retry_uuid(p_draft_id) or p_expected_version is null or p_expected_version not between 1 and 9007199254740991
  or coalesce(p_candidate_hash,'')!~'^[a-f0-9]{64}$' or coalesce(p_source_hash,'')!~'^[a-f0-9]{64}$' then
  raise exception 'Invalid Site Copy candidate freshness binding' using errcode='22023';end if;
 envelope:=jsonb_build_object('version',1,'entityType','site_copy','entityId',p_entity_id,'draftId',p_draft_id,'draftVersion',p_expected_version,'candidateHash',p_candidate_hash,'sourceHash',p_source_hash);
 -- Exact legacy entity text remains the old pending/promote identity.
 perform pg_advisory_xact_lock(hashtextextended('premium-translation:site_copy:'||p_entity_id,0));
 select * into d from public.premium_translation_working_drafts where id=p_draft_id for share;
 if d.id is null then return envelope||jsonb_build_object('linked',false,'canPromote',false,'reason','candidate_missing');end if;
 if d.entity_type is distinct from 'site_copy' or d.entity_id is distinct from p_entity_id then
  return envelope||jsonb_build_object('linked',false,'canPromote',false,'reason','candidate_changed');end if;
 select exists(select 1 from premium_translation_private.catalog_operation_artifacts where linked_draft_id=d.id) into linked;
 if d.version is distinct from p_expected_version or d.candidate_hash is distinct from p_candidate_hash or d.source_hash is distinct from p_source_hash then
  return envelope||jsonb_build_object('linked',linked,'canPromote',false,'reason','candidate_changed');end if;
 if not linked then
  return envelope||jsonb_build_object('linked',false,'canPromote',true,'reason',null);end if;
 begin
  perform pg_advisory_xact_lock(188654771,2);
  select * into b from public.homepage_blocks where id=p_entity_id::uuid for update;
  perform premium_translation_private.site_copy_operation_assert_paid_candidate(d,b);
 exception when serialization_failure then
  return envelope||jsonb_build_object('linked',true,'canPromote',false,'reason','source_changed');
 end;
 return envelope||jsonb_build_object('linked',true,'canPromote',true,'reason',null);
end; $$;

revoke all on function premium_translation_private.site_copy_operation_configuration_valid(jsonb,text),
 premium_translation_private.site_copy_operation_progress(jsonb),
 premium_translation_private.site_copy_operation_scope_lock(),
 premium_translation_private.site_copy_operation_source_valid(text,jsonb,jsonb,jsonb,jsonb),
 premium_translation_private.site_copy_operation_capture(text,jsonb),
 premium_translation_private.site_copy_operation_assert_current(premium_translation_private.catalog_operation_artifacts),
 premium_translation_private.site_copy_operation_owned(uuid,uuid,uuid),
 premium_translation_private.site_copy_operation_view(premium_translation_private.catalog_operation_artifacts,boolean,boolean,boolean),
 premium_translation_private.site_copy_operation_complete_valid(premium_translation_private.catalog_operation_artifacts,jsonb),
 premium_translation_private.site_copy_operation_cache_guard(),
 premium_translation_private.site_copy_operation_item_guard(),
 premium_translation_private.site_copy_operation_assert_constructed(uuid),
 premium_translation_private.site_copy_operation_cache_commit_guard(),
 premium_translation_private.site_copy_linked_candidate_update_guard(),
 premium_translation_private.site_copy_paid_approval_settings(public.premium_translation_working_drafts,public.homepage_blocks,jsonb),
 premium_translation_private.site_copy_paid_promotion_guard(),
 premium_translation_private.site_copy_operation_assert_paid_candidate(public.premium_translation_working_drafts,public.homepage_blocks) from public,anon,authenticated,service_role;
revoke all on function public.reconcile_site_copy_translation_operation(uuid),
 public.get_site_copy_translation_operation_artifacts(uuid,uuid,uuid,text,text,text),
 public.begin_site_copy_translation_operation(uuid,uuid,uuid,uuid,text,text,jsonb,jsonb,jsonb,jsonb,jsonb),
 public.record_site_copy_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text),
 public.record_site_copy_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb),
 public.finish_site_copy_translation_operation(uuid,uuid,uuid,jsonb,jsonb),
 public.site_copy_translation_operation_ready(),
 public.get_site_copy_translation_candidate_freshness(text,uuid,bigint,text,text) from public,anon,authenticated,service_role;
grant execute on function public.reconcile_site_copy_translation_operation(uuid),
 public.get_site_copy_translation_operation_artifacts(uuid,uuid,uuid,text,text,text),
 public.begin_site_copy_translation_operation(uuid,uuid,uuid,uuid,text,text,jsonb,jsonb,jsonb,jsonb,jsonb),
 public.record_site_copy_translation_operation_dispatch(uuid,uuid,uuid,uuid,text,text,text,text),
 public.record_site_copy_translation_operation_response(uuid,uuid,uuid,jsonb,jsonb),
 public.finish_site_copy_translation_operation(uuid,uuid,uuid,jsonb,jsonb),
 public.site_copy_translation_operation_ready(),
 public.get_site_copy_translation_candidate_freshness(text,uuid,bigint,text,text) to authenticated;
commit;

-- Owned loopback PostgreSQL17 only; synthetic Auth/CMS/provider artifacts.
-- Run after unchanged native scaffold/old fixtures and the new admission SQL.
-- The wire observer records actual closed RPC inputs/results; it grants no API.
reset role;
set timezone='UTC';
create table public.site_copy_operation_fixture_results(label text primary key,value jsonb not null);
alter table public.site_copy_operation_fixture_results enable row level security;
create policy site_copy_operation_fixture_staff on public.site_copy_operation_fixture_results for all to authenticated using(public.is_staff()) with check(public.is_staff());
grant select,insert,update on public.site_copy_operation_fixture_results to authenticated;
create table public.site_copy_operation_fixture_wire(id uuid primary key default gen_random_uuid(),at_time timestamptz default clock_timestamp(),rpc text,args jsonb,response jsonb);
alter table public.site_copy_operation_fixture_wire enable row level security;
create policy site_copy_operation_wire_staff on public.site_copy_operation_fixture_wire for all to authenticated using(public.is_staff()) with check(public.is_staff());
grant select,insert on public.site_copy_operation_fixture_wire to authenticated;
create function public.site_copy_operation_fixture_call(name text,args jsonb)
returns jsonb language plpgsql set search_path='' as $$ declare r jsonb;begin
 case name
 when 'site_copy_translation_operation_ready' then r:=to_jsonb(public.site_copy_translation_operation_ready());
 when 'begin_site_copy_translation_operation' then r:=public.begin_site_copy_translation_operation((args->>'p_job_id')::uuid,(args->>'p_item_id')::uuid,(args->>'p_operation_id')::uuid,(args->>'p_block_id')::uuid,args->>'p_provider',args->>'p_source_hash',args->'p_source_snapshot',args->'p_source_revision',args->'p_target_revision',args->'p_expected_state',args->'p_configuration');
 when 'reconcile_site_copy_translation_operation' then r:=public.reconcile_site_copy_translation_operation((args->>'p_operation_id')::uuid);
 when 'get_site_copy_translation_operation_artifacts' then r:=public.get_site_copy_translation_operation_artifacts((args->>'p_job_id')::uuid,(args->>'p_item_id')::uuid,(args->>'p_operation_id')::uuid,args->>'p_intent_hash',args->>'p_source_hash',args->>'p_raw_seed_hash');
 when 'record_site_copy_translation_operation_dispatch' then r:=public.record_site_copy_translation_operation_dispatch((args->>'p_job_id')::uuid,(args->>'p_item_id')::uuid,(args->>'p_operation_id')::uuid,(args->>'p_call_id')::uuid,args->>'p_provider',args->>'p_model',args->>'p_pass',args->>'p_request_hash');
 when 'record_site_copy_translation_operation_response' then r:=public.record_site_copy_translation_operation_response((args->>'p_job_id')::uuid,(args->>'p_item_id')::uuid,(args->>'p_operation_id')::uuid,args->'p_metadata',args->'p_response_artifact');
 when 'finish_site_copy_translation_operation' then r:=public.finish_site_copy_translation_operation((args->>'p_job_id')::uuid,(args->>'p_item_id')::uuid,(args->>'p_operation_id')::uuid,args->'p_outcome',nullif(args->'p_candidate','null'::jsonb));
 when 'get_site_copy_translation_candidate_freshness' then r:=public.get_site_copy_translation_candidate_freshness(args->>'p_entity_id',(args->>'p_draft_id')::uuid,(args->>'p_expected_version')::bigint,args->>'p_candidate_hash',args->>'p_source_hash');
 else raise exception 'Unknown Site Copy fixture RPC' using errcode='22023';end case;
 insert into public.site_copy_operation_fixture_wire(rpc,args,response) values(name,args,r);return r;
end; $$;
create function public.site_copy_operation_fixture_seed(review boolean default true)
returns jsonb language plpgsql security definer set search_path='' set timezone='UTC' as $$
declare b public.homepage_blocks%rowtype;identity uuid:=gen_random_uuid();settings jsonb;items jsonb;begin
 delete from public.premium_translation_working_drafts where entity_type='site_copy';
 delete from public.homepage_blocks canonical where canonical.settings->>'systemKey'='site-copy-overrides';
 settings:=public.site_copy_fixture_settings();
 insert into public.homepage_blocks(id,block_type,title,settings,display_order,is_enabled,background_style,background_media_id,updated_by,updated_at)
 values(identity,'text','KEEP AUTHORED TITLE',settings,-17,false,'paper','99999999-9999-4999-8999-999999999999',
  '11111111-1111-4111-8111-111111111111',transaction_timestamp()) returning * into b;
 -- Original semantic hashes are opaque synthetic server inputs, distinct from
 -- the actual full-row native fingerprint. SQL never substitutes JSONB hash.
 items:=jsonb_build_array(jsonb_build_object('key','intro','text',E'Исходный \u2014 текст\r\nс новой строкой','sourceHash',repeat('c',64)),
  jsonb_build_object('key','cta','text','Открыть карту','sourceHash',repeat('d',64)));
 return jsonb_build_object('entityId',b.id,'sourceHash',repeat('b',64),'sourceSnapshot',jsonb_build_object('settings',b.settings,'items',items),
  'sourceRevision',jsonb_build_object('blockId',b.id,'blockUpdatedAt',b.updated_at),'targetRevision',jsonb_build_object('id',b.id,'updatedAt',b.updated_at),
  'expectedState',jsonb_build_object('version',1,'block',jsonb_build_object('id',b.id,'settings',b.settings,'updated_at',b.updated_at)),
  'configuration',public.writer_operation_fixture_config()||jsonb_build_object('schemaName','probpera_site_copy_translation','maxOutputTokens',12000,'twoPassReview',review),
  'payload',jsonb_build_object('items',jsonb_build_array(jsonb_build_object('key','intro','text','Separate English copy awaiting explicit human review.'),jsonb_build_object('key','cta','text','Open the map'))));
end; $$;
create function public.site_copy_operation_fixture_begin_args(a jsonb)
returns jsonb language sql volatile set search_path='' as $$
 select jsonb_build_object('p_job_id',gen_random_uuid(),'p_item_id',gen_random_uuid(),'p_operation_id',gen_random_uuid(),'p_block_id',a->'entityId',
  'p_provider',a#>'{configuration,provider}','p_source_hash',a->'sourceHash','p_source_snapshot',a->'sourceSnapshot','p_source_revision',a->'sourceRevision',
  'p_target_revision',a->'targetRevision','p_expected_state',a->'expectedState','p_configuration',a->'configuration');
$$;
create function public.site_copy_operation_fixture_begin(a jsonb)
returns jsonb language sql set search_path='' as $$ select public.site_copy_operation_fixture_call('begin_site_copy_translation_operation',public.site_copy_operation_fixture_begin_args(a)); $$;
create function public.site_copy_operation_fixture_artifact(r jsonb)
returns jsonb language sql set search_path='' as $$ select public.site_copy_operation_fixture_call('get_site_copy_translation_operation_artifacts',jsonb_build_object(
 'p_job_id',r->'jobId','p_item_id',r->'itemId','p_operation_id',r->'operationId','p_intent_hash',r->'intentHash','p_source_hash',r->'sourceHash','p_raw_seed_hash',r->'rawSeedHash')); $$;
create function public.site_copy_operation_fixture_dispatch_args(r jsonb,pass text)
returns jsonb language sql volatile set search_path='' as $$ select jsonb_build_object('p_job_id',r->'jobId','p_item_id',r->'itemId','p_operation_id',r->'operationId','p_call_id',gen_random_uuid(),
 'p_provider',r->'provider','p_model',case pass when 'translation' then r#>'{configuration,model}' else r#>'{configuration,reviewerModel}' end,'p_pass',pass,'p_request_hash',repeat('e',64)); $$;
create function public.site_copy_operation_fixture_ack(r jsonb,payload jsonb)
returns jsonb language plpgsql set search_path='' as $$ declare calls jsonb;last jsonb;metadata jsonb;begin
 calls:=public.site_copy_operation_fixture_artifact(r)->'calls';last:=calls->(jsonb_array_length(calls)-1)->'metadata';
 metadata:=(last-array['dispatchRecordedAt','responseReceivedAt'])||jsonb_build_object('httpStatus',200,'requestId',null,'responseId','native-site-'||(last->>'pass'),'inputTokens',5,'outputTokens',6);
 return public.site_copy_operation_fixture_call('record_site_copy_translation_operation_response',jsonb_build_object('p_job_id',r->'jobId','p_item_id',r->'itemId','p_operation_id',r->'operationId',
  'p_metadata',metadata,'p_response_artifact',jsonb_build_object('version',1,'body',jsonb_build_object('response',payload::text))));
end; $$;
create function public.site_copy_operation_fixture_pass(r jsonb,pass text,payload jsonb)
returns jsonb language plpgsql set search_path='' as $$ begin return public.site_copy_operation_fixture_ack(public.site_copy_operation_fixture_call('record_site_copy_translation_operation_dispatch',public.site_copy_operation_fixture_dispatch_args(r,pass)),payload);end; $$;
create function public.site_copy_operation_fixture_candidate(r jsonb,payload jsonb)
returns jsonb language plpgsql set search_path='' as $$ declare calls jsonb;first jsonb;last jsonb;n integer;begin
 calls:=public.site_copy_operation_fixture_artifact(r)->'calls';n:=jsonb_array_length(calls);first:=calls->0->'metadata';last:=calls->(n-1)->'metadata';
 return jsonb_build_object('payload',payload,'provenance',jsonb_build_object('provider',r->'provider','translatorModel',first->'model','reviewerModel',case when n=1 then 'null'::jsonb else last->'model' end,
  'translatorRequestId',first->'responseId','reviewerRequestId',case when n=1 then 'null'::jsonb else last->'responseId' end,'generatedAt','2026-10-30T10:00:00.123456Z'),
  'translatorCallId',first->'callId','reviewerCallId',case when n=1 then 'null'::jsonb else last->'callId' end);
end; $$;
create function public.site_copy_operation_fixture_finish(r jsonb,payload jsonb)
returns jsonb language sql set search_path='' as $$ select public.site_copy_operation_fixture_call('finish_site_copy_translation_operation',jsonb_build_object(
 'p_job_id',r->'jobId','p_item_id',r->'itemId','p_operation_id',r->'operationId','p_outcome',jsonb_build_object('status','succeeded','providerCalls',r->'providerCalls','model',r#>'{configuration,model}'),
 'p_candidate',public.site_copy_operation_fixture_candidate(r,payload))); $$;
create function public.site_copy_operation_fixture_free(r jsonb)
returns jsonb language sql set search_path='' as $$ select public.site_copy_operation_fixture_call('finish_site_copy_translation_operation',jsonb_build_object(
 'p_job_id',r->'jobId','p_item_id',r->'itemId','p_operation_id',r->'operationId','p_outcome',jsonb_build_object('status','skipped','providerCalls',0),'p_candidate',null)); $$;
create function public.site_copy_operation_fixture_freshness(d jsonb)
returns jsonb language sql set search_path='' as $$ select public.site_copy_operation_fixture_call('get_site_copy_translation_candidate_freshness',jsonb_build_object(
 'p_entity_id',d->'entityId','p_draft_id',d->'id','p_expected_version',d->'version','p_candidate_hash',d->'candidateHash','p_source_hash',d->'sourceHash')); $$;

-- Exact actual old identities/ACL/RLS/checks remain; new scope is staff-only.
do $$ declare fn record;begin
 set local role anon;
 perform public.premium_fixture_error('select public.site_copy_translation_operation_ready()','42501');reset role;
 set local role authenticated;perform set_config('request.jwt.claim.sub','33333333-3333-4333-8333-333333333333',true);
 perform public.premium_fixture_error('select public.site_copy_translation_operation_ready()','42501');
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 assert public.site_copy_operation_fixture_call('site_copy_translation_operation_ready','{}')='true'::jsonb;
 perform public.premium_fixture_error('select * from premium_translation_private.catalog_operation_artifacts','42501');
 assert public.site_copy_operation_fixture_call('reconcile_site_copy_translation_operation','{"p_operation_id":null}') is null;reset role;
 for fn in select p.oid::regprocedure as signature from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='premium_translation_private' and p.proname like 'site_copy_operation_%' loop
  assert not has_function_privilege('authenticated',fn.signature,'execute') and not has_function_privilege('service_role',fn.signature,'execute');
 end loop;
end; $$;
select 'M07_SITE_COPY_ADMISSION_ACL_PASS';

-- Fully received valid candidate requires explicit human promotion. Native old
-- promotion is exercised through its real entry point and real CMS mutation.
do $$ declare a jsonb;r jsonb;done jsonb;artifact jsonb;draft jsonb;before_row jsonb;promoted jsonb;review boolean;fresh jsonb;foreign_fresh jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach review in array array[false,true] loop
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete deferred;
  a:=public.site_copy_operation_fixture_seed(review);select to_jsonb(b) into before_row from public.homepage_blocks b where id=(a->>'entityId')::uuid;
  set local role authenticated;r:=public.site_copy_operation_fixture_begin(a);assert r->'canExecute'='true'::jsonb;
  reset role;
  set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
  set local role authenticated;
  r:=public.site_copy_operation_fixture_pass(r,'translation',a->'payload');
  if review then r:=public.site_copy_operation_fixture_pass(r,'review',a->'payload');end if;
  done:=public.site_copy_operation_fixture_finish(r,a->'payload');artifact:=public.site_copy_operation_fixture_artifact(done);
  assert done#>>'{result,state}'='translated' and done#>>'{result,persistence}'='working-draft';
  assert artifact->'sourceSnapshot'=a->'sourceSnapshot','retained original semantic source';
  assert artifact#>'{rawSeed,block}'=before_row,'retained entire actual raw seed';
  assert done->>'sourceHash'<>done->>'rawSeedHash','semantic and full raw hashes stay distinct';
  assert (select to_jsonb(b)=before_row from public.homepage_blocks b where id=(a->>'entityId')::uuid);
  draft:=public.get_premium_translation_working_draft('site_copy',a->>'entityId')->'draft';
  perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb,false)',draft),'22023');
  fresh:=public.site_copy_operation_fixture_freshness(draft);assert fresh->'linked'='true'::jsonb and fresh->'canPromote'='true'::jsonb;
  perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
  foreign_fresh:=public.site_copy_operation_fixture_freshness(draft);assert foreign_fresh=fresh;
  perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_artifact(%L::jsonb)',done),'42501');
  set local timezone='Pacific/Kiritimati';
  promoted:=public.site_copy_fixture_promote(draft);assert promoted->>'state'='promoted';reset role;set local timezone='UTC';
  assert (select (to_jsonb(b)-array['settings','updated_at','updated_by'])=(before_row-array['settings','updated_at','updated_by']) from public.homepage_blocks b where id=(a->>'entityId')::uuid);
  assert (select settings#>'{siteCopy,ru}'=before_row#>'{settings,siteCopy,ru}' and settings#>'{siteCopy,fr}'=before_row#>'{settings,siteCopy,fr}'
   and settings#>>'{siteCopy,en,manual}'='Keep authored English' and settings#>>'{siteCopy,en,cta}'='Open the map' from public.homepage_blocks where id=(a->>'entityId')::uuid);
  assert not exists(select 1 from public.premium_translation_working_drafts where id=(draft->>'id')::uuid);
  fresh:=public.site_copy_operation_fixture_freshness(draft);assert fresh->>'reason'='candidate_missing' and fresh->'canPromote'='false'::jsonb;
  insert into public.site_copy_operation_fixture_results values('complete-review-'||review,jsonb_build_object('args',a,'finished',done,'artifact',artifact,'draft',draft,'promotion',promoted,'canonicalBefore',before_row,'crossStaffFreshness',foreign_fresh,'afterPromotionFreshness',fresh));
 end loop;
end; $$;
select 'M07_SITE_COPY_ADMISSION_COMPLETE_AND_NATIVE_PROMOTE_PASS';

-- Confirmed zero-call cleanup has no invented expense and allows a new intent.
do $$ declare a jsonb;r jsonb;done jsonb;args jsonb;again jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);a:=public.site_copy_operation_fixture_seed(false);args:=public.site_copy_operation_fixture_begin_args(a);
 set local role authenticated;r:=public.site_copy_operation_fixture_call('begin_site_copy_translation_operation',args);done:=public.site_copy_operation_fixture_free(r);
 again:=public.site_copy_operation_fixture_call('begin_site_copy_translation_operation',args);assert again->'replayed'='true'::jsonb and again->'canExecute'='false'::jsonb;
 assert done#>>'{result,persistence}'='none' and done->'providerCalls'='0'::jsonb;reset role;
 assert (select model is null and provider_request_id is null and input_tokens is null and output_tokens is null and duration_ms is null from public.translation_job_attempts where staff_retry_operation_id=(r->>'operationId')::uuid);
 insert into public.site_copy_operation_fixture_results values('zero-call-cleanup',jsonb_build_object('args',a,'begin',r,'finished',done,'replay',again));
end; $$;
select 'M07_SITE_COPY_ADMISSION_ZERO_CALL_PASS';

-- A synthetic transaction can roll back retained paid artifacts without a
-- DELETE bypass. Observed actual RPC records survive only as fixture evidence.
do $$ declare a jsonb;replacement jsonb;r jsonb;pending jsonb;blocked jsonb;late jsonb;artifact jsonb;args jsonb;
 before_wire uuid[];observed jsonb;trace jsonb;cancel jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 select coalesce(array_agg(id),'{}'::uuid[]) into before_wire from public.site_copy_operation_fixture_wire;
 begin
  a:=public.site_copy_operation_fixture_seed(true);set local role authenticated;r:=public.site_copy_operation_fixture_begin(a);
  pending:=public.site_copy_operation_fixture_call('record_site_copy_translation_operation_dispatch',public.site_copy_operation_fixture_dispatch_args(r,'translation'));
  blocked:=public.site_copy_operation_fixture_call('reconcile_site_copy_translation_operation',jsonb_build_object('p_operation_id',r->'operationId'));
  assert blocked->>'blockReason'='provider_outcome_unknown' and blocked->'canExecute'='false'::jsonb and blocked->'canDispatch'='false'::jsonb;
  perform public.premium_fixture_error(format('select public.finish_site_copy_translation_operation(%L,%L,%L,%L::jsonb,null)',r->>'jobId',r->>'itemId',r->>'operationId',
   jsonb_build_object('status','dead_letter','providerCalls',1)),'40001');
  reset role;replacement:=public.site_copy_operation_fixture_seed(false);args:=public.site_copy_operation_fixture_begin_args(replacement);
  args:=jsonb_set(args,'{p_configuration,model}','"changed-current-model"');
  set local role authenticated;blocked:=public.site_copy_operation_fixture_call('begin_site_copy_translation_operation',args);
  assert blocked->>'operationId'=r->>'operationId' and blocked->>'entityId'=a->>'entityId' and blocked->>'blockReason'='provider_outcome_unknown';
  perform set_config('request.jwt.claim.sub','22222222-2222-4222-8222-222222222222',true);
  blocked:=public.site_copy_operation_fixture_call('reconcile_site_copy_translation_operation',jsonb_build_object('p_operation_id',r->'operationId'));
  assert blocked->>'blockReason'='operation_owned_by_another_actor';
  perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_artifact(%L::jsonb)',r),'42501');
  perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
  cancel:=public.request_translation_job_cancel((r->>'jobId')::uuid,(r->>'jobVersion')::bigint);
  late:=public.site_copy_operation_fixture_ack(pending,a->'payload');artifact:=public.site_copy_operation_fixture_artifact(late);
  assert late->>'blockReason'='operation_stopped' and late->'providerCalls'='1'::jsonb and late->'pendingCallId'='null'::jsonb;
  assert artifact#>'{calls,0,responseArtifact,body}'=jsonb_build_object('response',(a->'payload')::text) and artifact->'sourceSnapshot'=a->'sourceSnapshot';
  assert artifact#>>'{rawSeed,block,id}'=a->>'entityId' and artifact#>>'{rawSeed,block,id}'<>replacement->>'entityId';
  perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','record_site_copy_translation_operation_dispatch',public.site_copy_operation_fixture_dispatch_args(r,'review')),'40001');
  perform public.premium_fixture_error(format('select public.finish_site_copy_translation_operation(%L,%L,%L,%L::jsonb,null)',r->>'jobId',r->>'itemId',r->>'operationId',
   jsonb_build_object('status','dead_letter','providerCalls',1)),'40001');
  reset role;set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
  select coalesce(jsonb_agg(to_jsonb(w) order by at_time,id),'[]'::jsonb) into trace from public.site_copy_operation_fixture_wire w where not(w.id=any(before_wire));
  observed:=jsonb_build_object('args',a,'replacement',replacement,'pending',pending,'blocked',blocked,'cancel',cancel,'late',late,'artifact',artifact,'observedWire',trace,
   'constantLogicalScopeHeld',true,'privateActorDenied',true,'lateBodyAfterCancelRetained',true,'partialNoTerminalRetry',true);
  raise exception 'Rollback synthetic retained paid state' using errcode='ZX001';
 exception when sqlstate 'ZX001' then null;end;
 assert observed is not null and not exists(select 1 from premium_translation_private.catalog_operation_artifacts where operation_id=(r->>'operationId')::uuid);
 insert into public.site_copy_operation_fixture_results values('unknown-scope-recreate-cancel-late-body',observed);
end; $$;
select 'M07_SITE_COPY_ADMISSION_UNKNOWN_CANCEL_RECREATE_PASS';

-- Construct a new private proof from actual zero-call native rows. This is a
-- fixture owner forgery input, never a production admission path or bypass.
create function public.site_copy_operation_fixture_forge(a premium_translation_private.catalog_operation_artifacts,patch jsonb default '{}')
returns premium_translation_private.catalog_operation_artifacts language plpgsql security definer set search_path='' set timezone='UTC' as $$
declare j public.translation_jobs%rowtype;i public.translation_job_items%rowtype;marker jsonb;begin
 a:=jsonb_populate_record(a,patch);a.operation_id:=gen_random_uuid();a.job_id:=gen_random_uuid();a.item_id:=gen_random_uuid();
 a.calls:='[]';a.candidate:=null;a.final_receipt:=null;a.finish_fingerprint:=null;a.linked_draft_id:=null;a.linked_draft_version:=null;a.candidate_hash:=null;a.attempt_write_proof:=null;
 a.raw_seed_hash:=probpera_translation_operations.retry_fingerprint(a.raw_seed);a.configuration_hash:=probpera_translation_operations.retry_fingerprint(a.configuration);
 a.begin_request_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(a.job_id,a.item_id,a.operation_id,a.actor_id,a.entity_id,a.provider,a.source_hash,
  a.source_snapshot,a.source_revision,a.target_revision,a.expected_state,a.configuration));
 a.intent_hash:=probpera_translation_operations.retry_fingerprint(jsonb_build_array(a.begin_request_hash,a.raw_seed_hash));
 marker:=jsonb_build_object('version',1,'protocol','site-copy-translation','logicalScope','site-copy-overrides','operationId',a.operation_id,'actorId',a.actor_id,
  'sourceHash',a.source_hash,'intentHash',a.intent_hash,'rawSeedHash',a.raw_seed_hash,'configurationHash',a.configuration_hash,'startedAt',a.created_at,'attemptNumber',1,
  'progress',jsonb_build_object('version',1,'updatedAt',a.created_at,'calls','[]'::jsonb));
 j:=jsonb_populate_record(null::public.translation_jobs,a.job_write_proof||jsonb_build_object('id',a.job_id,'kind','site_copy','provider',a.provider,'requested_by',a.actor_id,
  'status','reviewing','version',1,'succeeded_items',0,'failed_items',0,'cancel_requested_at',null,'completed_at',null,
  'resume_cursor',jsonb_build_object('siteCopyOperation',jsonb_build_object('version',1,'logicalScope','site-copy-overrides','operationId',a.operation_id,'actorId',a.actor_id,'intentHash',a.intent_hash))));
 i:=jsonb_populate_record(null::public.translation_job_items,a.item_write_proof||jsonb_build_object('id',a.item_id,'job_id',a.job_id,'entity_type','site_copy','entity_id',a.entity_id,
  'source_hash',a.source_hash,'status','reviewing','attempt_count',0,'staff_retry',marker,'last_error_code',null));
 a.job_write_proof:=to_jsonb(j);a.item_write_proof:=to_jsonb(i);return a;
end; $$;

do $$ declare mode text;args jsonb;r jsonb;a premium_translation_private.catalog_operation_artifacts%rowtype;
 forged premium_translation_private.catalog_operation_artifacts%rowtype;j public.translation_jobs%rowtype;i public.translation_job_items%rowtype;
 rejected boolean;actual_code text;actual_message text;matrix jsonb:='[]';begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach mode in array array['missing-job-and-item','missing-item','preexisting-free-job-item','wrong-actual-job-kind','wrong-actual-job-provider','wrong-actual-job-actor','wrong-actual-item-source','missing-json-proof','wrong-intent-proof','forged-full-server-row'] loop
  rejected:=false;actual_code:=null;actual_message:=null;
  begin
   args:=public.site_copy_operation_fixture_seed(false);set local role authenticated;r:=public.site_copy_operation_fixture_begin(args);reset role;
   select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=(r->>'operationId')::uuid;
   forged:=public.site_copy_operation_fixture_forge(a);
   if mode='forged-full-server-row' then
    forged:=public.site_copy_operation_fixture_forge(a,jsonb_build_object('raw_seed',jsonb_set(a.raw_seed,'{block,title}','"FORGED RAW TITLE"')));
   end if;
   j:=jsonb_populate_record(null::public.translation_jobs,forged.job_write_proof);
   i:=jsonb_populate_record(null::public.translation_job_items,forged.item_write_proof);
   if mode in('preexisting-free-job-item','wrong-actual-job-kind','wrong-actual-job-provider','wrong-actual-job-actor','wrong-actual-item-source') then
    if mode='wrong-actual-job-kind' then j.kind:='country';end if;
    if mode='wrong-actual-job-provider' then j.provider:='openai';end if;
    if mode='wrong-actual-job-actor' then j.requested_by:='22222222-2222-4222-8222-222222222222';end if;
    i.staff_retry:=null;if mode='wrong-actual-item-source' then i.source_hash:=repeat('f',64);end if;
    insert into public.translation_jobs select j.*;insert into public.translation_job_items select i.*;
   end if;
   if mode='missing-json-proof' then forged.item_write_proof:=forged.item_write_proof-'id';end if;
   if mode='wrong-intent-proof' then forged.intent_hash:=repeat('f',64);end if;
   insert into premium_translation_private.catalog_operation_artifacts select forged.*;
   if mode='missing-item' then insert into public.translation_jobs select j.*;end if;
   set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
  exception when insufficient_privilege then
   rejected:=true;actual_code:=sqlstate;actual_message:=sqlerrm;
   when serialization_failure then
    if mode<>'forged-full-server-row' then raise;end if;rejected:=true;actual_code:=sqlstate;actual_message:=sqlerrm;
  end;
  assert rejected,'forged construction committed: '||mode;
  assert not exists(select 1 from premium_translation_private.catalog_operation_artifacts where operation_id=forged.operation_id);
  assert not exists(select 1 from public.translation_jobs where id=forged.job_id);
  assert not exists(select 1 from public.translation_job_items where id=forged.item_id);
  matrix:=matrix||jsonb_build_array(jsonb_build_object('case',mode,'databaseCode',actual_code,'message',actual_message,'allNewRowsRolledBack',true));
 end loop;
 insert into public.site_copy_operation_fixture_results values('reverse-construction-forgeries',matrix);
end; $$;
select 'M07_SITE_COPY_ADMISSION_REVERSE_CONSTRUCTION_FORGERIES_PASS';



-- An ordinary guarded manual/history-shaped save remains possible while a new
-- paid candidate waits. Actual paid promotion still rechecks the whole OLD row,
-- even when a non-settings edit shares the exact same transaction-time CAS.
do $$ declare a jsonb;r jsonb;done jsonb;d jsonb;fresh jsonb;settings jsonb;payload jsonb;saved uuid;legacy jsonb;upper_id text;
 original_draft public.premium_translation_working_drafts%rowtype;b public.homepage_blocks%rowtype;
 before_wire uuid[];observed jsonb;trace jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 select coalesce(array_agg(id),'{}'::uuid[]) into before_wire from public.site_copy_operation_fixture_wire;
 begin
  a:=public.site_copy_operation_fixture_seed(false);set local role authenticated;r:=public.site_copy_operation_fixture_begin(a);
  r:=public.site_copy_operation_fixture_pass(r,'translation',a->'payload');done:=public.site_copy_operation_fixture_finish(r,a->'payload');
  d:=public.get_premium_translation_working_draft('site_copy',a->>'entityId')->'draft';reset role;
  select * into original_draft from public.premium_translation_working_drafts where id=(d->>'id')::uuid;
  perform public.premium_fixture_error(format('update public.premium_translation_working_drafts set payload=%L::jsonb where id=%L','{"items":[]}',d->>'id'),'42501');
  perform public.premium_fixture_error(format('update public.premium_translation_working_drafts set version=version+1 where id=%L',d->>'id'),'42501');
  perform public.premium_fixture_error(format('update public.premium_translation_working_drafts set id=gen_random_uuid() where id=%L',d->>'id'),'42501');
  update public.homepage_blocks set title=title||' RAW NONSETTINGS DRIFT' where id=(a->>'entityId')::uuid;
  select * into b from public.homepage_blocks where id=(a->>'entityId')::uuid;
  assert b.settings=a#>'{sourceSnapshot,settings}' and b.updated_at=(a#>>'{targetRevision,updatedAt}')::timestamptz,'same-CAS full-row drift is genuine';
  set local role authenticated;fresh:=public.site_copy_operation_fixture_freshness(d);
  assert fresh->'linked'='true'::jsonb and fresh->'canPromote'='false'::jsonb and fresh->>'reason'='source_changed';
  perform public.premium_fixture_error(format('select public.site_copy_fixture_promote(%L::jsonb)',d),'40001');reset role;
  settings:=jsonb_set(b.settings,'{siteCopy,en,intro}','"Historical approved English restored by a human"');
  settings:=jsonb_set(settings,'{premiumTranslation,siteCopyEn,intro,humanReview}',jsonb_build_object('status','approved','reviewedBy','11111111-1111-4111-8111-111111111111','reviewedAt','2026-10-01T10:00:00.123456Z'));
  payload:=jsonb_build_object('block_type','text','title',b.title,'settings',settings,'display_order',b.display_order,'is_enabled',b.is_enabled,
   'background_style',b.background_style,'background_media_id',b.background_media_id);
  set local role authenticated;saved:=public.save_site_copy_block(b.updated_at,payload,'{"nativeManualRestore":true}');
  assert saved=b.id and public.get_premium_translation_working_draft('site_copy',a->>'entityId')->'draft'=d;
  saved:=public.save_site_copy_block(b.updated_at,jsonb_set(payload,'{settings,premiumTranslation,siteCopyEn,intro,humanReview,reviewedBy}','"raw-manual-attribution"'),'{"nativeManualMetadata":true}');
  assert (select canonical.settings#>>'{premiumTranslation,siteCopyEn,intro,humanReview,reviewedBy}'='raw-manual-attribution' from public.homepage_blocks canonical where canonical.id=b.id),'ordinary raw human metadata is preserved';
  assert public.site_copy_operation_fixture_artifact(done)#>'{candidate,payload}'=a->'payload';
  perform public.premium_fixture_discard(d);reset role;
  assert not exists(select 1 from public.premium_translation_working_drafts where id=original_draft.id);
  begin insert into public.premium_translation_working_drafts select original_draft.*;raise exception 'Historical UUID reused' using errcode='ZX002';
  exception when insufficient_privilege then null;end;
  -- A new actual unlinked legacy UUID is not misidentified by cache history or
  -- source/candidate hashes, and its exact textual UUID case is preserved.
  select * into b from public.homepage_blocks where id=(a->>'entityId')::uuid;upper_id:=upper(b.id::text);
  set local role authenticated;
  legacy:=public.stage_premium_translation_working_draft('site_copy',upper_id,a->>'sourceHash',jsonb_build_object('settings',b.settings,'items',a#>'{sourceSnapshot,items}'),
   jsonb_build_object('blockId',upper_id,'blockUpdatedAt',b.updated_at),jsonb_build_object('id',upper_id,'updatedAt',b.updated_at),a->'payload',
   jsonb_build_object('provider','cloudflare','translatorModel','fixture-translator','reviewerModel',null,'translatorRequestId','legacy-native','reviewerRequestId',null,'generatedAt','2026-10-01T10:00:00.123456Z'),null,0)->'draft';
  fresh:=public.site_copy_operation_fixture_freshness(legacy);assert fresh->'linked'='false'::jsonb and fresh->'canPromote'='true'::jsonb and fresh->'reason'='null'::jsonb;
  reset role;
  begin
   update public.premium_translation_working_drafts set id=original_draft.id where id=(legacy->>'id')::uuid;
   raise exception 'Legacy renamed into consumed paid UUID' using errcode='ZX002';
  exception when insufficient_privilege then assert sqlerrm='Consumed Site Copy candidate UUID cannot be reused';end;
  set local role authenticated;
  fresh:=public.site_copy_operation_fixture_freshness(jsonb_set(legacy,'{entityId}',to_jsonb(lower(upper_id))));
  assert fresh->>'reason'='candidate_changed' and fresh->'canPromote'='false'::jsonb;
  assert public.site_copy_fixture_promote(legacy)->>'state'='promoted';
  assert public.site_copy_operation_fixture_artifact(done)#>'{candidate,payload}'=a->'payload';
  reset role;set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
  select coalesce(jsonb_agg(to_jsonb(w) order by at_time,id),'[]'::jsonb) into trace from public.site_copy_operation_fixture_wire w where not(w.id=any(before_wire));
  observed:=jsonb_build_object('sameCasFullRowStaleDenied',true,'manualRestorePayload',payload,'manualSaveAllowed',true,'paidPreviewDiscardPreserved',true,
   'historicalPaidUuidReuseDenied',true,'legacyNewUuidAndTextCasePreserved',true,'oldPaidBodyRetained',true,'malformedManualMetadataPreserved',true,'observedWire',trace);
  raise exception 'Rollback synthetic review state' using errcode='ZX001';
 exception when sqlstate 'ZX001' then null;end;
 assert observed is not null;
 insert into public.site_copy_operation_fixture_results values('paid-fullrow-manual-restore-discard-legacy',observed);
end; $$;
select 'M07_SITE_COPY_ADMISSION_FULLROW_MANUAL_RESTORE_LEGACY_PASS';

-- Actual unchanged revision capture and staff history-shaped restore of an
-- ordinary block remain available. Direct system Site Copy UPDATE stays denied
-- by the old restrictive policy; the guarded save above is the allowed path.
do $$ declare ordinary uuid:=gen_random_uuid();snapshot jsonb;changed public.homepage_blocks%rowtype;rows_changed integer;observed jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 begin
  set local role authenticated;
  insert into public.homepage_blocks(id,block_type,title,settings,display_order,is_enabled,background_style,updated_by)
   values(ordinary,'text','Original ordinary authored title','{"ordinaryRaw":{"rights":"KEEP"}}',7,true,'paper','11111111-1111-4111-8111-111111111111');
  update public.homepage_blocks set title='Changed ordinary title',settings='{"ordinaryRaw":{"rights":"CHANGED"}}' where id=ordinary;
  reset role;
  -- The selected bare-PG foundation does not model managed default table
  -- grants. The fixture owner reads the actual captured old revision; the
  -- real staff role performs the exact ordinary CAS restore mutation below.
  select r.snapshot into snapshot from public.homepage_block_revisions r where homepage_block_id=ordinary order by revision_number desc limit 1;
  select * into changed from public.homepage_blocks where id=ordinary;
  set local role authenticated;
  update public.homepage_blocks set title=snapshot->>'title',settings=snapshot->'settings',display_order=(snapshot->>'display_order')::integer,
   is_enabled=(snapshot->>'is_enabled')::boolean,background_style=snapshot->>'background_style',updated_by='11111111-1111-4111-8111-111111111111'
   where id=ordinary and updated_at=changed.updated_at;
  get diagnostics rows_changed=row_count;assert rows_changed=1;
  assert (select title='Original ordinary authored title' and settings=snapshot->'settings' from public.homepage_blocks where id=ordinary);
  reset role;assert (select count(*)=2 from public.homepage_block_revisions where homepage_block_id=ordinary);set local role authenticated;
  update public.homepage_blocks set title='Unpermitted direct system restore' where settings->>'systemKey'='site-copy-overrides';
  get diagnostics rows_changed=row_count;assert rows_changed=0;
  reset role;observed:=jsonb_build_object('ordinaryHistoryShapedStaffMutationAllowed',true,'actualOldCaptureRevisions',2,'historySnapshotReadByFixtureOwner',true,
   'managedDefaultTableGrantsNotModeled',true,'directSystemRestoreOldRlsDenied',true,'providerCalls',0);
  raise exception 'Rollback synthetic ordinary restore' using errcode='ZX001';
 exception when sqlstate 'ZX001' then null;end;
 assert observed is not null;insert into public.site_copy_operation_fixture_results values('ordinary-history-restore-and-old-system-policy',observed);
end; $$;
select 'M07_SITE_COPY_ADMISSION_OLD_HISTORY_SHAPED_MUTATION_PASS';



do $$ declare a jsonb;args jsonb;bad jsonb;r jsonb;done jsonb;existing uuid;before_counts jsonb;after_counts jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);a:=public.site_copy_operation_fixture_seed(false);args:=public.site_copy_operation_fixture_begin_args(a);
 select id into existing from public.translation_jobs where kind<>'site_copy' limit 1;assert existing is not null;
 bad:=jsonb_set(args,'{p_job_id}',to_jsonb(existing));set local role authenticated;
 perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','begin_site_copy_translation_operation',bad),'40001');reset role;
 select id into existing from public.translation_job_items where entity_type<>'site_copy' limit 1;assert existing is not null;
 bad:=jsonb_set(args,'{p_item_id}',to_jsonb(existing));set local role authenticated;
 perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','begin_site_copy_translation_operation',bad),'40001');reset role;
 select operation_id into existing from premium_translation_private.writer_operation_artifacts limit 1;assert existing is not null;
 bad:=jsonb_set(args,'{p_operation_id}',to_jsonb(existing));set local role authenticated;
 perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','begin_site_copy_translation_operation',bad),'40001');reset role;
 select operation_id into existing from premium_translation_private.catalog_operation_artifacts where entity_type in('literary_work','country') limit 1;assert existing is not null;
 bad:=jsonb_set(args,'{p_operation_id}',to_jsonb(existing));set local role authenticated;
 perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','begin_site_copy_translation_operation',bad),'42501');reset role;
 before_counts:=jsonb_build_array((select count(*) from premium_translation_private.catalog_operation_artifacts),(select count(*) from public.translation_jobs),(select count(*) from public.translation_job_items));
 set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
 set local role authenticated;
 perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','begin_site_copy_translation_operation',args),'42501');reset role;
 after_counts:=jsonb_build_array((select count(*) from premium_translation_private.catalog_operation_artifacts),(select count(*) from public.translation_jobs),(select count(*) from public.translation_job_items));
 assert before_counts=after_counts,'immediate incomplete construction rolled back all new rows';
 set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete deferred;
 set local role authenticated;r:=public.site_copy_operation_fixture_call('begin_site_copy_translation_operation',args);reset role;
 set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
 set local role authenticated;done:=public.site_copy_operation_fixture_free(r);reset role;
 perform premium_translation_private.site_copy_operation_assert_constructed((r->>'operationId')::uuid);
 insert into public.site_copy_operation_fixture_results values('occupied-ids-and-manual-constraint-modes',jsonb_build_object('unrelatedJobDenied',true,'unrelatedItemDenied',true,
  'writerOperationUuidDenied',true,'catalogDomainUuidDenied',true,'immediateBeforeIncompleteRefused',true,'allNewRowsRolledBack',true,'immediateAfterCompletePassed',true,'finalActualAttemptProofPassed',true));
end; $$;
select 'M07_SITE_COPY_ADMISSION_IDS_SET_IMMEDIATE_PASS';

-- A forged zero-call terminal private receipt cannot omit its actual attempt,
-- even when real job/item writes exactly match its forged write projections.
do $$ declare args jsonb;r jsonb;done jsonb;a premium_translation_private.catalog_operation_artifacts%rowtype;
 forged premium_translation_private.catalog_operation_artifacts%rowtype;terminal premium_translation_private.catalog_operation_artifacts%rowtype;
 j public.translation_jobs%rowtype;i public.translation_job_items%rowtype;t public.translation_job_attempts%rowtype;
 rejected boolean:=false;actual_message text;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 begin
  args:=public.site_copy_operation_fixture_seed(false);set local role authenticated;r:=public.site_copy_operation_fixture_begin(args);done:=public.site_copy_operation_fixture_free(r);reset role;
  select * into a from premium_translation_private.catalog_operation_artifacts where operation_id=(r->>'operationId')::uuid;
  forged:=public.site_copy_operation_fixture_forge(a);j:=jsonb_populate_record(null::public.translation_jobs,forged.job_write_proof);i:=jsonb_populate_record(null::public.translation_job_items,forged.item_write_proof);
  insert into premium_translation_private.catalog_operation_artifacts select forged.*;insert into public.translation_jobs select j.*;insert into public.translation_job_items select i.*;
  terminal:=forged;terminal.finish_fingerprint:=a.finish_fingerprint;
  terminal.final_receipt:=a.final_receipt||jsonb_build_object('jobId',forged.job_id,'itemId',forged.item_id,'operationId',forged.operation_id,'intentHash',forged.intent_hash);
  j:=jsonb_populate_record(null::public.translation_jobs,a.job_write_proof||jsonb_build_object('id',forged.job_id,'resume_cursor',forged.job_write_proof->'resume_cursor'));
  i:=jsonb_populate_record(null::public.translation_job_items,a.item_write_proof||jsonb_build_object('id',forged.item_id,'job_id',forged.job_id));
  t:=jsonb_populate_record(null::public.translation_job_attempts,a.attempt_write_proof||jsonb_build_object('id',nextval('public.translation_job_attempts_id_seq'),'item_id',forged.item_id,
   'staff_retry_operation_id',forged.operation_id,'staff_retry_receipt',(a.attempt_write_proof->'staff_retry_receipt')||jsonb_build_object('intentHash',forged.intent_hash,'receipt',terminal.final_receipt)));
  terminal.job_write_proof:=to_jsonb(j);terminal.item_write_proof:=to_jsonb(i);terminal.attempt_write_proof:=to_jsonb(t);
  update premium_translation_private.catalog_operation_artifacts set final_receipt=terminal.final_receipt,finish_fingerprint=terminal.finish_fingerprint,
   job_write_proof=terminal.job_write_proof,item_write_proof=terminal.item_write_proof,attempt_write_proof=terminal.attempt_write_proof where operation_id=forged.operation_id;
  update public.translation_jobs set status=j.status,version=j.version,completed_at=j.completed_at,updated_at=j.updated_at,resume_cursor=j.resume_cursor where id=forged.job_id;
  update public.translation_job_items set status=i.status,attempt_count=i.attempt_count,staff_retry=null,updated_at=i.updated_at,last_error_code=i.last_error_code where id=forged.item_id;
  -- Intentionally omit the real translation_job_attempts INSERT.
  set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
 exception when insufficient_privilege then rejected:=true;actual_message:=sqlerrm;end;
 assert rejected and actual_message='Site Copy completed admission actual attempt differs','reverse proof must reach missing actual terminal attempt';
 assert not exists(select 1 from premium_translation_private.catalog_operation_artifacts where operation_id=forged.operation_id);
 assert not exists(select 1 from public.translation_jobs where id=forged.job_id);
 insert into public.site_copy_operation_fixture_results values('missing-real-terminal-attempt',jsonb_build_object('rejected',true,'databaseCode','42501','message',actual_message,'allConstructionRolledBack',true));
end; $$;
select 'M07_SITE_COPY_ADMISSION_REAL_TERMINAL_ATTEMPT_PASS';

-- Readiness covers the whole increment. Missing metadata freshness closes new
-- expense capability while original private artifact GET remains owner-readable.
do $$ declare r jsonb;artifact jsonb;before_wire uuid[];trace jsonb;observed jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 select coalesce(array_agg(id),'{}'::uuid[]) into before_wire from public.site_copy_operation_fixture_wire;
 begin
  drop function public.get_site_copy_translation_candidate_freshness(text,uuid,bigint,text,text);
  set local role authenticated;
  assert public.site_copy_operation_fixture_call('site_copy_translation_operation_ready','{}')='false'::jsonb;
  r:=public.site_copy_operation_fixture_call('reconcile_site_copy_translation_operation','{"p_operation_id":null}');
  artifact:=public.site_copy_operation_fixture_artifact(r);assert artifact#>>'{receipt,operationId}'=r->>'operationId';reset role;
  select coalesce(jsonb_agg(to_jsonb(w) order by at_time,id),'[]'::jsonb) into trace from public.site_copy_operation_fixture_wire w where not(w.id=any(before_wire));
  observed:=jsonb_build_object('missingFreshnessReadyFalse',true,'ownerArtifactStillReadable',true,'observedWire',trace);
  raise exception 'Rollback only new reader capability removal' using errcode='ZX001';
 exception when sqlstate 'ZX001' then null;end;
 set local role authenticated;assert public.site_copy_operation_fixture_call('site_copy_translation_operation_ready','{}')='true'::jsonb;reset role;
 assert observed is not null;insert into public.site_copy_operation_fixture_results values('missing-freshness-capability-restored',observed);
end; $$;
select 'M07_SITE_COPY_ADMISSION_READINESS_FULL_INCREMENT_PASS';

-- Every existing configured translation/repair/review sequence keeps its
-- original models and one-attempt/four-reservation cap for both providers.
do $$ declare sequence text;passes text[];pass text;a jsonb;r jsonb;done jsonb;review boolean;mode text;count_calls integer;observed jsonb:='[]';begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 foreach sequence in array array['translation,repair','translation,repair,review','translation,review,repair','translation,repair,review,repair'] loop
  set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete deferred;
  review:=position('review' in sequence)>0;a:=public.site_copy_operation_fixture_seed(review);
  mode:=case when review then 'openai' else 'cloudflare' end;a:=jsonb_set(a,'{configuration,provider}',to_jsonb(mode));
  set local role authenticated;r:=public.site_copy_operation_fixture_begin(a);
  perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','record_site_copy_translation_operation_dispatch',public.site_copy_operation_fixture_dispatch_args(r,'review')),case when review then '40001' else '22023' end);
  passes:=string_to_array(sequence,',');count_calls:=0;
  foreach pass in array passes loop r:=public.site_copy_operation_fixture_pass(r,pass,a->'payload');count_calls:=count_calls+1;end loop;
  assert (r->>'providerCalls')::integer=count_calls;
  if count_calls=4 then
   perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','record_site_copy_translation_operation_dispatch',public.site_copy_operation_fixture_dispatch_args(r,'repair')),'40001');
  elsif not review then
   perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','record_site_copy_translation_operation_dispatch',public.site_copy_operation_fixture_dispatch_args(r,'repair')),'22023');
  end if;
  done:=public.site_copy_operation_fixture_finish(r,a->'payload');assert done#>>'{result,state}'='translated';reset role;
  set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
  observed:=observed||jsonb_build_array(jsonb_build_object('sequence',sequence,'provider',mode,'providerCalls',count_calls,'finished',done));
 end loop;
 insert into public.site_copy_operation_fixture_results values('configured-repairs-and-reservation-caps',observed);
end; $$;
select 'M07_SITE_COPY_ADMISSION_REPAIR_POLICY_CAPS_PASS';







-- Confirmed partial output before the real original deadline stays retained.
-- The elapsed wait uses the actual server clock; no changed clock function,
-- GUC deadline, cache rewrite, or expired-operation restart is used.
do $$ declare a jsonb;r jsonb;partial jsonb;blocked jsonb;artifact jsonb;before_wire uuid[];observed jsonb;trace jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 select coalesce(array_agg(id),'{}'::uuid[]) into before_wire from public.site_copy_operation_fixture_wire;
 begin
  a:=public.site_copy_operation_fixture_seed(true);set local role authenticated;r:=public.site_copy_operation_fixture_begin(a);
  partial:=public.site_copy_operation_fixture_pass(r,'translation',a->'payload');artifact:=public.site_copy_operation_fixture_artifact(partial);
  assert partial->>'phase'='running' and partial->'pendingCallId'='null'::jsonb and partial->'providerCalls'='1'::jsonb;
  perform pg_sleep(45.1);
  blocked:=public.site_copy_operation_fixture_call('reconcile_site_copy_translation_operation',jsonb_build_object('p_operation_id',r->'operationId'));
  assert blocked->>'blockReason'='operation_deadline' and blocked->'canExecute'='false'::jsonb and blocked->'canDispatch'='false'::jsonb;
  perform public.premium_fixture_error(format('select public.site_copy_operation_fixture_call(%L,%L::jsonb)','record_site_copy_translation_operation_dispatch',public.site_copy_operation_fixture_dispatch_args(r,'review')),'40001');
  perform public.premium_fixture_error(format('select public.finish_site_copy_translation_operation(%L,%L,%L,%L::jsonb,null)',r->>'jobId',r->>'itemId',r->>'operationId',jsonb_build_object('status','dead_letter','providerCalls',1)),'40001');
  blocked:=public.site_copy_operation_fixture_call('begin_site_copy_translation_operation',public.site_copy_operation_fixture_begin_args(a));
  assert blocked->>'operationId'=r->>'operationId' and blocked->>'blockReason'='operation_deadline';
  assert (public.site_copy_operation_fixture_artifact(blocked)->'calls')=artifact->'calls';
  reset role;set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
  select coalesce(jsonb_agg(to_jsonb(w) order by at_time,id),'[]'::jsonb) into trace from public.site_copy_operation_fixture_wire w where not(w.id=any(before_wire));
  observed:=jsonb_build_object('beforeDeadline',partial,'afterDeadline',blocked,'artifact',artifact,'observedWire',trace,'realElapsedDeadline',true,'noReviewerStarted',true);
  raise exception 'Rollback synthetic partial state' using errcode='ZX001';
 exception when sqlstate 'ZX001' then null;end;
 assert observed is not null;
 insert into public.site_copy_operation_fixture_results values('confirmed-partial-real-deadline',observed);
end; $$;
select 'M07_SITE_COPY_ADMISSION_PARTIAL_REAL_DEADLINE_PASS';

-- A first body arriving after the actual original deadline is still retained.
-- Finishing its already complete optional-review sequence costs no new call.
do $$ declare a jsonb;r jsonb;pending jsonb;late jsonb;done jsonb;artifact jsonb;before_wire uuid[];observed jsonb;trace jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 select coalesce(array_agg(id),'{}'::uuid[]) into before_wire from public.site_copy_operation_fixture_wire;
 begin
  a:=public.site_copy_operation_fixture_seed(false);set local role authenticated;r:=public.site_copy_operation_fixture_begin(a);
  pending:=public.site_copy_operation_fixture_call('record_site_copy_translation_operation_dispatch',public.site_copy_operation_fixture_dispatch_args(r,'translation'));
  perform pg_sleep(45.1);
  late:=public.site_copy_operation_fixture_call('reconcile_site_copy_translation_operation',jsonb_build_object('p_operation_id',r->'operationId'));
  assert late->>'blockReason'='provider_outcome_unknown' and late->'pendingCallId'=pending->'pendingCallId';
  late:=public.site_copy_operation_fixture_ack(pending,a->'payload');assert late->>'blockReason'='operation_deadline';
  artifact:=public.site_copy_operation_fixture_artifact(late);
  assert artifact#>'{calls,0,responseArtifact,body}'=jsonb_build_object('response',(a->'payload')::text);
  done:=public.site_copy_operation_fixture_finish(late,a->'payload');assert done#>>'{result,state}'='translated' and done->'providerCalls'='1'::jsonb;
  reset role;set constraints premium_translation_private.catalog_artifacts_site_copy_admission_complete immediate;
  select coalesce(jsonb_agg(to_jsonb(w) order by at_time,id),'[]'::jsonb) into trace from public.site_copy_operation_fixture_wire w where not(w.id=any(before_wire));
  observed:=jsonb_build_object('unknownAfterDeadline',pending,'lateFirstAck',late,'artifact',artifact,'completeNoNewExpense',done,'realElapsedDeadline',true,'observedWire',trace);
  raise exception 'Rollback synthetic late response' using errcode='ZX001';
 exception when sqlstate 'ZX001' then null;end;
 assert observed is not null;insert into public.site_copy_operation_fixture_results values('first-body-after-real-deadline-complete-retention',observed);
end; $$;
select 'M07_SITE_COPY_ADMISSION_FIRST_BODY_AFTER_DEADLINE_PASS';

-- Actual unchanged JS builder/hash + actual production one-pass raw response,
-- then real native journal. The owner runner derives FINISH through the actual
-- installed SDK/retained helper from this native GET, never a copied test time.
create function public.site_copy_operation_fixture_real_js_input()
returns jsonb language sql immutable set search_path='' as $$ select $native_real_js${"sourceSnapshot":{"settings":{"siteCopy":{"en":{"intro":"Existing machine copy","manual":"Keep authored English","unrelated":{"raw":true}},"fr":{"intro":"  Fran\u00e7ais intact  ","rights":["\u00e9diteur",null]},"ru":{"cta":"\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u043a\u0430\u0440\u0442\u0443","intro":"  \u0418\u0441\u0445\u043e\u0434\u043d\u044b\u0439 \u2014 \u0442\u0435\u043a\u0441\u0442\r\n\u0441 \u043d\u043e\u0432\u043e\u0439 \u0441\u0442\u0440\u043e\u043a\u043e\u0439  ","manual":"\u0420\u0443\u0447\u043d\u043e\u0439 \u0440\u0443\u0441\u0441\u043a\u0438\u0439"},"localeExtension":{"preserve":true}},"systemKey":"site-copy-overrides","unknownSettings":{"empty":[],"rights":{"owner":"editor"}},"premiumTranslation":{"siteCopyEn":{"intro":{"sourceHash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","customMachine":{"rights":"keep"}},"unselected":{"raw":"preserved"}},"customPremium":["keep",null]}},"items":[{"key":"cta","text":"\u041e\u0442\u043a\u0440\u044b\u0442\u044c \u043a\u0430\u0440\u0442\u0443","sourceHash":"26e9cfce4f747547b41d586b515412a7ed47d71f37bab9afe42bb41b36fc0f21"},{"key":"intro","text":"\u0418\u0441\u0445\u043e\u0434\u043d\u044b\u0439 - \u0442\u0435\u043a\u0441\u0442\r\n\u0441 \u043d\u043e\u0432\u043e\u0439 \u0441\u0442\u0440\u043e\u043a\u043e\u0439","sourceHash":"98dd0fd83450cc0134dc053d9df7152805b640580254ff3eb0d5622c57a7fab0"}]},"sourceHash":"428450394708d92b258fe25a1360ef780c7899187952036ae000a13e8a851944","configuration":{"version":1,"provider":"cloudflare","model":"fixture-translator","reviewerModel":"fixture-reviewer","twoPassReview":false,"translatorReasoningEffort":"none","translatorReasoningMode":"standard","reviewerReasoningEffort":"none","reviewerReasoningMode":"standard","promptFingerprint":"472b1cbb789ca7df7bf60be740c7a3d724b4006cbe71f31b95d901d1a94f8e7f","schemaName":"probpera_site_copy_translation","maxOutputTokens":12000},"dispatch":{"p_job_id":"fb3babd6-416f-44d2-8fd2-dfb04280b6ee","p_item_id":"269be366-4459-4f4f-b412-ef7787c2f963","p_operation_id":"0c5659de-cc83-45fe-bd74-65bd4d3e396b","p_call_id":"a3f91af3-70b4-49d0-b205-0f22a7a0a83a","p_provider":"cloudflare","p_model":"fixture-translator","p_pass":"translation","p_request_hash":"083aedaa8788840e97bd8099d30d957d4e418e78fcd6ae4a7dd2aaa15af960e4"},"responseMetadata":{"callId":"a3f91af3-70b4-49d0-b205-0f22a7a0a83a","provider":"cloudflare","model":"fixture-translator","pass":"translation","httpStatus":null,"requestId":null,"responseId":"controlled-site-copy-1","inputTokens":11,"outputTokens":13},"responseArtifact":{"version":1,"body":{"id":"controlled-site-copy-1","response":"{\"items\":[{\"key\":\"cta\",\"text\":\"Find books in the catalogue\"},{\"key\":\"intro\",\"text\":\"Find books in the catalogue\"}]}","usage":{"prompt_tokens":11,"completion_tokens":13}}},"orderedPayload":{"items":[{"key":"cta","text":"Find books in the catalogue"},{"key":"intro","text":"Find books in the catalogue"}]}}$native_real_js$::jsonb; $$;
do $$ declare input jsonb;a jsonb;r jsonb;request jsonb;metadata jsonb;artifact jsonb;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 input:=public.site_copy_operation_fixture_real_js_input();a:=public.site_copy_operation_fixture_seed(false);
 assert a#>'{sourceSnapshot,settings}'=input#>'{sourceSnapshot,settings}','actual native canonical settings equal production builder input';
 a:=a||jsonb_build_object('sourceSnapshot',input->'sourceSnapshot','sourceHash',input->'sourceHash','configuration',input->'configuration','payload',input->'orderedPayload');
 set local role authenticated;r:=public.site_copy_operation_fixture_begin(a);
 request:=(input->'dispatch')||jsonb_build_object('p_job_id',r->'jobId','p_item_id',r->'itemId','p_operation_id',r->'operationId','p_call_id',gen_random_uuid());
 r:=public.site_copy_operation_fixture_call('record_site_copy_translation_operation_dispatch',request);
 metadata:=(input->'responseMetadata')||jsonb_build_object('callId',r->'pendingCallId');
 r:=public.site_copy_operation_fixture_call('record_site_copy_translation_operation_response',jsonb_build_object('p_job_id',r->'jobId','p_item_id',r->'itemId','p_operation_id',r->'operationId',
  'p_metadata',metadata,'p_response_artifact',input->'responseArtifact'));
 artifact:=public.site_copy_operation_fixture_artifact(r);reset role;
 assert artifact#>>'{receipt,sourceHash}'='428450394708d92b258fe25a1360ef780c7899187952036ae000a13e8a851944';
 insert into public.site_copy_operation_fixture_results values('real-js-native-input',jsonb_build_object('artifact',artifact,'expectedPayload',input->'orderedPayload',
  'actualBuilderSeedSha256','f5e49f4925b44ce0d2fcc023d2c9c40a7557bf2173b722f7171959808ca7354d','nativeReceiptBodyBeforeTrustedFinish',true));
end; $$;
select 'M07_SITE_COPY_NATIVE_REAL_JS_INPUT_RECORDED_PASS';
