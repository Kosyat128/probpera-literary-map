begin;
set local timezone='UTC';set local role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
do $real_finish$ declare input jsonb:=$actual_retained_candidate${"p_job_id":"578d1952-40be-4fc5-9670-baf5f9cc9c18","p_item_id":"0d9d4134-4286-4e6e-b1ac-1c5310753bd4","p_operation_id":"c0fb0081-ab7c-46d2-ac88-c7808caad888","p_outcome":{"status":"succeeded","providerCalls":1,"model":"fixture-translator","requestId":"controlled-site-copy-1","inputTokens":11,"outputTokens":13},"p_candidate":{"payload":{"items":[{"key":"cta","text":"Find books in the catalogue"},{"key":"intro","text":"Find books in the catalogue"}]},"provenance":{"provider":"cloudflare","translatorModel":"fixture-translator","reviewerModel":null,"translatorRequestId":"controlled-site-copy-1","reviewerRequestId":null,"generatedAt":"2026-10-30T11:20:53.317Z"},"translatorCallId":"876078e8-9111-444c-9cd6-b64391afff10","reviewerCallId":null}}$actual_retained_candidate$::jsonb;r jsonb;a jsonb;expected jsonb;begin
 select value->'expectedPayload' into expected from public.site_copy_operation_fixture_results where label='real-js-native-input';
 r:=public.site_copy_operation_fixture_call('finish_site_copy_translation_operation',input);
 a:=public.site_copy_operation_fixture_artifact(r);
 assert a->'candidate'=input->'p_candidate' and a#>'{candidate,payload}'=expected,'native saved candidate equals actual retained production reconstruction';
 insert into public.site_copy_operation_fixture_results values('real-js-native-roundtrip',jsonb_build_object('finished',r,'artifact',a,'actualRetainedBuilderCandidate',input->'p_candidate',
  'actualSdkGetAndProductionRetainedBuilder',true,'nativeStoredCandidateParity',true,'externalProviderCalls',0));
end; $real_finish$;
commit;
select value->'artifact' from public.site_copy_operation_fixture_results where label='real-js-native-roundtrip';
