$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-admission-sql-native\v8'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
$dataDirectory=Join-Path $clusterRoot 'data'
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory -or $owned.service){throw 'Unexpected owned local cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Owned previous PID remains'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Owned PID file remains'}
if(@(Get-NetTCPConnection -LocalPort 55438 -State Listen -ErrorAction SilentlyContinue).Count -ne 0){throw 'Unexpected listener'}
$started=$false
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres-intermediate-export.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned local start failed'}
 $started=$true;$ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8';$psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Wrong owned data directory'}
 $query="select coalesce(jsonb_agg(jsonb_build_object('rpc',rpc,'args',args,'response',response) order by at_time,id),'[]'::jsonb) from public.site_copy_operation_fixture_wire"
 $json=& $psql -h 127.0.0.1 -p 55438 -U postgres -d site_copy_admission_v8_20261030 --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc $query
 if($LASTEXITCODE -ne 0){throw 'Native intermediate export failed'}
 $out=Join-Path $nativeRoot 'native-goldens-intermediate-v8.json'
 $json|Set-Content -LiteralPath $out -Encoding utf8
 $value=Get-Content -LiteralPath $out -Raw|ConvertFrom-Json
 [pscustomobject]@{classification='INTERMEDIATE_HISTORICAL_V8_NATIVE_WIRE_NOT_FINAL_READER_NOT_INSTALLED';records=@($value).Count;sha256=(Get-FileHash -LiteralPath $out -Algorithm SHA256).Hash.ToLowerInvariant();nativeSqlSha256='664299a7f2ab07e8110c5cbba3123557486c60f65fe644d0e56c22fb3979f4be';nativeFixtureSha256='a91e8804f74557d75bf91759bd3ba85153d4bc6812102c73f5f48f190d36e84a';nativeAdapterAtCapture='cf355ad7a1ec9b72c7cf17cf0a3492eb805197e03b2be6bdff14c3c01b08eeee';providerCalls=0}|ConvertTo-Json|Tee-Object -FilePath(Join-Path $nativeRoot 'intermediate-export-receipt.json')
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'intermediate-export-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'intermediate-export-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
