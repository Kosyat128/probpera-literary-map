﻿$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-admission-sql-native\v5'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory -or $owned.service){throw 'Unexpected owned isolated cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID still exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
if(@(Get-NetTCPConnection -LocalPort 55438 -State Listen -ErrorAction SilentlyContinue).Count -ne 0){throw 'Unexpected listener on owned loopback port'}
$started=$false;$exitCode=1
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned local PostgreSQL start failed'}
 $started=$true;$ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8';$psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not owned loopback cluster'}
 $database='site_copy_admission_v5_20261030'
 $exists=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc "select count(*) from pg_database where datname='$database'"
 if($exists -ne '0'){throw 'Native database already exists; refusing reset'}
 $oldFamilyCount=& $psql -h 127.0.0.1 -p 55438 -U postgres -d site_copy_admission_v2_20261030 --no-psqlrc -Atc "select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='premium_translation_private' and p.proname like 'site_copy_operation_%'"
 if($LASTEXITCODE -ne 0 -or $oldFamilyCount -ne '0'){throw 'Owned v2 template is not the rolled-back pre-admission baseline'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc --set=ON_ERROR_STOP=1 -c "create database $database template site_copy_admission_v2_20261030"
 if($LASTEXITCODE -ne 0){throw 'Native database creation failed'}
 $stamp=[DateTime]::UtcNow
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'fixture.sql') *> (Join-Path $nativeRoot 'run.log')
 $exitCode=$LASTEXITCODE
 [pscustomobject]@{database=$database;startedAt=$stamp.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');exitCode=$exitCode;elapsedMs=([DateTime]::UtcNow-$stamp).TotalMilliseconds;loopback='127.0.0.1';port=55438;providerCalls=0}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'run-receipt.json') -Encoding utf8
 Get-Content -LiteralPath(Join-Path $nativeRoot 'run.log')|Select-Object -Last 9
 Write-Output ('PSQL_EXIT='+$exitCode)
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
exit $exitCode
