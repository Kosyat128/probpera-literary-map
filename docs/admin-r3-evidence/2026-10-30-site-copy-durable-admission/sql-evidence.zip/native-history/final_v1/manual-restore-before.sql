-- Actual OLD guarded-save contract in the owned pre-admission v2 database.
-- Synthetic rows only; the entire observation transaction rolls back.
begin;
set local timezone='UTC';
create temporary table site_copy_manual_before_output(value jsonb);
do $$ declare b public.homepage_blocks%rowtype;a jsonb;d jsonb;settings jsonb;payload jsonb;saved uuid;begin
 perform set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
 delete from public.premium_translation_working_drafts where entity_type='site_copy';
 delete from public.homepage_blocks canonical where canonical.settings->>'systemKey'='site-copy-overrides';
 insert into public.homepage_blocks(id,block_type,title,settings,display_order,is_enabled,background_style,background_media_id,updated_by,updated_at)
 values('dddddddd-dddd-4ddd-8ddd-dddddddddddd','text','KEEP AUTHORED TITLE',public.site_copy_fixture_settings(),-17,false,'paper','99999999-9999-4999-8999-999999999999',
  '11111111-1111-4111-8111-111111111111',transaction_timestamp()) returning * into b;
 a:=public.site_copy_fixture_args();set local role authenticated;d:=public.premium_fixture_stage(a)->'draft';reset role;
 update public.homepage_blocks set title=title||' RAW NONSETTINGS DRIFT' where id=b.id;
 select * into b from public.homepage_blocks where id=b.id;
 settings:=jsonb_set(b.settings,'{siteCopy,en,intro}','"Historical approved English restored by a human"');
 settings:=jsonb_set(settings,'{premiumTranslation,siteCopyEn,intro,humanReview}',jsonb_build_object('status','approved','reviewedBy','11111111-1111-4111-8111-111111111111','reviewedAt','2026-10-01T10:00:00.123456Z'));
 payload:=jsonb_build_object('block_type','text','title',b.title,'settings',settings,'display_order',b.display_order,'is_enabled',b.is_enabled,
  'background_style',b.background_style,'background_media_id',b.background_media_id);
 set local role authenticated;saved:=public.save_site_copy_block(b.updated_at,payload,'{"nativeManualRestore":true}');reset role;
 assert saved=b.id and (select canonical.settings#>>'{siteCopy,en,intro}'='Historical approved English restored by a human' from public.homepage_blocks canonical where id=b.id);
 assert (select count(*)=1 from public.premium_translation_working_drafts where id=(d->>'id')::uuid);
 insert into pg_temp.site_copy_manual_before_output values(jsonb_build_object('classification','ACTUAL_OLD_GUARDED_SAVE_WITH_PENDING_LEGACY_CANDIDATE','payload',payload,
  'saved',true,'pendingCandidateRetained',true,'providerCalls',0,'productionWrites',0,'transactionRolledBack',true));
end; $$;
select value from pg_temp.site_copy_manual_before_output;
rollback;
