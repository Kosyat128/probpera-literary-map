﻿$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-admission-sql-native\final_v1'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory -or $owned.service){throw 'Unexpected owned isolated cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID still exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
if(@(Get-NetTCPConnection -LocalPort 55438 -State Listen -ErrorAction SilentlyContinue).Count -ne 0){throw 'Unexpected listener on owned loopback port'}
$started=$false;$exitCode=1
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned local PostgreSQL start failed'}
 $started=$true;$ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8';$psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not owned loopback cluster'}
 $database='site_copy_admission_final_v1_20261030'
 $exists=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc "select count(*) from pg_database where datname='$database'"
 if($LASTEXITCODE -ne 0 -or $exists -ne '1'){throw 'Exact previously completed final database missing'}
 $stamp=[DateTime]::UtcNow
 $current=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f(Join-Path $nativeRoot 'after-functions.sql')
 if($LASTEXITCODE -ne 0 -or $current.Trim() -ne (Get-Content -LiteralPath(Join-Path $nativeRoot 'after-functions.json') -Raw).Trim()){throw 'Final functions drift since native fixture proof'}
 $active=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select count(*) from public.translation_job_items where entity_type='site_copy' and staff_retry is not null"
 if($LASTEXITCODE -ne 0 -or $active -ne '0'){throw 'Cannot start race completion with an unresolved operation'}
 & node 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-admission-races-sol\run-races.cjs' --execute-owned --owned $ownedPath --database $database --output 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-admission-sql-native\final_v1\concurrency' *> (Join-Path $nativeRoot 'completion-concurrency.raw.log')
 if($LASTEXITCODE -ne 0){throw 'Final corrected-path actual native concurrency failed'}
  $wire=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select coalesce(jsonb_agg(jsonb_build_object('rpc',e.rpc,'args',e.args,'response',e.response) order by e.at_time,e.id),'[]'::jsonb) from (select rpc,args,response,at_time::text,id::text from public.site_copy_operation_fixture_wire union all select trace.entry->>'rpc',trace.entry->'args',trace.entry->'response',trace.entry->>'at_time',trace.entry->>'id' from public.site_copy_operation_fixture_results r cross join lateral jsonb_array_elements(coalesce(r.value->'observedWire','[]'::jsonb)) trace(entry)) e"
  if($LASTEXITCODE -ne 0){throw 'Native wire export failed'}
  $wire|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-goldens.raw-utf8.json') -Encoding utf8
  & python 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-durable-admission-next\canonicalize-native-json.py' (Join-Path $nativeRoot 'native-goldens.raw-utf8.json') (Join-Path $nativeRoot 'native-goldens.json') *> (Join-Path $nativeRoot 'native-json-canonicalization.json')
  if($LASTEXITCODE -ne 0){throw 'Native JSON equivalent ASCII export failed'}
  $cases=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select coalesce(jsonb_agg(jsonb_build_object('label',label,'value',value) order by label),'[]'::jsonb) from public.site_copy_operation_fixture_results"
  if($LASTEXITCODE -ne 0){throw 'Native case export failed'}
  $cases|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-cases.json') -Encoding utf8
 $exitCode=0
 [pscustomobject]@{classification='COMPLETION_AFTER_PRECONNECTION_SHORT_PATH_PREFLIGHT_REFUSAL_NO_SQL_OR_SOURCE_CHANGE';database=$database;startedAt=$stamp.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');exitCode=0;elapsedMs=([DateTime]::UtcNow-$stamp).TotalMilliseconds;providerCalls=0}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'completion-receipt.json') -Encoding utf8
 Write-Output 'FINAL_COMPLETION_PASS'
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'completion-cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'completion-cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
exit $exitCode
