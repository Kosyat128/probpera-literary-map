﻿$ErrorActionPreference='Stop'
$nativeRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-admission-sql-native\final_v1'
$clusterRoot='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native'
$dataDirectory=Join-Path $clusterRoot 'data'
$ownedPath=Join-Path $clusterRoot 'owned-cluster.json'
$owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
if($owned.port -ne 55438 -or $owned.dataDirectory -ne $dataDirectory -or $owned.service){throw 'Unexpected owned isolated cluster'}
if(Get-Process -Id $owned.pid -ErrorAction SilentlyContinue){throw 'Previous postmaster PID still exists'}
if(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid')){throw 'Unexpected active postmaster PID file'}
if(@(Get-NetTCPConnection -LocalPort 55438 -State Listen -ErrorAction SilentlyContinue).Count -ne 0){throw 'Unexpected listener on owned loopback port'}
$started=$false;$exitCode=1
try{
 & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -l (Join-Path $nativeRoot 'postgres.log') -o '-h 127.0.0.1 -p 55438' -w -t 20 start
 if($LASTEXITCODE -ne 0){throw 'Owned local PostgreSQL start failed'}
 $started=$true;$ownedPid=[int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1)
 $owned.pid=$ownedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $env:PGCLIENTENCODING='UTF8';$psql=Join-Path $owned.pgBin 'psql.exe'
 $actualData=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc 'show data_directory'
 if($LASTEXITCODE -ne 0 -or $actualData.Replace('/','\').ToLowerInvariant() -ne $dataDirectory.ToLowerInvariant()){throw 'Not owned loopback cluster'}
 $database='site_copy_admission_final_v1_20261030'
 $exists=& $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc -Atc "select count(*) from pg_database where datname='$database'"
 if($exists -ne '0'){throw 'Native database already exists; refusing reset'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc --set=ON_ERROR_STOP=1 -c "create database $database"
 if($LASTEXITCODE -ne 0){throw 'Native database creation failed'}
 $stamp=[DateTime]::UtcNow
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'foundation.sql') *> (Join-Path $nativeRoot 'foundation.log')
 if($LASTEXITCODE -ne 0){throw 'Final exact old foundation failed'}
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'manual-restore-before.sql') *> (Join-Path $nativeRoot 'manual-restore-before.raw.log')
 if($LASTEXITCODE -ne 0){throw 'Same-foundation actual OLD guarded-save BEFORE failed'}
 $baselineDatabase='site_copy_admission_final_v1_before_20261030'
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d postgres --no-psqlrc --set=ON_ERROR_STOP=1 -c "create database $baselineDatabase template $database" *> (Join-Path $nativeRoot 'before-database-clone.log')
 if($LASTEXITCODE -ne 0){throw 'Final same-foundation BEFORE clone failed'}
 foreach($scope in @('functions','tables','indexes','constraints','triggers','relations','roles')){
  $before=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $baselineDatabase --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select value from public.site_copy_operation_fixture_baseline where label='$scope'"
  if($LASTEXITCODE -ne 0){throw 'Final BEFORE export failed'}
  $before|Set-Content -LiteralPath(Join-Path $nativeRoot ('before-'+$scope+'.json')) -Encoding utf8
 }
 $env:SUPABASE_TELEMETRY_DISABLED='1';$env:DO_NOT_TRACK='1';$env:SUPABASE_NO_UPDATE_NOTIFIER='1';$env:SUPABASE_NO_KEYRING='1';$env:SUPABASE_HOME=Join-Path $nativeRoot 'cli-home'
 $cli='C:\Users\Костя\Documents\Codex\2026-10-09\v\work\portable-db-tools\supabase-2.120.0\supabase.exe'
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$baselineDatabase+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors-before.raw.log')
 $beforeAdvisorExit=$LASTEXITCODE
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'migration.sql') *> (Join-Path $nativeRoot 'migration.log')
 if($LASTEXITCODE -ne 0){throw 'Final new migration failed'}
 foreach($scope in @('functions','tables','indexes','constraints','triggers','relations','roles')){
  $after=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot ('after-'+$scope+'.sql'))
  if($LASTEXITCODE -ne 0){throw 'Final AFTER export failed'}
  $after|Set-Content -LiteralPath(Join-Path $nativeRoot ('after-'+$scope+'.json')) -Encoding utf8
 }
 & $cli db advisors --db-url ('postgresql://postgres@127.0.0.1:55438/'+$database+'?sslmode=disable') --type security --level warn --fail-on error --output-format json *> (Join-Path $nativeRoot 'security-advisors-after-migration.raw.log')
 $afterAdvisorExit=$LASTEXITCODE
 $available=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc -Atc "select count(*) from pg_available_extensions where name='plpgsql_check'"
 [pscustomobject]@{sameFoundationBeforeDatabase=$baselineDatabase;beforeAdvisorExit=$beforeAdvisorExit;afterAdvisorExit=$afterAdvisorExit;plpgsqlCheckAvailable=[int]$available;lint='NOT_RUN_EXTENSION_NOT_INSTALLED_NO_INSTALL';managedAuthOrProviderClaim=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'advisors-lint-receipt.json') -Encoding utf8
 & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -f (Join-Path $nativeRoot 'fixture-cases.sql') *> (Join-Path $nativeRoot 'run.log')
 $exitCode=$LASTEXITCODE
 [pscustomobject]@{database=$database;startedAt=$stamp.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');exitCode=$exitCode;elapsedMs=([DateTime]::UtcNow-$stamp).TotalMilliseconds;loopback='127.0.0.1';port=55438;providerCalls=0}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'run-receipt.json') -Encoding utf8
 if($exitCode -eq 0){
  $realInput=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select value->'artifact' from public.site_copy_operation_fixture_results where label='real-js-native-input'"
  if($LASTEXITCODE -ne 0 -or -not $realInput){throw 'Real JS native input missing'}
  $realInput|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-real-js-before.json') -Encoding utf8
  & node 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-durable-tests-sol\native-candidate-from-artifact.cjs' (Join-Path $nativeRoot 'native-real-js-before.json') (Join-Path $nativeRoot 'actual-retained-candidate.json') *> (Join-Path $nativeRoot 'actual-retained-candidate.log')
  if($LASTEXITCODE -ne 0){throw 'Actual SDK and retained builder could not reconstruct native GET'}
  & node 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-durable-admission-next\prepare-real-js-finish.cjs' (Join-Path $nativeRoot 'native-real-js-before.json') (Join-Path $nativeRoot 'actual-retained-candidate.json') (Join-Path $nativeRoot 'real-js-finish.sql') *> (Join-Path $nativeRoot 'real-js-finish-prepare.log')
  if($LASTEXITCODE -ne 0){throw 'Actual retained candidate FINISH preparation failed'}
  & $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAt -f (Join-Path $nativeRoot 'real-js-finish.sql') *> (Join-Path $nativeRoot 'real-js-finish.raw.log')
  if($LASTEXITCODE -ne 0){throw 'Native FINISH of actual retained production candidate failed'}
  $realFinal=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select value->'artifact' from public.site_copy_operation_fixture_results where label='real-js-native-roundtrip'"
  if($LASTEXITCODE -ne 0 -or -not $realFinal){throw 'Real JS final native GET missing'}
  $realFinal|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-real-js-final-artifact.json') -Encoding utf8
  & node 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-admission-races-sol\run-races.cjs' --execute-owned --owned $ownedPath --database $database --output (Join-Path $nativeRoot 'concurrency') *> (Join-Path $nativeRoot 'concurrency.raw.log')
  if($LASTEXITCODE -ne 0){throw 'Final native concurrency groups failed'}
  $wire=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select coalesce(jsonb_agg(jsonb_build_object('rpc',e.rpc,'args',e.args,'response',e.response) order by e.at_time,e.id),'[]'::jsonb) from (select rpc,args,response,at_time::text,id::text from public.site_copy_operation_fixture_wire union all select trace.entry->>'rpc',trace.entry->'args',trace.entry->'response',trace.entry->>'at_time',trace.entry->>'id' from public.site_copy_operation_fixture_results r cross join lateral jsonb_array_elements(coalesce(r.value->'observedWire','[]'::jsonb)) trace(entry)) e"
  if($LASTEXITCODE -ne 0){throw 'Native wire export failed'}
  $wire|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-goldens.raw-utf8.json') -Encoding utf8
  & python 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\site-copy-durable-admission-next\canonicalize-native-json.py' (Join-Path $nativeRoot 'native-goldens.raw-utf8.json') (Join-Path $nativeRoot 'native-goldens.json') *> (Join-Path $nativeRoot 'native-json-canonicalization.json')
  if($LASTEXITCODE -ne 0){throw 'Native JSON equivalent ASCII export failed'}
  $cases=& $psql -h 127.0.0.1 -p 55438 -U postgres -d $database --no-psqlrc --set=ON_ERROR_STOP=1 -qAtc "select coalesce(jsonb_agg(jsonb_build_object('label',label,'value',value) order by label),'[]'::jsonb) from public.site_copy_operation_fixture_results"
  if($LASTEXITCODE -ne 0){throw 'Native case export failed'}
  $cases|Set-Content -LiteralPath(Join-Path $nativeRoot 'native-cases.json') -Encoding utf8
 }
 Get-Content -LiteralPath(Join-Path $nativeRoot 'run.log')|Select-Object -Last 9
 Write-Output ('PSQL_EXIT='+$exitCode)
}finally{
 if($started){
  if([int](Get-Content -LiteralPath(Join-Path $dataDirectory 'postmaster.pid') -TotalCount 1) -ne $ownedPid){throw 'Owned PID changed; refusing stop'}
  & (Join-Path $owned.pgBin 'pg_ctl.exe') -D $dataDirectory -m fast -w -t 20 stop *> (Join-Path $nativeRoot 'cleanup.log')
  $stopCode=$LASTEXITCODE
  [pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');ownedPid=$ownedPid;pgCtlExitCode=$stopCode;processRemains=[bool](Get-Process -Id $ownedPid -ErrorAction SilentlyContinue);pidFileRemains=(Test-Path -LiteralPath(Join-Path $dataDirectory 'postmaster.pid'));port=55438;serviceCreated=$false}|ConvertTo-Json|Set-Content -LiteralPath(Join-Path $nativeRoot 'cleanup.json') -Encoding utf8
  if($stopCode -ne 0){throw 'Owned cleanup failed'}
 }
}
exit $exitCode
