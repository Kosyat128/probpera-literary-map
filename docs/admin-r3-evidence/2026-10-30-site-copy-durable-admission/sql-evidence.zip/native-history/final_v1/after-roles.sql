set search_path=public,pg_catalog;set timezone='UTC';
select jsonb_agg(to_jsonb(r) order by r.rolname) from pg_roles r;
