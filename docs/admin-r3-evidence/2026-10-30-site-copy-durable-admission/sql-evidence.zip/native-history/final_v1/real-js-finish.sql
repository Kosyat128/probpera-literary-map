begin;
set local timezone='UTC';set local role authenticated;
select set_config('request.jwt.claim.sub','11111111-1111-4111-8111-111111111111',true);
do $real_finish$ declare input jsonb:=$actual_retained_candidate${"p_job_id":"db61b0de-d93c-4836-aab3-338c7069e5c4","p_item_id":"f80eee3f-face-43f5-a672-a6771cfef262","p_operation_id":"6067f745-55ec-419b-9a4c-fb7062623f99","p_outcome":{"status":"succeeded","providerCalls":1,"model":"fixture-translator","requestId":"controlled-site-copy-1","inputTokens":11,"outputTokens":13},"p_candidate":{"payload":{"items":[{"key":"cta","text":"Find books in the catalogue"},{"key":"intro","text":"Find books in the catalogue"}]},"provenance":{"provider":"cloudflare","translatorModel":"fixture-translator","reviewerModel":null,"translatorRequestId":"controlled-site-copy-1","reviewerRequestId":null,"generatedAt":"2026-10-30T12:06:19.281Z"},"translatorCallId":"8cfceffb-ca8e-4a93-8e0d-5f11eaa397cb","reviewerCallId":null}}$actual_retained_candidate$::jsonb;r jsonb;a jsonb;expected jsonb;begin
 select value->'expectedPayload' into expected from public.site_copy_operation_fixture_results where label='real-js-native-input';
 r:=public.site_copy_operation_fixture_call('finish_site_copy_translation_operation',input);
 a:=public.site_copy_operation_fixture_artifact(r);
 assert a->'candidate'=input->'p_candidate' and a#>'{candidate,payload}'=expected,'native saved candidate equals actual retained production reconstruction';
 insert into public.site_copy_operation_fixture_results values('real-js-native-roundtrip',jsonb_build_object('finished',r,'artifact',a,'actualRetainedBuilderCandidate',input->'p_candidate',
  'actualSdkGetAndProductionRetainedBuilder',true,'nativeStoredCandidateParity',true,'externalProviderCalls',0));
end; $real_finish$;
commit;
select value->'artifact' from public.site_copy_operation_fixture_results where label='real-js-native-roundtrip';
