begin;set local statement_timeout='12s';select jsonb_build_object('tag','pid','pid',pg_backend_pid());select jsonb_build_object('tag','value','value',((select to_jsonb(d) from public.premium_translation_working_drafts d where id='948d6cf3-ff2a-4a19-a595-5cc5ae563fb5'::uuid for update)));select jsonb_build_object('tag','ready','pid',pg_backend_pid());
rollback;\q
