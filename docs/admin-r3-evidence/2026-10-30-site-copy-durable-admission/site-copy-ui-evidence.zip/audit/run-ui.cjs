const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),out=path.join(__dirname,'ui-'+new Date().toISOString().replaceAll(':','-'));
fs.mkdirSync(out,{recursive:true});const temp=path.join(out,'tmp');fs.mkdirSync(temp);
const env={};for(const name of ['SystemRoot','WINDIR','COMSPEC','PATH','PATHEXT','USERPROFILE','LOCALAPPDATA','APPDATA','NUMBER_OF_PROCESSORS'])if(process.env[name])env[name]=process.env[name];
Object.assign(env,{TEMP:temp,TMP:temp,CI:'1',NEXT_TELEMETRY_DISABLED:'1',NO_COLOR:'1',NODE_ENV:'production'});
const files=process.argv.slice(2);if(!files.length)files.push('apps/admin/app/(dashboard)/translations/site-copy-operation-ui.integration.test.ts');
const started=Date.now(),run=spawnSync(process.execPath,[path.join(repo,'node_modules/vitest/vitest.mjs'),'run',...files,'--maxWorkers=1','--reporter=json','--outputFile='+path.join(out,'raw.json')],{cwd:repo,env,encoding:'utf8',timeout:180000,maxBuffer:32*1024*1024});
fs.writeFileSync(path.join(out,'stdout.log'),run.stdout||'');fs.writeFileSync(path.join(out,'stderr.log'),run.stderr||'');
const raw=fs.existsSync(path.join(out,'raw.json'))?JSON.parse(fs.readFileSync(path.join(out,'raw.json'),'utf8')):null;
const receipt={checkedAt:new Date().toISOString(),files,exitCode:run.status,signal:run.signal,error:run.error?.message||null,durationMs:Date.now()-started,
 counts:raw&&{total:raw.numTotalTests,pass:raw.numPassedTests,fail:raw.numFailedTests,pending:raw.numPendingTests,todo:raw.numTodoTests},
 failures:raw?.testResults.flatMap(file=>file.assertionResults.filter(test=>test.status==='failed').map(test=>({file:file.name,name:test.fullName,errors:test.failureMessages})))||[]};
fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify({out,...receipt}));process.exitCode=run.status??2;
