const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),{zipSync,unzipSync}=require(path.join(repo,'node_modules/fflate'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),read=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const payload={},sourceRows=new Map();
function add(name,bytes){assert.ok(name&&!name.startsWith('/')&&!name.includes('\\')&&!name.split('/').some(p=>p==='..'||!p));assert.ok(!Object.hasOwn(payload,name),`Duplicate ${name}`);payload[name]=new Uint8Array(bytes);}
function file(name,filename){add(name,fs.readFileSync(filename));}
function tree(label,dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){if(entry.name==='tmp')continue;assert.equal(entry.isSymbolicLink(),false);const target=path.join(dir,entry.name),name=label+'/'+entry.name;if(entry.isDirectory())tree(name,target);else if(entry.isFile())file(name,target);}}
function source(row,role){const filename=path.resolve(repo,row.file);assert.ok(filename.startsWith(repo+path.sep));const bytes=fs.readFileSync(filename),actual=sha(bytes);assert.equal(actual,row.sha256,`Current source drift ${row.file}`);const previous=sourceRows.get(row.file);if(previous){assert.equal(previous.sha256,actual);previous.roles.push(role);}else sourceRows.set(row.file,{file:row.file,bytes:bytes.length,sha256:actual,roles:[role]});}
const uiPath=path.resolve(__dirname,'../site-copy-operation-ui-source-proof-yXZhu5/read-graph.json'),profilePath=path.resolve(__dirname,'../profile-scan-ui-source-proof-72o6h1/read-graph.json');
const recoveryDir=path.join(__dirname,'final-ui-checks-2026-10-30T10-36-10.124Z'),recoveryPath=path.join(recoveryDir,'private-recovery-source-proof/report.json');
for(const [label,filename]of[['new-sitecopy-ui',uiPath],['old-profile-ui',profilePath],['old-private-recovery-supplement',recoveryPath]]){const report=read(filename);for(const row of report.sources)source(row,label);file('source-proofs/'+label+'.json',filename);if(report.nativeFixture)source(report.nativeFixture,label+'-native-profile-json');}
const preservation=read(path.join(__dirname,'action-and-ui-preservation.json'));assert.equal(preservation.allPass,true);for(const row of preservation.bindings)source(row,'preservation-currentbinding');
const tests=['apps/admin/app/(dashboard)/translations/site-copy-operation-ui.integration.test.ts','apps/admin/lib/site-copy-private-recovery-page.integration.test.ts'];
for(const name of tests)source({file:name,sha256:sha(fs.readFileSync(path.join(repo,name)))},'actual-test-entry');
for(const row of sourceRows.values())file('current-sources/'+row.file,path.join(repo,row.file));
const first=path.join(__dirname,'ui-2026-10-30T10-29-08.951Z'),second=path.join(__dirname,'ui-2026-10-30T10-31-39.619Z');
const one=read(path.join(first,'receipt.json')),two=read(path.join(second,'receipt.json'));assert.equal(one.exitCode,0);assert.equal(two.exitCode,0);assert.deepEqual([one.counts.total,one.counts.pass,one.counts.fail,one.counts.pending],[231,231,0,0]);assert.deepEqual([two.counts.total,two.counts.pass,two.counts.fail,two.counts.pending],[158,158,0,0]);
tree('runs/ui231',first);tree('runs/old-loads158',second);tree('runs/typescript-and-recovery-graph',recoveryDir);
tree('original-ui-captures/library-profile',path.join(__dirname,'old-ui-before-sitecopy'));tree('original-ui-captures/other-old-setups',path.join(__dirname,'old-ui-setup-before'));
for(const name of['action-and-ui-preservation.json','action-and-ui-preservation.cjs','run-ui.cjs','final-ui-checks.cjs','seal-ui-evidence.cjs'])file('audit/'+name,path.join(__dirname,name));
const dependencies=['typescript','vitest','react','react-dom','cheerio','@supabase/supabase-js','next','fflate'].map(name=>{const filename=require.resolve(name+'/package.json',{paths:[repo]}),b=fs.readFileSync(filename);return{name,version:JSON.parse(b).version,packageJsonSha256:sha(b)}});
const bindings={checkedAt:new Date().toISOString(),classification:'LOCAL_ACTUAL_UI_VITEST_SSR_READ_RECOVERY_RESUME_SOURCE_BINDINGS_NOT_PORTABLE_OR_NATIVE_E2E',sourceCount:sourceRows.size,sources:[...sourceRows.values()].sort((a,b)=>a.file.localeCompare(b.file)),dependencies,node:process.version,
 counts:{distinctVitest:389,newSitecopyUI:87,oldLibraryUI:52,oldProfileUI:92,oldLoadsAndRecovery:158,allPassed:389,pending:0},
 typed:read(path.join(recoveryDir,'receipt.json')).typescript,
 explicitIntentException:'One old site_copy numeric resume case now explicitly expects translation_resume_stale; case retained. Earlier profile checkpoint exceptions are not relabeled unchanged.',
 explicitReadScopeAddition:'Original legacy/nonmetadata RPC no-call and dependency counters remain tested; new exact-null reconciliation is separately measured, so old zero-total-RPC scope is not claimed unchanged.',
 limitations:['No live browser, managed DB/RLS, real provider, publication, native race or full230-criterion acceptance.', 'Installed dependency metadata is bound, not bundled; this UI packet is not a portable replay capsule.', 'The extra standalone4-case private-recovery execution retains its raw report/sourcegraph only and adds no distinct test count.']};
add('SOURCE_BINDINGS.json',Buffer.from(JSON.stringify(bindings,null,2)));
const folded=new Set();for(const name of Object.keys(payload)){assert.ok(!folded.has(name.toLowerCase()));folded.add(name.toLowerCase());}
const entries=Object.entries(payload).map(([name,b])=>({path:name,bytes:b.length,sha256:sha(b)})).sort((a,b)=>a.path.localeCompare(b.path));
add('MANIFEST.json',Buffer.from(JSON.stringify({classification:bindings.classification,payloadCount:entries.length,entries},null,2)));
const zipped=zipSync(payload,{level:6}),zipPath=path.join(__dirname,'site-copy-ui-evidence.zip');fs.writeFileSync(zipPath,zipped,{flag:'wx'});
const extracted=unzipSync(fs.readFileSync(zipPath));assert.equal(Object.keys(extracted).length,entries.length+1);for(const row of entries){assert.equal(extracted[row.path].length,row.bytes);assert.equal(sha(extracted[row.path]),row.sha256);}
const receipt={checkedAt:new Date().toISOString(),zipPath,zipSha256:sha(zipped),zipBytes:zipped.length,payloads:entries.length,totalEntries:entries.length+1,sourceCount:sourceRows.size,sourceBindingsSha256:sha(payload['SOURCE_BINDINGS.json']),manifestSha256:sha(payload['MANIFEST.json']),allPayloadReadback:true,sourceDrift:false,uniqueSafeCasefoldPaths:true,counts:bindings.counts,limitations:bindings.limitations};
fs.writeFileSync(path.join(__dirname,'ui-evidence-receipt.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
