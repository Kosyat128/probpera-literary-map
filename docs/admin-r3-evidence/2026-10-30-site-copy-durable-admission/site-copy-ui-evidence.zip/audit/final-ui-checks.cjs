const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),out=path.join(__dirname,'final-ui-checks-'+new Date().toISOString().replaceAll(':','-'));
fs.mkdirSync(out,{recursive:true});const temp=path.join(out,'tmp');fs.mkdirSync(temp);
const env={};for(const key of['SystemRoot','WINDIR','COMSPEC','PATH','PATHEXT','USERPROFILE','LOCALAPPDATA','APPDATA','NUMBER_OF_PROCESSORS'])if(process.env[key])env[key]=process.env[key];
Object.assign(env,{TEMP:temp,TMP:temp,CI:'1',NEXT_TELEMETRY_DISABLED:'1',NO_COLOR:'1',NODE_ENV:'production'});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const files=['apps/admin/app/(dashboard)/translations/site-copy-operation-ui.integration.test.ts','apps/admin/app/(dashboard)/translations/library-scan-ui.integration.test.ts','apps/admin/app/(dashboard)/translations/profile-scan-ui.integration.test.ts','apps/admin/app/(dashboard)/translations/translations-load-errors.integration.test.ts','apps/admin/app/(dashboard)/site-copy/site-copy-load-errors.integration.test.ts','apps/admin/lib/fixtures/site-copy-private-recovery-page.cjs'];
const before=files.map(file=>({file,sha256:sha(fs.readFileSync(path.join(repo,file)))}));
const start=Date.now(),typed=spawnSync(process.execPath,[path.join(repo,'node_modules/typescript/bin/tsc'),'--project','apps/admin/tsconfig.json','--noEmit','--incremental','false'],{cwd:repo,env,encoding:'utf8',timeout:180000,maxBuffer:16*1024*1024});
fs.writeFileSync(path.join(out,'admin-typescript.stdout.log'),typed.stdout||'');fs.writeFileSync(path.join(out,'admin-typescript.stderr.log'),typed.stderr||'');
const typeDuration=Date.now()-start;
const recoveryOut=path.join(out,'private-recovery-source-proof'),recoveryStart=Date.now(),recovered=spawnSync(process.execPath,[path.join(repo,'apps/admin/lib/fixtures/site-copy-private-recovery-page.cjs')],{cwd:repo,env:{...env,SITE_COPY_REPO:repo,SITE_COPY_RECOVERY_OUTPUT_ROOT:recoveryOut},encoding:'utf8',timeout:30000,maxBuffer:24*1024*1024});
fs.writeFileSync(path.join(out,'private-recovery.stdout.log'),recovered.stdout||'');fs.writeFileSync(path.join(out,'private-recovery.stderr.log'),recovered.stderr||'');
const recovery=fs.existsSync(path.join(recoveryOut,'report.json'))?JSON.parse(fs.readFileSync(path.join(recoveryOut,'report.json'),'utf8')):null;
const after=files.map(file=>({file,sha256:sha(fs.readFileSync(path.join(repo,file)))}));
const report={checkedAt:new Date().toISOString(),classification:'FOCUSED_ADMIN_TYPECHECK_AND_READGRAPH_SUPPLEMENT_TO_ALREADY_PASSED4CASE_RECOVERY_WRAPPER',before,after,sourceDrift:JSON.stringify(before)!==JSON.stringify(after),
 typescript:{exitCode:typed.status,error:typed.error?.message||null,durationMs:typeDuration},
 recovery:{exitCode:recovered.status,error:recovered.error?.message||null,durationMs:Date.now()-recoveryStart,checks:recovery?.checks,sourceCount:recovery?.sources.length,
  scope:'This reruns the same4cases once only to retain complete raw report/sourcegraph absent from passing Vitest stdout. It adds no distinct acceptance count.'}};
fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({out,...report}));process.exitCode=typed.status===0&&recovered.status===0&&!report.sourceDrift?0:1;
