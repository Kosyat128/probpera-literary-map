const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),ts=require(path.join(repo,'node_modules/typescript'));
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex'),bytes=file=>fs.readFileSync(file),text=file=>bytes(file).toString();
const baseline=JSON.parse(text(path.resolve(__dirname,'../profile-stable-scan-final-validation-v3/source-before.json'))),baseMap=new Map(baseline.files.map(row=>[row.path,row]));
const checks=[],bindings=[];function check(name,pass,detail){checks.push({name,pass,detail});}
function parse(file){return ts.createSourceFile(file,text(file),ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);}
function nodes(source,predicate){const result=[];function visit(node){if(predicate(node))result.push(node);ts.forEachChild(node,visit);}visit(source);return result;}
const actionFiles=['apps/admin/app/(dashboard)/site-copy/actions.ts','apps/admin/app/(dashboard)/site-copy/inline-actions.ts'];
for(const file of actionFiles){const original=path.resolve(__dirname,'../site-copy-durable-tests-next/source-snapshots',file),current=path.join(repo,file),before=parse(original),after=parse(current),base=baseMap.get(file);
 check(`${file} original capture matches sealed1af`,base?.sha256===sha(bytes(original)),{originalSha256:sha(bytes(original)),baselineSha256:base?.sha256});
 const imports=source=>nodes(source,node=>ts.isImportDeclaration(node)&&node.moduleSpecifier.getText(source).includes('short-hyphens')).map(node=>node.getText(source));
 const calls=source=>nodes(source,node=>ts.isCallExpression(node)&&['normalizeShortHyphens','normalizeShortHyphensDeep'].includes(node.expression.getText(source))).map(node=>node.getText(source));
 check(`${file} original normalizer imports exact`,JSON.stringify(imports(before))===JSON.stringify(imports(after)),imports(before));
 check(`${file} all original direct normalizer calls exact`,JSON.stringify(calls(before))===JSON.stringify(calls(after)),{count:calls(before).length,calls:calls(before)});
 if(file.endsWith('/inline-actions.ts'))check('Inline source-only action entire bytes exact',bytes(original).equals(bytes(current)));
 else{const prefix=value=>value.slice(0,value.indexOf('  let translationState ='));check('Source-save complete original function prefix through actual save/CAS/publication exact',prefix(text(original))===prefix(text(current)),{note:'Includes all original source payload, raw settings preservation, save_site_copy_block args and ordinary requestPublicBuild before optional translation.'});}
 bindings.push({file,bytes:bytes(current).length,sha256:sha(bytes(current))});}
const protectedFiles=baseline.files.filter(row=>/\.(?:ts|tsx|mjs|cjs)$/u.test(row.path)&&/(?:normaliz|hyphen)/iu.test(path.basename(row.path)));
const protectedProof=protectedFiles.map(row=>({...row,currentSha256:sha(bytes(path.join(repo,row.path))),match:row.sha256===sha(bytes(path.join(repo,row.path)))}));
check('All baseline normalizer/hyphen named code and tests remain byte exact',protectedProof.every(row=>row.match),{count:protectedProof.length,files:protectedProof});
for(const name of['library-scan-ui.integration.test.ts','profile-scan-ui.integration.test.ts']){const file='apps/admin/app/(dashboard)/translations/'+name,beforePath=path.join(__dirname,'old-ui-before-sitecopy',name),afterPath=path.join(repo,file),before=text(beforePath),after=text(afterPath);
 check(`${name} captured original matches sealed1af`,baseMap.get(file)?.sha256===sha(bytes(beforePath)),{originalSha256:sha(bytes(beforePath)),baselineSha256:baseMap.get(file)?.sha256});
 function afterDescribe(value){return value.slice(value.indexOf('\ndescribe('));}
 if(name.startsWith('profile'))check('All92 original profile UI cases/full assertions exact after setup adaptation',afterDescribe(before)===afterDescribe(after));
 else{const oldStart=before.indexOf('  it.each(["site_copy"])("existing %s ordinal'),newStart=after.indexOf('  it.each(["site_copy"])("legacy %s ordinal'),oldEnd=before.indexOf('  it.each(["writer", "country"])',oldStart),newEnd=after.indexOf('  it.each(["writer", "country"])',newStart);
  const remaining=(value,start,end)=>afterDescribe(value.slice(0,start)+'\nDECLARED_SITECOPY_LEGACY_INTENT_SUPERSEDED\n'+value.slice(end));
  check('All other51 original library UI cases/full assertions exact; one sitecopy ordinal intent explicitly superseded',oldStart>=0&&newStart>=0&&oldEnd>=0&&newEnd>=0&&remaining(before,oldStart,oldEnd)===remaining(after,newStart,newEnd),{originalCase:before.slice(oldStart,oldEnd),currentCase:after.slice(newStart,newEnd),authorization:'Root explicit task 2026-10-30: numeric legacy site_copy resume must close with translation_resume_stale; preserve case and original unrelated checks.'});}
 bindings.push({file,bytes:bytes(afterPath).length,sha256:sha(bytes(afterPath))});}
const extraFiles=['apps/admin/app/(dashboard)/site-copy/site-copy-load-errors.integration.test.ts','apps/admin/app/(dashboard)/translations/translations-load-errors.integration.test.ts','apps/admin/lib/fixtures/site-copy-private-recovery-page.cjs','apps/admin/lib/site-copy-private-recovery-page.integration.test.ts'];
const assertCall=node=>ts.isCallExpression(node)&&ts.isPropertyAccessExpression(node.expression)&&
 (/^(?:expect\(|assert\.)/u.test(node.expression.getText()));
const extraProof=[];
for(const file of extraFiles){const original=path.join(__dirname,'old-ui-setup-before',file),current=path.join(repo,file),before=parse(original),after=parse(current);
 check(`${file} original setup capture matches sealed1af`,baseMap.get(file)?.sha256===sha(bytes(original)),{originalSha256:sha(bytes(original)),baselineSha256:baseMap.get(file)?.sha256});
 const oldCalls=nodes(before,assertCall).map(n=>n.getText(before)),newCalls=nodes(after,assertCall).map(n=>n.getText(after));let position=0;
 const preserved=oldCalls.every(call=>{const at=newCalls.indexOf(call,position);position=at+1;return at>=0;});
 check(`${file} all${oldCalls.length} original full assertion calls preserved in order`,preserved,{oldCount:oldCalls.length,currentCount:newCalls.length});
 if(file.endsWith('.integration.test.ts')){const body=value=>value.slice(value.indexOf('\ndescribe('));check(`${file} entire original test declaration/assertion tail exact`,body(text(original))===body(text(current)));}
 if(file.endsWith('.cjs'))for(const name of['candidate','recovery','pagination','unavailable']){const declaration=(source)=>nodes(source,n=>ts.isFunctionDeclaration(n)&&n.name?.getText(source)===name)[0]?.getText(source);check(`Private recovery original ${name} body exact`,declaration(before)===declaration(after));}
 if(file.endsWith('site-copy-private-recovery-page.integration.test.ts'))check('Private recovery4-case wrapper whole bytes exact',bytes(original).equals(bytes(current)));
 extraProof.push({file,originalAssertionCount:oldCalls.length,currentAssertionCount:newCalls.length,allOriginalAssertionsPreserved:preserved});
 bindings.push({file,bytes:bytes(current).length,sha256:sha(bytes(current))});}
const report={checkedAt:new Date().toISOString(),classification:'READ_ONLY_SOURCE_AND_OLD_UI_FULL_ASSERTION_PRESERVATION_WITH_ONE_DECLARED_NEW_LEGACY_INTENT_EXCEPTION',baselineFingerprint:baseline.validationSourceSha256,checks,allPass:checks.every(c=>c.pass),bindings,extraProof,
 setupAdaptations:['Old library/profile SSR fixtures add actual configured owner getStaffSession shape required by fresh private read auth.', 'Actual new metadata RPC is declared as confirmed null in old fixtures; it never fabricates an operation, provider event or write.'],
 limitations:['Static/source proof supplements actual UI regression execution; it is not browser/native/full230 acceptance.','Original profile checkpoint already declared2 writer/country library-UI legacy-intent exceptions and2 separate routing exceptions; this site-copy legacy exception is additive, not hidden under all-original unchanged.',
 'The old site-copy-load-errors rpc-not-called assertion is retained for all legacy/nonmetadata RPCs. The new readonly logical reconciliation is a declared scope addition with its own exact-null args and per-render count assertions; it is not claimed that zero total RPCs still occur.',
 'Translations load-errors original dependency counters/whitelist retain their original domain; new metadata observation is separately measured. Private-recovery raw wire includes each new exact-null reconciliation; all original discovery/discard/canonical/publication checks remain exact.']};
fs.writeFileSync(path.join(__dirname,'action-and-ui-preservation.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({allPass:report.allPass,checks:checks.length,fail:checks.filter(c=>!c.pass),sha256:sha(bytes(path.join(__dirname,'action-and-ui-preservation.json')))}));process.exitCode=report.allPass?0:1;
