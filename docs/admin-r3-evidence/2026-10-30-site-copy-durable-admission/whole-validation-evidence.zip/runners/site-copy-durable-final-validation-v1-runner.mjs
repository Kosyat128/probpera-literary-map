import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, mkdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';

const work = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(work, '../probpera-literary-map');
const out = path.join(work, 'site-copy-durable-final-validation-v1');
mkdirSync(out, {recursive:true});
const hash = data => createHash('sha256').update(data).digest('hex');
const write = (name, value) => writeFileSync(path.join(out,name), JSON.stringify(value,null,2)+'\n');
const git = (...args) => execFileSync('git', args, {cwd:root, encoding:'utf8', maxBuffer:32*1024*1024}).trimEnd();
const head = git('rev-parse','HEAD');
const envAllow = /^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/i;
const childEnv = Object.fromEntries(Object.entries(process.env).filter(([key]) => envAllow.test(key)));
const taskTemp=path.join(out,'temp'); mkdirSync(taskTemp,{recursive:true}); Object.assign(childEnv, {CI:'1',NEXT_TELEMETRY_DISABLED:'1',NO_COLOR:'1',TMP:taskTemp,TEMP:taskTemp});
Object.assign(childEnv, {M07_ARTICLE_SCAN_EVIDENCE:path.join(out,'article-scan-evidence.json'),M07_ARTICLE_TERMINAL_EVIDENCE:path.join(out,'article-terminal-evidence.json')});
const selectedHistorical = readFileSync(path.join(work,'historical-test-selection.txt'),'utf8').replace(/^\uFEFF/u,'').split(/\r?\n/u).filter(Boolean);
const addedTest = 'apps/admin/lib/writer-biography-machine-review.integration.test.ts';
const newOwned = git('ls-files','--others','--exclude-standard','-z').split('\0').filter(p=>/^(apps\/admin\/|scripts\/database\/|supabase\/migrations\/)/u.test(p));
const selected = [...new Set([...selectedHistorical.filter(name=>existsSync(path.join(root,name))), addedTest, 'apps/admin/lib/site-copy-machine-review.integration.test.ts', 'apps/admin/lib/site-copy-private-recovery-page.integration.test.ts', 'apps/admin/lib/profile-library-batch-budgets.integration.test.ts', 'apps/admin/lib/translation-response-artifacts.integration.test.ts', 'apps/admin/lib/writer-translation-operation-rpc.integration.test.ts', 'apps/admin/lib/writer-admission.integration.test.ts', 'apps/admin/lib/writer-admission-routing.integration.test.ts', 'apps/admin/lib/catalog-translation-operation-rpc.integration.test.ts', 'apps/admin/lib/catalog-admission.integration.test.ts', 'apps/admin/lib/catalog-admission-routing.integration.test.ts', 'apps/admin/lib/catalog-translation-candidate-freshness-rpc.integration.test.ts', 'apps/admin/lib/catalog-review-full-seed.integration.test.ts', ...newOwned.filter(name=>/\.test\.tsx?$/u.test(name))])];
const missing = selectedHistorical.filter(name=>!existsSync(path.join(root,name)));

function snapshot(name) {
  const currentOwned = git('ls-files','--others','--exclude-standard','-z').split('\0').filter(p=>/^(apps\/admin\/|scripts\/database\/|supabase\/migrations\/)/u.test(p));
  const paths = [...new Set([...git('ls-files','-z').split('\0').filter(Boolean),...newOwned,...currentOwned])].sort();
  const files = paths.map(filename => {
    const full = path.join(root,filename);
    if(!existsSync(full)) return {path:filename,missing:true};
    return {path:filename,size:statSync(full).size,sha256:hash(readFileSync(full))};
  });
  const validationFiles = files.filter(file=>!file.path.startsWith('docs/'));
  const value = {validationSourceCount:validationFiles.length,validationSourceSha256:hash(JSON.stringify(validationFiles)),validationComparisonExclusion:'docs/ only; full files remain in snapshot and document drift is reported separately',newOwnedFiles:currentOwned,schemaVersion:1,capturedAt:new Date().toISOString(),head:git('rev-parse','HEAD'),branch:git('branch','--show-current'),trackedFileCount:files.length,aggregateSha256:hash(JSON.stringify(files)),status:git('status','--porcelain=v1','--untracked-files=all'),files};
  write(name,value);
  return value;
}

async function run(id,args,cwd=root) {
  const logPath=path.join(out,`${id}.log`);
  if(existsSync(logPath)) throw Error('Never replace an earlier verification log');
  writeFileSync(logPath,'');
  const {appendFileSync} = await import('node:fs');
  const start=new Date();
  const receipt = {schemaVersion:1,id,head,executable:process.execPath,args,cwd,startedAt:start.toISOString(),log:logPath,environmentPolicy:'Allow only OS/runtime paths; CI=1, NEXT_TELEMETRY_DISABLED=1, NO_COLOR=1. No credentials inherited.',status:'RUNNING'};
  write(`${id}-receipt.json`,receipt);
  console.log(`START ${id} ${receipt.startedAt}`);
  return await new Promise(resolve=>{
    const child=spawn(process.execPath,args,{cwd,env:childEnv,windowsHide:true,stdio:['ignore','pipe','pipe']});
    Object.assign(receipt,{runnerPid:process.pid,childPid:child.pid});write(`${id}-receipt.json`,receipt);
    child.stdout.on('data',chunk=>appendFileSync(logPath,chunk));
    child.stderr.on('data',chunk=>appendFileSync(logPath,chunk));
    child.once('error',error=>{receipt.spawnError=String(error);});
    child.once('close',(code,signal)=>{
      Object.assign(receipt,{finishedAt:new Date().toISOString(),durationMs:Date.now()-start.valueOf(),exitCode:code,signal,status:code===0?'PASS':'FAIL',logSha256:hash(readFileSync(logPath))});
      write(`${id}-receipt.json`,receipt);
      console.log(`END ${id} ${receipt.status} exit=${code} durationMs=${receipt.durationMs}`);
      resolve(receipt);
    });
  });
}

const mode=process.argv[2];
if(mode==='prepare') {
  if(existsSync(path.join(out,'source-before.json'))) throw Error('Use a new immutable run directory');
  const patchPath='docs/admin-r3-evidence/2026-10-09-handoff/independent-telegram.patch';
  const patch=readFileSync(path.join(root,patchPath));
  const patchFiles=[...patch.toString('utf8').matchAll(/^diff --git a\/(.+) b\/(.+)$/gmu)].map(m=>m[2]);
  const manifest={head,addedCurrentFile:addedTest,note:'Current baseline196 plus all maintained continuation, stable library and stable writer/country profile suites including task-owned JSON test inputs; distinct from historical mixed 197-file/5982-test selection',historicalSelectionCount:selectedHistorical.length,currentSelectionCount:selected.length,missingHistoricalFiles:missing,selectedFiles:selected,historicalSelectionSha256:hash(readFileSync(path.join(work,'historical-test-selection.txt'))),independentTelegramPatch:{path:patchPath,sha256:hash(patch),applied:false,paths:patchFiles,existingSelectedPaths:patchFiles.filter(p=>selected.includes(p)),note:'Historical mixed working-tree coverage included separate Telegram changes. The current committed branch does not include that patch. The missing Telegram footer file is excluded and existing inherited Telegram files run as committed; this is not the identical historical 197-file/5982-test coverage.'}};
  write('selection-manifest.json',manifest);
  writeFileSync(path.join(out,'current-test-selection.txt'),selected.join('\n')+'\n');
  const snap=snapshot('source-before.json');
  write('runtime.json',{node:process.version,executable:process.execPath,platform:process.platform,arch:process.arch,head,runnerSha256:hash(readFileSync(fileURLToPath(import.meta.url)))});
  console.log(JSON.stringify({head,historical:selectedHistorical.length,current:selected.length,missing,trackedFileCount:snap.trackedFileCount,aggregateSha256:snap.aggregateSha256,status:snap.status},null,2));
} else if(mode==='focused') {
  const names=['apps/admin/lib/premium-translation-review.integration.test.ts','apps/admin/lib/country-profile-machine-review.integration.test.ts','apps/admin/lib/literary-work-machine-review.integration.test.ts','apps/admin/lib/country-translation-source-binding.integration.test.ts','apps/admin/lib/writer-biography-machine-review.integration.test.ts','apps/admin/app/(dashboard)/site-copy/site-copy-load-errors.integration.test.ts','apps/admin/lib/site-copy-machine-review.integration.test.ts','apps/admin/lib/site-copy-storage.test.ts','apps/admin/lib/site-copy-runtime-coverage.test.ts'];
  const result=await run('focused-tests',[path.join(root,'node_modules/vitest/vitest.mjs'),'run',...names,'--maxWorkers=2','--reporter=json','--outputFile='+path.join(out,'focused-tests.raw.json')]);process.exitCode=result.exitCode===0?0:1;
} else if(mode==='tests') {
  const receipt=await run('selected-tests',[path.join(root,'node_modules/vitest/vitest.mjs'),'run',...selected,'--maxWorkers=2','--reporter=json',`--outputFile=${path.join(out,'selected-tests.raw.json')}`]);
  if(existsSync(path.join(out,'selected-tests.raw.json'))) {
    const raw=JSON.parse(readFileSync(path.join(out,'selected-tests.raw.json'),'utf8'));
    write('selected-tests-summary.json',{head,exitCode:receipt.exitCode,success:raw.success,numTotalTestSuites:raw.numTotalTestSuites,numPassedTestSuites:raw.numPassedTestSuites,numFailedTestSuites:raw.numFailedTestSuites,numTotalTests:raw.numTotalTests,numPassedTests:raw.numPassedTests,numFailedTests:raw.numFailedTests,numPendingTests:raw.numPendingTests,numTodoTests:raw.numTodoTests,testFileCount:raw.testResults?.length,failedFiles:raw.testResults?.filter(r=>r.status!=='passed').map(r=>({name:r.name,status:r.status,message:r.message,assertionFailures:r.assertionResults?.filter(a=>a.status==='failed').map(a=>({fullName:a.fullName,failureMessages:a.failureMessages}))}))});
  }
  snapshot('source-after-tests.json');
  process.exitCode=receipt.exitCode===0?0:1;
} else if(mode==='gates') {
  const npmCli=path.join(path.dirname(process.execPath),'node_modules/npm/bin/npm-cli.js');
  const admin=path.join(root,'apps/admin');
  const adminRequire=createRequire(path.join(admin,'package.json'));
  const tsc=path.join(path.dirname(adminRequire.resolve('typescript/package.json')),'bin/tsc');
  const receipts=[];
  receipts.push(await run('gate-admin-build',[npmCli,'run','admin:build']));
  receipts.push(await run('gate-admin-typescript',[tsc,'--noEmit','--incremental','false'],admin));
  receipts.push(await run('gate-cloudflare-typescript',[tsc,'--project','tsconfig.cloudflare.json','--incremental','false'],admin));
  receipts.push(await run('gate-client-secrets',[path.join(root,'scripts/check-admin-client-secrets.mjs')]));
  receipts.push(await run('gate-readonly-hyphens',[path.join(root,'scripts/normalize-short-hyphens.mjs')]));
  const before=JSON.parse(readFileSync(path.join(out,'source-before.json'),'utf8'));
  const after=snapshot('source-after-gates.json');
  const original = new Map(before.files.map(f=>[f.path,f]));
  const allChanged = after.files.filter(f=>JSON.stringify(original.get(f.path))!==JSON.stringify(f));
  const changed = allChanged.filter(f=>!f.path.startsWith('docs/'));
  const documentChanges = allChanged.filter(f=>f.path.startsWith('docs/'));
  const protectedPaths = ['scripts/normalize-short-hyphens.mjs','scripts/lib/short-hyphens.mjs','scripts/lib/literary-news-media.test.mjs','scripts/lib/literary-news-social.mjs','scripts/lib/literary-news-social.test.mjs','scripts/lib/literary-news-text-fallback.test.mjs','scripts/workers/literary-news-delivery-worker.test.mjs'];
  write('excluded-source-protection.json',{head,paths:protectedPaths.map(p=>({path:p,before:original.get(p)?.sha256,after:after.files.find(f=>f.path===p)?.sha256,unchanged:original.get(p)?.sha256===after.files.find(f=>f.path===p)?.sha256})),telegramFooterStillAbsent:!existsSync(path.join(root,'scripts/lib/literary-news-telegram-footer.test.mjs')),normalizerWriteFlagUsed:false});
  write('source-drift.json',{comparisonExclusion:'docs/ only',fullSnapshotFileCount:after.files.length,validationSourceCount:after.validationSourceCount,validationSourceSha256Before:before.validationSourceSha256,validationSourceSha256After:after.validationSourceSha256,documentChanges,allChanged,headBefore:before.head,headAfter:after.head,aggregateBefore:before.aggregateSha256,aggregateAfter:after.aggregateSha256,changed,zeroValidationSourceDrift:changed.length===0,zeroTrackedFileDrift:allChanged.length===0,gitStatusAfter:after.status});
  write('gates-summary.json',{head,passed:receipts.filter(r=>r.status==='PASS').length,total:receipts.length,receipts:receipts.map(({id,status,exitCode,durationMs})=>({id,status,exitCode,durationMs})),zeroValidationSourceDrift:changed.length===0,zeroTrackedFileDrift:allChanged.length===0,documentChanges:documentChanges.map(f=>f.path)});
  process.exitCode=receipts.every(r=>r.status==='PASS')?0:1;
} else throw new Error('Use prepare, tests, or gates');
