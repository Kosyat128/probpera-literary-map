from pathlib import Path
import datetime, hashlib, json, zipfile

work=Path(__file__).resolve().parent
repo=work.parent/'probpera-literary-map'
out=work/'site-copy-durable-final-validation-v1'
folder=repo/'docs/admin-r3-evidence/2026-10-30-site-copy-durable-admission'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda name:json.loads((out/name).read_text(encoding='utf-8-sig'))
def write(name,value):
    target=out/name
    assert not target.exists(),target
    target.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

before,after_tests,after_gates=[read(n) for n in ['source-before.json','source-after-tests.json','source-after-gates.json']]
fingerprint='8e5c3553807cef985efb3e05adf585df10b30953f986d6ce2ee184858492f9ab'
assert before['validationSourceSha256']==after_tests['validationSourceSha256']==after_gates['validationSourceSha256']==fingerprint
assert before['files']==after_tests['files']==after_gates['files']
assert before['head']==after_tests['head']==after_gates['head']=='acb910d89133396e8e9794e91bd5db74128dab3b'
assert before['validationSourceCount']==10493 and before['trackedFileCount']==10720
selection=read('selection-manifest.json')
tests,receipt,gates,drift=[read(n) for n in ['selected-tests-summary.json','selected-tests-receipt.json','gates-summary.json','source-drift.json']]
assert selection['currentSelectionCount']==tests['testFileCount']==219
assert tests['numTotalTests']==7193 and tests['numPassedTests']==7187 and tests['numFailedTests']==6
assert tests['numPendingTests']==tests['numTodoTests']==0
assert receipt['finishedAt'] and receipt['exitCode']==1
assert gates['passed']==4 and gates['total']==5 and drift['zeroValidationSourceDrift'] and drift['zeroTrackedFileDrift']
assert all(row['status']=='PASS' or row['id']=='gate-readonly-hyphens' for row in gates['receipts'])
protection,increment=read('baseline-preservation.json'),read('increment-source-comparison.json')
assert protection['pass'] and increment['status']=='PASS'
assert len(increment['changedExisting'])==16 and len(increment['added'])==17 and not increment['removed']
assert increment['unchangedOriginalSourceCount']==10460

prior=repo/'docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/whole-validation-evidence.zip'
assert sha(prior.read_bytes())=='b66820cc11c51824d68a1c59968bd34077e18c52eb96f06dcd14f1c84a535326'
with zipfile.ZipFile(prior) as z:
    old_tests_bytes=z.read('final/selected-tests-summary.json')
    old_tests=json.loads(old_tests_bytes)
    old_readonly=z.read('reused-checks-v3/gate-readonly-hyphens.log')
def failures(report):
    return sorted([{'fullName':case['fullName'],'firstErrors':[text.replace('\r\n','\n').split('\n')[0] for text in case.get('failureMessages',[])]}
        for file in report.get('failedFiles',[]) for case in file.get('assertionFailures',[])],key=lambda row:row['fullName'])
assert failures(tests)==failures(old_tests) and len(failures(tests))==6
readonly=(out/'gate-readonly-hyphens.log').read_bytes()
assert readonly==old_readonly
assert sum(line.startswith('- ') for line in readonly.decode('utf-8-sig').splitlines())==41
write('baseline-failure-comparison.json',{'sameSixCasesAndFirstErrors':True,'baselineArchiveSha256':sha(prior.read_bytes()),
    'prior':failures(old_tests),'current':failures(tests),'scope':'Original missing M02 BEFORE files remain absent; no reconstruction, skip or weakened assertion.'})
write('readonly-baseline-comparison.json',{'byteIdenticalToPriorFinalBaseline':True,'findingCount':41,'sha256':sha(readonly),'normalizerWriteFlagUsed':False})

ui_readback=json.loads((work/'site-copy-ui-packet-independent-readback.json').read_text(encoding='utf-8'))
native_readback=json.loads((work/'site-copy-native-packet-independent-readback.json').read_text(encoding='utf-8'))
assert ui_readback['payloadsVerified']==142 and ui_readback['currentSourceBindingsVerified']==79 and ui_readback['distinctPassedCases']==389
assert native_readback['payloadsVerified']==1642 and native_readback['physicalSourcesVerified']==59 and native_readback['frozenFingerprint']==fingerprint
assert native_readback['nativeRows']==196 and native_readback['actualTypedWrappers']==8 and native_readback['nativeRealJsBuilderParityCases']==1
native=json.loads((work/'site-copy-admission-sql-native/final_v1/native-summary.json').read_text(encoding='utf-8-sig'))
sdk=(work/'site-copy-durable-tests-sol/native-final-v1/conformance.json').read_bytes()
assert sha(sdk)=='1997844ec7a936ef5ad06ec94e33f6e7a0b447e644077253039bdbe26aab518c'
assert native['concurrency']['pass']==12 and native['concurrency']['fail']==0 and native['postCleanupLiveness']['listenerCount']==0
external=[]
for name,expected in [('site-copy-ui-evidence.zip','e63c52edb96360435dfa2eb3509bebf96921c1c2ccc54926123ac5a564e14be1'),
    ('sql-evidence.zip','0449763c0f5a507b476a5e8401c27b0d9cc8ae10ed636851557e12672e476659'),
    ('site-copy-durable-controlled-tests.zip',None)]:
    file=folder/name
    data=file.read_bytes()
    if expected:assert sha(data)==expected
    external.append({'path':file.relative_to(repo).as_posix(),'bytes':len(data),'sha256':sha(data)})
genuine_before=repo/'docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/next-retry-partial-before.zip'
assert sha(genuine_before.read_bytes())=='cf1a17f1033b1ab3bec07cf484c6d0ad1bec9a5dadfd800199d397bd58805b3b'
external.append({'path':genuine_before.relative_to(repo).as_posix(),'bytes':genuine_before.stat().st_size,'sha256':sha(genuine_before.read_bytes())})
external.append({'path':prior.relative_to(repo).as_posix(),'bytes':prior.stat().st_size,'sha256':sha(prior.read_bytes())})
summary={'schemaVersion':1,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':before['head'],
    'classification':'LOCAL_DURABLE_SITE_COPY_INCREMENT_VERIFIED_WITH_EXACT_KNOWN_BASELINE_FAILURES_NOT_FULL_M07_M24_R3_ACCEPTANCE',
    'source':{'fingerprint':fingerprint,'nonDocFiles':10493,'fullFrozenEntries':10720,'changedVersus1af':16,'addedVersus1af':17,
        'previousFilesExact':10460,'zeroSourceDrift':True,'allFullInputEntryArraysIdentical':True},
    'tests':{'files':219,'total':7193,'passed':7187,'failed':6,'pending':0,'todo':0,'sameSixHistoricalM02Failures':True,'durationMs':receipt['durationMs']},
    'gates':{**gates,'readonlyFindings':41,'readonlyLogByteIdenticalToPreviousFinalBaseline':True},
    'protection':{'normalizers':4,'rulesAndTests':19,'normalizerImportCallScopes':16,'oldMigrations':72,'telegramPaths':6,'packageFiles':3,'allExact':True},
    'native':{'wireRecords':196,'typedWrappers':8,'realJsRetainedBuilderParityCases':1,'concurrencyGroups':12,'oldFunctionsExact':186,
        'oldTargetTableMetadataExact':8,'oldRelationsExact':53,'rolesExact':19,'indexCounts':[35,36],'triggerCounts':[22,27],
        'constraintCounts':[95,96],'advisors':native['securityAdvisors'],'clientsTerminal':26,'ownedServerStopped':True,
        'externalFinalSdkReportSha256':sha(sdk),'nativeOnlyArchiveIncludesFinalSdkReport':False},
    'ui':{'distinctLocalCasesPassed':389,'payloads':142,'sourceBindings':79,'classification':'Controlled/SSR; not browser or managed Auth E2E'},
    'externalArchives':external,
    'limits':['Native SQL uses an exact selected real old DDL foundation and synthetic Auth; SDK replay is a separately bound wire replay, not managed PostgREST/Auth/browser E2E.',
        'Most native source hashes intentionally remain opaque. One real JS-source/body/native cache case proves actual retained-candidate full parity; controlled helper cases cover real projection/hash behavior separately.',
        'The original genuine cf1/a63 BEFORE retains2 site-copy failures. Current unchanged oracle passes all22 checks; old66 complete assertions remain. One old site-copy numeric resume intent is explicitly superseded in addition to the earlier four library/profile intent exceptions.',
        'Initial native parse/fixture, concurrency-ready barrier and final short-path orchestration failures, and portableV1 missing-source failure remain retained with their original scope.',
        'Paid incomplete/unknown work is conservatively held. Trusted partial continuation, addressed nonarticle failed-item retry, broader budgets and all remaining M07/M24/M04/M02/M13/R3 acceptance remain pending.',
        'History-shaped guarded staff CAS save is covered; old direct site-copy history UPDATE remains denied and no managed history-read grants were invented.',
        'No keys/setup, paid provider, production migration/deploy, push, PR, mass backfill or actual social send occurred. Full26-module/230-criterion goal remains active.']}
write('validation-summary.json',summary)
entries={'final/'+p.name:p.read_bytes() for p in out.iterdir() if p.is_file() and p.suffix in ['.json','.log','.txt']}
for name in ['site-copy-durable-final-validation-v1-runner.mjs','site-copy-durable-final-validation-v1-runner.before-sidecars.mjs',
    'site-copy-durable-preservation-v1.mjs','site-copy-durable-increment-comparison-v1.mjs','package-site-copy-durable-final-validation-v1.py',
    'verify-site-copy-ui-packet.py','verify-site-copy-native-packet.py']:
    entries['runners/'+name]=(work/name).read_bytes()
for name in ['site-copy-ui-packet-independent-readback.json','site-copy-native-packet-independent-readback.json']:
    entries['root/'+name]=(work/name).read_bytes()
for p in (work/'site-copy-unrelated-actions').iterdir():
    if p.is_file():entries['root/unrelated-actions/'+p.name]=p.read_bytes()
entries['root/native-summary-final.json']=(work/'site-copy-admission-sql-native/final_v1/native-summary.json').read_bytes()
entries['root/external-final-sdk-conformance.json']=sdk
entries['baseline/profile1af-tests-summary.json']=old_tests_bytes
entries['baseline/profile1af-readonly.log']=old_readonly
for p in folder.glob('*.receipt.json'):entries['external-receipts/'+p.name]=p.read_bytes()
entries['README.md']=('Local durable site-copy admission, response retention and owner recovery.\n\n'
    '219-file whole suite:7187/7193 PASS, exact6 inherited missing-original M02 failures, zero pending/todo. Four other gates PASS; readonly log remains exact41 inherited findings. No excluded normalizer changes.\n\n'
    '196 native records replay through installed SDK and all8 typed wrappers, with one actual real-JS retained/native-candidate parity case. Native12 concurrency groups pass; same-foundation186 old routines and existing table/security metadata remain exact.\n\n'
    'See final/validation-summary.json and external controlled/native/UI archives for precise scope and original failures. This is not full M07/M24/R3 acceptance or a managed Auth/browser run. Full goal remains active.\n').encode()
manifest={'schemaVersion':1,'sourceFingerprint':fingerprint,'classification':summary['classification'],
    'entries':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]}
entries['manifest.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
target=folder/'whole-validation-evidence.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(target) as z:
    for row in manifest['entries']:assert len(z.read(row['path']))==row['bytes'] and sha(z.read(row['path']))==row['sha256']
result={'archive':target.name,'sha256':sha(target.read_bytes()),'bytes':target.stat().st_size,'verifiedPayloads':len(manifest['entries']),
    'sourceFingerprint':fingerprint,'testFiles':219,'testsTotal':7193,'testsPassed':7187,'testsFailed':6,'sameSixHistoricalM02Failures':True,
    'gatesPassed':4,'gatesTotal':5,'readonlyBaselineFindings':41,'zeroSourceDrift':True}
receipt_target=folder/'whole-validation-evidence.receipt.json'
assert not receipt_target.exists()
receipt_target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
