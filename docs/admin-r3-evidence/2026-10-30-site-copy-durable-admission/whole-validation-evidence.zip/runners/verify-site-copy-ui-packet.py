from pathlib import Path, PurePosixPath
import datetime, hashlib, json, zipfile
work=Path(__file__).resolve().parent
repo=(work/'../probpera-literary-map').resolve()
archive=work/'site-copy-engine-sol/site-copy-ui-evidence.zip'
sha=lambda b: hashlib.sha256(b).hexdigest()
assert sha(archive.read_bytes())=='e63c52edb96360435dfa2eb3509bebf96921c1c2ccc54926123ac5a564e14be1'
with zipfile.ZipFile(archive) as z:
    names=z.namelist()
    assert len(names)==len(set(names))==len({n.casefold() for n in names})==143
    for name in names:
        p=PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name
    manifest=json.loads(z.read('MANIFEST.json'))
    assert len(manifest['entries'])==manifest['payloadCount']==142
    assert set(names)=={r['path'] for r in manifest['entries']}|{'MANIFEST.json'}
    for row in manifest['entries']:
        data=z.read(row['path'])
        assert len(data)==row['bytes'] and sha(data)==row['sha256'], row['path']
    bindings=json.loads(z.read('SOURCE_BINDINGS.json'))
    assert len(bindings['sources'])==bindings['sourceCount']==79
    for row in bindings['sources']:
        local=(repo/row['file']).resolve()
        assert local.is_relative_to(repo)
        data=local.read_bytes()
        assert data==z.read('current-sources/'+row['file'])
        assert len(data)==row['bytes'] and sha(data)==row['sha256'], row['file']
    reports=[]
    cases={}
    for name in names:
        if not name.endswith('.json'): continue
        data=json.loads(z.read(name))
        if not isinstance(data,dict) or 'numTotalTests' not in data or 'testResults' not in data: continue
        assert data['numFailedTests']==data['numPendingTests']==data.get('numTodoTests',0)==0
        for file in data['testResults']:
            for case in file.get('assertionResults',[]):
                assert case['status']=='passed'
                cases[(file['name'].replace('\\','/'),case['fullName'])]=True
        reports.append({'path':name,'total':data['numTotalTests'],'passed':data['numPassedTests']})
    assert len(cases)==389, (len(cases),reports)
result={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive':str(archive),'sha256':sha(archive.read_bytes()),'payloadsVerified':142,
        'currentSourceBindingsVerified':79,'rawReports':reports,'distinctPassedCases':389,
        'allPassedZeroPendingTodo':True,'classification':'INDEPENDENT_UI_PACKET_READBACK_AND_CURRENT_PHYSICAL_BINDING_CHECK_NOT_NATIVE_OR_BROWSER_E2E'}
target=work/'site-copy-ui-packet-independent-readback.json'
assert not target.exists()
target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
