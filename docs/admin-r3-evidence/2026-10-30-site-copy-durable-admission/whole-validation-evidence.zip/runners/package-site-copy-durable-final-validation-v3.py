"""V3 parent draft. Execute only after root whole/gates, current UI/control seal and review."""
from pathlib import Path
import datetime,hashlib,json,zipfile

work=Path(__file__).resolve().parent
repo=work.parent/'probpera-literary-map'
out=work/'site-copy-durable-final-validation-v3'
folder=repo/'docs/admin-r3-evidence/2026-10-30-site-copy-durable-admission'
testwork=work/'site-copy-durable-tests-sol'
stage=testwork/'package-stage-global-v3-final'
portable_output=stage/'replay-output-2026-10-30T13-55-17-689Z'
ui_path=testwork/'whole-v3-current-ui-proof/current-ui-subset.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
read=lambda n:load(out/n)
def write(name,data):
 p=out/name;assert not p.exists(),p
 p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

before,after_tests,after_gates=[read(n) for n in ['source-before.json','source-after-tests.json','source-after-gates.json']]
fingerprint='b0b79b534a1f02c326b951224d2b82482840c5397acb1d99afe7930532efda38'
assert all(s['validationSourceSha256']==fingerprint for s in [before,after_tests,after_gates])
assert all(s['head']=='acb910d89133396e8e9794e91bd5db74128dab3b' for s in [before,after_tests,after_gates])
assert all(s['validationSourceCount']==10493 and s['trackedFileCount']==10720 for s in [before,after_tests,after_gates])
non_doc=lambda s:[r for r in s['files'] if not r['path'].startswith('docs/')]
assert non_doc(before)==non_doc(after_tests)==non_doc(after_gates)
maps=[{r['path']:r for r in s['files']} for s in [before,after_tests,after_gates]]
changed=sorted(name for name in set().union(*[set(m) for m in maps]) if not maps[0].get(name)==maps[1].get(name)==maps[2].get(name))
assert changed==['docs/CODEX_ADMIN_EXECUTION_STATE.md'],changed
full_equal=before['files']==after_tests['files']==after_gates['files']
assert not full_equal
document_proof={'allFullInputEntryArraysIdentical':False,'nonDocInputEntryArraysIdentical':True,
 'allowedDocumentPath':'docs/CODEX_ADMIN_EXECUTION_STATE.md','actualChangedPaths':changed,
 'canonicalRows':{'before':maps[0][changed[0]],'afterTests':maps[1][changed[0]],'afterGates':maps[2][changed[0]]},
 'scope':'Original snapshots are not rewritten/relabelled. Canonical progress documentation changed after preparation; validation excludes docs/ only and code fingerprint staysb0b79.'}

selection,tests,receipt,gates,drift=[read(n) for n in ['selection-manifest.json','selected-tests-summary.json','selected-tests-receipt.json','gates-summary.json','source-drift.json']]
assert selection['currentSelectionCount']==tests['testFileCount']==219
assert tests['numTotalTests']==7193 and tests['numPassedTests']==7187 and tests['numFailedTests']==6
assert tests['numPendingTests']==tests['numTodoTests']==0
raw=read('selected-tests.raw.json')
count_keys=['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']
assert {k:raw[k] for k in count_keys}=={k:tests[k] for k in count_keys}
assert receipt['finishedAt'] and receipt['exitCode']==1 and '--maxWorkers=1' in receipt['args']
assert not any('testNamePattern' in arg for arg in receipt['args'])
assert gates['passed']==4 and gates['total']==5 and drift['zeroValidationSourceDrift']
assert drift['zeroTrackedFileDrift'] is False
assert sorted(r['path'] for r in drift['documentChanges'])==changed
assert sorted(gates['documentChanges'])==changed
assert all(r['status']=='PASS' or r['id']=='gate-readonly-hyphens' for r in gates['receipts'])
protection,increment=read('baseline-preservation.json'),read('increment-source-comparison.json')
assert protection['pass'] and increment['status']=='PASS'
assert len(increment['changedExisting'])==23 and len(increment['added'])==17 and not increment['removed']
assert increment['unchangedOriginalSourceCount']==10453

prior=repo/'docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/whole-validation-evidence.zip'
assert sha(prior.read_bytes())=='b66820cc11c51824d68a1c59968bd34077e18c52eb96f06dcd14f1c84a535326'
with zipfile.ZipFile(prior) as z:
 old_tests_bytes=z.read('final/selected-tests-summary.json');old_tests=json.loads(old_tests_bytes)
 old_readonly=z.read('reused-checks-v3/gate-readonly-hyphens.log')
def failures(report):
 return sorted([{'fullName':c['fullName'],'firstErrors':[t.replace('\r\n','\n').split('\n')[0] for t in c.get('failureMessages',[])]}
  for s in report.get('failedFiles',[]) for c in s.get('assertionFailures',[])],key=lambda r:r['fullName'])
raw_failures=sorted([{'fullName':c['fullName'],'firstErrors':[t.replace('\r\n','\n').split('\n')[0] for t in c.get('failureMessages',[])]}
 for s in raw['testResults'] for c in s['assertionResults'] if c['status']=='failed'],key=lambda r:r['fullName'])
assert raw_failures==failures(tests)
assert failures(tests)==failures(old_tests) and len(failures(tests))==6
readonly=(out/'gate-readonly-hyphens.log').read_bytes()
assert readonly==old_readonly and sum(line.startswith('- ') for line in readonly.decode('utf-8-sig').splitlines())==41

current398=read('domain398.raw.json');library=read('domain-library.raw.json')
assert current398['numTotalTests']==current398['numPassedTests']==398 and current398['numFailedTests']==current398['numPendingTests']==current398['numTodoTests']==0
assert library['numTotalTests']==library['numPassedTests']==117 and library['numFailedTests']==library['numPendingTests']==library['numTodoTests']==0
for name in ['domain398-receipt.json','domain-library-receipt.json']:
 r=read(name);assert r['exitCode']==0 and '--maxWorkers=1' in r['args']
 assert not any('testTimeout' in arg or 'testNamePattern' in arg for arg in r['args'])
review_audit=load(testwork/'review-domain-load-independent-static-audit/audit.json')
assert review_audit['source']['beforeSha256']=='c509886eb6f67124d10a95ad1cce068d556f4079ad165c5c2d1a433cd9f03649'
assert review_audit['source']['currentSha256']=='97b9886d62749873b61ad0afff8dd7dcd62d2d117b8d6fb21b23c3055ab9fc28'
assert all(review_audit['checks'].values())
assert maps[-1]['apps/admin/lib/premium-translation-review.ts']['sha256']==review_audit['source']['currentSha256']

portable=load(portable_output/'receipt.json');integrity=load(testwork/'portable-current-v3-source-integrity.json')
assert portable['globalSourceSha256']==integrity['globalSourceSha256']==fingerprint
assert len(portable['results'])==3 and all(r['status']==0 and r['error'] is None for r in portable['results'])
assert integrity['bindings']==151 and integrity['drift']==0
assert integrity['portableReceiptSha256']==sha((portable_output/'receipt.json').read_bytes())
sdk_path=portable_output/'native/conformance.json';sdk=sdk_path.read_bytes();sdk_data=json.loads(sdk)
assert sha(sdk)=='1b2b1b961753714bb44a9487618c4a5ef40ba76efedaeb9c5f85cc3cd48ad80c'
assert sdk_data['total']==sdk_data['passed']==196 and sdk_data['failed']==0 and sdk_data['builderParity']['status']=='passed'
assert sdk_data['builderParity']['positiveCases']==1
for r in sdk_data['currentSources']:
 assert r['sha256']==maps[-1][r['file']]['sha256']
ui=load(ui_path)
assert ui['globalSourceSha256']==fingerprint and ui['counts']=={'total':389,'passed':389,'failed':0,'pending':0,'todo':0,'files':6}
assert ui['wholeRawSha256']==sha((out/'selected-tests.raw.json').read_bytes())
assert ui['wholeCounts']=={k:raw[k] for k in count_keys}
assert {r['file'] for r in ui['historicalUiPacket']['currentDifferences']}=={'apps/admin/app/(dashboard)/translations/page.tsx','apps/admin/lib/premium-translation-review.ts'}
for r in ui['sources']:assert r['sha256']==maps[-1][r['file']]['sha256']

control_receipt=load(folder/'site-copy-durable-controlled-tests.receipt.json')
assert control_receipt['globalSourceSha256']==fingerprint
assert control_receipt['focused']['total']==control_receipt['focused']['passed']==398
assert control_receipt['portable']['commands']==control_receipt['portable']['passed']==3
assert control_receipt['portable']['nativeConformanceSha256']==sha(sdk)
assert control_receipt['nativeSdk']['total']==control_receipt['nativeSdk']['passed']==196
assert control_receipt['currentUi']['cases']==389 and control_receipt['currentUi']['subsetOfCurrentWhole'] is True
native_readback=load(work/'site-copy-native-packet-independent-readback.json')
assert native_readback['payloadsVerified']==1642 and native_readback['physicalSourcesVerified']==59
native=load(work/'site-copy-admission-sql-native/final_v1/native-summary.json')
assert native['concurrency']['pass']==12 and native['concurrency']['fail']==0 and native['postCleanupLiveness']['listenerCount']==0
with zipfile.ZipFile(folder/'sql-evidence.zip') as z:
 native_manifest=json.loads(z.read('manifest.json'))
 for r in native_manifest['physicalSources']:
  assert r['sha256']==maps[-1][r['file']]['sha256'] and r['bytes']==maps[-1][r['file']]['size']
external=[]
for name,expected in [('site-copy-ui-evidence.zip','e63c52edb96360435dfa2eb3509bebf96921c1c2ccc54926123ac5a564e14be1'),
 ('sql-evidence.zip','0449763c0f5a507b476a5e8401c27b0d9cc8ae10ed636851557e12672e476659'),
 ('site-copy-durable-controlled-tests.zip',control_receipt['sha256'])]:
 p=folder/name;b=p.read_bytes();assert sha(b)==expected
 external.append({'path':p.relative_to(repo).as_posix(),'bytes':len(b),'sha256':sha(b)})
genuine=repo/'docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/next-retry-partial-before.zip'
assert sha(genuine.read_bytes())=='cf1a17f1033b1ab3bec07cf484c6d0ad1bec9a5dadfd800199d397bd58805b3b'
external.extend([{'path':p.relative_to(repo).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in [genuine,prior]])

write('document-drift-comparison.json',document_proof)
write('baseline-failure-comparison.json',{'sameSixCasesAndFirstErrors':True,'baselineArchiveSha256':sha(prior.read_bytes()),'prior':failures(old_tests),'current':failures(tests),'scope':'Original missing M02 BEFORE files remain absent; no reconstruction, skip or weakened assertion.'})
write('readonly-baseline-comparison.json',{'byteIdenticalToPriorFinalBaseline':True,'findingCount':41,'sha256':sha(readonly),'normalizerWriteFlagUsed':False})
summary={'schemaVersion':1,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':before['head'],
 'classification':'LOCAL_SITE_COPY_V3_VERIFIED_WITH_EXACT_KNOWN_BASELINE_FAILURES_NOT_FULL_M07_M24_R3_ACCEPTANCE',
 'source':{'fingerprint':fingerprint,'nonDocFiles':10493,'fullFrozenEntries':10720,'changedVersus1af':23,'addedVersus1af':17,'previousFilesExact':10453,'zeroNonDocSourceDrift':True,'allFullInputEntryArraysIdentical':False,'allowedDocumentDrift':document_proof},
 'tests':{'files':219,'total':7193,'passed':7187,'failed':6,'pending':0,'todo':0,'sameSixHistoricalM02Failures':True,'durationMs':receipt['durationMs']},
 'gates':{**gates,'readonlyFindings':41,'readonlyLogByteIdenticalToPreviousFinalBaseline':True},
 'protection':{'normalizers':4,'rulesAndTests':19,'normalizerImportCallScopes':16,'oldMigrations':72,'telegramPaths':6,'packageFiles':3,'allExact':True},
 'currentFocused':{'cases':398,'passed':398,'rawSha256':sha((out/'domain398.raw.json').read_bytes()),'rerunAfterActualLazyReviewSourceChange':True},
 'currentOriginalLibrary':{'cases':117,'passed':117,'rawSha256':sha((out/'domain-library.raw.json').read_bytes()),'unchangedWholeFileAndDefaultTimeout':True},
 'currentPortable':{'commands':3,'passed':3,'actualPhysicalInputs':151,'drift':0,'newNativeSqlExecution':False},
 'native':{'wireRecords':196,'typedWrappers':8,'realJsRetainedBuilderParityCases':1,'concurrencyGroups':12,'oldFunctionsExact':186,'oldTargetTableMetadataExact':8,'oldRelationsExact':53,'rolesExact':19,'indexCounts':[35,36],'triggerCounts':[22,27],'constraintCounts':[95,96],'advisors':native['securityAdvisors'],'clientsTerminal':26,'ownedServerStopped':True,'freshCurrentSdkReportSha256':sha(sdk),'nativeOnlyArchiveIncludesFinalSdkReport':False,'preservationFoundation':'Same selected M24 fixture foundation before/after only; synthetic outbox/queue stub support and no editor_autosaves. Not actual M04 queue or whole production DB acceptance.'},
 'ui':{'currentWholeUiCases':389,'subsetNotExtraRun':True,'currentSourceFingerprint':fingerprint,'historicalFocusedCases':389,'historicalPayloads':142,'historicalSourceBindings':79,'historicalArchive':'site-copy-ui-evidence.zip','historicalDifferences':ui['historicalUiPacket']['currentDifferences'],'scope':'Currentwhole389 actual assertions +two freshafterAllgraphs/fullphysical bindings. Older e63 has page-copy and lazyreview differences; not browser/managedAuth or newpercasewire proof.'},
 'externalArchives':external,
 'limits':['Native SQL uses selected real DDL and syntheticAuth; SDK wire replay is separate, not managedPostgREST/Auth/browserE2E. ExactlyONE real-JS source/native candidate matches retainedbuilder; opaque hash fixtures are wire/guard controls.',
  'Native final foundation includes synthetic outbox/queue stub support and no editor_autosaves. The186 oldroutine exact comparison is against that same selected M24 fixture foundation before/after, not the actual M04 queue or whole production DB. Fresh M04/M20 proof requires actual20260814_publication_outbox_and_schema_health.sql and20260828_zz_editor_autosaves.sql foundations. No new M24 SQL retest is implied.',
  'Genuinecf1/a63 retains2sitecopyFAIL/9guardsPASS/11preservationPASS; CURRENT unchangedoracle22PASS. Originalold66 assertions/source-save7normalizer calls remain exact;5SSRsetups preserve732assertions/115casebodies.2sourceguards have3 declared matcher changes, not blanketunchanged-assertion scope.',
  'V1whole7121/7193 with72FAIL and V2whole7181/7193 with12FAIL remain immutable. V1 nine and V2 six default5s signatures are not hidden; isolated9 and repair204 are separate scopes with247diagnostic-unselected cases not claimed rerun. V3 actually reruns all7193 withmax1/default5s/no cache shortcut or permanent skip.',
  'V3 makes a real domain dependency change: reviewc509→97b removes eager sitecopyfreshness import and awaits SAME reader after existingcanPromote guard/inexistingtry.15otherfunctions andremainingbody/catch exact. Fresh398/library117/current3portable are new actual evidence; old398/portable are historical rather than reused after this drift. Native actual17 and packet59 inputs remain unchanged.',
  'Only canonical progress document differs across full snapshots. Non-doc arrays are byte-exact; before/afterfullarray equality is FALSE and no snapshot is relabeled. Sourcefingerprint excludes docs/ only.',
  'Paidpartial/unknown work is conservativelyheld. ExplicitpartialContinue/addressednonarticlefailedRetry/parameters andremainingM07/M24/M04/M02/M13/R3 acceptance stay pending. No full26module/230criterion completion.',
  'No keys/providerbilling/productionmigration/deploy/push/PR/massbackfill/actualsocialsend occurred.']}
write('validation-summary.json',summary)

entries={};names=set()
def put(name,data):
 assert name not in entries and name.casefold() not in names and not name.startswith('/') and '..' not in Path(name).parts and ':' not in name,name
 entries[name]=data;names.add(name.casefold())
def tree(source,prefix):
 assert source.is_dir(),source
 included=0
 for p in sorted(source.rglob('*')):
  if p.is_file() and p.suffix in ['.json','.log','.txt','.mjs','.cjs','.py','.ts','.tsx','.md'] and not any(x in ['temp','tmp','node_modules'] for x in p.relative_to(source).parts):
   put(prefix+'/'+p.relative_to(source).as_posix(),p.read_bytes());included+=1
 assert included>0,(source,'Required artifact tree may not be empty')
for p in sorted(out.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.txt']:put('final/'+p.name,p.read_bytes())
for n in ['site-copy-durable-final-validation-v1-runner.mjs','site-copy-durable-final-validation-v1-runner.before-sidecars.mjs','site-copy-durable-final-validation-v2-runner.mjs','site-copy-durable-final-validation-v3-runner.mjs','package-site-copy-durable-final-validation-v1.py','package-site-copy-durable-final-validation-v2.py','package-site-copy-durable-final-validation-v3.py','verify-site-copy-ui-packet.py','verify-site-copy-native-packet.py']:
 put('runners/'+n,(work/n).read_bytes())
for v in ['v1','v2']:
 source=work/('site-copy-durable-final-validation-'+v)
 for required in ['selected-tests.raw.json','selected-tests-receipt.json','source-before.json','source-after-tests.json']:assert (source/required).is_file(),source/required
 tree(source,'history/whole-'+v)
for n in ['site-copy-unrelated-actions','site-copy-source-guard-intents','site-copy-review-domain-load']:tree(work/n,'root/'+n)
tree(work/'site-copy-engine-sol/old-five-ssr-setup','root/five-old-SSR-preservation')
tree(testwork/'review-domain-load-independent-static-audit','root/independent-lazy-review-audit')
tree(testwork/'broad-v1-independent-failure-audit','root/independent-V1-failure-audit')
for n in ['site-copy-ui-packet-independent-readback.json','site-copy-native-packet-independent-readback.json']:put('root/'+n,(work/n).read_bytes())
for n in ['current-v2-recipe-static-review.json','v3-packaging-static-review.json']:
 put('root/recipe-static-reviews-before-hardening/'+n,(work/'site-copy-engine-sol'/n).read_bytes())
for n in ['prepare-controlled-current-v3.py','seal-controlled-current-v3.py','derive-current-ui-proof-v3.py']:
 put('root/current-controlled-recipes/'+n,(testwork/n).read_bytes())
put('root/broad-v2-six-timeout-history.json',(testwork/'broad-v2-six-timeout-history.json').read_bytes())
put('root/portable-current-v3-source-integrity.json',(testwork/'portable-current-v3-source-integrity.json').read_bytes())
put('root/current-native-sdk-conformance.json',sdk)
put('root/native-summary-final.json',(work/'site-copy-admission-sql-native/final_v1/native-summary.json').read_bytes())
tree(ui_path.parent,'root/current-whole-UI-subset')
put('baseline/profile1af-tests-summary.json',old_tests_bytes);put('baseline/profile1af-readonly.log',old_readonly)
selected=[s.strip() for s in (out/'current-test-selection.txt').read_text('utf-8').splitlines() if s.strip()]
assert len(selected)==219
for name in sorted(set(selected+[r['path'] for r in increment['changedExisting']+increment['added']])):
 data=(repo/name).read_bytes();assert sha(data)==maps[-1][name]['sha256']
 put('current-selected-and-increment/'+name,data)
for p in folder.glob('*.receipt.json'):put('external-receipts/'+p.name,p.read_bytes())
put('README.md',('CurrentV3 b0b79:7193cases/7187PASS/exact6originalM02FAIL/0pending. FourgatesPASS;readonly41inherited. Non-doc arrays exact; fullarrays differ ONLYcanonical progressdocs, explicitly retained.\n\nFresh398, unchangedlibrary117 and current3portablePASS after actual guarded lazyreview dependency change. Native196/all8wrappers+ONErealbuilder, native12races; current389UI belongs to actualwhole, no extra389run. PriorV1/V2failures/raw and historicale63UI/page+review differences preserved. See final/validation-summary.json. No fullM07/M24/R3 or managedAuth/browser/provider-invoice acceptance.\n').encode())
manifest={'schemaVersion':1,'sourceFingerprint':fingerprint,'classification':summary['classification'],'entries':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(entries.items())]}
put('manifest.json',(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
target=folder/'whole-validation-evidence.zip';assert not target.exists()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(entries.items()):z.writestr(name,data)
with zipfile.ZipFile(target) as z:
 assert len(z.namelist())==len(entries)==len(set(z.namelist()))==len({n.casefold() for n in z.namelist()})
 for r in manifest['entries']:
  b=z.read(r['path']);assert len(b)==r['bytes'] and sha(b)==r['sha256']
result={'archive':target.name,'sha256':sha(target.read_bytes()),'bytes':target.stat().st_size,'verifiedPayloads':len(manifest['entries']),'sourceFingerprint':fingerprint,'testFiles':219,'testsTotal':7193,'testsPassed':7187,'testsFailed':6,'sameSixHistoricalM02Failures':True,'gatesPassed':4,'gatesTotal':5,'readonlyBaselineFindings':41,'zeroNonDocSourceDrift':True,'allFullInputEntryArraysIdentical':False,'allowedDocumentDrift':changed}
p=folder/'whole-validation-evidence.receipt.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
