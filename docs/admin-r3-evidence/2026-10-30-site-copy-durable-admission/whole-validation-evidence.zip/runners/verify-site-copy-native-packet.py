from pathlib import Path, PurePosixPath
import datetime, hashlib, json, zipfile
work=Path(__file__).resolve().parent
repo=(work/'../probpera-literary-map').resolve()
archive=work/'site-copy-admission-native-evidence.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(archive.read_bytes())=='0449763c0f5a507b476a5e8401c27b0d9cc8ae10ed636851557e12672e476659'
frozen=json.loads((work/'site-copy-durable-final-validation-v1/source-before.json').read_text(encoding='utf-8'))
assert frozen['validationSourceSha256']=='8e5c3553807cef985efb3e05adf585df10b30953f986d6ce2ee184858492f9ab'
frozen_files={r['path']:r for r in frozen['files']}
with zipfile.ZipFile(archive) as z:
    names=z.namelist()
    assert len(names)==len(set(names))==len({n.casefold() for n in names})==1643
    for name in names:
        p=PurePosixPath(name)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in name and ':' not in name
    manifest=json.loads(z.read('manifest.json'))
    payloads=json.loads(z.read('payload-manifest.json'))
    assert len(payloads)==1642
    assert set(names)=={r['file'] for r in payloads}|{'payload-manifest.json'}
    for row in payloads:
        data=z.read(row['file'])
        assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['file']
    assert len(manifest['physicalSources'])==59
    for row in manifest['physicalSources']:
        data=(repo/row['file']).read_bytes()
        assert data==z.read('sources/'+row['file'])
        assert len(data)==row['bytes']==frozen_files[row['file']]['size']
        assert sha(data)==row['sha256']==frozen_files[row['file']]['sha256'],row['file']
    summary_bytes=z.read(manifest['nativeSummary'])
    assert sha(summary_bytes)=='df35f5f366c95fe643766059507bbd46d25de253fa50170ddefad03a35205f96'
    native=json.loads(summary_bytes)
    assert native['nativeWireRecords']==196
    assert native['concurrency']['pass']==12 and native['concurrency']['fail']==0
    assert len(native['concurrency']['groups'])==12 and all(r['pass'] for r in native['concurrency']['groups'].values())
    assert native['ownPsqlClientsTerminal']==26
    assert native['cleanup']['pgCtlExitCode']==0
    for key in ['cleanup','postCleanupLiveness']:
        assert native[key]['processRemains'] is native[key]['pidFileRemains'] is native[key]['serviceCreated'] is False
    assert native['postCleanupLiveness']['listenerCount']==0
    assert native['securityAdvisors']['sameFoundationExactJsonEquality'] and native['securityAdvisors']['newFindings']==0
    assert native['securityAdvisors']['beforeCount']==native['securityAdvisors']['afterCount']==15
    comparison=native['sameFoundationComparison']
    assert comparison['functions']['beforeCount']==186 and not comparison['functions']['changed'] and not comparison['functions']['removed']
    for kind in ['tables','relations','roles']:
        assert not comparison[kind]['added'] and not comparison[kind]['removed'] and not comparison[kind]['changed']
    assert comparison['indexes']['beforeCount']==35 and comparison['indexes']['afterCount']==36
    assert comparison['triggers']['beforeCount']==22 and comparison['triggers']['afterCount']==27
    wire=z.read(manifest['nativeFinalAscii'])
    assert wire.isascii() and len(json.loads(wire))==196
    assert sha(wire)=='fada405569b97282eb71e36f791ae315cf20e11cb94f0359ee862710954aad41'
    assert wire==(repo/'apps/admin/lib/fixtures/site-copy-translation-operation-native-goldens.json').read_bytes()
sdk_path=work/'site-copy-durable-tests-sol/native-final-v1/conformance.json'
sdk_bytes=sdk_path.read_bytes()
assert sha(sdk_bytes)=='1997844ec7a936ef5ad06ec94e33f6e7a0b447e644077253039bdbe26aab518c'
sdk=json.loads(sdk_bytes)
assert sdk['total']==sdk['passed']==len(sdk['results'])==196 and sdk['failed']==0 and all(r['pass'] for r in sdk['results'])
assert len(sdk['counts'])==8 and sum(sdk['counts'].values())==196
assert sdk['nativeInputSha256']==sha(wire)
assert sdk['builderParity']['status']=='passed' and sdk['builderParity']['positiveCases']==1
assert sdk['builderParity']['externalProviderCalls']==sdk['builderParity']['newBegin']==sdk['builderParity']['canonicalWrites']==0
for row in sdk['currentSources']:
    data=(repo/row['file']).read_bytes()
    assert sha(data)==row['sha256']==frozen_files[row['file']]['sha256']
    assert len(data)==row['bytes']==frozen_files[row['file']]['size']
result={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'classification':'INDEPENDENT_NATIVE_ARCHIVE_READBACK_FROZEN_SOURCE_AND_EXTERNAL_FINAL_SDK_BINDING_PASS',
    'archiveSha256':sha(archive.read_bytes()),'payloadsVerified':1642,'physicalSourcesVerified':59,
    'frozenFingerprint':frozen['validationSourceSha256'],'nativeRows':196,'actualTypedWrappers':8,
    'externalSdkReportSha256':sha(sdk_bytes),'nativeRealJsBuilderParityCases':1,'actualConcurrencyGroupsPassed':12,
    'ownClientsTerminal':26,'oldFunctionsExact':186,'oldTargetTablesExact':8,'oldRelationsExact':53,'rolesExact':19,
    'securityAdvisorsSame15ZeroNew':True,'ownedServerStoppedAndPortFreeProof':True,
    'scope':'Selected real SQL and synthetic Auth foundation; raw native wire through installed SDK is a separately bound replay, not a managed PostgREST/Auth/browser run. Original orchestration failures remain in the immutable archive.'}
target=work/'site-copy-native-packet-independent-readback.json'
assert not target.exists()
target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
