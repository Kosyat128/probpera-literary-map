import fs from 'node:fs';import path from 'node:path';import{createRequire}from'node:module';import{fileURLToPath}from'node:url';import{createHash}from'node:crypto';
const out=path.dirname(fileURLToPath(import.meta.url)),work=path.dirname(out),repo=path.resolve(work,'../probpera-literary-map');
const ts=createRequire(path.join(repo,'package.json'))('typescript'),sha=b=>createHash('sha256').update(b).digest('hex');
const baseline=JSON.parse(fs.readFileSync(path.join(work,'profile-stable-scan-final-validation-v4/source-before.json'),'utf8'));
if(baseline.validationSourceSha256!=='1af04f3230b3395637a3e06090c1b25c72c66735d4c185be36c626374e4df02e')throw Error('Wrong baseline');
const file='apps/admin/app/(dashboard)/translations/actions.ts',beforeBytes=fs.readFileSync(path.join(out,'baseline-actions.ts')),currentBytes=fs.readFileSync(path.join(repo,file));
if(sha(beforeBytes)!==baseline.files.find(r=>r.path===file).sha256)throw Error('Not the genuine baseline file');
function functions(bytes){const source=ts.createSourceFile(file,bytes.toString('utf8').replace(/\r\n?/gu,'\n'),ts.ScriptTarget.Latest,true);return new Map(source.statements.filter(ts.isFunctionDeclaration).map(n=>[n.name.text,n.getText(source)]));}
const original=functions(beforeBytes),current=functions(currentBytes);
const names=['translationsUrl','translatePremiumLibraryBatchAction','translatePremiumWriterBatchAction'];
const functionsChecked=names.map(name=>({name,unchanged:original.get(name)===current.get(name),before:original.get(name),after:current.get(name)}));
const paths=['apps/admin/app/(dashboard)/translations/country-actions.ts','apps/admin/app/(dashboard)/translations/article-actions.ts',
 'apps/admin/app/(dashboard)/translations/article-item-retry-action.ts','apps/admin/lib/library-translation-scan.ts','apps/admin/lib/profile-translation-scan.ts',
 'apps/admin/lib/writer-translation-operation.ts','apps/admin/lib/catalog-translation-operation.ts'];
const filesChecked=paths.map(file=>{const bytes=fs.readFileSync(path.join(repo,file)),old=baseline.files.find(r=>r.path===file);if(!old)throw Error('Missing original '+file);return{file,bytes:bytes.length,beforeSha256:old.sha256,currentSha256:sha(bytes),unchanged:old.sha256===sha(bytes)};});
const pass=functionsChecked.every(r=>r.unchanged)&&filesChecked.every(r=>r.unchanged);
const result={checkedAt:new Date().toISOString(),pass,baselineFingerprint:baseline.validationSourceSha256,
 baselineActionsSha256:sha(beforeBytes),currentActionsSha256:sha(currentBytes),comparison:'AST whole-function text after CRLF normalization; unrelated whole modules remain byte-exact',
 functionsChecked,filesChecked,scope:'Site-copy helper/actions/UI/read/review intentionally changed in this increment; this preserves separate library/profile/article behavior, not whole shared actions-file equality.'};
const target=path.join(out,'receipt.json');if(fs.existsSync(target))throw Error('Never replace an audit receipt');fs.writeFileSync(target,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({pass,functions:functionsChecked.length,wholeFiles:filesChecked.length,receiptSha256:sha(fs.readFileSync(target))}));process.exitCode=pass?0:1;
