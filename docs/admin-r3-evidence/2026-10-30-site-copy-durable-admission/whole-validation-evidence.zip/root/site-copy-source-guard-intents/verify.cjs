const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {createRequire}=require('node:module'),work=path.dirname(__dirname),repo=path.resolve(work,'../probpera-literary-map');
const ts=createRequire(path.join(repo,'package.json'))('typescript'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const frozen=JSON.parse(fs.readFileSync(path.join(work,'site-copy-durable-final-validation-v1/source-before.json'),'utf8'));
const names=['backfill-cursor','translation-operations'],results=[];
const replace=new Map([
 ['expect(fields).toHaveLength(5)','expect(fields).toHaveLength(4)'],
 ['expect(page).toContain("staff-runner")','expect(page).toContain("По кнопке запускается один ограниченный пакет.")'],
 ['expect(page).toContain("Service-role lease API")','expect(page).toContain("Продолжение использует сохранённую попытку или исходный список")'],
]);
function nodes(text,file){const source=ts.createSourceFile(file,text.replace(/\r\n?/gu,'\n'),ts.ScriptTarget.Latest,true),expects=[],cases=[];
 function visit(node){if(ts.isCallExpression(node)){const value=node.getText(source);
  if(/^expect\([\s\S]*\)\.(?:not\.)?[A-Za-z]+\(/u.test(value))expects.push(value);
  if(ts.isIdentifier(node.expression)&&node.expression.text==='it')cases.push(value);}
  ts.forEachChild(node,visit);}visit(source);return{expects,cases};}
for(const name of names){
 const file='apps/admin/app/(dashboard)/translations/'+name+'.source.test.ts';
 const beforeBytes=fs.readFileSync(path.join(__dirname,name+'.before.ts')),afterBytes=fs.readFileSync(path.join(repo,file));
 assert.equal(sha(beforeBytes),frozen.files.find(row=>row.path===file).sha256);
 const before=nodes(beforeBytes.toString(),file),after=nodes(afterBytes.toString(),file);
 let position=0,replaced=0;
 for(const original of before.expects){const expected=replace.get(original)||original;if(expected!==original)replaced++;
  const index=after.expects.findIndex((value,index)=>index>=position&&value===expected);assert.ok(index>=position,original);position=index+1;}
 const unchangedCases=before.cases.filter(value=>after.cases.includes(value)).length;
 assert.equal(before.cases.length,after.cases.length);
 results.push({file,beforeSha256:sha(beforeBytes),afterSha256:sha(afterBytes),originalCompleteAssertions:before.expects.length,
  replacementAssertions:replaced,remainingOriginalAssertionsPreservedInOrder:true,originalCases:before.cases.length,unchangedWholeCases:unchangedCases,
  declaredChangedCases:before.cases.length-unchangedCases});
}
const pageFile='apps/admin/app/(dashboard)/translations/page.tsx';
const beforePage=fs.readFileSync(path.join(__dirname,'page.before.tsx')),afterPage=fs.readFileSync(path.join(repo,pageFile));
assert.equal(sha(beforePage),frozen.files.find(row=>row.path===pageFile).sha256);
const old='Продолжение использует сохранённую попытку или исходный список; фоновое расписание запускается отдельно.';
const next='Продолжение использует сохранённую попытку или исходный список. По кнопке запускается один ограниченный пакет.';
assert.equal(beforePage.toString().replace(/\r\n?/gu,'\n').replace(old,next),afterPage.toString().replace(/\r\n?/gu,'\n'));
const report={classification:'DECLARED_SITE_COPY_PROTOCOL_AND_PLAIN_MANUAL_RUNNER_COPY_SOURCE_GUARD_INTENTS',
 baselineFingerprint:frozen.validationSourceSha256,results,
 page:{file:pageFile,beforeSha256:sha(beforePage),afterSha256:sha(afterPage),onlyQueueExplanatoryStringChanged:true},
 intents:['Four scan forms keep their cursors/manifests; site-copy has an explicit fresh UUID and no numeric BackfillCursorFields. The old fifth numeric form expectation is superseded; assertions for its fresh UUID are added.',
 'Queue explanation states the actual button-driven bounded package in plain language. Technical staff-runner/lease API labels are replaced, and actual addressed native marker/operation submission checks are added.'],
 limits:['No assertion deletion or generic count weakening: three exact replacements are declared, all other full matcher calls remain in order and five unrelated whole cases remain exact.',
 'This preserves source guards; actual SSR/resume/expense behavior has separate runtime tests.']};
assert.equal(results.reduce((total,row)=>total+row.replacementAssertions,0),3);
assert.equal(results.reduce((total,row)=>total+row.unchangedWholeCases,0),5);
const target=path.join(__dirname,'receipt.json');assert.equal(fs.existsSync(target),false);
fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({pass:true,files:2,declaredReplacements:3,wholeUnrelatedCasesExact:5,sha256:sha(fs.readFileSync(target))}));
