"""Seal only an already frozen, successfully replayed parent stage. No tests run here."""
import hashlib
import json
import pathlib
import re
import shutil
import sys
import zipfile

here = pathlib.Path(__file__).resolve().parent
repo = here.parent.parent / 'probpera-literary-map'
sha = lambda value: hashlib.sha256(value).hexdigest()
encode = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
read = lambda path: json.loads(pathlib.Path(path).read_bytes())
assert len(sys.argv) == 4, 'stage directory, portable receipt, destination evidence directory required'
stage, portable_path, destination = map(lambda value: pathlib.Path(value).resolve(), sys.argv[1:])
assert stage.parent == here
assert destination.is_relative_to((repo / 'docs/admin-r3-evidence').resolve())
metadata, portable = read(stage / 'STAGE.json'), read(portable_path)
assert metadata['classification'] == 'SITE_COPY_CONTROLLED_V3_FRESH_398_CURRENT_SOURCE_FROZEN_PENDING_PORTABLE_AND_WHOLE_UI'
assert portable['globalSourceSha256'] == metadata['globalSourceSha256']
assert portable['sourceInventorySha256'] == metadata['sourceInventorySha256']
assert len(portable['results']) == 3 + len(metadata['extraPortableCommands'])
assert all(row['status'] == 0 and row['error'] is None for row in portable['results'])
config = read(stage / 'PREPARATION-INPUTS.json')
snapshot = read(config['snapshot'])
assert snapshot['validationSourceSha256'] == metadata['globalSourceSha256']
frozen = {row['path']: row for row in snapshot['files']}
for row in metadata['sourceBindings']:
    value = (repo / row['file']).read_bytes()
    assert sha(value) == row['sha256'] == frozen[row['file']]['sha256']
    assert value == (stage / 'current' / row['file']).read_bytes()
integrity_path = here / 'portable-current-v3-source-integrity.json'
integrity = read(integrity_path)
assert integrity['globalSourceSha256'] == metadata['globalSourceSha256']
assert integrity['bindings'] == len(metadata['sourceBindings']) and integrity['drift'] == 0
assert integrity['portableReceiptSha256'] == sha(portable_path.read_bytes())
(stage / 'evidence' / 'portable-final-source-integrity.json').write_bytes(integrity_path.read_bytes())
assert sha(pathlib.Path(config['focusedRaw']).read_bytes()) == metadata['focusedRawSha256']
assert sha((stage/'replay-native.cjs').read_bytes()) == sha((here/'replay-native.cjs').read_bytes())
whole_dir=here.parent/'site-copy-durable-final-validation-v3'
whole=read(whole_dir/'selected-tests.raw.json')
whole_receipt=read(whole_dir/'selected-tests-receipt.json')
gates=read(whole_dir/'gates-summary.json')
assert whole['numTotalTests']==7193 and whole['numPassedTests']==7187 and whole['numFailedTests']==6
assert whole['numPendingTests']==whole['numTodoTests']==0 and whole_receipt['finishedAt']
assert gates['passed']==4 and gates['total']==5
after_gates=read(whole_dir/'source-after-gates.json')
assert after_gates['validationSourceSha256']==metadata['globalSourceSha256']
assert [r for r in snapshot['files'] if not r['path'].startswith('docs/')]==[r for r in after_gates['files'] if not r['path'].startswith('docs/')]
before_map={r['path']:r for r in snapshot['files']};after_map={r['path']:r for r in after_gates['files']}
doc_drift=sorted(name for name in set(before_map)|set(after_map) if before_map.get(name)!=after_map.get(name))
assert doc_drift==['docs/CODEX_ADMIN_EXECUTION_STATE.md']
def m02_identity(data):
    result=[]
    for suite in data['testResults']:
        for item in suite['assertionResults']:
            if item['status']!='failed':continue
            assert suite['name'].endswith('/apps/admin/app/(dashboard)/articles/article-operation-server.integration.test.ts')
            message='\n'.join(item['failureMessages']);assert 'ENOENT' in message
            match=re.search(r'\.tmp[\\/][^\'"\n]+',message);assert match
            result.append((item['fullName'],match.group(0).replace('\\','/')))
    return sorted(result)
old_whole=read(here.parent/'site-copy-durable-final-validation-v1/selected-tests.raw.json')
old_m02={'testResults':[s for s in old_whole['testResults'] if s['name'].endswith('/apps/admin/app/(dashboard)/articles/article-operation-server.integration.test.ts')]}
assert len(m02_identity(whole))==6 and m02_identity(whole)==m02_identity(old_m02)
ui_folder=here/'whole-v3-current-ui-proof'
ui=read(ui_folder/'current-ui-subset.json')
assert ui['globalSourceSha256']==metadata['globalSourceSha256']
assert ui['counts']=={'total':389,'passed':389,'failed':0,'pending':0,'todo':0,'files':6}
assert ui['wholeRawSha256']==sha((whole_dir/'selected-tests.raw.json').read_bytes())
assert {r['file'] for r in ui['historicalUiPacket']['currentDifferences']}=={'apps/admin/app/(dashboard)/translations/page.tsx','apps/admin/lib/premium-translation-review.ts'}
bound={r['file']:r for r in metadata['sourceBindings']}
for r in ui['sources']:
    assert r['sha256']==bound[r['file']]['sha256']==frozen[r['file']]['sha256']
shutil.copytree(ui_folder,stage/'ui/current-whole-V3-proof')
for name in ['selected-tests.raw.json','selected-tests-summary.json','selected-tests-receipt.json','gates-summary.json','source-after-tests.json','source-after-gates.json','source-drift.json','baseline-preservation.json','increment-source-comparison.json']:
    target=stage/'evidence/actual-whole-V3'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(whole_dir/name,target)
(stage/'support/current-V3').mkdir(parents=True,exist_ok=True)
(stage/'support/current-V3/seal-controlled-current-v3.py').write_bytes(pathlib.Path(__file__).read_bytes())

proof = stage / 'evidence/portable-staged-pass'
assert not proof.exists()
proof.mkdir(parents=True)
portable_output = pathlib.Path(portable['output'])
for file in portable_output.iterdir():
    if file.is_file():
        shutil.copyfile(file, proof / file.name)
for label, name in [('core', 'core/site-copy-admission-cases-report.json'), ('old66', 'old66/report.json'), ('native', 'native/conformance.json')]:
    shutil.copyfile(portable_output / name, proof / (label + '.json'))
native = read(proof / 'native.json')
assert native['passed'] == native['total'] == metadata['nativeSdk']['total'] and native['failed'] == 0
assert native['builderParity']['status'] == 'passed'
assert sha((proof/'native.json').read_bytes())==integrity['nativeConformanceSha256']=='1b2b1b961753714bb44a9487618c4a5ef40ba76efedaeb9c5f85cc3cd48ad80c'
assert native['runnerSha256']==sha((stage/'replay-native.cjs').read_bytes())
for label,key in [('core','sources'),('old66','sources'),('native','currentSources')]:
    replayed=read(proof/(label+'.json'))
    for row in replayed[key]:assert row['sha256']==bound[row['file']]['sha256']==frozen[row['file']]['sha256']
    if label!='native':assert all(row['pass'] for row in replayed['checks'])
metadata['classification'] = 'SITE_COPY_V3_FRESH_398_PORTABLE_PASS_CURRENT_WHOLE_UI_SOURCE_FROZEN_PENDING_INDEPENDENT_ZIP_READBACK'
metadata['portable'] = {'commands': len(portable['results']), 'passed': len(portable['results']),
    'sourceInventorySha256': metadata['sourceInventorySha256'],
    'scope': 'Captured core45/SAME22, original66 assertions and exact native wire through every real typed wrapper plus ONE actual native retained candidate. Raw focused and UI scopes are separate and overlap these.'}
metadata['currentWhole']={k:whole[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']}
metadata['currentUi']={'cases':389,'passed':389,'files':6,'subsetOfCurrentWhole':True,'newTestsExecutedByDerivation':0,'rawSubsetSha256':sha((ui_folder/'current-ui-subset.json').read_bytes()),'historicalDifferences':ui['historicalUiPacket']['currentDifferences']}
metadata['documentDrift']={'allFullInputEntryArraysIdentical':False,'nonDocInputEntryArraysIdentical':True,'allowedDocumentPaths':doc_drift}
metadata['portable']['nativeConformanceSha256']=sha((proof/'native.json').read_bytes())
metadata['nativeSdk']['currentConformanceSha256']=sha((proof/'native.json').read_bytes())
metadata['nativeSdk']['currentActualSourceCount']=len(native['currentSources'])
metadata['qualifications'].append('Old portableV1 missing-source failure, subsequent8e5 portable3PASS, V1whole72FAIL and V2whole12FAIL remain historical. Actual review source changed fromc509 to97b; CURRENT398 and all3portablecommands were freshly rerun onb0b. NativeSQL was not rerun. Current389UI derives from actualwholeV3, not an extra389run.')
metadata['qualifications'].append('Nativefinal uses the same selected M24 fixture foundation before/after, including synthetic outbox/queue stub support and no editor_autosaves.186oldroutine exact is not actual M04 queue/whole production DB acceptance. Fresh M04/M20 foundation proof requires actual20260814 publication outbox and20260828_zz_editor_autosaves; no M24 SQL retest is implied.')
(stage / 'STAGE.json').write_bytes(encode(metadata))
readme = f'''# Site-copy durable admission controlled evidence

The final focused scope passes {metadata['focused']['passed']}/{metadata['focused']['total']} with zero failures, pending or todo.
It includes 45 actual scenario groups and all 22 unchanged a63 oracle checks,
46 controlled journal API guards, 22 metadata freshness guards, all 66 original
private-review assertions, each of {metadata['nativeSdk']['total']} original native wire rows through its
corresponding actual typed wrapper, and ONE real-JS-source native candidate
through the unchanged production retained builder. Other opaque native fixture
hashes are wire/DTO controls, not helper end-to-end proof. UI 389 and old article 117
are separately scoped evidence and overlap the root whole run. CURRENT wholeV3
is7187/7193PASS with the exact6 inherited M02 failures and0pending/todo.
CURRENT389UI is a six-suite subset of that actualwhole, with2 freshautomatic
source graphs; no extra389run or per-case wire sidecar is fabricated. Olde63
UI packet differs at page-copy AND guarded domain-lazy review import.

Genuine cf1/a63 BEFORE is immutable. It retains 2 site-copy target failures,
9 other-domain guard passes and 11 canonical/publication preservation passes.
The separately versioned CURRENT observer keeps all 11 actual triggers and
unchanged a63 bytes; only the old diagnostic assertions requiring the defect
to make 3 calls are removed from the CURRENT observer. Original WIP capture is
not uniformly 1af: 41 of 44 entries match V2 and 3 support differences remain.
The separate original-observer CURRENT 44 binding matches 1af, as retained in cf1.

Unknown accepted work holds the fixed logical scope before current source,
block UUID, actor, model or feature changes. Complete acknowledged bodies recover
from the original source/configuration with no new BEGIN/provider request.
The original 1 attempt / 4 reservations / 45000 ms / 50 keys / 12000 tokens and optional-review
semantics are preserved. Reservations are distinct from confirmed external
delivery or invoices. Native authorization, full-row freshness, promotion and
concurrency proof remain separate from controlled SDK declarations.

The old 66 entire execution/assertion body and all original full assertions remain
unchanged. The old article 117 only adds a separately observed readonly metadata SDK
scope; domain spies, terminal wire counts and all case bodies remain unchanged.
All 7 protected source-save normalizer calls/imports/helper closures remain exact.
Actual source save and ordinary source publication still precede optional
translation. Machine completion never approves or publishes a candidate.

Current sources are physically captured and bound to the root frozen fingerprint
{metadata['globalSourceSha256']}. Every payload has a byte count and SHA256.
Run node REPLAY.cjs <absolute installed dependency checkout path>. Its strict
source mapper refuses uncaptured local app reads;declared installed package
identities must match. The three default commands replay captured core/SAME,
old 66 and every native typed wrapper. UI has no portable claim. Historical
startup, editing, harness and intermediate runs remain qualified and immutable.
The first portable V1 passed core/native but the strict mapper refused the
uncaptured old66 publicView source scripts/site-copy-overrides.mjs. That failed
output and source inventory are retained. V2 added actual bytes from its same
8e5 freeze and passed. A later real production dependency change means those
core/old66 reports are historical. CurrentV3 freshly reran398 and3portablecommands;
15otherreviewfunctions and the original guard/catch remain exact. NativeSQL
body/schema remains unchanged. V1whole72FAIL and V2whole12FAIL remain retained.
Full source arrays differ ONLY at canonical progress documentation; non-doc
arrays and code fingerprint remain exact. No snapshot was rewritten/relabelled.

No production/provider invoice, managed database/browser E2E, keys setup, push,
PR or full M07/M24/26-module/230-criterion R3 completion is claimed. The root whole
validation and gates are recorded separately.
'''
(stage / 'README.md').write_text(readme, encoding='utf-8')
payload = []
folded = set()
for file in sorted(stage.rglob('*')):
    if not file.is_file() or file.relative_to(stage).parts[0].startswith('replay-output-'):
        continue
    assert not file.is_symlink()
    name = file.relative_to(stage).as_posix()
    assert name.casefold() not in folded and '..' not in pathlib.PurePosixPath(name).parts and ':' not in name
    folded.add(name.casefold())
    if name == 'MANIFEST.json':
        continue
    value = file.read_bytes()
    payload.append({'path': name, 'bytes': len(value), 'sha256': sha(value)})
manifest = {'schemaVersion': 1, 'classification': 'SITE_COPY_DURABLE_ADMISSION_CONTROLLED_SOURCE_FROZEN_STAGE_REPLAY_PASS',
    'globalSourceSha256': metadata['globalSourceSha256'], 'currentSourceCount': len(metadata['sourceBindings']),
    'payloadCount': len(payload), 'payload': payload}
manifest_bytes = encode(manifest)
assert not (stage / 'MANIFEST.json').exists()
(stage / 'MANIFEST.json').write_bytes(manifest_bytes)
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'site-copy-durable-controlled-tests.zip'
assert not archive.exists(), 'Never overwrite sealed evidence'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for row in payload:
        output.write(stage / row['path'], row['path'])
    output.writestr('MANIFEST.json', manifest_bytes)
with zipfile.ZipFile(archive) as sealed:
    names = sealed.namelist()
    assert len(names) == len(set(names)) == len({name.casefold() for name in names}) == len(payload) + 1
    assert sealed.read('MANIFEST.json') == manifest_bytes
    for row in payload:
        value = sealed.read(row['path'])
        assert len(value) == row['bytes'] and sha(value) == row['sha256']
manifest_target = destination / 'site-copy-durable-controlled-tests.manifest.json'
receipt_target = destination / 'site-copy-durable-controlled-tests.receipt.json'
assert not manifest_target.exists() and not receipt_target.exists()
manifest_target.write_bytes(manifest_bytes)
receipt = {'classification': 'SEALED_SITE_COPY_CONTROLLED_TEST_EVIDENCE_PENDING_SEPARATE_INDEPENDENT_AUDIT',
    'zip': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()),
    'manifestSha256': sha(manifest_bytes), 'payloads': len(payload), 'archiveEntries': len(payload) + 1,
    'currentBindings': len(metadata['sourceBindings']), 'globalSourceSha256': metadata['globalSourceSha256'],
    'sourceInventorySha256': metadata['sourceInventorySha256'], 'focused': metadata['focused'], 'core': metadata['core'],
    'nativeSdk': metadata['nativeSdk'], 'portable': metadata['portable'], 'currentWhole':metadata['currentWhole'],
    'currentUi':metadata['currentUi'],'documentDrift':metadata['documentDrift'],'qualifications': metadata['qualifications']}
receipt_target.write_bytes(encode(receipt))
print(json.dumps({'archive': str(archive), 'bytes': receipt['bytes'], 'sha256': receipt['sha256'],
    'payloads': len(payload), 'currentBindings': receipt['currentBindings']}))
