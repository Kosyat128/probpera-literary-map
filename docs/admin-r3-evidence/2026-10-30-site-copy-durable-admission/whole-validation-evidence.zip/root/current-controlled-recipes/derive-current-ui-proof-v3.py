"""Derive a current UI subset from the completed whole run; never execute tests."""
import datetime,hashlib,json,pathlib,sys,zipfile
here=pathlib.Path(__file__).resolve().parent
work=here.parent
repo=work.parent/'probpera-literary-map'
assert len(sys.argv)==5,'whole-folder profile-read-graph.json sitecopy-read-graph.json output-folder'
whole,profile_graph,sitecopy_graph,out=[pathlib.Path(x).resolve() for x in sys.argv[1:]]
assert out.parent.is_relative_to(work.resolve()) and not out.exists()
read=lambda p:json.loads(pathlib.Path(p).read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
snapshot_path=whole/'source-before.json'
snapshot=read(snapshot_path)
frozen={r['path']:r for r in snapshot['files']}
raw_path=whole/'selected-tests.raw.json'
raw=read(raw_path)
receipt_path=whole/'selected-tests-receipt.json'
receipt=read(receipt_path)
assert receipt.get('finishedAt') and raw['numTotalTests']==7193
assert raw['numPendingTests']==raw['numTodoTests']==0
start=datetime.datetime.fromisoformat(receipt['startedAt'].replace('Z','+00:00')).timestamp()
end=datetime.datetime.fromisoformat(receipt['finishedAt'].replace('Z','+00:00')).timestamp()
cases={
 'apps/admin/app/(dashboard)/translations/library-scan-ui.integration.test.ts':52,
 'apps/admin/app/(dashboard)/translations/profile-scan-ui.integration.test.ts':92,
 'apps/admin/app/(dashboard)/translations/site-copy-operation-ui.integration.test.ts':87,
 'apps/admin/app/(dashboard)/translations/translations-load-errors.integration.test.ts':85,
 'apps/admin/app/(dashboard)/site-copy/site-copy-load-errors.integration.test.ts':69,
 'apps/admin/lib/site-copy-private-recovery-page.integration.test.ts':4,
}
selected=[]
for suite in raw['testResults']:
 relative=suite['name'].split('/probpera-literary-map/')[-1]
 if relative not in cases:continue
 assert len(suite['assertionResults'])==cases[relative]
 assert all(r['status']=='passed' for r in suite['assertionResults']),relative
 selected.append({'relativeFile':relative,'rawSuite':suite})
assert len(selected)==6 and sum(len(x['rawSuite']['assertionResults']) for x in selected)==389
out.mkdir()
bindings={}
def bind(name,expected=None,role='current-UI-physical-input'):
 value=(repo/name).read_bytes()
 observed=sha(value)
 assert observed==frozen[name]['sha256'],name
 if expected:assert observed==expected,name
 assert len(value)==frozen[name].get('size',frozen[name].get('bytes')),name
 if name in bindings:
  bindings[name]['roles']=sorted(set(bindings[name]['roles']+[role]));return
 target=out/'current-source'/name
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(value)
 bindings[name]={'file':name,'bytes':len(value),'sha256':observed,'roles':[role]}
graphs=[]
for label,p,test in [
 ('profile',profile_graph,'apps/admin/app/(dashboard)/translations/profile-scan-ui.integration.test.ts'),
 ('sitecopy',sitecopy_graph,'apps/admin/app/(dashboard)/translations/site-copy-operation-ui.integration.test.ts')]:
 data=read(p)
 assert start<=p.stat().st_mtime<=end+2,(p,'must be an actual fresh graph from this whole run')
 assert data['sourceDrift'] is False
 assert data['sourceCount']==len(data['sources'])
 for r in data['sources']:bind(r['file'],r['sha256'],'actual-'+label+'-whole-SSR-read-graph')
 if 'testFile' in data:bind(data['testFile']['file'],data['testFile']['sha256'],'actual-'+label+'-whole-test-source')
 else:bind(test,data['testFileSha256'],'actual-'+label+'-whole-test-source')
 if 'nativeFixture' in data:
  r=data['nativeFixture'];bind(r['file'],r['sha256'],'actual-profile-whole-native-JSON-input')
 target=out/(label+'-actual-read-graph.json');target.write_bytes(p.read_bytes())
 graphs.append({'mode':label,'originalPath':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'freshWithinWholeRun':True,'sourceCount':len(data['sources'])})
old=work/'site-copy-engine-sol/site-copy-ui-evidence.zip'
assert sha(old.read_bytes())=='e63c52edb96360435dfa2eb3509bebf96921c1c2ccc54926123ac5a564e14be1'
with zipfile.ZipFile(old) as z:historical=json.loads(z.read('SOURCE_BINDINGS.json'))
differences=[]
for r in historical['sources']:
 name=r.get('file',r.get('path',r.get('module')))
 bind(name,role='current-physical-UI-scope-from-qualified-historical-inventory')
 now=bindings[name]['sha256']
 if now!=r['sha256']:differences.append({'file':name,'historicalSha256':r['sha256'],'currentSha256':now})
assert len(historical['sources'])==79
assert {r['file'] for r in differences}=={
 'apps/admin/app/(dashboard)/translations/page.tsx','apps/admin/lib/premium-translation-review.ts'},differences
assert bindings['apps/admin/lib/premium-translation-review.ts']['sha256']=='97b9886d62749873b61ad0afff8dd7dcd62d2d117b8d6fb21b23c3055ab9fc28'
for name in cases:bind(name,role='actual-whole-six-UI-test-source')
result={'classification':'CURRENT_UI_389_DERIVED_SUBSET_OF_ACTUAL_WHOLE_V3_NOT_AN_EXTRA_RUN','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'globalSourceSha256':snapshot['validationSourceSha256'],'snapshotSha256':sha(snapshot_path.read_bytes()),'wholeRawPath':str(raw_path),'wholeRawSha256':sha(raw_path.read_bytes()),'wholeReceiptSha256':sha(receipt_path.read_bytes()),'wholeCounts':{k:raw[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests','numTodoTests']},'counts':{'total':389,'passed':389,'failed':0,'pending':0,'todo':0,'files':6},'suites':selected,'automaticActualGraphs':graphs,'currentSourceCount':len(bindings),'sources':sorted(bindings.values(),key=lambda r:r['file']),'historicalUiPacket':{'sha256':'e63c52edb96360435dfa2eb3509bebf96921c1c2ccc54926123ac5a564e14be1','sourceCount':79,'rawScope':'Historical389 actualPASS; not relabeled current after page explanatory copy and the genuine guarded domain-lazy review import changed. Both exact source proofs remain retained.','currentDifferences':differences},'testsExecutedByDerivation':0,'qualifications':['These389 cases are the actual selected suites inside finalwhole7193, not another389-run and not additive to whole counts.','Two afterAll read graphs come from this whole run and bind actual app/test/nativeJSON bytes. Other old UI test source inputs are frozen physical snapshots; no new per-case SDK wire sidecar is fabricated.','All six expose no enable-by-env evidence path. The private-recovery wrapper explicitly deletes its optional output-root env. No fs preload, new observer/cache, timeout, assertion or permanent skip change was introduced.','No portableUI/native/browser/provider-invoice/R3-completion claim. Remaining whole failures, if any, remain in wholeCounts and full original raw report.']}
p=out/'current-ui-subset.json'
p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'report':str(p),'sha256':sha(p.read_bytes()),'actualWholeUiCases':389,'newTestRuns':0,'currentBindings':len(bindings),'historicalDifferences':len(differences)}))
