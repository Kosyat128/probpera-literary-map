"""Parent-only preparation. Requires settled native/UI inputs and root source freeze.

No seal, replay, source edit or database work occurs in this script.
"""
import hashlib
import json
import pathlib
import re
import sys
import zipfile

here = pathlib.Path(__file__).resolve().parent
work, repo = here.parent, here.parent.parent / 'probpera-literary-map'
sha = lambda value: hashlib.sha256(value).hexdigest()
encode = lambda value: (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
read = lambda path: json.loads(pathlib.Path(path).read_bytes())
assert len(sys.argv) == 2, 'Provide the finalized packaging input JSON after root source freeze'
config = read(sys.argv[1])
assert config['classification'] == 'CURRENT_V3_FRESH_398_AND_GUARDED_DOMAIN_LAZY_SOURCE_FROZEN_PENDING_PORTABLE'
snapshot_path = pathlib.Path(config['snapshot'])
snapshot = read(snapshot_path)
fingerprint = config['globalSourceSha256']
assert snapshot['validationSourceSha256'] == fingerprint
frozen = {row['path']: row for row in snapshot['files']}
stage = (here / config['stageName']).resolve()
assert stage.parent == here, 'Stage must be a direct child of this parent work folder'
assert not stage.exists(), 'Use a new stage; preserve earlier prepared evidence'
stage.mkdir()
payload, casefold_names, sources = {}, set(), {}

def put(name, value):
    path = pathlib.PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and '\\' not in name and ':' not in name
    assert name not in payload and name.casefold() not in casefold_names, name
    target = stage / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(value)
    payload[name] = {'path': name, 'bytes': len(value), 'sha256': sha(value)}
    casefold_names.add(name.casefold())

def file(name, source):
    source = pathlib.Path(source)
    assert source.is_file() and not source.is_symlink(), source
    put(name, source.read_bytes())

def add_source(name, role, expected=None):
    name = name.replace('\\', '/')
    value = (repo / name).read_bytes()
    assert name in frozen and sha(value) == frozen[name]['sha256'], name
    assert len(value) == frozen[name].get('size', frozen[name].get('bytes')), name
    if expected:
        assert sha(value) == expected, name
    if name in sources:
        sources[name]['roles'] = sorted(set(sources[name]['roles'] + [role]))
        return
    sources[name] = {'file': name, 'bytes': len(value), 'sha256': sha(value), 'roles': [role]}
    put('current/' + name, value)

core = read(config['coreReport'])
focused = read(config['focusedRaw'])
native = read(config['nativeConformance'])
assert sha(pathlib.Path(config['nativeConformance']).read_bytes()) == '1997844ec7a936ef5ad06ec94e33f6e7a0b447e644077253039bdbe26aab518c'
assert native['runnerSha256'] == sha((here/'replay-native.cjs').read_bytes())
assert sha((repo/'apps/admin/lib/premium-translation-review.ts').read_bytes()) == '97b9886d62749873b61ad0afff8dd7dcd62d2d117b8d6fb21b23c3055ab9fc28'
golden_bytes = pathlib.Path(config['finalNativeGoldens']).read_bytes()
goldens = json.loads(golden_bytes)
assert all(row['pass'] for row in core['checks']) and len(core['checks']) == config['expectedCoreGroups']
assert focused['numFailedTests'] == focused['numPendingTests'] == focused['numTodoTests'] == 0
assert focused['numTotalTests'] == focused['numPassedTests'] == config['expectedFocusedCount']
assert native['total'] == native['passed'] == len(goldens) and native['failed'] == 0
assert native['nativeInputSha256'] == sha(golden_bytes)
assert native['builderParity']['status'] == 'passed' and native['builderParity']['positiveCases'] == 1
same = next(row['same'] for row in core['traces'] if row['name'].startswith('CURRENT executes all11'))
assert same['summary'] == {'checks': 22, 'pass': 22, 'fail': 0, 'targetFail': 0, 'preservationFail': 0, 'controlFail': 0}
for item in config['currentSourceReports']:
    if item.get('member'):
        archive_bytes = pathlib.Path(item['file']).read_bytes()
        assert sha(archive_bytes) == item['archiveSha256']
        with zipfile.ZipFile(item['file']) as archive:
            data = json.loads(archive.read(item['member']))
    else:
        data = read(item['file'])
    for row in data[item['rowsKey']]:
        add_source(row.get('file', row.get('module', row.get('path'))), item['role'], row['sha256'])
historical_ui_path=pathlib.Path(config['historicalUiPacket'])
assert sha(historical_ui_path.read_bytes()) == 'e63c52edb96360435dfa2eb3509bebf96921c1c2ccc54926123ac5a564e14be1'
with zipfile.ZipFile(historical_ui_path) as archive:
    historical_ui=json.loads(archive.read('SOURCE_BINDINGS.json'))
ui_differences=[]
for row in historical_ui['sources']:
    name=row.get('file',row.get('path',row.get('module')))
    add_source(name,'current-physical-UI-scope-with-qualified-historical-raw')
    current_sha=sources[name]['sha256']
    if current_sha!=row['sha256']:
        ui_differences.append({'file':name,'historicalSha256':row['sha256'],'currentSha256':current_sha})
assert {row['file'] for row in ui_differences} == {'apps/admin/app/(dashboard)/translations/page.tsx','apps/admin/lib/premium-translation-review.ts'}
for name in config.get('additionalCurrentInputs', []):
    add_source(name, 'declared-current-integration-input')
for name in ['package.json', 'package-lock.json', 'apps/admin/package.json']:
    add_source(name, 'unchanged-package-identity')
if config.get('incrementComparison'):
    delta = read(config['incrementComparison'])
    for row in delta['changedExisting'] + delta['added']:
        add_source(row['path'], 'root-declared-current-increment')

# Capture every explicit local CJS transport dependency; dynamic application
# dependencies remain bounded by actual read graphs and the strict replay mapper.
queue = [name for name in sources if name.endswith('.cjs')]
for name in queue:
    for match in re.finditer(r"require\(['\"](\.[^'\"]+)['\"]\)", (repo / name).read_text('utf-8')):
        base = (repo / name).parent / match.group(1)
        for suffix in ['', '.cjs', '.js']:
            target = pathlib.Path(str(base) + suffix).resolve()
            if target.is_file():
                relative = target.relative_to(repo.resolve()).as_posix()
                new = relative not in sources
                add_source(relative, 'explicit-local-CJS-support')
                if new and relative.endswith('.cjs'):
                    queue.append(relative)
                break

genuine_name = 'docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/next-retry-partial-before.zip'
genuine_bytes = (repo / genuine_name).read_bytes()
assert sha(genuine_bytes) == 'cf1a17f1033b1ab3bec07cf484c6d0ad1bec9a5dadfd800199d397bd58805b3b'
put('immutable/' + genuine_name, genuine_bytes)
with zipfile.ZipFile(repo / genuine_name) as archive:
    original = archive.read('partial-pass-safety.same-contract.cjs')
    assert sha(original) == 'a63a42d6b2870cd78dfb45cdf23683fac1ccc19079281fed6caa9595502bff45'
    put('genuine-before/exact-a63-oracle.cjs', original)
    for name in ['report.json', 'original-capture-runner.cjs', 'same-contract-original.json',
                 'post-original-global-v3-source-comparison.json', 'receipt.json', 'verification-summary.json']:
        put('genuine-before/' + name, archive.read(name))
for item in config['artifacts']:
    source, destination = pathlib.Path(item['source']), item['destination']
    if item.get('kind', 'file') == 'file':
        file(destination, source)
    else:
        assert source.is_dir()
        for item_path in sorted(source.rglob('*')):
            relative = item_path.relative_to(source)
            if not item_path.is_file() or any(part in ['temp', 'tmp', 'node_modules'] for part in relative.parts):
                continue
            if item_path.suffix not in ['.json', '.log', '.cjs', '.mjs', '.ts', '.tsx', '.md', '.txt', '.sql', '.zip']:
                continue
            file(destination + '/' + relative.as_posix(), item_path)
file('evidence/global/source-before.json', snapshot_path)
file('native/final-native-goldens.json', config['finalNativeGoldens'])
file('replay-native.cjs', here / 'replay-native.cjs')
file('REPLAY.cjs', here / 'portable-replay.cjs')
file('replay-location-preload.cjs', work / 'profile-stable-tests-sol/package-stage-v3/replay-location-preload.cjs')
rows = [sources[name] for name in sorted(sources)]
packages = []
for name in ['@supabase/supabase-js', 'typescript', 'zod', 'next', 'react', 'react-dom', 'cheerio', 'fflate', 'vitest']:
    value = (repo / 'node_modules' / name / 'package.json').read_bytes()
    packages.append({'name': name, 'version': json.loads(value)['version'], 'sha256': sha(value)})
metadata = {
    'classification': 'SITE_COPY_CONTROLLED_V3_FRESH_398_CURRENT_SOURCE_FROZEN_PENDING_PORTABLE_AND_WHOLE_UI',
    'globalSourceSha256': fingerprint, 'globalSnapshotSha256': sha(snapshot_path.read_bytes()),
    'sourceBindings': rows, 'sourceInventorySha256': sha(encode(rows)), 'packages': packages,
    'focused': {'total': focused['numTotalTests'], 'passed': focused['numPassedTests'], 'failed': 0, 'pending': 0, 'todo': 0},
    'focusedRawSha256':sha(pathlib.Path(config['focusedRaw']).read_bytes()),
    'historicalUiDifferences':ui_differences,
    'nativeOriginalEvidence':{'conformanceSha256':sha(pathlib.Path(config['nativeConformance']).read_bytes()),'scope':'Original native196 actual17 source inputs remain exact and native59 SQL/fixture inputs remain current. Fresh portable typed-wrapper replay will have its own raw report; no new native SQL execution.'},
    'core': {'groups': len(core['checks']), 'originalOracleChecks': 22, 'currentTargetFail': 0, 'genuineBeforeTargetFail': 2,
             'unchangedOtherDomainGuards': 9, 'canonicalPublicationPreservation': 11},
    'nativeSdk': {'total': len(goldens), 'passed': native['passed'], 'inputSha256': sha(golden_bytes),
                  'realSourceBuilderParity': native['builderParity'],
                  'scope': 'Every original native row passes installed SDK plus its actual corresponding typed wrapper; ONE real-JS-source stored native candidate also matches the actual retained builder. Other opaque native rows are not claimed helperE2E. SQL execution and races remain separate.'},
    'extraPortableCommands': config.get('extraPortableCommands', []),
    'qualifications': [
        'Genuine cf1 original WIP capture is not uniformly1af:41 of44 captured source entries match V2 and3 support differences are retained. Separate current44 original-observer bindings match1af. No source or original three-call diagnostic expectation was relabeled.',
        'Exact original a63 oracle remains unchanged. The CURRENT observer keeps all11 actual triggers, removing only original diagnostic expectations requiring the site-copy defect to cause3calls.',
        'Durable reservations differ from confirmed external dispatch/invoices. Refused native-shaped dispatch RPCs are not additional accepted reservations/provider calls.',
        'Historical startup/SDK/source-edit/harness failures and intermediate passing scopes remain separately qualified; no stale source is relabeled final.',
        'Genuine6b reviewc509 changed to97b only by removing the static site-copy freshness reader import and awaiting the same reader inside the original guarded try after canPromote.15other functions and remaining guard/catch body are exact. Current398 was rerun; old398/core/old66/portable8e5 raw are historical rather than reused after this actual source drift.',
        'Olde63 UI inventory now differs at exactly page explanatory copy and guarded domain-lazy review import. Current physical UI inputs are frozen; current389 assertions require the later actualwhole7193 subset and two fresh automatic graphs. No currentUI PASS is asserted by preparation.',
        'WholeV1 retained7121PASS/72FAIL and wholeV2 retained7181PASS/12FAIL, with all9then6 default5s timeout signatures and original6M02 errors. No snapshot/failure is relabeled or overwritten. No test-cache shortcut, timeout increase or permanent skip was introduced.',
        'Controlled provider/Auth/CMS/RPC boundaries, native SQL/RLS/concurrency, UI scope and whole gates remain distinct. No production, keys, provider billing, managed browser acceptance or fullM07/M24/R3 completion is claimed.',
    ],
}
put('STAGE.json', encode(metadata))
put('CURRENT-SOURCE-INVENTORY.json', encode(rows))
put('PREPARATION-INPUTS.json', encode(config))
(here / (config['stageName'] + '-receipt.json')).write_bytes(encode({'stage': str(stage), 'payloads': len(payload),
    'currentBindings': len(rows), 'sourceInventorySha256': metadata['sourceInventorySha256'], 'globalSourceSha256': fingerprint,
    'sealed': False, 'portableReplay': 'NOT_RUN_BY_PREPARATION'}))
print(json.dumps({'stage': str(stage), 'payloads': len(payload), 'currentBindings': len(rows), 'sealed': False}))
