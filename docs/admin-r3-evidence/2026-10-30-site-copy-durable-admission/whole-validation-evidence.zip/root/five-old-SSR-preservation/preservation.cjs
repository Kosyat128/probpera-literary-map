const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const repo = path.resolve(__dirname, '../../..', 'probpera-literary-map');
const ts = require(path.join(repo, 'node_modules/typescript'));
const files = [
  'apps/admin/lib/article-item-retry-journal.integration.test.ts',
  'apps/admin/lib/translation-provider-self-test-binding.integration.test.ts',
  'apps/admin/app/(dashboard)/translations/article-item-retry-admission.integration.test.ts',
  'apps/admin/app/(dashboard)/translations/article-item-retry.integration.test.ts',
  'apps/admin/app/(dashboard)/translations/article-machine-draft-callers.integration.test.ts',
];
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function nodes(source, predicate) {
  const result = []; const ast = ts.createSourceFile('source.ts', source, ts.ScriptTarget.Latest, true);
  function walk(node) { if (predicate(node)) result.push(node.getText(ast)); ts.forEachChild(node, walk); }
  walk(ast); return result;
}
const assertion = node => ts.isCallExpression(node) && /^expect\b/.test(node.expression.getText());
const testCase = node => ts.isCallExpression(node) && /^(?:it|test)(?:\.|\(|$)/.test(node.expression.getText());
const imports = node => ts.isImportDeclaration(node);
const loader = node => ts.isFunctionDeclaration(node) && ['actualPage', 'actualModules', 'modules'].includes(node.name?.text);
const timeoutOrCacheSetting = node => ts.isCallExpression(node) && /(?:setTimeout|setConfig|\.cache)$/.test(node.expression.getText()) ||
  ts.isPropertyAssignment(node) && /^(?:testTimeout|hookTimeout|pool|maxWorkers|minWorkers|fileParallelism|isolate)$/.test(node.name.getText());
function subsequence(original, current) {
  let index = 0; for (const value of current) if (value === original[index]) index++;
  return index === original.length;
}
const rows = files.map(file => {
  const beforeBytes = fs.readFileSync(path.join(__dirname, 'before', file));
  const currentBytes = fs.readFileSync(path.join(repo, file));
  const before = beforeBytes.toString(), current = currentBytes.toString();
  const oldAssertions = nodes(before, assertion), newAssertions = nodes(current, assertion);
  const oldCases = nodes(before, testCase), newCases = nodes(current, testCase);
  const checks = {
    originalFullTestDeclarationsByteExact: JSON.stringify(oldCases) === JSON.stringify(newCases),
    originalAllFullAssertionCallNodesInOrder: subsequence(oldAssertions, newAssertions),
    originalImportsByteExact: JSON.stringify(nodes(before, imports)) === JSON.stringify(nodes(current, imports)),
    originalActualSourceLoadersByteExact: JSON.stringify(nodes(before, loader)) === JSON.stringify(nodes(current, loader)),
    originalTimeoutAndCacheSettingsExact: JSON.stringify(nodes(before, timeoutOrCacheSetting)) === JSON.stringify(nodes(current, timeoutOrCacheSetting)),
    newMetadataReadExactNullOnly: /expect\(name\)\.toBe\("reconcile_site_copy_translation_operation"\)/.test(current) &&
      /expect\(args\)\.toEqual\(\{ p_operation_id: null \}\)/.test(current) && /return \{ data: null, error: null \}/.test(current),
    newRecoveryActionNeverExecutedAssertion: current.includes('expect(recoverSiteCopy).not.toHaveBeenCalled()'),
  };
  const target = path.join(__dirname, 'after', file); fs.mkdirSync(path.dirname(target), { recursive: true }); fs.writeFileSync(target, currentBytes);
  return { file, beforeSha256: sha(beforeBytes), currentSha256: sha(currentBytes), originalAssertionCallNodes: oldAssertions.length,
    currentAssertionCallNodes: newAssertions.length, originalFullTestDeclarations: oldCases.length, currentFullTestDeclarations: newCases.length,
    checks, originalAssertions: oldAssertions, originalFullCases: oldCases };
});
const report = { checkedAt: new Date().toISOString(), purpose: 'SETUP_ONLY_SOURCE_PRESERVATION_NOT_TEST_EXECUTION',
  scopeAddition: 'Actual site-copy metadata reader and strict adapter remain loaded. New exact-null reconcile transport/fresh matching staff/nonexecuted recovery action are declared separately; original article/provider/build/audit/configuration spy scopes are retained.',
  behaviorExceptions: [], runtimeExecuted: false, compilerExecuted: false,
  rows, allPassed: rows.every(row => Object.values(row.checks).every(Boolean)) };
const output = path.join(__dirname, 'preservation.json'); fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ output, allPassed: report.allPassed, sha256: sha(fs.readFileSync(output)), rows: rows.map(({ file, beforeSha256, currentSha256, originalAssertionCallNodes, currentAssertionCallNodes, originalFullTestDeclarations, currentFullTestDeclarations, checks }) => ({ file, beforeSha256, currentSha256, originalAssertionCallNodes, currentAssertionCallNodes, originalFullTestDeclarations, currentFullTestDeclarations, checks })) }, null, 2));
if (!report.allPassed) process.exitCode = 1;
