-- SYNTHETIC PLATFORM SUPPORT ONLY. PREPARED, NOT EXECUTED.
-- No public CMS/outbox/autosave relation or production function is replaced.
-- The owned PostgreSQL bootstrap must already supply the three platform roles.
do $platform_roles$
begin
 if not exists(select 1 from pg_roles where rolname='anon')
  or not exists(select 1 from pg_roles where rolname='authenticated')
  or not exists(select 1 from pg_roles where rolname='service_role') then
  raise exception 'Owned platform roles are missing; do not invent privileges';
 end if;
 if exists(select 1 from pg_roles where rolname in('anon','authenticated') and (rolsuper or rolbypassrls)) then
  raise exception 'Test actors must not be superuser/BYPASSRLS';
 end if;
end;
$platform_roles$;

create schema auth;
create table auth.users (
 id uuid primary key,
 email text,
 raw_user_meta_data jsonb not null default '{}'::jsonb
);
create function auth.uid() returns uuid language sql stable set search_path=''
as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
grant usage on schema auth to anon,authenticated,service_role;
grant execute on function auth.uid() to anon,authenticated,service_role;

-- Only the Storage catalog columns referenced by the unchanged whole CMS
-- migration are represented. No actual Storage HTTP, file bytes or policy
-- equivalence to the managed service is claimed.
create schema storage;
create table storage.buckets (
 id text primary key,
 name text not null,
 public boolean not null default false,
 file_size_limit bigint,
 allowed_mime_types text[]
);
create table storage.objects (
 id uuid primary key,
 bucket_id text references storage.buckets(id),
 name text not null
);
alter table storage.objects enable row level security;

-- supabase/schema.sql attaches four genuine community relations to this
-- platform publication. Realtime delivery/subscriptions are not exercised.
create publication supabase_realtime;
