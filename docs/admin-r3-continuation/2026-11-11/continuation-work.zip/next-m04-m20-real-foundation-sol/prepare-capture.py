import datetime,hashlib,json,pathlib,re
own=pathlib.Path(__file__).resolve().parent;work=own.parent;repo=work.parent/'probpera-literary-map'
assert not (own/'source-manifest.json').exists(),'New prepared capture must not replace any earlier provenance'
def digest(data):return hashlib.sha256(data).hexdigest()
chain=[
 ('supabase/schema.sql','Actual current checked-in community/base schema; supplies real profiles/comment types needed by the entire CMS migration.'),
 ('supabase/migrations/20260728_cms_foundation.sql','Actual CMS relations, canonical/revision tables, staff-role authority, timestamp functions, original RLS and Storage policies.'),
 ('supabase/migrations/20260730_literary_archive.sql','Actual literary_works and book_editions with all constraints/policies.'),
 ('supabase/migrations/20260730_page_revision_history.sql','Actual page revision trigger implementation.'),
 ('supabase/migrations/20260730_staff_management.sql','Actual original staff management functions, prerequisite to later owner invariant.'),
 ('supabase/migrations/20260808_article_translations.sql','Actual article translation enum/table/revisions/Russian sync and RLS.'),
 ('supabase/migrations/20260808_book_translations_and_import_staging.sql','Actual literary translation/source/external-ID/import relations and publishability policies.'),
 ('supabase/migrations/20260812_homepage_block_revisions.sql','Actual singleton/revision history definitions, no synthetic duplicate-master correction.'),
 ('supabase/migrations/20260812_writer_and_work_revisions.sql','Actual writer override/work/site-chrome revisions and policies.'),
 ('supabase/migrations/20260813_editorial_database_admin.sql','Actual country override and edition revision tables/policies.'),
 ('supabase/migrations/20260813_homepage_atomic_move.sql','Actual move RPC required by original health metadata.'),
 ('supabase/migrations/20260813_tags_updated_at.sql','Actual tags timestamp schema update.'),
 ('supabase/migrations/20260813_unified_revision_history.sql','Actual complete revision view over all genuine predecessor tables.'),
 ('supabase/migrations/20260814_publication_outbox_and_schema_health.sql','ENTIRE actual outbox table/index/ledger/functions/all20triggers/RLS/ACL/health. No slices or stubs.'),
 ('supabase/migrations/20260820_literary_work_cover_artworks.sql','Actual21st relation/publication trigger needed by later staff-read/atomic-bundle health.'),
 ('supabase/migrations/20260822_staff_editorial_read_rls.sql','Actual staff canonical/translation/media SELECT policies; original later health definition.'),
 ('supabase/migrations/20260822_zz_atomic_article_bundle.sql','ENTIRE actual SECURITY INVOKER bundle predecessor needed by Sep5 reviewed body patches.'),
 ('supabase/migrations/20260828_zz_editor_autosaves.sql','ENTIRE actual autosave schema/bounds/FORCE RLS/actor+staff policies/authenticatedDML/security-invoker save.'),
 ('supabase/migrations/20260901_zz_staff_owner_invariant.sql','Actual current staff-membership FORCE RLS/ACL and serialized owner RPCs.'),
 ('supabase/migrations/20260901_zzz_admin_mutation_guards.sql','ENTIRE actual mutation/redirect guards, readonly redirect ACLs and owner/staff boundaries, not just callable signatures.'),
 ('supabase/migrations/20260902_article_working_drafts.sql','ENTIRE actual private draft model, role boundaries and SECURITY INVOKER promotion predecessor.'),
 ('supabase/migrations/20260905_article_publication_permissions.sql','ENTIRE actual permission hotfix and exact invoker predecessor/body/ACL checks.'),
]
references=[
 ('apps/admin/lib/publication.ts','Actual application publication/queue/mark behavior; not executed by foundation SQL.'),
 ('apps/admin/lib/public-build.ts','Actual provider request boundary/acceptance limitations; no provider calls.'),
 ('apps/admin/app/(dashboard)/publication/actions.ts','Actual retry/full-release caller contract, unchanged.'),
 ('apps/admin/app/(dashboard)/publication/page.tsx','Actual existing queue DTO and row form; no UI execution.'),
 ('apps/admin/app/(dashboard)/editor-autosave/actions.ts','Actual exact-delete predicates/Boolean result for future M20 SQL/SDK equivalence.'),
 ('scripts/check-public-build-requests.mjs','Actual service-role consumer pending set and highwater finalizer; no service key or HTTP execution.'),
 ('scripts/lib/cms-publication-head.mjs','Actual maximum outbox/legacy head capture.'),
 ('scripts/lib/cms-publication-state.mjs','Actual bigint/head-window semantics.'),
 ('scripts/export-stable-published-content.mjs','Actual joint ordinary+Premium retry wrapper.'),
 ('scripts/export-published-content.mjs','Actual ordinary exporter, captured only.'),
 ('scripts/export-premium-translations.mjs','Actual Premium exporter/head output, captured only.'),
 ('.github/workflows/deploy-pages.yml','Actual shared release lifecycle/coalescing/finalization; never invoked.'),
 ('scripts/database/build-production-migration-plan.mjs','Existing reviewed chronology/reference; this prepared local subset does not populate production migration ledger.'),
 ('docs/admin-r3-task-package/modules/M04.md','Actual requested acceptance boundaries.'),
 ('docs/admin-r3-task-package/modules/M20.md','Actual recovery/deletion acceptance boundaries.'),
]
sources=[];sections=[];offset=0
header=b'\\set ON_ERROR_STOP on\n-- PREPARED ONLY: actual unchanged repository SQL plus declared platform scaffold.\n-- NO execution/parse/success claim. Fresh owned local database only; no production.\n\n'
scaffold=(own/'platform-scaffold.sql').read_bytes();parts=[header,b'-- BEGIN DECLARED SYNTHETIC PLATFORM SUPPORT\n',scaffold,b'\n-- END DECLARED SYNTHETIC PLATFORM SUPPORT\n']
offset=sum(map(len,parts))
table_origins={};required=['articles','article_tags','article_translations','pages','homepage_blocks','banners','navigation_menus','navigation_items','redirects','categories','tags','media_assets','media_usages','literary_works','literary_work_translations','literary_work_sources','literary_work_external_ids','book_editions','writer_profile_overrides','country_profile_overrides']
for index,(file,reason) in enumerate(chain,1):
 data=(repo/file).read_bytes();dest=own/'sources'/file;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 source={'file':file,'bytes':len(data),'sha256':digest(data),'role':reason,'mode':'WHOLE_FILE_BYTE_EXACT','applyOrder':index};sources.append(source)
 begin=f'\n-- BEGIN WHOLE ORIGINAL {file} SHA256 {source["sha256"]}\n'.encode('ascii');end=f'\n-- END WHOLE ORIGINAL {file}\n'.encode('ascii')
 offset+=len(begin);sections.append({'file':file,'contentOffsetBytes':offset,'bytes':len(data),'sha256':source['sha256']});parts.extend([begin,data,end]);offset+=len(data)+len(end)
 for table in required:
  match=re.search(r'create\s+table\s+(?:if\s+not\s+exists\s+)?public\.'+re.escape(table)+r'\s*\(',data.decode('utf-8-sig'),re.I)
  if match and table not in table_origins:table_origins[table]={'file':file,'line':data.decode('utf-8-sig')[:match.start()].count('\n')+1,'applyOrder':index,'classification':'STATIC_ORIGIN_ONLY_NOT_SQL_PARSE'}
 if file.endswith('20260814_publication_outbox_and_schema_health.sql'):assert set(required)==set(table_origins),'All20 actual relation definitions must precede whole outbox migration'
for file,reason in references:
 data=(repo/file).read_bytes();dest=own/'sources'/file;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);sources.append({'file':file,'bytes':len(data),'sha256':digest(data),'role':reason,'mode':'REFERENCE_CAPTURE_ONLY_NO_EXECUTION'})
foundation=b''.join(parts);(own/'foundation.prepared.sql').write_bytes(foundation)
for section in sections:assert digest(foundation[section['contentOffsetBytes']:section['contentOffsetBytes']+section['bytes']])==section['sha256']
manifest={'atUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':'PREPARED_ONLY_WHOLE_REAL_OLD_SCHEMA_CHAIN_NOT_EXECUTED_OR_PARSED',
 'head':'acb910d89133396e8e9794e91bd5db74128dab3b','rootValidation':'WholeV3 terminal7187/7193 with6historicalM02; gates still active per root. No current source rebind/acceptance is invented by preparation.',
 'foundation':{'file':'foundation.prepared.sql','bytes':len(foundation),'sha256':digest(foundation),'wholeAppliedRepositoryFiles':len(chain),'exactSections':sections},
 'platformScaffold':{'file':'platform-scaffold.sql','bytes':len(scaffold),'sha256':digest(scaffold),'synthetic':True,'scope':'Only auth.users/uid, minimal Storage catalogs, Realtime publication and existing platform-role checks. No public target table/function/policy replacement; no managed Auth/Storage/Realtime proof.'},
 'sources':sources,'actual20RelationOrigins':table_origins,
 'consumerAndPermissionScope':'Actual Aug14 append/enqueue/mark bodies occur only in their original whole migration; later true staff-read/owner/redirect/article working-draft/Sep5 permission chain is included. Consumer/export/workflow scripts are byte-exact references, not SQL, service or network execution.',
 'knownDependenciesAndLimits':[
  'Existing anon/authenticated/service_role roles must already be supplied by the owned platform bootstrap. The scaffold refuses absent actors or superuser/BYPASSRLS authenticated/anon; it does not CREATE/ALTER roles.',
  'Local PG17 must provide pgcrypto as required by the actual schema. No extension/provider/network installation is performed by preparation.',
  'The repo does not explicitly grant broad authenticated DML/SELECT on many canonical CMS tables. Real managed default privileges are not proven here. NO blanket grants or fake target privileges were added; positive canonical invoker mutations/save_autosave(entityId) may require separately evidenced platform defaults.',
  'Actual outbox explicit authenticated SELECT/RPC EXECUTE and autosave authenticatedDML/actor RLS are in the whole migrations and remain testable without invented grants. Fixture-owner seeding/trigger observations must be labeled as such.',
  'Current schema.sql is the actual checked-in base and contains community features accumulated later. This is a selected-current-source replay of old migration definitions, not a production dump or proof of historical/live effective schema.',
  'The whole Sep5 hotfix validates exact Aug22/Sep2 function signatures/bodies and ACLs. Unexpected predecessor aborts honestly; do not rewrite/stub the function or suppress the check to get PASS.',
  '21st cover-artwork relation/trigger is included for actual Aug22 health dependencies. No full latest project capabilities/health claim follows from this subset.',
  'No production ledger rows are forged, and no old migrations or excluded normalizers/rules/calls are edited. Unrelated typography/studio/analytics/reader/machine-translation/data repair chains are omitted intentionally.',
  'M04 native old-baseline append/mark vs future new retry protocol and M20 exact-delete actor/scope controls need their own actual execution receipts. This file has NOT been SQL-parsed, applied, tested or compiled.',
 ],
 'futureRetryActorDeletionRisk':'Existing outbox.actor_id FK is ON DELETE SET NULL. A future retry actor-nonnull CHECK/unique(actor,op) could block normal auth-user deletion or lose deduplication onNULL. Decide the retained identity/global operation uniqueness semantics explicitly; this prepared OLD foundation adds no new columns/constraints and makes no decision.',
 'safeFutureReuse':'Use fresh unique owned database on127.0.0.1:55438 only, verify actual oldPID/pidfile/port before start, compare data_directory, and always finally stop exact ownPID. Existing descriptor/PG17binaries may be reused; never clone/overwrite the prior stub DB as an actual outbox baseline.',
 'execution':{'sql':False,'databaseStarted':False,'compiler':False,'browser':False,'provider':False,'sourceEdited':False,'productionWrites':0}}
(own/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'classification':manifest['classification'],'foundationBytes':len(foundation),'foundationSha256':digest(foundation),'wholeSqlFiles':len(chain),'physicalCaptures':len(sources),'actualTargetRelations':len(table_origins),'manifestSha256':digest((own/'source-manifest.json').read_bytes())}))
