-- READONLY OBSERVATION RECIPE, PREPARED/NOT_EXECUTED. No PASS assertions.
select jsonb_build_object('classification','ACTUAL_SCHEMA_OBSERVATION_ONLY',
 'outbox',to_regclass('public.public_build_outbox'),
 'autosaves',to_regclass('public.editor_autosaves'),
 'enqueue',to_regprocedure('public.enqueue_public_build_request(text,text,text,jsonb)'),
 'mark',to_regprocedure('public.mark_public_build_dispatched(bigint,text)'),
 'capture',to_regprocedure('public.capture_public_build_outbox()'),
 'saveAutosave',to_regprocedure('public.save_editor_autosave(text,uuid,text,text,timestamptz,uuid,bigint,text,jsonb,timestamptz)'));
select jsonb_agg(jsonb_build_object('role',rolname,'superuser',rolsuper,'bypassRls',rolbypassrls,'inherit',rolinherit) order by rolname)
 from pg_roles where rolname in('anon','authenticated','service_role');
select jsonb_agg(jsonb_build_object('table',c.oid::regclass::text,'owner',pg_get_userbyid(c.relowner),'rls',c.relrowsecurity,'forceRls',c.relforcerowsecurity,
 'authSelect',has_table_privilege('authenticated',c.oid,'SELECT'),'authInsert',has_table_privilege('authenticated',c.oid,'INSERT'),
 'authUpdate',has_table_privilege('authenticated',c.oid,'UPDATE'),'authDelete',has_table_privilege('authenticated',c.oid,'DELETE'),'acl',c.relacl) order by c.oid::regclass::text)
 from pg_class c where c.oid in('public.public_build_outbox'::regclass,'public.editor_autosaves'::regclass,'public.articles'::regclass,'public.pages'::regclass,'public.staff_memberships'::regclass);
select jsonb_agg(to_jsonb(p) order by p.tablename,p.policyname) from pg_policies p
 where p.schemaname='public' and p.tablename in('public_build_outbox','editor_autosaves','articles','pages','staff_memberships');
select jsonb_agg(jsonb_build_object('table',t.tgrelid::regclass::text,'name',t.tgname,'enabled',t.tgenabled,'definition',pg_get_triggerdef(t.oid)) order by t.tgrelid::regclass::text,t.tgname)
 from pg_trigger t where not t.tgisinternal and t.tgfoid='public.capture_public_build_outbox()'::regprocedure;
select jsonb_agg(jsonb_build_object('name',p.oid::regprocedure::text,'owner',pg_get_userbyid(p.proowner),'definer',p.prosecdef,'config',p.proconfig,'acl',p.proacl,'definition',pg_get_functiondef(p.oid)) order by p.oid::regprocedure::text)
 from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public'
 and p.proname in('append_public_build_outbox','enqueue_public_build_request','mark_public_build_dispatched','capture_public_build_outbox','save_editor_autosave','is_staff','lock_article_working_draft_for_publication','upsert_article_redirect_guarded','save_article_bundle','promote_article_working_draft');
