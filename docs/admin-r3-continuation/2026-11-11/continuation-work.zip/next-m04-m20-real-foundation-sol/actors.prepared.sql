-- OPTIONAL SYNTHETIC LOCAL FIXTURE DATA ONLY. PREPARED, NOT EXECUTED.
-- Run only as fixture owner after the actual foundation in a fresh owned DB.
-- The actual handle_new_user trigger creates profiles from these valid fields.
insert into auth.users(id,email,raw_user_meta_data) values
 ('11111111-1111-4111-8111-111111111111','owner.native@fixture.invalid','{"display_name":"Native owner"}'),
 ('22222222-2222-4222-8222-222222222222','admin.native@fixture.invalid','{"display_name":"Native foreign admin"}'),
 ('33333333-3333-4333-8333-333333333333','reader.native@fixture.invalid','{"display_name":"Native nonstaff reader"}'),
 ('44444444-4444-4444-8444-444444444444','editor.native@fixture.invalid','{"display_name":"Native editor"}');
insert into public.staff_memberships(user_id,role,created_by) values
 ('11111111-1111-4111-8111-111111111111','owner','11111111-1111-4111-8111-111111111111'),
 ('22222222-2222-4222-8222-222222222222','admin','11111111-1111-4111-8111-111111111111'),
 ('44444444-4444-4444-8444-444444444444','editor','11111111-1111-4111-8111-111111111111');
-- No public canonical rows, autosaves or outbox events are manufactured here.
