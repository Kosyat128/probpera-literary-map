\set ON_ERROR_STOP on
-- PREPARED ONLY: actual unchanged repository SQL plus declared platform scaffold.
-- NO execution/parse/success claim. Fresh owned local database only; no production.

-- BEGIN DECLARED SYNTHETIC PLATFORM SUPPORT
-- SYNTHETIC PLATFORM SUPPORT ONLY. PREPARED, NOT EXECUTED.
-- No public CMS/outbox/autosave relation or production function is replaced.
-- The owned PostgreSQL bootstrap must already supply the three platform roles.
do $platform_roles$
begin
 if not exists(select 1 from pg_roles where rolname='anon')
  or not exists(select 1 from pg_roles where rolname='authenticated')
  or not exists(select 1 from pg_roles where rolname='service_role') then
  raise exception 'Owned platform roles are missing; do not invent privileges';
 end if;
 if exists(select 1 from pg_roles where rolname in('anon','authenticated') and (rolsuper or rolbypassrls)) then
  raise exception 'Test actors must not be superuser/BYPASSRLS';
 end if;
end;
$platform_roles$;

create schema auth;
create table auth.users (
 id uuid primary key,
 email text,
 raw_user_meta_data jsonb not null default '{}'::jsonb
);
create function auth.uid() returns uuid language sql stable set search_path=''
as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
grant usage on schema auth to anon,authenticated,service_role;
grant execute on function auth.uid() to anon,authenticated,service_role;

-- Only the Storage catalog columns referenced by the unchanged whole CMS
-- migration are represented. No actual Storage HTTP, file bytes or policy
-- equivalence to the managed service is claimed.
create schema storage;
create table storage.buckets (
 id text primary key,
 name text not null,
 public boolean not null default false,
 file_size_limit bigint,
 allowed_mime_types text[]
);
create table storage.objects (
 id uuid primary key,
 bucket_id text references storage.buckets(id),
 name text not null
);
alter table storage.objects enable row level security;

-- supabase/schema.sql attaches four genuine community relations to this
-- platform publication. Realtime delivery/subscriptions are not exercised.
create publication supabase_realtime;

-- END DECLARED SYNTHETIC PLATFORM SUPPORT

-- BEGIN WHOLE ORIGINAL supabase/schema.sql SHA256 84ef3bca37e6d0cf5990d1bc0a263bf5bb19784cfdba3b4da8b6d04ba7924459
create extension if not exists pgcrypto;

create type public.community_role as enum ('reader', 'moderator', 'editor', 'admin');
create type public.publication_status as enum ('published', 'hidden', 'pending');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 2 and 80),
  avatar_url text,
  bio text check (char_length(bio) <= 1000),
  role public.community_role not null default 'reader',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.forum_topics (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 5 and 140),
  body text not null check (char_length(body) between 10 and 8000),
  category text not null check (char_length(category) between 2 and 80),
  status public.publication_status not null default 'published',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.forum_replies (
  id uuid primary key default gen_random_uuid(),
  topic_id uuid not null references public.forum_topics(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 2 and 4000),
  status public.publication_status not null default 'published',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.article_comments (
  id uuid primary key default gen_random_uuid(),
  article_slug text not null check (char_length(article_slug) between 2 and 180),
  parent_id uuid references public.article_comments(id) on delete cascade,
  author_id uuid references public.profiles(id) on delete set null,
  guest_name text check (char_length(guest_name) between 2 and 80),
  session_id uuid not null,
  body text not null check (char_length(body) between 2 and 4000),
  status public.publication_status not null default 'published',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (author_id is not null or guest_name is not null)
);

create table public.ratings (
  id uuid primary key default gen_random_uuid(),
  subject_type text not null check (subject_type in ('article', 'book')),
  subject_id text not null check (char_length(subject_id) between 2 and 180),
  user_id uuid references public.profiles(id) on delete set null,
  session_id uuid not null,
  score smallint not null check (score between 1 and 5),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.content_views (
  id bigint generated always as identity primary key,
  path text not null check (char_length(path) between 1 and 320),
  session_id uuid not null,
  user_id uuid references public.profiles(id) on delete set null,
  referrer_host text check (char_length(referrer_host) <= 180),
  previous_path text check (char_length(previous_path) between 1 and 320),
  navigation_source text not null default 'direct' check (
    navigation_source in ('direct', 'internal', 'external', 'campaign')
  ),
  utm_source text check (char_length(utm_source) <= 120),
  utm_medium text check (char_length(utm_medium) <= 80),
  utm_campaign text check (char_length(utm_campaign) <= 180),
  created_at timestamptz not null default now()
);

create table public.reader_favorites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  item_type text not null check (item_type in ('article', 'book')),
  item_id text not null check (char_length(item_id) between 1 and 240),
  title text not null check (char_length(title) between 1 and 300),
  section_id text check (char_length(section_id) <= 120),
  section_label text not null check (char_length(section_label) between 1 and 240),
  href text check (char_length(href) <= 500),
  added_at timestamptz not null default now(),
  unique (user_id, item_type, item_id)
);

create table public.reader_book_collections (
  id text not null check (id ~ '^[A-Za-z0-9:_-]{1,192}$'),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null check (
    char_length(name) between 1 and 120
    and name = btrim(name)
  ),
  description text check (char_length(description) between 1 and 800),
  icon text check (icon in ('book', 'star', 'quill', 'archive', 'heart')),
  collection_type text not null default 'manual' check (
    collection_type in ('system', 'manual', 'smart', 'editorial')
  ),
  system_type text check (
    system_type in ('library', 'want-to-read', 'reading', 'finished')
  ),
  visibility text not null default 'private' check (visibility = 'private'),
  background_preset text check (
    char_length(background_preset) between 1 and 80
    and background_preset ~ '^[a-z0-9][a-z0-9-]*$'
  ),
  dynamic_book_themes boolean not null default true,
  theme_intensity smallint not null default 70 check (
    theme_intensity between 0 and 100
  ),
  sort_mode text not null default 'editorial-relevance' check (
    sort_mode in (
      'editorial-relevance',
      'title',
      'writer',
      'oldest',
      'newest',
      'cover-first',
      'manual',
      'recent'
    )
  ),
  filter_state jsonb not null default '{}'::jsonb check (
    jsonb_typeof(filter_state) = 'object'
  ),
  schema_version smallint not null default 1 check (schema_version >= 1),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, id),
  check (
    (collection_type = 'system' and system_type is not null)
    or (collection_type <> 'system' and system_type is null)
  )
);

create table public.reader_book_collection_items (
  collection_id text not null check (
    collection_id ~ '^[A-Za-z0-9:_-]{1,192}$'
  ),
  user_id uuid not null,
  book_key text not null check (char_length(book_key) between 1 and 240),
  position integer not null check (position between 0 and 999999),
  schema_version smallint not null default 1 check (schema_version >= 1),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint reader_book_collection_items_owner_fk
    foreign key (user_id, collection_id)
    references public.reader_book_collections(user_id, id)
    on delete cascade,
  primary key (user_id, collection_id, book_key)
);

create table public.reader_book_favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  book_key text not null check (char_length(book_key) between 1 and 240),
  schema_version smallint not null default 1 check (schema_version >= 1),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, book_key)
);

create table public.comment_reports (
  id uuid primary key default gen_random_uuid(),
  comment_id uuid not null references public.article_comments(id) on delete cascade,
  reporter_id uuid references public.profiles(id) on delete set null,
  session_id uuid not null,
  reason text not null check (char_length(reason) between 5 and 500),
  status text not null default 'open' check (status in ('open', 'resolved')),
  resolved_at timestamptz,
  resolved_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create index forum_topics_created_idx on public.forum_topics(created_at desc);
create index forum_replies_topic_idx on public.forum_replies(topic_id, created_at);
create index article_comments_slug_idx on public.article_comments(article_slug, created_at desc);
create index ratings_subject_idx on public.ratings(subject_type, subject_id);
create unique index ratings_user_unique_idx
  on public.ratings(subject_type, subject_id, user_id)
  where user_id is not null;
create unique index ratings_guest_unique_idx
  on public.ratings(subject_type, subject_id, session_id)
  where user_id is null;
create index content_views_created_idx on public.content_views(created_at desc);
create index content_views_path_idx on public.content_views(path, created_at desc);
create index content_views_normalized_path_idx
  on public.content_views (
    (split_part(split_part(path, '#', 1), '?', 1))
  );
create index reader_favorites_user_idx
  on public.reader_favorites(user_id, added_at desc);
create index reader_book_collections_owner_updated_idx
  on public.reader_book_collections(user_id, updated_at desc, id);
create index reader_book_collection_items_order_idx
  on public.reader_book_collection_items(user_id, collection_id, position);
create index reader_book_collection_items_owner_updated_idx
  on public.reader_book_collection_items(
    user_id,
    updated_at desc,
    collection_id,
    book_key
  );
create index reader_book_favorites_owner_created_idx
  on public.reader_book_favorites(user_id, created_at desc, book_key);
create index comment_reports_created_idx on public.comment_reports(created_at desc);
create unique index comment_reports_session_unique_idx
  on public.comment_reports(comment_id, session_id);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data ->> 'display_name', ''), split_part(new.email, '@', 1))
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create or replace function public.set_reader_book_state_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

revoke all on function public.set_reader_book_state_updated_at() from public;

create trigger reader_book_collections_set_updated_at
  before update on public.reader_book_collections
  for each row execute function public.set_reader_book_state_updated_at();

create trigger reader_book_collection_items_set_updated_at
  before update on public.reader_book_collection_items
  for each row execute function public.set_reader_book_state_updated_at();

create trigger reader_book_favorites_set_updated_at
  before update on public.reader_book_favorites
  for each row execute function public.set_reader_book_state_updated_at();

create or replace function public.is_community_moderator()
returns boolean
language sql
stable
security definer set search_path = ''
as $$
  select exists (
    select 1
    from public.profiles
    where id = (select auth.uid())
      and role in ('moderator', 'editor', 'admin')
  );
$$;

create or replace function public.rate_content(
  p_subject_type text,
  p_subject_id text,
  p_score smallint,
  p_session_id uuid
)
returns void
language plpgsql
security definer set search_path = ''
as $$
begin
  if p_subject_type not in ('article', 'book')
    or char_length(p_subject_id) not between 2 and 180
    or p_score not between 1 and 5 then
    raise exception 'Invalid rating';
  end if;

  if (select auth.uid()) is null then
    update public.ratings
      set score = p_score, updated_at = now()
      where subject_type = p_subject_type
        and subject_id = p_subject_id
        and user_id is null
        and session_id = p_session_id;

    if not found then
      insert into public.ratings
        (subject_type, subject_id, user_id, session_id, score)
      values
        (p_subject_type, p_subject_id, null, p_session_id, p_score);
    end if;
  else
    update public.ratings
      set score = p_score, session_id = p_session_id, updated_at = now()
      where subject_type = p_subject_type
        and subject_id = p_subject_id
        and user_id = (select auth.uid());

    if not found then
      insert into public.ratings
        (subject_type, subject_id, user_id, session_id, score)
      values
        (p_subject_type, p_subject_id, (select auth.uid()), p_session_id, p_score);
    end if;
  end if;
end;
$$;

create or replace function public.get_rating_summary(
  p_subject_type text,
  p_subject_id text,
  p_session_id uuid
)
returns table (
  average_score numeric,
  rating_count bigint,
  my_score smallint
)
language sql
stable
security definer set search_path = ''
as $$
  select
    round(avg(score)::numeric, 2) as average_score,
    count(*) as rating_count,
    max(score) filter (
      where (
        (select auth.uid()) is not null
        and user_id = (select auth.uid())
      ) or (
        (select auth.uid()) is null
        and user_id is null
        and session_id = p_session_id
      )
    ) as my_score
  from public.ratings
  where subject_type = p_subject_type
    and subject_id = p_subject_id;
$$;

create or replace function public.get_content_view_count(p_paths text[])
returns bigint
language sql
stable
security definer set search_path = ''
as $$
  select count(*)
  from public.content_views
  where split_part(split_part(path, '#', 1), '?', 1)
    = any (p_paths[1:16]);
$$;

create or replace function public.submit_article_comment(
  p_article_slug text,
  p_session_id uuid,
  p_body text,
  p_guest_name text default null,
  p_parent_id uuid default null
)
returns uuid
language plpgsql
security definer set search_path = ''
as $$
declare
  new_comment_id uuid;
  current_user_id uuid := (select auth.uid());
  normalized_body text := btrim(p_body);
  normalized_guest_name text := nullif(btrim(p_guest_name), '');
  recent_comments integer;
  link_count integer;
begin
  if char_length(p_article_slug) not between 2 and 180
    or char_length(normalized_body) not between 2 and 4000 then
    raise exception 'Invalid comment';
  end if;

  if current_user_id is null
    and (
      normalized_guest_name is null
      or char_length(normalized_guest_name) not between 2 and 80
    ) then
    raise exception 'Guest name required';
  end if;

  select count(*) into recent_comments
  from public.article_comments
  where session_id = p_session_id
    and created_at > now() - interval '10 minutes';

  if recent_comments >= 4 then
    raise exception 'Too many comments';
  end if;

  select count(*) into link_count
  from regexp_matches(normalized_body, 'https?://', 'gi');

  if link_count > 3 then
    raise exception 'Too many links';
  end if;

  insert into public.article_comments (
    article_slug,
    parent_id,
    author_id,
    guest_name,
    session_id,
    body
  )
  values (
    p_article_slug,
    p_parent_id,
    current_user_id,
    case when current_user_id is null then normalized_guest_name else null end,
    p_session_id,
    normalized_body
  )
  returning id into new_comment_id;

  return new_comment_id;
end;
$$;

create or replace function public.report_article_comment(
  p_comment_id uuid,
  p_session_id uuid,
  p_reason text
)
returns void
language plpgsql
security definer set search_path = ''
as $$
begin
  if char_length(btrim(p_reason)) not between 5 and 500
    or not exists (
      select 1
      from public.article_comments
      where id = p_comment_id and status = 'published'
    ) then
    raise exception 'Invalid report';
  end if;

  insert into public.comment_reports (
    comment_id,
    reporter_id,
    session_id,
    reason
  )
  values (
    p_comment_id,
    (select auth.uid()),
    p_session_id,
    btrim(p_reason)
  )
  on conflict (comment_id, session_id) do nothing;
end;
$$;

create or replace function public.resolve_comment_report(
  p_report_id uuid,
  p_hide_comment boolean default false
)
returns void
language plpgsql
security definer set search_path = ''
as $$
declare
  reported_comment_id uuid;
begin
  if not public.is_community_moderator() then
    raise exception 'Moderator access required';
  end if;

  select comment_id into reported_comment_id
  from public.comment_reports
  where id = p_report_id and status = 'open';

  if reported_comment_id is null then
    raise exception 'Report not found';
  end if;

  if p_hide_comment then
    update public.article_comments
    set status = 'hidden', updated_at = now()
    where id = reported_comment_id;
  end if;

  update public.comment_reports
  set
    status = 'resolved',
    resolved_at = now(),
    resolved_by = (select auth.uid())
  where id = p_report_id;
end;
$$;

grant execute on function public.rate_content(text, text, smallint, uuid)
  to anon, authenticated;
grant execute on function public.get_rating_summary(text, text, uuid)
  to anon, authenticated;
grant execute on function public.get_content_view_count(text[])
  to anon, authenticated;
grant execute on function public.submit_article_comment(text, uuid, text, text, uuid)
  to anon, authenticated;
grant execute on function public.report_article_comment(uuid, uuid, text)
  to anon, authenticated;
grant execute on function public.resolve_comment_report(uuid, boolean)
  to authenticated;
grant select, insert, update, delete
  on public.reader_favorites
  to authenticated;
revoke all on table public.reader_book_collections from public, anon;
revoke all on table public.reader_book_collection_items from public, anon;
revoke all on table public.reader_book_favorites from public, anon;
grant select, insert, update, delete
  on table public.reader_book_collections,
    public.reader_book_collection_items,
    public.reader_book_favorites
  to authenticated;
grant all
  on table public.reader_book_collections,
    public.reader_book_collection_items,
    public.reader_book_favorites
  to service_role;

alter table public.profiles enable row level security;
alter table public.forum_topics enable row level security;
alter table public.forum_replies enable row level security;
alter table public.article_comments enable row level security;
alter table public.ratings enable row level security;
alter table public.content_views enable row level security;
alter table public.reader_favorites enable row level security;
alter table public.reader_book_collections enable row level security;
alter table public.reader_book_collections force row level security;
alter table public.reader_book_collection_items enable row level security;
alter table public.reader_book_collection_items force row level security;
alter table public.reader_book_favorites enable row level security;
alter table public.reader_book_favorites force row level security;
alter table public.comment_reports enable row level security;

create policy "Public profiles are readable"
on public.profiles for select
to anon, authenticated
using (true);

create policy "Users update their own profile"
on public.profiles for update
to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

create policy "Published topics are readable"
on public.forum_topics for select
to anon, authenticated
using (status = 'published' or author_id = (select auth.uid()) or public.is_community_moderator());

create policy "Authenticated users create topics"
on public.forum_topics for insert
to authenticated
with check ((select auth.uid()) = author_id);

create policy "Authors manage their topics"
on public.forum_topics for update
to authenticated
using (author_id = (select auth.uid()) or public.is_community_moderator())
with check (author_id = (select auth.uid()) or public.is_community_moderator());

create policy "Published replies are readable"
on public.forum_replies for select
to anon, authenticated
using (status = 'published' or author_id = (select auth.uid()) or public.is_community_moderator());

create policy "Authenticated users create replies"
on public.forum_replies for insert
to authenticated
with check ((select auth.uid()) = author_id);

create policy "Authors manage their replies"
on public.forum_replies for update
to authenticated
using (author_id = (select auth.uid()) or public.is_community_moderator())
with check (author_id = (select auth.uid()) or public.is_community_moderator());

create policy "Published comments are readable"
on public.article_comments for select
to anon, authenticated
using (status = 'published' or author_id = (select auth.uid()) or public.is_community_moderator());

create policy "Authenticated users create comments"
on public.article_comments for insert
to anon, authenticated
with check (
  (
    (select auth.uid()) is not null
    and (select auth.uid()) = author_id
    and guest_name is null
  ) or (
    (select auth.uid()) is null
    and author_id is null
    and guest_name is not null
  )
);

create policy "Authors manage their comments"
on public.article_comments for update
to authenticated
using (author_id = (select auth.uid()) or public.is_community_moderator())
with check (author_id = (select auth.uid()) or public.is_community_moderator());

create policy "Ratings are readable"
on public.ratings for select
to anon, authenticated
using (true);

create policy "Visitors record anonymous page views"
on public.content_views for insert
to anon, authenticated
with check (user_id is null or user_id = (select auth.uid()));

create policy "Editors read page views"
on public.content_views for select
to authenticated
using (public.is_community_moderator());

create policy "Readers view their own favorites"
on public.reader_favorites for select
to authenticated
using (user_id = (select auth.uid()));

create policy "Readers create their own favorites"
on public.reader_favorites for insert
to authenticated
with check (user_id = (select auth.uid()));

create policy "Readers update their own favorites"
on public.reader_favorites for update
to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

create policy "Readers delete their own favorites"
on public.reader_favorites for delete
to authenticated
using (user_id = (select auth.uid()));

create policy "Readers view their own book collections"
on public.reader_book_collections for select
to authenticated
using (user_id = (select auth.uid()));

create policy "Readers create their own book collections"
on public.reader_book_collections for insert
to authenticated
with check (user_id = (select auth.uid()) and visibility = 'private');

create policy "Readers update their own book collections"
on public.reader_book_collections for update
to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()) and visibility = 'private');

create policy "Readers delete their own book collections"
on public.reader_book_collections for delete
to authenticated
using (user_id = (select auth.uid()));

create policy "Readers view their own book collection items"
on public.reader_book_collection_items for select
to authenticated
using (user_id = (select auth.uid()));

create policy "Readers create their own book collection items"
on public.reader_book_collection_items for insert
to authenticated
with check (user_id = (select auth.uid()));

create policy "Readers update their own book collection items"
on public.reader_book_collection_items for update
to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

create policy "Readers delete their own book collection items"
on public.reader_book_collection_items for delete
to authenticated
using (user_id = (select auth.uid()));

create policy "Readers view their own book favorites"
on public.reader_book_favorites for select
to authenticated
using (user_id = (select auth.uid()));

create policy "Readers create their own book favorites"
on public.reader_book_favorites for insert
to authenticated
with check (user_id = (select auth.uid()));

create policy "Readers update their own book favorites"
on public.reader_book_favorites for update
to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

create policy "Readers delete their own book favorites"
on public.reader_book_favorites for delete
to authenticated
using (user_id = (select auth.uid()));

create policy "Editors read comment reports"
on public.comment_reports for select
to authenticated
using (public.is_community_moderator());

alter publication supabase_realtime add table
  public.forum_topics,
  public.forum_replies,
  public.article_comments,
  public.ratings;

-- END WHOLE ORIGINAL supabase/schema.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260728_cms_foundation.sql SHA256 e40a9758696c472e210378ed4ec4de87eaa5ae91091478b217dfc8ef584c3f22
-- «Проба Пера»: защищённая CMS и редакционный контур.
-- Выполняется после базовой схемы supabase/schema.sql.

create extension if not exists pgcrypto;

do $$
begin
  create type public.staff_role as enum ('owner', 'admin', 'editor');
exception
  when duplicate_object then null;
end
$$;

do $$
begin
  create type public.article_status as enum (
    'draft',
    'review',
    'scheduled',
    'published',
    'hidden',
    'archived'
  );
exception
  when duplicate_object then null;
end
$$;

do $$
begin
  create type public.page_status as enum ('draft', 'published', 'hidden');
exception
  when duplicate_object then null;
end
$$;

create table if not exists public.staff_memberships (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role public.staff_role not null default 'editor',
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.is_staff(
  allowed_roles public.staff_role[] default array[
    'owner'::public.staff_role,
    'admin'::public.staff_role,
    'editor'::public.staff_role
  ]
)
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.staff_memberships
    where user_id = (select auth.uid())
      and role = any(allowed_roles)
  );
$$;

revoke all on function public.is_staff(public.staff_role[]) from public;
grant execute on function public.is_staff(public.staff_role[]) to authenticated;

-- Роль сообщества больше не берётся из саморедактируемого профиля.
create or replace function public.is_community_moderator()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select public.is_staff();
$$;

-- Профиль можно редактировать самостоятельно, но роль сообщества - только
-- через доверенный серверный контур. Одной RLS для защиты отдельного столбца
-- недостаточно, поэтому права выдаются только на безопасные поля.
revoke update on public.profiles from authenticated;
grant update(display_name, avatar_url, bio) on public.profiles to authenticated;

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 120),
  description text not null default '',
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,119}$'),
  parent_id uuid references public.categories(id) on delete set null,
  image_url text,
  seo_title text check (char_length(seo_title) <= 180),
  seo_description text check (char_length(seo_description) <= 400),
  display_order integer not null default 0,
  is_visible boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tags (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 80),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,79}$'),
  description text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.media_assets (
  id uuid primary key default gen_random_uuid(),
  bucket text not null default 'editorial-media',
  object_path text not null unique,
  original_name text not null,
  mime_type text not null,
  byte_size bigint not null check (byte_size > 0 and byte_size <= 26214400),
  width integer check (width is null or width > 0),
  height integer check (height is null or height > 0),
  alt_text text not null default '' check (char_length(alt_text) <= 500),
  caption text not null default '' check (char_length(caption) <= 1000),
  creator text not null default '',
  source_url text,
  license_name text not null default '',
  license_url text,
  focus_x numeric(5,4) not null default 0.5 check (focus_x between 0 and 1),
  focus_y numeric(5,4) not null default 0.5 check (focus_y between 0 and 1),
  collection_name text not null default 'Общее',
  uploaded_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.articles (
  id uuid primary key default gen_random_uuid(),
  legacy_id text unique,
  title text not null check (char_length(title) between 3 and 240),
  subtitle text not null default '' check (char_length(subtitle) <= 360),
  excerpt text not null default '' check (char_length(excerpt) <= 700),
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  cover_media_id uuid references public.media_assets(id) on delete set null,
  cover_external_url text,
  cover_alt text not null default '' check (char_length(cover_alt) <= 500),
  category_id uuid references public.categories(id) on delete set null,
  author_id uuid references auth.users(id) on delete set null,
  status public.article_status not null default 'draft',
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,179}$'),
  legacy_path text unique check (legacy_path is null or legacy_path like '/%'),
  published_at timestamptz,
  scheduled_at timestamptz,
  featured boolean not null default false,
  show_on_homepage boolean not null default false,
  pinned boolean not null default false,
  related_article_id uuid references public.articles(id) on delete set null,
  sources jsonb not null default '[]'::jsonb,
  bibliography jsonb not null default '[]'::jsonb,
  seo_title text check (char_length(seo_title) <= 180),
  seo_description text check (char_length(seo_description) <= 400),
  seo_keywords text[] not null default '{}',
  canonical_url text,
  og_title text check (char_length(og_title) <= 180),
  og_description text check (char_length(og_description) <= 400),
  og_media_id uuid references public.media_assets(id) on delete set null,
  allow_indexing boolean not null default true,
  created_by uuid not null references auth.users(id) on delete restrict,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  check (
    status <> 'scheduled'
    or scheduled_at is not null
  ),
  check (
    status <> 'published'
    or published_at is not null
  )
);

create table if not exists public.article_tags (
  article_id uuid not null references public.articles(id) on delete cascade,
  tag_id uuid not null references public.tags(id) on delete cascade,
  primary key (article_id, tag_id)
);

create table if not exists public.article_revisions (
  id bigint generated always as identity primary key,
  article_id uuid not null references public.articles(id) on delete cascade,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid references auth.users(id) on delete set null,
  change_summary text not null default '',
  created_at timestamptz not null default now(),
  unique (article_id, revision_number)
);

create table if not exists public.media_usages (
  media_id uuid not null references public.media_assets(id) on delete cascade,
  entity_type text not null check (
    entity_type in ('article', 'page', 'banner', 'homepage', 'category')
  ),
  entity_id uuid not null,
  field_name text not null default 'content',
  created_at timestamptz not null default now(),
  primary key (media_id, entity_type, entity_id, field_name)
);

create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 2 and 180),
  slug text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{1,119}$'),
  excerpt text not null default '',
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  status public.page_status not null default 'draft',
  seo_title text,
  seo_description text,
  canonical_url text,
  allow_indexing boolean not null default true,
  created_by uuid not null references auth.users(id) on delete restrict,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.page_revisions (
  id bigint generated always as identity primary key,
  page_id uuid not null references public.pages(id) on delete cascade,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (page_id, revision_number)
);

create table if not exists public.homepage_blocks (
  id uuid primary key default gen_random_uuid(),
  block_type text not null check (
    block_type in (
      'hero',
      'article-grid',
      'carousel',
      'editors-choice',
      'popular',
      'latest',
      'categories',
      'book-vs-screen',
      'literary-map',
      'awards',
      'subscription',
      'text'
    )
  ),
  title text not null default '',
  settings jsonb not null default '{}'::jsonb,
  display_order integer not null default 0,
  is_enabled boolean not null default true,
  background_style text not null default 'light' check (
    background_style in ('light', 'violet', 'orange', 'paper', 'transparent')
  ),
  background_media_id uuid references public.media_assets(id) on delete set null,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.banners (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 160),
  desktop_media_id uuid references public.media_assets(id) on delete set null,
  tablet_media_id uuid references public.media_assets(id) on delete set null,
  mobile_media_id uuid references public.media_assets(id) on delete set null,
  title text not null default '',
  description text not null default '',
  target_url text,
  button_text text not null default '',
  starts_at timestamptz,
  ends_at timestamptz,
  display_order integer not null default 0,
  is_active boolean not null default false,
  page_patterns text[] not null default array['/'],
  created_by uuid not null references auth.users(id) on delete restrict,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at is null or starts_at is null or ends_at > starts_at)
);

create table if not exists public.navigation_menus (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  location text not null unique check (location in ('header', 'footer')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.navigation_items (
  id uuid primary key default gen_random_uuid(),
  menu_id uuid not null references public.navigation_menus(id) on delete cascade,
  parent_id uuid references public.navigation_items(id) on delete cascade,
  label text not null check (char_length(label) between 1 and 100),
  href text not null,
  open_in_new_tab boolean not null default false,
  is_visible boolean not null default true,
  display_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.redirects (
  id uuid primary key default gen_random_uuid(),
  source_path text not null unique check (source_path like '/%'),
  destination_path text not null check (destination_path like '/%' or destination_path ~ '^https://'),
  status_code smallint not null default 301 check (status_code in (301, 302, 307, 308)),
  is_active boolean not null default true,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.publication_jobs (
  id uuid primary key default gen_random_uuid(),
  article_id uuid references public.articles(id) on delete cascade,
  run_at timestamptz not null,
  status text not null default 'pending' check (
    status in ('pending', 'running', 'completed', 'failed', 'cancelled')
  ),
  last_error text,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists articles_status_published_idx
  on public.articles(status, published_at desc)
  where deleted_at is null;
create index if not exists articles_category_idx
  on public.articles(category_id, published_at desc)
  where deleted_at is null;
create index if not exists articles_updated_idx on public.articles(updated_at desc);
create index if not exists articles_scheduled_idx
  on public.articles(scheduled_at)
  where status = 'scheduled' and deleted_at is null;
create index if not exists article_revisions_article_idx
  on public.article_revisions(article_id, revision_number desc);
create index if not exists media_assets_created_idx
  on public.media_assets(created_at desc)
  where deleted_at is null;
create index if not exists admin_audit_created_idx
  on public.admin_audit_log(created_at desc);
create index if not exists publication_jobs_run_idx
  on public.publication_jobs(run_at)
  where status = 'pending';

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create or replace function public.capture_article_revision()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_revision integer;
begin
  if old is not distinct from new then
    return new;
  end if;

  select coalesce(max(revision_number), 0) + 1
  into next_revision
  from public.article_revisions
  where article_id = old.id;

  insert into public.article_revisions (
    article_id,
    revision_number,
    snapshot,
    changed_by
  )
  values (
    old.id,
    next_revision,
    to_jsonb(old),
    coalesce(new.updated_by, (select auth.uid()))
  );

  return new;
end;
$$;

drop trigger if exists articles_capture_revision on public.articles;
create trigger articles_capture_revision
  before update on public.articles
  for each row execute function public.capture_article_revision();

do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'staff_memberships',
    'categories',
    'media_assets',
    'articles',
    'pages',
    'homepage_blocks',
    'banners',
    'navigation_menus',
    'navigation_items',
    'redirects',
    'publication_jobs'
  ]
  loop
    execute format('drop trigger if exists %I_set_updated_at on public.%I', table_name, table_name);
    execute format(
      'create trigger %I_set_updated_at before update on public.%I for each row execute function public.set_updated_at()',
      table_name,
      table_name
    );
  end loop;
end
$$;

alter table public.staff_memberships enable row level security;
alter table public.categories enable row level security;
alter table public.tags enable row level security;
alter table public.media_assets enable row level security;
alter table public.articles enable row level security;
alter table public.article_tags enable row level security;
alter table public.article_revisions enable row level security;
alter table public.media_usages enable row level security;
alter table public.pages enable row level security;
alter table public.page_revisions enable row level security;
alter table public.homepage_blocks enable row level security;
alter table public.banners enable row level security;
alter table public.navigation_menus enable row level security;
alter table public.navigation_items enable row level security;
alter table public.redirects enable row level security;
alter table public.admin_audit_log enable row level security;
alter table public.publication_jobs enable row level security;

create policy "Staff read their membership"
on public.staff_memberships for select
to authenticated
using (user_id = (select auth.uid()) or public.is_staff(array['owner'::public.staff_role]));

create policy "Owners manage staff"
on public.staff_memberships for all
to authenticated
using (public.is_staff(array['owner'::public.staff_role]))
with check (public.is_staff(array['owner'::public.staff_role]));

create policy "Public read visible categories"
on public.categories for select
to anon, authenticated
using (is_visible);

create policy "Staff manage categories"
on public.categories for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Public read tags"
on public.tags for select
to anon, authenticated
using (true);

create policy "Staff manage tags"
on public.tags for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Public read active media metadata"
on public.media_assets for select
to anon, authenticated
using (deleted_at is null);

create policy "Staff create media metadata"
on public.media_assets for insert
to authenticated
with check (public.is_staff() and uploaded_by = (select auth.uid()));

create policy "Staff update media metadata"
on public.media_assets for update
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Staff delete media metadata"
on public.media_assets for delete
to authenticated
using (public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role]));

create policy "Public read published articles"
on public.articles for select
to anon, authenticated
using (
  (
    status = 'published'
    and published_at <= now()
    and deleted_at is null
  )
);

create policy "Staff create articles"
on public.articles for insert
to authenticated
with check (
  public.is_staff()
  and created_by = (select auth.uid())
  and updated_by = (select auth.uid())
);

create policy "Staff update articles"
on public.articles for update
to authenticated
using (public.is_staff())
with check (public.is_staff() and updated_by = (select auth.uid()));

create policy "Owners and admins delete articles"
on public.articles for delete
to authenticated
using (public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role]));

create policy "Public read published article tags"
on public.article_tags for select
to anon, authenticated
using (
  exists (
    select 1 from public.articles
    where id = article_id
      and status = 'published'
      and published_at <= now()
      and deleted_at is null
  )
);

create policy "Staff manage article tags"
on public.article_tags for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Staff read revisions"
on public.article_revisions for select
to authenticated
using (public.is_staff());

create policy "Staff manage media usage"
on public.media_usages for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Public read published pages"
on public.pages for select
to anon, authenticated
using (
  (status = 'published' and deleted_at is null)
);

create policy "Staff manage pages"
on public.pages for all
to authenticated
using (public.is_staff())
with check (
  public.is_staff()
  and created_by is not null
  and updated_by = (select auth.uid())
);

create policy "Staff read page revisions"
on public.page_revisions for select
to authenticated
using (public.is_staff());

create policy "Public read enabled homepage blocks"
on public.homepage_blocks for select
to anon, authenticated
using (is_enabled);

create policy "Staff manage homepage blocks"
on public.homepage_blocks for all
to authenticated
using (public.is_staff())
with check (public.is_staff() and updated_by = (select auth.uid()));

create policy "Public read active banners"
on public.banners for select
to anon, authenticated
using (
  (
    is_active
    and (starts_at is null or starts_at <= now())
    and (ends_at is null or ends_at > now())
  )
);

create policy "Staff manage banners"
on public.banners for all
to authenticated
using (public.is_staff())
with check (
  public.is_staff()
  and created_by is not null
  and updated_by = (select auth.uid())
);

create policy "Public read navigation menus"
on public.navigation_menus for select
to anon, authenticated
using (true);

create policy "Staff manage navigation menus"
on public.navigation_menus for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Public read visible navigation items"
on public.navigation_items for select
to anon, authenticated
using (is_visible);

create policy "Staff manage navigation items"
on public.navigation_items for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Public read active redirects"
on public.redirects for select
to anon, authenticated
using (is_active);

create policy "Staff manage redirects"
on public.redirects for all
to authenticated
using (public.is_staff())
with check (
  public.is_staff()
  and created_by = (select auth.uid())
);

create policy "Staff read audit log"
on public.admin_audit_log for select
to authenticated
using (public.is_staff());

create policy "Staff append audit log"
on public.admin_audit_log for insert
to authenticated
with check (public.is_staff() and actor_id = (select auth.uid()));

create policy "Staff manage publication jobs"
on public.publication_jobs for all
to authenticated
using (public.is_staff())
with check (
  public.is_staff()
  and created_by = (select auth.uid())
);

-- Публичная корзина Storage: читать можно всем, изменять - только редакции.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'editorial-media',
  'editorial-media',
  true,
  26214400,
  array['image/jpeg', 'image/png', 'image/webp', 'image/avif']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create policy "Public read editorial media"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'editorial-media');

create policy "Staff upload editorial media"
on storage.objects for insert
to authenticated
with check (bucket_id = 'editorial-media' and public.is_staff());

create policy "Staff update editorial media"
on storage.objects for update
to authenticated
using (bucket_id = 'editorial-media' and public.is_staff())
with check (bucket_id = 'editorial-media' and public.is_staff());

create policy "Owners and admins delete editorial media"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'editorial-media'
  and public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
);

insert into public.navigation_menus (name, location)
values
  ('Верхнее меню', 'header'),
  ('Меню подвала', 'footer')
on conflict (location) do nothing;

insert into public.categories (name, slug, description, display_order)
values
  ('Мнение о книге', 'book-opinions', 'Авторские рецензии и размышления о книгах.', 10),
  ('Книга и экранизация', 'screen-adaptations', 'Сравнение литературного текста и экранной версии.', 20),
  ('Писатели мира', 'writers-world', 'Биографии, судьбы и литературные маршруты.', 30),
  ('Книжный гид и подборки', 'book-guides', 'Тематические подборки и рекомендации.', 40),
  ('Литературные премии', 'awards', 'История наград, лауреаты и произведения.', 50),
  ('Фольклор и мифология', 'folklore', 'Мифы, легенды и устная традиция.', 60),
  ('Русский язык', 'language', 'Редкие слова, история и культура речи.', 70),
  ('О литературе и культуре', 'literary-essays', 'Эссе о литературе и культурных явлениях.', 80),
  ('Литературные истории', 'author-stories', 'Профессии писателей и необычные истории.', 90)
on conflict (slug) do nothing;

-- Первый владелец назначается вручную после регистрации:
-- insert into public.staff_memberships (user_id, role)
-- select id, 'owner' from auth.users where email = 'owner@example.com';

-- END WHOLE ORIGINAL supabase/migrations/20260728_cms_foundation.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260730_literary_archive.sql SHA256 61efd3ae702719a9f8c915a4c2716aa8bb7b4c9072f4c37a01d0a0417fb387c7
-- Нормализованный редакционный контур книжного архива.
-- Главным источником энциклопедических данных остаётся src/data/countries.
-- Эти таблицы дают CMS безопасный рабочий слой для проверки произведений,
-- конкретных изданий и ISBN без дублирования одной обложки на уровне произведения.

create table if not exists public.literary_works (
  id uuid primary key default gen_random_uuid(),
  legacy_id text not null unique check (char_length(legacy_id) between 2 and 180),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  title text not null check (char_length(title) between 1 and 300),
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{0,179}$'),
  original_title text not null default '' check (char_length(original_title) <= 300),
  first_published integer check (first_published between -3000 and 2100),
  original_language text not null default '' check (char_length(original_language) <= 120),
  genres text[] not null default '{}',
  tags text[] not null default '{}',
  description text not null default '' check (char_length(description) <= 5000),
  source_url text,
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (writer_id, slug)
);

create table if not exists public.book_editions (
  id uuid primary key default gen_random_uuid(),
  legacy_id text not null unique check (char_length(legacy_id) between 2 and 240),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  title text not null default '' check (char_length(title) <= 300),
  isbn_10 text check (
    isbn_10 is null
    or regexp_replace(isbn_10, '[^0-9Xx]', '', 'g') ~ '^[0-9]{9}[0-9Xx]$'
  ),
  isbn_13 text check (
    isbn_13 is null
    or regexp_replace(isbn_13, '[^0-9]', '', 'g') ~ '^[0-9]{13}$'
  ),
  publisher text not null default '' check (char_length(publisher) <= 240),
  publication_year integer check (publication_year between 1400 and 2100),
  language text not null default '' check (char_length(language) <= 120),
  format text not null default '' check (char_length(format) <= 120),
  page_count integer check (page_count is null or page_count > 0),
  cover_url text,
  cover_source_url text,
  cover_rights_status text not null default 'unverified'
    check (
      cover_rights_status in (
        'public-domain',
        'licensed',
        'permission',
        'editorial-original',
        'external-preview',
        'unverified'
      )
    ),
  license_name text not null default '' check (char_length(license_name) <= 240),
  license_url text,
  creator text not null default '' check (char_length(creator) <= 240),
  rights_holder text not null default '' check (char_length(rights_holder) <= 240),
  rights_checked_at date,
  source_url text,
  is_primary boolean not null default false,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (
    cover_url is null
    or (
      cover_source_url is not null
      and cover_rights_status <> 'unverified'
      and rights_checked_at is not null
    )
  )
);

create unique index if not exists literary_works_country_legacy_idx
  on public.literary_works(country_id, legacy_id);

create index if not exists literary_works_writer_idx
  on public.literary_works(country_id, writer_id, editorial_status);

create index if not exists literary_works_search_idx
  on public.literary_works
  using gin (
    to_tsvector(
      'simple',
      coalesce(title, '') || ' ' || coalesce(original_title, '') || ' ' ||
      coalesce(description, '')
    )
  );

create unique index if not exists book_editions_isbn_10_unique_idx
  on public.book_editions (
    regexp_replace(upper(isbn_10), '[^0-9X]', '', 'g')
  )
  where isbn_10 is not null;

create unique index if not exists book_editions_isbn_13_unique_idx
  on public.book_editions (
    regexp_replace(isbn_13, '[^0-9]', '', 'g')
  )
  where isbn_13 is not null;

create unique index if not exists book_editions_one_primary_idx
  on public.book_editions(work_id)
  where is_primary;

create index if not exists book_editions_work_idx
  on public.book_editions(work_id, publication_year desc);

drop trigger if exists literary_works_set_updated_at on public.literary_works;
create trigger literary_works_set_updated_at
  before update on public.literary_works
  for each row execute function public.set_updated_at();

drop trigger if exists book_editions_set_updated_at on public.book_editions;
create trigger book_editions_set_updated_at
  before update on public.book_editions
  for each row execute function public.set_updated_at();

alter table public.literary_works enable row level security;
alter table public.book_editions enable row level security;

create policy "Public read reviewed literary works"
on public.literary_works for select
to anon, authenticated
using (editorial_status in ('reviewed', 'verified'));

create policy "Staff manage literary works"
on public.literary_works for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

create policy "Public read verified book editions"
on public.book_editions for select
to anon, authenticated
using (
  (
    cover_url is null
    or (
      cover_rights_status <> 'unverified'
      and cover_source_url is not null
      and rights_checked_at is not null
    )
  )
  and exists (
    select 1
    from public.literary_works
    where literary_works.id = book_editions.work_id
      and literary_works.editorial_status in ('reviewed', 'verified')
  )
);

create policy "Staff manage book editions"
on public.book_editions for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

-- END WHOLE ORIGINAL supabase/migrations/20260730_literary_archive.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260730_page_revision_history.sql SHA256 64a6d3ee5e94a3adca1e419f5f9d9be89d92f17d6703db5f1987a45e8cafc91e
-- Version history for permanent CMS pages.
-- Article revisions were part of the initial CMS migration; pages use the
-- same immutable-snapshot model so every editorial change is recoverable.

create or replace function public.capture_page_revision()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_revision integer;
begin
  if old is not distinct from new then
    return new;
  end if;

  select coalesce(max(revision_number), 0) + 1
  into next_revision
  from public.page_revisions
  where page_id = old.id;

  insert into public.page_revisions (
    page_id,
    revision_number,
    snapshot,
    changed_by
  )
  values (
    old.id,
    next_revision,
    to_jsonb(old),
    coalesce(new.updated_by, (select auth.uid()))
  );

  return new;
end;
$$;

drop trigger if exists pages_capture_revision on public.pages;
create trigger pages_capture_revision
  before update on public.pages
  for each row execute function public.capture_page_revision();

create index if not exists page_revisions_page_idx
  on public.page_revisions(page_id, revision_number desc);

-- END WHOLE ORIGINAL supabase/migrations/20260730_page_revision_history.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260730_staff_management.sql SHA256 c2203867f8f0068fdefd6b4ecd0f2f3c4bf747263414402758fac0c3fa180a40
-- Owner-only staff management by email. The dashboard never receives a
-- service-role key and cannot enumerate auth.users.

create or replace function public.owner_set_staff_member(
  p_email text,
  p_role public.staff_role
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  target_user_id uuid;
  current_role public.staff_role;
  owner_count integer;
begin
  if not public.is_staff(array['owner'::public.staff_role]) then
    raise exception 'Owner access required';
  end if;

  select id into target_user_id
  from auth.users
  where lower(email) = lower(btrim(p_email))
  limit 1;

  if target_user_id is null then
    raise exception 'User must register before being added to the editorial team';
  end if;

  select role into current_role
  from public.staff_memberships
  where user_id = target_user_id;

  if current_role = 'owner'::public.staff_role
    and p_role <> 'owner'::public.staff_role then
    select count(*) into owner_count
    from public.staff_memberships
    where role = 'owner'::public.staff_role;
    if owner_count <= 1 then
      raise exception 'The last owner cannot be demoted';
    end if;
  end if;

  insert into public.staff_memberships (user_id, role, created_by)
  values (target_user_id, p_role, (select auth.uid()))
  on conflict (user_id) do update
  set role = excluded.role, updated_at = now();

  return target_user_id;
end;
$$;

create or replace function public.owner_remove_staff_member(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  target_role public.staff_role;
  owner_count integer;
begin
  if not public.is_staff(array['owner'::public.staff_role]) then
    raise exception 'Owner access required';
  end if;
  if p_user_id = (select auth.uid()) then
    raise exception 'Use another owner account to remove your own access';
  end if;

  select role into target_role
  from public.staff_memberships
  where user_id = p_user_id;

  if target_role = 'owner'::public.staff_role then
    select count(*) into owner_count
    from public.staff_memberships
    where role = 'owner'::public.staff_role;
    if owner_count <= 1 then
      raise exception 'The last owner cannot be removed';
    end if;
  end if;

  delete from public.staff_memberships where user_id = p_user_id;
end;
$$;

revoke all on function public.owner_set_staff_member(text, public.staff_role)
  from public;
revoke all on function public.owner_remove_staff_member(uuid) from public;
grant execute on function public.owner_set_staff_member(text, public.staff_role)
  to authenticated;
grant execute on function public.owner_remove_staff_member(uuid)
  to authenticated;

-- END WHOLE ORIGINAL supabase/migrations/20260730_staff_management.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260808_article_translations.sql SHA256 daf65baf551218d7c0d4c3e045d6f95c3393f2f3709a2a26cf077d1e3fcd921e
-- Additive bilingual article storage. Existing public.articles columns remain the
-- Russian compatibility source until the admin application is migrated.

do $$
begin
  create type public.article_translation_status as enum (
    'draft',
    'review',
    'approved',
    'published',
    'stale',
    'archived'
  );
exception
  when duplicate_object then null;
end
$$;

alter table public.articles
  add column if not exists source_locale text not null default 'ru'
  check (source_locale in ('ru', 'en'));

create table if not exists public.article_translations (
  id uuid primary key default gen_random_uuid(),
  article_id uuid not null references public.articles(id) on delete cascade,
  locale text not null check (locale in ('ru', 'en')),
  title text not null check (char_length(title) between 3 and 240),
  subtitle text not null default '' check (char_length(subtitle) <= 360),
  excerpt text not null default '' check (char_length(excerpt) <= 700),
  content_json jsonb not null default '{"type":"doc","content":[]}'::jsonb,
  content_html text not null default '',
  cover_alt text not null default '' check (char_length(cover_alt) <= 500),
  slug text not null check (slug ~ '^[a-z0-9][a-z0-9-]{1,179}$'),
  sources jsonb not null default '[]'::jsonb,
  bibliography jsonb not null default '[]'::jsonb,
  seo_title text check (char_length(seo_title) <= 180),
  seo_description text check (char_length(seo_description) <= 400),
  seo_keywords text[] not null default '{}',
  canonical_url text,
  og_title text check (char_length(og_title) <= 180),
  og_description text check (char_length(og_description) <= 400),
  status public.article_translation_status not null default 'draft',
  source_content_hash text,
  source_article_updated_at timestamptz,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  approved_by uuid references auth.users(id) on delete set null,
  approved_at timestamptz,
  published_at timestamptz,
  created_by uuid not null references auth.users(id) on delete restrict,
  updated_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (article_id, locale),
  unique (locale, slug),
  check (
    status not in ('approved', 'published')
    or approved_at is not null
  ),
  check (
    status <> 'published'
    or published_at is not null
  )
);

create table if not exists public.article_translation_revisions (
  id bigint generated always as identity primary key,
  article_translation_id uuid not null
    references public.article_translations(id) on delete cascade,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid references auth.users(id) on delete set null,
  change_summary text not null default '',
  created_at timestamptz not null default now(),
  unique (article_translation_id, revision_number)
);

create index if not exists article_translations_article_locale_idx
  on public.article_translations(article_id, locale);
create index if not exists article_translations_release_idx
  on public.article_translations(locale, status, published_at desc)
  where deleted_at is null;
create index if not exists article_translation_revisions_translation_idx
  on public.article_translation_revisions(
    article_translation_id,
    revision_number desc
  );

create or replace function public.article_source_content_hash(
  article_row public.articles
)
returns text
language sql
immutable
set search_path = ''
as $$
  select pg_catalog.md5(
    coalesce(article_row.title, '') || pg_catalog.chr(31) ||
    coalesce(article_row.subtitle, '') || pg_catalog.chr(31) ||
    coalesce(article_row.excerpt, '') || pg_catalog.chr(31) ||
    coalesce(article_row.content_json::text, '') || pg_catalog.chr(31) ||
    coalesce(article_row.content_html, '') || pg_catalog.chr(31) ||
    coalesce(article_row.cover_alt, '') || pg_catalog.chr(31) ||
    coalesce(article_row.slug, '') || pg_catalog.chr(31) ||
    coalesce(article_row.sources::text, '') || pg_catalog.chr(31) ||
    coalesce(article_row.bibliography::text, '') || pg_catalog.chr(31) ||
    coalesce(article_row.seo_title, '') || pg_catalog.chr(31) ||
    coalesce(article_row.seo_description, '') || pg_catalog.chr(31) ||
    coalesce(article_row.seo_keywords::text, '') || pg_catalog.chr(31) ||
    coalesce(article_row.og_title, '') || pg_catalog.chr(31) ||
    coalesce(article_row.og_description, '')
  );
$$;

create or replace function public.capture_article_translation_revision()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_revision integer;
begin
  if old is not distinct from new then
    return new;
  end if;

  select coalesce(max(revision_number), 0) + 1
  into next_revision
  from public.article_translation_revisions
  where article_translation_id = old.id;

  insert into public.article_translation_revisions (
    article_translation_id,
    revision_number,
    snapshot,
    changed_by
  )
  values (
    old.id,
    next_revision,
    to_jsonb(old),
    coalesce(new.updated_by, (select auth.uid()))
  );

  return new;
end;
$$;

drop trigger if exists article_translations_capture_revision
  on public.article_translations;
create trigger article_translations_capture_revision
  before update on public.article_translations
  for each row execute function public.capture_article_translation_revision();

drop trigger if exists article_translations_set_updated_at
  on public.article_translations;
create trigger article_translations_set_updated_at
  before update on public.article_translations
  for each row execute function public.set_updated_at();

-- Preserve the current editor: every existing article is copied to an explicit
-- Russian translation without changing or deleting its compatibility columns.
insert into public.article_translations (
  article_id,
  locale,
  title,
  subtitle,
  excerpt,
  content_json,
  content_html,
  cover_alt,
  slug,
  sources,
  bibliography,
  seo_title,
  seo_description,
  seo_keywords,
  canonical_url,
  og_title,
  og_description,
  status,
  source_content_hash,
  source_article_updated_at,
  reviewed_by,
  reviewed_at,
  approved_by,
  approved_at,
  published_at,
  created_by,
  updated_by,
  created_at,
  updated_at,
  deleted_at
)
select
  article.id,
  'ru',
  article.title,
  article.subtitle,
  article.excerpt,
  article.content_json,
  article.content_html,
  article.cover_alt,
  article.slug,
  article.sources,
  article.bibliography,
  article.seo_title,
  article.seo_description,
  article.seo_keywords,
  article.canonical_url,
  article.og_title,
  article.og_description,
  case
    when article.status = 'published' then 'published'
    when article.status in ('review', 'scheduled') then 'review'
    when article.status in ('hidden', 'archived') then 'archived'
    else 'draft'
  end::public.article_translation_status,
  public.article_source_content_hash(article),
  article.updated_at,
  case when article.status = 'published' then article.updated_by else null end,
  case when article.status = 'published' then article.published_at else null end,
  case when article.status = 'published' then article.updated_by else null end,
  case when article.status = 'published' then article.published_at else null end,
  case when article.status = 'published' then article.published_at else null end,
  article.created_by,
  article.updated_by,
  article.created_at,
  article.updated_at,
  article.deleted_at
from public.articles article
on conflict (article_id, locale) do nothing;

create or replace function public.sync_russian_article_translation()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_status public.article_translation_status;
  next_hash text;
begin
  next_status := case
    when new.status = 'published' then 'published'
    when new.status in ('review', 'scheduled') then 'review'
    when new.status in ('hidden', 'archived') then 'archived'
    else 'draft'
  end;
  next_hash := public.article_source_content_hash(new);

  insert into public.article_translations (
    article_id,
    locale,
    title,
    subtitle,
    excerpt,
    content_json,
    content_html,
    cover_alt,
    slug,
    sources,
    bibliography,
    seo_title,
    seo_description,
    seo_keywords,
    canonical_url,
    og_title,
    og_description,
    status,
    source_content_hash,
    source_article_updated_at,
    reviewed_by,
    reviewed_at,
    approved_by,
    approved_at,
    published_at,
    created_by,
    updated_by,
    created_at,
    updated_at,
    deleted_at
  )
  values (
    new.id,
    'ru',
    new.title,
    new.subtitle,
    new.excerpt,
    new.content_json,
    new.content_html,
    new.cover_alt,
    new.slug,
    new.sources,
    new.bibliography,
    new.seo_title,
    new.seo_description,
    new.seo_keywords,
    new.canonical_url,
    new.og_title,
    new.og_description,
    next_status,
    next_hash,
    new.updated_at,
    case when next_status = 'published' then new.updated_by else null end,
    case when next_status = 'published' then new.published_at else null end,
    case when next_status = 'published' then new.updated_by else null end,
    case when next_status = 'published' then new.published_at else null end,
    case when next_status = 'published' then new.published_at else null end,
    new.created_by,
    new.updated_by,
    new.created_at,
    new.updated_at,
    new.deleted_at
  )
  on conflict (article_id, locale) do update set
    title = excluded.title,
    subtitle = excluded.subtitle,
    excerpt = excluded.excerpt,
    content_json = excluded.content_json,
    content_html = excluded.content_html,
    cover_alt = excluded.cover_alt,
    slug = excluded.slug,
    sources = excluded.sources,
    bibliography = excluded.bibliography,
    seo_title = excluded.seo_title,
    seo_description = excluded.seo_description,
    seo_keywords = excluded.seo_keywords,
    canonical_url = excluded.canonical_url,
    og_title = excluded.og_title,
    og_description = excluded.og_description,
    status = excluded.status,
    source_content_hash = excluded.source_content_hash,
    source_article_updated_at = excluded.source_article_updated_at,
    reviewed_by = excluded.reviewed_by,
    reviewed_at = excluded.reviewed_at,
    approved_by = excluded.approved_by,
    approved_at = excluded.approved_at,
    published_at = excluded.published_at,
    updated_by = excluded.updated_by,
    deleted_at = excluded.deleted_at;

  if tg_op = 'UPDATE'
    and public.article_source_content_hash(old) is distinct from next_hash
  then
    update public.article_translations
    set
      status = 'stale',
      approved_by = null,
      approved_at = null,
      published_at = null,
      updated_by = new.updated_by,
      source_article_updated_at = new.updated_at
    where article_id = new.id
      and locale <> 'ru'
      and status in ('approved', 'published');
  end if;

  return new;
end;
$$;

drop trigger if exists articles_sync_russian_translation on public.articles;
create trigger articles_sync_russian_translation
  after insert or update of
    title,
    subtitle,
    excerpt,
    content_json,
    content_html,
    cover_alt,
    slug,
    sources,
    bibliography,
    seo_title,
    seo_description,
    seo_keywords,
    canonical_url,
    og_title,
    og_description,
    status,
    published_at,
    updated_by,
    deleted_at
  on public.articles
  for each row execute function public.sync_russian_article_translation();

alter table public.article_translations enable row level security;
alter table public.article_translation_revisions enable row level security;

drop policy if exists "Public read released article translations"
  on public.article_translations;
create policy "Public read released article translations"
on public.article_translations for select
to anon, authenticated
using (
  (
    status in ('approved', 'published')
    and deleted_at is null
    and exists (
      select 1
      from public.articles article
      where article.id = article_id
        and article.status = 'published'
        and article.published_at <= now()
        and article.deleted_at is null
    )
  )
);

drop policy if exists "Staff create article translations"
  on public.article_translations;
create policy "Staff create article translations"
on public.article_translations for insert
to authenticated
with check (
  public.is_staff()
  and created_by = (select auth.uid())
  and updated_by = (select auth.uid())
);

drop policy if exists "Staff update article translations"
  on public.article_translations;
create policy "Staff update article translations"
on public.article_translations for update
to authenticated
using (public.is_staff())
with check (
  public.is_staff()
  and updated_by = (select auth.uid())
);

drop policy if exists "Owners and admins delete article translations"
  on public.article_translations;
create policy "Owners and admins delete article translations"
on public.article_translations for delete
to authenticated
using (
  public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
);

drop policy if exists "Staff read article translation revisions"
  on public.article_translation_revisions;
create policy "Staff read article translation revisions"
on public.article_translation_revisions for select
to authenticated
using (public.is_staff());

-- END WHOLE ORIGINAL supabase/migrations/20260808_article_translations.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260808_book_translations_and_import_staging.sql SHA256 357871b2cc57bd534acb8c91d194b16b59e46ad0d4e2f38bd1fe63df0f20ef7c
-- Bilingual, source-aware publication workflow for literary works.
-- Discovery imports land in book_import_candidates. Only reviewed works with
-- complete RU/EN editorial text and provenance are visible through public RLS.

create table if not exists public.literary_work_translations (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  locale text not null check (locale in ('ru', 'en')),
  title text not null check (char_length(title) between 1 and 300),
  description text not null check (char_length(description) between 140 and 900),
  source_language text not null check (char_length(source_language) between 2 and 40),
  translation_method text not null
    check (
      translation_method in (
        'editorial-original',
        'human-translation',
        'licensed-source'
      )
    ),
  editorial_status text not null default 'draft'
    check (editorial_status in ('draft', 'reviewed', 'verified')),
  source_urls text[] not null default '{}',
  reviewed_at date,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, locale),
  check (
    editorial_status = 'draft'
    or (
      reviewed_at is not null
      and cardinality(source_urls) > 0
    )
  )
);

create table if not exists public.literary_work_sources (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  provider text not null check (char_length(provider) between 2 and 160),
  source_url text not null check (source_url ~ '^https://'),
  field_names text[] not null check (cardinality(field_names) > 0),
  license_name text,
  usage text not null
    check (usage in ('structured-data', 'reference-only', 'licensed-copy')),
  retrieved_at date not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, provider, source_url)
);

create table if not exists public.literary_work_external_ids (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  scheme text not null check (scheme ~ '^[a-z0-9][a-z0-9_-]{1,39}$'),
  external_id text not null check (char_length(external_id) between 1 and 180),
  source_url text not null check (source_url ~ '^https://'),
  created_at timestamptz not null default now(),
  unique (scheme, external_id),
  unique (work_id, scheme, external_id)
);

create table if not exists public.book_import_candidates (
  id uuid primary key default gen_random_uuid(),
  provider text not null check (provider ~ '^[a-z0-9][a-z0-9_-]{1,39}$'),
  external_id text not null check (char_length(external_id) between 1 and 180),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  writer_key text not null check (char_length(writer_key) between 3 and 320),
  title text not null check (char_length(title) between 1 and 300),
  source_url text not null check (source_url ~ '^https://'),
  quality_score integer not null default 0 check (quality_score between 0 and 100),
  status text not null default 'candidate'
    check (status in ('candidate', 'rejected', 'reviewed', 'promoted')),
  rejection_reasons text[] not null default '{}',
  payload jsonb not null default '{}'::jsonb,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  promoted_work_id uuid references public.literary_works(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, external_id),
  check (
    status not in ('reviewed', 'promoted')
    or (reviewed_by is not null and reviewed_at is not null)
  ),
  check (status <> 'promoted' or promoted_work_id is not null)
);

create index if not exists literary_work_translations_public_idx
  on public.literary_work_translations(work_id, locale, editorial_status);
create index if not exists literary_work_sources_work_idx
  on public.literary_work_sources(work_id);
create index if not exists literary_work_external_ids_work_idx
  on public.literary_work_external_ids(work_id);
create index if not exists book_import_candidates_queue_idx
  on public.book_import_candidates(status, quality_score desc, created_at);
create index if not exists book_import_candidates_writer_idx
  on public.book_import_candidates(writer_key, status);

drop trigger if exists literary_work_translations_set_updated_at
  on public.literary_work_translations;
create trigger literary_work_translations_set_updated_at
  before update on public.literary_work_translations
  for each row execute function public.set_updated_at();

drop trigger if exists literary_work_sources_set_updated_at
  on public.literary_work_sources;
create trigger literary_work_sources_set_updated_at
  before update on public.literary_work_sources
  for each row execute function public.set_updated_at();

drop trigger if exists book_import_candidates_set_updated_at
  on public.book_import_candidates;
create trigger book_import_candidates_set_updated_at
  before update on public.book_import_candidates
  for each row execute function public.set_updated_at();

alter table public.literary_work_translations enable row level security;
alter table public.literary_work_sources enable row level security;
alter table public.literary_work_external_ids enable row level security;
alter table public.book_import_candidates enable row level security;

create or replace function public.is_publishable_literary_work(target_work_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1
    from public.literary_works as work
    where work.id = target_work_id
      and work.editorial_status in ('reviewed', 'verified')
      and exists (
        select 1
        from public.literary_work_sources as source
        where source.work_id = work.id
      )
      and not exists (
        select 1
        from public.literary_work_sources as source
        where source.work_id = work.id
          and (
            btrim(source.provider) = ''
            or source.source_url !~* '^https://'
            or cardinality(source.field_names) = 0
            or source.retrieved_at is null
          )
      )
      and 2 = (
        select count(distinct translation.locale)
        from public.literary_work_translations as translation
        where translation.work_id = work.id
          and translation.locale in ('ru', 'en')
          and translation.editorial_status in ('reviewed', 'verified')
          and translation.reviewed_at is not null
          and btrim(translation.title) <> ''
          and btrim(translation.source_language) <> ''
          and char_length(btrim(translation.description)) between 140 and 900
          and (
            select count(*)
            from regexp_matches(
              btrim(translation.description),
              '[.!?…]+([[:space:]]|$)',
              'g'
            )
          ) between 2 and 3
          and case
            when translation.locale = 'ru'
              then translation.description ~ '[А-Яа-яЁё]'
            when translation.locale = 'en'
              then translation.description ~ '[A-Za-z]'
                -- PostgreSQL ARE has no portable Unicode Script=Cyrillic class.
                -- Check every code point across the current Cyrillic blocks.
                and not exists (
                  select 1
                  from unnest(
                    string_to_array(
                      translation.title || translation.description,
                      null::text
                    )
                  ) as glyph(value)
                  where ascii(glyph.value) between 1024 and 1327
                    or ascii(glyph.value) between 7296 and 7311
                    or ascii(glyph.value) between 11744 and 11775
                    or ascii(glyph.value) between 42560 and 42655
                    or ascii(glyph.value) between 65070 and 65071
                    or ascii(glyph.value) between 122928 and 123023
                )
            else false
          end
          and position('Р°' in translation.description) = 0
          and position('Рµ' in translation.description) = 0
          and position('Рё' in translation.description) = 0
          and position('СЃ' in translation.description) = 0
          and position('С‚' in translation.description) = 0
          and position('вЂ' in translation.description) = 0
          and cardinality(translation.source_urls) > 0
          and not exists (
            select 1
            from unnest(translation.source_urls) as declared(source_url)
            where declared.source_url is null
              or btrim(declared.source_url) !~* '^https://'
              or not exists (
                select 1
                from public.literary_work_sources as source
                where source.work_id = translation.work_id
                  and source.source_url = btrim(declared.source_url)
              )
          )
          and (
            translation.translation_method <> 'licensed-source'
            or exists (
              select 1
              from unnest(translation.source_urls) as declared(source_url)
              join public.literary_work_sources as source
                on source.work_id = translation.work_id
               and source.source_url = btrim(declared.source_url)
              where source.usage = 'licensed-copy'
                and btrim(coalesce(source.license_name, '')) <> ''
            )
          )
      )
  );
$$;

revoke all on function public.is_publishable_literary_work(uuid) from public;
grant execute on function public.is_publishable_literary_work(uuid)
  to anon, authenticated;

drop policy if exists "Public read reviewed literary works"
  on public.literary_works;
drop policy if exists "Public read publishable literary works"
  on public.literary_works;
create policy "Public read publishable literary works"
on public.literary_works for select
to anon, authenticated
using (public.is_publishable_literary_work(id));

drop policy if exists "Public read publishable work translations"
  on public.literary_work_translations;
create policy "Public read publishable work translations"
on public.literary_work_translations for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work translations"
  on public.literary_work_translations;
create policy "Staff manage work translations"
on public.literary_work_translations for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Public read publishable work sources"
  on public.literary_work_sources;
create policy "Public read publishable work sources"
on public.literary_work_sources for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work sources"
  on public.literary_work_sources;
create policy "Staff manage work sources"
on public.literary_work_sources for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Public read publishable work external ids"
  on public.literary_work_external_ids;
create policy "Public read publishable work external ids"
on public.literary_work_external_ids for select
to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Staff manage work external ids"
  on public.literary_work_external_ids;
create policy "Staff manage work external ids"
on public.literary_work_external_ids for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Staff manage book import candidates"
  on public.book_import_candidates;
create policy "Staff manage book import candidates"
on public.book_import_candidates for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

-- END WHOLE ORIGINAL supabase/migrations/20260808_book_translations_and_import_staging.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260812_homepage_block_revisions.sql SHA256 eaa188a8f0f185cafc787b7d356cca54c65d19647447fdf52dc96804f95b4b20
-- Immutable history for visual edits of homepage blocks. The public snapshot
-- still comes from homepage_blocks; this table is editorial recovery data only.

create table if not exists public.homepage_block_revisions (
  id bigint generated always as identity primary key,
  homepage_block_id uuid references public.homepage_blocks(id) on delete set null,
  revision_number integer not null,
  snapshot jsonb not null,
  changed_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (homepage_block_id, revision_number)
);

create or replace function public.capture_homepage_block_revision()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_revision integer;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;

  select coalesce(max(revision_number), 0) + 1
  into next_revision
  from public.homepage_block_revisions
  where homepage_block_id = old.id;

  insert into public.homepage_block_revisions (
    homepage_block_id,
    revision_number,
    snapshot,
    changed_by
  )
  values (
    old.id,
    next_revision,
    to_jsonb(old),
    coalesce(
      case when tg_op = 'UPDATE' then new.updated_by else old.updated_by end,
      (select auth.uid())
    )
  );

  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists homepage_blocks_capture_revision on public.homepage_blocks;
create trigger homepage_blocks_capture_revision
  before update or delete on public.homepage_blocks
  for each row execute function public.capture_homepage_block_revision();

create index if not exists homepage_block_revisions_block_idx
  on public.homepage_block_revisions(homepage_block_id, revision_number desc);

-- System blocks are singletons. This also turns a simultaneous first save
-- from two admin tabs into a visible uniqueness conflict instead of two
-- divergent records whose last-updated row silently wins.
with ranked_system_blocks as (
  select
    id,
    row_number() over (
      partition by settings ->> 'systemKey'
      order by updated_at desc, id desc
    ) as position
  from public.homepage_blocks
  where settings ? 'systemKey'
)
delete from public.homepage_blocks as block
using ranked_system_blocks as ranked
where block.id = ranked.id
  and ranked.position > 1;

create unique index if not exists homepage_blocks_system_key_unique_idx
  on public.homepage_blocks ((settings ->> 'systemKey'))
  where settings ? 'systemKey';

-- Every built-in public section is also a singleton. Keep the newest row if
-- an older deployment already allowed a race, then reject future duplicates.
with ranked_core_blocks as (
  select
    id,
    row_number() over (
      partition by settings ->> 'coreSectionKey'
      order by updated_at desc, id desc
    ) as position
  from public.homepage_blocks
  where settings ? 'coreSectionKey'
)
delete from public.homepage_blocks as block
using ranked_core_blocks as ranked
where block.id = ranked.id
  and ranked.position > 1;

create unique index if not exists homepage_blocks_core_section_key_unique_idx
  on public.homepage_blocks ((settings ->> 'coreSectionKey'))
  where settings ? 'coreSectionKey';

alter table public.homepage_block_revisions enable row level security;

drop policy if exists "Staff read homepage block revisions"
  on public.homepage_block_revisions;
create policy "Staff read homepage block revisions"
on public.homepage_block_revisions for select
to authenticated
using (public.is_staff());

-- END WHOLE ORIGINAL supabase/migrations/20260812_homepage_block_revisions.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260812_writer_and_work_revisions.sql SHA256 ea800be1c968aad3a59c3b0287ad0380074641142aa0930c2e2761f9165f78b0
-- Durable editor-owned overrides for writer profiles and revision history for
-- both writers and literary works. The static country files remain the safe
-- fallback; published CMS values are applied last during the public build.

create table if not exists public.writer_profile_overrides (
  id uuid primary key default gen_random_uuid(),
  country_id text not null check (char_length(country_id) between 2 and 120),
  writer_id text not null check (char_length(writer_id) between 2 and 180),
  fields jsonb not null default '{}'::jsonb,
  is_enabled boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (country_id, writer_id),
  check (jsonb_typeof(fields) = 'object')
);

create index if not exists writer_profile_overrides_public_idx
  on public.writer_profile_overrides(country_id, writer_id)
  where is_enabled;

drop trigger if exists writer_profile_overrides_set_updated_at
  on public.writer_profile_overrides;
create trigger writer_profile_overrides_set_updated_at
  before update on public.writer_profile_overrides
  for each row execute function public.set_updated_at();

create table if not exists public.writer_profile_override_revisions (
  id bigint generated always as identity primary key,
  override_id uuid references public.writer_profile_overrides(id) on delete set null,
  country_id text not null,
  writer_id text not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create or replace function public.capture_writer_profile_override_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  revision_actor uuid;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  if tg_op = 'UPDATE' then
    revision_actor := coalesce(new.updated_by, (select auth.uid()));
  else
    revision_actor := (select auth.uid());
  end if;
  insert into public.writer_profile_override_revisions (
    override_id,
    country_id,
    writer_id,
    snapshot,
    revised_by
  ) values (
    old.id,
    old.country_id,
    old.writer_id,
    to_jsonb(old),
    revision_actor
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists writer_profile_overrides_capture_revision
  on public.writer_profile_overrides;
create trigger writer_profile_overrides_capture_revision
  before update or delete on public.writer_profile_overrides
  for each row execute function public.capture_writer_profile_override_revision();

alter table public.literary_works
  add column if not exists updated_by uuid references auth.users(id) on delete set null;

alter table public.literary_works
  add column if not exists is_cms_locked boolean not null default false;

create table if not exists public.literary_work_revisions (
  id bigint generated always as identity primary key,
  work_id uuid references public.literary_works(id) on delete set null,
  legacy_id text not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create or replace function public.capture_literary_work_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  revision_actor uuid;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  if tg_op = 'UPDATE' then
    revision_actor := coalesce(new.updated_by, (select auth.uid()));
  else
    revision_actor := (select auth.uid());
  end if;
  insert into public.literary_work_revisions (
    work_id,
    legacy_id,
    snapshot,
    revised_by
  ) values (
    old.id,
    old.legacy_id,
    to_jsonb(old),
    revision_actor
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists literary_works_capture_revision on public.literary_works;
create trigger literary_works_capture_revision
  before update or delete on public.literary_works
  for each row execute function public.capture_literary_work_revision();

create table if not exists public.site_chrome_revisions (
  id bigint generated always as identity primary key,
  entity_type text not null check (entity_type in ('banner', 'navigation_item')),
  entity_id uuid not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create index if not exists site_chrome_revisions_entity_idx
  on public.site_chrome_revisions(entity_type, entity_id, revised_at desc);

create or replace function public.capture_site_chrome_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  insert into public.site_chrome_revisions (
    entity_type,
    entity_id,
    snapshot,
    revised_by
  ) values (
    case when tg_table_name = 'banners' then 'banner' else 'navigation_item' end,
    old.id,
    to_jsonb(old),
    (select auth.uid())
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists banners_capture_visual_revision on public.banners;
create trigger banners_capture_visual_revision
  before update or delete on public.banners
  for each row execute function public.capture_site_chrome_revision();

drop trigger if exists navigation_items_capture_visual_revision
  on public.navigation_items;
create trigger navigation_items_capture_visual_revision
  before update or delete on public.navigation_items
  for each row execute function public.capture_site_chrome_revision();

alter table public.writer_profile_overrides enable row level security;
alter table public.writer_profile_override_revisions enable row level security;
alter table public.literary_work_revisions enable row level security;
alter table public.site_chrome_revisions enable row level security;

drop policy if exists "Public read enabled writer overrides"
  on public.writer_profile_overrides;
create policy "Public read enabled writer overrides"
on public.writer_profile_overrides for select
to anon, authenticated
using (is_enabled);

drop policy if exists "Staff manage writer overrides"
  on public.writer_profile_overrides;
create policy "Staff manage writer overrides"
on public.writer_profile_overrides for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Staff read writer override revisions"
  on public.writer_profile_override_revisions;
create policy "Staff read writer override revisions"
on public.writer_profile_override_revisions for select
to authenticated
using (public.is_staff());

drop policy if exists "Staff read literary work revisions"
  on public.literary_work_revisions;
create policy "Staff read literary work revisions"
on public.literary_work_revisions for select
to authenticated
using (public.is_staff());

drop policy if exists "Staff read site chrome revisions"
  on public.site_chrome_revisions;
create policy "Staff read site chrome revisions"
on public.site_chrome_revisions for select
to authenticated
using (public.is_staff());

-- END WHOLE ORIGINAL supabase/migrations/20260812_writer_and_work_revisions.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260813_editorial_database_admin.sql SHA256 339c1e87580f4ddd3a82a1e98beb82dc2a1c2a79983c29a7e348e3e62931f53e
-- Full editorial database overrides for countries plus missing history for
-- exact book editions. Static TypeScript records remain the audited fallback;
-- enabled CMS overrides are exported and applied last by the public build.

create table if not exists public.country_profile_overrides (
  id uuid primary key default gen_random_uuid(),
  country_id text not null unique
    check (char_length(country_id) between 2 and 120),
  fields jsonb not null default '{}'::jsonb,
  is_enabled boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (jsonb_typeof(fields) = 'object')
);

create index if not exists country_profile_overrides_public_idx
  on public.country_profile_overrides(country_id)
  where is_enabled;

drop trigger if exists country_profile_overrides_set_updated_at
  on public.country_profile_overrides;
create trigger country_profile_overrides_set_updated_at
  before update on public.country_profile_overrides
  for each row execute function public.set_updated_at();

create table if not exists public.country_profile_override_revisions (
  id bigint generated always as identity primary key,
  override_id uuid references public.country_profile_overrides(id)
    on delete set null,
  country_id text not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create index if not exists country_profile_override_revisions_country_idx
  on public.country_profile_override_revisions(country_id, revised_at desc);

create or replace function public.capture_country_profile_override_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  revision_actor uuid;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  if tg_op = 'UPDATE' then
    revision_actor := coalesce(new.updated_by, (select auth.uid()));
  else
    revision_actor := (select auth.uid());
  end if;
  insert into public.country_profile_override_revisions (
    override_id,
    country_id,
    snapshot,
    revised_by
  ) values (
    old.id,
    old.country_id,
    to_jsonb(old),
    revision_actor
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists country_profile_overrides_capture_revision
  on public.country_profile_overrides;
create trigger country_profile_overrides_capture_revision
  before update or delete on public.country_profile_overrides
  for each row execute function public.capture_country_profile_override_revision();

create table if not exists public.book_edition_revisions (
  id bigint generated always as identity primary key,
  edition_id uuid references public.book_editions(id) on delete set null,
  legacy_id text not null,
  snapshot jsonb not null,
  revised_at timestamptz not null default now(),
  revised_by uuid references auth.users(id) on delete set null
);

create index if not exists book_edition_revisions_edition_idx
  on public.book_edition_revisions(edition_id, revised_at desc);

create or replace function public.capture_book_edition_revision()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;
  insert into public.book_edition_revisions (
    edition_id,
    legacy_id,
    snapshot,
    revised_by
  ) values (
    old.id,
    old.legacy_id,
    to_jsonb(old),
    (select auth.uid())
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

drop trigger if exists book_editions_capture_revision on public.book_editions;
create trigger book_editions_capture_revision
  before update or delete on public.book_editions
  for each row execute function public.capture_book_edition_revision();

alter table public.country_profile_overrides enable row level security;
alter table public.country_profile_override_revisions enable row level security;
alter table public.book_edition_revisions enable row level security;

drop policy if exists "Public read enabled country overrides"
  on public.country_profile_overrides;
create policy "Public read enabled country overrides"
on public.country_profile_overrides for select
to anon, authenticated
using (is_enabled);

drop policy if exists "Staff manage country overrides"
  on public.country_profile_overrides;
create policy "Staff manage country overrides"
on public.country_profile_overrides for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

drop policy if exists "Staff read country override revisions"
  on public.country_profile_override_revisions;
create policy "Staff read country override revisions"
on public.country_profile_override_revisions for select
to authenticated
using (public.is_staff());

drop policy if exists "Staff read book edition revisions"
  on public.book_edition_revisions;
create policy "Staff read book edition revisions"
on public.book_edition_revisions for select
to authenticated
using (public.is_staff());

-- Public policies must never invoke the staff-only helper. It is deliberately
-- not executable by anon; authenticated staff receive the wider view through
-- the separate permissive staff policies already defined for every table.
drop policy if exists "Public read visible categories" on public.categories;
create policy "Public read visible categories"
on public.categories for select to anon, authenticated using (is_visible);

drop policy if exists "Public read active media metadata" on public.media_assets;
create policy "Public read active media metadata"
on public.media_assets for select to anon, authenticated using (deleted_at is null);

drop policy if exists "Public read published articles" on public.articles;
create policy "Public read published articles"
on public.articles for select to anon, authenticated
using (status = 'published' and published_at <= now() and deleted_at is null);

drop policy if exists "Public read published article tags" on public.article_tags;
create policy "Public read published article tags"
on public.article_tags for select to anon, authenticated
using (
  exists (
    select 1 from public.articles
    where id = article_id
      and status = 'published'
      and published_at <= now()
      and deleted_at is null
  )
);

drop policy if exists "Public read published pages" on public.pages;
create policy "Public read published pages"
on public.pages for select to anon, authenticated
using (status = 'published' and deleted_at is null);

drop policy if exists "Public read enabled homepage blocks" on public.homepage_blocks;
create policy "Public read enabled homepage blocks"
on public.homepage_blocks for select to anon, authenticated using (is_enabled);

drop policy if exists "Public read active banners" on public.banners;
create policy "Public read active banners"
on public.banners for select to anon, authenticated
using (
  is_active
  and (starts_at is null or starts_at <= now())
  and (ends_at is null or ends_at > now())
);

drop policy if exists "Public read visible navigation items" on public.navigation_items;
create policy "Public read visible navigation items"
on public.navigation_items for select to anon, authenticated using (is_visible);

drop policy if exists "Public read active redirects" on public.redirects;
create policy "Public read active redirects"
on public.redirects for select to anon, authenticated using (is_active);

drop policy if exists "Public read released article translations"
  on public.article_translations;
create policy "Public read released article translations"
on public.article_translations for select to anon, authenticated
using (
  status in ('approved', 'published')
  and deleted_at is null
  and exists (
    select 1
    from public.articles article
    where article.id = article_id
      and article.status = 'published'
      and article.published_at <= now()
      and article.deleted_at is null
  )
);

drop policy if exists "Public read publishable literary works" on public.literary_works;
create policy "Public read publishable literary works"
on public.literary_works for select to anon, authenticated
using (public.is_publishable_literary_work(id));

drop policy if exists "Public read publishable work translations"
  on public.literary_work_translations;
create policy "Public read publishable work translations"
on public.literary_work_translations for select to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Public read publishable work sources"
  on public.literary_work_sources;
create policy "Public read publishable work sources"
on public.literary_work_sources for select to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Public read publishable work external ids"
  on public.literary_work_external_ids;
create policy "Public read publishable work external ids"
on public.literary_work_external_ids for select to anon, authenticated
using (public.is_publishable_literary_work(work_id));

drop policy if exists "Public read verified book editions" on public.book_editions;
create policy "Public read verified book editions"
on public.book_editions for select to anon, authenticated
using (
  (
    cover_url is null
    or (
      cover_rights_status <> 'unverified'
      and cover_source_url is not null
      and rights_checked_at is not null
    )
  )
  and exists (
    select 1
    from public.literary_works
    where literary_works.id = book_editions.work_id
      and literary_works.editorial_status in ('reviewed', 'verified')
  )
);

-- END WHOLE ORIGINAL supabase/migrations/20260813_editorial_database_admin.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260813_homepage_atomic_move.sql SHA256 7bdd781bfec7c3f1f55aac8b5b7e670ab0b97ae574b47e9b671ab041d2e87484
-- Reorder custom homepage blocks in one database transaction. The row locks
-- serialize simultaneous admin clicks and prevent the three-step swap from
-- leaving duplicate or temporary display_order values after a partial error.
create or replace function public.move_homepage_block(
  p_block_id uuid,
  p_direction text
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  current_block public.homepage_blocks%rowtype;
  target_block public.homepage_blocks%rowtype;
  temporary_order integer;
begin
  if not public.is_staff() then
    raise exception 'staff access required';
  end if;
  if p_direction not in ('up', 'down') then
    raise exception 'invalid homepage block direction';
  end if;

  -- Lock every movable row in the same deterministic order before choosing
  -- neighbours, so concurrent reorder transactions cannot interleave.
  perform id
  from public.homepage_blocks
  where not (settings ? 'systemKey')
    and not (settings ? 'coreSectionKey')
  order by display_order, id
  for update;

  select * into current_block
  from public.homepage_blocks
  where id = p_block_id
    and not (settings ? 'systemKey')
    and not (settings ? 'coreSectionKey');
  if not found then
    return false;
  end if;

  if p_direction = 'up' then
    select * into target_block
    from public.homepage_blocks
    where not (settings ? 'systemKey')
      and not (settings ? 'coreSectionKey')
      and (display_order, id) < (current_block.display_order, current_block.id)
    order by display_order desc, id desc
    limit 1;
  else
    select * into target_block
    from public.homepage_blocks
    where not (settings ? 'systemKey')
      and not (settings ? 'coreSectionKey')
      and (display_order, id) > (current_block.display_order, current_block.id)
    order by display_order, id
    limit 1;
  end if;
  if not found then
    return false;
  end if;

  select least(current_block.display_order, target_block.display_order, 0) - 1
  into temporary_order;

  update public.homepage_blocks
  set display_order = temporary_order,
      updated_by = (select auth.uid())
  where id = current_block.id;

  update public.homepage_blocks
  set display_order = current_block.display_order,
      updated_by = (select auth.uid())
  where id = target_block.id;

  update public.homepage_blocks
  set display_order = target_block.display_order,
      updated_by = (select auth.uid())
  where id = current_block.id;

  return true;
end;
$$;

revoke all on function public.move_homepage_block(uuid, text) from public;
grant execute on function public.move_homepage_block(uuid, text) to authenticated;

-- END WHOLE ORIGINAL supabase/migrations/20260813_homepage_atomic_move.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260813_tags_updated_at.sql SHA256 b9517ee519ae181955074346c71839029eca46b52e1f44eaa3d2a6fd816e7cc6
-- Optimistic locking for taxonomy tags. Existing rows receive a deterministic
-- version based on their creation time before the column becomes NOT NULL.
alter table public.tags
  add column if not exists updated_at timestamptz;

update public.tags
set updated_at = coalesce(updated_at, created_at, now())
where updated_at is null;

alter table public.tags
  alter column updated_at set default now(),
  alter column updated_at set not null;

drop trigger if exists tags_set_updated_at on public.tags;
create trigger tags_set_updated_at
  before update on public.tags
  for each row execute function public.set_updated_at();

create index if not exists tags_catalog_name_idx
  on public.tags(name asc, id asc);

-- END WHOLE ORIGINAL supabase/migrations/20260813_tags_updated_at.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260813_unified_revision_history.sql SHA256 94c2f7bb9a85e664ceea73f70679557cb862e7afc362539f35c0aa5c99850e8a
-- Единый read-only каталог версий нужен админке для честного server-side
-- поиска и глобальной пагинации по всем типам контента.

create or replace view public.admin_revision_history
with (security_invoker = true)
as
select
  'article'::text as kind,
  revision.id as revision_id,
  revision.article_id::text as entity_id,
  revision.snapshot,
  revision.changed_by as actor_id,
  revision.created_at,
  revision.revision_number,
  entity.id is not null as restorable,
  concat_ws(' ', revision.article_id::text, revision.snapshot ->> 'title', revision.snapshot ->> 'name', revision.snapshot ->> 'legacy_id') as search_text,
  entity.updated_at as entity_updated_at
from public.article_revisions revision
left join public.articles entity on entity.id = revision.article_id
union all
select 'page', revision.id, revision.page_id::text, revision.snapshot,
  revision.changed_by, revision.created_at, revision.revision_number,
  entity.id is not null,
  concat_ws(' ', revision.page_id::text, revision.snapshot ->> 'title', revision.snapshot ->> 'name', revision.snapshot ->> 'legacy_id'),
  entity.updated_at
from public.page_revisions revision
left join public.pages entity on entity.id = revision.page_id
union all
select 'homepage', revision.id,
  coalesce(revision.homepage_block_id::text, revision.snapshot ->> 'id'),
  revision.snapshot, revision.changed_by, revision.created_at,
  revision.revision_number,
  entity.id is not null,
  concat_ws(' ', revision.homepage_block_id::text, revision.snapshot ->> 'title', revision.snapshot ->> 'name', revision.snapshot ->> 'systemKey'),
  entity.updated_at
from public.homepage_block_revisions revision
left join public.homepage_blocks entity on entity.id = revision.homepage_block_id
union all
select 'country', revision.id,
  coalesce(revision.override_id::text, revision.snapshot ->> 'id', revision.country_id),
  revision.snapshot, revision.revised_by, revision.revised_at, null::integer,
  entity.id is not null,
  concat_ws(' ', revision.override_id::text, revision.country_id, revision.snapshot ->> 'name', revision.snapshot ->> 'title'),
  entity.updated_at
from public.country_profile_override_revisions revision
left join public.country_profile_overrides entity on entity.id = revision.override_id
union all
select 'writer', revision.id,
  coalesce(revision.override_id::text, revision.snapshot ->> 'id', revision.country_id || ':' || revision.writer_id),
  revision.snapshot, revision.revised_by, revision.revised_at, null::integer,
  entity.id is not null,
  concat_ws(' ', revision.override_id::text, revision.country_id, revision.writer_id, revision.snapshot ->> 'name', revision.snapshot ->> 'title'),
  entity.updated_at
from public.writer_profile_override_revisions revision
left join public.writer_profile_overrides entity on entity.id = revision.override_id
union all
select 'work', revision.id,
  coalesce(revision.work_id::text, revision.snapshot ->> 'id', revision.legacy_id),
  revision.snapshot, revision.revised_by, revision.revised_at, null::integer,
  entity.id is not null,
  concat_ws(' ', revision.work_id::text, revision.legacy_id, revision.snapshot ->> 'title', revision.snapshot ->> 'original_title'),
  entity.updated_at
from public.literary_work_revisions revision
left join public.literary_works entity on entity.id = revision.work_id
union all
select 'edition', revision.id,
  coalesce(revision.edition_id::text, revision.snapshot ->> 'id', revision.legacy_id),
  revision.snapshot, revision.revised_by, revision.revised_at, null::integer,
  entity.id is not null,
  concat_ws(' ', revision.edition_id::text, revision.legacy_id, revision.snapshot ->> 'title', revision.snapshot ->> 'isbn_10', revision.snapshot ->> 'isbn_13'),
  entity.updated_at
from public.book_edition_revisions revision
left join public.book_editions entity on entity.id = revision.edition_id
union all
select
  case revision.entity_type when 'banner' then 'banner' else 'navigation' end,
  revision.id, revision.entity_id::text, revision.snapshot, revision.revised_by,
  revision.revised_at, null::integer,
  case revision.entity_type
    when 'banner' then banner.id is not null
    else navigation.id is not null
  end,
  concat_ws(' ', revision.entity_id::text, revision.snapshot ->> 'title', revision.snapshot ->> 'name', revision.snapshot ->> 'label'),
  coalesce(banner.updated_at, navigation.updated_at)
from public.site_chrome_revisions revision
left join public.banners banner
  on revision.entity_type = 'banner' and banner.id = revision.entity_id
left join public.navigation_items navigation
  on revision.entity_type = 'navigation_item' and navigation.id = revision.entity_id
where revision.entity_type in ('banner', 'navigation_item');

revoke all on public.admin_revision_history from public, anon;
grant select on public.admin_revision_history to authenticated;

-- END WHOLE ORIGINAL supabase/migrations/20260813_unified_revision_history.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260814_publication_outbox_and_schema_health.sql SHA256 7c2a143fe3f6d011c5d196d79c6a611c3b3d18b4ce823df277b6b49677c543c0
-- Transactional public-build outbox and a staff-only production schema probe.
--
-- Editorial writes and their publication request must either commit together or
-- fail together.  The trigger below therefore runs inside every content
-- mutation transaction.  The admin still attempts a fast GitHub dispatch, but
-- the five-minute scheduled workflow can always recover an accepted write.

-- Repository-owned ledger for the guarded production reconciliation workflow.
-- It is intentionally separate from Supabase CLI's internal migration table:
-- changing vendor-owned bookkeeping would make later CLI reconciliation
-- ambiguous.  A recorded checksum is immutable; the workflow refuses to run
-- an edited historical migration under the same version.
create table if not exists public.probpera_schema_migrations (
  version text primary key
    check (version ~ '^20[0-9]{6}_[a-z0-9_]+$'),
  migration_sha256 text not null
    check (migration_sha256 ~ '^[0-9a-f]{64}$'),
  repository_sha text not null
    check (repository_sha ~ '^[0-9a-f]{40}$'),
  applied_at timestamptz not null default now()
);

alter table public.probpera_schema_migrations enable row level security;
revoke all on table public.probpera_schema_migrations from anon, authenticated;
grant select on table public.probpera_schema_migrations to service_role;

create or replace function public.protect_probpera_schema_migration_ledger()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  raise exception 'probpera schema migration ledger is append-only';
end;
$$;

revoke all on function public.protect_probpera_schema_migration_ledger()
  from public;

drop trigger if exists probpera_schema_migrations_append_only
  on public.probpera_schema_migrations;
create trigger probpera_schema_migrations_append_only
  before update or delete on public.probpera_schema_migrations
  for each row
  execute function public.protect_probpera_schema_migration_ledger();

create table if not exists public.public_build_outbox (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  entity_type text not null check (char_length(entity_type) between 1 and 120),
  entity_id text not null check (char_length(entity_id) between 1 and 240),
  reason text not null default 'editorial-mutation'
    check (char_length(reason) between 1 and 240),
  status text not null default 'requested'
    check (status in ('requested', 'dispatched', 'deployed', 'failed')),
  metadata jsonb not null default '{}'::jsonb,
  attempt_count integer not null default 0 check (attempt_count >= 0),
  last_error text,
  provider text,
  requested_at timestamptz not null default now(),
  dispatched_at timestamptz,
  deployed_at timestamptz,
  deployment_run_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (jsonb_typeof(metadata) = 'object')
);

-- Each accepted request is immutable until it is finalized.  Do not collapse
-- pending rows by entity: a mutation can commit after a deploy has read its
-- high-water mark but before that deploy finalizes it.  Reusing the old row/id
-- in that window would acknowledge content that was never in the build.
drop index if exists public.public_build_outbox_pending_entity_idx;
create index public_build_outbox_pending_entity_idx
  on public.public_build_outbox(entity_type, entity_id, id)
  where status in ('requested', 'dispatched', 'failed');

create index if not exists public_build_outbox_pending_order_idx
  on public.public_build_outbox(id)
  where status in ('requested', 'dispatched', 'failed');

-- The compatibility consumer keeps checking the audit queue during rollout.
-- A partial index prevents that five-minute probe from scanning the full
-- editorial audit history once the transactional outbox is live.
create index if not exists admin_audit_public_build_queue_idx
  on public.admin_audit_log(id desc)
  where action in (
    'public_build.requested',
    'public_build.failed',
    'public_build.deployed'
  );

drop trigger if exists public_build_outbox_set_updated_at
  on public.public_build_outbox;
create trigger public_build_outbox_set_updated_at
  before update on public.public_build_outbox
  for each row execute function public.set_updated_at();

create or replace function public.append_public_build_outbox(
  p_actor_id uuid,
  p_entity_type text,
  p_entity_id text,
  p_reason text,
  p_metadata jsonb default '{}'::jsonb
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  outbox_id bigint;
begin
  if nullif(trim(p_entity_type), '') is null
    or nullif(trim(p_entity_id), '') is null then
    raise exception 'public build entity identity is required';
  end if;

  insert into public.public_build_outbox (
    actor_id,
    entity_type,
    entity_id,
    reason,
    metadata,
    status,
    requested_at
  ) values (
    p_actor_id,
    left(trim(p_entity_type), 120),
    left(trim(p_entity_id), 240),
    left(coalesce(nullif(trim(p_reason), ''), 'editorial-mutation'), 240),
    coalesce(p_metadata, '{}'::jsonb),
    'requested',
    now()
  )
  returning id into outbox_id;

  return outbox_id;
end;
$$;

revoke all on function public.append_public_build_outbox(
  uuid, text, text, text, jsonb
) from public;

create or replace function public.enqueue_public_build_request(
  p_entity_type text,
  p_entity_id text,
  p_reason text,
  p_metadata jsonb default '{}'::jsonb
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_staff() then
    raise exception 'staff access required';
  end if;

  -- This explicit event intentionally coexists with row-trigger events.  The
  -- RPC also covers manual republish operations and gives the fast dispatch a
  -- concrete event to annotate.  At-least-once duplicates are harmless;
  -- mutating/reusing an older pending row is not.
  return public.append_public_build_outbox(
    (select auth.uid()),
    p_entity_type,
    p_entity_id,
    p_reason,
    p_metadata
  );
end;
$$;

revoke all on function public.enqueue_public_build_request(
  text, text, text, jsonb
) from public;
grant execute on function public.enqueue_public_build_request(
  text, text, text, jsonb
) to authenticated;

create or replace function public.mark_public_build_dispatched(
  p_outbox_id bigint,
  p_provider text
)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_staff() then
    raise exception 'staff access required';
  end if;

  update public.public_build_outbox
  set status = 'dispatched',
      provider = left(nullif(trim(p_provider), ''), 80),
      dispatched_at = now(),
      attempt_count = attempt_count + 1,
      last_error = null
  where id = p_outbox_id
    and status in ('requested', 'dispatched', 'failed');

  return found;
end;
$$;

revoke all on function public.mark_public_build_dispatched(bigint, text)
  from public;
grant execute on function public.mark_public_build_dispatched(bigint, text)
  to authenticated;

create or replace function public.capture_public_build_outbox()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  row_data jsonb;
  mutation_id text;
begin
  if tg_op = 'UPDATE' and old is not distinct from new then
    return new;
  end if;

  row_data := case when tg_op = 'DELETE' then to_jsonb(old) else to_jsonb(new) end;
  mutation_id := coalesce(
    row_data ->> 'id',
    row_data ->> 'article_id',
    row_data ->> 'work_id',
    row_data ->> 'homepage_block_id',
    row_data ->> 'country_id',
    row_data ->> 'writer_id',
    tg_table_name
  );

  perform public.append_public_build_outbox(
    (select auth.uid()),
    tg_table_name,
    mutation_id,
    'database-' || lower(tg_op),
    jsonb_build_object('operation', lower(tg_op), 'table', tg_table_name)
  );

  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;

revoke all on function public.capture_public_build_outbox() from public;

do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'articles',
    'article_tags',
    'article_translations',
    'pages',
    'homepage_blocks',
    'banners',
    'navigation_menus',
    'navigation_items',
    'redirects',
    'categories',
    'tags',
    'media_assets',
    'media_usages',
    'literary_works',
    'literary_work_translations',
    'literary_work_sources',
    'literary_work_external_ids',
    'book_editions',
    'writer_profile_overrides',
    'country_profile_overrides'
  ]
  loop
    execute format(
      'drop trigger if exists %I_public_build_outbox on public.%I',
      table_name,
      table_name
    );
    execute format(
      'create trigger %I_public_build_outbox after insert or update or delete on public.%I for each row execute function public.capture_public_build_outbox()',
      table_name,
      table_name
    );
  end loop;
end;
$$;

alter table public.public_build_outbox enable row level security;

revoke all on table public.public_build_outbox from anon, authenticated;
grant select on table public.public_build_outbox to authenticated;
grant select, update on table public.public_build_outbox to service_role;

drop policy if exists "Staff read public build outbox"
  on public.public_build_outbox;
create policy "Staff read public build outbox"
on public.public_build_outbox for select
to authenticated
using (public.is_staff());

-- This probe is deliberately staff-only.  The migration depends on every
-- listed table/function, so a successful response proves that the production
-- schema has reached the current editorial contract.
create or replace function public.get_editorial_schema_health()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when public.is_staff() then jsonb_build_object(
      'version', '20260814_publication_outbox_and_schema_health',
      'checkedAt', now(),
      'outbox', to_regclass('public.public_build_outbox') is not null,
      'outboxRpc',
        to_regprocedure(
          'public.enqueue_public_build_request(text,text,text,jsonb)'
        ) is not null,
      'migrationLedger',
        to_regclass('public.probpera_schema_migrations') is not null,
      'publicationTriggers', (
        select count(*) = 20
        from pg_catalog.pg_trigger outbox_trigger
        join pg_catalog.pg_class relation
          on relation.oid = outbox_trigger.tgrelid
        join pg_catalog.pg_namespace namespace
          on namespace.oid = relation.relnamespace
        where namespace.nspname = 'public'
          and not outbox_trigger.tgisinternal
          and outbox_trigger.tgfoid =
            'public.capture_public_build_outbox()'::regprocedure
          and outbox_trigger.tgname =
            (relation.relname::text || '_public_build_outbox')::name
          and relation.relname = any(array[
            'articles',
            'article_tags',
            'article_translations',
            'pages',
            'homepage_blocks',
            'banners',
            'navigation_menus',
            'navigation_items',
            'redirects',
            'categories',
            'tags',
            'media_assets',
            'media_usages',
            'literary_works',
            'literary_work_translations',
            'literary_work_sources',
            'literary_work_external_ids',
            'book_editions',
            'writer_profile_overrides',
            'country_profile_overrides'
          ]::name[])
      ),
      'pendingPublicBuilds', (
        select count(*)
        from public.public_build_outbox
        where status in ('requested', 'dispatched', 'failed')
      ),
      'revisionHistory', to_regclass('public.admin_revision_history') is not null,
      'workTranslations', to_regclass('public.literary_work_translations') is not null,
      'countryOverrides', to_regclass('public.country_profile_overrides') is not null,
      'writerOverrides', to_regclass('public.writer_profile_overrides') is not null,
      'homepageMove', to_regprocedure('public.move_homepage_block(uuid,text)') is not null,
      'tagsUpdatedAt', exists (
        select 1
        from information_schema.columns
        where table_schema = 'public'
          and table_name = 'tags'
          and column_name = 'updated_at'
      )
    )
    else null
  end;
$$;

revoke all on function public.get_editorial_schema_health() from public;
grant execute on function public.get_editorial_schema_health() to authenticated;

-- END WHOLE ORIGINAL supabase/migrations/20260814_publication_outbox_and_schema_health.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260820_literary_work_cover_artworks.sql SHA256 9c07f74693406071b99e1bc5f0e80c323a85cc6ce72b1bdf3434643b7b16ba90
-- Work-level editorial artwork is intentionally separate from book_editions.
-- User-supplied illustrations do not identify a publisher, printing or ISBN.

create table if not exists public.literary_work_cover_artworks (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.literary_works(id) on delete cascade,
  cover_url text not null check (
    cover_url ~ '^brand/book-covers/[a-z0-9][a-z0-9-]*\.webp$'
    or cover_url ~ '^https://'
  ),
  thumbnail_url text not null check (
    thumbnail_url ~ '^brand/book-covers/thumbs/[a-z0-9][a-z0-9-]*\.webp$'
    or thumbnail_url ~ '^https://'
  ),
  cover_width integer not null check (cover_width between 1 and 4000),
  cover_height integer not null check (cover_height between 1 and 6000),
  thumbnail_width integer not null check (thumbnail_width between 1 and 2000),
  thumbnail_height integer not null check (thumbnail_height between 1 and 3000),
  rights_status text not null default 'editorial-original'
    check (rights_status = 'editorial-original'),
  cover_source_url text not null check (cover_source_url ~ '^https://'),
  rights_checked_at date not null,
  source_archive_sha256 text not null check (source_archive_sha256 ~ '^[a-f0-9]{64}$'),
  source_image_sha256 text not null check (source_image_sha256 ~ '^[a-f0-9]{64}$'),
  source_filename text not null check (char_length(source_filename) between 1 and 500),
  source_relative_path text not null check (char_length(source_relative_path) between 1 and 900),
  source_index integer not null check (source_index > 0),
  is_primary boolean not null default true,
  provenance jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, source_archive_sha256, source_image_sha256),
  unique (source_archive_sha256, source_index),
  check (
    provenance @> '{"kind":"user-supplied"}'::jsonb
    and provenance->>'archiveSha256' = source_archive_sha256
    and provenance->>'imageSha256' = source_image_sha256
  )
);

create unique index if not exists literary_work_cover_artworks_one_primary_idx
  on public.literary_work_cover_artworks(work_id)
  where is_primary;

create index if not exists literary_work_cover_artworks_work_idx
  on public.literary_work_cover_artworks(work_id, rights_checked_at desc);

create or replace function public.guard_literary_work_cover_artwork_provenance()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.work_id is distinct from old.work_id
    or new.cover_url is distinct from old.cover_url
    or new.thumbnail_url is distinct from old.thumbnail_url
    or new.cover_width is distinct from old.cover_width
    or new.cover_height is distinct from old.cover_height
    or new.thumbnail_width is distinct from old.thumbnail_width
    or new.thumbnail_height is distinct from old.thumbnail_height
    or new.rights_status is distinct from old.rights_status
    or new.cover_source_url is distinct from old.cover_source_url
    or new.rights_checked_at is distinct from old.rights_checked_at
    or new.source_archive_sha256 is distinct from old.source_archive_sha256
    or new.source_image_sha256 is distinct from old.source_image_sha256
    or new.source_filename is distinct from old.source_filename
    or new.source_relative_path is distinct from old.source_relative_path
    or new.source_index is distinct from old.source_index
    or new.provenance is distinct from old.provenance then
    raise exception
      'Literary work artwork provenance is immutable; create a new artwork row instead.';
  end if;
  return new;
end;
$$;

revoke all on function public.guard_literary_work_cover_artwork_provenance()
  from public;

drop trigger if exists literary_work_cover_artworks_guard_provenance
  on public.literary_work_cover_artworks;
create trigger literary_work_cover_artworks_guard_provenance
  before update on public.literary_work_cover_artworks
  for each row execute function public.guard_literary_work_cover_artwork_provenance();

drop trigger if exists literary_work_cover_artworks_set_updated_at
  on public.literary_work_cover_artworks;
create trigger literary_work_cover_artworks_set_updated_at
  before update on public.literary_work_cover_artworks
  for each row execute function public.set_updated_at();

do $$
begin
  if to_regprocedure('public.capture_public_build_outbox()') is not null then
    execute 'drop trigger if exists literary_work_cover_artworks_public_build_outbox '
      || 'on public.literary_work_cover_artworks';
    execute 'create trigger literary_work_cover_artworks_public_build_outbox '
      || 'after insert or update or delete on public.literary_work_cover_artworks '
      || 'for each row execute function public.capture_public_build_outbox()';
  end if;
end;
$$;

alter table public.literary_work_cover_artworks enable row level security;

revoke all on table public.literary_work_cover_artworks from anon, authenticated;
grant select on table public.literary_work_cover_artworks to anon, authenticated;
grant insert, update, delete on table public.literary_work_cover_artworks
  to authenticated;
grant all on table public.literary_work_cover_artworks to service_role;

drop policy if exists "Public read publishable literary work artwork"
  on public.literary_work_cover_artworks;
create policy "Public read publishable literary work artwork"
on public.literary_work_cover_artworks for select
to anon, authenticated
using (
  rights_status = 'editorial-original'
  and rights_checked_at is not null
  and public.is_publishable_literary_work(work_id)
);

drop policy if exists "Staff manage literary work artwork"
  on public.literary_work_cover_artworks;
create policy "Staff manage literary work artwork"
on public.literary_work_cover_artworks for all
to authenticated
using (public.is_staff())
with check (public.is_staff());

-- Keep the staff-only schema-health contract current after adding the 21st
-- publication-bearing editorial relation.
create or replace function public.get_editorial_schema_health()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when public.is_staff() then jsonb_build_object(
      'version', '20260820_literary_work_cover_artworks',
      'checkedAt', now(),
      'outbox', to_regclass('public.public_build_outbox') is not null,
      'outboxRpc',
        to_regprocedure(
          'public.enqueue_public_build_request(text,text,text,jsonb)'
        ) is not null,
      'migrationLedger',
        to_regclass('public.probpera_schema_migrations') is not null,
      'publicationTriggers', (
        select count(*) = 21
        from pg_catalog.pg_trigger outbox_trigger
        join pg_catalog.pg_class relation
          on relation.oid = outbox_trigger.tgrelid
        join pg_catalog.pg_namespace namespace
          on namespace.oid = relation.relnamespace
        where namespace.nspname = 'public'
          and not outbox_trigger.tgisinternal
          and outbox_trigger.tgfoid =
            'public.capture_public_build_outbox()'::regprocedure
          and outbox_trigger.tgname =
            (relation.relname::text || '_public_build_outbox')::name
          and relation.relname = any(array[
            'articles',
            'article_tags',
            'article_translations',
            'pages',
            'homepage_blocks',
            'banners',
            'navigation_menus',
            'navigation_items',
            'redirects',
            'categories',
            'tags',
            'media_assets',
            'media_usages',
            'literary_works',
            'literary_work_translations',
            'literary_work_sources',
            'literary_work_external_ids',
            'book_editions',
            'writer_profile_overrides',
            'country_profile_overrides',
            'literary_work_cover_artworks'
          ]::name[])
      ),
      'pendingPublicBuilds', (
        select count(*)
        from public.public_build_outbox
        where status in ('requested', 'dispatched', 'failed')
      ),
      'revisionHistory',
        to_regclass('public.admin_revision_history') is not null,
      'workTranslations',
        to_regclass('public.literary_work_translations') is not null,
      'workCoverArtworks',
        to_regclass('public.literary_work_cover_artworks') is not null,
      'countryOverrides',
        to_regclass('public.country_profile_overrides') is not null,
      'writerOverrides',
        to_regclass('public.writer_profile_overrides') is not null,
      'homepageMove',
        to_regprocedure('public.move_homepage_block(uuid,text)') is not null,
      'tagsUpdatedAt', exists (
        select 1
        from information_schema.columns
        where table_schema = 'public'
          and table_name = 'tags'
          and column_name = 'updated_at'
      )
    )
    else null
  end;
$$;

revoke all on function public.get_editorial_schema_health() from public;
grant execute on function public.get_editorial_schema_health()
  to authenticated;

comment on table public.literary_work_cover_artworks is
  'Work-level editorial illustrations with immutable source-archive provenance; never an edition or ISBN claim.';

-- END WHOLE ORIGINAL supabase/migrations/20260820_literary_work_cover_artworks.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260822_staff_editorial_read_rls.sql SHA256 e43a6f937e86b7a6fe00093b1b97ef29c878d78d39ce275229bbfba139bc92f5
-- Canonical staff read access for editorial rows hidden from public readers.
-- Public SELECT policies remain unchanged; authenticated staff receive a
-- separate permissive path for drafts, translations and hidden media metadata.

drop policy if exists "Staff read articles" on public.articles;
create policy "Staff read articles"
on public.articles for select
to authenticated
using (public.is_staff());

drop policy if exists "Staff read article translations"
  on public.article_translations;
create policy "Staff read article translations"
on public.article_translations for select
to authenticated
using (public.is_staff());

drop policy if exists "Staff read media metadata" on public.media_assets;
create policy "Staff read media metadata"
on public.media_assets for select
to authenticated
using (public.is_staff());

-- Keep the staff-only schema-health contract current after making the
-- editorial read policies part of the canonical migration ledger.
create or replace function public.get_editorial_schema_health()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when public.is_staff() then jsonb_build_object(
      'version', '20260822_staff_editorial_read_rls',
      'checkedAt', now(),
      'outbox', to_regclass('public.public_build_outbox') is not null,
      'outboxRpc',
        to_regprocedure(
          'public.enqueue_public_build_request(text,text,text,jsonb)'
        ) is not null,
      'migrationLedger',
        to_regclass('public.probpera_schema_migrations') is not null,
      'publicationTriggers', (
        select count(*) = 21
        from pg_catalog.pg_trigger outbox_trigger
        join pg_catalog.pg_class relation
          on relation.oid = outbox_trigger.tgrelid
        join pg_catalog.pg_namespace namespace
          on namespace.oid = relation.relnamespace
        where namespace.nspname = 'public'
          and not outbox_trigger.tgisinternal
          and outbox_trigger.tgfoid =
            'public.capture_public_build_outbox()'::regprocedure
          and outbox_trigger.tgname =
            (relation.relname::text || '_public_build_outbox')::name
          and relation.relname = any(array[
            'articles',
            'article_tags',
            'article_translations',
            'pages',
            'homepage_blocks',
            'banners',
            'navigation_menus',
            'navigation_items',
            'redirects',
            'categories',
            'tags',
            'media_assets',
            'media_usages',
            'literary_works',
            'literary_work_translations',
            'literary_work_sources',
            'literary_work_external_ids',
            'book_editions',
            'writer_profile_overrides',
            'country_profile_overrides',
            'literary_work_cover_artworks'
          ]::name[])
      ),
      'staffEditorialReadPolicies', (
        select count(*) = 3
        from pg_catalog.pg_policies
        where schemaname = 'public'
          and cmd = 'SELECT'
          and roles = array['authenticated'::name]
          and position('is_staff' in coalesce(qual, '')) > 0
          and (
            (
              tablename = 'articles'
              and policyname = 'Staff read articles'
            )
            or (
              tablename = 'article_translations'
              and policyname = 'Staff read article translations'
            )
            or (
              tablename = 'media_assets'
              and policyname = 'Staff read media metadata'
            )
          )
      ),
      'pendingPublicBuilds', (
        select count(*)
        from public.public_build_outbox
        where status in ('requested', 'dispatched', 'failed')
      ),
      'revisionHistory',
        to_regclass('public.admin_revision_history') is not null,
      'workTranslations',
        to_regclass('public.literary_work_translations') is not null,
      'workCoverArtworks',
        to_regclass('public.literary_work_cover_artworks') is not null,
      'countryOverrides',
        to_regclass('public.country_profile_overrides') is not null,
      'writerOverrides',
        to_regclass('public.writer_profile_overrides') is not null,
      'homepageMove',
        to_regprocedure('public.move_homepage_block(uuid,text)') is not null,
      'tagsUpdatedAt', exists (
        select 1
        from information_schema.columns
        where table_schema = 'public'
          and table_name = 'tags'
          and column_name = 'updated_at'
      )
    )
    else null
  end;
$$;

revoke all on function public.get_editorial_schema_health() from public;
grant execute on function public.get_editorial_schema_health()
  to authenticated;

-- END WHOLE ORIGINAL supabase/migrations/20260822_staff_editorial_read_rls.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260822_zz_atomic_article_bundle.sql SHA256 a8c6f6213fcf6de10ae87e8b74f46724f62e536cdcf37e0836ed7de107eed257
-- Save the canonical Russian article row and its optional English translation in
-- one PostgreSQL transaction. Existing revision and public-build outbox triggers
-- remain authoritative and therefore commit or roll back with this function.
--
-- The function is deliberately SECURITY INVOKER: authenticated staff keep the
-- existing RLS checks and no privileged service-role path is introduced.

create or replace function public.save_article_bundle(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz,
  p_article_payload jsonb,
  p_english_mode text default 'none',
  p_english_payload jsonb default null,
  p_expected_english_updated_at timestamptz default null,
  p_redirect_source_path text default null,
  p_redirect_destination_path text default null,
  p_replace_homepage boolean default false,
  p_audit_action text default null,
  p_audit_metadata jsonb default '{}'::jsonb,
  p_social_publish_requested boolean default false,
  p_social_metadata jsonb default '{}'::jsonb
)
returns table (
  article_id uuid,
  article_updated_at timestamptz,
  english_updated_at timestamptz,
  homepage_replaced integer
)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  actor_id uuid := (select auth.uid());
  current_article public.articles%rowtype;
  current_english public.article_translations%rowtype;
  saved_article public.articles%rowtype;
  saved_english public.article_translations%rowtype;
  has_article boolean := false;
  has_english boolean := false;
  article_keywords text[];
  english_keywords text[];
  replaced_count integer := 0;
  effective_audit_action text;
begin
  if actor_id is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;

  if p_article_payload is null
    or jsonb_typeof(p_article_payload) <> 'object' then
    raise exception using errcode = '22023', message = 'ARTICLE_PAYLOAD_REQUIRED';
  end if;

  if p_english_mode not in ('none', 'save', 'stale') then
    raise exception using errcode = '22023', message = 'INVALID_ENGLISH_MODE';
  end if;

  if p_english_mode = 'save'
    and (p_english_payload is null or jsonb_typeof(p_english_payload) <> 'object') then
    raise exception using errcode = '22023', message = 'ENGLISH_PAYLOAD_REQUIRED';
  end if;

  article_keywords := coalesce(
    array(
      select jsonb_array_elements_text(
        coalesce(p_article_payload -> 'seo_keywords', '[]'::jsonb)
      )
    ),
    '{}'::text[]
  );

  if p_english_mode = 'save' then
    english_keywords := coalesce(
      array(
        select jsonb_array_elements_text(
          coalesce(p_english_payload -> 'seo_keywords', '[]'::jsonb)
        )
      ),
      '{}'::text[]
    );
  end if;

  -- Lock and validate both rows before the article UPDATE. Updating an article
  -- can legitimately mark a released English translation stale through the
  -- existing sync trigger, which also changes its updated_at. Checking the
  -- English timestamp after that trigger would create a false conflict.
  if p_article_id is not null then
    select *
    into current_article
    from public.articles
    where id = p_article_id
    for update;
    has_article := found;

    if not has_article then
      raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
    end if;

    if p_expected_article_updated_at is null
      or current_article.updated_at is distinct from p_expected_article_updated_at then
      raise exception using errcode = 'P0001', message = 'ARTICLE_CONFLICT';
    end if;

    if p_english_mode in ('save', 'stale') then
      select english_translation.*
      into current_english
      from public.article_translations as english_translation
      where english_translation.article_id = p_article_id
        and english_translation.locale = 'en'
      for update;
      has_english := found;

      if has_english then
        if p_expected_english_updated_at is null
          or current_english.updated_at is distinct from p_expected_english_updated_at then
          raise exception using errcode = 'P0001', message = 'ENGLISH_CONFLICT';
        end if;
      elsif p_expected_english_updated_at is not null then
        raise exception using errcode = 'P0001', message = 'ENGLISH_CONFLICT';
      end if;
    end if;

    update public.articles
    set
      title = p_article_payload ->> 'title',
      subtitle = coalesce(p_article_payload ->> 'subtitle', ''),
      excerpt = coalesce(p_article_payload ->> 'excerpt', ''),
      slug = p_article_payload ->> 'slug',
      content_html = coalesce(p_article_payload ->> 'content_html', ''),
      content_json = coalesce(
        p_article_payload -> 'content_json',
        '{"type":"doc","content":[]}'::jsonb
      ),
      category_id = nullif(p_article_payload ->> 'category_id', '')::uuid,
      status = (p_article_payload ->> 'status')::public.article_status,
      scheduled_at = nullif(p_article_payload ->> 'scheduled_at', '')::timestamptz,
      published_at = nullif(p_article_payload ->> 'published_at', '')::timestamptz,
      cover_external_url = nullif(p_article_payload ->> 'cover_external_url', ''),
      cover_alt = coalesce(p_article_payload ->> 'cover_alt', ''),
      legacy_path = nullif(p_article_payload ->> 'legacy_path', ''),
      seo_title = nullif(p_article_payload ->> 'seo_title', ''),
      seo_description = nullif(p_article_payload ->> 'seo_description', ''),
      seo_keywords = article_keywords,
      canonical_url = nullif(p_article_payload ->> 'canonical_url', ''),
      og_title = nullif(p_article_payload ->> 'og_title', ''),
      og_description = nullif(p_article_payload ->> 'og_description', ''),
      allow_indexing = coalesce((p_article_payload ->> 'allow_indexing')::boolean, true),
      sources = coalesce(p_article_payload -> 'sources', '[]'::jsonb),
      bibliography = coalesce(p_article_payload -> 'bibliography', '[]'::jsonb),
      featured = coalesce((p_article_payload ->> 'featured')::boolean, false),
      show_on_homepage = coalesce(
        (p_article_payload ->> 'show_on_homepage')::boolean,
        false
      ),
      pinned = coalesce((p_article_payload ->> 'pinned')::boolean, false),
      updated_by = actor_id
    where id = p_article_id
    returning * into saved_article;
  else
    if p_expected_article_updated_at is not null then
      raise exception using errcode = 'P0001', message = 'ARTICLE_CONFLICT';
    end if;

    insert into public.articles (
      title,
      subtitle,
      excerpt,
      slug,
      content_html,
      content_json,
      category_id,
      status,
      scheduled_at,
      published_at,
      cover_external_url,
      cover_alt,
      legacy_path,
      seo_title,
      seo_description,
      seo_keywords,
      canonical_url,
      og_title,
      og_description,
      allow_indexing,
      sources,
      bibliography,
      featured,
      show_on_homepage,
      pinned,
      created_by,
      updated_by
    ) values (
      p_article_payload ->> 'title',
      coalesce(p_article_payload ->> 'subtitle', ''),
      coalesce(p_article_payload ->> 'excerpt', ''),
      p_article_payload ->> 'slug',
      coalesce(p_article_payload ->> 'content_html', ''),
      coalesce(
        p_article_payload -> 'content_json',
        '{"type":"doc","content":[]}'::jsonb
      ),
      nullif(p_article_payload ->> 'category_id', '')::uuid,
      (p_article_payload ->> 'status')::public.article_status,
      nullif(p_article_payload ->> 'scheduled_at', '')::timestamptz,
      nullif(p_article_payload ->> 'published_at', '')::timestamptz,
      nullif(p_article_payload ->> 'cover_external_url', ''),
      coalesce(p_article_payload ->> 'cover_alt', ''),
      nullif(p_article_payload ->> 'legacy_path', ''),
      nullif(p_article_payload ->> 'seo_title', ''),
      nullif(p_article_payload ->> 'seo_description', ''),
      article_keywords,
      nullif(p_article_payload ->> 'canonical_url', ''),
      nullif(p_article_payload ->> 'og_title', ''),
      nullif(p_article_payload ->> 'og_description', ''),
      coalesce((p_article_payload ->> 'allow_indexing')::boolean, true),
      coalesce(p_article_payload -> 'sources', '[]'::jsonb),
      coalesce(p_article_payload -> 'bibliography', '[]'::jsonb),
      coalesce((p_article_payload ->> 'featured')::boolean, false),
      coalesce((p_article_payload ->> 'show_on_homepage')::boolean, false),
      coalesce((p_article_payload ->> 'pinned')::boolean, false),
      actor_id,
      actor_id
    )
    returning * into saved_article;
  end if;

  if p_english_mode = 'save' then
    if has_english then
      update public.article_translations
      set
        title = p_english_payload ->> 'title',
        subtitle = coalesce(p_english_payload ->> 'subtitle', ''),
        excerpt = coalesce(p_english_payload ->> 'excerpt', ''),
        content_json = coalesce(
          p_english_payload -> 'content_json',
          '{"type":"doc","content":[]}'::jsonb
        ),
        content_html = coalesce(p_english_payload ->> 'content_html', ''),
        cover_alt = coalesce(p_english_payload ->> 'cover_alt', ''),
        slug = p_english_payload ->> 'slug',
        sources = coalesce(p_english_payload -> 'sources', '[]'::jsonb),
        bibliography = coalesce(
          p_english_payload -> 'bibliography',
          '[]'::jsonb
        ),
        seo_title = nullif(p_english_payload ->> 'seo_title', ''),
        seo_description = nullif(p_english_payload ->> 'seo_description', ''),
        seo_keywords = english_keywords,
        canonical_url = nullif(p_english_payload ->> 'canonical_url', ''),
        og_title = nullif(p_english_payload ->> 'og_title', ''),
        og_description = nullif(p_english_payload ->> 'og_description', ''),
        status = (p_english_payload ->> 'status')::public.article_translation_status,
        source_content_hash = nullif(
          p_english_payload ->> 'source_content_hash',
          ''
        ),
        source_article_updated_at = saved_article.updated_at,
        reviewed_by = case
          when nullif(p_english_payload ->> 'reviewed_at', '') is null
            then null
          else actor_id
        end,
        reviewed_at = nullif(p_english_payload ->> 'reviewed_at', '')::timestamptz,
        approved_by = case
          when nullif(p_english_payload ->> 'approved_at', '') is null
            then null
          else actor_id
        end,
        approved_at = nullif(p_english_payload ->> 'approved_at', '')::timestamptz,
        published_at = nullif(p_english_payload ->> 'published_at', '')::timestamptz,
        updated_by = actor_id,
        deleted_at = nullif(p_english_payload ->> 'deleted_at', '')::timestamptz
      where id = current_english.id
      returning * into saved_english;
    else
      insert into public.article_translations (
        article_id,
        locale,
        title,
        subtitle,
        excerpt,
        content_json,
        content_html,
        cover_alt,
        slug,
        sources,
        bibliography,
        seo_title,
        seo_description,
        seo_keywords,
        canonical_url,
        og_title,
        og_description,
        status,
        source_content_hash,
        source_article_updated_at,
        reviewed_by,
        reviewed_at,
        approved_by,
        approved_at,
        published_at,
        created_by,
        updated_by,
        deleted_at
      ) values (
        saved_article.id,
        'en',
        p_english_payload ->> 'title',
        coalesce(p_english_payload ->> 'subtitle', ''),
        coalesce(p_english_payload ->> 'excerpt', ''),
        coalesce(
          p_english_payload -> 'content_json',
          '{"type":"doc","content":[]}'::jsonb
        ),
        coalesce(p_english_payload ->> 'content_html', ''),
        coalesce(p_english_payload ->> 'cover_alt', ''),
        p_english_payload ->> 'slug',
        coalesce(p_english_payload -> 'sources', '[]'::jsonb),
        coalesce(p_english_payload -> 'bibliography', '[]'::jsonb),
        nullif(p_english_payload ->> 'seo_title', ''),
        nullif(p_english_payload ->> 'seo_description', ''),
        english_keywords,
        nullif(p_english_payload ->> 'canonical_url', ''),
        nullif(p_english_payload ->> 'og_title', ''),
        nullif(p_english_payload ->> 'og_description', ''),
        (p_english_payload ->> 'status')::public.article_translation_status,
        nullif(p_english_payload ->> 'source_content_hash', ''),
        saved_article.updated_at,
        case
          when nullif(p_english_payload ->> 'reviewed_at', '') is null
            then null
          else actor_id
        end,
        nullif(p_english_payload ->> 'reviewed_at', '')::timestamptz,
        case
          when nullif(p_english_payload ->> 'approved_at', '') is null
            then null
          else actor_id
        end,
        nullif(p_english_payload ->> 'approved_at', '')::timestamptz,
        nullif(p_english_payload ->> 'published_at', '')::timestamptz,
        actor_id,
        actor_id,
        nullif(p_english_payload ->> 'deleted_at', '')::timestamptz
      )
      returning * into saved_english;
    end if;
  elsif p_english_mode = 'stale' and has_english then
    update public.article_translations
    set
      status = 'stale',
      approved_by = null,
      approved_at = null,
      published_at = null,
      updated_by = actor_id
    where id = current_english.id
    returning * into saved_english;
  end if;

  if nullif(trim(coalesce(p_redirect_source_path, '')), '') is not null
    and nullif(trim(coalesce(p_redirect_destination_path, '')), '') is not null
    and p_redirect_source_path is distinct from p_redirect_destination_path then
    insert into public.redirects (
      source_path,
      destination_path,
      status_code,
      is_active,
      created_by
    ) values (
      p_redirect_source_path,
      p_redirect_destination_path,
      301,
      true,
      actor_id
    )
    on conflict (source_path) do update set
      destination_path = excluded.destination_path,
      status_code = 301,
      is_active = true,
      created_by = actor_id;
  end if;

  if p_replace_homepage
    and saved_article.status = 'published'
    and saved_article.show_on_homepage
    and saved_article.category_id is not null then
    update public.articles
    set
      show_on_homepage = false,
      updated_by = actor_id
    where category_id = saved_article.category_id
      and status = 'published'
      and show_on_homepage
      and id <> saved_article.id;
    get diagnostics replaced_count = row_count;
  end if;

  effective_audit_action := coalesce(
    nullif(trim(coalesce(p_audit_action, '')), ''),
    case when p_article_id is null then 'article.created' else 'article.updated' end
  );

  insert into public.admin_audit_log (
    actor_id,
    action,
    entity_type,
    entity_id,
    metadata
  ) values (
    actor_id,
    effective_audit_action,
    'article',
    saved_article.id::text,
    coalesce(p_audit_metadata, '{}'::jsonb)
  );

  if p_social_publish_requested then
    insert into public.admin_audit_log (
      actor_id,
      action,
      entity_type,
      entity_id,
      metadata
    ) values (
      actor_id,
      'social_publish.requested',
      'article',
      saved_article.id::text,
      coalesce(p_social_metadata, '{}'::jsonb)
    );
  end if;

  return query
  select
    saved_article.id,
    saved_article.updated_at,
    case
      when p_english_mode in ('save', 'stale') and saved_english.id is not null
        then saved_english.updated_at
      else null
    end,
    replaced_count;
end;
$$;

revoke all on function public.save_article_bundle(
  uuid,
  timestamptz,
  jsonb,
  text,
  jsonb,
  timestamptz,
  text,
  text,
  boolean,
  text,
  jsonb,
  boolean,
  jsonb
) from public;
grant execute on function public.save_article_bundle(
  uuid,
  timestamptz,
  jsonb,
  text,
  jsonb,
  timestamptz,
  text,
  text,
  boolean,
  text,
  jsonb,
  boolean,
  jsonb
) to authenticated;

-- Keep the staff-only schema health probe synchronized with this canonical RPC.
create or replace function public.get_editorial_schema_health()
returns jsonb
language sql
stable
security definer
set search_path = ''
as $$
  select case
    when public.is_staff() then jsonb_build_object(
      'version', '20260822_zz_atomic_article_bundle',
      'checkedAt', now(),
      'outbox', to_regclass('public.public_build_outbox') is not null,
      'outboxRpc',
        to_regprocedure(
          'public.enqueue_public_build_request(text,text,text,jsonb)'
        ) is not null,
      'articleBundleRpc',
        to_regprocedure(
          'public.save_article_bundle(uuid,timestamptz,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
        ) is not null,
      'migrationLedger',
        to_regclass('public.probpera_schema_migrations') is not null,
      'publicationTriggers', (
        select count(*) = 21
        from pg_catalog.pg_trigger outbox_trigger
        join pg_catalog.pg_class relation
          on relation.oid = outbox_trigger.tgrelid
        join pg_catalog.pg_namespace namespace
          on namespace.oid = relation.relnamespace
        where namespace.nspname = 'public'
          and not outbox_trigger.tgisinternal
          and outbox_trigger.tgfoid =
            'public.capture_public_build_outbox()'::regprocedure
          and outbox_trigger.tgname =
            (relation.relname::text || '_public_build_outbox')::name
          and relation.relname = any(array[
            'articles',
            'article_tags',
            'article_translations',
            'pages',
            'homepage_blocks',
            'banners',
            'navigation_menus',
            'navigation_items',
            'redirects',
            'categories',
            'tags',
            'media_assets',
            'media_usages',
            'literary_works',
            'literary_work_translations',
            'literary_work_sources',
            'literary_work_external_ids',
            'book_editions',
            'writer_profile_overrides',
            'country_profile_overrides',
            'literary_work_cover_artworks'
          ]::name[])
      ),
      'staffEditorialReadPolicies', (
        select count(*) = 3
        from pg_catalog.pg_policies
        where schemaname = 'public'
          and cmd = 'SELECT'
          and roles = array['authenticated'::name]
          and position('is_staff' in coalesce(qual, '')) > 0
          and (
            (tablename = 'articles' and policyname = 'Staff read articles')
            or (
              tablename = 'article_translations'
              and policyname = 'Staff read article translations'
            )
            or (
              tablename = 'media_assets'
              and policyname = 'Staff read media metadata'
            )
          )
      ),
      'pendingPublicBuilds', (
        select count(*)
        from public.public_build_outbox
        where status in ('requested', 'dispatched', 'failed')
      ),
      'revisionHistory',
        to_regclass('public.admin_revision_history') is not null,
      'workTranslations',
        to_regclass('public.literary_work_translations') is not null,
      'workCoverArtworks',
        to_regclass('public.literary_work_cover_artworks') is not null,
      'countryOverrides',
        to_regclass('public.country_profile_overrides') is not null,
      'writerOverrides',
        to_regclass('public.writer_profile_overrides') is not null,
      'homepageMove',
        to_regprocedure('public.move_homepage_block(uuid,text)') is not null,
      'tagsUpdatedAt', exists (
        select 1
        from information_schema.columns
        where table_schema = 'public'
          and table_name = 'tags'
          and column_name = 'updated_at'
      )
    )
    else null
  end;
$$;

revoke all on function public.get_editorial_schema_health() from public;
grant execute on function public.get_editorial_schema_health()
  to authenticated;

-- END WHOLE ORIGINAL supabase/migrations/20260822_zz_atomic_article_bundle.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260828_zz_editor_autosaves.sql SHA256 f7b80e69501450f3c67be54dd047a62c3a1794dcb256068f2b780b3dce41a895
-- Private, actor-owned recovery copies for the shared editorial workspace.
--
-- Autosaves are deliberately isolated from canonical editorial tables,
-- revision history and the public-build outbox. They can therefore preserve
-- interrupted work without publishing or silently overwriting newer content.

create table if not exists public.editor_autosaves (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid not null references auth.users(id) on delete cascade,
  entity_type text not null check (entity_type in ('article', 'page')),
  entity_id uuid,
  draft_scope text not null check (
    char_length(draft_scope) between 1 and 160
    and draft_scope = btrim(draft_scope)
  ),
  locale_scope text not null check (
    char_length(locale_scope) between 1 and 32
    and locale_scope ~ '^[a-z][a-z0-9_-]*$'
  ),
  base_updated_at timestamptz,
  client_session_id uuid not null,
  client_sequence bigint not null check (client_sequence > 0),
  snapshot_hash text not null check (snapshot_hash ~ '^[0-9a-f]{64}$'),
  snapshot jsonb not null check (jsonb_typeof(snapshot) = 'object'),
  recovery_state text not null check (recovery_state in ('saved', 'conflict')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '30 days'),
  unique (
    actor_id,
    entity_type,
    draft_scope,
    locale_scope,
    client_session_id
  ),
  check (expires_at > created_at),
  check (octet_length(snapshot::text) <= 3500000)
);

create index if not exists editor_autosaves_actor_recent_idx
  on public.editor_autosaves(
    actor_id,
    entity_type,
    draft_scope,
    locale_scope,
    updated_at desc
  );
create index if not exists editor_autosaves_expiry_idx
  on public.editor_autosaves(expires_at);

alter table public.editor_autosaves enable row level security;
alter table public.editor_autosaves force row level security;

revoke all on table public.editor_autosaves from public, anon;
grant select, insert, update, delete on table public.editor_autosaves
  to authenticated;
grant all on table public.editor_autosaves to service_role;

drop policy if exists "Staff read their own editor autosaves"
  on public.editor_autosaves;
create policy "Staff read their own editor autosaves"
on public.editor_autosaves for select
to authenticated
using (
  actor_id = (select auth.uid())
  and public.is_staff()
);

drop policy if exists "Staff create their own editor autosaves"
  on public.editor_autosaves;
create policy "Staff create their own editor autosaves"
on public.editor_autosaves for insert
to authenticated
with check (
  actor_id = (select auth.uid())
  and public.is_staff()
);

drop policy if exists "Staff update their own editor autosaves"
  on public.editor_autosaves;
create policy "Staff update their own editor autosaves"
on public.editor_autosaves for update
to authenticated
using (
  actor_id = (select auth.uid())
  and public.is_staff()
)
with check (
  actor_id = (select auth.uid())
  and public.is_staff()
);

drop policy if exists "Staff delete their own editor autosaves"
  on public.editor_autosaves;
create policy "Staff delete their own editor autosaves"
on public.editor_autosaves for delete
to authenticated
using (
  actor_id = (select auth.uid())
  and public.is_staff()
);

create or replace function public.save_editor_autosave(
  p_entity_type text,
  p_entity_id uuid,
  p_draft_scope text,
  p_locale_scope text,
  p_base_updated_at timestamptz,
  p_client_session_id uuid,
  p_client_sequence bigint,
  p_snapshot_hash text,
  p_snapshot jsonb,
  p_expires_at timestamptz
)
returns jsonb
language plpgsql
security invoker
set search_path = ''
as $$
declare
  current_actor uuid := (select auth.uid());
  canonical_updated_at timestamptz;
  next_state text := 'saved';
  saved_row public.editor_autosaves%rowtype;
begin
  if current_actor is null or not public.is_staff() then
    raise exception 'A staff session is required';
  end if;
  if p_entity_type not in ('article', 'page')
    or p_draft_scope is null
    or char_length(p_draft_scope) not between 1 and 160
    or p_draft_scope <> btrim(p_draft_scope)
    or p_locale_scope is null
    or p_locale_scope !~ '^[a-z][a-z0-9_-]{0,31}$'
    or p_client_session_id is null
    or p_client_sequence is null
    or p_client_sequence <= 0
    or p_snapshot_hash is null
    or p_snapshot_hash !~ '^[0-9a-f]{64}$'
    or p_snapshot is null
    or jsonb_typeof(p_snapshot) <> 'object'
    or octet_length(p_snapshot::text) > 3500000
    or p_expires_at is null
    or p_expires_at <= now()
    or p_expires_at > now() + interval '45 days' then
    raise exception 'Invalid editor autosave payload';
  end if;

  if p_entity_id is not null then
    if p_entity_type = 'article' then
      select article.updated_at
      into canonical_updated_at
      from public.articles as article
      where article.id = p_entity_id;
    else
      select page_record.updated_at
      into canonical_updated_at
      from public.pages as page_record
      where page_record.id = p_entity_id;
    end if;

    if canonical_updated_at is null
      or p_base_updated_at is null
      or canonical_updated_at is distinct from p_base_updated_at then
      next_state := 'conflict';
    end if;
  elsif p_base_updated_at is not null then
    next_state := 'conflict';
  end if;

  insert into public.editor_autosaves as current_autosave (
    actor_id,
    entity_type,
    entity_id,
    draft_scope,
    locale_scope,
    base_updated_at,
    client_session_id,
    client_sequence,
    snapshot_hash,
    snapshot,
    recovery_state,
    expires_at
  )
  values (
    current_actor,
    p_entity_type,
    p_entity_id,
    p_draft_scope,
    p_locale_scope,
    p_base_updated_at,
    p_client_session_id,
    p_client_sequence,
    p_snapshot_hash,
    p_snapshot,
    next_state,
    p_expires_at
  )
  on conflict (
    actor_id,
    entity_type,
    draft_scope,
    locale_scope,
    client_session_id
  ) do update
  set
    entity_id = excluded.entity_id,
    base_updated_at = excluded.base_updated_at,
    client_sequence = excluded.client_sequence,
    snapshot_hash = excluded.snapshot_hash,
    snapshot = excluded.snapshot,
    recovery_state = excluded.recovery_state,
    updated_at = now(),
    expires_at = excluded.expires_at
  where current_autosave.client_sequence < excluded.client_sequence
  returning * into saved_row;

  if saved_row.id is null then
    select autosave.*
    into saved_row
    from public.editor_autosaves as autosave
    where autosave.actor_id = current_actor
      and autosave.entity_type = p_entity_type
      and autosave.draft_scope = p_draft_scope
      and autosave.locale_scope = p_locale_scope
      and autosave.client_session_id = p_client_session_id;
  end if;

  return jsonb_build_object(
    'id', saved_row.id,
    'state', saved_row.recovery_state,
    'sequence', saved_row.client_sequence,
    'snapshotHash', saved_row.snapshot_hash,
    'baseUpdatedAt', saved_row.base_updated_at,
    'updatedAt', saved_row.updated_at,
    'expiresAt', saved_row.expires_at
  );
end;
$$;

revoke all on function public.save_editor_autosave(
  text,
  uuid,
  text,
  text,
  timestamptz,
  uuid,
  bigint,
  text,
  jsonb,
  timestamptz
) from public, anon;
grant execute on function public.save_editor_autosave(
  text,
  uuid,
  text,
  text,
  timestamptz,
  uuid,
  bigint,
  text,
  jsonb,
  timestamptz
) to authenticated, service_role;

-- END WHOLE ORIGINAL supabase/migrations/20260828_zz_editor_autosaves.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260901_zz_staff_owner_invariant.sql SHA256 b991a3842e66c3002112f4160aa9f37e07c7f70e5266215bd91ea0a45489e8d1
-- Phase 8: make the last-owner invariant a database boundary.
-- Staff membership writes are possible only through the two owner RPCs below.

alter table public.staff_memberships enable row level security;
alter table public.staff_memberships force row level security;

drop policy if exists "Owners manage staff" on public.staff_memberships;
drop policy if exists "Staff read their membership" on public.staff_memberships;
create policy "Staff read their membership"
on public.staff_memberships for select
to authenticated
using (
  user_id = (select auth.uid())
  or public.is_staff(array['owner'::public.staff_role])
);

revoke all on table public.staff_memberships from public, anon, authenticated;
grant select on table public.staff_memberships to authenticated;

create or replace function public.owner_set_staff_member(
  p_email text,
  p_role public.staff_role
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  target_user_id uuid;
  current_role public.staff_role;
  owner_count integer;
begin
  -- Serialize every owner-changing operation, including changes to different rows.
  perform pg_advisory_xact_lock(188654771, 1);

  if actor_user_id is null
    or not public.is_staff(array['owner'::public.staff_role]) then
    raise exception using errcode = 'P0001', message = 'STAFF_OWNER_REQUIRED';
  end if;

  select id into target_user_id
  from auth.users
  where lower(email) = lower(btrim(p_email))
  limit 1;

  if target_user_id is null then
    raise exception using errcode = 'P0001', message = 'STAFF_USER_NOT_REGISTERED';
  end if;

  select role into current_role
  from public.staff_memberships
  where user_id = target_user_id
  for update;

  if current_role = 'owner'::public.staff_role
    and p_role <> 'owner'::public.staff_role then
    select count(*) into owner_count
    from public.staff_memberships
    where role = 'owner'::public.staff_role;
    if owner_count <= 1 then
      raise exception using errcode = 'P0001', message = 'STAFF_LAST_OWNER';
    end if;
  end if;

  insert into public.staff_memberships (user_id, role, created_by)
  values (target_user_id, p_role, actor_user_id)
  on conflict (user_id) do update
  set role = excluded.role,
      updated_at = now();

  insert into public.admin_audit_log (
    actor_id,
    action,
    entity_type,
    entity_id,
    metadata
  ) values (
    actor_user_id,
    'staff.updated',
    'staff',
    target_user_id::text,
    jsonb_build_object(
      'email', lower(btrim(p_email)),
      'previous_role', current_role,
      'role', p_role
    )
  );

  return target_user_id;
end;
$$;

create or replace function public.owner_remove_staff_member(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  target_role public.staff_role;
  owner_count integer;
begin
  perform pg_advisory_xact_lock(188654771, 1);

  if actor_user_id is null
    or not public.is_staff(array['owner'::public.staff_role]) then
    raise exception using errcode = 'P0001', message = 'STAFF_OWNER_REQUIRED';
  end if;
  if p_user_id = actor_user_id then
    raise exception using errcode = 'P0001', message = 'STAFF_SELF_REMOVE_FORBIDDEN';
  end if;

  select role into target_role
  from public.staff_memberships
  where user_id = p_user_id
  for update;

  if target_role is null then
    raise exception using errcode = 'P0001', message = 'STAFF_MEMBER_NOT_FOUND';
  end if;

  if target_role = 'owner'::public.staff_role then
    select count(*) into owner_count
    from public.staff_memberships
    where role = 'owner'::public.staff_role;
    if owner_count <= 1 then
      raise exception using errcode = 'P0001', message = 'STAFF_LAST_OWNER';
    end if;
  end if;

  delete from public.staff_memberships where user_id = p_user_id;

  insert into public.admin_audit_log (
    actor_id,
    action,
    entity_type,
    entity_id,
    metadata
  ) values (
    actor_user_id,
    'staff.removed',
    'staff',
    p_user_id::text,
    jsonb_build_object('previous_role', target_role)
  );
end;
$$;

revoke all on function public.owner_set_staff_member(text, public.staff_role)
  from public, anon, authenticated;
revoke all on function public.owner_remove_staff_member(uuid)
  from public, anon, authenticated;
grant execute on function public.owner_set_staff_member(text, public.staff_role)
  to authenticated;
grant execute on function public.owner_remove_staff_member(uuid)
  to authenticated;

-- END WHOLE ORIGINAL supabase/migrations/20260901_zz_staff_owner_invariant.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260901_zzz_admin_mutation_guards.sql SHA256 47ba449f1980a7c2e87e28355bf9bf8c2cd9a772b10886dbc5d1e3339445c9f2
-- Phase 8: atomic, fail-closed mutation boundaries for Site Copy, redirects,
-- and comment moderation. Existing public read contracts remain unchanged.

create or replace function public.save_site_copy_block(
  p_expected_updated_at timestamptz,
  p_payload jsonb,
  p_audit_metadata jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  block_id uuid;
  current_updated_at timestamptz;
begin
  perform pg_advisory_xact_lock(188654771, 2);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  if jsonb_typeof(p_payload) <> 'object'
    or p_payload #>> '{settings,systemKey}' <> 'site-copy-overrides'
    or p_payload ->> 'block_type' <> 'text' then
    raise exception using errcode = 'P0001', message = 'SITE_COPY_INVALID_PAYLOAD';
  end if;

  select id, updated_at into block_id, current_updated_at
  from public.homepage_blocks
  where settings @> '{"systemKey":"site-copy-overrides"}'::jsonb
  order by updated_at desc
  limit 1
  for update;

  if block_id is not null then
    if p_expected_updated_at is null
      or current_updated_at <> p_expected_updated_at then
      raise exception using errcode = 'P0001', message = 'SITE_COPY_WRITE_CONFLICT';
    end if;
    update public.homepage_blocks
    set block_type = p_payload ->> 'block_type',
        title = p_payload ->> 'title',
        settings = p_payload -> 'settings',
        display_order = (p_payload ->> 'display_order')::integer,
        is_enabled = (p_payload ->> 'is_enabled')::boolean,
        background_style = p_payload ->> 'background_style',
        background_media_id = nullif(p_payload ->> 'background_media_id', '')::uuid,
        updated_by = actor_user_id
    where id = block_id;
  else
    if p_expected_updated_at is not null then
      raise exception using errcode = 'P0001', message = 'SITE_COPY_WRITE_CONFLICT';
    end if;
    insert into public.homepage_blocks (
      block_type, title, settings, display_order, is_enabled,
      background_style, background_media_id, updated_by
    ) values (
      p_payload ->> 'block_type',
      p_payload ->> 'title',
      p_payload -> 'settings',
      (p_payload ->> 'display_order')::integer,
      (p_payload ->> 'is_enabled')::boolean,
      p_payload ->> 'background_style',
      nullif(p_payload ->> 'background_media_id', '')::uuid,
      actor_user_id
    ) returning id into block_id;
  end if;

  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor_user_id,
    case when coalesce((p_audit_metadata ->> 'inline_editor')::boolean, false)
      then 'site_copy.inline_updated' else 'site_copy.updated' end,
    'site_copy', block_id::text,
    coalesce(p_audit_metadata, '{}'::jsonb) || jsonb_build_object('storage', 'homepage_blocks')
  );
  return block_id;
exception
  when invalid_text_representation or numeric_value_out_of_range or not_null_violation
    or check_violation then
    raise exception using errcode = 'P0001', message = 'SITE_COPY_INVALID_PAYLOAD';
end;
$$;

-- Keep ordinary homepage blocks editable through their existing staff flows,
-- but make the singleton Site Copy row writable only by the security-definer
-- RPC above. Restrictive policies compose with the existing permissive staff
-- policy and protect both the old and proposed row on UPDATE.
drop policy if exists "Site Copy insert requires guarded RPC"
  on public.homepage_blocks;
create policy "Site Copy insert requires guarded RPC"
on public.homepage_blocks as restrictive for insert to authenticated
with check (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
);

drop policy if exists "Site Copy update requires guarded RPC"
  on public.homepage_blocks;
create policy "Site Copy update requires guarded RPC"
on public.homepage_blocks as restrictive for update to authenticated
using (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
)
with check (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
);

drop policy if exists "Site Copy delete requires guarded RPC"
  on public.homepage_blocks;
create policy "Site Copy delete requires guarded RPC"
on public.homepage_blocks as restrictive for delete to authenticated
using (
  coalesce(settings #>> '{systemKey}', '') <> 'site-copy-overrides'
);

create or replace function public.assert_redirect_candidate(
  p_id uuid,
  p_source_path text,
  p_destination_path text,
  p_is_active boolean
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  normalized_source text := regexp_replace(p_source_path, '/+$', '');
  normalized_destination text := case
    when p_destination_path like '/%' then regexp_replace(p_destination_path, '/+$', '')
    else p_destination_path
  end;
begin
  normalized_source := case when normalized_source = '' then '/' else normalized_source end;
  normalized_destination := case when normalized_destination = '' then '/' else normalized_destination end;
  if char_length(normalized_source) > 500
    or char_length(normalized_destination) > 500
    or normalized_source !~ '^/(?:$|[^/\\])'
    or normalized_source ~ '[[:cntrl:]\\]'
    or not (
      normalized_destination ~ '^/(?:$|[^/\\])'
      or normalized_destination ~ '^https://[^/[:space:]]+(?:/.*)?$'
    )
    or normalized_destination ~ '[[:cntrl:]\\]' then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_PATH';
  end if;
  if normalized_source = normalized_destination then
    raise exception using errcode = 'P0001', message = 'REDIRECT_SELF_REFERENCE';
  end if;

  if p_is_active and exists (
    select 1 from public.redirects r
    where r.id is distinct from p_id and r.is_active
      and (
        r.source_path = normalized_source
        or (normalized_destination like '/%' and r.source_path = normalized_destination)
        or r.destination_path = normalized_source
      )
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_COLLISION_OR_CHAIN';
  end if;

  if p_is_active and exists (
    select 1 from public.pages p
    where p.deleted_at is null and p.status = 'published'
      and (
        '/stranitsy/' || p.slug = normalized_source
        or regexp_replace(
          regexp_replace(coalesce(p.canonical_url, ''), '^https://[^/]+', ''),
          '/+$', ''
        ) = normalized_source
      )
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_LIVE_ROUTE_COLLISION';
  end if;

  if p_is_active and exists (
    select 1 from public.articles a
    where a.deleted_at is null and a.status = 'published'
      and regexp_replace(
        regexp_replace(coalesce(a.canonical_url, ''), '^https://[^/]+', ''),
        '/+$', ''
      ) = normalized_source
  ) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_LIVE_ROUTE_COLLISION';
  end if;
end;
$$;

create or replace function public.create_seo_redirect_guarded(
  p_source_path text,
  p_destination_path text,
  p_status_code smallint,
  p_is_active boolean
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  redirect_id uuid;
begin
  perform pg_advisory_xact_lock(188654771, 3);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  if p_status_code not in (301, 302, 307, 308) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_STATUS';
  end if;
  perform public.assert_redirect_candidate(null, p_source_path, p_destination_path, p_is_active);
  insert into public.redirects (
    source_path, destination_path, status_code, is_active, created_by
  ) values (
    coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/'),
    case when p_destination_path like '/%' then coalesce(nullif(regexp_replace(p_destination_path, '/+$', ''), ''), '/') else p_destination_path end,
    p_status_code, p_is_active, actor_user_id
  ) returning id into redirect_id;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id, metadata)
  values (actor_user_id, 'redirect.created', 'redirect', redirect_id::text,
    jsonb_build_object('sourcePath', p_source_path, 'destinationPath', p_destination_path,
      'statusCode', p_status_code, 'isActive', p_is_active));
  return redirect_id;
exception when unique_violation then
  raise exception using errcode = 'P0001', message = 'REDIRECT_SOURCE_EXISTS';
end;
$$;

create or replace function public.update_seo_redirect_guarded(
  p_id uuid,
  p_expected_updated_at timestamptz,
  p_source_path text,
  p_destination_path text,
  p_status_code smallint,
  p_is_active boolean
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  current_updated_at timestamptz;
begin
  perform pg_advisory_xact_lock(188654771, 3);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  select updated_at into current_updated_at from public.redirects where id = p_id for update;
  if current_updated_at is null or current_updated_at <> p_expected_updated_at then
    raise exception using errcode = 'P0001', message = 'REDIRECT_WRITE_CONFLICT';
  end if;
  if p_status_code not in (301, 302, 307, 308) then
    raise exception using errcode = 'P0001', message = 'REDIRECT_INVALID_STATUS';
  end if;
  perform public.assert_redirect_candidate(p_id, p_source_path, p_destination_path, p_is_active);
  update public.redirects set
    source_path = coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/'),
    destination_path = case when p_destination_path like '/%' then coalesce(nullif(regexp_replace(p_destination_path, '/+$', ''), ''), '/') else p_destination_path end,
    status_code = p_status_code,
    is_active = p_is_active
  where id = p_id;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id, metadata)
  values (actor_user_id, 'redirect.updated', 'redirect', p_id::text,
    jsonb_build_object('sourcePath', p_source_path, 'destinationPath', p_destination_path,
      'statusCode', p_status_code, 'isActive', p_is_active));
  return p_id;
exception when unique_violation then
  raise exception using errcode = 'P0001', message = 'REDIRECT_SOURCE_EXISTS';
end;
$$;

create or replace function public.delete_seo_redirect_guarded(
  p_id uuid,
  p_expected_updated_at timestamptz
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  current_updated_at timestamptz;
begin
  perform pg_advisory_xact_lock(188654771, 3);
  if actor_user_id is null
    or not public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role]) then
    raise exception using errcode = 'P0001', message = 'ADMIN_HIGH_RISK_ROLE_REQUIRED';
  end if;
  select updated_at into current_updated_at from public.redirects where id = p_id for update;
  if current_updated_at is null or current_updated_at <> p_expected_updated_at then
    raise exception using errcode = 'P0001', message = 'REDIRECT_WRITE_CONFLICT';
  end if;
  delete from public.redirects where id = p_id;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id)
  values (actor_user_id, 'redirect.deleted', 'redirect', p_id::text);
  return p_id;
end;
$$;

drop policy if exists "Staff manage redirects" on public.redirects;
drop policy if exists "Staff read redirects" on public.redirects;
create policy "Staff read redirects" on public.redirects for select to authenticated
using (public.is_staff());
revoke insert, update, delete on table public.redirects from public, anon, authenticated;
grant select on table public.redirects to anon, authenticated;

create or replace function public.moderate_comments_guarded(
  p_items jsonb,
  p_status public.publication_status
)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_user_id uuid := (select auth.uid());
  requested_count integer;
  updated_count integer;
begin
  perform pg_advisory_xact_lock(188654771, 4);
  if actor_user_id is null or not public.is_staff() then
    raise exception using errcode = 'P0001', message = 'ADMIN_STAFF_REQUIRED';
  end if;
  if p_status not in ('published'::public.publication_status, 'hidden'::public.publication_status)
    or jsonb_typeof(p_items) <> 'array' then
    raise exception using errcode = 'P0001', message = 'COMMENT_INVALID_INPUT';
  end if;
  select count(*), count(distinct item.id)
    into requested_count, updated_count
  from (
    select (value ->> 'id')::uuid as id
    from jsonb_array_elements(p_items)
  ) item;
  if requested_count < 1 or requested_count > 100 or requested_count <> updated_count then
    raise exception using errcode = 'P0001', message = 'COMMENT_INVALID_INPUT';
  end if;

  with requested as (
    select (value ->> 'id')::uuid as id,
      (value ->> 'updatedAt')::timestamptz as updated_at
    from jsonb_array_elements(p_items)
  ), locked as (
    select c.id
    from public.article_comments c join requested r on r.id = c.id
    order by c.id
    for update
  ), changed as (
    update public.article_comments c
    set status = p_status, updated_at = now()
    from requested r
    where c.id = r.id and c.updated_at = r.updated_at
    returning c.id
  )
  select count(*) into updated_count from changed;

  if updated_count <> requested_count then
    raise exception using errcode = 'P0001', message = 'COMMENT_WRITE_CONFLICT';
  end if;
  insert into public.admin_audit_log (actor_id, action, entity_type, entity_id)
  select actor_user_id, 'comment.' || p_status::text, 'comment', value ->> 'id'
  from jsonb_array_elements(p_items);
  return updated_count;
exception when invalid_text_representation or datetime_field_overflow then
  raise exception using errcode = 'P0001', message = 'COMMENT_INVALID_INPUT';
end;
$$;

-- Readers may still correct the body of their own comment. Status moderation,
-- identity fields and timestamps are no longer directly writable through the
-- authenticated API; the guarded RPC and existing security-definer community
-- functions retain their complete transactional access.
drop policy if exists "Authors manage their comments"
  on public.article_comments;
create policy "Authors manage their comments"
on public.article_comments for update to authenticated
using (author_id = (select auth.uid()))
with check (author_id = (select auth.uid()));

revoke update, delete on table public.article_comments
  from public, anon, authenticated;
revoke update (
  id, article_slug, parent_id, author_id, guest_name, session_id,
  body, status, created_at, updated_at
) on table public.article_comments from public, anon, authenticated;
grant update (body) on table public.article_comments to authenticated;

drop trigger if exists article_comments_set_updated_at
  on public.article_comments;
create trigger article_comments_set_updated_at
  before update on public.article_comments
  for each row execute function public.set_updated_at();

revoke all on function public.save_site_copy_block(timestamptz, jsonb, jsonb) from public, anon, authenticated;
revoke all on function public.assert_redirect_candidate(uuid, text, text, boolean) from public, anon, authenticated;
revoke all on function public.create_seo_redirect_guarded(text, text, smallint, boolean) from public, anon, authenticated;
revoke all on function public.update_seo_redirect_guarded(uuid, timestamptz, text, text, smallint, boolean) from public, anon, authenticated;
revoke all on function public.delete_seo_redirect_guarded(uuid, timestamptz) from public, anon, authenticated;
revoke all on function public.moderate_comments_guarded(jsonb, public.publication_status) from public, anon, authenticated;
grant execute on function public.save_site_copy_block(timestamptz, jsonb, jsonb) to authenticated;
grant execute on function public.create_seo_redirect_guarded(text, text, smallint, boolean) to authenticated;
grant execute on function public.update_seo_redirect_guarded(uuid, timestamptz, text, text, smallint, boolean) to authenticated;
grant execute on function public.delete_seo_redirect_guarded(uuid, timestamptz) to authenticated;
grant execute on function public.moderate_comments_guarded(jsonb, public.publication_status) to authenticated;

-- END WHOLE ORIGINAL supabase/migrations/20260901_zzz_admin_mutation_guards.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260902_article_working_drafts.sql SHA256 d83fec40a992068146741e77e7337e7cdf1c50f8fb290c424d41a9240d5323d8
-- Private working copies for editing an already published article without
-- mutating its public row until the normal atomic publication flow succeeds.

create table if not exists public.article_working_drafts (
  article_id uuid primary key
    references public.articles(id) on update cascade on delete cascade,
  base_article_updated_at timestamptz not null,
  payload jsonb not null,
  english_payload jsonb not null,
  expected_english_updated_at timestamptz,
  version bigint not null default 1,
  actor_id uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint article_working_drafts_payload_object_check
    check (jsonb_typeof(payload) = 'object'),
  constraint article_working_drafts_payload_size_check
    check (octet_length(payload::text) <= 5242880),
  constraint article_working_drafts_english_payload_check
    check (
      jsonb_typeof(english_payload) = 'object'
      and octet_length(english_payload::text) <= 5242880
      and (
        english_payload = '{"mode":"disabled"}'::jsonb
        or (
          english_payload ->> 'mode' = 'save'
          and jsonb_typeof(english_payload -> 'payload') = 'object'
        )
      )
    ),
  constraint article_working_drafts_version_check check (version > 0),
  constraint article_working_drafts_timestamp_order_check
    check (updated_at >= created_at)
);

create index if not exists article_working_drafts_updated_idx
  on public.article_working_drafts(updated_at desc, article_id);
create index if not exists article_working_drafts_actor_idx
  on public.article_working_drafts(actor_id, updated_at desc);

alter table public.article_working_drafts enable row level security;
alter table public.article_working_drafts force row level security;
revoke all on table public.article_working_drafts from public, anon, authenticated;
grant select on table public.article_working_drafts to authenticated;
grant all on table public.article_working_drafts to service_role;

-- Editors may prepare drafts and send them to review, but only owners/admins
-- may mutate the public/scheduled article rows.  Keep this boundary in RLS so
-- a handcrafted PostgREST/RPC request cannot bypass the server action check.
drop policy if exists "Staff create articles" on public.articles;
create policy "Staff create articles"
  on public.articles for insert to authenticated
  with check (
    public.is_staff()
    and created_by = (select auth.uid())
    and updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or status in ('draft', 'review')
    )
  );

drop policy if exists "Staff update articles" on public.articles;
create policy "Staff update articles"
  on public.articles for update to authenticated
  using (
    public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
    or (
      public.is_staff(array['editor'::public.staff_role])
      and status in ('draft', 'review')
    )
  )
  with check (
    updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review')
      )
    )
  );

-- Apply the same release boundary to article translations.  Editors may work
-- only inside an unpublished parent and may never manufacture an approved,
-- published or archived translation through direct PostgREST writes.
drop policy if exists "Staff create article translations"
  on public.article_translations;
create policy "Staff create article translations"
  on public.article_translations for insert to authenticated
  with check (
    created_by = (select auth.uid())
    and updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review')
        and approved_by is null
        and approved_at is null
        and published_at is null
        and deleted_at is null
        and exists (
          select 1
          from public.articles parent_article
          where parent_article.id = article_id
            and parent_article.status in ('draft', 'review')
            and parent_article.deleted_at is null
        )
      )
    )
  );

drop policy if exists "Staff update article translations"
  on public.article_translations;
create policy "Staff update article translations"
  on public.article_translations for update to authenticated
  using (
    public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
    or (
      public.is_staff(array['editor'::public.staff_role])
      and deleted_at is null
      and exists (
        select 1
        from public.articles parent_article
        where parent_article.id = article_id
          and parent_article.status in ('draft', 'review')
          and parent_article.deleted_at is null
      )
    )
  )
  with check (
    updated_by = (select auth.uid())
    and (
      public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role])
      or (
        public.is_staff(array['editor'::public.staff_role])
        and status in ('draft', 'review', 'stale')
        and approved_by is null
        and approved_at is null
        and published_at is null
        and deleted_at is null
        and exists (
          select 1
          from public.articles parent_article
          where parent_article.id = article_id
            and parent_article.status in ('draft', 'review')
            and parent_article.deleted_at is null
        )
      )
    )
  );

drop policy if exists "Staff read article working drafts"
  on public.article_working_drafts;
create policy "Staff read article working drafts"
  on public.article_working_drafts
  for select to authenticated
  using (public.is_staff());

create or replace function public.save_article_working_draft(
  p_article_id uuid,
  p_base_article_updated_at timestamptz,
  p_payload jsonb,
  p_english_payload jsonb,
  p_expected_english_updated_at timestamptz,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_article public.articles%rowtype;
  current_english_updated_at timestamptz;
  current_draft public.article_working_drafts%rowtype;
  saved public.article_working_drafts%rowtype;
begin
  if actor is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'staff-required';
  end if;
  if p_article_id is null
    or p_base_article_updated_at is null
    or p_expected_version is null
    or p_expected_version < 0
    or jsonb_typeof(p_payload) is distinct from 'object'
    or octet_length(p_payload::text) > 5242880
    or (
      jsonb_typeof(p_english_payload) is distinct from 'object'
      or octet_length(p_english_payload::text) > 5242880
      or not (
        p_english_payload = '{"mode":"disabled"}'::jsonb
        or (
          p_english_payload ->> 'mode' = 'save'
          and jsonb_typeof(p_english_payload -> 'payload') = 'object'
        )
      )
    ) then
    raise exception using errcode = '22023', message = 'working-draft-invalid';
  end if;

  select * into current_article
  from public.articles
  where id = p_article_id
  for update;
  if not found or current_article.deleted_at is not null
    or current_article.status is distinct from 'published'::public.article_status then
    raise exception using errcode = 'P0001', message = 'published-article-required';
  end if;
  if current_article.updated_at is distinct from p_base_article_updated_at then
    raise exception using errcode = '40001', message = 'article-version-conflict';
  end if;

  select translation.updated_at into current_english_updated_at
  from public.article_translations translation
  where translation.article_id = p_article_id
    and translation.locale = 'en'
    and translation.deleted_at is null
  for update;
  if current_english_updated_at is distinct from p_expected_english_updated_at then
    raise exception using errcode = '40001', message = 'english-version-conflict';
  end if;

  select * into current_draft
  from public.article_working_drafts
  where article_id = p_article_id
  for update;
  if found then
    if current_draft.version is distinct from p_expected_version then
      raise exception using errcode = '40001', message = 'working-draft-version-conflict';
    end if;
    update public.article_working_drafts
    set base_article_updated_at = p_base_article_updated_at,
        payload = p_payload,
        english_payload = p_english_payload,
        expected_english_updated_at = p_expected_english_updated_at,
        version = current_draft.version + 1,
        actor_id = actor,
        updated_at = now()
    where article_id = p_article_id and version = p_expected_version
    returning * into saved;
  else
    if p_expected_version <> 0 then
      raise exception using errcode = '40001', message = 'working-draft-version-conflict';
    end if;
    insert into public.article_working_drafts (
      article_id, base_article_updated_at, payload, english_payload,
      expected_english_updated_at, version, actor_id
    ) values (
      p_article_id, p_base_article_updated_at, p_payload, p_english_payload,
      p_expected_english_updated_at, 1, actor
    ) returning * into saved;
  end if;

  if saved.article_id is null then
    raise exception using errcode = '40001', message = 'working-draft-version-conflict';
  end if;
  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor,
    'article.working_draft.saved',
    'article',
    saved.article_id::text,
    jsonb_build_object(
      'version', saved.version,
      'baseArticleUpdatedAt', saved.base_article_updated_at,
      'hasEnglish', saved.english_payload ->> 'mode' = 'save'
    )
  );
  return jsonb_build_object(
    'articleId', saved.article_id,
    'version', saved.version,
    'updatedAt', saved.updated_at
  );
end;
$$;

create or replace function public.discard_article_working_draft(
  p_article_id uuid,
  p_expected_version bigint
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_version bigint;
begin
  if actor is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'staff-required';
  end if;
  if p_article_id is null or p_expected_version is null or p_expected_version < 1 then
    raise exception using errcode = '22023', message = 'working-draft-invalid';
  end if;
  select version into current_version
  from public.article_working_drafts
  where article_id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'working-draft-not-found';
  end if;
  if current_version is distinct from p_expected_version then
    raise exception using errcode = '40001', message = 'working-draft-version-conflict';
  end if;
  delete from public.article_working_drafts
  where article_id = p_article_id and version = p_expected_version;
  insert into public.admin_audit_log (
    actor_id, action, entity_type, entity_id, metadata
  ) values (
    actor,
    'article.working_draft.discarded',
    'article',
    p_article_id::text,
    jsonb_build_object('version', p_expected_version)
  );
  return jsonb_build_object('articleId', p_article_id, 'discarded', true);
end;
$$;

create or replace function public.clear_article_working_draft_after_promotion()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  delete from public.article_working_drafts where article_id = new.id;
  return new;
end;
$$;

-- An existing privileged release must not erase a newer working copy.  The
-- guard makes the legacy bundle RPC fail closed whenever a working draft is
-- present; only the promotion RPC below installs the transaction-local CAS
-- evidence after locking article -> draft in the canonical order.
create or replace function public.guard_article_working_draft_promotion()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_draft_version bigint;
  expected_promotion text;
begin
  if new.status not in ('published', 'scheduled', 'hidden', 'archived') then
    return new;
  end if;

  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = new.id
  for update;
  if not found then
    return new;
  end if;

  expected_promotion := nullif(
    current_setting('probpera.expected_working_draft_promotion', true),
    ''
  );
  if expected_promotion is distinct from
    (new.id::text || ':' || current_draft_version::text) then
    raise exception using
      errcode = '40001',
      message = 'WORKING_DRAFT_CONFLICT';
  end if;
  return new;
end;
$$;

create or replace function public.promote_article_working_draft(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz,
  p_expected_working_draft_version bigint,
  p_article_payload jsonb,
  p_english_mode text,
  p_english_payload jsonb,
  p_expected_english_updated_at timestamptz,
  p_redirect_source_path text,
  p_redirect_destination_path text,
  p_replace_homepage boolean,
  p_audit_action text,
  p_audit_metadata jsonb,
  p_social_publish_requested boolean,
  p_social_metadata jsonb
)
returns table (
  article_id uuid,
  article_updated_at timestamptz,
  english_updated_at timestamptz,
  homepage_replaced integer
)
language plpgsql
security invoker
set search_path = ''
as $$
declare
  current_article_updated_at timestamptz;
  current_draft_version bigint;
  has_working_draft boolean := false;
  target_status text := p_article_payload ->> 'status';
begin
  if (select auth.uid()) is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  if p_article_id is null
    or p_expected_article_updated_at is null
    or p_expected_working_draft_version is null
    or p_expected_working_draft_version < 0 then
    raise exception using errcode = '22023', message = 'PROMOTION_INPUT_INVALID';
  end if;
  if target_status is null
    or target_status not in ('published', 'scheduled', 'hidden', 'archived') then
    raise exception using errcode = '22023', message = 'PROMOTION_STATUS_REQUIRED';
  end if;

  select article.updated_at
  into current_article_updated_at
  from public.articles article
  where article.id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
  end if;
  if current_article_updated_at is distinct from p_expected_article_updated_at then
    raise exception using errcode = '40001', message = 'ARTICLE_CONFLICT';
  end if;

  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  has_working_draft := found;
  if (
    p_expected_working_draft_version = 0
    and has_working_draft
  ) or (
    p_expected_working_draft_version > 0
    and (
      not has_working_draft
      or current_draft_version is distinct from p_expected_working_draft_version
    )
  ) then
    raise exception using errcode = '40001', message = 'WORKING_DRAFT_CONFLICT';
  end if;

  perform set_config(
    'probpera.expected_working_draft_promotion',
    p_article_id::text || ':' || p_expected_working_draft_version::text,
    true
  );

  return query
  select bundle.article_id,
         bundle.article_updated_at,
         bundle.english_updated_at,
         bundle.homepage_replaced
  from public.save_article_bundle(
    p_article_id,
    p_expected_article_updated_at,
    p_article_payload,
    p_english_mode,
    p_english_payload,
    p_expected_english_updated_at,
    p_redirect_source_path,
    p_redirect_destination_path,
    p_replace_homepage,
    p_audit_action,
    p_audit_metadata,
    p_social_publish_requested,
    p_social_metadata
  ) bundle;
end;
$$;

drop trigger if exists articles_guard_working_draft_promotion
  on public.articles;
create trigger articles_guard_working_draft_promotion
before update on public.articles
for each row
when (new.status in ('published', 'scheduled', 'hidden', 'archived'))
execute function public.guard_article_working_draft_promotion();

drop trigger if exists articles_clear_working_draft_after_promotion
  on public.articles;
create trigger articles_clear_working_draft_after_promotion
after update on public.articles
for each row
when (new.status in ('published', 'scheduled', 'hidden', 'archived'))
execute function public.clear_article_working_draft_after_promotion();

revoke all on function public.save_article_working_draft(
  uuid, timestamptz, jsonb, jsonb, timestamptz, bigint
) from public, anon, authenticated, service_role;
revoke all on function public.discard_article_working_draft(uuid, bigint)
  from public, anon, authenticated, service_role;
revoke all on function public.clear_article_working_draft_after_promotion()
  from public, anon, authenticated, service_role;
revoke all on function public.guard_article_working_draft_promotion()
  from public, anon, authenticated, service_role;
revoke all on function public.promote_article_working_draft(
  uuid, timestamptz, bigint, jsonb, text, jsonb, timestamptz, text, text,
  boolean, text, jsonb, boolean, jsonb
) from public, anon, authenticated, service_role;
grant execute on function public.save_article_working_draft(
  uuid, timestamptz, jsonb, jsonb, timestamptz, bigint
) to authenticated;
grant execute on function public.discard_article_working_draft(uuid, bigint)
  to authenticated;
grant execute on function public.promote_article_working_draft(
  uuid, timestamptz, bigint, jsonb, text, jsonb, timestamptz, text, text,
  boolean, text, jsonb, boolean, jsonb
) to authenticated;

-- END WHOLE ORIGINAL supabase/migrations/20260902_article_working_drafts.sql

-- BEGIN WHOLE ORIGINAL supabase/migrations/20260905_article_publication_permissions.sql SHA256 508ab243ebf6f38df8af11f3f30846103b277d59d4ee715149206716e365d7bd
-- Keep public save/promotion SECURITY INVOKER and both protected tables read-only
-- to authenticated clients. Only the existing guarded operations may write.

create or replace function public.lock_article_working_draft_for_publication(
  p_article_id uuid,
  p_expected_article_updated_at timestamptz
)
returns bigint
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_article_updated_at timestamptz;
  current_draft_version bigint;
begin
  if (select auth.uid()) is null
    or not public.is_staff(array['owner'::public.staff_role, 'admin'::public.staff_role]) then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  if p_article_id is null or p_expected_article_updated_at is null then
    raise exception using errcode = '22023', message = 'PROMOTION_INPUT_INVALID';
  end if;

  -- Match the save/promotion lock order even when this helper is called directly.
  select article.updated_at into current_article_updated_at
  from public.articles article
  where article.id = p_article_id
  for update;
  if not found then
    raise exception using errcode = 'P0001', message = 'ARTICLE_NOT_FOUND';
  end if;
  if current_article_updated_at is distinct from p_expected_article_updated_at then
    raise exception using errcode = '40001', message = 'ARTICLE_CONFLICT';
  end if;

  select draft.version into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  return current_draft_version;
end;
$$;

revoke all on function public.lock_article_working_draft_for_publication(uuid, timestamptz)
  from public, anon, authenticated, service_role;
grant execute on function public.lock_article_working_draft_for_publication(uuid, timestamptz)
  to authenticated;

create or replace function public.upsert_article_redirect_guarded(
  p_source_path text,
  p_destination_path text
)
returns uuid
language plpgsql
security invoker
set search_path = ''
as $$
declare
  existing_redirect_id uuid;
  existing_updated_at timestamptz;
  normalized_source text := coalesce(nullif(regexp_replace(p_source_path, '/+$', ''), ''), '/');
begin
  if (select auth.uid()) is null or not public.is_staff() then
    raise exception using errcode = '42501', message = 'STAFF_ACCESS_REQUIRED';
  end if;
  -- Share the SEO RPC lock before reading its CAS token. Never use a direct
  -- INSERT/UPDATE or SELECT FOR UPDATE on the read-only redirects table.
  perform pg_advisory_xact_lock(188654771, 3);
  select redirect.id, redirect.updated_at
  into existing_redirect_id, existing_updated_at
  from public.redirects redirect
  where redirect.source_path = normalized_source;
  if found then
    return public.update_seo_redirect_guarded(
      existing_redirect_id, existing_updated_at,
      p_source_path, p_destination_path, 301::smallint, true
    );
  end if;
  return public.create_seo_redirect_guarded(
    p_source_path, p_destination_path, 301::smallint, true
  );
end;
$$;

revoke all on function public.upsert_article_redirect_guarded(text, text)
  from public, anon, authenticated, service_role;
grant execute on function public.upsert_article_redirect_guarded(text, text)
  to authenticated;

-- Replace only the two reviewed statements. Fail closed on an unexpected
-- predecessor; retain every original role, payload, CAS, RLS and atomicity gate.
do $publication_permissions$
declare
  promotion_oid regprocedure := to_regprocedure(
    'public.promote_article_working_draft(uuid,timestamptz,bigint,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
  );
  bundle_oid regprocedure := to_regprocedure(
    'public.save_article_bundle(uuid,timestamptz,jsonb,text,jsonb,timestamptz,text,text,boolean,text,jsonb,boolean,jsonb)'
  );
  definition text;
  old_lock text := $old_lock$  select draft.version
  into current_draft_version
  from public.article_working_drafts draft
  where draft.article_id = p_article_id
  for update;
  has_working_draft := found;$old_lock$;
  new_lock text := $new_lock$  current_draft_version := public.lock_article_working_draft_for_publication(
    p_article_id, p_expected_article_updated_at
  );
  has_working_draft := current_draft_version is not null;$new_lock$;
  old_redirect text := $old_redirect$    insert into public.redirects (
      source_path,
      destination_path,
      status_code,
      is_active,
      created_by
    ) values (
      p_redirect_source_path,
      p_redirect_destination_path,
      301,
      true,
      actor_id
    )
    on conflict (source_path) do update set
      destination_path = excluded.destination_path,
      status_code = 301,
      is_active = true,
      created_by = actor_id;$old_redirect$;
  new_redirect text := $new_redirect$    perform public.upsert_article_redirect_guarded(
      p_redirect_source_path, p_redirect_destination_path
    );$new_redirect$;
begin
  if promotion_oid is null or bundle_oid is null
    or exists (select 1 from pg_proc where oid in (promotion_oid, bundle_oid) and prosecdef) then
    raise exception 'Expected SECURITY INVOKER article publication functions are missing';
  end if;

  definition := pg_get_functiondef(promotion_oid);
  if strpos(definition, old_lock) > 0 and strpos(definition, new_lock) = 0
    and (length(definition) - length(replace(definition, old_lock, ''))) = length(old_lock) then
    execute replace(definition, old_lock, new_lock);
  elsif strpos(definition, old_lock) > 0 or strpos(definition, new_lock) = 0 then
    raise exception 'Unexpected article promotion lock predecessor';
  end if;

  definition := pg_get_functiondef(bundle_oid);
  if strpos(definition, old_redirect) > 0 and strpos(definition, new_redirect) = 0
    and (length(definition) - length(replace(definition, old_redirect, ''))) = length(old_redirect) then
    execute replace(definition, old_redirect, new_redirect);
  elsif strpos(definition, old_redirect) > 0 or strpos(definition, new_redirect) = 0 then
    raise exception 'Unexpected article redirect write predecessor';
  end if;

  if exists (
    select 1 from pg_proc where oid in (promotion_oid, bundle_oid) and prosecdef
  ) or not (
    select prosecdef from pg_proc
    where oid = 'public.lock_article_working_draft_for_publication(uuid,timestamptz)'::regprocedure
  ) or (
    select prosecdef from pg_proc
    where oid = 'public.upsert_article_redirect_guarded(text,text)'::regprocedure
  ) then
    raise exception 'Article publication privilege boundaries changed';
  end if;
  if has_table_privilege('authenticated', 'public.article_working_drafts', 'INSERT,UPDATE,DELETE')
    or has_any_column_privilege('authenticated', 'public.article_working_drafts', 'UPDATE')
    or has_table_privilege('authenticated', 'public.redirects', 'INSERT,UPDATE,DELETE')
    or has_any_column_privilege('authenticated', 'public.redirects', 'UPDATE') then
    raise exception 'Protected article tables must remain read-only to authenticated clients';
  end if;
  if not has_function_privilege('authenticated',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or not has_function_privilege('authenticated',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE')
    or has_function_privilege('anon',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or has_function_privilege('service_role',
      'public.lock_article_working_draft_for_publication(uuid,timestamptz)', 'EXECUTE')
    or has_function_privilege('anon',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE')
    or has_function_privilege('service_role',
      'public.upsert_article_redirect_guarded(text,text)', 'EXECUTE') then
    raise exception 'Article publication helper ACLs are invalid';
  end if;
end;
$publication_permissions$;

-- END WHOLE ORIGINAL supabase/migrations/20260905_article_publication_permissions.sql
