PREPARED ONLY. No SQL parse/application, native test, compiler, database/server,
browser or provider was run. No expected-success claim is made.

foundation.prepared.sql contains the whole unchanged current checked-in
supabase/schema.sql and21 whole actual migration files. Every original section
has a byte offset/length/SHA in source-manifest.json; each is also captured under
sources/. There are37 exact repository captures, including reference-only
application/consumer/export/workflow/contracts. Nothing was patched or sliced
from the actual outbox, autosave, canonical, revision, guard or permission DDL.

The declaration of20 outbox relation origins is a static source map, NOT a SQL
parse or a claim that those objects have been created. The whole actual Aug14
outbox follows those20 definitions. Actual cover-artwork then adds the21st
relation/trigger before the real later health functions. Whole staff-read,
owner/redirect guards, atomic article bundle, working drafts and Sep5 permission
hotfix are included so callable signatures are not substituted for their real
predecessors or ACLs. This focused chain is not all current project migrations.

Only platform-scaffold.sql is synthetic: auth.users/uid, minimal Storage
catalogs and Realtime publication. It checks existing platform roles and does
not create/alter roles, replace is_staff or fake any public target. Managed
GoTrue/Storage/Realtime behavior is NOT modeled. The whole real schema installs
handle_new_user: future fixture users therefore need valid email/display-name
metadata; inserting only an ID can correctly fail the real profiles constraint.
actors.prepared.sql records such local fixture data, but has not run.

Future owner-only execution recipe, ONLY AFTER explicit root release:

1. Bind all37 captured repository files to the exact completed root snapshot.
   Re-read source-manifest hashes/section ranges. Never silently use a changed
   source file or claim the old stub enqueue is this actual baseline.
2. Reuse existing PG17.11 binaries/owned loopback55438 descriptor only after a
   fresh actual previous-PID, postmaster.pid and listener check. The last old
   cleanup receipt is historical and is not current liveness evidence.
3. Create a NEW uniquely named local database; refuse an existing name. Do not
   clone/reset/drop the former site-copy DB or bypass a reused runner allowlist.
4. Use current PowerShell7 + psql --no-psqlrc --set=ON_ERROR_STOP=1 with the new
   foundation.prepared.sql. Retain full original output/exit code and input SHA.
   A missing dependency/predecessor/privilege is a genuine preparation/runtime
   finding, not permission to replace a real object or suppress the guard.
5. actors.prepared.sql is optional actual-table fixture data. The fixture owner
   may seed synthetic users/memberships; probes must SET ROLE authenticated and
   exercise auth.uid/current staff RLS without superuser/BYPASSRLS for actors.
6. Use postflight.prepared.sql to OBSERVE actual schema/ACL/trigger facts. It
   has no hardcoded success verdict. Export actual function definitions and
   table/index/constraint/policy/ACL baseline before any future additive retry
   migration; compare to that SAME foundation afterward.
7. Keep actual M04 append/mark/native races and M20 exact-delete proofs separate.
   Always stop only the exact owned PID in finally; record process/pidfile/port
   and every client termination. No production host, credentials or provider.

Important missing privilege provenance: many canonical CMS tables rely on
managed default grants not declared in these repository migrations. This recipe
adds NO broad/default grants to those targets. Actual outbox SELECT/RPC and
autosave authenticatedDML grants are explicit in the real migrations. Positive
canonical invoker writes or save_editor_autosave with canonical entity lookup
may remain unavailable until the real default-grant source is established.
Owner fixture seeding/trigger observation is not authenticated mutation proof.

Existing outbox actor_id references auth.users ON DELETE SET NULL. A future
retry actor-nonnull check/UNIQUE(actor,operation) design must resolve deletion/
retained identity semantics explicitly; this OLD foundation adds no retry
columns, checks, authority or policy and does not change that contract.

M20 exact-delete can use actual actor/session/sequence/hash predicates against
the real FORCE-RLS autosave table. Wrong/foreign/newer and revoked-staff cases
must remain exact, never weaken query predicates/grants. The separate React
component probe is not a managed PostgREST/Auth/full-admin E2E claim.
