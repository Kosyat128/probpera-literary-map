"""Curate immutable, non-secret continuation work for the authorized Git checkpoint."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import zipfile

WORK = Path(__file__).resolve().parent
REPO = WORK.parent / 'probpera-literary-map'
OUT = REPO / 'docs/admin-r3-continuation/2026-11-11'

DIRECTORIES = [
    'acceptance-gap-inventory-sol',
    'next-editor-creator-execution-sol',
    'next-m19-creator-before-sol',
    'next-m20-page-actor-before-sol',
    'm19-creator-fix-draft-sol',
    'm19-creator-fix-draft-v2-sol',
    'm19-creator-implementation-sol',
    'm19-next-source-preparation',
    'm20-page-pending-fix-draft-sol',
    'm20-page-pending-implementation-sol',
    'm20-page-pending-tests-sol',
    'm20-pending-submitter-tests-proposal-sol',
    'next-m04-publication-cut-before-sol',
    'next-m04-m20-real-foundation-sol',
    'next-m04-m20-native-runner-sol',
    'm04-publication-cut-before-v1',
    'm04-publication-cut-before-v1-launcher',
    'm04-publication-cut-before-v2-launcher',
    'm04-publication-cut-syntax-v2',
    'm04-publication-cut-independent-static-review-sol',
    'm19-m20-portability-audit-sol',
    'portable-capture-smoke-creator-20261111',
    'portable-capture-smoke-pending-20261111',
]
FILES = [
    'root-r3-next-fixes-live-state.json',
    'root-m19-m20-wip-checkpoint.json',
    'root-m19-m20-wip-checkpoint.mjs',
    'canonical-before-m19-m20-implementation-wip.md',
    'canonical-at-4df-immutable-seal.md',
    'm19-m20-genuine-controlled-before.zip',
    'm19-m20-genuine-controlled-before.manifest.json',
    'm19-m20-genuine-controlled-before.receipt.json',
    'm19-m20-genuine-controlled-before.current54-barrier.json',
    'historical-test-selection.txt',
    'continuation-validation/source-before.json',
    'profile-stable-scan-final-validation-v4/source-before.json',
    'm04-m20-final-validation-v2/source-before.json',
    'm04-m20-final-validation-v2/selected-tests-summary.json',
    'm04-m20-final-validation-v2/gates-summary.json',
    'm04-m20-final-validation-v2/baseline-preservation.json',
    'm04-m20-final-validation-v2/gate-readonly-hyphens.log',
    'm04-m20-final-validation-v2-runner.mjs',
    'm04-m20-final-validation-v2-preservation.mjs',
    'm19-m20-local-validation-v1-runner.mjs',
    'm19-m20-local-validation-v1-preservation.mjs',
    'm19-m20-local-validation-prepared.json',
    'prepare-m19-m20-local-validation.mjs',
    'run-m04-cut-before-v3.py',
    'package-admin-transfer-20261111.py',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


paths = set()
for name in DIRECTORIES:
    directory = WORK / name
    if not directory.is_dir() or directory.is_symlink():
        raise ValueError('Missing or linked required work directory: ' + name)
    for path in directory.rglob('*'):
        if path.is_symlink():
            raise ValueError('Do not transfer linked work inputs: ' + str(path))
        if path.is_file() and not any(part in ('__pycache__', 'child-temp', 'temp') for part in path.relative_to(directory).parts):
            paths.add(path.relative_to(WORK).as_posix())
for name in FILES:
    path = WORK / name
    if not path.is_file() or path.is_symlink():
        raise ValueError('Missing or linked required work file: ' + name)
    paths.add(name)

files = []
payload = {}
for name in sorted(paths):
    path = WORK / name
    if path.resolve().is_relative_to(WORK.resolve()) is False:
        raise ValueError('Work source escape')
    if path.name in ('.env', '.env.local', 'owned-cluster.json') or path.suffix.lower() in ('.exe', '.dll', '.pdb', '.key', '.pem', '.pyc'):
        raise ValueError('Runtime or secret material is not a continuation payload: ' + name)
    data = path.read_bytes()
    payload[name] = data
    files.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})

manifest = {
    'schemaVersion': 1,
    'classification': 'PORTABLE_CONTINUATION_WORK_AND_HISTORICAL_EVIDENCE_NOT_NEW_ACCEPTANCE',
    'handoffDate': '2026-11-11',
    'createdAt': datetime.now(timezone.utc).isoformat(),
    'baseCommit': 'acb910d89133396e8e9794e91bd5db74128dab3b',
    'branch': 'codex/admin-r3-data-errors',
    'latestVerifiedHistoricalSource': '4dfef15fce331db39acc97da710c1a814b30554434b72754239f95111e4edb78',
    'currentProductStage': 'SIX_M19_M20_PRODUCTION_FILES_WIP_NOT_AFTER_TESTED',
    'nativeM04T12': 'NOT_RUN_BOTH_FAILURES_BEFORE_DATABASE_START',
    'sourceSelection': {'directories': DIRECTORIES, 'files': FILES},
    'excluded': ['Secrets and local env', 'Installed dependencies and runtimes', 'PostgreSQL data and owned PID descriptor', 'Temporary directories and Python caches', 'Missing M02 originals are neither searched nor recreated'],
    'pathPolicy': 'Restore as new sibling work directory. Absolute paths inside retained files are historical references; recapture current inputs and prepare new local native environment before executing.',
    'files': files,
}
manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
OUT.mkdir(parents=True, exist_ok=True)
archive = OUT / 'continuation-work.zip'
if archive.exists() or (OUT / 'continuation-work.manifest.json').exists() or (OUT / 'continuation-work.receipt.json').exists():
    raise FileExistsError('Never overwrite a sealed handoff')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=7) as target:
    for name, data in payload.items():
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 11, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (stat.S_IFREG | 0o644) << 16
        info.compress_type = zipfile.ZIP_DEFLATED
        target.writestr(info, data)
    target.writestr('manifest.json', manifest_bytes)

with zipfile.ZipFile(archive) as check:
    assert len(check.infolist()) == len(files) + 1
    assert check.read('manifest.json') == manifest_bytes
    for row in files:
        data = check.read(row['path'])
        assert data == payload[row['path']] and len(data) == row['bytes'] and sha(data) == row['sha256']
for row in files:
    assert (WORK / row['path']).read_bytes() == payload[row['path']], 'Work source changed during packaging'

(OUT / 'continuation-work.manifest.json').write_bytes(manifest_bytes)
archive_bytes = archive.read_bytes()
receipt = {
    'classification': 'ALL_CURATED_PAYLOADS_HASH_VERIFIED_NOT_APP_TEST_EXECUTION',
    'date': '2026-11-11',
    'payloadCount': len(files),
    'uncompressedPayloadBytes': sum(row['bytes'] for row in files),
    'archive': {'file': archive.name, 'bytes': len(archive_bytes), 'sha256': sha(archive_bytes)},
    'manifestSha256': sha(manifest_bytes),
    'sourceDriftDuringPackaging': [],
    'productionTestsRunByPackaging': 0,
}
(OUT / 'continuation-work.receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(receipt))
