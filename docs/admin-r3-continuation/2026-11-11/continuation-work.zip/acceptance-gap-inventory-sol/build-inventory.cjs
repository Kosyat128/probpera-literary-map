const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const currentFile=file=>{const filename=path.resolve(repo,file);return{file,exists:fs.existsSync(filename),...(fs.existsSync(filename)?{bytes:fs.statSync(filename).size,sha256:sha(fs.readFileSync(filename))}:{})}};
function anchor(file,needle){const lines=fs.readFileSync(path.join(repo,file),'utf8').split(/\r?\n/u),at=lines.findIndex(line=>line.includes(needle));assert.ok(at>=0,`${file}: ${needle}`);return{file,line:at+1,needle,evidenceLevel:'SOURCE_INSPECTION_ONLY'};}
const requirements=[];
for(const module of['M07','M24'])for(const line of fs.readFileSync(path.join(repo,`docs/admin-r3-task-package/modules/${module}.md`),'utf8').split(/\r?\n/u)){
 if(!line.startsWith('| '+module+'-T'))continue;const cells=line.split('|').map(s=>s.trim());requirements.push({id:cells[1],requirement:cells[2],expected:cells[3],requiredLevel:cells[4]});}
const evidence={
 PWHOLE:{...currentFile('docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/whole-validation-evidence.zip'),receipt:'docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/whole-validation-evidence.receipt.json',member:'final/selected-tests.raw.json',scope:'Sealed1af current-at-that-checkpoint full source. Specific case names/statuses were read, not inferred from total tests. It does not cover current site-copy working changes.'},
 PSCAN:{...currentFile('docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/profile-stable-scan-controlled-tests.zip'),scope:'Actual finite writer/country engine/actions/SDK/SSR controls and unchanged a988 coverage oracle. Local controlled boundaries; no browser/managed claim.'},
 PSQL:{...currentFile('docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/sql-evidence.zip'),scope:'Real owned PostgreSQL finite profile manifests/child/prefix/cancel constraints and2/3-session races. Native56 replay qualification is parser+GET, not all-mutator SDK integration.'},
 LSQL:{...currentFile('docs/admin-r3-evidence/2026-10-30-stable-traversal/sql-evidence.zip'),scope:'Real owned PostgreSQL library fixed-window/keyset/highwater and concurrency controls; metadata and paid APIs remain separate.'},
 CADMIT:{...currentFile('docs/admin-r3-evidence/2026-10-30-catalog-admission/catalog-admission-controlled-tests.zip'),scope:'Actual book/country helpers, retained raw bodies, original seed validators, manual/current/pending, unknown/complete recovery; controlled storage/provider.'},
 CSQL:{...currentFile('docs/admin-r3-evidence/2026-10-30-catalog-admission/sql-evidence.zip'),scope:'Actual isolated SQL full seed/CAS/private stage/promotion/role controls, native groups and concurrent admission; synthetic Auth/outbox scaffold disclosed.'},
 CFRESH:{...currentFile('docs/admin-r3-evidence/2026-10-30-catalog-review-freshness/catalog-review-freshness-controlled-tests.zip'),scope:'Actual review/SSR offers close on licence/opaque-rights source drift; preview/discard preserved; unchanged original checks and explicit historical graph qualification.'},
 WADMIT:{...currentFile('docs/admin-r3-evidence/2026-10-30-writer-admission/writer-admission-controlled-tests.zip'),scope:'Actual writer paid admission/ACK/body recovery/manual/private review control, not automatic partial continuation.'},
 BUDGET:{...currentFile('docs/admin-r3-evidence/2026-10-29-profile-budgets/runtime-regression-evidence-typefix.zip'),member:'current-final/current-controls/report.json',scope:'Specific original33 budget controls and39-case wrapper, genuine same-input conflict-cap proofs; same source assertions retained. Strongest current-at-1af run is also in PWHOLE.'},
 SCREVIEW:{...currentFile('docs/admin-r3-evidence/2026-10-29-site-copy-review/runtime-evidence.zip'),member:'m07-site-copy-review-package-final5-20261029-sol/current/report.json',scope:'Actual66 source-save/model/private-review/manual/raw-preservation controls plus4 orphan recovery page checks. Controlled provider/Auth/storage/publication, not e2e.'},
 SCSQL:{...currentFile('docs/admin-r3-evidence/2026-10-29-site-copy-review/sql-presentation-evidence.zip'),scope:'Actual native28 old book/country/writer/sitecopy groups and singleton lock; final escape-only fixture source proof. Prior private-review/CAS behavior, not new paid admission whole acceptance.'},
 SCNOW:{...currentFile('../work/site-copy-focused-fcxsix/receipt.json'),scope:'Current in-flight phase: actual4-file focused200/200,44 core groups incl freshness controls. Local SDK/provider boundary; source bindings apply to this receipt, not an unsealed global current acceptance.'},
 SCUI:{...currentFile('../work/site-copy-engine-sol/site-copy-ui-evidence.zip'),scope:'Current UI-only immutable389-case packet,79 source bindings; new87 read/SSR/resume/recovery cases. Dependency identities are recorded, not a portable browser/native replay.4 repeated recovery cases add no distinct count.'},
 SCBEFORE:{...currentFile('docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/next-retry-partial-before.zip'),scope:'Genuine historical cf1/a63 two sitecopy partial/unknown failures with9 other-domain guards. Current sitecopy implementation proof is in-flight; historical original source scope is explicitly distinct from validated1af.'},
 NEXTKNOWN:{...currentFile('../work/next-known-editorial-partial-sol/prepared-plan.json'),scope:'SOURCE_ONLY/PREPARED. New valid translation plus invalid review/final repair and second ordinary helper producer has NOT executed. No runtime failure inferred.'},
 NEXTPARAM:{...currentFile('../work/next-site-copy-parameters-before.cjs'),scope:'Root-only prepared real {page}/{total}/{count} placeholder producer, NOT executed. Source suspicion is not a reproduced mismatch or accepted fix.'}
};
const rows=[];
function row(id,status,proof,remainingFunctionality,remainingProof,notes=[],anchors=[]){const requirement=requirements.find(r=>r.id===id);assert.ok(requirement,id);rows.push({...requirement,status,strongestRelevantProof:proof.map(([ref,detail])=>({ref,detail})),remainingFunctionality,remainingProof,notes,anchors});}
const batch='apps/admin/app/(dashboard)/translations/article-batch.integration.test.ts',page='apps/admin/app/(dashboard)/translations/page.tsx';
row('M07-T01','PARTIAL',[
 ['PWHOLE','Specific article manual-current/manual-stale/deleted ownership cases and sitecopy66 manual/blank/null/ambiguous guards pass; historical book/country manual draft SAME39 is recorded in canonical checkpoint.'],
 ['CADMIT','Book/country helper manual/current/pending/source guards.'],['WADMIT','Writer ordinary/batch/manual private-body protection.'],['SCNOW','Current sitecopy manual/present blank/null/malformed ownership controls retain source exactly.']],
 ['No new overwrite defect established here. Verify all relevant retry/restore/import routes; current explicit nonarticle retry is absent rather than permission to weaken manual protection.'],
 ['A criterion-scoped DB+integration route matrix across backfill/retry/restore and all applicable entity kinds is not mapped; new sitecopy phase must be sealed/rebound.'],
 ['Canonical explicitly kept all-route T01 DB/integration acceptance partial. Do not convert protected source diff or suite totals into all-route proof.']);
row('M07-T02','LOCAL_PROOF',[
 ['CSQL','Actual full original book/country seed and atomic current-source/manual/CAS private promotion refusal.'],['CFRESH','Actual preflight closes on opaque rights/licence drift while retaining review/discard.'],['SCREVIEW','Changed RU and manual takeover during the second provider pass retain stale private output without canonical mutation.'],['SCSQL','Real private staging/current singleton/CAS promotion guard.']],
 ['No remaining unsafe late overwrite demonstrated in inspected current paths; output stays private.'],
 ['Rebind new sitecopy full-row cache/atomic promotion to final native/current global source; managed Auth/PostgREST remains a separate deployment-level limitation.'],
 ['LOCAL_PROOF is scoped actual isolated DB+integration, not whole-module or production acceptance.']);
row('M07-T03','PARTIAL',[
 ['PWHOLE','Article failed-item selection/operation and stable scan integration suites run; terminal successes are not reused as retry targets.'],['PSCAN','Continue uses original finite profile membership, not rescan statistics.'],['SCUI','Sitecopy recovery is addressed/free and distinct from fresh intent.']],
 ['Nonarticle addressed failed-item/version retry and its explicit operator UI remain pending. No10-item8success/2failure end-to-end command flow was located.'],
 ['Produce exact finite10-item8+2 fixture through actual bounded actions; execute Continue and selected Retry, proving8successful/manual/current items get no regeneration.'],
 ['Zero-cost recovery and a63 partial holds are not a paid failed-item retry implementation.']);
row('M07-T04','LOCAL_PROOF',[
 ['PWHOLE','Actual article stop/accepted-first-pass and authoritative receipt-count controls pass.'],['PSQL','Real cancellation/dispatch/member-prefix constraints preserve accepted responses and refuse new reservations.'],['SCNOW','Feature flag before new expense and after accepted translation, cancellation and original45s controls.']],
 ['No new stop defect established. Keep staff bounded-sync distinct from service-role leases and do not claim a background worker.'],
 ['Seal current sitecopy source/native proof and re-evaluate any new worker/global-concurrency mechanism separately.'],
 ['Canonical older active-stop native proof is referenced but its ignored.tmp raw path is absent here; use retained archives/current specifically mapped controls, not reconstructed originals.']);
row('M07-T05','LOCAL_PROOF',[
 ['SCREVIEW','Actual technical completion leaves canonical/public EN unchanged, stages pending private output and requires explicit checkbox for promotion.'],['SCSQL','Actual human approval/discard/private guard with old branch compatibility.'],['CFRESH','Review availability depends on actual full seed.'],['SCUI','Actual receipt wording is historical, reservations do not imply HTTP completion, owner preview is validated, no automatic publish/current-draft assertion.']],
 ['No extra feature needed merely to restyle the existing review mechanism.'],
 ['Final new sitecopy whole/native source seal is pending; full authenticated publication lifecycle remains separately unverified.'],
 ['Required unit/component behavior has concrete local proof. Old admitted records are not mass relabeled.']);
row('M07-T06','LOCAL_PROOF',[
 ['PWHOLE','Specific37 gate/full Health+Translations configuration-binding cases and70 actual self-test action/SDK cases pass in sealed1af raw report.']],
 ['No remaining configuration identity defect identified in inspected current source; models/reasoning/review/prompt identity and current-result consumption exist.'],
 ['Keep source binding current when callers change. Real paid probe/managed service tests are not required to manufacture unit/static acceptance and are not authorized here.'],
 ['Canonical explicitly calls this locally verified at its required unit/static boundary. Historical.tmp raw references are absent, but current-at-1af specific test results are present in the immutable whole archive.']);
row('M07-T07','LEVEL_DEFERRED',[
 ['PWHOLE','Named actual article batch case reaches helper and translates stale published machine EN; hash+revision classifier is exercised with controlled DB/provider transport.'],['CSQL','Independent native source/target CAS guards strengthen safety, but are not by themselves the exact published-stale scenario.']],
 ['No source defect demonstrated in current prefilter; published is not freshness.'],
 ['Map/run the exact published-machine-old-RU-hash scenario at required unmocked DB level through corresponding actual path; historical local integration alone does not supply that DB proof.'],[],[anchor(batch,'translates stale published machine EN')]);
row('M07-T08','LOCAL_PROOF',[
 ['PWHOLE','Named actual helper/action tests confirm matching source hash plus valid RU revision and zero model calls; wrong/missing revision stays unknown.']],
 ['No remaining currentness classification defect identified.'],
 ['Preserve exact no-provider and matching-revision controls after any future retry change; no new real provider call is needed.'],[],[anchor(batch,'confirms matching hash and source revision')]);
row('M07-T09','LEVEL_DEFERRED',[
 ['PWHOLE','Named mixed current/stale machine/manual/missing action test and manual freshness helper cases pass; manual remains manual with independent freshness.']],
 ['Axes are present in helper/action summaries; no current source defect demonstrated here.'],
 ['A specifically mapped actual component/SSR rendering of the mixed-axis summary is still needed for the component half of integration+component; the current operation-receipt UI cases are not that scenario.'],[],[anchor(batch,'mixed current/stale machine/manual/missing')]);
row('M07-T10','LOCAL_PROOF',[
 ['BUDGET','Genuine same-input conflict-only writer/library/country controls measure started attempts rather than successes, original3/4/2 caps and4-call attempt bounds.'],['PWHOLE','Specific39 budget and59 article batch cases pass in sealed current-at-1af report.']],
 ['No per-request conflict-cap defect demonstrated. Global multi-request billing/concurrency budgets are separate cross-cutting work.'],
 ['Retain all old cap assertions and exact cursor/receipt accounting when explicit retries are added.']);
row('M07-T11','LOCAL_PROOF',[
 ['PWHOLE','Specific actual OpenAI+Cloudflare shared translation/repair/review/final-repair, stop/deadline and real-shaped429 accounting controls pass;32 premium budget cases.'],['BUDGET','Domain helpers share original1attempt/4reservations and bounded batch budgets; incomplete response is not staged as complete.'],['SCNOW','Current sitecopy raw-body-before-next-pass,45s/cancel/flag and partial hold controls.']],
 ['Known editorial-failure repeat regeneration is a separate SOURCE_ONLY suspicion, not a reproduced defect; prepared NEXT producer remains unexecuted. No automatic paid partial continuation is required or authorized by T11.'],
 ['Rebind current sitecopy final native/controlled/whole source; execute the distinct NEXT trigger only after root release, preserving result even if no failure occurs.'],
 ['The existing a63 deadline/unknown controls are passing safety holds, not proof of trusted paid continuation or a new deadline.']);
row('M07-T12','LOCAL_PROOF',[
 ['LSQL','Actual book fixed windows/high-water/keyset/tied-date insert-delete-update controls and real lock races.'],['PSQL','Actual eager immutable finite writer/country tuple/hash manifests and predecessor/prefix/cancel constraints.'],['PSCAN','Unchanged a988 target checks, actual engines/SDK/actions and window-local SSR counts; requested window identity and no false future500confirmed.']],
 ['No remaining demonstrated bounded traversal omission/repeat defect in mapped scope. New corpus members intentionally require the documented fresh command.'],
 ['Keep current sitecopy changes from invalidating older traversal readgraph/source bindings; do not infer all-mutator SDK/native end-to-end from native56 GET/parser qualification.']);
row('M07-T13','PARTIAL',[
 ['PWHOLE','Article-only explicit failed item/version action, stable scan continuation and ordinary private candidate controls exist and pass local integration.'],['SCUI','Strict5-field sitecopy marker/exact job-op-actor-intent routing; numeric legacy resume refuses, recovery carries no fresh intent.'],['PSCAN','Finite profile Continue stays separate from one-item paid operation marker.']],
 ['Actual generic/nonarticle addressed failed-item/version operator flow remains absent; full10=8+2 Continue-vs-Retry UI workflow is pending.'],
 ['Required integration+admin-e2e must execute that real command flow. Earlier native browser ordinary-admission snapshots and current SSR do not substitute for its full authenticated lifecycle.'],[],[anchor(page,'entity_type: z.literal("article")'),anchor(page,'.eq("job_id", query.retryJob).eq("entity_type", "article")')]);
row('M24-T01','LEVEL_DEFERRED',[
 ['SCREVIEW','Actual save runs guarded source RPC then ordinary publication before optional model work; runtime disabled/throw/provider failure preserves changed RU, old EN, other locales/settings and one ordinary build request.'],['SCSQL','Real singleton/CAS storage authority.'],['SCNOW','Durable new admission/unknown body retention and no duplicate paid aggregate.']],
 ['Source-save ordering is already corrected; do not reimplement it or invent a bilingual release policy not established by the current architecture.'],
 ['Required DB+integration+e2e needs actual source-save/provider-unavailable browser roundtrip and confirmed persisted/public version semantics; controlled build request is not deployed delivery.'],
 ['Current source-save prefix through save/CAS/ordinary build is independently byte-exact to1af, but e2e remains deferred.']);
row('M24-T02','LOCAL_PROOF',[
 ['SCREVIEW','Actual second-pass RU change and manual EN takeover retain stale private output, never overwrite current text, and close approval.'],['SCSQL','Actual SQL stage/promote exact singleton/settings/source/target CAS and manual ownership.'],['SCUI','Owner-only validated retained preview, historical receipt and no new expense under current source/runtime outage.']],
 ['No concrete remaining late canonical overwrite demonstrated.'],
 ['Current new full-row paid-cache/linked-draft freshness/native race proof must be finalized and sealed at the actual source; no current native12/12 claim is made by this inventory.']);
row('M24-T03','PARTIAL',[
 ['NEXTPARAM','Real page/total/count strings and replacement sites are identified; a parent-only producer is prepared but unexecuted.']],
 ['Current candidate validation checks keys/order/text/Cyrillic, not an explicit real-variable/token compatibility contract. This is a source-only gap candidate pending genuine reproduction, not an invented universal ICU requirement.'],
 ['Run the real parameterized-key BEFORE after current seal, then unit+e2e mismatch/refusal and a plain-text positive control; verify supported token mechanisms actually used.'],[],[anchor('apps/admin/lib/site-copy-translation-contract.ts','export function validateSiteCopyTranslationCandidate'),anchor('src/i18n/InterfaceLanguage.tsx','Страница {page} из {total}')]);
row('M24-T04','PARTIAL',[
 ['PWHOLE','Site-copy storage tests explicitly delete empty submitted overrides to inherit fallback, preserve omitted neighbour/locales and inline EN.'],['SCREVIEW','Actual RU-only/EN-only raw preservation/tombstone/neighbour cases.']],
 ['Reset/inherit exists, but UI/storage currently collapse blank into inheritance. No explicit permitted-intentional-empty key contract or distinct command has been mapped; determine applicability per real key instead of claiming absence makes it N/A.'],
 ['Required DB+integration must cover all three intents for a genuinely allowed-empty key, or document/test a real key-specific no-empty policy before save; preserve raw omitted values.'],[],[anchor('apps/admin/lib/site-copy-storage.ts','else ru.delete(targetKey)'),anchor('apps/admin/components/SiteCopyEditor.tsx','Пусто - исходный текст')]);
row('M24-T05','LEVEL_DEFERRED',[
 ['SCREVIEW','Actual stale deleted-master save cannot recreate, duplicate canonical rows close helpers/actions before provider/writes, raw settings retained.'],['SCSQL','Actual shared singleton advisory lock and source/target CAS boundaries.'],['SCNOW','Current native full-row admission/promotion concurrency work is in flight, separate from sealed UI/SDK proof.']],
 ['No new lost-update/duplicate-master defect established in allowed current action path. Source-only mutex/CAS is not a substitute for the exact concurrency scenario.'],
 ['Map/finish exact real two ordinary forms with same expected revision, stale post and deleted/recreated first-create race; assert one authoritative master and no lost neighbouring update at DB+integration level. Current paid FINISH/promote-vs-save races strengthen but do not silently replace this contract.']);
row('M24-T06','UNMAPPED',[],
 ['Personal/shared server actions and owner/shared/admin RLS exist. Do not invent a new template system; first verify actual roles/read/edit/delete/apply behavior.'],
 ['No criterion-specific retained DB+e2e two-actor personal/private and permitted shared application proof was located in the inspected checkpoint/receipts. Need real RLS actor matrix plus actual shared selection/nonempty article flow.'],
 ['Existing implementation presence is not acceptance; initialNOT_RUN is not used as a verdict.'],[anchor('apps/admin/app/(dashboard)/articles/template-actions.ts','export async function saveEditorTemplateAction'),anchor('supabase/migrations/20260802_editor_templates.sql','Staff read available editor templates')]);
row('M24-T07','PARTIAL',[
 ['PWHOLE','Specific site-copy storage unit case rejects prototype keys at read/mutation boundaries; curated/custom universal keys, inline EN and nonempty projection controls pass.'],['SCREVIEW','Actual full raw neighbour/locale/settings preservation and candidate key/order constraints.']],
 ['Reserved-key defenses and allowed interface custom keys exist; no actual pollution defect established. Actual form feedback/rejection and permitted unknown-existing custom key path still need direct route mapping.'],
 ['Required unit+integration should execute unknown/reserved/custom key save through the actual action, preserving canonical dictionary/object prototype and legitimate stored keys; unit helper/source tests alone are insufficient.'],[],[anchor('apps/admin/lib/site-copy-storage.test.ts','rejects prototype keys'),anchor('apps/admin/app/(dashboard)/site-copy/actions.ts','function isAllowedCopyKey')]);
row('M24-T08','PARTIAL',[],
 ['Existing template HTML sanitizer, nonempty article confirmation, mandatory pre-insertion recovery copy and authored-dirty marker are present. Unsafe content/approval-reset behavior is not established by this source inspection.'],
 ['Map/run actual unsafe template application through preview against a nonempty article, consent refusal/backup failure and successful sanitized copy; verify previous rights/facts/review approvals do not transfer. Required e2e+integration is not supplied by sanitizer source/unit existence or M02 mocked template boundaries.'],
 ['editor-template-html.test.ts exists but was not present in the specifically inspected1af selected raw report; no new test was run for this inventory.'],[anchor('apps/admin/lib/editor-template-html.test.ts','still removes executable attributes'),anchor('apps/admin/components/ArticleEditor.tsx','const applyTemplate ='),anchor('apps/admin/components/ArticleEditor.tsx','editor.commands.setContent(html)')]);
assert.equal(rows.length,21);assert.equal(new Set(rows.map(r=>r.id)).size,21);
const oldRefs=['.tmp/m07-t06-final-aggregate-v1-proof.json','.tmp/m07-t04-final-aggregate-v1-proof.json','.tmp/m07-t01-final-aggregate-v1-proof.json','.tmp/m07-t06-sql-binding-pair-v4-proof.json','.tmp/m07-t04-sql-active-stop-v1-proof.json','.tmp/m07-source-provenance-final-v2-aggregate-proof.json'].map(currentFile);
const report={checkedAt:new Date().toISOString(),classification:'PARENT_ONLY_READ_ONLY_ACCEPTANCE_GAP_INVENTORY_NOT_ACCEPTANCE_RESULTS',
 definitions:{UNMAPPED:'No specifically relevant criterion runtime evidence mapped in inspected receipts; code may exist.',PARTIAL:'Coverage/behavior/protocol parts remain unresolved; no whole-criterion acceptance.',LOCAL_PROOF:'Specifically relevant local tests/native SQL are mapped at their disclosed boundaries, not production/module acceptance.',LEVEL_DEFERRED:'Behavior has lower-level local proof, while an explicitly required DB/component/e2e scenario remains unmapped/unexecuted.'},
 baseline:{latestCanonicalValidatedFingerprint:'1af04f3230b3395637a3e06090c1b25c72c66735d4c185be36c626374e4df02e',currentSitecopy:'IN_PROGRESS; focused/UI packets are not yet a sealed full global replacement of1af',canonical:currentFile('docs/CODEX_ADMIN_EXECUTION_STATE.md')},
 requirementsSources:['docs/admin-r3-task-package/CORE_RULES.md','docs/admin-r3-task-package/modules/M07.md','docs/admin-r3-task-package/modules/M24.md'].map(currentFile),
 evidence,rows,legacyCanonicalRawReferences:oldRefs,
 inventoryCounts:Object.fromEntries(['UNMAPPED','PARTIAL','LOCAL_PROOF','LEVEL_DEFERRED'].map(s=>[s,rows.filter(r=>r.status===s).length])),
 crossCuttingRemaining:['Current sitecopy final native/SDK/global code seal and source binding.','Known editorial-failure repeat producer and real-placeholder producer remain PREPARED/NOT_EXECUTED.','Nonarticle explicit failed item/version operator route and genuine10=8+2 UI flow.','Global multi-request billing/concurrency policy remains separate from per-request caps.','M24 intentional-empty policy and personal/shared/unsafe template flows need direct proof before any implementation assumption.','Managed Auth/PostgREST/deployed delivery/full authenticated browser lifecycle stay distinct from controlled SDK/native PostgreSQL/SSR.'],
 limitations:['No tests, compiler, DB, app, provider or browser execution occurred for this inventory; only existing files/receipts/immutable archive JSON were read.',
 'No application/doc/status-template file was edited. Classification counts are inventory bookkeeping, not passed criteria or a percentage of230.',
 'Six referenced legacy.tmp artifacts are absent here. Their canonical history is not erased, but missing raw files are not fabricated or silently considered reopened; present sealed archive case reports are identified separately.',
 'No M02 original search/reconstruction was performed. Existing six M02 historical broad failures are outside this inventory.']};
fs.writeFileSync(path.join(__dirname,'m07-m24-gap-inventory.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({criteria:rows.length,statuses:report.inventoryCounts,sha256:sha(fs.readFileSync(path.join(__dirname,'m07-m24-gap-inventory.json'))),missingEvidence:Object.entries(evidence).filter(([,v])=>!v.exists).map(([k])=>k),legacyRawAbsent:oldRefs.filter(r=>!r.exists).length}));
