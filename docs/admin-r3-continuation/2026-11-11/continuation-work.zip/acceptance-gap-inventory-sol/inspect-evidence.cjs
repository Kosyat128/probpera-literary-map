const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const repo=path.resolve(__dirname,'../../probpera-literary-map'),{unzipSync}=require(path.join(repo,'node_modules/fflate'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const archives=['docs/admin-r3-evidence/2026-10-30-profile-stable-traversal/whole-validation-evidence.zip','docs/admin-r3-evidence/2026-10-29-profile-budgets/runtime-regression-evidence-typefix.zip','docs/admin-r3-evidence/2026-10-29-site-copy-review/runtime-evidence.zip'];
const results=[];
for(const file of archives){const bytes=fs.readFileSync(path.join(repo,file)),entries=unzipSync(bytes),jsons=[];
 for(const [name,body]of Object.entries(entries)){if(!name.endsWith('.json'))continue;let value;try{value=JSON.parse(Buffer.from(body).toString())}catch{continue}
  if(Array.isArray(value.testResults)){const matches=value.testResults.filter(row=>/self-test|translation-runtime-gate|article-batch|premium-translation-budget|machine-ownership|profile-library-batch-budget|site-copy|template/iu.test(row.name));jsons.push({path:name,sha256:sha(body),role:'actual-Vitest-raw-report',files:matches.map(row=>({file:row.name,pass:row.assertionResults.filter(t=>t.status==='passed').length,fail:row.assertionResults.filter(t=>t.status==='failed').length,pending:row.assertionResults.filter(t=>t.status==='pending').length,cases:row.assertionResults.map(t=>({name:t.fullName,status:t.status}))}))});}
  if(Array.isArray(value.checks)&&value.checks.some(row=>/manual|stop|budget|provider|source|concurrent|preserv|ordinary|save/iu.test(row.name||'')))jsons.push({path:name,sha256:sha(body),role:'specific-controlled-check-report',summary:value.summary||null,checks:value.checks.map(row=>({name:row.name,pass:row.pass,category:row.category}))});
 }
 results.push({file,sha256:sha(bytes),bytes:bytes.length,entries:Object.keys(entries).length,relevantJson:jsons});}
const out={checkedAt:new Date().toISOString(),classification:'READ_ONLY_EXISTING_ARCHIVE_RECEIPT_INSPECTION_NO_TEST_EXECUTION',archives:results};
fs.mkdirSync(__dirname,{recursive:true});fs.writeFileSync(path.join(__dirname,'evidence-inspection.json'),JSON.stringify(out,null,2));
console.log(JSON.stringify(results.map(r=>({file:r.file,sha256:r.sha256,entries:r.entries,jsons:r.relevantJson.map(j=>({path:j.path,role:j.role,files:j.files?.map(f=>({file:f.file,pass:f.pass,fail:f.fail})),checks:j.checks?.length}))})),null,2));
