import datetime,hashlib,json,pathlib,re
work=pathlib.Path(__file__).resolve().parent
repo=work.parent.parent/'probpera-literary-map'
canonical='docs/CODEX_ADMIN_EXECUTION_STATE.md'
modules=[f'M{x:02d}' for x in range(13,26) if x!=24]
def meta(file):
    p=repo/file
    if not p.is_file():return {'file':file,'exists':False}
    b=p.read_bytes();return {'file':file,'exists':True,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def anchor(file,needle,scope='CURRENT_SOURCE_ONLY_NOT_RUNTIME_PROOF'):
    lines=(repo/file).read_text(encoding='utf-8-sig').splitlines()
    hits=[i+1 for i,s in enumerate(lines) if needle in s]
    assert hits,(file,needle)
    return {'file':file,'line':hits[0],'needle':needle,'evidenceLevel':scope}
evidence={
 'CANON':{'file':canonical,'scope':'Current canonical describes exact historical and in-progress proof boundaries; no module acceptance inferred from old Phase checkboxes.'},
 'PSELECT':{'file':'../work/profile-stable-scan-final-validation-v4/selected-tests-summary.json','selection':'../work/profile-stable-scan-final-validation-v4/current-test-selection.txt','sourceAge':'Sealed 1af04f3230b3395637a3e06090c1b25c72c66735d4c185be36c626374e4df02e, prior to current site-copy working changes.','scope':'Small terminal summary and file-selection metadata inspected only; individual raw assertion results and current source identity were not re-extracted. Named current test source anchors identify relevant lower-level contracts, not an automatic criterion PASS.'},
 'SEO_CANON':{'file':canonical,'line':3598,'sourceAge':'Historical October7 62d7f4917c353bea7dab0efcfb83149da6a44db3f84eb14f9af363ae6c4a482c slice.','scope':'Actual isolated PG scalar UUID/one mutation/audit/outbox/duplicate proof plus actual action/publication replay with synthetic Auth/SDK. Five SQL markers and paired27 controls are explicitly scoped; no native update/delete/concurrent redirects or whole managed schema claimed. Historical raw .tmp paths are not present in this checkout.'},
 'PAGE_CANON':{'file':canonical,'line':3130,'sourceAge':'Historical 587aede Page durable operations slice, subsequently inherited by sealed1af and current code. No fresh browser/native run in this inventory.','scope':'Actual PageEditor/TipTap Chrome fixtures with synthetic actions/read/ledger, native Next with synthetic Auth/SDK/ledger, separate isolated PostgreSQL45 markers and strict DTO replay. These independent boundaries do not form authenticated managed admin E2E.'},
 'M02_READ_CANON':{'file':canonical,'line':2048,'sourceAge':'Historical M02 read-boundary implementation, inherited by sealed1af selection; not a new current full acceptance.','scope':'Actual SSR/loader/DTO/GET/CSV fail-closed slices are named in canonical. Loader correctness does not establish write transactions, browser interaction, privacy/RLS or every criterion in a module.'},
 'SITE_NATIVE':{'file':'../work/site-copy-admission-sql-native/final_v1/native-summary.json','sourceAge':'Current frozen site-copy SQL c3f3f2b5 / fixture12941fd9; exact final native-only ZIP0449763c is immutable, not opened or hashed by this inventory.','scope':'Owned selected-old-DDL PG17, synthetic Auth;12 real races/186 old routines preserved/8 table metadata unchanged/unknown retained/full-row guards. Final196 typed-wrapper and one retained-body parity are separately recorded in canonical. Not full project migration/managed Auth/browser acceptance.'},
 'CURRENT_SOURCE':{'scope':'Read-only bounded current source excerpts and named test declarations. Presence of code or a test is not execution, and missing mapping is not missing code.'},
 'NEWS_DOC':{'file':'docs/literary-news-native-preparation.md','scope':'Existing architecture/verification-limit documentation only: fake AI/storage local scope, disabled defaults, durable owner/fence. Not deployment, provider or calendar/DB criterion acceptance.'}
}
rows=[]
for module in modules:
    file=f'docs/admin-r3-task-package/modules/{module}.md'
    for line,s in enumerate((repo/file).read_text(encoding='utf-8').splitlines(),1):
        if not re.match(r'\| '+module+r'-T\d+ \|',s):continue
        cols=re.split(r'(?<!\\)\|',s)[1:-1]
        row={'id':cols[0].strip(),'requirement':cols[1].strip().replace('\\|','|'),'expected':cols[2].strip().replace('\\|','|'),'requiredLevel':cols[3].strip(),
         'status':'UNMAPPED','strongestRelevantProof':[],
         'remainingFunctionality':['No missing implementation is inferred from unmapped evidence. Inspect the named current path against this exact scenario before choosing any change.'],
         'remainingProof':['Map exact assertion/command/source-bound evidence at every required level; PLANNED/initial NOT_RUN and aggregate counts are not current acceptance.'],
         'notes':['No tests, compiler, DB/server, browser or external/provider action was run for this inventory.'],
         'anchors':[{'file':file,'line':line,'scope':'REQUIREMENT'}]}
        rows.append(row)
by={r['id']:r for r in rows}
def setrow(id,status,proof,func,proofgap,anchors=(),notes=()):
    r=by[id];r.update(status=status,strongestRelevantProof=[{'ref':ref,'detail':detail} for ref,detail in proof],remainingFunctionality=[func],remainingProof=[proofgap])
    r['anchors'].extend(anchor(*a) for a in anchors);r['notes'].extend(notes)
seo='apps/admin/app/(dashboard)/seo/page.tsx';sa='apps/admin/app/(dashboard)/seo/actions.ts';sqlguards='supabase/migrations/20260901_zzz_admin_mutation_guards.sql'
setrow('M13-T01','PARTIAL',[('CURRENT_SOURCE','SEO page still builds missing-field issues from raw canonical_url, independently of renderer fallback.')],
 'Confirmed source discrepancy: raw canonical_url absence is reported as canonical missing. Reuse the actual public resolver for computed canonical rather than changing author fields.',
 'Capture an actual fallback fixture through report/renderer and recheck correct issue classification at unit+integration levels.',[(seo,'if (!article.canonical_url)')])
setrow('M13-T02','PARTIAL',[('M02_READ_CANON','SEO reads/count failures and independent result retention are locally covered; completeness is not.'),('CURRENT_SOURCE','Issues query still limits the raw preview to12 rows.')],
 'Confirmed source discrepancy: the issues display remains a bounded12-row preview, without a mapped complete versioned issue report/filter/page workflow.',
 'Browser scenario with >12 multilingual issues must reach every issue and correct editor target; prove report-version identity.',[(seo,'.limit(12)')])
setrow('M13-T03','UNMAPPED',[('CURRENT_SOURCE','Existing release audit script is a separate entry point; admin raw-field issue preview is not a versioned HTML audit.')],
 'Map/reuse release/snapshot identity in an existing bounded audit result and distinguish stale reports; no new synchronous Worker scan is implied.',
 'Integration fault: mutate release after green audit and verify old report cannot close new-version issues.', [('scripts/audit-seo-release.mjs','import')])
setrow('M13-T04','LEVEL_DEFERRED',[('SEO_CANON','Actual guarded redirect create/duplicate behavior and scalar result were tested; general cycles/Tilda/destination matrix was not.'),('CURRENT_SOURCE','Existing redirect RPCs use shared advisory locks and validators.')],
 'Preserve existing SQL guards; first determine exact equivalence/legacy-route gaps rather than replacing the redirect mechanism.',
 'Unit+browser matrix for cycle/self/Tilda route/destination conflict and author-content preservation remains unmapped.',[(sqlguards,'create or replace function public.create_seo_redirect_guarded')])
setrow('M13-T05','UNMAPPED',[('CURRENT_SOURCE','Release audit exists; safe arbitrary-address checker behavior is not mapped by this inspection.')],
 'Locate the actual network boundary and its allowlist/redirect/timeout policy before any change; absence of mapped evidence does not establish an SSRF bug.',
 'Integration check for protocol/redirect-loop/internal-address denial with synthetic endpoints and bounded responses.', [('scripts/audit-seo-release.mjs','import')])
setrow('M13-T06','LOCAL_PROOF',[('SEO_CANON','Actual PostgreSQL scalar UUID passed once through real action/publication with native-value replay; canonical insert/audit/outbox share the same ID.')],
 'No unresolved scalar UUID defect established; keep the narrow actual-function response adapter and old transactional guards.',
 'Rebind exact current action/publication/SQL sources to historical proof and final selected run; full managed Auth/PostgREST chain remains unverified.',[(sa,'createRedirectAction'),('apps/admin/app/(dashboard)/seo/seo-redirect-actions.integration.test.ts','binds the cached actual PostgreSQL scalar')])
setrow('M13-T07','LOCAL_PROOF',[('SEO_CANON','Paired27 rejects null/empty/object/array/nonUUID/wrong update/delete UUID before explicit aftermath; valid scalar accepted.')],
 'No missing result-form behavior established in these actual SEO actions. Preserve per-function parsing rather than universal data.id fallback.',
 'Source-bound current case statuses and lawful response-shape matrix must be tied to final working fingerprint; no new native UPDATE/DELETE claim.',[(sa,'createRedirectAction'),('apps/admin/app/(dashboard)/seo/seo-redirect-actions.integration.test.ts','describe(')])
setrow('M13-T08','UNMAPPED',[('CURRENT_SOURCE','Actual guarded functions exist; canonical notes explicitly leave equivalence and native update/delete matrix open.')],
 'Verify same-origin absolute/root-relative/trailing-slash equivalence using the public route resolver while preserving lawful external destinations.',
 'Required DB+integration equivalence/legacy-route fixture is not mapped.',[(sqlguards,'create or replace function public.create_seo_redirect_guarded')])
setrow('M13-T09','UNMAPPED',[('CURRENT_SOURCE','Existing redirect functions share advisory lock188654771/3 and transactional audit.')],
 'No missing lock inferred. Preserve the actual guarded RPC and test effective schema instead of weakening it.',
 'Two concurrent conflicting redirect transactions plus injected audit failure/rollback have no mapped real DB proof.',[(sqlguards,'pg_advisory_xact_lock(188654771, 3)')])
analytics='apps/admin/app/(dashboard)/analytics/analytics-load-errors.integration.test.ts'
for n in [1,5]:
 setrow(f'M14-T{n:02d}','PARTIAL',[('PSELECT','analytics-report unit and actual SSR/CSV suite are selected in sealed1af; exact current criterion assertions were not extracted.'),('CURRENT_SOURCE','UTC allowed-range, normalized DTO, formula-safe quoted CSV and accepted PG timestamp-offset cases exist.')],
  'Existing period/CSV implementation should be reused. Full timezone/day-boundary KPI/chart/CSV/external-link parity and complex export matrix are not yet established.',
  'Run exact boundary fixtures through actual report and CSV; verify no private fields, quotes/newlines/formula prefixes/RU-EN values and shared range.',[(analytics,'retains confirmed report values'),('apps/admin/lib/analytics-report.test.ts','uses an allowlisted UTC range')])
setrow('M14-T02','LOCAL_PROOF',[('M02_READ_CANON','Actual SSR and CSV distinguish unavailable/permission/invalid DTO from confirmed0/[]; independent geography remains available.'),('PSELECT','Actual analytics read suite is in sealed1af selection.')],
 'No new empty-vs-error defect found in inspected loader. Preserve explicit absence and error states.',
 'Rebind named SSR state tests to final current source; real user component/browser accessibility is distinct from this lower-level read proof.',[(analytics,'retains confirmed zeros and empty lists'),(analytics,'contains transport rejection')])
setrow('M14-T03','UNMAPPED',[('CURRENT_SOURCE','Analytics read/CSV code exists, but minimal event producer/secret-field redaction scenario was not mapped.')],
 'Inventory existing allowed event producers and schema before adding events; no new tracker or sensitive payload capture is authorized by the label.',
 'Unit+integration allowed-action vs sensitive URL/query/body fixture must prove event minimization.', [('apps/admin/lib/analytics-report.ts','export')])
setrow('M14-T04','LEVEL_DEFERRED',[('M02_READ_CANON','CSV rejects permission/unavailable responses with403/503 and private no-store; formula protection retained.'),('CURRENT_SOURCE','GET delegates authorization to get_admin_analytics_report; no direct data dump.')],
 'Preserve DB permission authority and formula escaping; no new bypass demonstrated.',
 'Actual guest-vs-staff effective-DB permission and exact formula-prefixed response test must be mapped; mock403 is not RLS proof.', [('apps/admin/app/(dashboard)/analytics/export/route.ts','get_admin_analytics_report')])
comments='apps/admin/app/(dashboard)/comments/page.tsx'; ca='apps/admin/app/(dashboard)/comments/actions.ts';owner='supabase/migrations/20260901_zz_staff_owner_invariant.sql'
setrow('M15-T01','PARTIAL',[('CURRENT_SOURCE','Individual action supports published, but visible row control still maps every nonhidden status to hidden.')],
 'Confirmed source discrepancy: pending comment receives Hide instead of explicit Approve; add intended action without editing reader text or widening permissions.',
 'Required actual DB+browser pending→published flow and clear status remains unmapped.',[(comments,'comment.status === "hidden" ? "published" : "hidden"')])
setrow('M15-T02','PARTIAL',[('CURRENT_SOURCE','Bounded100 selected IDs/versions reach one guarded moderation RPC with conflict handling.')],
 'Current caller provides one aggregate conflict/error and success count, not a mapped per-item conflict outcome; first reconcile desired transactional behavior with actual RPC.',
 'DB+browser selected-version race must show honest success/conflict result and preserve unselected rows.',[(ca,'moderate_comments_guarded'),(ca,'items.length > 100')])
for n in [3,5]:
 setrow(f'M15-T{n:02d}','UNMAPPED',[('CURRENT_SOURCE','Both owner-changing functions serialize via one advisory transaction lock and check the remaining owner count.')],
  'Do not invent a missing owner guard: it already exists. No new functionality defect inferred from the label.',
  'Real two-session deletion/demotion race on effective schema with2last owners is not mapped; include permissions, audit and meaningful conflict.',[(owner,'Serialize every owner-changing operation')])
setrow('M15-T04','LEVEL_DEFERRED',[('M02_READ_CANON','Team SSR keeps MFA/session/readiness independent; owner forms close for nonowner and data outage.'),('CURRENT_SOURCE','Current tests explicitly keep admin/editor/null outside owner forms; actual DB DTO authorization not tested here.')],
 'Preserve minimal server DTO/roles; verify reader/guest reads rather than assuming a hidden form enforces privacy.',
 'Actual DB+integration team DTO owner/admin/reader/guest matrix and auth.users minimization remains unmapped.', [('apps/admin/app/(dashboard)/settings/settings-load-errors.integration.test.ts','outside owner access forms')])
studio='supabase/migrations/20260901_zz_site_studio_engine.sql'
setrow('M16-T01','UNMAPPED',[('CURRENT_SOURCE','Existing token/change-set/release model and typed contracts are present, not a new constructor.')],
 'Map field ownership across homepage/sitecopy/studio/banners/menus; no duplicate-master defect established by this inspection.',
 'Integration+browser same-field edit across available editors with one master/version and recoverable conflict is not mapped.',[('apps/admin/lib/site-studio-contract.ts','export')])
setrow('M16-T02','LEVEL_DEFERRED',[('CURRENT_SOURCE','Actual release RPC has a shared lock and revision-group validation; read-side outage/restore guards have local SSR coverage.')],
 'Reuse the existing change set/publish/rollback model; do not infer that half-release behavior exists merely because native fault proof is absent.',
 'Real DB atomic fault/group rollback +browser preview consistency matrix remains unmapped.',[(studio,'Every public design release shares')])
setrow('M16-T03','UNMAPPED',[('CURRENT_SOURCE','Existing owner_lock checks and public preservation policy remain; general build/readonly gates are not scene regression proof.')],
 'No scene redesign required. Preserve globe/bookshelf geometry/behavior/authored text and system component restrictions.',
 'Exact public snapshot+public-e2e fixtures for studio changes on bookshelf/globe remain unmapped.',[(studio,'component is owner locked')])
setrow('M16-T04','UNMAPPED',[('CURRENT_SOURCE','Actual rollback RPC explicitly permits only the latest release and compares current published values; action sends releaseId by design.')],
 'No missing rollback-CAS defect established: server latest-release/current-value authority already exists. Preserve it.',
 'Actual DB+integration A→B→stale rollbackA and intervening token changes must be executed/mapped; source text alone is insufficient.',[(studio,'only the latest site design release can be rolled back')])
setrow('M17-T01','PARTIAL',[('PSELECT','Health-status test is selected in sealed1af. Private admin catalog-assets test exists but is NOT in this inspected selection; no executed result inferred for it.'),('M02_READ_CANON','Missing/invalid required catalogs close expensive actions; unknown readiness is not green.')],
 'Preserve verified catalog identity and distinguish admin/public/schema/content versions. Full staged manifest/pointer/eventual-consistency gap not inferred.',
 'Map exact stale manifest/missing blob/checksum-mismatch integration cases across all catalog versions; no total-suite substitution.', [('apps/admin/lib/admin-catalog-assets.test.ts','reads bounded catalog values')])
setrow('M17-T02','LOCAL_PROOF',[('M02_READ_CANON','Health keeps backup and restore_drill markers as separate values, and unavailable reads are UNKNOWN.'),('CURRENT_SOURCE','The page derives separate backupHealth and restoreHealth; a backup marker alone does not select restore success.')],
 'No backup-equals-restore UI conflation found in inspected path; actual marker provenance must still remain honest.',
 'Rebind exact missing/failed restore marker fixture to current unit+integration evidence and verify deployed job provenance separately.', [('apps/admin/app/(dashboard)/health/page.tsx','const restoreHealth')])
setrow('M17-T03','UNMAPPED',[('SITE_NATIVE','Finite10000 SQL traversal and bounded local timings exist, but they are not the project-wide warm/cold UI benchmark.')],
 'Use fixed10k plus long-document baseline before optimizing; no blanket limit increase or benchmark percentile from a few runs.',
 'Required same-environment baseline/final with≥20warm repeats, separate cold, query/bytes/worker/open/type/search metrics and strict budgets is not mapped.', [('docs/admin-r3-task-package/modules/M17.md','не менее 20 повторов','REQUIREMENT')])
setrow('M17-T04','UNMAPPED',[('CURRENT_SOURCE','Existing Storage backup/verification scripts and unit fixtures are available; no actual isolated full restore drill read here.')],
 'Reuse existing manifest/verification workflow and report a missing Storage reference as incomplete, not full recovery.',
 'Integration restore with successful metadata but deliberately absent expected object must retain concrete missing coverage.', [('scripts/verify-supabase-storage-backup.test.mjs','import')])
setrow('M17-T05','PARTIAL',[('SITE_NATIVE','Current private paid caches/active unknown operations retain immutable bodies; native delete/forgery guards preserve records.'),('CURRENT_SOURCE','General purge rules target client_errors/content_views, not paid receipt tables.')],
 'No current blanket paid-receipt age purge found in inspected purge script. Inventory other cleanup paths before declaring all active operations safe.',
 'Required DB+integration cleanup of expired terminal alongside pending/unknown receipts across all applicable operation types remains unmapped.', [('scripts/purge-operational-data.mjs','operationalRetentionRules')])
setrow('M18-T01','PARTIAL',[('SITE_NATIVE','Current additive migration actually ran after selected unchanged prior DDL; all186old routines/8target table metadata/53relations/19roles exact.')],
 'Preserve existing applied migrations and additive compatibility. Selected native foundation is not a full clean-project/ledger/upgrade acceptance.',
 'Full effective clean schema and previous-schema upgrade including actual ledger, extension/roles/Auth, required invariants and source SHA must be mapped.', [('supabase/migrations/20261030094705_site_copy_translation_operation_admission.sql','begin;')])
setrow('M18-T02','LEVEL_DEFERRED',[('SITE_NATIVE','Readiness refuses missing freshness capability; owner metadata remains available. Current UI/controlled suites exercise nonexpense recovery before expense gates.')],
 'No fail-open capability issue found in these paid paths; preserve safe metadata recovery while closing new expense.',
 'Required actual admin browser against intentionally old schema plus integration source matrix remains unmapped.', [('apps/admin/lib/site-copy-translation-operation-rpc.ts','siteCopyTranslationOperationReady')])
setrow('M18-T03','LEVEL_DEFERRED',[('CANON','Sealed1af build/TypeScript/Cloudflare/client-secret/readonly gates PASS; protected text/component scopes are independently bound.')],
 'No content/URL/scene change inferred from current sitecopy slice; build gates alone do not prove public routes or draft nonleakage.',
 'Safe snapshot build plus actual public-e2e routes/bookshelf/globe/draft absence remains unmapped at whole-project scope.', [('docs/admin-r3-task-package/modules/M18.md','M18-T03','REQUIREMENT')])
setrow('M18-T04','LOCAL_PROOF',[('CANON','Canonical explicitly retains initial72whole failures, setup fixes, currentV2 pending, historical6failures and productionNOT_RUN; native/controlled archives retain original failures.')],
 'No dishonest acceptance conversion found in current checkpoint. Final reporting still needs a criterion-complete matrix and completed currentV2/gates.',
 'After terminal currentV2, bind actual commands/exit/source/evidence/access scope; never use this inventory or initialNOT_RUN as acceptance.', [(canonical,'Current work status:','CURRENT_REPORT_METADATA')])
setrow('M18-T05','PARTIAL',[('SITE_NATIVE','Old functions/schema metadata preserved; actual old book/country paid flows pass after new guards, new readiness closes a missing new capability.')],
 'These narrow old-code/new-schema and missing-capability behaviors exist; no whole compatibility matrix implemented/proven by that alone.',
 'Full old-code+new-schema/new-code+old-schema+feature-off/backout matrix across affected modules and ledger remains open.', [('scripts/database/fixtures/site-copy-translation-operation-admission.sql','M07_SITE_COPY_ADMISSION_OLD_DOMAINS_UNCHANGED_PASS')])
setrow('M18-T06','UNMAPPED',[('CURRENT_SOURCE','Current owned native/race harness checks loopback/unique database/workspace and stopped itself before connecting on a path mismatch.')],
 'No new safety wrapper implied; inspect all actual test entry points, provider mocks and secret auth-state paths.',
 'Explicit negative production-host/real-auth-state/unmocked-provider attempts must stop before any write; missing dependencies must be NOT_RUN, notPASS.', [('docs/admin-r3-task-package/modules/M18.md','M18-T06','REQUIREMENT')])
pages='apps/admin/app/(dashboard)/pages/actions.ts';pl='apps/admin/lib/page-load-validation.ts'; preview='apps/admin/app/(dashboard)/pages/[id]/preview/page.tsx'
setrow('M19-T01','PARTIAL',[('CURRENT_SOURCE','createPageAction writes sanitized nonempty HTML with empty TipTap JSON; loader now refuses emptyJSON over nonemptyHTML rather than opening an empty editable document.')],
 'Confirmed source discrepancy remains: create consistent safe JSON and HTML from actual plain-text input before first insert, using existing TipTap contract.',
 'DB+browser create/reopen with paragraphs must preserve exact supported semantics; fail-closed refusal is not successful roundtrip.',[(pages,'content_json: { type: "doc", content: [] }'),(pl,'or open it over nonempty HTML')])
setrow('M19-T02','PARTIAL',[('M02_READ_CANON','Legacy emptyJSON/nonemptyHTML refuses unsafe editor; read/preview source bytes preserved.')],
 'Safe compatibility/explicit conversion preview and original-snapshot semantic diff remain unmapped; refusing form alone is not the required usable legacy workflow.',
 'Actual component+browser legacy view/conversion with zero write on open remains open.',[(pl,'or open it over nonempty HTML')])
setrow('M19-T03','UNMAPPED',[('CURRENT_SOURCE','Actual TipTap shape validation exists, but no inspected semantic HTML-vs-JSON conflict resolver is mapped.')],
 'Distinguish two valid divergent representations explicitly and preserve both; do not choose by truthiness, length or client time.',
 'Unit+integration divergence fixture with no silent canonical write remains unmapped.', [('apps/admin/components/PageEditor.tsx','content: page.content_json || page.content_html')])
setrow('M19-T04','LEVEL_DEFERRED',[('M02_READ_CANON','Actual shared TipTap schema validates nodes/marks/attrs and closes malformed editor without replacing data.')],
 'No malformed-document overwrite defect established in loader; preserve current fail-closed checks.',
 'Actual component+admin-browser unsupported/corrupt JSON with knownHTML error state and no save must be mapped.',[(pl,'canEditPageContent')])
setrow('M19-T05','PARTIAL',[('CURRENT_SOURCE','Plain create input is interpolated into paragraph HTML then sanitized, rather than escaped before interpreting tags.')],
 'Source-confirmed unsafe content-contract discrepancy: literal angle-bracket/tag examples can be interpreted/removed as markup. Use existing safe plain-text→document contract; no new typographic transform.',
 'Unit+browser plain tag/angle-bracket/script-like synthetic text roundtrip before any rewrite; no production-loss claim.',[(pages,'.map((paragraph) => `<p>${paragraph}</p>`)')])
setrow('M19-T06','PARTIAL',[('PAGE_CANON','Durable Page operation receipts/replay/CAS exist; that ledger is not a separate public-vs-private working revision.'),('CURRENT_SOURCE','Save still writes content/status directly to pages through canonical operation RPC or legacy UPDATE.')],
 'Current inspected path does not isolate working edits from canonical published Page content. Reuse/minimally extend existing draft model; never hide published page by changing it to draft.',
 'Actual DB+browser publicA→privateB→previewB without public mutation/export remains unverified.',[(pages,'supabase.from("pages").update(payload)')])
setrow('M19-T07','LEVEL_DEFERRED',[('PAGE_CANON','Actual Page operation duplicate/unknown/CAS and two-version retention have isolated DB and real-component browser proofs with disclosed synthetic boundaries.')],
 'Preserve original operation receipt, source versions and history CAS; no blind overwrite defect established in that scoped operation path.',
 'Required full DB+admin-browser two-tabs plus actual revision restore with shared document contract remains unmapped.', [('apps/admin/app/(dashboard)/pages/page-operation-server.integration.test.ts','describe(')])
setrow('M19-T08','LEVEL_DEFERRED',[('PAGE_CANON','Page editor tracks canonicalEdited and preserves author snapshots; general durable browser core is proven locally.')],
 'Verify current title-only edit leaves specific canonical/slug unchanged; no new URL normalization or rewrite is implied.',
 'Exact DB+browser special-canonical/title-only fixture with no explicitURL intent needs current source-bound proof.', [('apps/admin/components/PageEditor.tsx','Boolean(page.canonical_url && page.canonical_url !== generatedCanonical)')])
setrow('M19-T09','PARTIAL',[('M02_READ_CANON','Preview errors no longer become false404 and identity/readDTO are checked.'),('CURRENT_SOURCE','Preview query still selects canonical pages.content_html and renders it directly.')],
 'Confirmed source gap: draft-selected preview has not been connected because separate Page working draft contract remains open; do not silently substitute canonicalA for requestedB.',
 'Integration+admin-e2e selectedB/publicA and independent draft/main read failure matrix remains open.',[(preview,'.select("id,title,excerpt,content_html,updated_at,status")')])
setrow('M19-T10','UNMAPPED',[('CURRENT_SOURCE','Preview currently inserts stored HTML; source sanitation/validation upstream and CSP must be considered together.')],
 'No active-content exploit inferred by source view alone. Use the actual supported shared safe projection without broad rewrites.',
 'Security-browser+integration ordinary structures/unsafe fragment across Page+Article preview and actual CSP must be executed.',[(preview,'dangerouslySetInnerHTML')])
recovery='apps/admin/components/editor/RecoveryController.tsx'
for n,detail in [(1,'Page durable receipt controls do not clear dirty before confirmed response.'),(2,'A receipt cannot clear lateB; actual component Chrome and native Next synthetic-boundary cases preserve later edits.'),(3,'Page route ignores savedURL as cleanup permission; stronger original39 contract leaves9historical failures distinct from new39 proof.'),(6,'Actual component storage-error/foreignLOCAL+ownSESSION cases retain input; ephemeral metadata adapter preserves known receipts when writes fail.'),(8,'Locator/operation version guards and actual Page late-response fixtures exist, with separate synthetic route21 proof.')]:
 setrow(f'M20-T{n:02d}','LEVEL_DEFERRED',[('PAGE_CANON',detail)],
  'Preserve the existing receipt/late-edit/owned-copy behavior. No whole new defect inferred from missing full-stack E2E.',
  'Rebind exact scenario to current source and actual admin-browser+required DB boundary; independent Chrome/mock-ledger/SQL proofs are not one authenticated end-to-end chain.', [('apps/admin/components/PageEditor.tsx','export default'),(recovery,'lastSavedSnapshotRef')])
setrow('M20-T04','PARTIAL',[('CURRENT_SOURCE','Exact server delete already filters actor/id/session/sequence/snapshotHash; explicit discard is separate from canonical confirmation.')],
 'Preserve exact-delete authorization and user intent. Map actual deleted:false handling without deleting broader or newer copies.',
 'DB+integration explicit selected snapshot delete, then mismatched sequence/hash/newer/foreign copy denial remains unmapped.',[('apps/admin/app/(dashboard)/editor-autosave/actions.ts','deleteExactEditorAutosaveAction')])
setrow('M20-T05','LEVEL_DEFERRED',[('CURRENT_SOURCE','Current actual controller explicitly labels local only when onLocalFallback returns true; absent/false/throw yields error.'),('PAGE_CANON','Storage/component recovery regressions were locally exercised with synthetic server boundary, but this exact RecoveryController branch result is not mapped.')],
 'No absent-fallback false-success defect remains in inspected code; preserve strict positive confirmation.',
 'Map current actual component result for absent/undefined/false/throw and retain input/known server commit.',[(recovery,'setStatus(localResult === true ? "local" : "error")')])
setrow('M20-T07','PARTIAL',[('CURRENT_SOURCE','loadLatest .then still returns immediately for !result.ok without setting error, unlike catch.')],
 'Confirmed current source discrepancy: distinguish failed lookup from no-copy success and preserve readable error/unknown status.',
 'Produce parent-only actual component BEFORE on resolved{ok:false}, then eventual authorized fix/after; no runtime failure captured by this inventory.',[(recovery,'if (cancelled || !result.ok || !result.recovery) return;')])
setrow('M20-T09','PARTIAL',[('CURRENT_SOURCE','Actor-scoped primary storage and foreign-owner refusal have exact unit cases; legacy unscoped copy remains explicitly unknown-owner.'),('PAGE_CANON','Canonical expressly leaves privacy of legacy unscoped copies unverified.')],
 'Do not infer legacy ownership from URL/time or show it to next account. Controlled owner recovery and normal signed-in path must follow actual account-scoping policy.',
 'Actual A→logout→B same-device admin-browser and legacy fallback policy remains required; marked-owner unit tests alone do not close it.',[('apps/admin/lib/editor-recovery-owner.test.ts','keeps A and B author copies independently')])
setrow('M20-T10','PARTIAL',[('CURRENT_SOURCE','Server action returns{ok:true,deleted:false}; automatic controller cleanup tests only result.ok before clearing metadata/recovery.')],
 'Confirmed current source discrepancy: deleted:false is not proof of removal; retain recovery/unknown and retry only exact selected snapshot.',
 'DB+integration resolveddeleted:false and network failure with unchanged/newer copies, plus actual component status proof, remain open.',[(recovery,'if (cancelled || !result.ok) return;'),('apps/admin/app/(dashboard)/editor-autosave/actions.ts','deleted: Boolean(data?.id)')])
taxonomy='apps/admin/app/(dashboard)/categories/actions.ts'
setrow('M21-T01','UNMAPPED',[('CURRENT_SOURCE','Current taxonomy update has explicit slug/name and CAS; rename-only intent needs exact existing slug carried unchanged.')],
 'No rename-alone URL defect established. Test current action with unchangedslug before modifying it.',
 'DB+browser rename-only sameID/slug/assignments/historicalURLs remains unmapped.',[(taxonomy,'export async function')])
for n in [2,3,4,5,7]:
 setrow(f'M21-T{n:02d}','PARTIAL',[('M02_READ_CANON','Taxonomy read/count dependencies fail closed; that does not prove mutation impact plans.'),('CURRENT_SOURCE','Current inspected action updates/deletes categories/tags directly and performs separate aftermath; no inspected merge/impact-plan entry point.')],
  'Map existing effective constraints/routes first, then add only the missing exact impact-plan/recheck/merge or protectedURL behavior. DirectCAS and FKSETNULL/CASCADE alone do not fulfill the editorial requirement.',
  'Criterion-specific real DB+integration/browser matrix (assignedRU/EN, aliases/reservedpaths, newdependency afterpreview, tagdedup/content/history preservation) is not mapped.',[(taxonomy,'export async function deleteTaxonomyItemAction')])
setrow('M21-T06','PARTIAL',[('CURRENT_SOURCE','auditAndRequestBuild awaits a separate admin_audit_log insert but does not inspect its returned error; canonical mutation occurs separately.')],
 'Confirmed inspected action cannot make a required post-write audit atomically roll back the prior mutation. Determine actual obligatory audit contract/trigger first; preserve existing outbox/revisions.',
 'Real DB injected mandatory audit failure must prove transaction rollback under the effective schema; source-only tests are not enough.',[(taxonomy,'await supabase.from("admin_audit_log").insert')])
menus='apps/admin/app/(dashboard)/menus/actions.ts';banners='apps/admin/app/(dashboard)/banners/actions.ts'
for n in [1,2,3]:
 setrow(f'M22-T{n:02d}','UNMAPPED',[('CURRENT_SOURCE','Action has self-parent check and directCAS writes; loader deliberately keeps historically readable deep/cyclic/cross-menu rows. No final effective DB tree-invariant proof mapped.')],
  'Inspect all actual tree write/restore/RPC guards before choosing a fix. Do not use safe public forest rendering as write authority; exact subtree intent/versions must be protected.',
  'Real DB cycle/cross-menu/concurrentA↔B/delete-stale-tree matrix at required levels remains unmapped.',[(menus,'parsed.data.parentId === parsed.data.id')])
setrow('M22-T04','UNMAPPED',[('CURRENT_SOURCE','Existing menu editor/list and public forest remain; no mouse/keyboard stable subtree reorder evidence mapped.')],
 'Verify existing ordering and supported input before adding UI; preserve stable IDs and subtree ownership.',
 'Browser equal-displayOrder mouse/keyboard equivalence+refresh remains unmapped.',[('apps/admin/app/(dashboard)/menus/page.tsx','export default')])
for n,needle,detail in [(5,'.filter((item) => item.startsWith("/"))','invalid nonempty lines are silently dropped before validation'),(6,'.slice(0, 50)','51valid lines are sliced before max50 validation')]:
 setrow(f'M22-T{n:02d}','PARTIAL',[('CURRENT_SOURCE','Current pagePatterns preprocessing '+detail+'.')],
  'Confirmed source discrepancy: validate every original line and overflow without mutating the original form or silently replacing scope.',
  'Same-input unit+browser invalid/mixed/51-valid fixture must preserve prior settings and user form. This inventory did not execute a BEFORE.',[(banners,needle)])
setrow('M22-T07','UNMAPPED',[('CURRENT_SOURCE','Public cmsPagePatternMatches is an existing contract; admin exact preview parity was not inspected.')],
 'Reuse renderer path/locale/percent-encoding grammar; no arbitrary regex or broader prefix matching.',
 'Exact /stati/* neighborprefix,/en,slash,encoding unit+integration shared-result matrix remains unmapped.',[('docs/admin-r3-task-package/modules/M22.md','cmsPagePatternMatches','REQUIREMENT')])
setrow('M22-T08','PARTIAL',[('CURRENT_SOURCE','Banner action validates starts/ends as strings and passes them onward; no explicit inspected IANA/DST/ordered-interval parser.')],
 'Verify real DB time constraints and existing public window first, then apply shared M04 time contract without shifting stored instants.',
 'Unit+actualDB+browser invalid/equal/reversed/start==now/end==now/DST/zone parity remains unmapped.',[(banners,'startsAt: z.string().trim().max(40)')])
setrow('M22-T09','LEVEL_DEFERRED',[('M02_READ_CANON','Banners/homepage loader validates required media bundles and conflicting identities, preserving current visual data.')],
 'No art-direction or replacement-image change needed. Existing safe loader is not responsive fallback acceptance.',
 'Actual desktop/tablet/mobile and missingvariant browser preview against renderer fallback/focus remains unmapped.', [('apps/admin/lib/homepage-banner-load-errors.integration.test.ts','describe(')])
upload='apps/admin/app/api/media/upload/route.ts';font='apps/admin/app/api/site-fonts/upload/route.ts';mw='apps/admin/middleware.ts'
for n in [1,2]:
 setrow(f'M23-T{n:02d}','PARTIAL',[('CURRENT_SOURCE','Both uploads are cookie/staff-gated. No explicit Origin check found in inspected routes/auth/middleware; Next ServerAction guarantees are not evidence for RouteHandlers.')],
  'Map actual proxy/cookie/CSRF deployment contract before a change. Source observation alone does not establish production exploitability; preserve allowed / and /admin flows.',
  'Actual RouteHandler allowed/foreign/sibling/null/missing/forged-forwarded-host integration and required browser matrix remains unmapped.',[(upload,'export async function POST'),(font,'export async function POST'),(mw,'export async function middleware')])
setrow('M23-T03','PARTIAL',[('CURRENT_SOURCE','Media POST calls request.formData before file-size checks and outside its later maintry; font catches malformed formData but still parses before size.')],
 'Confirmed source parser-order discrepancy; determine actual Cloudflare/OpenNext hard limit/stream contract before implementing any custom parser.',
 'Runtime integration oversized/malformed/noContentLength/fieldcount/multipart-overhead proof at actual adapter remains unmapped.',[(upload,'const formData = await request.formData();'),(font,'formData = await request.formData();')])
setrow('M23-T04','UNMAPPED',[('CURRENT_SOURCE','Existing route imports actual raster sniffing and max dimension/pixel contracts. Actual-route unit suite exists but is NOT in the specifically inspected1af file selection; no execution inferred.')],
 'Preserve actual container/pixel/SHA/forbidden-format guards; no request to add antivirus/decompression or alter image policy.',
 'Map exact forgedMIME/clientdimensions/container/forbiddenformat actual-route results to current unit+integration source; current inventory does not rerun them.',[(upload,'inspectRasterImage'),('apps/admin/app/api/media/upload/route.test.ts','describe(')])
for n in [5,6]:
 setrow(f'M23-T{n:02d}','PARTIAL',[('CURRENT_SOURCE','Media upload then DBinsert has compensating remove(objectPath) on registration failure, but no inspected durable request operation/reconcile journal.')],
  'Inspect existing media lifecycle/cleanup first and minimally reuse it for requestidentity/uploaded/registered/unknown states; do not introduce a new parallel pipeline.',
  'Actual controlled crash afterStorage vs commit-response-loss retry with sameidentity, ownorphan verification and no registered-object deletion/duplicate remains unmapped.',[(upload,'remove([objectPath])')])
setrow('M23-T07','LEVEL_DEFERRED',[('CURRENT_SOURCE','Font route intentionally retains content-addressed shared objects after registration failure for staged lifecycle cleanup.')],
 'Do not add immediate shared-font deletion as compensation. Existing retention protects possible concurrent references.',
 'Real DB+integration2same-bytes requests, one success/oneconflict and working shared reference remains unmapped.',[(font,'hash; unreferenced objects are handled')])
setrow('M23-T08','UNMAPPED',[('CURRENT_SOURCE','Existing media lifecycle migration/purge workflow is available; actual race with a newly created reference not mapped.')],
 'Preserve graceperiod and recheckreferences/ownership immediately before deletion; no broad cleanup authorization follows from inventory.',
 'Real DB+integration previeworphan→newreference→purge denial and honest receipt remains unmapped.', [('supabase/migrations/20260830_media_studio_lifecycle.sql','create')])
setrow('M23-T09','UNMAPPED',[('M02_READ_CANON','Read-side media uses existing publicURL and does not fetch file bytes; draft status does not imply privateStorage.')],
 'Inventory actualbucket policies/signed preview support. Do not change old publicbucket globally or promise unsupported confidentiality.',
 'Actual authorized/unauthorized privatepreview and publicURL access integration is not mapped; no live URL fetch performed here.',[(upload,'editorial-media')])
setrow('M23-T10','UNMAPPED',[('CURRENT_SOURCE','Existing client image-upload helpers are available;20-file mixed-result receipt/retry scenario not mapped.')],
 'Determine current multi-file behavior and stable per-file identities before adding callbacks/UI; successfulfiles must not replay automatically.',
 'Browser+integration20synthetic uploads partialaccept/reject and selectedfailed-only retry remains unmapped.', [('apps/admin/lib/client-image-upload.ts','export')])
setrow('M23-T11','PARTIAL',[('CURRENT_SOURCE','Middleware sets private/no-store/security headers but matcher excludes prefetch; font helper sets private/no-store for success/errors. Individual response branches alone do not prove final deployment responses.')],
 'Verify actual middleware/Next/OpenNext/CDN route coverage including prefetch before choosing minimal fix. No production cache leak claimed from source alone.',
 'Required runtime-integration+admin-e2e2account JSON/HTML/RSC/redirect/401/403/503/malformedDTO/prefetch matrix remains unmapped.',[(mw,'{ type: "header", key: "next-router-prefetch" }'),(font,'Cache-Control')])
news='scripts/lib/literary-news-social.test.mjs';social='scripts/lib/literary-news-social.mjs'
setrow('M25-T01','PARTIAL',[('CURRENT_SOURCE','Existing reviewed public panel and dedicated literary-news model/durable social path already exist; no copying into articles needed.'),('NEWS_DOC','Existing disabled-by-default native preparation/private profile architecture is documented.')],
 'Map actual editorial master/version and projection relationship rather than building a second news surface.',
 'Real DB+integration approvedtestcard→existingblock with noarticles/newpublicpages remains unmapped.', [('scripts/lib/literary-news-publication.mjs','export')])
setrow('M25-T02','PARTIAL',[('CURRENT_SOURCE','Existing reviewed records distinguish kind/eventDate/publishedAt; existing public record validator requires valid eventDate, while held candidates may lack a verified date.')],
 'Do not replace unknown eventdate with sourcepublishedAt or fake00:00; verify date-only precision/timezone contract and held-vs-public eligibility.',
 'Unit+integration sourcepublishedAt/date-only/unknowndate with exact existingcalendar projection remains unmapped.', [('scripts/lib/literary-news-reviewed.mjs','!validDate(record.eventDate)')])
setrow('M25-T03','UNMAPPED',[('CURRENT_SOURCE','Existing itemID/eventKey and public correction/withdrawal reducer exist; actual calendar persistence/link proof not mapped.')],
 'Trace stable existingcalendar identity from approved revision through correction/withdrawal; do not create another calendar or infer identity from title.',
 'DB+integration samecalendarID date/title correction and coordinatedwithdrawal remains unmapped.', [('scripts/lib/literary-news-publication.test.mjs','holds fresh arrivals, applies corrections')])
setrow('M25-T04','PARTIAL',[('NEWS_DOC','Fixed source registry, bounded fetch and unpublished held state are documented; discovery cannot self-authorize editorial publication.'),('CURRENT_SOURCE','Existing validation/reviewed/approved queue boundary and safe-fetch suites are present.')],
 'Reuse existing untrusted-input and source verification boundaries; verify content approval is actor/revision-derived, not provider reviewed=true.',
 'Exact unit+integration embeddedinstructions/dangerousURL/reviewed=true fixture and no config/rights/editorial change proof remains unmapped.', [('scripts/lib/literary-news-approved-queue.test.mjs','rejects public flags')])
setrow('M25-T05','LOCAL_PROOF',[('PSELECT','Actual social/release-operator suites selected in sealed1af; current cases require complete current live-release proof and reject stale public revision.'),('CURRENT_SOURCE','Dedicated preparation requires a confirmed snapshot/release; explicit receipts gate delivery.')],
 'No held→blind-send feature gap established. Preserve existing publishedrevision authority and disabledchannels.',
 'Rebind exact held/draft/failed-publicrelease negative case outputs to current source; realexternalconnection remains NOT_RUN absentauthorization.',[(news,'requires complete current live-release proof')])
setrow('M25-T06','LEVEL_DEFERRED',[('PSELECT','Existing social/release suites cover fixed destinations, VKoff, stalecontrol, preview withoutplatformwrites; actual news identity is separate.'),('CURRENT_SOURCE','No copy-to-article adapter is needed for dedicated news transport.')],
 'Preserve source/revision/locale/destination/intent identity and current off-flags; do not enable delivery from this task.',
 'Required actual admin-e2e+integration article-vs-agenda previews and unconfigured provider states remain unmapped.', [('scripts/lib/literary-news-release-operator.test.mjs','while VK remains off')])
setrow('M25-T07','LOCAL_PROOF',[('PSELECT','Specific actual social suite selected in sealed1af; named lostresponse case leaves ambiguous afterlease with no blindcreate retry.'),('CURRENT_SOURCE','Durable dispatchStartedAt is recognized as unknown and retained.')],
 'No new unknown-outcome duplicate fix inferred for this existing news delivery path; preserve its original durable admission/claim/receipt logic.',
 'Bind exact current case status/source and channelresponse contract; no real Telegram/VK send/reconciliation trial authorized.',[(news,'a lost response remains ambiguous'),(social,'dispatch_outcome_unknown')])
setrow('M25-T08','LOCAL_PROOF',[('PSELECT','Existing social suite selected in sealed1af; correction/withdrawal/newrevision race cases reuseknown remoteID and preserve newer desiredrevision.'),('CURRENT_SOURCE','Transport distinguishes edit/create and returnsambiguous for uncertainreceipts.')],
 'Reuse existing supported remote updates; explicitly classify unsupported revoke rather than promising deletion.',
 'Map exact supported/unsupportedupdate/delete outcomes to source-bound mocks; external provider verification remains separateNOT_RUN.',[(news,'the next call edits the known ID')])
setrow('M25-T09','UNMAPPED',[('CURRENT_SOURCE','RSS/feed and native social transport are separate modules; feedgeneration is not an accepted remote receipt.')],
 'Do not conflate RSS readiness with platformsent. Verifyactual DTO/status consumers before changing UI.',
 'Unit+integration RSSartifact withoutplatformACK honest readiness status remains unmapped.', [('scripts/lib/literary-news-feed.mjs','RSS pubDate')])
setrow('M25-T10','PARTIAL',[('CURRENT_SOURCE','Approved-queue tests specifically preserve unrelated decisions and lastgoodstate on failedsource/failedprivate read; durable annualowner/fence exists.'),('NEWS_DOC','KVsnapshot/durableapproval ownership is documented and must be distinguished.')],
 'Trace actual rejected and confirmed editorial decisions across collector refresh, including adminactor/version, rather than treating heldsnapshot asmaster.',
 'Real DB+integration accepted/rejected decisions survive heldrefresh with exact source/masterrevision proof remains unmapped.', [('scripts/lib/literary-news-approved-queue.test.mjs','preserving unrelated decisions')])
assert len(rows)==91 and all(r['anchors'] and r['remainingProof'] for r in rows)
document={
 'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'classification':'PARENT_ONLY_READ_ONLY_ACCEPTANCE_GAP_INVENTORY_NOT_ACCEPTANCE_RESULTS',
 'definitions':{'UNMAPPED':'No specifically sufficient scenario/runtime evidence mapped at the required boundary; code may exist.','PARTIAL':'Mapped lower proof or source-confirmed discrepancy leaves behavior/protocol/proof requirements unresolved; not whole-criterion acceptance.','LOCAL_PROOF':'Specifically relevant local/historical behavior proof is mapped at its disclosed boundary, not production/module acceptance.','LEVEL_DEFERRED':'Lower-level local behavior is mapped but an explicitly required DB/component/admin/public browser scenario remains unmapped/unexecuted.'},
 'baseline':{'latestCanonicalValidatedFingerprint':'1af04f3230b3395637a3e06090c1b25c72c66735d4c185be36c626374e4df02e',
 'currentSitecopy':'Current native196/eight-wrapper/realJS/races12/focus398 PASS, frozen working8e5 firstwhole failure retained; fresh fullV2 is active/pending per root. Not yet a fully validated replacement snapshot.',
 'canonical':meta(canonical),'sourceAgePolicy':'Historical source provenance is retained. No original Phase done checkbox, requirement initialNOT_RUN, suitecount or code-presence is current criterion acceptance. Current source excerpts are observations only; source age is explicit per evidence ref.'},
 'requirementsSources':[meta('docs/admin-r3-task-package/CORE_RULES.md')]+[meta(f'docs/admin-r3-task-package/modules/{m}.md') for m in modules],
 'evidence':evidence,'rows':rows,
 'coverage':{'modules':modules,'criterionIds':[r['id'] for r in rows],'criterionCount':len(rows),'scope':'Inventory completeness only, not accepted/implemented count or percentage. M24 is intentionally excluded because its separate inventory already exists.'},
 'priorityActions':[
 {'kind':'SOURCE_CONFIRMED_REPRODUCTION_NEXT','ids':['M19-T01','M19-T05','M19-T06','M19-T09'],'action':'Capture current exact Page create/plaintext/workingdraft/preview BEFORE after whole run quiet; design minimal existing-document/draft reuse, preserving normalizers and public revision.'},
 {'kind':'SOURCE_CONFIRMED_REPRODUCTION_NEXT','ids':['M20-T07','M20-T10'],'action':'Capture resolved recoverylookup{ok:false} and exactcleanup{ok:true,deleted:false} against actual controller before any maintained fix.'},
 {'kind':'SOURCE_CONFIRMED_REPRODUCTION_NEXT','ids':['M22-T05','M22-T06'],'action':'Capture invalid/mixed/51patterns through actual existing banner preprocessing; preserve original decoded input and source hash.'},
 {'kind':'SOURCE_CONFIRMED_REPRODUCTION_NEXT','ids':['M13-T01','M13-T02','M15-T01'],'action':'Reproduce computedcanonical/>12issues/pendingdirectapproval through actual paths, then narrow changes preserving guardedRPCs.'},
 {'kind':'PROOF_FIRST_EXISTING_GUARD','ids':['M15-T03','M15-T05','M16-T04','M13-T09'],'action':'Use existing owner/rollback/redirect guards as the baseline; actual DB concurrency/old-version/auditfault proof is missing, not necessarily code.'},
 {'kind':'BOUNDARY_FIRST','ids':['M23-T01','M23-T02','M23-T03','M23-T11'],'action':'Confirm actual RouteHandler+middleware+Cloudflare/OpenNext cookie/origin/prefetch/body-limit behavior in isolation before minimal security/runtime corrections.'}],
 'auditLimits':['Only requirements/current bounded source excerpts/canonical and small receipt/selection metadata read. No tests/compiler/browser/server/provider/network/managed query ran.','No large ZIP decompression/hash or AST scan; no maintained source/docs edits; only this parent-only inventory and producer written.','No accepted module/criterion counts or percentages calculated. Unknown proof mapping is not an implementation absence claim.']}
for ref,item in evidence.items():
    if 'file' in item:item['observedFileMetadata']=meta(item['file'])
output=work/'m13-m25-except24-gap-inventory.json'
output.write_text(json.dumps(document,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'file':str(output),'rows':len(rows),'modules':len(modules),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'classification':document['classification']}))
