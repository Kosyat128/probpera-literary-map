// PREPARED / UNEXECUTED. Calls actual captured helpers and actual native canonical/outbox SQL.
// No DB start here. Explicit root release + owned lifecycle runner are prerequisites.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const assert = require('node:assert/strict'), { spawn } = require('node:child_process');
const { pathToFileURL } = require('node:url');
const { createGateway, quote } = require('./gateway.prepared.cjs');
const { caseIds, evaluate } = require('./oracle.prepared.cjs');
if (!process.argv.includes('--execute-owned')) {
  console.log(JSON.stringify({ classification: 'PREPARED_ONLY_UNEXECUTED', caseIds, databaseConnections: 0, testsRun: 0 }));
  process.exit(0);
}
const option = name => { const at = process.argv.indexOf(name); assert.ok(at >= 0 && process.argv[at + 1]); return process.argv[at + 1]; };
const ownedPath = path.resolve(option('--owned')), owned = JSON.parse(fs.readFileSync(ownedPath, 'utf8').replace(/^\uFEFF/u, ''));
const database = option('--database'), output = path.resolve(option('--output'));
const work = path.resolve(__dirname, '..'), relative = path.relative(work, output);
assert.ok(relative && !relative.startsWith('..') && !path.isAbsolute(relative));
assert.equal(fs.existsSync(output), false); fs.mkdirSync(output);
const sourceManifest = JSON.parse(fs.readFileSync(path.join(__dirname, 'source-manifest.prepared.json'), 'utf8'));
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
for (const row of sourceManifest.files) {
  const captured = fs.readFileSync(path.join(__dirname, 'sources', row.file));
  const current = fs.readFileSync(path.join(work, '..', 'probpera-literary-map', row.file));
  assert.equal(sha(captured), row.sha256, 'Captured source drift: ' + row.file);
  assert.equal(sha(current), row.sha256, 'Current source drift: ' + row.file);
}
assert.equal(owned.port, 55438); assert.equal(owned.listenAddress, '127.0.0.1'); assert.equal(owned.service, false);
const pidLines = fs.readFileSync(path.join(owned.dataDirectory, 'postmaster.pid'), 'utf8').trim().split(/\r?\n/u);
const normal = value => value.replaceAll('\\', '/').replace(/\/$/u, '').toLowerCase();
assert.equal(Number(pidLines[0]), owned.pid); assert.equal(Number(pidLines[3]), 55438); assert.equal(pidLines[5].trim(), '127.0.0.1'); assert.equal(normal(pidLines[1]), normal(owned.dataDirectory));
const mainSha = '1'.repeat(40), actor = '11111111-1111-4111-8111-111111111111', runToken = crypto.randomUUID().slice(0, 8);
const native = createGateway({ database, owned, output, tag: 'observer', mainSha });
const sessions = [], children = [], results = [], checks = [], order = [];
globalThis.fetch = () => { throw Error('Undeclared external fetch forbidden'); };
const write = (name, value) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + '\n');
const waitExit = (child, label, ms = 15000) => new Promise((resolve, reject) => {
  if (child.exitCode !== null) return resolve(child.exitCode);
  const timer = setTimeout(() => reject(Error('Owned child exit timeout: ' + label)), ms);
  child.once('error', error => { clearTimeout(timer); reject(error); });
  child.once('close', code => { clearTimeout(timer); resolve(code); });
});
function startA(label, sql) {
  const app = 'm04-cut-' + runToken + '-' + label.slice(0, 25);
  const child = spawn(native.psql, native.baseArgs, { env: { ...native.environment, PGAPPNAME: app }, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
  const s = { label, child, app, values: [], waiters: [], stdout: '', stderr: '', sql: '', closed: false, pid: null };
  sessions.push(s); child.stdin.on('error', () => {});
  child.once('error', error => { s.spawnError = error.message; s.stderr += '\nSPAWN_SETUP_FAILURE: ' + error.message; });
  let pending = '';
  child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
  child.stdout.on('data', chunk => {
    s.stdout += chunk; pending += chunk; let pos;
    while ((pos = pending.indexOf('\n')) >= 0) {
      const line = pending.slice(0, pos).replace(/\r$/u, ''); pending = pending.slice(pos + 1);
      if (!line.startsWith('{')) continue;
      let value; try { value = JSON.parse(line); } catch { continue; }
      s.values.push(value); if (value.tag === 'allocated') s.pid = value.pid;
      for (const waiter of [...s.waiters]) if (waiter.tag === value.tag) { s.waiters.splice(s.waiters.indexOf(waiter), 1); clearTimeout(waiter.timer); waiter.resolve(value); }
    }
  });
  child.stderr.on('data', chunk => s.stderr += chunk);
  child.once('close', code => {
    s.closed = true; s.exitCode = code;
    for (const waiter of s.waiters) { clearTimeout(waiter.timer); waiter.reject(Error(label + ' closed: ' + s.stderr)); }
    s.waiters = []; fs.writeFileSync(path.join(output, label + '.stdout.log'), s.stdout); fs.writeFileSync(path.join(output, label + '.stderr.log'), s.stderr);
  });
  s.send = text => { s.sql += text + '\n'; fs.writeFileSync(path.join(output, label + '.sql'), s.sql); child.stdin.write(text + '\n'); };
  s.wait = tag => {
    const old = s.values.find(value => value.tag === tag); if (old) return Promise.resolve(old);
    if (s.closed) return Promise.reject(Error('Session already closed: ' + label));
    return new Promise((resolve, reject) => { const waiter = { tag, resolve, reject }; waiter.timer = setTimeout(() => { s.waiters.splice(s.waiters.indexOf(waiter), 1); reject(Error('No exact session tag: ' + label + '/' + tag)); }, 12000); s.waiters.push(waiter); });
  };
  s.commit = async () => { s.send("commit;select jsonb_build_object('tag','committed','pid',pg_backend_pid());\\q"); await s.wait('committed'); assert.equal(await waitExit(child, label), 0); };
  s.send("begin isolation level read committed;set local statement_timeout='12s';set local idle_in_transaction_session_timeout='45s';select set_config('request.jwt.claim.sub'," + quote(actor) + ",true);" + sql);
  return s;
}
function pageDocument(html) {
  const text = html.replace(/^<p>|<\/p>$/gu, '');
  return { type: 'doc', content: [{ type: 'paragraph', content: [{ type: 'text', text }] }] };
}
function setPage(id, html) {
  const json = pageDocument(html);
  return 'update public.pages set content_html=' + quote(html) + ',content_json=' + quote(JSON.stringify(json)) + '::jsonb,updated_by=' + quote(actor) + '::uuid where id=' + quote(id) + '::uuid;';
}
function eventExpr(id) { return "(select id from public.public_build_outbox where entity_type='pages' and entity_id=" + quote(id) + " and reason='database-update' order by id desc limit 1)"; }
function beginA(id, html, label) { return startA(label, setPage(id, html) + "select jsonb_build_object('tag','allocated','pid',pg_backend_pid(),'eventId'," + eventExpr(id) + ",'transactionId',pg_current_xact_id()::text);"); }
function bCommit(id, html, label) { return native.query(label, 'begin;select set_config(\'request.jwt.claim.sub\',' + quote(actor) + ',true);' + setPage(id, html) + "select jsonb_build_object('pid',pg_backend_pid(),'eventId'," + eventExpr(id) + ",'transactionId',pg_current_xact_id()::text);commit;'); }
function snapshot(aId, bId, label) {
  return native.query(label, "select jsonb_build_object('nativeSnapshot',pg_current_snapshot()::text,'pages',(select jsonb_agg(jsonb_build_object('id',id,'content_html',content_html,'content_json',content_json,'updated_at',updated_at) order by id) from public.pages where id in(" + quote(aId) + '::uuid,' + quote(bId) + "::uuid)),'visibleEventIds',(select coalesce(jsonb_agg(id order by id),'[]'::jsonb) from public.public_build_outbox where status in('requested','dispatched','failed')));");
}
function state(aId, bId, aEventId, bEventId, label) {
  return native.query(label, "select jsonb_build_object('a',(select to_jsonb(p) from public.pages p where id=" + quote(aId) + "::uuid),'b',(select to_jsonb(p) from public.pages p where id=" + quote(bId) + "::uuid),'aEvent',(select to_jsonb(o) from public.public_build_outbox o where id=" + aEventId + "),'bEvent',(select to_jsonb(o) from public.public_build_outbox o where id=" + bEventId + "),'sameEntityEvents',(select jsonb_agg(to_jsonb(o) order by id) from public.public_build_outbox o where entity_type='pages' and entity_id=" + quote(aId) + '));');
}
function finalizer(config, onPatchReady) {
  const file = path.join(output, config.tag + '.config.json'); fs.writeFileSync(file, JSON.stringify(config, null, 2) + '\n');
  const child = spawn(process.execPath, [path.join(__dirname, 'finalizer-boundary.prepared.cjs'), file], { env: native.environment, stdio: ['ignore', 'pipe', 'pipe', 'ipc'], windowsHide: true });
  children.push(child); let stdout = '', stderr = '', gateError = null; child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
  child.stdout.on('data', value => stdout += value); child.stderr.on('data', value => stderr += value);
  child.on('message', message => {
    if (message?.tag !== 'native-patch-ready') return;
    Promise.resolve().then(onPatchReady).then(() => child.send({ tag: 'allow-native-patch' })).catch(error => { gateError = error; child.disconnect(); });
  });
  return waitExit(child, config.tag, 20000).then(exitCode => {
    fs.writeFileSync(path.join(output, config.tag + '.stdout.log'), stdout); fs.writeFileSync(path.join(output, config.tag + '.stderr.log'), stderr);
    if (gateError) throw gateError;
    assert.equal(exitCode, 0, 'Actual finalizer CLI failed: ' + stderr);
    const trace = JSON.parse(fs.readFileSync(config.traceOutput, 'utf8'));
    const patches = trace.requests.filter(request => request.method === 'PATCH');
    return { exitCode, patchCount: patches.length, changedIds: patches.flatMap(request => request.nativeResult.changedIds), traceFile: config.traceOutput };
  });
}
async function main() {
  const identity = native.query('actual-owned-identity', "select jsonb_build_object('database',current_database(),'dataDirectory',current_setting('data_directory'),'port',inet_server_port(),'address',inet_server_addr(),'version',current_setting('server_version'));");
  assert.equal(identity.database, database); assert.equal(identity.port, 55438); assert.equal(identity.address, '127.0.0.1'); assert.equal(normal(identity.dataDirectory), normal(owned.dataDirectory));
  const privilege = native.query('actual-unchanged-privileges', "select jsonb_build_object('select',has_table_privilege('service_role','public.public_build_outbox','SELECT'),'update',has_table_privilege('service_role','public.public_build_outbox','UPDATE'),'insert',has_table_privilege('service_role','public.public_build_outbox','INSERT'),'legacySelect',has_table_privilege('service_role','public.admin_audit_log','SELECT'),'actorExists',(select count(*)=1 from auth.users where id=" + quote(actor) + '::uuid));');
  assert.equal(privilege.actorExists, true); assert.equal(privilege.legacySelect, false, 'Unexpected foundation privilege; review scope before adapting');
  const missingLegacy = native.query('direct-service-legacy-read-precondition', 'select id from public.admin_audit_log limit 1;', { role: 'service_role', expectedError: '42501' });
  const source = file => pathToFileURL(path.join(__dirname, 'sources', 'scripts', file)).href;
  const { fetchCmsPublicationHead } = await import(source('lib/cms-publication-head.mjs'));
  const { verifyPublicationDeployHead } = await import(source('verify-publication-deploy-head.mjs'));
  const { coalescePublicationFollowUp } = await import(source('coalesce-publication-followup.mjs'));
  for (const caseId of caseIds) {
    const caseOrder = [], mark = value => { caseOrder.push(value); order.push({ caseId, event: value }); };
    const aId = crypto.randomUUID(), bId = crypto.randomUUID(), oldA = '<p>M04 old A ' + runToken + '</p>', newA = '<p>M04 new A ' + runToken + '</p>', newB = '<p>M04 new B ' + runToken + '</p>';
    const seed = (id, side) => '(' + quote(id) + '::uuid,' + quote('M04 cut ' + side) + ',' + quote('m04-cut-' + runToken + '-' + id) + ',' + quote(oldA) + ',' + quote(JSON.stringify(pageDocument(oldA))) + "::jsonb,'published'," + quote(actor) + '::uuid,' + quote(actor) + '::uuid)';
    native.query('seed-' + caseId, "begin;select set_config('request.jwt.claim.sub'," + quote(actor) + ",true);insert into public.pages(id,title,slug,content_html,content_json,status,created_by,updated_by) values" + seed(aId, 'A') + ',' + seed(bId, 'B') + ";select jsonb_build_object('seededPages',count(*)) from public.pages where id in(" + quote(aId) + '::uuid,' + quote(bId) + '::uuid);commit;');
    const lateLower = caseId.startsWith('lower-commit-'), higher = caseId === 'higher-commit-after-candidate';
    let a = null, allocated = null, candidate = null, explicitEventId = null;
    if (!higher) { a = beginA(aId, newA, 'a-' + caseId); allocated = await a.wait('allocated'); mark('a-allocated-uncommitted'); }
    const b = bCommit(bId, newB, 'b-' + caseId); mark('b-committed');
    if (!lateLower && !higher) { await a.commit(); mark('a-committed'); }
    if (caseId === 'trigger-and-explicit-coexist') {
      explicitEventId = native.query('explicit-same-entity', "begin;set local role authenticated;select set_config('request.jwt.claim.sub'," + quote(actor) + ",true);select jsonb_build_object('id',public.enqueue_public_build_request('pages'," + quote(aId) + ",'manual-explicit','{}'::jsonb));commit;").id;
    }
    const snap = snapshot(aId, bId, 'candidate-' + caseId);
    const head = await fetchCmsPublicationHead({ supabaseUrl: 'https://fixture-probpera.supabase.co', serviceKey: 'fixture-key-not-a-secret', fetchImpl: native.fetchImpl });
    assert.equal(head.legacyAuditHighWater, '0', 'This bounded finalizer slice requires baseline with no legacy pending head; never silently omit legacy marker');
    candidate = { ...snap, head, a: snap.pages.find(row => row.id === aId), b: snap.pages.find(row => row.id === bId) }; mark('candidate-read');
    if (lateLower) {
      const proof = native.query('held-source-proof-' + caseId, "select jsonb_build_object('application',application_name,'pid',pid,'state',state,'backendXid',backend_xid::text) from pg_stat_activity where pid=" + allocated.pid + ';');
      assert.equal(proof.state, 'idle in transaction'); assert.ok(proof.backendXid);
      write(caseId + '.transaction-proof.json', { allocated, b, observerProof: proof, canonicalSnapshot: snap });
    }
    if (higher) { a = beginA(aId, newA, 'a-' + caseId); allocated = await a.wait('allocated'); mark('a-allocated-after-candidate'); await a.commit(); mark('a-committed'); }
    if (caseId === 'lower-commit-before-head-guard') { await a.commit(); mark('a-committed'); }
    const environment = { SUPABASE_URL: 'https://fixture-probpera.supabase.co', SUPABASE_SERVICE_ROLE_KEY: 'fixture-key-not-a-secret', GITHUB_REPOSITORY: 'fixture/publication-cut', GITHUB_TOKEN: 'fixture-token-not-a-secret', GITHUB_RUN_ID: '90004012', EXPECTED_MAIN_SHA: mainSha, CANDIDATE_PUBLICATION_HEAD_SOURCE: head.source, CANDIDATE_OUTBOX_HIGH_WATER: head.outboxHighWater, CANDIDATE_LEGACY_AUDIT_HIGH_WATER: head.legacyAuditHighWater, CANDIDATE_ARTICLE_COUNT: '0', CANDIDATE_CONTENT_SHA256: sha(JSON.stringify(snap.pages)), GITHUB_OUTPUT: '', GITHUB_STEP_SUMMARY: '' };
    let guard; try { guard = { ok: true, value: await verifyPublicationDeployHead(environment, native.fetchImpl) }; } catch (error) { guard = { ok: false, message: error.message }; }
    const coalescer = await coalescePublicationFollowUp(environment, native.fetchImpl); mark('guard-and-coalescer-complete');
    let finalized = null, secondFinalizer = null, afterFirstFinalize = null;
    const config = tag => ({ database, owned, output, tag, mainSha, runId: '90004012', finalizer: path.join(__dirname, 'sources', 'scripts', 'check-public-build-requests.mjs'), marker: 'outbox:' + head.outboxHighWater, traceOutput: path.join(output, tag + '.trace.json'), failureOutput: path.join(output, tag + '.failure.json'), pauseBeforePatch: caseId === 'lower-commit-after-guard-before-patch' });
    if (guard.ok && coalescer.safeToFinalize) {
      finalized = await finalizer(config(caseId + '-finalizer'), async () => { mark('actual-finalizer-patch-ready'); await a.commit(); mark('a-committed'); mark('allow-native-patch'); }); mark('native-finalizer-complete');
    }
    if (caseId === 'duplicate-finalizer-callback') { afterFirstFinalize = state(aId, bId, allocated.eventId, b.eventId, 'first-callback-state'); const again = config(caseId + '-again'); again.pauseBeforePatch = false; secondFinalizer = await finalizer(again); }
    const final = state(aId, bId, allocated.eventId, b.eventId, 'final-' + caseId);
    const result = { caseId, oldA, newA, newB, aPid: allocated.pid, bPid: b.pid, aEventId: allocated.eventId, bEventId: b.eventId, explicitEventId, candidate, guard, coalescer, finalizer: finalized, secondFinalizer, afterFirstFinalize, final, order: caseOrder, servicePrivileges: privilege, legacyServiceDeniedCode: missingLegacy.expectedNativeError, actualHeadFetch: true, actualGuardReached: true, actualCoalescerReached: true, runtime: { functions: ['fetchCmsPublicationHead', 'verifyPublicationDeployHead', 'coalescePublicationFollowUp'], finalizer: finalized ? 'ACTUAL_CAPTURED_CLI_DYNAMIC_IMPORT' : 'NOT_CALLED_BECAUSE_ACTUAL_GUARD_OR_COALESCER_REFUSED' } };
    results.push(result); checks.push(...evaluate(result)); write('results.partial.json', { results, checks });
  }
}
let failure = null;
main().catch(error => { failure = { message: error.message, stack: error.stack, classification: 'SETUP_OR_HARNESS_OR_NATIVE_EXECUTION_FAILURE_NOT_AUTOMATIC_PRODUCT_FAILURE' }; }).finally(async () => {
  for (const session of sessions) if (!session.closed) { session.send('rollback;\\q'); try { await waitExit(session.child, session.label, 4000); } catch { session.child.kill(); await waitExit(session.child, session.label, 4000).catch(() => {}); } }
  for (const child of children) if (child.exitCode === null) { child.kill(); await waitExit(child, 'finalizer-cleanup', 4000).catch(() => {}); }
  let remaining = { remaining: null, cleanupQueryConfirmed: false };
  try { remaining = { ...native.query('actual-client-cleanup', "select jsonb_build_object('remaining',coalesce(jsonb_agg(jsonb_build_object('pid',pid,'app',application_name,'state',state)),'[]'::jsonb)) from pg_stat_activity where datname=current_database() and pid<>pg_backend_pid();"), cleanupQueryConfirmed: true }; }
  catch (error) { failure ??= { message: error.message, stack: error.stack, classification: 'CLEANUP_QUERY_UNCONFIRMED_OUTER_OWNED_STOP_REQUIRED' }; }
  write('native-gateway-trace.json', native.trace);
  const report = { classification: failure ? 'EXECUTION_INCOMPLETE_REQUIRES_REVIEW' : 'GENUINE_CONTROLLED_BEFORE_COMPLETE_NOT_FULL_EXPORT_ACCEPTANCE', database, rootMigrationSha256: '91e11a46e6db2834cf69bf5dda41a40151195cc410be85ce549a3a083debd320', cases: results.length, plannedCases: caseIds.length, checks: checks.length, passed: checks.filter(row => row.pass).length, failed: checks.filter(row => !row.pass).length, preconditionFailures: checks.filter(row => row.kind === 'PRECONDITION' && !row.pass).length, failure, results, oracle: checks, cleanup: { interactiveChildrenTerminal: sessions.every(s => s.closed), finalizerChildrenTerminal: children.every(c => c.exitCode !== null), remainingNativeClients: remaining.remaining, clusterStopOwnedByOuterLifecycle: true }, limits: ['Canonical snapshot is ONE actual owner query on two synthetic published pages, not complete joint RU/Premium export.', 'Native factual rows reach actual helpers/CLI through declared local fetch adapter, not managed PostgREST/Auth.', 'Legacy owner-read adaptation follows actual direct service 42501; all outbox SELECT/UPDATE use unchanged service_role grants.', 'No external GitHub/Supabase/provider request; GitHub responses are controlled.', 'No active/expired lease, full M04/global acceptance claim.'] };
  write('report.json', report); console.log(JSON.stringify({ ...report, results: undefined, oracle: undefined }));
  if (failure || report.preconditionFailures || !remaining.cleanupQueryConfirmed || remaining.remaining.length) process.exitCode = 1;
});
