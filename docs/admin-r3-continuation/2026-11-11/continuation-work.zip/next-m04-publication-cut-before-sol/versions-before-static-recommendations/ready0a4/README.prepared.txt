M04-T12 local publication-queue integrity BEFORE - PREPARED ONLY, UNEXECUTED

No current failure or success is claimed. Root's whole V2 runs on frozen4dfef;
all execution, DB start, syntax/compiler checks, compression and project writes
remain held until a NEW explicit root release. Existing unfinished producer files
were retained and completed in this work-only directory. Earlier unrelated
country/budget failures, adaptations, reviews and native archives are untouched.

Read fixture-plan.prepared.json for the exact six finite identities, intended
contract, controls and limits. oracle.prepared.cjs separates native/setup facts
from desired M04-T12 assertions; product failure requires true preconditions.

Runtime path: producer.prepared.cjs imports actual captured head/guard/coalescer;
finalizer-boundary.prepared.cjs imports the actual captured, unexported finalizer
CLI. gateway.prepared.cjs is only a declared fetch/delivery adapter. It validates
the actual URL, selector and body, then runs corresponding factual SQL. It never
adds desired membership filtering or a replacement guard/coalescer. External
GitHub responses are local constants/captured requests, never external calls.

Foundation: clone retained actual LOW-ID m04m20_native_20261030_v2 into a NEW DB;
apply only exact current91e retry migration. Never clone seq/race DBs whose
identity sequences exceeded2^53. Never reset/setval/drop a DB or sequence.
Head REST-like JSON uses native numeric ids and rejects unsafe values.
Canonical reads and legacy head use explicit owner-read fixture adaptation.
First preserve actual direct service legacy read42501 as an environment fact.
All outbox reads/updates use existing service_role privileges. No grant changes.
The bounded finalizer requires legacy head0; a different real baseline stops as
unsupported setup instead of silently omitting a legacy marker.

Canonical candidate means ONE actual SQL snapshot on two coherent synthetic
published pages, not the full ordinary RU plus Premium export or public artifact.
articleCount0/hash merely exercise the actual guard's current wire contract.
The real exporter/workflow/test sources are preserved references, not executed.

Lifecycle derives from the actually completed sequential runner, preserving
strict stopped-PID/pidfile/port preflight, exact data/bin paths, process epoch,
loopbackSQL identity, current-source checks, new clone only, allowlisted child
environment and owned-stop-finally. All child logs/failures and final process,
postmaster.pid/55438 liveness receipts remain. No service creation or cleanup
deletion/drop is allowed. Runtime setup failure is not a product defect.
The inherited pg_ctl pipe-EOF deferral is retained until after verified stop.

After root approves syntax/native execution and source hashes, intended command:

& 'C:\Users\Костя\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe' -NoProfile -File 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\next-m04-publication-cut-before-sol\run.prepared.ps1' -ExecuteOwned -Phase M04Cut -Database m04_cut_before_20261030_v1 -Output 'C:\Users\Костя\Documents\Codex\2026-10-09\v\work\m04-publication-cut-before-v1' -Migration 'C:\Users\Костя\Documents\Codex\2026-10-09\v\probpera-literary-map\supabase\migrations\20261030161000_publication_retry_admission.sql' -MigrationSha256 91e11a46e6db2834cf69bf5dda41a40151195cc410be85ce549a3a083debd320

This command has NOT run. Root must coordinate exclusive port55438 and current
binary/source/PID input freeze. The producer never starts/stops PG itself.
No uniform runtime success, native failure count or full criterion acceptance is
projected from this prepared text.
