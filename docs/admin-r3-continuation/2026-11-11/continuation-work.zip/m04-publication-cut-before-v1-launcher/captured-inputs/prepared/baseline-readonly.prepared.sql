-- PREPARED ONLY. Read-only foundation facts, never grants or synthetic target DDL.
\set ON_ERROR_STOP on
select jsonb_build_object(
 'classification','ACTUAL_RETAINED_LOW_ID_BASELINE_READINESS_NOT_ACCEPTANCE',
 'database',current_database(),
 'retryProtocolAbsent',to_regprocedure('public.admit_public_build_retry(bigint,uuid,text)') is null,
 'outboxMaxId',(select coalesce(max(id),0) from public.public_build_outbox),
 'outboxNumericHeadSafe',(select coalesce(max(id),0)<=9007199254740991 from public.public_build_outbox),
 'legacyMaxId',(select coalesce(max(id),0) from public.admin_audit_log where action in('public_build.requested','public_build.failed')),
 'pagesCaptureTrigger',(select count(*)=1 from pg_trigger where tgrelid='public.pages'::regclass and tgname='pages_public_build_outbox' and tgenabled='O' and not tgisinternal),
 'ownerFixturePresent',(select count(*)=1 from auth.users where id='11111111-1111-4111-8111-111111111111'::uuid),
 'outboxServiceSelect',has_table_privilege('service_role','public.public_build_outbox','SELECT'),
 'outboxServiceUpdate',has_table_privilege('service_role','public.public_build_outbox','UPDATE'),
 'outboxServiceInsert',has_table_privilege('service_role','public.public_build_outbox','INSERT'),
 'legacyServiceSelect',has_table_privilege('service_role','public.admin_audit_log','SELECT')
);
