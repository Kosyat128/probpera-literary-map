"""Parent-only TEXT/METADATA construction; never invokes any runtime or DB client."""
from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = WORK.parent / 'probpera-literary-map'
OLD = WORK / 'm04-retry-native-fixtures-sol'
hash_file = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = (OLD / 'run.prepared.ps1').read_text(encoding='utf-8-sig')
old_runner_hash = hash_file(OLD / 'run.prepared.ps1')
source = source.replace("[ValidateSet('M04')][string]$Phase='M04'", "[ValidateSet('M04Cut')][string]$Phase='M04Cut'")
source = source.replace("^m04_retry_native_[a-z0-9_]{1,44}$", "^m04_cut_before_[a-z0-9_]{1,42}$")
source = source.replace("'m04_retry_owned_'", "'m04_cut_owned_'")
source = source.replace("$null=Checked $node @('--check',(Join-Path $PSScriptRoot 'run-cases.prepared.cjs')) 'native-cases-syntax'", "$null=Checked $node @('--check',(Join-Path $PSScriptRoot 'producer.prepared.cjs')) 'prepared-producer-syntax'\n $null=Checked $node @('--check',(Join-Path $PSScriptRoot 'oracle.prepared.cjs')) 'prepared-oracle-syntax'\n $null=Checked $node @('--check',(Join-Path $PSScriptRoot 'gateway.prepared.cjs')) 'prepared-gateway-syntax'\n $null=Checked $node @('--check',(Join-Path $PSScriptRoot 'finalizer-boundary.prepared.cjs')) 'prepared-finalizer-boundary-syntax'")
source = source.replace("if((Hash $migrationFull) -ne $MigrationSha256){throw 'Root migration source drift'}", "if($MigrationSha256 -ne '91e11a46e6db2834cf69bf5dda41a40151195cc410be85ce549a3a083debd320' -or (Hash $migrationFull) -ne $MigrationSha256){throw 'Root-approved current migration source drift'}\n if($ExecuteRaces){throw 'ExecuteRaces is not part of this finite publication-cut fixture'}")
source = source.replace("$null=Checked $psql ((Psql-Args $Database)+@('-f',(Join-Path $PSScriptRoot 'before.prepared.sql'))) 'old-contract-before'\n $null=Checked $psql ((Psql-Args $Database)+@('-f',(Join-Path $PSScriptRoot 'legacy-seed-before.prepared.sql'))) 'old-real-legacy-seed'", "$null=Checked $psql ((Psql-Args $Database)+@('-f',(Join-Path $PSScriptRoot 'baseline-readonly.prepared.sql'))) 'actual-baseline-readonly-precondition'")
source = source.replace("$null=Checked $node @((Join-Path $PSScriptRoot 'run-cases.prepared.cjs'),'--execute-owned','--owned',$ownedPath,'--database',$Database,'--output',(Join-Path $outputFull 'native-cases')) 'native-cases' 180000\n if($ExecuteRaces){\n  $null=Checked $node @((Join-Path $PSScriptRoot 'run-races.prepared.cjs'),'--execute-owned','--owned',$ownedPath,'--database',$Database,'--output',(Join-Path $outputFull 'native-races')) 'native-races' 180000\n }", "$null=Checked $node @((Join-Path $PSScriptRoot 'producer.prepared.cjs'),'--execute-owned','--owned',$ownedPath,'--database',$Database,'--output',(Join-Path $outputFull 'controlled-cases')) 'actual-publication-cut-cases' 240000\n if((Hash $migrationFull) -ne $MigrationSha256){throw 'Root migration changed during controlled execution'}")
source = source.replace("ACTUAL_M04_NATIVE_CASE_EXECUTION_COMPLETED_REQUIRES_INDEPENDENT_SCHEMA_AND_SCOPE_REVIEW", "ACTUAL_CONTROLLED_PUBLICATION_CUT_EXECUTION_COMPLETED_REQUIRES_ORACLE_SCHEMA_SCOPE_REVIEW")
source = source.replace("PREPARED TEXT ONLY. Do not execute until the root agent releases native work.", "PREPARED TEXT ONLY / NEVER EXECUTED. Derived from actual completed seq lifecycle, with new low-ID clone and finite controlled publication-cut producer. Requires a NEW root native release.")
source = source.replace("Write-Json 'binary-bindings.json'", "Write-Json 'prepared-input-bindings.json' (@(Get-ChildItem -LiteralPath $PSScriptRoot -File | Where-Object { $_.Name -ne 'ready.prepared.json' }) | ForEach-Object { [pscustomobject]@{file=$_.FullName;sha256=(Hash $_.FullName)} })\n Write-Json 'binary-bindings.json'")
for forbidden in ['run-cases.prepared.cjs', 'run-races.prepared.cjs', 'legacy-seed-before.prepared.sql', "'old-contract-before'"]:
    assert forbidden not in source, forbidden
target = HERE / 'run.prepared.ps1'
assert not target.exists(), 'No overwrite of prior prepared lifecycle'
target.write_text(source, encoding='utf-8', newline='\n')
for name in ['schema-observation.prepared.sql', 'compare-schema.prepared.py']:
    target = HERE / name
    assert not target.exists()
    target.write_bytes((OLD / name).read_bytes())
manifest_path = HERE / 'source-manifest.prepared.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8-sig'))
current = []
for row in manifest['files']:
    captured, actual = HERE / 'sources' / row['file'], REPO / row['file']
    current.append({'file': row['file'], 'expectedSha256': row['sha256'],
                    'capturedSha256': hash_file(captured), 'currentSha256': hash_file(actual),
                    'matches': hash_file(captured) == hash_file(actual) == row['sha256'],
                    'role': row['role']})
receipt = {'classification': 'PREPARED_ONLY_UNEXECUTED_NO_SYNTAX_OR_NATIVE_CLAIM',
           'preparedAt': datetime.now(timezone.utc).isoformat(),
           'sourceManifestSha256': hash_file(manifest_path),
           'originalCapturedSourceCount': len(current),
           'current20Rebind': current,
           'all20StillExact': all(row['matches'] for row in current),
           'sourceAge': 'Captured original preparation before whole V1; current physical light rebind only, not global source validation.',
           'lifecycleDerivation': {'source': str(OLD / 'run.prepared.ps1'), 'sha256': old_runner_hash,
                                  'changes': ['new safe low-ID template clone name', 'exact current91e migration', 'finite controlled producer instead of old sequential/races', 'read-only baseline facts', 'unchanged strict PG PID/path/epoch/loopback/finally cleanup']},
           'preparedFiles': [{'file': path.name, 'bytes': path.stat().st_size, 'sha256': hash_file(path)}
                             for path in sorted(HERE.iterdir()) if path.is_file() and path.name != 'ready.prepared.json'],
           'databaseConnections': 0, 'testsRun': 0, 'syntaxChecks': 0, 'compilerRuns': 0,
           'browserRuns': 0, 'compressionRuns': 0, 'providers': 0, 'projectSourceWrites': 0,
           'requiresFreshRootReleaseBeforeExecution': True,
           'readiness': 'TEXT_PREPARED_ONLY_REQUIRES_STATIC_REVIEW_AND_LATER_SYNTAX_PREFLIGHT'}
assert len(current) == 20
out = HERE / 'ready.prepared.json'
assert not out.exists()
out.write_text(json.dumps(receipt, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'receipt': str(out), 'sha256': hash_file(out), 'all20StillExact': receipt['all20StillExact'],
                  'preparedFiles': len(receipt['preparedFiles']), 'testsRun': 0, 'databaseConnections': 0}))
