-- PREPARED ONLY / NO EXECUTION. Observe the SAME actual cloned old foundation.
-- No target DDL, synthetic grant, migration edit, password or row body export.
select jsonb_build_object('scope','functions','value',coalesce(jsonb_agg(jsonb_build_object(
 'name',p.oid::regprocedure::text,'owner',pg_get_userbyid(p.proowner),'kind',p.prokind,
 'definer',p.prosecdef,'config',p.proconfig,'acl',p.proacl,'definition',pg_get_functiondef(p.oid)
) order by p.oid::regprocedure::text),'[]'::jsonb))
from pg_proc p join pg_namespace n on n.oid=p.pronamespace
where n.nspname in('public','auth') and p.prokind in('f','p');

select jsonb_build_object('scope','tables','value',coalesce(jsonb_agg(jsonb_build_object(
 'schema',n.nspname,'name',c.relname,'kind',c.relkind,'owner',pg_get_userbyid(c.relowner),
 'acl',c.relacl,'rls',c.relrowsecurity,'forceRls',c.relforcerowsecurity,
 'columns',(select jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),
  'notNull',a.attnotnull,'identity',a.attidentity,'generated',a.attgenerated,'default',pg_get_expr(d.adbin,d.adrelid)) order by a.attnum)
  from pg_attribute a left join pg_attrdef d on d.adrelid=a.attrelid and d.adnum=a.attnum
  where a.attrelid=c.oid and a.attnum>0 and not a.attisdropped)
) order by n.nspname,c.relname),'[]'::jsonb))
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname in('public','auth','storage') and c.relkind in('r','p');

select jsonb_build_object('scope','indexes','value',coalesce(jsonb_agg(jsonb_build_object(
 'table',t.oid::regclass::text,'name',i.relname,'definition',pg_get_indexdef(i.oid),
 'valid',x.indisvalid,'ready',x.indisready,'unique',x.indisunique
) order by t.oid::regclass::text,i.relname),'[]'::jsonb))
from pg_index x join pg_class i on i.oid=x.indexrelid join pg_class t on t.oid=x.indrelid
join pg_namespace n on n.oid=t.relnamespace where n.nspname in('public','auth','storage');

select jsonb_build_object('scope','constraints','value',coalesce(jsonb_agg(jsonb_build_object(
 'table',c.conrelid::regclass::text,'name',c.conname,'type',c.contype,'validated',c.convalidated,
 'deferrable',c.condeferrable,'deferred',c.condeferred,'definition',pg_get_constraintdef(c.oid)
) order by c.conrelid::regclass::text,c.conname),'[]'::jsonb))
from pg_constraint c join pg_namespace n on n.oid=c.connamespace where n.nspname in('public','auth','storage');

select jsonb_build_object('scope','triggers','value',coalesce(jsonb_agg(jsonb_build_object(
 'table',t.tgrelid::regclass::text,'name',t.tgname,'enabled',t.tgenabled,
 'function',t.tgfoid::regprocedure::text,'definition',pg_get_triggerdef(t.oid)
) order by t.tgrelid::regclass::text,t.tgname),'[]'::jsonb))
from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace
where not t.tgisinternal and n.nspname in('public','auth','storage');

select jsonb_build_object('scope','policies','value',coalesce(jsonb_agg(to_jsonb(p) order by p.schemaname,p.tablename,p.policyname),'[]'::jsonb))
from pg_policies p where schemaname in('public','auth','storage');

select jsonb_build_object('scope','roles','value',jsonb_agg(jsonb_build_object(
 'name',rolname,'superuser',rolsuper,'bypassRls',rolbypassrls,'canLogin',rolcanlogin,
 'inherit',rolinherit,'createDb',rolcreatedb,'createRole',rolcreaterole,'replication',rolreplication,'config',rolconfig
) order by rolname)) from pg_roles;

select jsonb_build_object('scope','publication21Triggers','value',coalesce(jsonb_agg(jsonb_build_object(
 'table',t.tgrelid::regclass::text,'name',t.tgname,'enabled',t.tgenabled,'definition',pg_get_triggerdef(t.oid)
) order by t.tgrelid::regclass::text,t.tgname),'[]'::jsonb))
from pg_trigger t where not t.tgisinternal and t.tgfoid='public.capture_public_build_outbox()'::regprocedure;

select jsonb_build_object('scope','targetPrivileges','value',jsonb_agg(jsonb_build_object(
 'table',c.oid::regclass::text,'role',role_name,
 'select',has_table_privilege(role_name,c.oid,'SELECT'),'insert',has_table_privilege(role_name,c.oid,'INSERT'),
 'update',has_table_privilege(role_name,c.oid,'UPDATE'),'delete',has_table_privilege(role_name,c.oid,'DELETE')
) order by c.oid::regclass::text,role_name))
from pg_class c cross join unnest(array['anon','authenticated','service_role']) role_name
where c.oid in('public.public_build_outbox'::regclass,'public.admin_audit_log'::regclass,
 'public.articles'::regclass,'public.pages'::regclass,'public.editor_autosaves'::regclass);
