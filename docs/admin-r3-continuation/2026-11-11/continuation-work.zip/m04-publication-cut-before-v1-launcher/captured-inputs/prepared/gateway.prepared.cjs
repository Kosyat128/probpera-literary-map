// PREPARED ONLY. Native SQL over an owned loopback cluster; controlled HTTP gateway.
// Owner reads canonical/legacy data are declared privilege adaptations, not grants.
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),assert=require('node:assert/strict');
const quote=value=>"'"+String(value).replaceAll("'","''")+"'";
function createGateway(config){
 assert.match(config.database,/^m04_cut_before_[a-z0-9_]{1,42}$/u);
 assert.equal(config.owned.port,55438);assert.equal(config.owned.listenAddress,'127.0.0.1');assert.equal(config.owned.service,false);
 const environment={};for(const key of ['SystemRoot','WINDIR','COMSPEC','PATH','PATHEXT','USERPROFILE','PROGRAMDATA','PROGRAMFILES','SYSTEMDRIVE'])if(process.env[key]!==undefined)environment[key]=process.env[key];
 environment.TEMP=config.output;environment.TMP=config.output;environment.PGCLIENTENCODING='UTF8';environment.PGOPTIONS='-c timezone=UTC -c statement_timeout=10000 -c lock_timeout=3000';
 const psql=path.join(config.owned.pgBin,'psql.exe'),baseArgs=['-h','127.0.0.1','-p','55438','-U','postgres','-d',config.database,'--no-psqlrc','--set=ON_ERROR_STOP=1','--quiet','--no-align','--tuples-only'];
 const trace={adaptation:'CONTROLLED_HTTP_WITH_NATIVE_FACTUAL_SQL; legacy/canonical reads fixture-owner, outbox read/update actual service_role',requests:[],commands:[]};let serial=0;
 function query(label,statement,{role,expectedError}={}){
  assert.match(label,/^[a-z0-9_-]+$/u);const name=config.tag+'-'+(++serial)+'-'+label,file=path.join(config.output,name+'.sql');
  assert.equal(fs.existsSync(file),false);fs.writeFileSync(file,"\\set VERBOSITY verbose\nset timezone='UTC';\n"+(role?'set role '+role+';\n':'')+statement+'\n');
  const args=[...baseArgs,'-f',file],result=cp.spawnSync(psql,args,{cwd:config.output,env:environment,windowsHide:true,timeout:15000,maxBuffer:8*1024*1024});
  fs.writeFileSync(path.join(config.output,name+'.stdout.raw.log'),result.stdout||Buffer.alloc(0));fs.writeFileSync(path.join(config.output,name+'.stderr.raw.log'),result.stderr||Buffer.alloc(0));
  const command={label,args,pid:result.pid,exitCode:result.status,signal:result.signal,error:result.error?.message??null};trace.commands.push(command);fs.writeFileSync(path.join(config.output,name+'.command.json'),JSON.stringify(command,null,2)+'\n');
  if(result.error)throw result.error;const stderr=(result.stderr||Buffer.alloc(0)).toString('utf8');
  if(expectedError){assert.notEqual(result.status,0);assert.match(stderr,new RegExp('\\b'+expectedError+'\\b','u'));return{expectedNativeError:expectedError,stderr};}
  assert.equal(result.status,0,label+': '+stderr);
  const rows=(result.stdout||Buffer.alloc(0)).toString('utf8').split(/\r?\n/u).filter(line=>line.startsWith('{')||line.startsWith('[')).map(line=>JSON.parse(line));
  assert.ok(rows.length,label+' missing native JSON');return rows.at(-1);
 }
 function safeHead(rows){assert.ok(Array.isArray(rows));for(const row of rows){assert.equal(typeof row.id,'number','Native REST ID adaptation must remain numeric');assert.ok(Number.isSafeInteger(row.id)&&row.id>0,'UNEXERCISED unsafe native head ID; do not silently cast to text');}return rows;}
 function response(value,status=200){return new Response(status===204?null:JSON.stringify(value),{status,headers:status===204?{}:{'content-type':'application/json'}});}
 async function fetchImpl(raw,options={}){
  const url=new URL(String(raw)),method=options.method||'GET';const request={url:url.href,method,headerNames:Object.keys(options.headers||{}),body:options.body?JSON.parse(options.body):null};trace.requests.push(request);
  if(url.origin==='https://api.github.com'){
   request.controlledExternalOnly=true;
   if(method==='GET'&&url.pathname.endsWith('/git/ref/heads/main'))return response({object:{sha:config.mainSha}});
   if(method==='GET'&&url.pathname.endsWith('/actions/workflows/deploy-pages.yml/runs'))return response({workflow_runs:[]});
   if(method==='POST'&&url.pathname.endsWith('/actions/workflows/deploy-pages.yml/dispatches'))return response(null,204);
   throw new Error('UNEXERCISED unknown GitHub control request: '+url.href);
  }
  assert.equal(url.origin,'https://fixture-probpera.supabase.co','Network is forbidden outside declared controlled origins');
  if(method==='GET'&&url.pathname==='/rest/v1/public_build_outbox'){
   assert.equal(url.searchParams.get('select'),'id');assert.equal(url.searchParams.get('order'),'id.desc');assert.equal(url.searchParams.get('limit'),'1');
   const rows=query('native-outbox-head',"select coalesce(jsonb_agg(jsonb_build_object('id',id)),'[]'::jsonb) from(select id from public.public_build_outbox order by id desc limit 1) x;",{role:'service_role'});
   request.nativeReaderRole='service_role';request.response=safeHead(rows);return response(rows);
  }
  if(method==='GET'&&url.pathname==='/rest/v1/admin_audit_log'){
   assert.equal(url.searchParams.get('select'),'id');assert.equal(url.searchParams.get('action'),'in.(public_build.requested,public_build.failed)');assert.equal(url.searchParams.get('order'),'id.desc');assert.equal(url.searchParams.get('limit'),'1');
   const rows=query('native-legacy-head-owner-adaptation',"select coalesce(jsonb_agg(jsonb_build_object('id',id)),'[]'::jsonb) from(select id from public.admin_audit_log where action in('public_build.requested','public_build.failed') order by id desc limit 1) x;");
   request.nativeReaderRole='postgres fixture-owner, explicit missing service privilege adaptation';request.response=safeHead(rows);return response(rows);
  }
  if(method==='PATCH'&&url.pathname==='/rest/v1/public_build_outbox'){
   assert.deepEqual([...url.searchParams.keys()].sort(),['id','status']);const match=/^lte\.([1-9]\d*)$/u.exec(url.searchParams.get('id')||'');assert.ok(match);
   assert.equal(url.searchParams.get('status'),'in.(requested,dispatched,failed)');assert.equal(request.body.status,'deployed');assert.deepEqual(Object.keys(request.body).sort(),['deployed_at','deployment_run_id','last_error','status']);assert.equal(request.body.last_error,null);
   if(config.pauseBeforePatch){assert.ok(process.send,'Timing gate needs an IPC-owned child');process.send({tag:'native-patch-ready',request});await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Native patch delivery gate timeout')),15000);process.once('message',m=>{clearTimeout(timer);m?.tag==='allow-native-patch'?resolve():reject(Error('Unexpected native gate release'))})});}
   const body=request.body,run=body.deployment_run_id===null?'null':quote(body.deployment_run_id);
   request.nativeWriteRole='service_role';request.nativeResult=query('actual-finalizer-patch',"with changed as(update public.public_build_outbox set status='deployed',deployed_at="+quote(body.deployed_at)+"::timestamptz,deployment_run_id="+run+",last_error=null where id<="+match[1]+"::bigint and status in('requested','dispatched','failed') returning id) select jsonb_build_object('changedIds',coalesce(jsonb_agg(id order by id),'[]'::jsonb)) from changed;",{role:'service_role'});
   return response(null,204);
  }
  throw new Error('UNEXERCISED unmapped controlled REST request: '+method+' '+url.href);
 }
 return{query,fetchImpl,trace,environment,baseArgs,psql};
}
module.exports={createGateway,quote};
