// PREPARED ONLY. No import side effects, SQL, provider calls or desired helper clone.
const assert = require('node:assert/strict');
const caseIds = Object.freeze([
  'lower-commit-before-head-guard',
  'lower-commit-after-guard-before-patch',
  'higher-commit-after-candidate',
  'committed-before-candidate',
  'duplicate-finalizer-callback',
  'trigger-and-explicit-coexist',
]);
function evaluate(result) {
  assert.ok(caseIds.includes(result.caseId));
  const checks = [];
  const check = (id, kind, pass, actual) => checks.push({ id, kind, pass: pass === true, actual });
  const lateLower = result.caseId.startsWith('lower-commit-');
  const higher = result.caseId === 'higher-commit-after-candidate';
  check('independent-native-transactions', 'PRECONDITION', result.aPid !== result.bPid && result.aPid > 0 && result.bPid > 0, { aPid: result.aPid, bPid: result.bPid });
  check('safe-numeric-native-head-ids', 'PRECONDITION', [result.aEventId, result.bEventId, Number(result.candidate.head.outboxHighWater)].every(v => typeof v === 'number' && Number.isSafeInteger(v) && v > 0), { a: result.aEventId, b: result.bEventId, head: result.candidate.head });
  check('native-source-committed', 'PRECONDITION', result.final.a.content_html === result.newA, result.final.a);
  check('actual-runtime-boundaries-reached', 'PRECONDITION', result.actualHeadFetch && result.actualGuardReached && result.actualCoalescerReached, result.runtime);
  check('outbox-native-service-permissions-preserved', 'PRESERVATION', result.servicePrivileges.select && result.servicePrivileges.update && result.servicePrivileges.insert === false && result.legacyServiceDeniedCode === '42501', result.servicePrivileges);
  if (lateLower) {
    check('lower-allocated-before-higher', 'PRECONDITION', result.aEventId < result.bEventId, { a: result.aEventId, b: result.bEventId });
    check('candidate-excludes-uncommitted-content', 'PRECONDITION', result.candidate.a.content_html === result.oldA && !result.candidate.visibleEventIds.includes(result.aEventId), result.candidate);
    check('higher-visible-at-candidate', 'PRECONDITION', result.candidate.visibleEventIds.includes(result.bEventId) && Number(result.candidate.head.outboxHighWater) >= result.bEventId, result.candidate.head);
    check('actual-finalizer-patch-reached', 'PRECONDITION', result.finalizer?.exitCode === 0 && result.finalizer?.patchCount === 1, result.finalizer);
    check('included-b-actually-acknowledged-by-patch', 'PRECONDITION', result.final.bEvent.status === 'deployed' && result.final.bEvent.deployed_at !== null && result.finalizer?.changedIds.includes(result.bEventId), { bEvent: result.final.bEvent, changedIds: result.finalizer?.changedIds });
    check('unseen-revision-not-acknowledged', 'M04-T12-CONTRACT', ['requested', 'dispatched', 'failed'].includes(result.final.aEvent.status) && result.final.aEvent.deployed_at === null, result.final.aEvent);
    if (result.caseId === 'lower-commit-after-guard-before-patch') {
      check('commit-is-between-guard-and-native-patch', 'PRECONDITION', result.order.indexOf('guard-and-coalescer-complete') < result.order.indexOf('actual-finalizer-patch-ready') && result.order.indexOf('actual-finalizer-patch-ready') < result.order.indexOf('a-committed') && result.order.indexOf('a-committed') < result.order.indexOf('allow-native-patch'), result.order);
    }
  } else if (higher) {
    check('higher-event-allocated-after-candidate', 'PRECONDITION', result.aEventId > Number(result.candidate.head.outboxHighWater), { event: result.aEventId, head: result.candidate.head });
    check('higher-event-detected-by-real-guard', 'PRESERVATION', result.guard.ok === false && /CMS advanced after the build snapshot/u.test(result.guard.message), result.guard);
    check('real-coalescer-retains-newer-revision', 'PRESERVATION', result.coalescer.safeToFinalize === false && result.coalescer.dispatched === true && result.coalescer.state === 'cms-followup-dispatched', result.coalescer);
    check('higher-event-remains-pending', 'M04-T12-CONTROL', result.final.aEvent.status === 'requested' && result.final.aEvent.deployed_at === null && result.finalizer === null, result.final.aEvent);
  } else {
    check('candidate-includes-both-pages', 'PRESERVATION', result.candidate.a.content_html === result.newA && result.candidate.b.content_html === result.newB && result.candidate.visibleEventIds.includes(result.aEventId) && result.candidate.visibleEventIds.includes(result.bEventId), result.candidate);
    check('actual-current-guard-and-coalescer-accept', 'PRESERVATION', result.guard.ok && result.coalescer.safeToFinalize === true && result.coalescer.dispatched === false, { guard: result.guard, coalescer: result.coalescer });
    check('included-pages-acknowledged', 'M04-T06-BOUNDED-CONTROL', result.final.aEvent.status === 'deployed' && result.final.bEvent.status === 'deployed', result.final);
  }
  if (result.caseId === 'duplicate-finalizer-callback') {
    check('duplicate-callback-idempotent', 'M04-T04-CONTROL', JSON.stringify(result.afterFirstFinalize) === JSON.stringify(result.final) && result.secondFinalizer.exitCode === 0 && result.secondFinalizer.changedIds.length === 0, result.secondFinalizer);
  }
  if (result.caseId === 'trigger-and-explicit-coexist') {
    check('distinct-trigger-and-explicit-events-preserved', 'PRESERVATION', result.explicitEventId !== result.aEventId && result.final.sameEntityEvents.some(e => e.id === result.explicitEventId && e.reason === 'manual-explicit') && result.final.sameEntityEvents.some(e => e.id === result.aEventId && e.reason === 'database-update') && result.final.sameEntityEvents.filter(e => e.id === result.explicitEventId || e.id === result.aEventId).every(e => e.status === 'deployed'), result.final.sameEntityEvents);
  }
  return checks.map(row => ({ caseId: result.caseId, ...row }));
}
module.exports = { caseIds, evaluate };
