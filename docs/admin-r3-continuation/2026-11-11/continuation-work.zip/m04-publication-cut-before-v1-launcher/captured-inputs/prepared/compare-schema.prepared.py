# PREPARED ONLY. Offline comparison of future actual JSONL observations; no DB.
from pathlib import Path
import json,sys,hashlib

def load(path):
    rows=[json.loads(line) for line in Path(path).read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]
    assert len(rows)==9 and len({r['scope'] for r in rows})==9
    return {r['scope']:r['value'] for r in rows}

def keyed(rows,fields):return {tuple(r[f] for f in fields):r for r in rows}
before=load(sys.argv[1]);after=load(sys.argv[2]);final=load(sys.argv[3])
assert after==final,'Fixture failure injection changed schema/ACL after rollback'
report={}
for scope,fields,new_allowed,changed_allowed in [
 ('functions',['name'],{'admit_public_build_retry(bigint,uuid,text)','guard_public_build_retry_identity()'},{'enqueue_public_build_request(text,text,text,jsonb)'}),
 ('indexes',['name'],{'public_build_outbox_retry_operation_uidx','public_build_outbox_retry_source_uidx'},set()),
 ('constraints',['table','name'],{'public_build_outbox_retry_identity_check','public_build_outbox_retry_source_fkey'},set()),
 ('triggers',['table','name'],{'public_build_outbox_retry_identity_guard'},set()),
]:
    old=keyed(before[scope],fields);new=keyed(after[scope],fields)
    assert old.keys()<=new.keys(),scope+' removed an old declaration'
    added=[key[-1] for key in new.keys()-old.keys()]
    changed=[key[-1] for key in old if old[key]!=new[key]]
    assert set(added)==new_allowed,(scope,added)
    assert set(changed)==changed_allowed,(scope,changed)
    report[scope]={'before':len(old),'after':len(new),'added':sorted(added),'changed':sorted(changed),'otherOldDeclarationsExact':True}

old=keyed(before['functions'],['name']);new=keyed(after['functions'],['name'])
enqueue='enqueue_public_build_request(text,text,text,jsonb)'
assert {k:v for k,v in old[(enqueue,)].items() if k!='definition'}=={k:v for k,v in new[(enqueue,)].items() if k!='definition'}
for name in ['admit_public_build_retry(bigint,uuid,text)','guard_public_build_retry_identity()']:
    assert new[(name,)]['definer'] is True and new[(name,)]['owner']=='postgres'
    assert new[(name,)]['config']==['search_path=""']

old=keyed(before['tables'],['schema','name']);new=keyed(after['tables'],['schema','name'])
assert old.keys()==new.keys(),'New queue/table is forbidden'
for key,row in old.items():
    next_row=new[key]
    if key!=('public','public_build_outbox'):assert row==next_row,key
    else:
        assert {k:v for k,v in row.items() if k!='columns'}=={k:v for k,v in next_row.items() if k!='columns'}
        columns={c['name']:c for c in row['columns']};next_columns={c['name']:c for c in next_row['columns']}
        assert columns.keys()<=next_columns.keys()
        assert set(next_columns)-set(columns)=={'retry_operation_id','retry_of_outbox_id'}
        assert all(c==next_columns[n] for n,c in columns.items())
        for name,typ in [('retry_operation_id','uuid'),('retry_of_outbox_id','bigint')]:
            c=next_columns[name];assert c['type']==typ and not c['notNull'] and c['default'] is None and c['identity']=='' and c['generated']==''
report['tables']={'before':len(old),'after':len(new),'newTables':0,'onlyOutboxTwoNullableColumnsAdded':True,'allOldColumnsOwnersACLAndRLSExact':True}
for scope in ['policies','roles','targetPrivileges','publication21Triggers']:
    assert before[scope]==after[scope],scope
    report[scope]={'before':len(before[scope]),'after':len(after[scope]),'byteEquivalentStructuredValues':True}
assert len(before['publication21Triggers'])==21
assert not any('status' in r['definition'] for r in after['indexes'] if r['name']=='public_build_outbox_retry_source_uidx')
result={'classification':'OFFLINE_COMPARISON_OF_ACTUAL_NATIVE_SAME_FOUNDATION_DECLARATIONS_NOT_MANAGED_STACK_OR_NEW_EXECUTION','pass':True,'scopes':report,
 'inputs':[{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in sys.argv[1:4]],
 'intentionalOldFunctionReplacement':'enqueue reservation rejection only; owner/security/search_path/ACL unchanged','fixtureSchemaAfterRollbackExact':True}
out=Path(sys.argv[4]);assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=True,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,ensure_ascii=True))
