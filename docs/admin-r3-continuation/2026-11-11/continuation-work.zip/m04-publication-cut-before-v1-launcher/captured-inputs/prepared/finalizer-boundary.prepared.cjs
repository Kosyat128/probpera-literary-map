// Declared delivery/process instrumentation only. Actual captured CLI is imported.
const fs=require('node:fs'),{pathToFileURL}=require('node:url');
const {createGateway}=require('./gateway.prepared.cjs');
const config=JSON.parse(fs.readFileSync(process.argv[2],'utf8')),gateway=createGateway(config);
process.env.SUPABASE_URL='https://fixture-probpera.supabase.co';process.env.SUPABASE_SERVICE_ROLE_KEY='fixture-key-not-a-secret';process.env.GITHUB_RUN_ID=config.runId;process.env.GITHUB_ACTIONS='true';process.env.GITHUB_OUTPUT='';
globalThis.fetch=gateway.fetchImpl;
process.argv=[process.execPath,config.finalizer,'--finalize='+config.marker];
process.on('exit',code=>fs.writeFileSync(config.traceOutput,JSON.stringify({classification:'ACTUAL_FINALIZER_CLI_WITH_DECLARED_NATIVE_SQL_GATEWAY_NOT_MANAGED_REST',exitCode:code,...gateway.trace},null,2)+'\n'));
import(pathToFileURL(config.finalizer).href).catch(error=>{fs.writeFileSync(config.failureOutput,JSON.stringify({classification:'SETUP_GATEWAY_OR_ACTUAL_CLI_FAILURE_TARGET_NOT_AUTOMATICALLY_EXERCISED',message:error.message,stack:error.stack},null,2)+'\n');process.exitCode=1});
