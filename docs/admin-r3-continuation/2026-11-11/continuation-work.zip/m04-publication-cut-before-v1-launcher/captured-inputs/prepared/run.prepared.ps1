param(
 [switch]$ExecuteOwned,
 [ValidateSet('M04Cut')][string]$Phase='M04Cut',
 [string]$Database,
 [string]$Output,
 [string]$Migration,
 [string]$MigrationSha256,
 [switch]$ExecuteRaces
)
# PREPARED TEXT ONLY / NEVER EXECUTED. Derived from actual completed seq lifecycle, with new low-ID clone and finite controlled publication-cut producer. Requires a NEW root native release.
# No old database, directory, migration, role or target-table definition is reset.
$ErrorActionPreference='Stop'
$work='C:\Users\Костя\Documents\Codex\2026-10-09\v\work'
$recipe=Join-Path $work 'next-m04-m20-real-foundation-sol'
$ownedPath=Join-Path $work 'site-copy-sql-native\owned-cluster.json'
$expectedData='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native\data'
$expectedBin='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\PORTAB~1\POSTGR~1.11-\pgsql\bin'
$expectedFoundation='7d04cd14f5386b16e737f2556c49d153165d07dabc988c7f849d9846d75bd25d'
if(-not $ExecuteOwned){
 [pscustomobject]@{classification='PREPARED_ONLY_NOT_EXECUTED';phase=$Phase;foundationSha256=$expectedFoundation;requiresRootNativeRelease=$true;databaseStarted=$false;databaseConnections=0;noDropOrReset=$true}|ConvertTo-Json
 return
}
if($PSVersionTable.PSVersion.Major -lt 7){throw 'Use PowerShell 7; do not run via Windows PowerShell 5'}
if($Database -notmatch '^m04_cut_before_[a-z0-9_]{1,42}$'){throw 'A NEW allowlisted database name is required'}
if(-not $Output){throw 'A fresh work output directory is required'}
if(-not $Migration -or $MigrationSha256 -notmatch '^[a-f0-9]{64}$'){throw 'Root-approved NEW migration file and exact frozen SHA are required'}
$migrationFull=[IO.Path]::GetFullPath($Migration)
$migrationRoot=[IO.Path]::GetFullPath((Join-Path (Split-Path $work -Parent) 'probpera-literary-map\supabase\migrations')).TrimEnd('\')+'\'
if(-not $migrationFull.StartsWith($migrationRoot,[StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $migrationFull -PathType Leaf)){throw 'Only the root-owned new repository migration is allowed'}
$baselineDatabase='m04m20_native_20261030_v2'
$outputFull=[IO.Path]::GetFullPath($Output)
$workFull=[IO.Path]::GetFullPath($work).TrimEnd('\')+'\'
if(-not $outputFull.StartsWith($workFull,[StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $outputFull)){throw 'Output must be a new directory inside work'}
if(-not (Test-Path -LiteralPath ([IO.Path]::GetDirectoryName($outputFull)) -PathType Container)){throw 'Output parent must already exist'}
New-Item -ItemType Directory -Path $outputFull|Out-Null
$childTemp=Join-Path $outputFull 'child-temp'
New-Item -ItemType Directory -Path $childTemp|Out-Null
$children=[Collections.Generic.List[object]]::new()
$deferredStreams=[Collections.Generic.List[object]]::new()
$runAt=[DateTime]::UtcNow
$startAttempted=$false;$confirmedOwnedPid=$null;$failure=$null;$phaseResult='NOT_RUN';$cleanup=$null;$finiteOracle=$null
function Write-Json($Name,$Value){$Value|ConvertTo-Json -Depth 30|Set-Content -LiteralPath(Join-Path $outputFull $Name) -Encoding utf8}
function Hash($Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Normal-Path([string]$Value){$Value.Trim().Replace('/','\').TrimEnd('\').ToLowerInvariant()}
function Listeners(){@([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners()|Where-Object Port -eq 55438|ForEach-Object{$_.ToString()})}
function Invoke-Child([string]$Executable,[string[]]$Arguments,[string]$Label,[int]$TimeoutMs=120000){
 $psi=[Diagnostics.ProcessStartInfo]::new()
 $psi.FileName=$Executable;$psi.WorkingDirectory=$outputFull;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
 $psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
 $psi.StandardOutputEncoding=[Text.UTF8Encoding]::new($false);$psi.StandardErrorEncoding=[Text.UTF8Encoding]::new($false)
 $psi.Environment.Clear()
 foreach($name in @('SystemRoot','WINDIR','COMSPEC','PATH','PATHEXT','USERPROFILE','PROGRAMDATA','PROGRAMFILES','SYSTEMDRIVE')){
  $value=[Environment]::GetEnvironmentVariable($name);if($null -ne $value){$psi.Environment[$name]=$value}
 }
 $psi.Environment['TEMP']=$childTemp;$psi.Environment['TMP']=$childTemp
 $psi.Environment['PGCLIENTENCODING']='UTF8';$psi.Environment['PGAPPNAME']='m04_cut_owned_'+$Label
 $psi.Environment['PGOPTIONS']='-c statement_timeout=60000 -c lock_timeout=10000'
 foreach($argument in $Arguments){$psi.ArgumentList.Add($argument)}
 $process=[Diagnostics.Process]::new();$process.StartInfo=$psi;$at=[DateTime]::UtcNow
 if(-not $process.Start()){throw ('Owned child did not start: '+$Label)}
 $stdoutTask=$process.StandardOutput.ReadToEndAsync();$stderrTask=$process.StandardError.ReadToEndAsync()
 $timedOut=-not $process.WaitForExit($TimeoutMs)
 if($timedOut){$process.Kill();$process.WaitForExit()}
 # pg_ctl can exit while its owned postmaster still inherits pipe handles.
 # Do not wait for server pipe EOF before SQL identity or the finally stop.
 $deferred=$Label -eq 'pg-start'
 if($deferred){
  $stdout='';$stderr=''
  $deferredStreams.Add([pscustomobject]@{label=$Label;stdoutTask=$stdoutTask;stderrTask=$stderrTask})
 }else{
  $stdout=$stdoutTask.Result;$stderr=$stderrTask.Result
  [IO.File]::WriteAllText((Join-Path $outputFull ($Label+'.stdout.log')),$stdout,[Text.UTF8Encoding]::new($false))
  [IO.File]::WriteAllText((Join-Path $outputFull ($Label+'.stderr.log')),$stderr,[Text.UTF8Encoding]::new($false))
 }
 $receipt=[pscustomobject]@{label=$Label;executable=$Executable;args=$Arguments;environmentNames=@($psi.Environment.Keys|Sort-Object);startedAt=$at.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');pid=$process.Id;exited=$process.HasExited;exitCode=$process.ExitCode;timedOut=$timedOut;pipeEofDeferredUntilOwnedStop=$deferred}
 $children.Add($receipt);Write-Json ($Label+'.command.json') $receipt
 if($timedOut){throw ('Owned child timeout: '+$Label)}
 return [pscustomobject]@{exitCode=$process.ExitCode;stdout=$stdout;stderr=$stderr}
}
function Checked([string]$Executable,[string[]]$Arguments,[string]$Label,[int]$TimeoutMs=120000){
 $result=Invoke-Child $Executable $Arguments $Label $TimeoutMs
 if($result.exitCode -ne 0){throw ('ENVIRONMENT_OR_FOUNDATION_FAILURE: '+$Label+' exit '+$result.exitCode)}
 return $result
}
function Psql-Args([string]$Db){@('-h','127.0.0.1','-p','55438','-U','postgres','-d',$Db,'--no-psqlrc','--set=ON_ERROR_STOP=1','--quiet','--no-align','--tuples-only')}
function Owned-Pid-Proof(){
 $pidFile=Join-Path $expectedData 'postmaster.pid'
 if(-not (Test-Path -LiteralPath $pidFile)){return $null}
 $lines=@(Get-Content -LiteralPath $pidFile)
 if($lines.Count -lt 6 -or $lines[0] -notmatch '^\d+$' -or $lines[2] -notmatch '^\d+$'){throw 'Malformed postmaster identity; refusing stop/restart'}
 $serverPid=[int]$lines[0]
 if((Normal-Path $lines[1]) -ne (Normal-Path $expectedData) -or [int]$lines[3] -ne 55438 -or $lines[5].Trim() -ne '127.0.0.1'){throw 'Postmaster identity does not match the owned loopback cluster'}
 $epoch=[DateTimeOffset]::FromUnixTimeSeconds([long]$lines[2]).UtcDateTime
 if($epoch -lt $runAt.AddSeconds(-5)){throw 'Postmaster predates this start attempt; refusing stop'}
 $server=Get-Process -Id $serverPid -ErrorAction Stop
 if($server.ProcessName -ne 'postgres'){throw 'Owned PID is not postgres'}
 if($null -ne $confirmedOwnedPid -and $serverPid -ne $confirmedOwnedPid){throw 'Owned PID changed; refusing stop'}
 return [pscustomobject]@{pid=$serverPid;dataDirectory=$lines[1];port=[int]$lines[3];listenAddress=$lines[5];startedAt=$epoch.ToString('o');processName=$server.ProcessName;processPath=$server.Path}
}
try{
 $owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
 if($owned.service -or $owned.port -ne 55438 -or $owned.listenAddress -ne '127.0.0.1' -or (Normal-Path $owned.dataDirectory) -ne (Normal-Path $expectedData) -or (Normal-Path $owned.pgBin) -ne (Normal-Path $expectedBin)){throw 'Unrecognized owned cluster descriptor'}
 if($MigrationSha256 -ne '91e11a46e6db2834cf69bf5dda41a40151195cc410be85ce549a3a083debd320' -or (Hash $migrationFull) -ne $MigrationSha256){throw 'Root-approved current migration source drift'}
 if($ExecuteRaces){throw 'ExecuteRaces is not part of this finite publication-cut fixture'}
 Copy-Item -LiteralPath $migrationFull -Destination(Join-Path $outputFull 'root-migration.input.sql')
 $inputs=Get-Content -LiteralPath(Join-Path $recipe 'recipe-inputs.json') -Raw|ConvertFrom-Json
 foreach($row in $inputs.inputs){if((Hash (Join-Path $recipe $row.file)) -ne $row.sha256){throw ('Prepared input drift: '+$row.file)}}
 if((Hash (Join-Path $recipe 'foundation.prepared.sql')) -ne $expectedFoundation){throw 'Wrong actual foundation'}
 $manifest=Get-Content -LiteralPath(Join-Path $recipe 'source-manifest.json') -Raw|ConvertFrom-Json
 $repo=Join-Path (Split-Path $work -Parent) 'probpera-literary-map'
 foreach($section in $manifest.foundation.exactSections){if((Hash (Join-Path $repo $section.file)) -ne $section.sha256){throw ('Old schema/migration source drift: '+$section.file)}}
 $previousExists=[bool](Get-Process -Id ([int]$owned.pid) -ErrorAction SilentlyContinue)
 $pidFileExists=Test-Path -LiteralPath(Join-Path $expectedData 'postmaster.pid')
 $beforeListeners=Listeners
 Write-Json 'preflight.json' ([pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');descriptor=$owned;descriptorSha256=(Hash $ownedPath);previousPidExists=$previousExists;pidFileExists=$pidFileExists;listenerEndpoints=$beforeListeners;foundationSha256=$expectedFoundation;database=$Database;oldSchemaFilesBound=$manifest.foundation.exactSections.Count})
 if($previousExists -or $pidFileExists -or $beforeListeners.Count -ne 0){throw 'Previous PID/pidfile/port is active; do not restart or kill it'}
 $pgCtl=Join-Path $expectedBin 'pg_ctl.exe';$psql=Join-Path $expectedBin 'psql.exe';$postgres=Join-Path $expectedBin 'postgres.exe'
 $node='C:\Users\Костя\Documents\Codex\tools\node-v24.18.1\node.exe'
 $python='C:\Users\Костя\AppData\Local\Programs\Python\Python314\python.exe'
 if(-not (Test-Path -LiteralPath $node -PathType Leaf) -or -not (Test-Path -LiteralPath $python -PathType Leaf)){throw 'Approved Node24.18.1/Python3.14 binary absent'}
 $nodeVersion=Checked $node @('--version') 'node-version'
 $pythonVersion=Checked $python @('--version') 'python-version'
 if($nodeVersion.stdout.Trim() -ne 'v24.18.1' -or $pythonVersion.stdout.Trim() -notmatch '^Python 3\.14\.'){throw 'Approved native fixture runtime version mismatch'}
 $null=Checked $node @('--check',(Join-Path $PSScriptRoot 'producer.prepared.cjs')) 'prepared-producer-syntax'
 $null=Checked $node @('--check',(Join-Path $PSScriptRoot 'oracle.prepared.cjs')) 'prepared-oracle-syntax'
 $null=Checked $node @('--check',(Join-Path $PSScriptRoot 'gateway.prepared.cjs')) 'prepared-gateway-syntax'
 $null=Checked $node @('--check',(Join-Path $PSScriptRoot 'finalizer-boundary.prepared.cjs')) 'prepared-finalizer-boundary-syntax'
 Write-Json 'prepared-input-bindings.json' (@(Get-ChildItem -LiteralPath $PSScriptRoot -File | Where-Object { $_.Name -ne 'ready.prepared.json' }) | ForEach-Object { [pscustomobject]@{file=$_.FullName;sha256=(Hash $_.FullName)} })
 Write-Json 'binary-bindings.json' (@($pgCtl,$psql,$postgres)|ForEach-Object{[pscustomobject]@{file=$_;sha256=(Hash $_)}})
 $version=Checked $postgres @('--version') 'postgres-version'
 if($version.stdout -notmatch '\b17\.11\b'){throw 'Expected existing PostgreSQL 17.11 binaries'}
 $startAttempted=$true
 $null=Checked $pgCtl @('-D',$expectedData,'-l',(Join-Path $outputFull 'postgres.log'),'-o','-h 127.0.0.1 -p 55438','-w','-t','20','start') 'pg-start' 30000
 $proof=Owned-Pid-Proof
 if($null -eq $proof){throw 'Started cluster has no verified owned identity'}
 $confirmedOwnedPid=$proof.pid;Write-Json 'started-owned-identity.json' $proof
 $identity=Checked $psql ((Psql-Args 'postgres')+@('-c',"select jsonb_build_object('dataDirectory',current_setting('data_directory'),'port',inet_server_port(),'address',inet_server_addr(),'version',current_setting('server_version'),'database',current_database())")) 'server-identity'
 $identityJson=$identity.stdout.Trim()|ConvertFrom-Json
 if((Normal-Path $identityJson.dataDirectory) -ne (Normal-Path $expectedData) -or $identityJson.port -ne 55438 -or $identityJson.address -ne '127.0.0.1' -or $identityJson.version -notmatch '^17\.11(?:\s|$)'){throw 'Server identity mismatch; no fixture SQL may run'}
 $owned.pid=$confirmedOwnedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $exists=Checked $psql ((Psql-Args 'postgres')+@('-c',"select count(*) from pg_database where datname='$Database'")) 'database-exists'
 if($exists.stdout.Trim() -ne '0'){throw 'Database exists; no reset/drop/clone is permitted'}
 $sourceExists=Checked $psql ((Psql-Args 'postgres')+@('-c',"select count(*) from pg_database where datname='$baselineDatabase'")) 'baseline-exists'
 if($sourceExists.stdout.Trim() -ne '1'){throw 'Actual retained baseline database is absent; do not synthesize another'}
 $sourceClients=Checked $psql ((Psql-Args 'postgres')+@('-c',"select count(*) from pg_stat_activity where datname='$baselineDatabase'")) 'baseline-client-count'
 if($sourceClients.stdout.Trim() -ne '0'){throw 'Baseline has an active client; do not clone/reset/restart'}
 $null=Checked $psql ((Psql-Args 'postgres')+@('-c',('create database "'+$Database+'" template "'+$baselineDatabase+'"'))) 'database-clone-new'
 $null=Checked $psql ((Psql-Args $Database)+@('-f',(Join-Path $PSScriptRoot 'schema-observation.prepared.sql'))) 'schema-before'
 $null=Checked $psql ((Psql-Args $Database)+@('-f',(Join-Path $PSScriptRoot 'baseline-readonly.prepared.sql'))) 'actual-baseline-readonly-precondition'
 $null=Checked $psql ((Psql-Args $Database)+@('--single-transaction','-f',(Join-Path $outputFull 'root-migration.input.sql'))) 'root-new-migration'
 $null=Checked $psql ((Psql-Args $Database)+@('-f',(Join-Path $PSScriptRoot 'schema-observation.prepared.sql'))) 'schema-after'
 $phaseResult='ACTUAL_OLD_BASELINE_CLONED_AND_ROOT_NEW_MIGRATION_APPLIED_NOT_YET_ACCEPTANCE'
 $null=Checked $node @((Join-Path $PSScriptRoot 'producer.prepared.cjs'),'--execute-owned','--owned',$ownedPath,'--database',$Database,'--output',(Join-Path $outputFull 'controlled-cases')) 'actual-publication-cut-cases' 240000
 $probeReportPath=Join-Path $outputFull 'controlled-cases\report.json'
 if(-not (Test-Path -LiteralPath $probeReportPath -PathType Leaf)){throw 'Controlled producer lacks actual finite-oracle report; completion is unconfirmed'}
 $probeReport=Get-Content -LiteralPath $probeReportPath -Raw|ConvertFrom-Json
 $finiteOracle=[pscustomobject]@{report=$probeReportPath;reportSha256=(Hash $probeReportPath);executionVerdict=$probeReport.executionVerdict;oracleVerdict=$probeReport.oracleVerdict;checks=$probeReport.checks;passed=$probeReport.passed;failed=$probeReport.failed;preconditionFailures=$probeReport.preconditionFailures;completionIsNotAcceptance=$true;acceptanceStatus='NOT_CLAIMED'}
 Write-Json 'finite-oracle-verdict.json' $finiteOracle
 if($probeReport.executionVerdict -ne 'COMPLETED' -or $probeReport.preconditionFailures -ne 0 -or $probeReport.oracleVerdict.status -notin @('FAIL_GENUINE_BEFORE_FINITE_CONTRACT','PASS_BOUNDED_FINITE_ORACLE_ONLY')){throw 'Controlled setup or finite report is incomplete; no product verdict is authorized'}
 if((Hash $migrationFull) -ne $MigrationSha256){throw 'Root migration changed during controlled execution'}
 $null=Checked $psql ((Psql-Args $Database)+@('-f',(Join-Path $PSScriptRoot 'schema-observation.prepared.sql'))) 'schema-after-fixtures'
 $null=Checked $python @((Join-Path $PSScriptRoot 'compare-schema.prepared.py'),(Join-Path $outputFull 'schema-before.stdout.log'),(Join-Path $outputFull 'schema-after.stdout.log'),(Join-Path $outputFull 'schema-after-fixtures.stdout.log'),(Join-Path $outputFull 'schema-comparison.json')) 'schema-comparison'
 $phaseResult='GENUINE_BEFORE_EXECUTION_COMPLETED_'+$probeReport.oracleVerdict.status+'_NOT_ACCEPTANCE'
}catch{
 $failure=[pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');classification='SETUP_OR_FOUNDATION_OR_NATIVE_EXECUTION_FAILURE_REQUIRES_REVIEW_NOT_AUTOMATIC_APP_DEFECT';message=$_.Exception.Message;detail=$_.ToString()}
 Write-Json 'failure.json' $failure
}finally{
 try{
  if($startAttempted){
   $finalProof=Owned-Pid-Proof
   if($null -ne $finalProof){
    if($null -eq $confirmedOwnedPid){$confirmedOwnedPid=$finalProof.pid}
    $stop=Invoke-Child (Join-Path $expectedBin 'pg_ctl.exe') @('-D',$expectedData,'-m','fast','-w','-t','20','stop') 'pg-stop' 30000
    if($stop.exitCode -ne 0){throw 'Owned pg_ctl stop failed'}
   }
  }
  $remainingPid=if($null -eq $confirmedOwnedPid){$null}else{[bool](Get-Process -Id $confirmedOwnedPid -ErrorAction SilentlyContinue)}
  $cleanup=[pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');startAttempted=$startAttempted;ownedPid=$confirmedOwnedPid;ownedProcessRemains=$remainingPid;pidFileRemains=(Test-Path -LiteralPath(Join-Path $expectedData 'postmaster.pid'));listenerEndpoints=(Listeners);allLaunchedClientsExited=(@($children|Where-Object{-not $_.exited}).Count -eq 0);serviceCreated=$false;oldDatabaseDropped=$false;filesDeleted=$false}
  Write-Json 'cleanup.json' $cleanup
  if($startAttempted -and ($cleanup.ownedProcessRemains -or $cleanup.pidFileRemains -or $cleanup.listenerEndpoints.Count -ne 0)){throw 'Cleanup liveness is not terminal; no restart is authorized'}
 }catch{
  Write-Json 'cleanup-failure.json' ([pscustomobject]@{classification='OWNED_CLEANUP_UNCONFIRMED_STOP_AND_REVIEW';atUtc=[DateTime]::UtcNow.ToString('o');message=$_.Exception.Message})
  if($null -eq $failure){$failure=[pscustomobject]@{classification='CLEANUP_FAILURE';message=$_.Exception.Message}}
 }
 foreach($stream in $deferredStreams){
  $stdoutDone=$stream.stdoutTask.Wait(5000);$stderrDone=$stream.stderrTask.Wait(5000)
  if($stdoutDone -and $stderrDone){
   [IO.File]::WriteAllText((Join-Path $outputFull ($stream.label+'.stdout.log')),$stream.stdoutTask.Result,[Text.UTF8Encoding]::new($false))
   [IO.File]::WriteAllText((Join-Path $outputFull ($stream.label+'.stderr.log')),$stream.stderrTask.Result,[Text.UTF8Encoding]::new($false))
  }else{
   Write-Json ($stream.label+'.pipe-eof-unconfirmed.json') ([pscustomobject]@{afterOwnedStop=$true;stdoutDone=$stdoutDone;stderrDone=$stderrDone;noFurtherRestartAllowed=$true})
   if($null -eq $failure){$failure=[pscustomobject]@{classification='OWNED_START_PIPE_EOF_UNCONFIRMED';message='Pipe EOF remained open after cleanup; retain original process evidence'}}
  }
 }
 Write-Json 'run-receipt.json' ([pscustomobject]@{classification=$phaseResult;startedAt=$runAt.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');phase=$Phase;database=$Database;baselineTemplate=$baselineDatabase;rootMigrationSha256=$MigrationSha256;executeRaces=[bool]$ExecuteRaces;finiteOracle=$finiteOracle;completionIsNotAcceptance=$true;acceptanceStatus='NOT_CLAIMED';failure=$failure;cleanup=$cleanup;children=$children;providerCalls=0;productionConnections=0;managedAuthPostgrestE2EClaim=$false})
}
if($null -ne $failure){throw ('Owned native run failed; original receipts retained: '+$failure.message)}
