// Parent-only prepared launcher. No execution until explicit release after final V2 verification.
import fs from 'node:fs/promises';import path from 'node:path';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));if(process.argv.length!==3||process.argv[2]!=='--execute-controlled')throw Error('PREPARED ONLY: parent release required');
const output=path.join(path.dirname(here),'m19-creator-before-'+new Date().toISOString().replaceAll(':','-').replaceAll('.','-')),logs=output+'-launcher';await fs.mkdir(logs,{recursive:false});
const allowed=/^(?:PATH|SystemRoot|windir|TEMP|TMP|USERPROFILE|HOMEDRIVE|HOMEPATH|APPDATA|LOCALAPPDATA|PROGRAMFILES|PROGRAMFILES\(X86\)|PROGRAMDATA|COMSPEC|PATHEXT|NUMBER_OF_PROCESSORS|PROCESSOR_ARCHITECTURE)$/iu;
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>allowed.test(key)));env.CI='1';env.NODE_ENV='test';
const args=[path.join(here,'producer.mjs'),'--execute-controlled','--output='+output],startedAt=new Date().toISOString();
const child=spawn(process.execPath,args,{cwd:path.dirname(path.dirname(here)),env,stdio:['ignore','pipe','pipe'],windowsHide:true});const stdout=[],stderr=[];child.stdout.on('data',bytes=>stdout.push(bytes));child.stderr.on('data',bytes=>stderr.push(bytes));let error=null;child.on('error',value=>{error={name:value.name,message:value.message};});
const exitCode=await new Promise(resolve=>child.on('close',resolve));await fs.writeFile(path.join(logs,'stdout.log'),Buffer.concat(stdout));await fs.writeFile(path.join(logs,'stderr.log'),Buffer.concat(stderr));
const receipt={classification:'ACTUAL_PRODUCER_LAUNCH_NOT_AUTOMATIC_PRODUCT_VERDICT',startedAt,finishedAt:new Date().toISOString(),args,output,exitCode,error,environment:{scope:'OS-only plus CI/NODE_ENV',keys:Object.keys(env).sort(),secretValuesCaptured:false}};
await fs.writeFile(path.join(logs,'receipt.json'),JSON.stringify(receipt,null,2));process.stdout.write(JSON.stringify({output,logs,exitCode,error})+'\n');process.exitCode=exitCode===0?0:exitCode===1?1:2;
