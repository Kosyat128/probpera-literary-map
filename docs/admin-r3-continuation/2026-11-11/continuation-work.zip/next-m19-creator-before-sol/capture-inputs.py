"""Prepare metadata/copies only. No application import, compiler, browser or server execution."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re
HERE=Path(__file__).resolve().parent;WORK=HERE.parent;REPO=WORK.parent/'probpera-literary-map'
M20=WORK/'next-m20-page-actor-before-sol';PLAN=WORK/'m19-next-source-preparation/plan.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
base=json.loads((M20/'inputs.freeze.json').read_bytes());plan=json.loads(PLAN.read_bytes())
assert len(plan['sources'])==12 and base['validationSourceSha256']==plan['sourceFingerprint']
capture=HERE/'captured-current';roles={r['file']:set(r['roles'])|{'reused-M20-prepared-source-not-claimed-executed'} for r in base['sources']}
for r in plan['sources']:
 data=(REPO/r['file']).read_bytes();original=(PLAN.parent/'sources'/r['file']).read_bytes()
 assert data==original and len(data)==r['bytes'] and sha(data)==r['sha256'],r['file']
 roles.setdefault(r['file'],set()).add('root-M19-original12-current-reference-capture')
pending=['apps/admin/components/PageEditorLoader.tsx','apps/admin/lib/page-load-validation.ts'];seen=set();edges=[]
imports=re.compile(r'''(?:\bfrom\s+|\bimport\s*\(\s*|\brequire\s*\(\s*|\bimport\s+)(["'])([^"']+)\1''')
def resolve(request,parent):
 if request.startswith('@/'):target=REPO/'apps/admin'/request[2:]
 elif request.startswith('.'):target=(REPO/parent).parent/request
 else:return None
 for suffix in ['','.ts','.tsx','.js','.jsx','.json','/index.ts','/index.tsx']:
  p=Path(str(target)+suffix).resolve()
  if p.is_file():return p.relative_to(REPO.resolve()).as_posix()
 raise RuntimeError(f'Unresolved source {request} from {parent}')
while pending:
 name=pending.pop()
 if name in seen:continue
 seen.add(name);roles.setdefault(name,set()).add('M19-route-compatible-browser-static-candidate')
 for match in imports.finditer((REPO/name).read_text(encoding='utf-8-sig')):
  target=resolve(match[2],name)
  if target:edges.append({'from':name,'request':match[2],'to':target});pending.append(target)
frozen=json.loads(Path(base['frozenSnapshot']).read_bytes());frozen={r['path']:r for r in frozen['files']}
rows=[]
for name in sorted(roles):
 data=(REPO/name).read_bytes();r=frozen[name];assert len(data)==r['size'] and sha(data)==r['sha256']
 if name in {r['file'] for r in base['sources']}:
  prior=next(r for r in base['sources'] if r['file']==name);assert len(data)==prior['bytes'] and sha(data)==prior['sha256']
  assert (Path(base['captureRoot'])/name).read_bytes()==data,'Reused M20 captured source changed: '+name
 target=capture/name;target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==data
 else:target.write_bytes(data)
 rows.append({'file':name,'bytes':len(data),'sha256':sha(data),'roles':sorted(roles[name])})
dependencies=[]
for name in ['action-runtime.cjs','inputs.freeze.json','ready.json','producer.mjs','entry.jsx','launch.mjs','fixture-plan.json','capture-inputs.py']:
 data=(M20/name).read_bytes();dependencies.append({'file':str(M20/name),'bytes':len(data),'sha256':sha(data),'role':'immutable-prepared-M20-dependency-or-nonmodified-guard'})
receipt={'classification':'PREPARED_NOT_EXECUTED_M19_CREATOR_AND_REAL_READ_GUARD_LOADER_BOUNDARY',
 'preparedAt':datetime.now(timezone.utc).isoformat(),'repo':str(REPO),'captureRoot':str(capture),'sourceFingerprint':plan['sourceFingerprint'],
 'rootPlan':{'file':str(PLAN),'bytes':PLAN.stat().st_size,'sha256':sha(PLAN.read_bytes())},'rootOriginalSourceCount':12,
 'sources':rows,'sourceCount':len(rows),'packages':base['packages'],'M20dependencies':dependencies,'additionalStaticEdges':edges,
 'guardQualifier':'The actual canEditPageBundle/read-validation may reject the creator row before PageEditor mounts. Targets report that guarded unavailability/payload incoherence; no raw mount bypass or silent data-loss claim.',
 'execution':{'compile':'NOT_RUN','browser':'NOT_RUN','server':'NOT_STARTED','appImport':'NOT_RUN','DB':'NOT_STARTED','tests':'NOT_RUN'}}
out=HERE/'inputs.freeze.json';data=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode()
if out.exists():
 prior=json.loads(out.read_bytes());assert prior['sources']==rows and prior['M20dependencies']==dependencies
else:out.write_bytes(data)
print(json.dumps({'file':str(out),'sha256':sha(out.read_bytes()),'sources':len(rows),'root12Preserved':True,'M20unchanged':True,'executed':False}))
