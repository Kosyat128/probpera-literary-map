// No action without the future explicit parent release flag. Sanitizes child env; no credentials are read or printed.
import fs from 'node:fs/promises';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
if(process.argv.length!==3||process.argv[2]!=='--execute-controlled')throw Error('PREPARED ONLY: await parent release, then pass --execute-controlled');
const suffix=new Date().toISOString().replaceAll(':','-').replaceAll('.','-');
const output=path.join(path.dirname(here),'m20-page-actor-before-'+suffix);
const logDirectory=output+'-launcher';await fs.mkdir(logDirectory,{recursive:false});
const allowed=new Set(['SYSTEMROOT','WINDIR','PATH','PATHEXT','COMSPEC','SYSTEMDRIVE','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMFILES','PROGRAMFILES(X86)']);
const environment={};for(const [key,value]of Object.entries(process.env))if(allowed.has(key.toUpperCase())&&typeof value==='string')environment[key]=value;
environment.CI='1';environment.NODE_ENV='test';
const args=[path.join(here,'producer.mjs'),'--execute-controlled','--output='+output];
const startedAt=new Date().toISOString();
const child=spawn(process.execPath,args,{cwd:path.dirname(path.dirname(here)),env:environment,stdio:['ignore','pipe','pipe'],windowsHide:true});
const stdout=[],stderr=[];child.stdout.on('data',chunk=>stdout.push(chunk));child.stderr.on('data',chunk=>stderr.push(chunk));
let error=null;child.on('error',value=>{error={name:value.name,message:value.message};});
const exitCode=await new Promise(resolve=>child.on('close',resolve));
await fs.writeFile(path.join(logDirectory,'stdout.log'),Buffer.concat(stdout));await fs.writeFile(path.join(logDirectory,'stderr.log'),Buffer.concat(stderr));
const receipt={classification:'ACTUAL_CONTROLLED_BEFORE_PRODUCER_LAUNCH_NOT_A_PRODUCT_VERDICT',startedAt,finishedAt:new Date().toISOString(),
  executable:process.execPath,args,cwd:path.dirname(path.dirname(here)),output,exitCode,error,
  environment:{scope:'OS variables only plus CI=1/NODE_ENV=test',keys:Object.keys(environment).sort(),secretValuesCaptured:false}};
await fs.writeFile(path.join(logDirectory,'receipt.json'),JSON.stringify(receipt,null,2));
process.stdout.write(JSON.stringify({output,launcherReceipt:path.join(logDirectory,'receipt.json'),exitCode,error})+'\n');
process.exitCode=exitCode===0?0:exitCode===1?1:2;
