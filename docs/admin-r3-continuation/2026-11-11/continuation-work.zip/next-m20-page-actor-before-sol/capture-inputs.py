"""Parent-only metadata preparation. Does not load JS, bundle, start services or run tests."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent / 'probpera-literary-map'
SNAPSHOT = HERE.parent / 'm04-m20-final-validation-v1/source-before.json'
CAPTURE = HERE / 'captured-current'
EXPECTED = 'd2c8d66694778b8b8ad92a210ab48d116c6d63f1f7f2b7640b04077c13e8b5a2'
ROOTS = {
    'browser': ['apps/admin/components/PageEditor.tsx'],
    'server': ['apps/admin/app/(dashboard)/pages/actions.ts'],
}
BOUNDARIES = {
    'browser': {
        'apps/admin/app/(dashboard)/pages/actions.ts',
        'apps/admin/app/(dashboard)/editor-links/actions.ts',
        'apps/admin/app/(dashboard)/editor-autosave/actions.ts',
    },
    'server': {
        'apps/admin/lib/auth.ts', 'apps/admin/lib/supabase/server.ts',
        'apps/admin/lib/env.ts', 'apps/admin/lib/auto-translate-published-article-premium.ts',
    },
}
IMPORT = re.compile(r'''(?:\bfrom\s+|\bimport\s*\(\s*|\brequire\s*\(\s*|\bimport\s+)(["'])([^"']+)\1''')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def binding(file):
    data = (REPO / file).read_bytes()
    return {'file': file, 'bytes': len(data), 'sha256': digest(data)}

def resolve(request, parent):
    if request.startswith('@/'):
        target = REPO / 'apps/admin' / request[2:]
    elif request.startswith('.'):
        target = (REPO / parent).parent / request
    else:
        return None
    for suffix in ['', '.ts', '.tsx', '.js', '.jsx', '.json', '/index.ts', '/index.tsx', '/index.js']:
        actual = Path(str(target) + suffix).resolve()
        if actual.is_file():
            return actual.relative_to(REPO.resolve()).as_posix()
    raise RuntimeError(f'Unresolved static local import {request} from {parent}')

snapshot_bytes = SNAPSHOT.read_bytes()
snapshot = json.loads(snapshot_bytes.decode('utf-8-sig'))
assert snapshot['validationSourceSha256'] == EXPECTED
frozen = {row['path']: row for row in snapshot['files']}
roles, edges, external = {}, [], set()
for role, roots in ROOTS.items():
    pending, seen = list(roots), set()
    while pending:
        file = pending.pop()
        if file in seen:
            continue
        seen.add(file)
        boundary = file in BOUNDARIES[role]
        roles.setdefault(file, set()).add(role + ('-boundary-reference' if boundary else '-static-candidate'))
        if boundary:
            continue
        source = (REPO / file).read_text(encoding='utf-8-sig')
        for match in IMPORT.finditer(source):
            request = match[2]
            target = resolve(request, file)
            if target:
                edges.append({'scope': role, 'from': file, 'request': request, 'to': target})
                pending.append(target)
            else:
                external.add(request)

references = [
    'apps/admin/tests/browser/page-form-browser.mjs',
    'apps/admin/tests/browser/fixtures/page-form-entry.jsx',
    'apps/admin/tests/browser/article-operation-browser.mjs',
    'apps/admin/tests/browser/fixtures/article-operation-entry.jsx',
    'apps/admin/app/(dashboard)/pages/page-operation-server.integration.test.ts',
]
for file in references:
    roles.setdefault(file, set()).add('historical-mechanism-reference-only-not-executed')

rows = []
for file in sorted(roles):
    row = binding(file)
    native = frozen.get(file)
    assert native and native['size'] == row['bytes'] and native['sha256'] == row['sha256'], file
    target = CAPTURE / file
    target.parent.mkdir(parents=True, exist_ok=True)
    data = (REPO / file).read_bytes()
    if target.exists():
        assert target.read_bytes() == data, f'Would overwrite a different capture: {file}'
    else:
        target.write_bytes(data)
    rows.append({**row, 'roles': sorted(roles[file]), 'matchesFrozen': True})

package_files = ['package.json', 'apps/admin/package.json', 'package-lock.json', 'pnpm-lock.yaml']
package_names = ['next', 'react', 'react-dom', 'typescript', 'esbuild', 'playwright',
                 '@supabase/supabase-js', 'zod', '@tiptap/core', '@tiptap/react', '@tiptap/starter-kit',
                 'sanitize-html']
packages = []
for file in package_files:
    if (REPO / file).is_file():
        packages.append(binding(file))
for name in package_names:
    candidates = [REPO / 'node_modules' / name / 'package.json', REPO / 'apps/admin/node_modules' / name / 'package.json']
    actual = next((item for item in candidates if item.is_file()), None)
    if actual is None:
        raise RuntimeError(f'Installed package manifest unavailable: {name}')
    data = actual.read_bytes()
    parsed = json.loads(data)
    packages.append({'file': actual.relative_to(REPO).as_posix(), 'bytes': len(data), 'sha256': digest(data),
                     'name': parsed.get('name'), 'version': parsed.get('version')})

receipt = {
    'classification': 'PREPARED_NOT_EXECUTED_CURRENT_GENUINE_BEFORE_NO_DEFECT_INFERENCE',
    'preparedAt': datetime.now(timezone.utc).isoformat(),
    'repo': str(REPO), 'captureRoot': str(CAPTURE),
    'frozenSnapshot': str(SNAPSHOT), 'frozenSnapshotSha256': digest(snapshot_bytes),
    'validationSourceSha256': EXPECTED, 'sourceCount': len(rows), 'sources': rows,
    'staticEdges': sorted(edges, key=lambda row: (row['scope'], row['from'], row['request'])),
    'externalImportNames': sorted(external), 'packages': packages,
    'staticCoverageQualification': 'Conservative literal-import closure, including type-only imports. Actual runtime/bundle source reads are recorded only after an authorized future execution. Boundary/reference files are not claimed as executed.',
    'execution': {'compile': 'NOT_RUN', 'bundle': 'NOT_RUN', 'browser': 'NOT_RUN', 'server': 'NOT_STARTED', 'db': 'NOT_STARTED', 'tests': 'NOT_RUN'},
    'proofLevels': ['Actual component/action/installed SDK controlled transport is planned.',
                    'No native DB commit/concurrency, managed Auth/RLS, Next RSC transport, full module acceptance or current defect has been established.'],
}
output = HERE / 'inputs.freeze.json'
if output.exists():
    previous = json.loads(output.read_text(encoding='utf-8'))
    assert previous['sources'] == receipt['sources'] and previous['packages'] == receipt['packages'], 'Frozen inputs changed; prepare a new version directory.'
else:
    output.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'classification': receipt['classification'], 'sources': len(rows), 'packages': len(packages), 'freeze': str(output), 'sha256': digest(output.read_bytes())}))
