param(
 [switch]$ExecuteOwned,
 [ValidateSet('FoundationOnly','M20')][string]$Phase='FoundationOnly',
 [string]$Database,
 [string]$Output
)
# PREPARED TEXT ONLY. Do not execute until the root agent releases native work.
# No old database, directory, migration, role or target-table definition is reset.
$ErrorActionPreference='Stop'
$work='C:\Users\Костя\Documents\Codex\2026-10-09\v\work'
$recipe=Join-Path $work 'next-m04-m20-real-foundation-sol'
$ownedPath=Join-Path $work 'site-copy-sql-native\owned-cluster.json'
$expectedData='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\site-copy-sql-native\data'
$expectedBin='C:\Users\685F~1\DOCUME~1\Codex\2026-1~1\v\work\PORTAB~1\POSTGR~1.11-\pgsql\bin'
$expectedFoundation='7d04cd14f5386b16e737f2556c49d153165d07dabc988c7f849d9846d75bd25d'
if(-not $ExecuteOwned){
 [pscustomobject]@{classification='PREPARED_ONLY_NOT_EXECUTED';phase=$Phase;foundationSha256=$expectedFoundation;requiresRootNativeRelease=$true;databaseStarted=$false;databaseConnections=0;noDropOrReset=$true}|ConvertTo-Json
 return
}
if($PSVersionTable.PSVersion.Major -lt 7){throw 'Use PowerShell 7; do not run via Windows PowerShell 5'}
if($Database -notmatch '^m04m20_native_[a-z0-9_]{1,48}$'){throw 'A NEW allowlisted database name is required'}
if(-not $Output){throw 'A fresh work output directory is required'}
$outputFull=[IO.Path]::GetFullPath($Output)
$workFull=[IO.Path]::GetFullPath($work).TrimEnd('\')+'\'
if(-not $outputFull.StartsWith($workFull,[StringComparison]::OrdinalIgnoreCase) -or (Test-Path -LiteralPath $outputFull)){throw 'Output must be a new directory inside work'}
if(-not (Test-Path -LiteralPath ([IO.Path]::GetDirectoryName($outputFull)) -PathType Container)){throw 'Output parent must already exist'}
New-Item -ItemType Directory -Path $outputFull|Out-Null
$childTemp=Join-Path $outputFull 'child-temp'
New-Item -ItemType Directory -Path $childTemp|Out-Null
$children=[Collections.Generic.List[object]]::new()
$runAt=[DateTime]::UtcNow
$startAttempted=$false;$confirmedOwnedPid=$null;$failure=$null;$phaseResult='NOT_RUN';$cleanup=$null
function Write-Json($Name,$Value){$Value|ConvertTo-Json -Depth 30|Set-Content -LiteralPath(Join-Path $outputFull $Name) -Encoding utf8}
function Hash($Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Normal-Path([string]$Value){$Value.Trim().Replace('/','\').TrimEnd('\').ToLowerInvariant()}
function Listeners(){@([Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties().GetActiveTcpListeners()|Where-Object Port -eq 55438|ForEach-Object{$_.ToString()})}
function Invoke-Child([string]$Executable,[string[]]$Arguments,[string]$Label,[int]$TimeoutMs=120000){
 $psi=[Diagnostics.ProcessStartInfo]::new()
 $psi.FileName=$Executable;$psi.WorkingDirectory=$outputFull;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
 $psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
 $psi.StandardOutputEncoding=[Text.UTF8Encoding]::new($false);$psi.StandardErrorEncoding=[Text.UTF8Encoding]::new($false)
 $psi.Environment.Clear()
 foreach($name in @('SystemRoot','WINDIR','COMSPEC','PATH','PATHEXT','USERPROFILE','PROGRAMDATA','PROGRAMFILES','SYSTEMDRIVE')){
  $value=[Environment]::GetEnvironmentVariable($name);if($null -ne $value){$psi.Environment[$name]=$value}
 }
 $psi.Environment['TEMP']=$childTemp;$psi.Environment['TMP']=$childTemp
 $psi.Environment['PGCLIENTENCODING']='UTF8';$psi.Environment['PGAPPNAME']='m04m20_owned_'+$Label
 $psi.Environment['PGOPTIONS']='-c statement_timeout=60000 -c lock_timeout=10000'
 foreach($argument in $Arguments){$psi.ArgumentList.Add($argument)}
 $process=[Diagnostics.Process]::new();$process.StartInfo=$psi;$at=[DateTime]::UtcNow
 if(-not $process.Start()){throw ('Owned child did not start: '+$Label)}
 $stdoutTask=$process.StandardOutput.ReadToEndAsync();$stderrTask=$process.StandardError.ReadToEndAsync()
 $timedOut=-not $process.WaitForExit($TimeoutMs)
 if($timedOut){$process.Kill();$process.WaitForExit()}
 $stdout=$stdoutTask.Result;$stderr=$stderrTask.Result
 [IO.File]::WriteAllText((Join-Path $outputFull ($Label+'.stdout.log')),$stdout,[Text.UTF8Encoding]::new($false))
 [IO.File]::WriteAllText((Join-Path $outputFull ($Label+'.stderr.log')),$stderr,[Text.UTF8Encoding]::new($false))
 $receipt=[pscustomobject]@{label=$Label;executable=$Executable;args=$Arguments;environmentNames=@($psi.Environment.Keys|Sort-Object);startedAt=$at.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');pid=$process.Id;exited=$process.HasExited;exitCode=$process.ExitCode;timedOut=$timedOut}
 $children.Add($receipt);Write-Json ($Label+'.command.json') $receipt
 if($timedOut){throw ('Owned child timeout: '+$Label)}
 return [pscustomobject]@{exitCode=$process.ExitCode;stdout=$stdout;stderr=$stderr}
}
function Checked([string]$Executable,[string[]]$Arguments,[string]$Label,[int]$TimeoutMs=120000){
 $result=Invoke-Child $Executable $Arguments $Label $TimeoutMs
 if($result.exitCode -ne 0){throw ('ENVIRONMENT_OR_FOUNDATION_FAILURE: '+$Label+' exit '+$result.exitCode)}
 return $result
}
function Psql-Args([string]$Db){@('-h','127.0.0.1','-p','55438','-U','postgres','-d',$Db,'--no-psqlrc','--set=ON_ERROR_STOP=1','--quiet','--no-align','--tuples-only')}
function Owned-Pid-Proof(){
 $pidFile=Join-Path $expectedData 'postmaster.pid'
 if(-not (Test-Path -LiteralPath $pidFile)){return $null}
 $lines=@(Get-Content -LiteralPath $pidFile)
 if($lines.Count -lt 6 -or $lines[0] -notmatch '^\d+$' -or $lines[2] -notmatch '^\d+$'){throw 'Malformed postmaster identity; refusing stop/restart'}
 $serverPid=[int]$lines[0]
 if((Normal-Path $lines[1]) -ne (Normal-Path $expectedData) -or [int]$lines[3] -ne 55438 -or $lines[5].Trim() -ne '127.0.0.1'){throw 'Postmaster identity does not match the owned loopback cluster'}
 $epoch=[DateTimeOffset]::FromUnixTimeSeconds([long]$lines[2]).UtcDateTime
 if($epoch -lt $runAt.AddSeconds(-5)){throw 'Postmaster predates this start attempt; refusing stop'}
 $server=Get-Process -Id $serverPid -ErrorAction Stop
 if($server.ProcessName -ne 'postgres'){throw 'Owned PID is not postgres'}
 if($null -ne $confirmedOwnedPid -and $serverPid -ne $confirmedOwnedPid){throw 'Owned PID changed; refusing stop'}
 return [pscustomobject]@{pid=$serverPid;dataDirectory=$lines[1];port=[int]$lines[3];listenAddress=$lines[5];startedAt=$epoch.ToString('o');processName=$server.ProcessName;processPath=$server.Path}
}
try{
 $owned=Get-Content -LiteralPath $ownedPath -Raw|ConvertFrom-Json
 if($owned.service -or $owned.port -ne 55438 -or $owned.listenAddress -ne '127.0.0.1' -or (Normal-Path $owned.dataDirectory) -ne (Normal-Path $expectedData) -or (Normal-Path $owned.pgBin) -ne (Normal-Path $expectedBin)){throw 'Unrecognized owned cluster descriptor'}
 $inputs=Get-Content -LiteralPath(Join-Path $recipe 'recipe-inputs.json') -Raw|ConvertFrom-Json
 foreach($row in $inputs.inputs){if((Hash (Join-Path $recipe $row.file)) -ne $row.sha256){throw ('Prepared input drift: '+$row.file)}}
 if((Hash (Join-Path $recipe 'foundation.prepared.sql')) -ne $expectedFoundation){throw 'Wrong actual foundation'}
 $manifest=Get-Content -LiteralPath(Join-Path $recipe 'source-manifest.json') -Raw|ConvertFrom-Json
 $repo=Join-Path (Split-Path $work -Parent) 'probpera-literary-map'
 foreach($section in $manifest.foundation.exactSections){if((Hash (Join-Path $repo $section.file)) -ne $section.sha256){throw ('Old schema/migration source drift: '+$section.file)}}
 $previousExists=[bool](Get-Process -Id ([int]$owned.pid) -ErrorAction SilentlyContinue)
 $pidFileExists=Test-Path -LiteralPath(Join-Path $expectedData 'postmaster.pid')
 $beforeListeners=Listeners
 Write-Json 'preflight.json' ([pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');descriptor=$owned;descriptorSha256=(Hash $ownedPath);previousPidExists=$previousExists;pidFileExists=$pidFileExists;listenerEndpoints=$beforeListeners;foundationSha256=$expectedFoundation;database=$Database;oldSchemaFilesBound=$manifest.foundation.exactSections.Count})
 if($previousExists -or $pidFileExists -or $beforeListeners.Count -ne 0){throw 'Previous PID/pidfile/port is active; do not restart or kill it'}
 $pgCtl=Join-Path $expectedBin 'pg_ctl.exe';$psql=Join-Path $expectedBin 'psql.exe';$postgres=Join-Path $expectedBin 'postgres.exe'
 Write-Json 'binary-bindings.json' (@($pgCtl,$psql,$postgres)|ForEach-Object{[pscustomobject]@{file=$_;sha256=(Hash $_)}})
 $version=Checked $postgres @('--version') 'postgres-version'
 if($version.stdout -notmatch '\b17\.11\b'){throw 'Expected existing PostgreSQL 17.11 binaries'}
 $startAttempted=$true
 $null=Checked $pgCtl @('-D',$expectedData,'-l',(Join-Path $outputFull 'postgres.log'),'-o','-h 127.0.0.1 -p 55438','-w','-t','20','start') 'pg-start' 30000
 $proof=Owned-Pid-Proof
 if($null -eq $proof){throw 'Started cluster has no verified owned identity'}
 $confirmedOwnedPid=$proof.pid;Write-Json 'started-owned-identity.json' $proof
 $identity=Checked $psql ((Psql-Args 'postgres')+@('-c',"select jsonb_build_object('dataDirectory',current_setting('data_directory'),'port',inet_server_port(),'address',inet_server_addr(),'version',current_setting('server_version'),'database',current_database())")) 'server-identity'
 $identityJson=$identity.stdout.Trim()|ConvertFrom-Json
 if((Normal-Path $identityJson.dataDirectory) -ne (Normal-Path $expectedData) -or $identityJson.port -ne 55438 -or $identityJson.address -ne '127.0.0.1' -or $identityJson.version -notmatch '^17\.11(?:\s|$)'){throw 'Server identity mismatch; no fixture SQL may run'}
 $owned.pid=$confirmedOwnedPid;$owned|ConvertTo-Json|Set-Content -LiteralPath $ownedPath -Encoding utf8
 $exists=Checked $psql ((Psql-Args 'postgres')+@('-c',"select count(*) from pg_database where datname='$Database'")) 'database-exists'
 if($exists.stdout.Trim() -ne '0'){throw 'Database exists; no reset/drop/clone is permitted'}
 $null=Checked $psql ((Psql-Args 'postgres')+@('-c',('create database "'+$Database+'"'))) 'database-create'
 $null=Checked $psql ((Psql-Args $Database)+@('--single-transaction','-f',(Join-Path $recipe 'foundation.prepared.sql'))) 'foundation'
 $null=Checked $psql ((Psql-Args $Database)+@('--single-transaction','-f',(Join-Path $recipe 'actors.prepared.sql'))) 'actors'
 $null=Checked $psql ((Psql-Args $Database)+@('-f',(Join-Path $recipe 'postflight.prepared.sql'))) 'postflight'
 $phaseResult='ACTUAL_FOUNDATION_LOADED_NOT_CURRENT_FULL_MANAGED_STACK'
 if($Phase -eq 'M20'){
  $null=Checked $psql ((Psql-Args $Database)+@('-f',(Join-Path $PSScriptRoot 'm20-exact-delete.prepared.sql'))) 'm20-exact-delete'
  $phaseResult='ACTUAL_M20_NATIVE_EXACT_PREDICATE_CASES_COMPLETED_COMPONENT_AND_POSTGREST_SCOPE_SEPARATE'
 }
}catch{
 $failure=[pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');classification='SETUP_OR_FOUNDATION_OR_NATIVE_EXECUTION_FAILURE_REQUIRES_REVIEW_NOT_AUTOMATIC_APP_DEFECT';message=$_.Exception.Message;detail=$_.ToString()}
 Write-Json 'failure.json' $failure
}finally{
 try{
  if($startAttempted){
   $finalProof=Owned-Pid-Proof
   if($null -ne $finalProof){
    if($null -eq $confirmedOwnedPid){$confirmedOwnedPid=$finalProof.pid}
    $stop=Invoke-Child (Join-Path $expectedBin 'pg_ctl.exe') @('-D',$expectedData,'-m','fast','-w','-t','20','stop') 'pg-stop' 30000
    if($stop.exitCode -ne 0){throw 'Owned pg_ctl stop failed'}
   }
  }
  $remainingPid=if($null -eq $confirmedOwnedPid){$null}else{[bool](Get-Process -Id $confirmedOwnedPid -ErrorAction SilentlyContinue)}
  $cleanup=[pscustomobject]@{atUtc=[DateTime]::UtcNow.ToString('o');startAttempted=$startAttempted;ownedPid=$confirmedOwnedPid;ownedProcessRemains=$remainingPid;pidFileRemains=(Test-Path -LiteralPath(Join-Path $expectedData 'postmaster.pid'));listenerEndpoints=(Listeners);allLaunchedClientsExited=(@($children|Where-Object{-not $_.exited}).Count -eq 0);serviceCreated=$false;oldDatabaseDropped=$false;filesDeleted=$false}
  Write-Json 'cleanup.json' $cleanup
  if($startAttempted -and ($cleanup.ownedProcessRemains -or $cleanup.pidFileRemains -or $cleanup.listenerEndpoints.Count -ne 0)){throw 'Cleanup liveness is not terminal; no restart is authorized'}
 }catch{
  Write-Json 'cleanup-failure.json' ([pscustomobject]@{classification='OWNED_CLEANUP_UNCONFIRMED_STOP_AND_REVIEW';atUtc=[DateTime]::UtcNow.ToString('o');message=$_.Exception.Message})
  if($null -eq $failure){$failure=[pscustomobject]@{classification='CLEANUP_FAILURE';message=$_.Exception.Message}}
 }
 Write-Json 'run-receipt.json' ([pscustomobject]@{classification=$phaseResult;startedAt=$runAt.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');phase=$Phase;database=$Database;failure=$failure;cleanup=$cleanup;children=$children;providerCalls=0;productionConnections=0;managedAuthPostgrestE2EClaim=$false})
}
if($null -ne $failure){throw ('Owned native run failed; original receipts retained: '+$failure.message)}
