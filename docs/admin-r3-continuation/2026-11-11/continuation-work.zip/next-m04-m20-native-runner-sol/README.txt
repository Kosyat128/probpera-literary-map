PREPARED ONLY - NOT EXECUTED, PARSED, COMPILED OR PROVED SUCCESSFUL.

Root approval is still required before the future ExecuteOwned invocation.
The default branch only describes the plan. This new parent-only runner does
not modify a maintained source, old migration or prepared foundation.

It binds foundation7d04 and its recipe input hashes, then the22 current whole
schema/migration source bytes. It uses the existing explicitly owned PG17.11
binaries/data directory and loopback127.0.0.1:55438. Before any start it checks
the previous PID, actual postmaster.pid and actual TCP listeners. Any existing
PID/pidfile/listener stops the attempt: no automatic restart, kill, stale-file
deletion, service creation or old-database reset is allowed.

After pg_ctl start it verifies the new postmaster PID/data path/start epoch/
listen address and actual SQL server identity before CREATE DATABASE. The NEW
name must match m04m20_native_[a-z0-9_]+, must not exist, and is never dropped or
cloned. Per-child environment is cleared/allowlisted; no inherited PGURL,
password, provider credentials, HOME override or managed connection is used.
The actual whole foundation and optional actor data load with ON_ERROR_STOP
and a single transaction each. The read-only postflight observes real object,
ACL, trigger and function definitions. It adds no target DDL or missing grants.

The recipe's synthetic objects remain only the explicitly documented Auth,
Storage and Realtime platform scaffolds. Actual outbox/autosave/20 content
tables/wholeAug14/Sep5 predecessor functions and ACLs are unchanged old source.
Managed Auth, PostgREST, Storage delivery and current full Supabase readiness
are not modeled. Missing canonical managed default-grant provenance remains a
reported blocker for authenticated canonical invoker writes, not an excuse to
GRANT ALL or fabricate another target. New-draft entity_id=null autosave cases
can exercise their genuine explicit autosave grants without such a grant.

Future phases (examples only; NOT run):
  pwsh -File run.prepared.ps1 -ExecuteOwned -Phase FoundationOnly
    -Database m04m20_native_baseline_20261030_a -Output <NEW child of work>
  Phase M20 additionally executes the exact-delete fixture. A reused database
  name is refused. Each standalone execution uses another unique database.

Finally stops only the exact newly proved owned postmaster. It captures the
stop command, each child exit and fresh PID/pidfile/listener liveness. If startup
failed after creating a PID file, the same identity checks apply before stop.
An unprovable identity or cleanup failure stops all further work and preserves
the original failure; the runner does not guess which process is safe to kill.

Setup/old foundation failures are retained as environment/dependency findings,
not application failures. The fixture is separately PREPARED and may itself
have a syntax/dependency error. No PASS/native claim exists before an actual
released run. Native SQL counterpart predicates do not execute the JavaScript
server action or a managed PostgREST parser. M20 component BEFORE13/16 and
AFTER16/16 are a distinct already executed real-React proof. Full M20 Auth/DB/
integration/E2E acceptance remains separate.

Future M04 atomic retry migration is root-owned and absent here. This baseline
does not invent operation IDs, leases, dispatch authority or a new queue. Keep
the actual consumer high-water/export behavior and all distinct explicit and
trigger outbox events. The old actor FK ON DELETE SET NULL remains unchanged;
any future two-column nonnull retry identity design must resolve user deletion
and NULL uniqueness deliberately, not retrofit it silently into this baseline.
