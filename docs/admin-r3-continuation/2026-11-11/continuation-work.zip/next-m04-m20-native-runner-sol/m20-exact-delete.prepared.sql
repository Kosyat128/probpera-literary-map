-- PREPARED / NOT EXECUTED. Real old FORCE-RLS autosave table and save RPC.
-- No target DDL, fixture function, RLS bypass, grant or canonical write.
-- Native SQL counterpart of actions.ts exact DELETE; not actual PostgREST E2E.
-- Fixed hashes are opaque valid client hashes, not a proof of JS hash parity.
\set ON_ERROR_STOP on
\set owner 11111111-1111-4111-8111-111111111111
\set foreign 22222222-2222-4222-8222-222222222222
\set reader 33333333-3333-4333-8333-333333333333
\set editor 44444444-4444-4444-8444-444444444444
\set session_a aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa
\set session_b bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb
\set hash_a aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
\set hash_b bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb

begin;
set local statement_timeout='30s';
set local lock_timeout='5s';
select jsonb_build_object(
 'articles',(select count(*) from public.articles),
 'pages',(select count(*) from public.pages),
 'articleRevisions',(select count(*) from public.article_revisions),
 'pageRevisions',(select count(*) from public.page_revisions),
 'outbox',(select count(*) from public.public_build_outbox)
)::text as canonical_state \gset before_

set local role authenticated;
select set_config('request.jwt.claim.sub',:'owner',true);
select current_user='authenticated' and not (select rolbypassrls or rolsuper from pg_roles where rolname=current_user)
 and auth.uid()=:'owner'::uuid and public.is_staff() as pass \gset check_
select 1 / (:'check_pass'::boolean::integer);
select r->>'id' as id,r->>'sequence' as sequence,r->>'snapshotHash' as hash,r::text as receipt
from (select public.save_editor_autosave('article',null,'native-m20-exact','bilingual',null,
 :'session_a'::uuid,1,:'hash_a','{"title":"Keep original private draft A","rights":{"author":"unchanged"}}'::jsonb,now()+interval '30 days') r) s \gset saved_
select count(*)=1 and bool_and(client_sequence=1 and snapshot_hash=:'hash_a' and snapshot->>'title'='Keep original private draft A') as pass
 from public.editor_autosaves where id=:'saved_id'::uuid and actor_id=auth.uid() \gset check_
select jsonb_build_object('case','owner_actual_save_rpc_new_draft','criterion','M20-T04','pass',:'check_pass'::boolean,'receipt',:'saved_receipt'::jsonb);
select 1 / (:'check_pass'::boolean::integer);

-- Valid foreign staff still cannot observe/delete the owner's private copy.
reset role;
set local role authenticated;
select set_config('request.jwt.claim.sub',:'foreign',true);
select count(*)=0 and public.is_staff() as pass from public.editor_autosaves where id=:'saved_id'::uuid \gset check_
select jsonb_build_object('case','foreign_staff_private_read','criterion','M20-T04','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id=:'saved_id'::uuid and client_session_id=:'session_a'::uuid
 and client_sequence=1 and snapshot_hash=:'hash_a' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','foreign_staff_actual_exact_predicates_delete_zero','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=:'owner'::uuid and id=:'saved_id'::uuid and client_session_id=:'session_a'::uuid
 and client_sequence=1 and snapshot_hash=:'hash_a' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','foreign_forged_actor_predicate_still_rls_zero','criterion','M20-T04','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);

-- Exact native DELETE has all five actual action predicates; mismatches retain.
reset role;
set local role authenticated;
select set_config('request.jwt.claim.sub',:'owner',true);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id=:'saved_id'::uuid and client_session_id=:'session_b'::uuid
 and client_sequence=1 and snapshot_hash=:'hash_a' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','wrong_client_session_delete_zero','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id=:'saved_id'::uuid and client_session_id=:'session_a'::uuid
 and client_sequence=1 and snapshot_hash=:'hash_b' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','wrong_snapshot_hash_delete_zero','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id=:'saved_id'::uuid and client_session_id=:'session_a'::uuid
 and client_sequence=2 and snapshot_hash=:'hash_a' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','wrong_sequence_delete_zero','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id='ffffffff-ffff-4fff-8fff-ffffffffffff'::uuid and client_session_id=:'session_a'::uuid
 and client_sequence=1 and snapshot_hash=:'hash_a' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','wrong_id_delete_zero','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
select count(*)=1 and bool_and(client_sequence=1 and snapshot_hash=:'hash_a' and snapshot->>'title'='Keep original private draft A') as pass
 from public.editor_autosaves where id=:'saved_id'::uuid and actor_id=auth.uid() \gset check_
select jsonb_build_object('case','all_mismatch_attempts_retain_selected_copy','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);

-- The actual monotonic upsert supersedes the receipt; the stale one cannot delete.
select r->>'id' as id,r->>'sequence' as sequence,r->>'snapshotHash' as hash,r::text as receipt
from (select public.save_editor_autosave('article',null,'native-m20-exact','bilingual',null,
 :'session_a'::uuid,2,:'hash_b','{"title":"Newer private draft B","rights":{"author":"unchanged"}}'::jsonb,now()+interval '30 days') r) s \gset newer_
select :'newer_id'=:'saved_id' and :'newer_sequence'='2' and :'newer_hash'=:'hash_b' as pass \gset check_
select jsonb_build_object('case','actual_monotonic_newer_sequence_receipt','criterion','M20-T04','pass',:'check_pass'::boolean,'receipt',:'newer_receipt'::jsonb);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id=:'saved_id'::uuid and client_session_id=:'session_a'::uuid
 and client_sequence=1 and snapshot_hash=:'hash_a' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','stale_receipt_cannot_delete_newer_sequence','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
select r->>'sequence'='2' and r->>'snapshotHash'=:'hash_b' as pass
from (select public.save_editor_autosave('article',null,'native-m20-exact','bilingual',null,
 :'session_a'::uuid,1,:'hash_a','{"title":"Late old A must not overwrite B"}'::jsonb,now()+interval '30 days') r) s \gset check_
select jsonb_build_object('case','late_old_save_returns_existing_newer_receipt','criterion','M20-T04','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
select count(*)=1 and bool_and(client_sequence=2 and snapshot_hash=:'hash_b' and snapshot->>'title'='Newer private draft B') as pass
 from public.editor_autosaves where id=:'saved_id'::uuid and actor_id=auth.uid() \gset check_
select jsonb_build_object('case','newer_raw_private_snapshot_retained','criterion','M20-T04','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);

-- Distinct clients on the same locator remain distinct rows.
select r->>'id' as id from (select public.save_editor_autosave('article',null,'native-m20-exact','bilingual',null,
 :'session_b'::uuid,1,:'hash_a','{"title":"Other client private C"}'::jsonb,now()+interval '30 days') r) s \gset other_
select :'other_id'<>:'saved_id' and count(*)=2 as pass from public.editor_autosaves
 where actor_id=auth.uid() and draft_scope='native-m20-exact' \gset check_
select jsonb_build_object('case','same_locator_distinct_client_preserved','criterion','M20-T04','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id=:'saved_id'::uuid and client_session_id=:'session_a'::uuid
 and client_sequence=2 and snapshot_hash=:'hash_b' returning id
) select count(*)=1 as pass from deleted \gset check_
select jsonb_build_object('case','owner_current_exact_delete_one','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
select count(*)=1 and bool_and(id=:'other_id'::uuid and snapshot->>'title'='Other client private C') as pass
 from public.editor_autosaves where actor_id=auth.uid() and draft_scope='native-m20-exact' \gset check_
select jsonb_build_object('case','exact_delete_does_not_remove_other_client','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id=:'saved_id'::uuid and client_session_id=:'session_a'::uuid
 and client_sequence=2 and snapshot_hash=:'hash_b' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','same_delete_replay_zero_honest_no_receipt','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);

-- Nonstaff's existing actual grant does not bypass the staff+actor RLS policies.
reset role;
set local role authenticated;
select set_config('request.jwt.claim.sub',:'reader',true);
select count(*)=0 and not public.is_staff() as pass from public.editor_autosaves \gset check_
select jsonb_build_object('case','nonstaff_private_read_zero','criterion','M20-T04','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id=:'other_id'::uuid and client_session_id=:'session_b'::uuid
 and client_sequence=1 and snapshot_hash=:'hash_a' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','nonstaff_exact_delete_zero','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
do $nonstaff$
declare denied boolean:=false;
begin
 begin
  perform public.save_editor_autosave('article',null,'native-m20-denied','bilingual',null,
   'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'::uuid,1,repeat('a',64),'{}'::jsonb,now()+interval '30 days');
 exception when raise_exception then
  if sqlerrm='A staff session is required' then denied:=true;else raise;end if;
 end;
 if not denied then raise exception 'Native assertion: nonstaff save unexpectedly admitted';end if;
 raise notice '{"case":"actual_nonstaff_save_rpc_denied","criterion":"M20-T04","pass":true}';
end;
$nonstaff$;

-- Actual editor role is valid staff, then revocation makes its own row invisible.
reset role;
set local role authenticated;
select set_config('request.jwt.claim.sub',:'editor',true);
select r->>'id' as id from (select public.save_editor_autosave('page',null,'native-m20-editor','default',null,
 :'session_a'::uuid,1,:'hash_a','{"title":"Editor private D"}'::jsonb,now()+interval '30 days') r) s \gset editor_
select count(*)=1 and public.is_staff() as pass from public.editor_autosaves where id=:'editor_id'::uuid \gset check_
select jsonb_build_object('case','editor_staff_actual_own_save','criterion','M20-T04','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
reset role;
select set_config('request.jwt.claim.sub',:'owner',true);
delete from public.staff_memberships where user_id=:'editor'::uuid;
set local role authenticated;
select set_config('request.jwt.claim.sub',:'editor',true);
select count(*)=0 and not public.is_staff() as pass from public.editor_autosaves where id=:'editor_id'::uuid \gset check_
select jsonb_build_object('case','revoked_editor_own_private_read_zero','criterion','M20-T04','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
with deleted as (
 delete from public.editor_autosaves
 where actor_id=auth.uid() and id=:'editor_id'::uuid and client_session_id=:'session_a'::uuid
 and client_sequence=1 and snapshot_hash=:'hash_a' returning id
) select count(*)=0 as pass from deleted \gset check_
select jsonb_build_object('case','revoked_editor_exact_delete_zero','criterion','M20-T10','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);

-- The unchanged actual anon ACL gives a real DELETE error, not a zero-row ACK.
reset role;
set local role anon;
do $anon_delete$
declare denied boolean:=false;
begin
 begin
  delete from public.editor_autosaves
  where actor_id=auth.uid() and id='ffffffff-ffff-4fff-8fff-ffffffffffff'::uuid
   and client_session_id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'::uuid
   and client_sequence=1 and snapshot_hash=repeat('a',64);
 exception when insufficient_privilege then denied:=true;
 end;
 if not denied then raise exception 'Native assertion: anon DELETE did not return a permission error';end if;
 raise notice '{"case":"actual_anon_acl_delete_permission_error","criterion":"M20-T10","pass":true,"sqlstate":"42501"}';
end;
$anon_delete$;

reset role;
select jsonb_build_object(
 'articles',(select count(*) from public.articles),
 'pages',(select count(*) from public.pages),
 'articleRevisions',(select count(*) from public.article_revisions),
 'pageRevisions',(select count(*) from public.page_revisions),
 'outbox',(select count(*) from public.public_build_outbox)
)::text=:'before_canonical_state' as pass \gset check_
select jsonb_build_object('case','autosaves_do_not_mutate_canonical_revisions_or_outbox','criterion','M20-T04','pass',:'check_pass'::boolean);
select 1 / (:'check_pass'::boolean::integer);
rollback;
select jsonb_build_object('classification','ACTUAL_NATIVE_FIXTURE_FINISHED_ALL_MUTATIONS_ROLLED_BACK',
 'managedPostgrestAuthE2EClaim',false,'canonicalManagedDefaultGrantsAdded',false);
