"""Adapt the preserved real creator producer; source text only, no execution."""
from pathlib import Path
import json,hashlib
WORK=Path(__file__).resolve().parent.parent;REPO=WORK.parent/'probpera-literary-map';OUT=Path(__file__).resolve().parent
source=(WORK/'next-m19-creator-before-sol/producer.mjs').read_bytes().decode();sha=lambda b:hashlib.sha256(b).hexdigest()
source=source.replace('// PREPARE ONLY. Future release runs actual create action -> captured SDK row -> real read guard/loader/editor.','// Actual creator AFTER regression and additive real form controls; controlled action/SDK transport, no managed DB/Auth.')
source=source.replace("/^--(output|chrome)=(.+)$/u", "/^--(output|chrome|source-manifest)=(.+)$/u")
start=source.index("const freezeBytes=await fs.readFile(");end=source.index("const before=await physical()",start)
new_preflight='''if(!args['source-manifest']||!path.isAbsolute(args['source-manifest']))throw Error('Explicit prepared source manifest required');
const freezeBytes=await fs.readFile(args['source-manifest']),freeze=JSON.parse(freezeBytes),repo=freeze.repo,capture=freeze.captureRoot,work=path.resolve(repo,'../work');
if(!args.output||!path.isAbsolute(args.output))throw Error('Fresh absolute parent output required');
const output=path.resolve(args.output),relative=path.relative(work,output);
if(path.isAbsolute(relative)||relative.startsWith('..')||output===work||existsSync(output))throw Error('Fresh parent work output only');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function fixtureInputs(){return freeze.sources.filter(row=>row.roles.includes('fixture')).map(row=>({file:row.file,bytes:row.bytes,sha256:row.sha256}));}
async function physical(){
 const rows=[];
 for(const row of freeze.sources){const bytes=await fs.readFile(path.join(repo,row.file)),saved=await fs.readFile(path.join(capture,row.file));if(!bytes.equals(saved)||bytes.length!==row.bytes||sha(bytes)!==row.sha256)throw Error('Current/captured input drift: '+row.file);rows.push({file:row.file,bytes:bytes.length,sha256:sha(bytes)});}
 for(const row of freeze.packages){const bytes=await fs.readFile(path.join(repo,row.file));if(bytes.length!==row.bytes||sha(bytes)!==row.sha256)throw Error('Package identity drift: '+row.file);}
 return rows;
}
'''
source=source[:start]+new_preflight+source[end:]
source=source.replace('packages:freeze.packages,M20dependencies:freeze.M20dependencies','packages:freeze.packages')
source=source.replace("const {cases,prepareCreatorCase}=await import('./creator-adapter.mjs');", "process.env.PAGE_CREATOR_REPO=repo;process.env.PAGE_CREATOR_SOURCE_ROOT=capture;\nconst {cases,prepareCreatorCase,formCases,createFormCase,controlledFormDelivery}=await import((await import('node:url')).pathToFileURL(path.join(capture,'apps/admin/lib/fixtures/page-creator-cases.mjs')).href);")
source=source.replace("evaluate=native(path.join(here,'oracle.cjs'))", "evaluate=native(path.join(capture,'apps/admin/lib/fixtures/page-creator-original-oracle.cjs'))")
source=source.replace('serverGraph=new Map(),rows=new Map(),results=[];', 'serverGraph=new Map(),rows=new Map(),results=[],formResults=[],formContexts=new Map();')
source=source.replace("const virtual={", '''const pageSource=await fs.readFile(path.join(capture,'apps/admin/app/(dashboard)/pages/page.tsx'),'utf8');
const fieldStart='{canMutate && <CreatePageForm action={createPageAction}>';
const fieldEnd='        </CreatePageForm>}';
if(pageSource.split(fieldStart).length!==2||pageSource.split(fieldEnd).length!==2)throw Error('Actual current creator field boundary changed');
const fieldChildren=pageSource.slice(pageSource.indexOf(fieldStart)+fieldStart.length,pageSource.indexOf(fieldEnd));
await fs.writeFile(path.join(output,'actual-creator-field-children.json'),JSON.stringify({file:'apps/admin/app/(dashboard)/pages/page.tsx',pageSha256:sha(Buffer.from(pageSource)),fieldChildrenSha256:sha(Buffer.from(fieldChildren)),fieldChildren,scope:'Actual server-page JSX children extracted unchanged; standalone component, not full Next Page/Auth execution'},null,2));
const virtual={
 'page-creator-current-field-children':'import React from "react";export function FieldChildren({catalog}){return <>'+fieldChildren+'</>}',
''')
source=source.replace("loader:'js',resolveDir:repo}));", "loader:request.path==='page-creator-current-field-children'?'jsx':'js',resolveDir:repo}));")
source=source.replace("entryPoints:[path.join(here,'entry.jsx')]", "entryPoints:[path.join(capture,'apps/admin/tests/browser/fixtures/page-creator-entry.jsx')]")
source=source.replace(" for(const scenario of cases)rows.set(scenario.id,await prepareCreatorCase(scenario));", " for(const scenario of cases)rows.set(scenario.id,await prepareCreatorCase(scenario));\n for(const id of formCases){const context=createFormCase(id);context.gate=new Promise(resolve=>{context.release=resolve;});formContexts.set(id,context);}")
server_marker="   if(request.method==='GET'&&url.pathname==='/bundle.js')"
at=source.index(server_marker)
server_add='''   if(request.method==='POST'&&url.pathname==='/create'){
    const context=formContexts.get(url.searchParams.get('case'));if(!context)throw Error('Unknown finite form case');
    let body='';for await(const bytes of request){body+=bytes;if(body.length>8*1024*1024)throw Error('Oversized form transport');}
    const fields=JSON.parse(body);const record={fields,receivedAt:new Date().toISOString(),actualResult:null,deliveredResult:null,nativeRedirect:null,delivery:null};context.transport.push(record);
    try{record.actualResult=await context.runtime.create(fields);}
    catch(error){const native=createRequire(path.join(repo,'package.json'));if(!native('next/dist/client/components/redirect-error').isRedirectError(error))throw error;record.nativeRedirect={digest:error.digest,url:native('next/dist/client/components/redirect').getURLFromRedirectError(error)};}
    if(context.scenario==='committed-response-lost'){
      if(!record.nativeRedirect||context.runtime.trace.createPayloads.length!==1)throw Error('Lost-response control must first execute actual successful create');
      record.delivery='CONTROLLED_ACCEPTED_CREATE_RESPONSE_LOST';
    }else{
      if(record.actualResult?.outcome!=='rejected'||record.actualResult.reason!=='content'||context.runtime.trace.createPayloads.length!==0)throw Error('Malformed delivery controls require actual known pre-insert refusal');
      record.deliveredResult=controlledFormDelivery(context.scenario,record.actualResult);record.delivery='ACTUAL_RESULT_OR_LABELLED_MALFORMED_CLIENT_DELIVERY';
    }
    if(context.transport.length===1){context.ready=true;await context.gate;}
    record.deliveredAt=new Date().toISOString();
    response.writeHead(context.scenario==='committed-response-lost'?503:200,{'content-type':'application/json','cache-control':'no-store'});
    response.end(JSON.stringify(context.scenario==='committed-response-lost'?{ok:false,error:'Controlled accepted create response delivery lost'}:{ok:true,result:record.deliveredResult}));return;
   }
'''
source=source[:at]+server_add+source[at:]
source=source.replace("await context.addInitScript(scenario=>{", "await context.addInitScript(scenario=>{") # Original three-case observer body is retained.
loop_end=" }\n}catch(error){terminalError={name:error.name,message:error.message,stack:error.stack};}"
assert source.count(loop_end)==1
forms=''' }
 for(const id of formCases){
  const prepared=formContexts.get(id),context=await browser.newContext({viewport:{width:1280,height:1000},serviceWorkers:'block'}),checks=[],pageErrors=[],consoleErrors=[],externalRequests=[];
  const check=(name,pass,details)=>checks.push({name,pass:Boolean(pass),...(details===undefined?{}:{details})});
  let initial=null,pending=null,final=null,second=null,executionError=null;
  try{
   await context.route('**/*',route=>{const url=new URL(route.request().url());if(url.origin===origin)return route.continue();externalRequests.push({url:route.request().url(),method:route.request().method()});return route.abort('blockedbyclient');});
   await context.addInitScript(id=>{
    const h=window.__m19Creator={scenario:id,mode:'form',calls:[],resets:[],autosave:[],entryLoaded:false};
    h.createAction=async data=>{const call={fields:[...data.entries()],state:'pending'};h.calls.push(call);
      const response=await fetch('/create?case='+encodeURIComponent(id),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(call.fields)});
      const body=await response.json();if(!response.ok||!body.ok){call.state='transport-error';throw new Error(body.error||'Controlled create transport failed');}
      call.state='returned';call.result=body.result;return body.result;};
   },id);
   const page=await context.newPage();page.setDefaultTimeout(5000);page.on('pageerror',error=>pageErrors.push({name:error.name,message:error.message}));page.on('console',message=>{if(message.type()==='error')consoleErrors.push(message.text());});
   await page.goto(origin+'/',{waitUntil:'networkidle'});await page.waitForFunction(()=>window.__m19Creator.entryLoaded||window.__m19Creator.entryError);
   await page.locator('form textarea[name="content"]').waitFor();
   await page.evaluate(()=>document.querySelector('form').addEventListener('reset',event=>queueMicrotask(()=>window.__m19Creator.resets.push({defaultPrevented:event.defaultPrevented})),true));
   const captureForm=()=>page.evaluate(()=>({fields:[...new FormData(document.querySelector('form')).entries()],buttonDisabled:document.querySelector('button[type="submit"]').disabled,
     text:document.body.innerText,calls:window.__m19Creator.calls,resets:window.__m19Creator.resets,reactVersion:window.__m19Creator.reactVersion}));
   await page.locator('[name="title"]').fill('Exact original form title '+id);await page.locator('[name="slug"]').fill('exact-form-'+id);
   await page.locator('[name="excerpt"]').fill('Exact original form excerpt '+id);
   await page.locator('[name="content"]').fill(id==='committed-response-lost'?'Exact accepted paragraph.\\n\\nExact accepted second paragraph.':'&'.repeat(400000));
   initial=await captureForm();
   check('actual original creator field children and all catalog values are present',JSON.stringify(initial.fields.map(([name])=>name).sort())===JSON.stringify(['catalog_page','catalog_q','catalog_status','content','excerpt','slug','title'].sort()));
   check('no initial create or canonical SDK mutation',prepared.runtime.trace.actionCalls.length===0&&prepared.runtime.trace.createPayloads.length===0);
   await page.getByRole('button',{name:'Создать черновик',exact:true}).click();
   const until=Date.now()+5000;while(!prepared.ready){if(Date.now()>until)throw Error('Actual create bridge did not reach held first response');await new Promise(resolve=>setTimeout(resolve,20));}
   await page.waitForFunction(()=>document.querySelector('button[type="submit"]').disabled&&document.body.innerText.includes('Создание черновика...'));
   pending=await captureForm();
   check('actual CreatePageForm is visibly pending before response',pending.buttonDisabled&&pending.calls[0].state==='pending');
   check('actual submitted FormData retains ALL original fields',JSON.stringify(prepared.transport[0].fields)===JSON.stringify(initial.fields));
   prepared.release();
   await page.waitForFunction(()=>window.__m19Creator.calls[0].state!=='pending');
   await page.getByRole('alert').waitFor();await page.waitForFunction(()=>window.__m19Creator.resets.length>0);
   final=await captureForm();
   check('native React reset was actually prevented',final.resets.length>0&&final.resets.every(row=>row.defaultPrevented));
   check('ALL author and hidden catalog fields remain exact',JSON.stringify(final.fields)===JSON.stringify(initial.fields));
   if(id==='known-content-refusal'){
    check('known actual pre-insert rejection is shown inline',prepared.transport[0].actualResult.outcome==='rejected'&&final.text.includes(prepared.transport[0].actualResult.message)&&!final.buttonDisabled);
    check('known content rejection performed no insert audit or outbox write',prepared.runtime.trace.createPayloads.length===0&&prepared.runtime.trace.audit.length===0&&prepared.runtime.trace.enqueue.length===0);
    await page.locator('[name="title"]').fill('Exact corrected title retained');await page.locator('[name="content"]').fill('&'.repeat(400001));
    const beforeAgain=await captureForm();await page.getByRole('button',{name:'Создать черновик',exact:true}).click();
    await page.waitForFunction(()=>window.__m19Creator.calls.length===2&&window.__m19Creator.calls[1].state!=='pending'&&window.__m19Creator.resets.length===2);
    second=await captureForm();
    check('known no-write refusal permits an explicit corrected attempt retaining ALL fields',prepared.transport.length===2&&JSON.stringify(second.fields)===JSON.stringify(beforeAgain.fields)&&!second.buttonDisabled);
    check('second known refusal still has zero canonical audit or outbox writes',prepared.runtime.trace.createPayloads.length===0&&prepared.runtime.trace.audit.length===0&&prepared.runtime.trace.enqueue.length===0);
   }else{
    check('malformed or unknown delivery causes a visible no-retry hold',final.buttonDisabled&&final.text.includes('Результат создания не подтверждён'));
    const count=prepared.transport.length;await page.evaluate(()=>document.querySelector('form').requestSubmit());await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(resolve)));
    const afterBlocked=await captureForm();check('actual attempted resubmit is blocked with ALL fields intact',prepared.transport.length===count&&JSON.stringify(afterBlocked.fields)===JSON.stringify(initial.fields));
    if(id==='committed-response-lost')check('lost response follows one actual accepted create with no duplicate',prepared.transport[0].nativeRedirect&&prepared.runtime.trace.createPayloads.length===1&&prepared.runtime.trace.actionCalls.length===1);
    else check('malformed reply control starts from genuine known zero-write rejection',prepared.transport[0].actualResult.outcome==='rejected'&&prepared.runtime.trace.createPayloads.length===0&&prepared.runtime.trace.audit.length===0&&prepared.runtime.trace.enqueue.length===0);
   }
   check('installed Next React rendered the actual component',final.reactVersion?.startsWith('19.'));
   check('no actual component or undeclared network error',pageErrors.length===0&&externalRequests.length===0&&prepared.runtime.trace.external.length===0&&prepared.runtime.trace.protocolErrors.length===0);
  }catch(error){executionError={name:error.name,message:error.message,stack:error.stack};checks.push({name:'actual form finite controls complete',pass:false,classification:'EXECUTION_OR_OBSERVER_FAILURE_REQUIRES_CLASSIFICATION',details:executionError});}
  finally{prepared.release();formResults.push({scenario:id,checks,initial,pending,final,second,transport:prepared.transport,actualServerTrace:prepared.runtime.trace,pageErrors,consoleErrors,externalRequests,executionError});for(const[file,row]of prepared.runtime.graph)serverGraph.set(file,row);await context.close();}
 }
}catch(error){terminalError={name:error.name,message:error.message,stack:error.stack};}'''
source=source.replace(loop_end,forms)
source=source.replace("const checks=results.flatMap(row=>row.checks),report=", "const coreChecks=results.flatMap(row=>row.checks),formChecks=formResults.flatMap(row=>row.checks),checks=[...coreChecks,...formChecks],report=")
source=source.replace("cleanup,results,\n browserSources", "cleanup,results,formResults,originalCreatorScope:{cases:results.length,checks:coreChecks.length,passed:coreChecks.filter(row=>row.pass).length,failed:coreChecks.filter(row=>!row.pass).length},additiveFormScope:{cases:formResults.length,plannedCases:formCases.length,checks:formChecks.length,passed:formChecks.filter(row=>row.pass).length,failed:formChecks.filter(row=>!row.pass).length},\n browserSources")
source=source.replace("results.length===cases.length&&report.failed===0", "results.length===cases.length&&formResults.length===formCases.length&&report.failed===0")
source=source.replace("cases:results.length,checks:checks.length,passed:report.passed", "cases:results.length+formResults.length,originalCases:results.length,additiveFormCases:formResults.length,checks:checks.length,passed:report.passed")
target=REPO/'apps/admin/tests/browser/page-creator-browser.mjs';assert not target.exists();target.write_text(source,encoding='utf-8',newline='\n')
proof={'classification':'MAINTAINED_BROWSER_SOURCE_ADAPTER_ONLY_NOT_EXECUTED','originalProducer':{'file':'work/next-m19-creator-before-sol/producer.mjs','sha256':sha((WORK/'next-m19-creator-before-sol/producer.mjs').read_bytes())},'maintainedProducer':{'file':str(target.relative_to(REPO)),'sha256':sha(target.read_bytes())},'originalCoreCaseDeclarationsAndOracle':'Byte-exact copies in maintained cases/original-oracle; original three-case observer loop kept except current source/path setup.','adapters':['Explicit current AFTER captured-source manifest; no BEFORE overwrite or current fallback','Actual source extracted CreatePageForm children and real component mode','9 additive actual form known/malformed/unknown delivery controls; separately counted','Current action return values or native redirects recorded, fault delivery labelled; no saved-result mock'],'execution':'NOT_RUN'}
(OUT/'browser-adapter-preservation.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8');print(json.dumps({'file':str(target),'sha256':sha(target.read_bytes()),'originalCases':3,'additiveFormCases':9,'executed':False}))
