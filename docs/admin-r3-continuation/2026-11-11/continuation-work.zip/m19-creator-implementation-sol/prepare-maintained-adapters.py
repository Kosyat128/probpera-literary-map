"""Source preparation only; never imports application/JS or runs a bundle/test."""
from pathlib import Path
import hashlib,json
WORK=Path(__file__).resolve().parent.parent;REPO=WORK.parent/'probpera-literary-map';OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
old=WORK/'next-m20-page-actor-before-sol/action-runtime.cjs';source=old.read_bytes().decode()
assert sha(old.read_bytes())=='dcc9e9707fbee9d75f22e75ac8e4278eddb0f978c087eb92b9c8582f6aec94a7'
old_config="const HERE = __dirname;\nconst freeze = JSON.parse(fs.readFileSync(path.join(HERE, 'inputs.freeze.json'), 'utf8'));\nconst native = createRequire(path.join(freeze.repo, 'package.json'));"
new_config="const repo = process.env.PAGE_CREATOR_REPO || path.resolve(__dirname, '../../../..');\nconst sourceRoot = process.env.PAGE_CREATOR_SOURCE_ROOT || repo;\nconst native = createRequire(path.join(repo, 'package.json'));"
assert source.count(old_config)==1
runtime=source.replace(old_config,new_config).replace("  const sources = new Map(freeze.sources.map(row => [row.file, row]));\n",'')
runtime=runtime.replace("const file=base+suffix;if(sources.has(file))return file;", "const file=base+suffix;\n      if(file.startsWith('../')||path.posix.isAbsolute(file))throw Error('Local source escaped explicit sourceRoot');\n      const actual=path.join(sourceRoot,file);if(fs.existsSync(actual)&&fs.statSync(actual).isFile())return file;")
old_load="    const binding=sources.get(file);assert(binding,'Source is absent from strict prepared capture: '+file);\n    const bytes=fs.readFileSync(path.join(freeze.captureRoot,file));\n    assert.equal(bytes.length,binding.bytes);assert.equal(sha(bytes),binding.sha256);"
new_load="    const bytes=fs.readFileSync(path.join(sourceRoot,file));\n    const binding={file,bytes:bytes.length,sha256:sha(bytes)};"
assert runtime.count(old_load)==1;runtime=runtime.replace(old_load,new_load)
old_create="    trace.actionCalls.push({kind:'create',fields:copy(fields),result:'native redirect or throw; not a client operation receipt'});\n    return load('apps/admin/app/(dashboard)/pages/actions.ts').createPageAction(form(fields));"
new_create="    const record={kind:'create',fields:copy(fields),result:null,nativeSignalDigest:null};trace.actionCalls.push(record);\n    try {const result=await load('apps/admin/app/(dashboard)/pages/actions.ts').createPageAction(form(fields));record.result=copy(result);return result;}\n    catch(error){record.nativeSignalDigest=error?.digest||null;throw error;}"
assert runtime.count(old_create)==1;runtime=runtime.replace(old_create,new_create)
runtime=runtime.replace('// PREPARE ONLY until the parent explicitly releases controlled execution.','// Actual current create/save/check modules and installed SDK; controlled Auth/native transport only.')
runtime=runtime.replace('  // Optional future M19 bridge export only: no M19 scenario/route/oracle is active\n  // in this five-case M20 producer. Native redirect signals propagate unchanged.','  // Actual create action; closed known-content return and native redirect both propagate unchanged.')
target=REPO/'apps/admin/lib/fixtures/page-creator-runtime.cjs';assert not target.exists();target.write_text(runtime,encoding='utf-8',newline='\n')

old_cases=WORK/'next-m19-creator-before-sol/creator-adapter.mjs';text=old_cases.read_bytes().decode();start=text.index('export const cases=[');end=text.index('export async function prepareCreatorCase',start);cases_block=text[start:end]
old_header="const freeze=JSON.parse(await fs.readFile(path.join(here,'inputs.freeze.json'),'utf8'));\nconst native=createRequire(path.join(freeze.repo,'package.json'));\nconst {createPageActorRuntime,actorId,previous}=native(path.resolve(here,'../next-m20-page-actor-before-sol/action-runtime.cjs'));"
new_header="const repo=process.env.PAGE_CREATOR_REPO||path.resolve(here,'../../../..');\nconst native=createRequire(path.join(repo,'package.json'));\nconst {createPageActorRuntime,actorId,previous}=native(path.join(here,'page-creator-runtime.cjs'));"
assert text.count(old_header)==1;text=text.replace(old_header,new_header)
text=text.replace('// New adapter only. Reuses the immutable M20 actual action loader; does not clone createPageAction.','// Actual current action/SDK runtime; original three creator cases below remain byte-exact BEFORE declarations.')
assert text[text.index('export const cases=['):text.index('export async function prepareCreatorCase')]==cases_block
text+='''
// Additive real CreatePageForm controls. These are not part of the original three cases/42 checks.
export const formCases=Object.freeze([
  'known-content-refusal','extra-key-result','empty-message-result','whitespace-message-result',
  'missing-message-result','null-result','overlong-message-result','wrong-outcome-result','committed-response-lost',
]);
export function createFormCase(id){
  assert(formCases.includes(id));
  return{scenario:id,runtime:createPageActorRuntime('form-'+id,{allowCreate:true}),transport:[],ready:false};
}
export function controlledFormDelivery(id,result){
  if(id==='known-content-refusal')return result;
  if(id==='extra-key-result')return{...result,canExecute:true};
  if(id==='empty-message-result')return{...result,message:''};
  if(id==='whitespace-message-result')return{...result,message:' \\n\\t'};
  if(id==='missing-message-result'){const {message,...rest}=result;return rest;}
  if(id==='null-result')return null;
  if(id==='overlong-message-result')return{...result,message:'x'.repeat(501)};
  if(id==='wrong-outcome-result')return{...result,outcome:'saved'};
  throw Error('Transport-loss control never delivers a successful result');
}
'''
cases_target=REPO/'apps/admin/lib/fixtures/page-creator-cases.mjs';assert not cases_target.exists();cases_target.write_text(text,encoding='utf-8',newline='\n')
oracle_old=WORK/'next-m19-creator-before-sol/oracle.cjs';oracle_target=REPO/'apps/admin/lib/fixtures/page-creator-original-oracle.cjs';assert not oracle_target.exists();oracle_target.write_bytes(oracle_old.read_bytes())

entry=(WORK/'next-m19-creator-before-sol/entry.jsx').read_bytes().decode()
entry=entry.replace("import {validPageEditorRead,canEditPageBundle} from '@/lib/page-load-validation';", "import {validPageEditorRead,canEditPageBundle} from '@/lib/page-load-validation';\nimport CreatePageForm from '@/app/(dashboard)/pages/CreatePageForm';\nimport {FieldChildren} from 'page-creator-current-field-children';")
marker="async function main(){\n";assert entry.count(marker)==1
entry=entry.replace(marker,marker+'''  if(h.mode==='form'){
    h.reactVersion=React.version;
    createRoot(document.getElementById('root')).render(<CreatePageForm action={h.createAction}>
      <FieldChildren catalog={{term:'Exact original catalog query',status:'all',page:3}} />
    </CreatePageForm>);
    h.entryLoaded=true;return;
  }
''')
entry_target=REPO/'apps/admin/tests/browser/fixtures/page-creator-entry.jsx';assert not entry_target.exists();entry_target.write_text(entry,encoding='utf-8',newline='\n')
proof={'classification':'MAINTAINED_SOURCE_ADAPTERS_PREPARED_NOT_EXECUTED','originalActionLoader':{'file':str(old),'sha256':sha(old.read_bytes())},'runtime':{'file':str(target.relative_to(REPO)),'sha256':sha(target.read_bytes()),'adapters':['repo/sourceRoot environment instead of immutable BEFORE freeze; strict explicit sourceRoot with no current fallback','dynamic actual file read graph rather than BEFORE manifest lookup','create return/native redirect recorded for real client form; action itself unmocked']},'originalThreeCaseBlockSha256':sha(cases_block.encode()),'caseBlockByteExact':True,'originalOracle':{'file':str(oracle_old),'sha256':sha(oracle_old.read_bytes())},'maintainedOriginalOracle':{'file':str(oracle_target.relative_to(REPO)),'sha256':sha(oracle_target.read_bytes()),'byteExact':True},'newAdditiveFormCases':9,'oldProbesAndDraftsModified':False,'execution':'NOT_RUN'}
(OUT/'source-adapter-preservation.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'runtime':str(target),'cases':str(cases_target),'oracle':str(oracle_target),'entry':str(entry_target),'originalThreeCasesAnd42Checks':'BYTE_EXACT','executed':False}))
