package ru.probpera.literaryplanet;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Closed native support payload. No filesystem, network, profile or authority reads. */
final class PlanetAdultDiagnosticJson {
    static final int MAX_BYTES = 16384;
    static final String FILE_NAME = "literary-planet-diagnostics.json";
    static final String MIME = "application/json";
    interface Check { void check() throws Exception; }
    private static void require(boolean value) throws Exception { if (!value) throw new Exception("Diagnostic unavailable"); }
    private static Map<String,Object> object(Object value,String... keys) throws Exception {
        require(value instanceof Map); @SuppressWarnings("unchecked") Map<String,Object> row=(Map<String,Object>)value;
        require(row.size()==keys.length); for(String key:keys) require(row.containsKey(key)); return row;
    }
    private static String text(Object value) throws Exception { require(value instanceof String); return (String)value; }
    private static boolean choice(Object value,String... choices) { return value instanceof String && Arrays.asList(choices).contains(value); }
    private static void unknown(Object value,String reason) throws Exception {
        Map<String,Object> row=object(value,"status","reason");require("unknown".equals(row.get("status"))&&reason.equals(row.get("reason")));
    }
    private static Object observed(Object value,String source) throws Exception {
        Map<String,Object> row=object(value,"status","source","value");require("observed".equals(row.get("status"))&&source.equals(row.get("source")));return row.get("value");
    }
    private static boolean isUnknown(Object value) { return value instanceof Map && "unknown".equals(((Map<?,?>)value).get("status")); }
    private static void optionalUnknown(Object value) throws Exception { unknown(value,"not-observed"); }
    private static void item(Object value) throws Exception {
        if(value==null)return;require(text(value).matches("[\\p{L}\\p{N}][\\p{L}\\p{N}_.:-]{0,159}"));
    }
    private static void counter(Object value) throws Exception { require(value instanceof Long && (Long)value>=0 && (Long)value<=1000000000L); }
    static byte[] decode(String json,String platform) throws Exception {
        require(json!=null&&!json.isEmpty()&&json.length()<=MAX_BYTES&&choice(platform,"android","ios"));
        ByteBuffer encoded=StandardCharsets.UTF_8.newEncoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT).encode(CharBuffer.wrap(json));
        byte[] bytes=new byte[encoded.remaining()];encoded.get(bytes);boolean accepted=false;
        try {
            require(bytes.length>0&&bytes.length<=MAX_BYTES);
            Map<String,Object> root=object(new Parser(bytes).parse(),"versions","environment","graphicsTier","activeItems",
                "lastTransfer","webglRecovery","store","availableStorage","integrity","correlationIds");
            Map<String,Object> versions=object(root.get("versions"),"app","build","content");
            unknown(versions.get("app"),"not-exposed");optionalUnknown(versions.get("build"));optionalUnknown(versions.get("content"));
            Map<String,Object> environment=object(root.get("environment"),"platform","os","deviceClass");
            require(platform.equals(observed(environment.get("platform"),"platform-services")));
            unknown(environment.get("os"),"not-exposed");unknown(environment.get("deviceClass"),"not-exposed");
            Object graphics=root.get("graphicsTier");
            if(isUnknown(graphics))optionalUnknown(graphics);else require(choice(observed(graphics,"adult-graphics-policy"),"high","balanced","economy"));
            Object active=root.get("activeItems");
            if(isUnknown(active))optionalUnknown(active);else {
                Map<String,Object> row=object(observed(active,"adult-canonical-selection"),"scope","countryId","writerId","workId");
                Object country=row.get("countryId"),writer=row.get("writerId"),work=row.get("workId");
                item(country);item(writer);item(work);Object scope=row.get("scope");
                require(choice(scope,"none","globe-selection","settled-reader"));
                if("none".equals(scope))require(country==null&&writer==null&&work==null);
                else {require(country!=null);if("globe-selection".equals(scope))require(work==null);else require(writer!=null&&work!=null);}
            }
            Map<String,Object> transfer=object(root.get("lastTransfer"),"update","baseRepair","otherDownloads");
            for(Object value:transfer.values())optionalUnknown(value);
            Object webgl=root.get("webglRecovery");
            if(isUnknown(webgl))optionalUnknown(webgl);else {
                Map<String,Object> row=object(observed(webgl,"canonical-globe-lifecycle"),"lossCount","restorationCount");
                counter(row.get("lossCount"));counter(row.get("restorationCount"));
            }
            Map<String,Object> store=object(root.get("store"),"provider","errorCategory");
            unknown(store.get("provider"),"not-exposed");unknown(store.get("errorCategory"),"not-exposed");
            Object storage=root.get("availableStorage");
            if(isUnknown(storage))optionalUnknown(storage);else {
                Map<String,Object> row=object(observed(storage,"adult-download-storage"),"bucket","scope");
                require(choice(row.get("bucket"),"under-100-mib","100-mib-to-1-gib","1-to-5-gib","at-least-5-gib"));
                require(choice(row.get("scope"),"device","browser-origin"));
            }
            optionalUnknown(root.get("integrity"));unknown(root.get("correlationIds"),"not-exposed");
            accepted=true;return bytes;
        } finally {if(!accepted)Arrays.fill(bytes,(byte)0);if(encoded.hasArray())Arrays.fill(encoded.array(),(byte)0);}
    }
    static String sha256(byte[] bytes) throws Exception {
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(bytes);try {
            StringBuilder out=new StringBuilder(64);for(byte value:digest){out.append("0123456789abcdef".charAt((value&255)>>>4));out.append("0123456789abcdef".charAt(value&15));}return out.toString();
        }finally{Arrays.fill(digest,(byte)0);}
    }
    static void verify(InputStream stream,int expected,String checksum,Check check) throws Exception {
        require(stream!=null&&expected>0&&expected<=MAX_BYTES&&checksum!=null&&checksum.matches("[a-f0-9]{64}"));
        byte[] actual=new byte[expected],extra=new byte[1];int offset=0;
        try{while(offset<expected){check.check();int count=stream.read(actual,offset,expected-offset);require(count>0);offset+=count;}
            check.check();require(stream.read(extra)==-1&&sha256(actual).equals(checksum));check.check();
        }finally{Arrays.fill(actual,(byte)0);Arrays.fill(extra,(byte)0);}
    }
    /** Bounded JSON grammar: duplicates, fractions, -0, invalid UTF8/surrogates fail closed. */
    private static final class Parser {
        final String source;int at,nodes;
        Parser(byte[] bytes)throws Exception{source=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();}
        Object parse()throws Exception{Object value=value(0);white();require(at==source.length());return value;}
        void white(){while(at<source.length()&&" \t\r\n".indexOf(source.charAt(at))>=0)at++;}
        boolean take(char c){white();if(at<source.length()&&source.charAt(at)==c){at++;return true;}return false;}
        Object value(int depth)throws Exception{
            require(depth<=12&&++nodes<=512);white();require(at<source.length());char c=source.charAt(at);
            if(c=='"')return string();
            if(c=='{'){at++;Map<String,Object> row=new LinkedHashMap<>();if(take('}'))return row;
                do{white();require(at<source.length()&&source.charAt(at)=='"');String key=string();require(!row.containsKey(key)&&take(':'));row.put(key,value(depth+1));}while(take(','));require(take('}'));return row;}
            for(String word:new String[]{"true","false","null"})if(source.startsWith(word,at)){at+=word.length();return word.equals("null")?null:Boolean.valueOf(word);}
            int start=at;if(c=='-')at++;require(at<source.length());
            if(source.charAt(at)=='0')at++;else{require(source.charAt(at)>='1'&&source.charAt(at)<='9');while(at<source.length()&&source.charAt(at)>='0'&&source.charAt(at)<='9')at++;}
            String number=source.substring(start,at);require(!number.equals("-0"));long result=Long.parseLong(number);
            require(result>=-9007199254740991L&&result<=9007199254740991L);return Long.valueOf(result);
        }
        String string()throws Exception{
            require(source.charAt(at++)=='"');StringBuilder out=new StringBuilder();boolean ended=false;
            while(at<source.length()){char c=source.charAt(at++);if(c=='"'){ended=true;break;}require(c>=32);
                if(c=='\\'){require(at<source.length());c=source.charAt(at++);switch(c){
                    case '"':case '\\':case '/':break;case 'b':c='\b';break;case 'f':c='\f';break;case 'n':c='\n';break;case 'r':c='\r';break;case 't':c='\t';break;
                    case 'u':require(at+4<=source.length());int n=0;for(int i=0;i<4;i++){char digit=source.charAt(at++);require(digit>='0'&&digit<='9'||digit>='a'&&digit<='f'||digit>='A'&&digit<='F');n=n*16+Character.digit(digit,16);}c=(char)n;break;
                    default:throw new Exception("Diagnostic unavailable");
                }}out.append(c);
            }
            require(ended);String result=out.toString();for(int i=0;i<result.length();i++){
                char c=result.charAt(i);if(Character.isHighSurrogate(c))require(i+1<result.length()&&Character.isLowSurrogate(result.charAt(++i)));else require(!Character.isLowSurrogate(c));
            }return result;
        }
    }
}
