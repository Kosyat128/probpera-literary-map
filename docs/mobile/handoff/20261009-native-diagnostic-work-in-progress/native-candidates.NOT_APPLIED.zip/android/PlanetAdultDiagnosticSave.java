package ru.probpera.literaryplanet;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.SystemClock;
import androidx.activity.result.ActivityResult;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** One diagnostic file only. Its Host is the existing native adult-context owner. */
final class PlanetAdultDiagnosticSave implements AutoCloseable {
    interface Host {
        Activity activity();
        <T> T main(Callable<T> action) throws Exception;
        void transfer(PlanetAdultDiagnosticSave operation) throws Exception;
        void check(PlanetAdultDiagnosticSave operation,boolean transferred) throws Exception;
        void expired(PlanetAdultDiagnosticSave operation);
    }
    static final class Request implements AutoCloseable {
        final String id,contextToken;final long generation;private byte[] bytes;
        Request(String id,String token,long generation,byte[] bytes){this.id=id;contextToken=token;this.generation=generation;this.bytes=bytes;}
        synchronized byte[] take()throws Exception{require(bytes!=null);byte[] result=bytes;bytes=null;return result;}
        public synchronized void close(){if(bytes!=null)Arrays.fill(bytes,(byte)0);bytes=null;}
    }
    static final class Cancel {
        final String id,contextToken,target;final long generation;
        Cancel(String id,String token,long generation,String target){this.id=id;contextToken=token;this.generation=generation;this.target=target;}
    }
    private static void require(boolean value)throws Exception{if(!value)throw new Exception("Diagnostic save unavailable");}
    private static void exact(Map<String,Object> row,String... names)throws Exception{
        require(row!=null&&row.size()==names.length);for(String name:names)require(row.containsKey(name));
    }
    private static String token(Object value)throws Exception{require(value instanceof String&&((String)value).matches("[a-f0-9]{32}"));return(String)value;}
    private static long integer(Object value,long low,long high)throws Exception{
        require(value instanceof Integer||value instanceof Long||value instanceof Double);double number=((Number)value).doubleValue();
        require(Double.isFinite(number)&&number==Math.rint(number)&&number>=low&&number<=high
            &&Double.doubleToRawLongBits(number)!=Double.doubleToRawLongBits(-0.0d));return((Number)value).longValue();
    }
    static Request decode(Map<String,Object> row)throws Exception{
        exact(row,"version","requestId","contextToken","generation","json");integer(row.get("version"),2,2);
        String id=token(row.get("requestId")),context=token(row.get("contextToken"));long generation=integer(row.get("generation"),1,9007199254740990L);
        require(row.get("json") instanceof String);byte[] bytes=PlanetAdultDiagnosticJson.decode((String)row.get("json"),"android");
        return new Request(id,context,generation,bytes);
    }
    static Cancel decodeCancel(Map<String,Object> row)throws Exception{
        exact(row,"version","requestId","contextToken","generation","targetRequestId");integer(row.get("version"),2,2);
        String id=token(row.get("requestId")),context=token(row.get("contextToken")),target=token(row.get("targetRequestId"));
        require(!id.equals(target));return new Cancel(id,context,integer(row.get("generation"),1,9007199254740990L),target);
    }
    static Map<String,Object> map(Object... entries){Map<String,Object> row=new LinkedHashMap<>();for(int i=0;i<entries.length;i+=2)row.put((String)entries[i],entries[i+1]);return row;}
    static Map<String,Object> refusal(String id,String outcome){return map("version",2L,"requestId",id,"status","diagnostic-save",
        "receipt",map("requestId",id,"outcome",outcome,"bytes",0L,"sha256",null));}
    static Map<String,Object> cancelled(Cancel request,boolean known){return map("version",2L,"requestId",request.id,
        "status","diagnostic-cancel","targetRequestId",request.target,"cancelled",known);}

    final Request request;final long deadline;
    private final Host host;private final int count;private final String checksum;private byte[] bytes;
    private final CountDownLatch returned=new CountDownLatch(1),pickerEnded=new CountDownLatch(1);
    private volatile boolean pickerPending,cancelled,closed,transferred,cleanupKnown,finished;
    private boolean received;private long last;private Uri destination;private String outcome="cancelled";
    private boolean pickerLaunched;private android.os.Handler expiryHandler;private Runnable expiry;
    PlanetAdultDiagnosticSave(Host host,Request request,long deadline)throws Exception{
        this.host=host;this.request=request;this.deadline=deadline;bytes=request.take();
        count=bytes.length;checksum=PlanetAdultDiagnosticJson.sha256(bytes);last=SystemClock.elapsedRealtime();
        require(count>0&&count<=PlanetAdultDiagnosticJson.MAX_BYTES&&last>=0&&last<deadline&&deadline-last<=60000);
    }
    private void current()throws Exception{
        synchronized(this){long now=SystemClock.elapsedRealtime();require(!closed&&!cancelled&&!finished&&now>=last&&now<deadline);last=now;}
        host.check(this,transferred);
    }
    boolean matches(String token,long generation,String id){return request.contextToken.equals(token)&&request.generation==generation&&request.id.equals(id);}
    boolean ownsPicker(){return pickerPending&&!closed&&!cancelled&&!finished&&transferred&&SystemClock.elapsedRealtime()<deadline;}
    boolean cleanupKnown(){return cleanupKnown;}
    boolean cancelled(){return cancelled;}
    boolean cancel(){synchronized(this){if(finished)return false;cancelled=true;pickerPending=false;}returned.countDown();return true;}
    private void receive(ActivityResult result){
        synchronized(this){
            if(!received){received=true;pickerPending=false;
                if(result!=null&&result.getResultCode()==Activity.RESULT_OK){
                    outcome="error";Uri selected=result.getData()==null?null:result.getData().getData();
                    if(selected!=null&&"content".equals(selected.getScheme()))destination=selected;
                }
            }
        }pickerEnded.countDown();returned.countDown();
    }
    Map<String,Object> save(){
        String result="error";
        try{
            current();host.transfer(this);transferred=true;current();
            host.main(()->{
                current();Activity activity=host.activity();require(activity instanceof MainActivity&&!activity.isFinishing()&&!activity.isDestroyed()&&activity.hasWindowFocus());

                expiryHandler=new android.os.Handler(android.os.Looper.getMainLooper());
                expiry=()->{cancel();host.expired(this);};
                require(expiryHandler.postDelayed(expiry,Math.max(1,deadline-SystemClock.elapsedRealtime())));
                Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(PlanetAdultDiagnosticJson.MIME).putExtra(Intent.EXTRA_TITLE,PlanetAdultDiagnosticJson.FILE_NAME);
                synchronized(this){current();pickerPending=true;}
                try{((MainActivity)activity).launchAdultDiagnosticPicker(request.id,intent,this::receive);pickerLaunched=true;}catch(Throwable failure){cancel();throw failure;}
                return null;
            });
            while(!returned.await(10,TimeUnit.MILLISECONDS))current();
            if(cancelled)result="cancelled";
            else{
                current();if(destination==null)result=outcome;
                else{
                    // Result delivery may precede the returning Activity's first focused frame.
                    for(;;){current();boolean focused=host.main(()->{current();return host.activity().hasWindowFocus()
                        &&((MainActivity)host.activity()).getLifecycle().getCurrentState().isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED);});
                        if(focused)break;Thread.sleep(10);}
                    current();writeVerified();current();result="saved";
                }
            }
        }catch(Throwable failure){result=cancelled||SystemClock.elapsedRealtime()>=deadline?"cancelled":"error";}
        synchronized(this){if("saved".equals(result)&&cancelled)result="cancelled";finished=true;}
        if(!"saved".equals(result)&&destination!=null&&!removePartial())result="error";
        close();
        if(!cleanupKnown)result="error";
        return map("version",2L,"requestId",request.id,"status","diagnostic-save",
            "receipt",map("requestId",request.id,"outcome",result,"bytes",(long)count,"sha256",checksum));
    }
    private void writeVerified()throws Exception{
        current();android.content.ContentResolver resolver=host.activity().getContentResolver();
        try(android.os.ParcelFileDescriptor fd=resolver.openFileDescriptor(destination,"rwt")){
            require(fd!=null);try(java.io.FileOutputStream output=new android.os.ParcelFileDescriptor.AutoCloseOutputStream(fd)){
                for(int at=0;at<count;){current();int size=Math.min(4096,count-at);output.write(bytes,at,size);at+=size;}
                output.flush();current();output.getFD().sync();
            }
        }
        current();try(java.io.InputStream input=resolver.openInputStream(destination)){
            PlanetAdultDiagnosticJson.verify(input,count,checksum,this::current);
        }current();
    }
    private boolean removePartial(){
        try{return android.provider.DocumentsContract.deleteDocument(host.activity().getContentResolver(),destination);}
        catch(Throwable unavailable){return false;}
    }
    public void close(){
        synchronized(this){if(closed)return;closed=true;pickerPending=false;}returned.countDown();
        try{host.main(()->{
            if(expiryHandler!=null&&expiry!=null)expiryHandler.removeCallbacks(expiry);
            expiry=null;expiryHandler=null;
            if(pickerLaunched&&pickerEnded.getCount()!=0)((MainActivity)host.activity()).cancelAdultDiagnosticPicker(request.id);
            return null;
        });
            // Cleanup time can join an OS dismissal, but never permits more file writes or extends admission.
            cleanupKnown=!pickerLaunched||pickerEnded.await(2000,TimeUnit.MILLISECONDS);
            if(cancelled&&destination!=null&&!"saved".equals(outcome)&&!removePartial())cleanupKnown=false;
        }catch(Exception unavailable){cleanupKnown=false;}
        if(bytes!=null)Arrays.fill(bytes,(byte)0);bytes=null;request.close();
    }
}

