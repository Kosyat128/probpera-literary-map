package ru.probpera.literaryplanet;

import com.getcapacitor.BridgeActivity;
import android.os.Bundle;

public class MainActivity extends BridgeActivity {

    /** Dedicated, bounded result identities so cancellation can finish only our own picker. */
    private static final int DIAGNOSTIC_RESULT_FIRST=0x6d00,DIAGNOSTIC_RESULT_LIMIT=0x7500;
    private int nextDiagnosticResult=DIAGNOSTIC_RESULT_FIRST;
    private static final class DiagnosticPicker {
        final String id;final int code;final java.util.function.Consumer<androidx.activity.result.ActivityResult> callback;
        DiagnosticPicker(String id,int code,java.util.function.Consumer<androidx.activity.result.ActivityResult> callback){this.id=id;this.code=code;this.callback=callback;}
    }
    private DiagnosticPicker diagnosticPicker;
    @SuppressWarnings("deprecation")
    final void launchAdultDiagnosticPicker(String id,android.content.Intent intent,java.util.function.Consumer<androidx.activity.result.ActivityResult> callback)throws Exception{
        if(android.os.Looper.myLooper()!=android.os.Looper.getMainLooper()||diagnosticPicker!=null||nextDiagnosticResult>=DIAGNOSTIC_RESULT_LIMIT
            ||id==null||!id.matches("[a-f0-9]{32}")||callback==null||isFinishing()||isDestroyed()||!hasWindowFocus())throw new Exception("Diagnostic picker unavailable");
        DiagnosticPicker original=new DiagnosticPicker(id,nextDiagnosticResult++,callback);diagnosticPicker=original;
        try{startActivityForResult(intent,original.code);}catch(Throwable failure){diagnosticPicker=null;throw failure;}
    }
    /** Never finishes another application's unrelated activity or reuses a result identity. */
    final void cancelAdultDiagnosticPicker(String id)throws Exception{
        if(android.os.Looper.myLooper()!=android.os.Looper.getMainLooper())throw new Exception("Diagnostic picker unavailable");
        DiagnosticPicker original=diagnosticPicker;if(original!=null){if(!original.id.equals(id))throw new Exception("Diagnostic picker changed");finishActivity(original.code);}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,android.content.Intent data){
        if(requestCode>=DIAGNOSTIC_RESULT_FIRST&&requestCode<DIAGNOSTIC_RESULT_LIMIT){
            DiagnosticPicker original=diagnosticPicker;
            if(original!=null&&original.code==requestCode){diagnosticPicker=null;original.callback.accept(new androidx.activity.result.ActivityResult(resultCode,data));}
            return;
        }super.onActivityResult(requestCode,resultCode,data);
    }

    private PlanetChildWebResources childResources;
    final PlanetChildWebResources childWebResources() throws Exception {
        if(android.os.Looper.myLooper()!=android.os.Looper.getMainLooper()||getBridge()==null)throw new PlanetChildVault.Unavailable();
        if(childResources==null)childResources=PlanetChildWebResources.install(this);
        return childResources;
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(PlanetContentStorePlugin.class);
        registerPlugin(PlanetSecureStorePlugin.class);
        registerPlugin(PlanetChildPlugin.class);
        super.onCreate(savedInstanceState);
        try{childWebResources();}catch(Exception unavailable){childResources=null;}
    }
}
